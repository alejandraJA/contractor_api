﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    //dev:Rodolfo
    //Date: 26/08/2017
    //Modulo:Credito
    //Submodulo:MonederoRedimir
    public class DM0312_CMonederoxRedimir
    {
        public int idVenta { get; set; }

        public Dictionary<int, string> GetMonederoPorRedimir()
        {
            Dictionary<int, string> DiccionarioReturn = new Dictionary<int, string>();
            SqlDataReader dr = null;
            string query = string.Empty;

            query = string.Format(
                "SELECT  V.Cliente, Movimiento = v.Mov, v.MovID, Monedero = t.Serie,Saldo =SUM(SM.Saldo),Redimir = T.importe," +
                " SaldoPosterior = (SUM(SM.Saldo) - t.importe) FROM Venta V WITH(NOLOCK)  LEFT JOIN TarjetaSerieMovMAVI T WITH(NOLOCK) on v.id = T.id" +
                " LEFT JOIN Saldop SM WITH(NOLOCK) ON T.serie = SM.cuenta WHERE V.id = {0} " +
                "GROUP BY V.Cliente,v.Mov,v.MovID,t.Serie,t.importe", idVenta);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        for (int i = 0; i < dr.FieldCount; i++)
                        {
                            string value = dr[i].ToString();
                            DiccionarioReturn.Add(i, value);
                        }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CMonederoxRedimir", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return DiccionarioReturn;
        }

        public bool CondicionesMonedero()
        {
            bool res = false;
            SqlDataReader dr = null;
            string query = string.Empty;

            query = string.Format("SELECT COUNT(ID) FROM venta WITH(NOLOCK) " +
                                  " WHERE MOV IN (SELECT Mov from MovTipo WHERE Clave='VTAS.P')" +
                                  " AND Estatus='PENDIENTE' AND id={0}", idVenta);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows) res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CMonederoxRedimir", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return res;
        }
    }
}