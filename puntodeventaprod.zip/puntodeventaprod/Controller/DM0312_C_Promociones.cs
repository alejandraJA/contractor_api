﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class DM0312_C_Promociones
    {
        /// <summary>
        ///     Permite llenar lista con las imagenes de promociones
        /// </summary>
        /// <returns></returns>
        public List<DM0312_MPromociones> FillImage()
        {
            List<DM0312_MPromociones> listModel = new List<DM0312_MPromociones>();
            SqlDataReader dr = null;
            string query = "SELECT Uen, Imagen, IdImagen FROM [AdminDoc].[dbo].[TREDM0312_Promociones] WITH(NOLOCK) ";
            try
            {
                SqlCommand sqlCommad = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                sqlCommad.CommandType = CommandType.Text;
                dr = sqlCommad.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MPromociones promocion = new DM0312_MPromociones();
                    promocion.Uen = Convert.ToInt32(dr["Uen"].ToString());
                    promocion.Imagen = (byte[])dr.GetValue(1);
                    promocion.IdImagen = Convert.ToInt32(dr["IdImagen"].ToString());
                    listModel.Add(promocion);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return listModel;
        }


        /// <summary>
        ///     Actualiza la foto en null ("Se simula el delete")
        ///     Developer: Victor Avila
        ///     Date: 17/11/2017
        /// </summary>
        /// <param name="idFoto"></param>
        /// <returns>int</returns>
        public int DeletePicture(int idFoto, int UEN)
        {
            int validaDelete = 0;
            string query =
                "UPDATE  [AdminDoc].[dbo].[TREDM0312_Promociones] WITH(ROWLOCK) SET Imagen = 0x00  WHERE IdImagen = " +
                idFoto + " AND UEN = " + UEN + " ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                validaDelete = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Promociones", ex);
                MessageBox.Show(ex.Message);
            }

            return validaDelete;
        }


        public int UpdatePicture(byte[] b, int idFoto)
        {
            int validaDelete = 0;
            MemoryStream ms = new MemoryStream();


            string query =
                "UPDATE [AdminDoc].[dbo].[TREDM0312_Promociones] WITH(ROWLOCK) SET Imagen = @Imagen   WHERE IdImagen = @foto";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                sqlCommand.Parameters.Add(new SqlParameter("@Imagen", b));
                sqlCommand.Parameters.Add(new SqlParameter("@foto", idFoto));
                validaDelete = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Promociones", ex);
            }

            return validaDelete;
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            Image returnImage = null;
            try
            {
                MemoryStream ms = new MemoryStream(byteArrayIn, 0, byteArrayIn.Length);
                ms.Write(byteArrayIn, 0, byteArrayIn.Length);
                returnImage = Image.FromStream(ms, true);
            }
            catch
            {
            }

            return returnImage;
        }
    }
}