﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;


//GESSY 1286
namespace PuntoVenta.Controller {
    public class SancionController {
        public List<String> fetchMotivosSancion(string Valor) {
            string query = @"Select nombre
            from tablastd WITH (NOLOCK)
            WHERE TablaSt = 'MOTIVOSANCIONREACTIVACION'
            and Valor is null
                or Valor = @Valor";

            List<String> Motivos = new List<String>();

            try {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@Valor", Valor);
                //sqlCommand.CommandType = CommandType.Text;
                
                using (SqlDataReader reader = sqlCommand.ExecuteReader()) {
                    if (reader.HasRows) {
                        while (reader.Read()) {
                            Motivos.Add(reader[0].ToString());
                        }
                    }
                }

            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
            }

            return Motivos;
        }

        public bool guardarSancionPendiente(Dictionary<string, string> Parametros) {
            bool respuesta = false;
            try {
                string query = @"INSERT INTO VTASCSanciones 
                (fecha, sucursal, vendedor, monto, movID, cliente, usuarioCredito, observaciones, aplica, estatus)
                VALUES 
                (GETDATE(), @sucursal, @vendedor, @monto, @movID, @cliente, @usuarioCredito, @observaciones, @aplica, 'PENDIENTE')";

                using (var cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica)) {
                    foreach (var parametro in Parametros) {
                        cmd.Parameters.AddWithValue(parametro.Key, parametro.Value);
                    }

                    cmd.ExecuteNonQuery();
                }

            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
            } finally {
                respuesta = true;
            }

            return respuesta;
        }

        public string getSanctionAmount() {
            string Amount = "";

            string query = @"select valor
            from VTASCParametroDeSancion With(nolock)
            where Parametro = 'Sanc_Uni$'";

            try {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();

                if (dr.Read()) Amount = dr[0].ToString();
            } catch (Exception e) {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }
            
            return Amount;
        }
        
        
        
    }
}