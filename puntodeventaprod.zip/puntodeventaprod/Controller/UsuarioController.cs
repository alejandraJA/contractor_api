﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace PuntoVenta.Controller
{
    public class UsuarioController
    {
        public string AccesoUsuario(string usuario)
        {
            string accesoUsuario = string.Empty;

            string query = @"select top 1 acceso
            from usuario with (nolock)
            where Usuario = @usuario";

            SqlDataReader dr = null;
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@usuario", usuario);

                    cmd.CommandType = CommandType.Text;
                    dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                            accesoUsuario = dr.GetString(0);
                    else
                        accesoUsuario = "";
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return accesoUsuario;
        }
    }
}