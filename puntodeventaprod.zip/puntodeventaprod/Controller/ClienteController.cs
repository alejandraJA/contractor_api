﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class ClienteController
    {
        private static readonly Cliente cliente = new Cliente();
        private string query;

        private enumTablaSTD.TablaSTD std;

        public Cliente getClienteDB(string Codigo)
        {
            query = @"select top 1 Nombre from cte WITH (NOLOCK) where cliente = @cliente";

            conexion Conexion = new conexion();
            SqlConnection cnn = Conexion.SqlConexionERP("INTELISISTMP");
            cnn.Open();

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, cnn))
                {
                    cmd.Parameters.AddWithValue("@cliente", Codigo ?? "''");
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                cliente.Nombre = dr["Nombre"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);

                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            cnn.Close();

            return cliente;
        }

        public string getCorreoTemporalCliente(string Cliente)
        {
            string resultado = string.Empty;
            const string sQuery = @"SELECT dbo.FnCREDICorreosTemporalesClientes (@Cliente)";

            using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                cmd.Parameters.AddWithValue("@Cliente", Cliente);
                cmd.CommandType = CommandType.Text;

                try
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            if (dr.Read())
                                resultado = dr[0].ToString();
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return resultado;
        }

        public List<string> getListaCteGenericos()
        {
            std = enumTablaSTD.TablaSTD.CtesGenericos;

            SqlDataReader dr;
            List<string> resultado = new List<string>();

            using (SqlCommand cmd = new SqlCommand(std.getQuery(), ClaseEstatica.ConexionEstatica))
            {
                try
                {
                    cmd.ExecuteNonQuery();
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            resultado.Add(dr["cuenta"].ToString());
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return resultado ?? new List<string>();
        }
    }
}