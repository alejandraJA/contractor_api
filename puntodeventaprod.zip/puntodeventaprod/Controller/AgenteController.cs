﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class AgenteController
    {
        public Agente datosAgente(string Usuario)
        {
            Agente agenteM = new Agente();

            string query =
                @"SELECT top 1 
                p.Cuenta, 
                p.Propiedad, u.Nombre
                  FROM prop p WITH (NOLOCK)
                INNER JOIN Usuario u WITH (NOLOCK) ON p.cuenta = u.Usuario 
                AND p.Tipo = 'Giro' AND u.Usuario = @Usuario";

            SqlDataReader dr = null;
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add("@Usuario", Usuario);
                    cmd.CommandType = CommandType.Text;
                    using (dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            agenteM.ClaveAgente = dr["Cuenta"].ToString();
                            agenteM.Clave = dr["Propiedad"].ToString();
                            agenteM.NombreAgente = dr["Nombre"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return agenteM;
        }
    }
}