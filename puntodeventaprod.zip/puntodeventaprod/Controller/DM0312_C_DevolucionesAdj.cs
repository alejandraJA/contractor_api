﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_DevolucionesAdj
    {
        /// <summary>
        ///     Valida el movimiento a devolver o a adjudicar, que exista en la tabla Venta con estatus Concluido
        /// </summary>
        /// <param name="Mov">string</param>
        /// ///
        /// <param name="MovId">string</param>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public string ValidarAdjudicacionMov(string Mov, string MovId)
        {
            string ModID = "";
            SqlDataReader dr = null;
            string query = "select movid from venta WITH (NOLOCK) WHERE estatus='concluido' and mov = '" + Mov +
                           "' AND movid ='" + MovId + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        ModID = dr[0].ToString();
                else
                    ModID = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarAdjudicacionMov", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return ModID;
        }

        /// <summary>
        ///     Valida en la adjudicacion que el movimiento no sea de contado
        /// </summary>
        /// <param name="Mov">string</param>
        /// <param name="MovId">string</param>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public string ValidarAdjudicacionMovD(string Mov, string MovId)
        {
            string ModID = "";
            SqlDataReader dr = null;
            string query =
                "select movid from venta WITH (NOLOCK) WHERE enviara not in (2,5,6,1) and estatus='concluido' and mov = '" +
                Mov + "' AND movid ='" + MovId + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        ModID = dr[0].ToString();
                else
                    ModID = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarAdjudicacionMov", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return ModID;
        }

        /// <summary>
        ///     valida que la factura a la que se quiere devolver no tenga devoluciones concluidas con el importe total mayor al
        ///     que se quiere devolver
        /// </summary>
        /// <param name="mov">string</param>
        /// <param name="movid">string</param>
        /// <param name="op">int</param>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public string ValidarReferenciaDev(string mov, string movid, int op)
        {
            string referencia = "";
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SpEDM0312_ValidarDevolucion", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = mov;
                cmd.Parameters.Add("@MovID", SqlDbType.VarChar).Value = movid;
                cmd.Parameters.Add("@OP", SqlDbType.Int).Value = op;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        referencia = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarReferenciaDev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return referencia;
        }

        /// <summary>
        ///     valida que el movimiento a adjudicar no sea referencia de otros movimientos
        /// </summary>
        /// <param name="Referencia">string</param>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public string ValidarReferenciaAdj(string Referencia)
        {
            string referencia = "";
            SqlDataReader dr = null;
            string query =
                "select referencia from venta WITH (NOLOCK) where mov in ('Devolucion Venta','Sol Dev Unicaja') and estatus='pendiente' and referencia='" +
                Referencia + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        referencia = dr[0].ToString();
                else
                    referencia = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarReferenciaAdj", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return referencia;
        }

        /// <summary>
        ///     Elimina las series cargadas al momento de hacer alguna modificacion a las cantidades a devolver
        /// </summary>
        /// <param name="id">int</param>
        /// <param name="art">string</param>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public void DeleteSeries(int id, string art)
        {
            SqlDataReader dr = null;
            string query = "delete SerieLoteMov where id='" + id + "' and articulo='" + art + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarReferenciaAdj", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /// <summary>
        ///     Obtiene la informacion del cliente de la factura que se va a devolver
        /// </summary>
        /// <param name="Mov">string</param>
        /// <param name="MovId">string</param>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public List<string> InformacionFacturaDevolucion(string Mov, string MovId)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            string query =
                "SELECT v.Cliente,c.Nombre,v.agente,v.enviarA,v.condicion,v.Almacen,v.agenteservicio,v.id,v.importe,v.impuestos,v.uen,CONVERT(VARCHAR(10), V.FechaEmision , 103) AS FechaEmision FROM venta V WITH (NOLOCK) inner join cte C WITH (NOLOCK) on c.cliente =v.Cliente  WHERE mov = '" +
                Mov + "' AND movid ='" + MovId + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Lista.Add(dr[0].ToString());
                        Lista.Add(dr[1].ToString());
                        Lista.Add(dr[2].ToString());
                        Lista.Add(dr[3].ToString());
                        Lista.Add(dr[4].ToString());
                        Lista.Add(dr[5].ToString());
                        Lista.Add(dr[6].ToString());
                        Lista.Add(dr[7].ToString());
                        Lista.Add(dr[8].ToString());
                        Lista.Add(dr[9].ToString());
                        Lista.Add(dr[10].ToString());
                        Lista.Add(dr[11].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InformacionFacturaDevolucion", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Manda a llamar los almacenes a los que se podra adjudicar
        /// </summary>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public List<string> ListaAlmacenesADJ()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            string query = "select almacen from Alm WITH (NOLOCK) where RecibeAjd =1";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr.GetString(0));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ListaAlmacenesADJ", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Obtiene los articulos del paquete seleccionado
        /// </summary>
        /// <param name="articulo">string</param>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public List<string> ArtPaquetes(string articulo)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            string query = "SELECT Opcion FROM ArtJuegod with(nolock) where articulo='" + articulo + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr.GetString(0));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("artPaquetes", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Validar si el articulo seleccionado es paquete o no
        /// </summary>
        /// <param name="Tipo">string</param>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public string TipoArtPaquetes(string Tipo)
        {
            string TipoP = "";
            SqlDataReader dr = null;
            string query = "select tipo from art with(nolock) where articulo= '" + Tipo + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        TipoP = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TipoArtPaquetes", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return TipoP;
        }

        /// <summary>
        ///     Obtiene las series permitidas para cada articulo
        /// </summary>
        /// <param name="id">string</param>
        /// <param name="art">string</param>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public string SerieArtPaquete(string id, string art)
        {
            string SerieP = "";
            SqlDataReader dr = null;
            string query = "select SerieLote from serielotemov with(nolock) where id= '" + id + "' and articulo='" +
                           art + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        SerieP = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SerieArtPaquete", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return SerieP;
        }


        public string obtenerPropiedad(string id, string art)
        {
            string SerieP = "";
            SqlDataReader dr = null;
            string query = "select Propiedades from serielotemov with(nolock) where id= '" + id + "' and articulo='" +
                           art + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        SerieP = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SerieArtPaquete", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return SerieP;
        }

        public string MonederoRedimido(string id)
        {
            string monedero = "";
            SqlDataReader dr = null;
            string query = "select sum(Importe) from TarjetaSerieMovMAVI WITH (NOLOCK) where id = '" + id + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        monedero = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MonederoRedimido", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return monedero;
        }

        /// <summary>
        ///     Obtiene la sucursal del almacen seleccionado
        /// </summary>
        /// <param name="Almacen">string</param>
        /// Developer:Erika Perez
        /// Date: 28/10/17
        public int SucursalALM(string Almacen)
        {
            int suc = 0;
            SqlDataReader dr = null;
            string query = "select Sucursal from alm WITH (NOLOCK) where almacen= '" + Almacen + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        suc = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalALM", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return suc;
        }

        public string PropAgente(string usuario)
        {
            string Agente = "";
            SqlDataReader dr = null;
            string query = " SELECT top 1 Propiedad FROM Prop with (nolock) WHERE Cuenta= '" + usuario + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        Agente = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("PropAgente", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Agente;
        }

        /// <summary>
        ///     Obtiene el detalle del movimento a devolver
        /// </summary>
        /// <param name="id">int</param>
        /// Developer:Erika Perez
        /// Date: 29/10/17
        public DataTable DetalleVenta(int id)
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_DM0312PuntoDeVentaDetalleDev", ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@id", SqlDbType.VarChar).Value = id;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DetalleVenta", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public DateTime fechaA(int ID)
        {
            DateTime fecha = new DateTime();
            string query = "select FECHAEMISION FROM VENTA WHERE ID= " + ID + "";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) fecha = Convert.ToDateTime(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fecha;
        }


        ////////////////////
        public void borrarVentaCteD(int id, int estacion)
        {
            SqlDataReader dr = null;
            string query = string.Empty;


            query = string.Format("	delete VentaCteDLista   WHERE id = '" + id + "' and estacion='" + estacion + "' ");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("UpdateComentarios", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }
        /////////////////////

        public bool InsertspVentaCte_Dev(string cliente, DateTime fechaA, DateTime fechaB)
        {
            bool res = false;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spVentaCteD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@Estacion", SqlDbType.Int).Value = ClaseEstatica.WorkStation;
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = "MAVI";
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.AddWithValue("@FechaD", fechaA);
                cmd.Parameters.AddWithValue("@FechaA", fechaB);
                cmd.ExecuteNonQuery();
                res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_Dev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            return res;
        }

        ///////////////////////////

        public void UpdateVentaCteD(int id, string articulo, int cantidad)
        {
            SqlDataReader dr = null;
            string query = string.Empty;


            query = string.Format("	UPDATE Vcte WITH (ROWLOCK) SET Vcte.CantidadA = '" + cantidad +
                                  "' FROM VentaCteDLista Vcte INNER JOIN VentaCteD d  ON d.ID = vcte.ID and d.Estacion=vcte.Estacion and d.Renglon=vcte.Renglon  WHERE vcte.ID = '" +
                                  id + "' and  vcte.estacion='" + ClaseEstatica.WorkStation + "' and d.Articulo='" +
                                  articulo + "' ");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("UpdateVentaCteD", "DM0312_C_DevolucionesAdj", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /////////////////////////////////

        public bool InsertspVentaCteMonedero_Dev(int suc, int ventaid)
        {
            bool res = false;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spVentaCteDAceptar";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = suc;
                cmd.Parameters.Add("@Estacion", SqlDbType.Int).Value = ClaseEstatica.WorkStation;
                cmd.Parameters.Add("@VentaID", SqlDbType.Int).Value = ventaid;
                cmd.Parameters.Add("@MovTipo", SqlDbType.VarChar).Value = "VTAS.SD";
                cmd.Parameters.Add("@CopiaridVenta", SqlDbType.Int).Value = 1;
                cmd.ExecuteNonQuery();
                res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_Dev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            return res;
        }

        ///////////////////////////////////


        /// <summary>
        ///     Inserta/Elimina articulo en VentaD para devolucion de paquetes
        /// </summary>
        /// <param name="item">model</param>
        /// <param name="art">string</param>
        /// <param name="IdVenta">int</param>
        /// <param name="IdFactura">int</param>
        /// <param name="renglon">int</param>
        /// <param name="renglonID">int</param>
        /// <param name="renglonSub">int</param>
        /// Developer:Erika Perez
        /// Date: 29/10/17
        public bool InsertVentaD_DevPaquetes(DM0312_M_DetalleDev item, string art, int IdVenta, int IdFactura,
            int renglon, int renglonID, int renglonSub, int cantP)
        {
            bool res = false;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0312InsertVentadDevoluciones";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.Add("@IdFactura", SqlDbType.Int).Value = IdFactura;
                cmd.Parameters.Add("@Renglon", SqlDbType.Int).Value = renglon;
                cmd.Parameters.AddWithValue("@RenglonSub", renglonSub);
                cmd.Parameters.AddWithValue("@RenglonID", renglonID);
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = art;
                cmd.Parameters.Add("@Cantidad", SqlDbType.Float).Value = cantP;
                cmd.Parameters.Add("@IDCOPIAMAVI", SqlDbType.Int).Value = IdFactura;
                cmd.ExecuteNonQuery();
                res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_Dev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            return res;
        }

        /// <summary>
        ///     Inserta/Elimina articulo en VentaD para devolucion
        /// </summary>
        /// <param name="item">model</param>
        /// <param name="IdVenta">int</param>
        /// <param name="IdFactura">int</param>
        /// <param name="renglon">int</param>
        /// <param name="renglonID">int</param>
        /// Developer:Erika Perez
        /// Date: 30/10/17
        public bool InsertVentaD_Dev(DM0312_M_DetalleDev item, int IdVenta, int IdFactura, int renglon, int renglonID)
        {
            int defaultInt = 0;

            bool res = false;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0312InsertVentadDevoluciones";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.Add("@IdFactura", SqlDbType.Int).Value = IdFactura;
                cmd.Parameters.Add("@Renglon", SqlDbType.Int).Value = renglon;
                cmd.Parameters.AddWithValue("@RenglonSub", defaultInt);
                cmd.Parameters.AddWithValue("@RenglonID", renglonID);
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Cantidad", SqlDbType.Float).Value = item.CantidadDevolver;
                cmd.Parameters.Add("@IDCOPIAMAVI", SqlDbType.Int).Value = IdFactura;
                ////Se agrega el renglon////
                cmd.Parameters.Add("@RenglonF", SqlDbType.Int).Value = item.renglon;
                ////////////////////////////
                cmd.ExecuteNonQuery();
                res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_Dev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            return res;
        }


        #region MetodosSeriesDev //Rodolfo

        public int CountSerieLoteMov(int idventaDev)
        {
            SqlDataReader dr = null;

            int res = 0;

            string query = string.Format("select count(*) from serielotemov WITH(NOLOCK) where id={0}", idventaDev);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        string res_ = dr[0].ToString();

                        res = Convert.ToInt32(res_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_Dev", "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message + "en " + "DM0312_C_Devoluciones");
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }


            return res;
        }

        #endregion

        #region //-CandadoEmbarque

        /// <summary>
        ///     Metodo encargado de obtener el estatus e id del embarque
        /// </summary>
        /// <param name="sMovid">Mov id de la factura</param>
        /// <returns>retorna un string con el estatus e id del embarque</returns>
        public string validarEstatusEmbarque(string sMovid)
        {
            DataTable dt = new DataTable();
            string sEstatusIdEmbarque = string.Empty;
            try
            {
                string sQuery =
                    "SELECT e.Estatus,e.ID FROM Embarque e WITH(NOLOCK) INNER JOIN EmbarqueMov em WITH(NOLOCK) " +
                    "ON e.ID = em.AsignadoID INNER JOIN Venta v WITH(NOLOCK) ON v.MovID = em.MovID AND v.Mov = em.Mov WHERE v.MovID = @MovId";

                SqlParameter[] pars =
                {
                    new SqlParameter("@MovId", sMovid)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        sEstatusIdEmbarque = row["Estatus"] + "|" + row["ID"];
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sEstatusIdEmbarque;
        }

        #endregion

        public bool validarSiEsPromocion(string sMovId)
        {
            bool bEsPromocion = false;
            try
            {
                string sQuery = @"select top 1 vd.ID from venta v with(nolock) 
                                join ventad vd with(nolock)
                                on v.ID = vd.ID
                                where mov in('Factura', 'Factura Viu', 'Factura Mayoreo') and MovID = @MovId
                                and IdCampanaPromocion is not null";

                SqlParameter[] pars =
                {
                    new SqlParameter("@MovId", sMovId)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEsPromocion = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bEsPromocion;
        }


        public bool validarDevolucionVenta(string sReferencia)
        {
            bool bEsPromocion = false;
            try
            {
                string sQuery =
                    @"select top 1 ID from venta where Referencia = @Referencia and mov in( 'Devolucion Venta', 'Devolucion Viu', 'Devolucion Mayoreo')
                                    AND Estatus = 'CONCLUIDO'
                                    ORDER BY ID DESC";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Referencia", sReferencia)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEsPromocion = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bEsPromocion;
        }


        #region MetodosVentaDAdjudicaciones //Rodolfo

        /// <summary>
        ///     obtener articulo para adjudicación
        /// </summary>
        /// <param name="articulo">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 13/11/17
        public List<DM0312_M_ArticulosAdjudicados> BuscaArticulosAdjText(string Articulo)
        {
            List<DM0312_M_ArticulosAdjudicados> Lista = new List<DM0312_M_ArticulosAdjudicados>();

            SqlDataReader dr = null;

            string query = string.Empty;

            //query = string.Format("SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Art.Estatus, ISNULL(Disponible,0) as Disponible,Impuesto1 as Impuesto,Art.Tipo as Tipo,unidad FROM Art WITH(NOLOCK) INNER JOIN ArtDisponible  WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo INNER JOIN ALM ON ArtDisponible.Almacen = ALM.almacen " +
            // " WHERE art.Grupo ='MERCANCIA ESPECIAL' AND Art.Categoria ='VENTA' AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Art.Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' and ArtDisponible.Disponible>0  and Alm.Categoria='ADJUDICACION' " +
            // " AND Art.Articulo='{0}'" +
            // " ORDER BY Art.Articulo", Articulo);

            query = string.Format(
                "SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Art.Estatus, ISNULL(Disponible,0) as Disponible,Impuesto1 as Impuesto,Art.Tipo as Tipo,unidad FROM Art WITH(NOLOCK) INNER JOIN ArtDisponible  WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo INNER JOIN ALM WITH (NOLOCK) ON ArtDisponible.Almacen = ALM.almacen " +
                " WHERE art.Grupo ='MERCANCIA ESPECIAL' AND Art.Categoria ='VENTA' AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Art.Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' and ArtDisponible.Disponible>0  and Alm.Categoria='ADJUDICACION' " +
                " and Art.Articulo='{0}'" +
                " ORDER BY Art.Articulo", Articulo);

            try
            {
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_M_ArticulosAdjudicados EmptyModel = new DM0312_M_ArticulosAdjudicados();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_M_ArticulosAdjudicados model_ = new DM0312_M_ArticulosAdjudicados();
                        model_.Codigo = dr["Codigo"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Linea = dr["Linea"].ToString();
                        model_.Estatus = dr["Estatus"].ToString();
                        model_.Disponible = dr["Disponible"].ToString();
                        model_.Impuesto = dr["Impuesto"].ToString();
                        model_.Tipo = dr["Tipo"].ToString();
                        model_.unidad = dr["unidad"].ToString();
                        Lista.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_DevolucionesAdj", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     obtener id de inventario dependiente del articulo para adjudicación
        /// </summary>
        /// <param name="articulo">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 14/11/17
        public string InvDSelect(string articulo)
        {
            string rest = string.Empty;

            string query = string.Format("SELECT I.ID,COSTO,CANTIDAD,IMPORTE,D.Almacen FROM InvD D WITH (NOLOCK)" +
                                         " JOIN Inv I WITH (NOLOCK) ON D.ID=I.ID" +
                                         " WHERE D.Articulo='{0}' AND " +
                                         " D.Almacen in(select Almacen from alm WITH(NOLOCK) where Nombre like 'ALMACEN ADJUDICACION%')",
                articulo);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr[0] + "," + dr[1] + "," + dr[2] + "," + dr[3] + "," + dr[4];
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Devoluciones", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }

        #endregion
    }
}