﻿using System.Data.SqlClient;
using System.Reflection;
using Conexion;

namespace PuntoVenta
{
    internal class conexion
    {
        private const string _ServerAndroid =
#if CUBOS
                "MAVICBOSANDROID"
#elif PRODUCCION || PRODDEBUG
            "MAVIANDROID01"
#elif PROSERVER
            "PROSERVER"
#endif
            ;

        private const string _ServerERPMAVI =
#if CUBOS
                "MAVICUBOS"
#elif PRODUCCION || PRODDEBUG
            "ERPMAVI"
#elif PROSERVER
            "PROSERVER"
#endif
            ;


        public void SqlConexionStatica()
        {
            SqlConnection cnn = ObjetoConexion.getconexion(_ServerERPMAVI, "INTELISISTMP");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn.ConnectionString = builder.ConnectionString;
            ClaseEstatica.ConexionEstatica = cnn;
        }

        public SqlConnection SqlConexionERP(string DataBase)
        {
            SqlConnection cnn = ObjetoConexion.getconexion(_ServerERPMAVI, DataBase);
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn.ConnectionString = builder.ConnectionString;
            return cnn;
        }

        public void SqlConexionStaticaAndroid()
        {
            SqlConnection cnn2 = ObjetoConexion.getconexion(_ServerAndroid, "ADMINDOC");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn2.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn2.ConnectionString = builder.ConnectionString;
            ClaseEstatica.ConexionEstaticaAndroid = cnn2;
        }

        public void SqlConexionStaticaAndroidServicio()
        {
            SqlConnection cnn2 = ObjetoConexion.getconexion(_ServerAndroid, "servicioandroid");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn2.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn2.ConnectionString = builder.ConnectionString;
            ClaseEstatica.ConexionEstaticaAndroidS = cnn2;
        }

        public void SqlConexionStaticaHistoricoAdminDoc()
        {
            SqlConnection cnn2 = ObjetoConexion.getconexion(_ServerAndroid, "AdminDocHistorico");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn2.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn2.ConnectionString = builder.ConnectionString;
            ClaseEstatica.ConexionHistoricoAdminDoc = cnn2;
        }

        public void SqlConexionStaticaAndroidSid()
        {
            SqlConnection cnn3 = ObjetoConexion.getconexion(_ServerAndroid, "SID");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cnn3.ConnectionString);
            builder.ApplicationName = Assembly.GetCallingAssembly().GetName().Name;
            cnn3.ConnectionString = builder.ConnectionString;
            ClaseEstatica.ConexionEstaticaAndroidSid = cnn3;
        }
    }
}