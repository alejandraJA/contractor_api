﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CrtlHistorialSolicitudes
    {
        /// <summary>
        ///     Metodo que permite llenar el dataGrid Eventos Historial Solicitudes
        ///     <param name="movimiento"></param>
        ///     <param name="tipoMovimiento"></param>
        ///     <returns>DataSet</returns>
        ///     Developer: Victor Avila
        ///     Date:04/08/2017
        ///     <summary>
        public DataTable LlenaConsultarEventosHistorialSolicitudes(string movimiento, string tipoMovimiento)
        {
            DataTable dataSet = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            string query =
                "SELECT  mb.Fecha, mb.Clave, sg.Descripcion, mb.Evento, mb.Usuario, u.Nombre  FROM MovBitacora mb WITH(NOLOCK) " +
                "INNER JOIN Usuario u WITH(NOLOCK) ON  u.Usuario = mb.Usuario " +
                "INNER JOIN MAVIClaveSeguimiento sg WITH(NOLOCK) ON sg.Clave = mb.Clave " +
                "WHERE mb.id=@Id order by mb.fecha desc";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                SqlParameter sqlParameter = new SqlParameter("@Id", SqlDbType.VarChar);
                sqlParameter.Value = movimiento;
                sqlCommand.Parameters.Add(sqlParameter);
                sqlParameter = new SqlParameter("@Mov", SqlDbType.VarChar);
                sqlParameter.Value = tipoMovimiento;
                sqlCommand.Parameters.Add(sqlParameter);
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);

                foreach (DataRow item in dataSet.Rows) item["Clave"] = item["Clave"] + "  " + item["Descripcion"];
                dataSet.Columns.Remove("Descripcion");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlHistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Permite llenar el Datagrid  principal de la forma Historial Solicitudes
        ///     <param name="mov"></param>
        ///     <param name="situacion"></param>
        ///     <param name="estatus"></param>
        ///     <param name="fechaD"></param>
        ///     <param name="fechaA"></param>
        ///     <param name="cliente"></param>
        ///     <param name="movId"></param>
        ///     Developer: Victor Avila
        ///     Date: 02/09/2017
        ///     <returns>List<DM0312_MHistorialSolicitudes></returns>
        public List<DM0312_MHistorialSolicitudes> LlenaDataGridHistorialSolicitudes(string mov, string situacion,
            string estatus, string fechaD, string fechaA, string cliente, string movId, string canal)
        {
            List<DM0312_MHistorialSolicitudes> modelHistorial = new List<DM0312_MHistorialSolicitudes>();
            SqlDataAdapter sqlDataAdatpter = new SqlDataAdapter();
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312PuntoVentaHistorialSolicitudes",
                    ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.Add("@Movimiento", SqlDbType.VarChar).Value = mov;
                sqlCommand.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = situacion;
                sqlCommand.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = estatus;
                sqlCommand.Parameters.Add("@FechaD", SqlDbType.VarChar).Value = fechaD;
                sqlCommand.Parameters.Add("@FechaA", SqlDbType.VarChar).Value = fechaA;
                sqlCommand.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                sqlCommand.Parameters.Add("@MovId", SqlDbType.VarChar).Value = movId;
                sqlCommand.Parameters.Add("@CanalVenta", SqlDbType.VarChar).Value = canal;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MHistorialSolicitudes historial_ = new DM0312_MHistorialSolicitudes();
                        historial_.Id = Convert.ToInt32(dr["id"].ToString());
                        historial_.Movimiento = dr["Movimiento"] + " " + dr["ID_Movimiento"];
                        historial_.IdMovimiento = dr["ID_Movimiento"].ToString();
                        historial_.CanalVenta = dr["Canal_Venta"].ToString();
                        historial_.Suc = dr["Suc"].ToString();
                        historial_.Cuenta = dr["Cuenta"].ToString();
                        historial_.Situacion = dr["Situacion"].ToString();
                        historial_.Agente = dr["Agente"].ToString();
                        historial_.NombreCliente = dr["Nombre_Cliente"].ToString();
                        historial_.Estatus = dr["Estatus"].ToString();
                        historial_.FechaAlta = Convert.ToDateTime(dr["FechaAlta"]);
                        historial_.ImporteTotal = "$ " + Convert.ToDouble(dr["ImporteTotal"]).ToString("0.00");
                        historial_.Totalizador = Convert.ToDouble(dr["ImporteTotal"]);
                        historial_.Calificacion = dr["Calificacion"].ToString();
                        historial_.FechaUltimaMod = dr["FechaUltMov"].ToString();
                        historial_.Condicion = dr["Condicion"].ToString();
                        historial_.Usuario = dr["Usuario"].ToString();
                        historial_.Mov = dr["Movimiento"].ToString();
                        modelHistorial.Add(historial_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlHistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return modelHistorial;
        }

        /// <summary>
        ///     Metodo que permite llenar el comboBox Situacion
        /// </summary>
        /// <param name="tablero"></param>
        /// <returns></returns>
        /// Developer: Victor Avila
        /// Date:13/09/2017
        public List<string> ComboSituacion(HistorialSolicitudes tablero)
        {
            object comboMov = tablero.cbx_movimiento.SelectedItem;
            object comboSituacion = tablero.cbx_Situacion.SelectedItem;
            string query =
                "SELECT DISTINCT Ms.Situacion FROM MovSituacion Ms WITH(NOLOCK) WHERE Ms.Modulo='VTAS' AND Mov = @Mov";
            List<string> situacion = new List<string>();
            SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Mov", Convert.ToString(comboMov));
            SqlDataReader dr = null;
            try
            {
                dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        situacion.Add(dr.GetString(0));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlHistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return situacion;
        }

        /// <summary>
        ///     Permite llenar el comboBox Canal principal
        ///     Developer : Victor Avila
        ///     Date: 10/09/2017
        /// </summary>
        /// <param name="cliente"></param>
        /// <returns></returns>
        public List<int> ComboCanalesVenta(string cliente)
        {
            List<int> list = new List<int>();
            string query =
                "SELECT ct.ID FROM VentasCanalMAVI vm WITH (NOLOCK) INNER JOIN CteEnviarA  ct WITH (NOLOCK) ON ct.ID = vm.ID WHERE ct.Cliente = @Cliente AND vm.Categoria IN ('CREDITO MENUDEO', 'ASOCIADOS')";
            SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Cliente", cliente);
            SqlDataReader dr = null;
            try
            {
                dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        list.Add(dr.GetInt32(0));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlHistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return list;
        }

        /// <summary>
        ///     Busca el cliente para verificar que sea correcto y este dado de alta
        /// </summary>
        /// Developer : Victor Avila
        /// Date: 11/09/2017
        /// <returns></returns>
        public int ValidaUsuario(string cliente)
        {
            int validaUsua = 0;
            SqlDataReader dr = null;
            string query = "SELECT COUNT(*) FROM  Cte WITH(NOLOCK) WHERE Estatus = 'Alta'  AND Cliente = @Cliente ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Cliente", cliente);
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        validaUsua = dr.GetInt32(0);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlHistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return validaUsua;
        }


        public List<string> ActualizacionDatos(string cliente)
        {
            List<string> lista = new List<string>();
            SqlDataReader dr = null;
            string query =
                "select top 1 FechaEmision,sucursal,usuario from venta v with (nolock) inner join MovCampoExtra c on c.id=v.id where C.Modulo='VTAS' AND v.cliente= '" +
                cliente + "' order by v.fechaemision desc";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        lista.Add(dr[0].ToString());
                        lista.Add(dr[1].ToString());
                        lista.Add(dr[2].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ListaNominas", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return lista;
        }
    }
}