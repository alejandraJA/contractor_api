﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta.Controller
{
    internal class CAlmacenes
    {
        /// <summary>
        ///     Obtiene los almacenes disponibles del tipo de almacen actual
        /// </summary>
        /// <returns>List<MAlmacen></returns>
        /// Developer: Dan Palacios
        /// Date:26/08/17
        public List<MAlmacen> ObtenerAlmacenes()
        {
            List<MAlmacen> Almacenes = new List<MAlmacen>();

            SqlCommand command = new SqlCommand("SP_DM0312ManejoAlmacenes", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@ID", DM0312_DetalleCambiarAlmacen.IDVenta);
            command.Parameters.AddWithValue("@Almacen", DM0312_DetalleCambiarAlmacen.AlmacenActual);
            command.CommandType = CommandType.StoredProcedure;
            SqlParameter returnParameter = command.Parameters.Add("@ReturnVal", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;

            try
            {
                SqlDataReader dr = command.ExecuteReader();
                int result = 1;
                if (returnParameter.Value != null) result = (int)returnParameter.Value;

                if (result == 1)
                {
                    if (dr.HasRows)
                        while (dr.Read())
                        {
                            MAlmacen NuevoAlmacen = new MAlmacen
                            {
                                Clave = (string)dr["Almacen"],
                                Nombre = (string)dr["Nombre"],
                                Sucursal = (int)dr["Sucursal"]
                            };
                            Almacenes.Add(NuevoAlmacen);
                        }
                }
                else
                {
                    Almacenes.Clear();
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerAlmacenes", "CAlmacenes.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerAlmacenes, class: CAlmacenes.cs");
            }

            return Almacenes;
        }

        /// <summary>
        ///     Actualiza el almacen del movimiento
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        public int ActualizarAlmacen(string Estatus)
        {
            SqlCommand command = new SqlCommand("SP_DM0312ManejoAlmacenes", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@ID", DM0312_DetalleCambiarAlmacen.IDVenta);
            command.Parameters.AddWithValue("@Almacen", DM0312_DetalleCambiarAlmacen.AlmacenActual);
            if (Estatus != "PENDIENTE") command.Parameters.AddWithValue("@Estatus", Estatus);
            command.Parameters.AddWithValue("@CambiarAlmacen", true);
            command.CommandType = CommandType.StoredProcedure;
            SqlParameter returnParameter = command.Parameters.Add("@ReturnVal", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;
            int result = 0;
            try
            {
                command.ExecuteNonQuery();
                if (returnParameter.Value != null) result = (int)returnParameter.Value;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizarAlmacen", "CAlmacenes.cs", ex);
                MessageBox.Show(ex.Message + " function: ActualizarAlmacen, class: CAlmacenes.cs");
            }

            return result;
        }
    }
}