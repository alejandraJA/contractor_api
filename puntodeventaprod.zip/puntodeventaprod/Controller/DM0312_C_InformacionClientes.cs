﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_InformacionClientes
    {
        /// <summary>
        ///     Optiene la informacion principal del cliente
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 05/09/17
        public List<string> InfoCliente(string cliente)
        {
            List<string> informacion = new List<string>();
            SqlCommand command = new SqlCommand("SP_MaviDM0312InformacionCliente", ClaseEstatica.ConexionEstatica);
            command.CommandType = CommandType.StoredProcedure;

            try
            {
                SqlParameter infoCliente = new SqlParameter("@Cliente", SqlDbType.VarChar);
                infoCliente.Value = cliente;
                command.Parameters.Add(infoCliente);
                SqlDataReader slqDataReader = command.ExecuteReader();
                if (slqDataReader.HasRows)
                    while (slqDataReader.Read())
                    {
                        informacion.Add(slqDataReader.GetString(0));
                        informacion.Add(slqDataReader.GetString(1));
                        informacion.Add(slqDataReader.GetString(2));
                        informacion.Add(slqDataReader.GetString(3));
                        informacion.Add(slqDataReader.GetString(4));
                        informacion.Add(slqDataReader.GetString(5));
                        informacion.Add(slqDataReader.GetString(6));
                        informacion.Add(slqDataReader.GetString(7));
                        informacion.Add(slqDataReader.GetString(8));
                        informacion.Add(slqDataReader.GetString(9));
                        informacion.Add(slqDataReader.GetString(10));
                        informacion.Add(slqDataReader.GetString(11));
                        informacion.Add(slqDataReader.GetString(12));
                        informacion.Add(slqDataReader.GetString(13));
                        informacion.Add(slqDataReader.GetString(14));
                    }

                slqDataReader.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InfoCliente", "DM0312_C_InformacionClientes", ex);
                MessageBox.Show(ex.Message);
            }

            return informacion;
        }

        /// <summary>
        ///     Obtiene Ventas Pendientes
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="FechaInicio">DateTime</param>
        /// <param name="FechaFin">DateTime</param>
        /// <returns>DataTable</returns>
        /// Fecha modificacion: 16/11/17
        /// Autor de modificacion: Dan Palacios
        /// Descripcion de modificacion: se agrega fecha inicio y fecha de terminacion para busquedas y se agrega log
        public DataTable VentasPendientes(string cliente, DateTime FechaInicio, DateTime FechaFinal)
        {
            DataTable dataSet = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            string query = "SELECT Movimiento=(Venta.Mov+' '+Venta.MovID), Venta.FechaEmision, venta.FechaRequerida, " +
                           "cast(venta.Saldo as varchar(20)) Saldo FROM  Venta WITH (NOLOCK) WHERE VENTA.Cliente = @Cliente " +
                           " AND FechaEmision between @FechaInicio AND @FechaFinal AND VENTA.estatus='Pendiente'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Cliente", cliente);
                sqlCommand.Parameters.AddWithValue("@FechaInicio", FechaInicio);
                sqlCommand.Parameters.AddWithValue("@FechaFinal", FechaFinal);
                adapter.SelectCommand = sqlCommand;
                adapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VentasPendientes", "DM0312_C_InformacionClientes", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene Ventas Pendientes
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="FechaInicio">DateTime</param>
        /// <param name="FechaFin">DateTime</param>
        /// <returns>DataTable</returns>
        /// Fecha modificacion: 16/11/17
        /// Autor de modificacion: Dan Palacios
        /// Descripcion de modificacion: se agrega fecha inicio y fecha de terminacion para busquedas
        public DataTable DatosXcobrar(string Cliente, DateTime FechaDE, DateTime FechaA)
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_MaviDM0312InformacionClienteDatosCobrar", ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@ClienteD", SqlDbType.VarChar).Value = Cliente;
                command.Parameters.Add("@FechaDE", SqlDbType.DateTime).Value = FechaDE;
                command.Parameters.Add("@FechaA", SqlDbType.DateTime).Value = FechaA;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosXcobrar", "DM0312_C_InformacionClientes", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene habitos de pago
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Buscador">string</param>
        /// <param name="FechaInicio">DateTime</param>
        /// <param name="FechaFin">DateTime</param>
        /// <returns>DataTable</returns>
        /// Fecha modificacion: 16/11/17
        /// Autor de modificacion: Dan Palacios
        /// Descripcion de modificacion: se agrega fecha inicio y fecha de terminacion para busquedas
        public DataTable HabitoPago(string Cliente, string Buscador, DateTime FechaInicio, DateTime FechaFin)
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_MaviDM0312InformacionClienteHabitosPago", ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                command.Parameters.Add("@Buscar", SqlDbType.VarChar).Value = Buscador;
                command.Parameters.AddWithValue("@FechaInicio", FechaInicio);
                command.Parameters.AddWithValue("@FechaFin", FechaFin);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("HabitoPago", "DM0312_C_InformacionClientes", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        #region //-BeneficiariosFinales

        /// <summary>
        ///     Metodo encargado de validar si el cliente seleccionado tiene algun beneficiario registrado.
        /// </summary>
        /// <returns>Retorna true si el cliente cuenta con algun beneficiario </returns>
        public bool TieneBeneficiario(string cliente)
        {
            bool tiene = false;
            try
            {
                string sQuery =
                    "select top 1 id from venta with(nolock) where cliente = @Cliente and enviara = 76 and mov = 'Analisis Credito' " +
                    "and ctefinal <> '' ";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", cliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        tiene = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return tiene;
        }


        /// <summary>
        ///     Metodo encargado de validar si el cliente seleccionado tiene algun aval registrado.
        /// </summary>
        /// <returns>Retorna true si el cliente cuenta con algun aval registrado </returns>
        public bool TieneAval(string cliente)
        {
            bool tiene = false;
            try
            {
                string sQuery = "select * from ctecto where cliente= @Cliente and tipo='aval'";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", cliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        tiene = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return tiene;
        }

        #endregion
    }
}