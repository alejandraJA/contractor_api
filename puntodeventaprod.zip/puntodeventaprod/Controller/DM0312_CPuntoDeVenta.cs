﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public partial class DM0312_CPuntoDeVenta
    {
        private readonly DM0312_C_ExploradorVenta c = new DM0312_C_ExploradorVenta();
        private readonly DM0312_C_UpdPrecioEmp controller = new DM0312_C_UpdPrecioEmp();

        /// <summary>
        ///     Valida la informacion del cliente y separa el correo por cuenta y dominio
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 17/09/17
        public List<string> LlenaDatosCliente(string Cliente)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312DatosGeneralesCliente ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente  ", SqlDbType.VarChar).Value = Cliente;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Lista.Add(dr[0].ToString());
                        Lista.Add(dr[1].ToString());
                        Lista.Add(dr[2].ToString());
                        Lista.Add(dr[3].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaDatosCliente", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        public List<string> ListaNominas(string nomina, string cliente)
        {
            List<string> nominas = new List<string>();
            SqlDataReader dr = null;
            string query =
                "select a.cliente from CteEnviarA a with (nolock) inner join cte c on c.Cliente=a.Cliente where id=34 and a.cliente <>'" +
                cliente + "' and nomina= '" + nomina + "' and c.Estatus='alta'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        nominas.Add(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ListaNominas", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return nominas;
        }


        public int SucursalRDP(int sucursal)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format(
                        "SELECT COUNT(Numero) TabNum FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum='SUCURSALES RDP' AND CAST(Numero AS INT)=" +
                        sucursal + "");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valor = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalRDP", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valor;
        }


        public int numeroDocumentos(string condicion)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format("select top 1 DANumeroDocumentos from Condicion with (nolock) where Condicion = '" +
                                  condicion + "'");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valor = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalRDP", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valor;
        }

        public string LineaART(string articulo)
        {
            string valor = "";
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format("select top 1 linea from art with (nolock) where articulo = '" + articulo + "'");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valor = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LineaART", "CPuntoVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valor;
        }

        public List<string> InfoCorreoTemporal(string Cliente)
        {
            List<string> Lista = new List<string>();

            try
            {
                using (SqlCommand cmd = new SqlCommand("SP_DM0312CorreoTemporal ", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Cliente  ", SqlDbType.VarChar).Value = Cliente;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                Lista.Add(dr[0].ToString());
                                Lista.Add(dr[1].ToString());
                            }

                        dr.Close();
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return Lista;
        }

        /// <summary>
        ///     Manda traer los precios del articulo seleccionado y de cada una de sus condiciones de venta
        /// </summary>
        /// <param name="articulo">string</param>
        /// <param name="uen">int</param>
        /// <param name="opc">int</param>
        /// Developer: Erika Perez
        /// Date: 20/01/18
        public DataTable PreciosCondicion(string articulo, int uen, int opc)
        {
            DataTable dataSet = new DataTable();
            string query;
            if (opc == 1)
                query = "  SELECT precio,Condicion FROM PropreListaDFinal with (nolock) where  ARTICULO='" + articulo +
                        "' and uen ='" + uen + "' and sucursal ='" + ClaseEstatica.Usuario.sucursal +
                        "' ORDER BY precio ASC ";
            else
                query = "  SELECT precio,Condicion FROM PropreListaDFinal with (nolock) where  ARTICULO='" + articulo +
                        "' and uen ='" + uen + "' ORDER BY precio ASC ";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("PreciosCondicion", "DM0312_C_PuntoVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Saber la forma de pago del movimento
        /// </summary>
        /// <param name="mov">string</param>
        /// <param name="movid">string</param>
        /// Developer: Erika Perez
        /// Date: 05/11/17
        public string OrigenDev(string mov, string movid)
        {
            string formaPago = "";
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MaviDM0312DevolucionOrigen", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Mov  ", SqlDbType.VarChar).Value = mov;
                cmd.Parameters.Add("@MovID  ", SqlDbType.VarChar).Value = movid;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        formaPago = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("OrigenDev", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return formaPago;
        }

        /// <summary>
        ///     Metodo para validar si la nomina del empleado se encuentra guardada y es correcta para poder consultarla
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="var">int</param>
        /// Developer: Erika Perez
        /// Date: 05/11/17
        public string ValidarMostrarNomina(string cliente, int var)
        {
            string nominaR = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            if (var == 1)
                query = "select empleado from TcA_RelacionCteFinalEmpleado WITH (NOLOCK) where cliente='" + cliente +
                        "'";
            else
                query = "select top 1 nomina from CteEnviarA WITH (NOLOCK) where id=34 and cliente='" + cliente + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        nominaR = dr[0].ToString();
                else
                    nominaR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarMostrarNomina", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return nominaR;
        }

        /// <summary>
        ///     Optiene el almacen de la sucursal del movimiento
        /// </summary>
        /// <param name="suc">int</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public string AlmacenDeSucursal(int suc)
        {
            string almacen = "";
            SqlDataReader dr = null;
            int suc2 = 0;
            suc2 = ClaseEstatica.Usuario.sucursal;
            string query = "SELECT AlmacenPrincipal FROM Sucursal WITH (NOLOCK) WHERE Sucursal='" + suc + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        almacen = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AlmacenDeSucursal", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return almacen;
        }

        /// <summary>
        ///     inserta o edita el campo de nomina cuando esta ya fue validada
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="nomina">string</param>
        /// <param name="opc">int</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public void InsertNomina(string cliente, string nomina, int opc)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            if (opc == 1)
                query = string.Format("INSERT INTO TcA_RelacionCteFinalEmpleado (cliente,final,Empleado) VALUES ('" +
                                      cliente + "',null,'" + nomina + "')");
            if (opc == 2)
                query = string.Format("	UPDATE TcA_RelacionCteFinalEmpleado WITH (ROWLOCK) SET Empleado='" + nomina +
                                      "'  WHERE Cliente = '" + cliente + "'");
            if (opc == 3)
                query = string.Format("	UPDATE cteenviara WITH (ROWLOCK) SET NOMINA='" + nomina +
                                      "'  WHERE Cliente = '" + cliente + "' AND ID=34");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertNomina", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /// <summary>
        ///     edita la nomina en la tabla: CteEnviarA cuando sea una venta de instituciones
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="nomina">string</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public void InsertNominaCTE(string cliente, string nomina)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            ;

            query = string.Format("	UPDATE CteEnviarA WITH (ROWLOCK) SET Nomina='" + nomina +
                                  "'  WHERE id=34 and Cliente = '" + cliente + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertNominaCTE", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }
        }

        public string LlenaTelefono(string Cliente)
        {
            SqlDataReader dr = null;
            string Codigo = "";
            try
            {
                string query = string.Empty;
                query = string.Format(
                    "SELECT Cliente, Telefono From CteTel WITH(NOLOCK) WHERE Tipo = 'Particular' AND Cliente = '{0}'AND " +
                    " Fecha = (SELECT Max(Fecha) FROM CteTel WITH(NOLOCK) WHERE Tipo = 'Particular' AND Cliente = '{0}')",
                    Cliente);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MVentanaEntrada model = new DM0312_MVentanaEntrada();
                        model.Codigo = dr[0].ToString();
                        Codigo = model.Codigo;
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaTelefono", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Codigo;
        }

        /// <summary>
        ///     manda llamar el telefono movil mas actual del cliente
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public string LlenaCelular(string Cliente)
        {
            SqlDataReader dr = null;
            string Codigo = "";
            try
            {
                string query = string.Empty;
                query = string.Format(
                    "SELECT Cliente, Telefono From CteTel WITH(NOLOCK) WHERE Tipo = 'Movil' AND Cliente = '{0}'AND " +
                    " Fecha = (SELECT Max(Fecha) FROM CteTel WITH(NOLOCK) WHERE Tipo = 'Movil' AND Cliente = '{0}')",
                    Cliente);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MVentanaEntrada model = new DM0312_MVentanaEntrada();
                        model.Codigo = dr[0].ToString();
                        Codigo = model.Codigo;
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaCelular", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Codigo;
        }


        /// <summary>
        ///     optiene el almacen de la sucursal de la venta
        /// </summary>
        /// <param name="Sucursal">int</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public string LlenaAlmacen(int Sucursal)
        {
            SqlDataReader dr = null;
            string Suc = "";
            try
            {
                string query = string.Empty;
                query = string.Format("SELECT Almacen FROM Alm WITH (NOLOCK) WHERE Sucursal = {0} ", Sucursal);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        Suc = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Suc;
        }

        /// <summary>
        ///     optiene los cliente dados de alta en la tabla cte
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 10/11/17
        public List<DM0312_MPuntoDeVentaCliente> TodosClientes()
        {
            List<DM0312_MPuntoDeVentaCliente> Lista = new List<DM0312_MPuntoDeVentaCliente>();
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;
                query =
                    " SELECT DISTINCT Cte.Cliente, Nombre,eMail1 FROM cte WITH(NOLOCK) WHERE Cte.Estatus = 'Alta' ORDER BY Cte.Cliente,Nombre ";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                DM0312_MPuntoDeVentaCliente EmptyModel = new DM0312_MPuntoDeVentaCliente();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MPuntoDeVentaCliente model_ = new DM0312_MPuntoDeVentaCliente();
                        model_.Codigo = dr["Cliente"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.eMail = dr["eMail1"].ToString();
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TodosClientes", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        public void updateDieVenta(int iIdVenta, bool bEstatus)
        {
            try
            {
                string sQuery = "SET NOCOUNT ON; UPDATE Venta WITH(ROWLOCK) SET pagodie = @Valor WHERE Id = @Id";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Valor", bEstatus)
                    {
                        SqlDbType = SqlDbType.Bit
                    },
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Obtener el valor del tipo DIMA
        /// </summary>
        /// <returns></returns>
        public string ValorTipoDIMA(string cliente)
        {
            string val = "";
            SqlDataReader dr = null;
            string query;
            query = "SELECT top 1 TipoDIMA FROM cte WITH(NOLOCK) WHERE cliente ='" + cliente + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = dr[0].ToString();
                else
                    val = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValorTipoDIMA", "CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }


        public string ValidarDie()
        {
            string clienteR = "";
            SqlDataReader dr = null;
            string query = "select NOMBRE from tablastd  WITH (NOLOCK) WHERE tablast='ACCESO DIE' and nombre = '" +
                           ClaseEstatica.Usuario.sucursal + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        clienteR = dr[0].ToString();
                else
                    clienteR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return clienteR;
        }

        /// <summary>
        ///     optiene los agentes dependiendo de la sucursal del usuario
        /// </summary>
        /// <param name="suc">int</param>
        /// Developer: Erika Perez
        /// Date: 10/11/17
        public List<DM0312_MPuntoDeVentaAgente> TodosAgentes(int suc)
        {
            List<DM0312_MPuntoDeVentaAgente> Lista = new List<DM0312_MPuntoDeVentaAgente>();
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;

            try
            {
                string query = string.Empty;
                if (ClaseEstatica.Usuario.Uen == 1)
                {
                    if (ClaseEstatica.Usuario.sucursal == 30)
                        query =
                            "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                            sucursal +
                            "'  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' AND TIPO<>'AUDITOR'  ORDER BY Categoria desc,Agente,Nombre";
                    else
                        query =
                            "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                            sucursal +
                            "'  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' AND TIPO<>'AUDITOR'   union all select venta.AGENTE2,CASE WHEN venta.TIPO='EQUIPO' THEN p.ApellidoPaterno+' '+ApellidoMaterno+' '+p.Nombre ELSE venta.Nombre END ,venta.Tipo,venta.Categoria,venta.SucursalEmpresa from(select AGENTE2=CASE WHEN TIPO='EQUIPO' THEN  REPORTAA ELSE Agente END,Nombre, Tipo,Categoria,SucursalEmpresa from agente a   with(nolock) where  categoria ='ventas dima' and estatus ='alta')venta inner join Personal P ON p.Personal=venta.AGENTE2 where venta.AGENTE2<>'' AND  venta.Tipo='SUBGERENTE'   ORDER BY Categoria desc,Agente,Nombre";
                }
                else
                {
                    if (ClaseEstatica.Usuario.Uen == 3)
                        query =
                            "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                            sucursal +
                            "' and estatus ='alta' AND TIPO<>'AUDITOR'   ORDER BY Categoria desc,Agente,Nombre";
                    else
                        query =
                            "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                            sucursal +
                            "'  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' AND TIPO<>'AUDITOR'  ORDER BY Categoria desc,Agente,Nombre";
                }

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();

                DM0312_MPuntoDeVentaAgente EmptyModel = new DM0312_MPuntoDeVentaAgente();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MPuntoDeVentaAgente model_ = new DM0312_MPuntoDeVentaAgente();
                        model_.Agente = dr["Agente"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Tipo = dr["Tipo"].ToString();
                        model_.Categoria = dr["Categoria"].ToString();
                        model_.Sucursal = dr["SucursalEmpresa"].ToString();
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TodosAgentes", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     optiene los canales en los cuales el cliente ah echo ventas
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 11/11/17
        public List<DM0312_MPuntoDeVentaCanales> LlenaCanalesCliente(string Cliente)
        {
            List<DM0312_MPuntoDeVentaCanales> Lista = new List<DM0312_MPuntoDeVentaCanales>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = string.Format(
                    "SELECT a.id as Canal,a.Clave,a.Nombre,a.Direccion FROM CteEnviarA A WITH(NOLOCK) inner join  VentasCanalMAVI v WITH (NOLOCK) on a.id=v.id WHERE V.UEN=" +
                    ClaseEstatica.Usuario.Uen + " AND A.Cliente = '{0}' ORDER BY A.Id,A.Clave", Cliente);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_MPuntoDeVentaCanales EmptyModel = new DM0312_MPuntoDeVentaCanales();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MPuntoDeVentaCanales model_ = new DM0312_MPuntoDeVentaCanales();
                        model_.Canal = int.Parse(dr["Canal"].ToString());
                        model_.Clave = dr["Clave"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Direccion = dr["Direccion"].ToString();
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaCanalesCliente", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     valida si el cliente en el canal seleccionado es nuevo o casa
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 11/11/17
        public string validaCasa(string Cliente, int Canal)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT dbo.fnClientesNuevosCasaMAVICanal ('{0}',{1})", Cliente, Canal);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaCasa", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        /// <summary>
        ///     optiene las condiciones de venta que podra elegir el usuario dependiendo del canal seleccionado
        /// </summary>
        /// <param name="Usuario">string</param>
        /// <param name="Canal">int</param>
        /// <param name="var">int</param>
        /// Developer: Erika Perez
        /// Date: 14/11/17
        public List<string> LlenaCondicion(string Usuario, int Canal, int var)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            try
            {
                if (var == 1)
                {
                    SqlCommand cmd = new SqlCommand("spCondicionNivelAccesoFiltrado", ClaseEstatica.ConexionEstatica);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                    cmd.Parameters.Add("@CANALVENTA  ", SqlDbType.Int).Value = Canal;
                    dr = cmd.ExecuteReader();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("spCondicionNivelAccesoFiltradoCanalVenta",
                        ClaseEstatica.ConexionEstatica);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                    cmd.Parameters.Add("@CANALVENTA  ", SqlDbType.Int).Value = Canal;
                    dr = cmd.ExecuteReader();
                }

                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
                else
                    Lista = new List<string>();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaCondicion", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     optiene los almacenes en los que se pueden realizar ventas
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 14/11/17
        public List<DM0312_MPuntoDeVentaAlmacen> LlenaAlmacen()
        {
            List<DM0312_MPuntoDeVentaAlmacen> Lista = new List<DM0312_MPuntoDeVentaAlmacen>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query =
                    "SELECT Almacen,Nombre,Grupo,Sucursal FROM Alm WITH(NOLOCK) WHERE Estatus = 'Alta'  AND Alm.Almacen NOT LIKE 'I%'AND Alm.Almacen NOT LIKE '(T%'AND (Alm.Almacen NOT LIKE 'A%') union all SELECT Almacen,Nombre,Grupo,Sucursal FROM Alm WITH(NOLOCK) where Alm.Almacen = 'A00500'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MPuntoDeVentaAlmacen EmptyModel = new DM0312_MPuntoDeVentaAlmacen();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MPuntoDeVentaAlmacen model_ = new DM0312_MPuntoDeVentaAlmacen();
                        model_.Almacen = dr["Almacen"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Grupo = dr["Grupo"].ToString();
                        model_.Sucursal = int.Parse(dr["Sucursal"].ToString());
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     optiene los conceptos dependiendo el tipo de movimiento
        /// </summary>
        /// <param name="TipoCanal">string</param>
        /// Developer: Erika Perez
        /// Date: 16/11/17
        public List<string> LlenaConcepto(string TipoCanal)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = string.Format(
                    " SELECT Concepto FROM EmpresaConceptoValidar WITH(NOLOCK) WHERE Modulo = 'VTAS' AND Mov = '{0}' ORDER BY Concepto",
                    TipoCanal);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_MComentariosVenta EmptyModel = new DM0312_MComentariosVenta();
                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaConcepto", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     optiene las posibles formas de envio para ventas de mayoreo
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 16/11/17
        public List<string> LlenaFormaDeEnvio()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                query = "SELECT FormaEnvio FROM FormaEnvio WITH(NOLOCK) ORDER BY FormaEnvio";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
                else
                    Lista.Clear();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaFormaDeEnvio", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        /// <summary>
        ///     optiene las posibles formas de cobro para ventas en linea
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 17/02/18
        public List<string> LlenaFormaDeCobro(string formaActual)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                query = "SELECT formapago FROM FormaPago WITH(NOLOCK) WHERE VentaLinea='SI' and formapago<>'" +
                        formaActual + "' ORDER BY FormaPago ";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    if (formaActual != "") Lista.Add(formaActual);
                    while (dr.Read()) Lista.Add(dr[0].ToString());
                }
                else
                {
                    Lista.Clear();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaFormaDeCobro", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        /// <summary>
        ///     optiene todos los canales dependiendo en la Uen donde se encuentren
        /// </summary>
        /// <param name="Uen">int</param>
        /// Developer: Erika Perez
        /// Date: 17/12/17
        public DataTable LlenaTodosLosCanales(int Uen)
        {
            DataTable dataSet = new DataTable();
            SqlCommand sqlCommand = null;
            string query = string.Empty;

            query = string.Format("SELECT Id,Cadena FROM VentasCanalMAVI WITH(NOLOCK) WHERE Uen = {0} ORDER BY Id",
                Uen);
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaTodosLosCanales", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     metodo para agregar un nuevo canal al cliente a vender
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 17/12/17
        public bool AgregaNuevoCanal(string Cliente, int Canal)
        {
            bool Agrega = new bool();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("spAltaCanalCteExiste ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente  ", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Canal  ", SqlDbType.Int).Value = Canal;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Agrega = true;
                else
                    Agrega = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AgregaNuevoCanal", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Agrega;
        }


        public bool ArticulosValr(string Cliente)
        {
            bool Agrega = new bool();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query =
                    "SELECT top 1 MOV,ESTATUS,SITUACION,ARTICULO,cliente,venta.ID FROM VENTA with (nolock) INNER JOIN VENTAD ON VENTA.ID=VENTAD.ID WHERE MOV='ANALISIS CREDITO' AND ESTATUS='PENDIENTE' AND SITUACION='CONDICIONADO' and articulo like '%valr%' and venta.cliente ='" +
                    Cliente + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Agrega = true;
                else
                    Agrega = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AgregaNuevoCanal", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Agrega;
        }

        /// <summary>
        ///     metodo para saber si se tiene que pedir telefonos o no
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Usuario">int</param>
        /// Developer: Erika Perez
        /// Date: 19/12/17
        public int validaTelefono(string Cliente, string Usuario)
        {
            SqlDataReader dr = null;
            int var = 0;
            try
            {
                string query;
                query = string.Format(" SELECT dbo.FnCXCValidaTelCte ('{0}','{1}')", Cliente, Usuario);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        var = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaTelefono", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return var;
        }

        /// <summary>
        ///     metodo para validar si el almacen es de tipo activo fijo
        /// </summary>
        /// <param name="almacen">string</param>
        /// Developer: Erika Perez
        /// Date: 19/12/17
        public string AlmacenActivoFijo(string almacen)
        {
            SqlDataReader dr = null;
            string tipo = "";
            try
            {
                string query = string.Empty;
                query = "SELECT Tipo FROM ALM WHERE ALMACEN ='" + almacen + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        tipo = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AlmacenActivoFijo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return tipo;
        }

        /// <summary>
        ///     metodo para validar si el cliente su tipo sea cliente
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 20/12/17
        public bool ClienteConCuenta(string cliente)
        {
            SqlDataReader dr = null;
            bool cuenta = false;
            try
            {
                string query = string.Empty;
                query = "select tipo from cte where tipo='Cliente' and cliente='" + cliente + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        cuenta = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteConCuenta", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return cuenta;
        }


        public bool ClienteConP(string cliente)
        {
            SqlDataReader dr = null;
            bool cuenta = false;
            try
            {
                string query = string.Empty;
                query = "select tipo from cte where tipo='Prospecto' and cliente='" + cliente + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        cuenta = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteConP", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return cuenta;
        }

        //Catalogo Articulos

        /// <summary>
        ///     Optiene el listado de lineas que existen
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 20/12/17
        public DataTable LlenaLinea()
        {
            DataTable dataSet = new DataTable();
            SqlCommand sqlCommand = null;
            string query = string.Empty;

            query =
                "SELECT DISTINCT Linea FROM Art WITH (NOLOCK) WHERE Grupo IN ('MERCANCIA DE LINEA','INVENTARIOS') AND Categoria IN('ACTIVOS FIJOS','VENTA') AND Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' ORDER BY LINEA";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaLinea", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }


        /// <summary>
        ///     Optiene los articulos dependiendo de los filtros del usuario y que estos esten dados de alta
        /// </summary>
        /// <param name="Articulo">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Condicion">string</param>
        /// <param name="OPC">int</param>
        /// Developer: Erika Perez
        /// Date: 20/12/17
        public List<DM0312_MPuntoDeVentaArt> BuscaArticulos(string Articulo, string Almacen, string Condicion, int OPC,
            string sTipoDima = "")
        {
            List<DM0312_MPuntoDeVentaArt> Lista = new List<DM0312_MPuntoDeVentaArt>();
            SqlDataReader dr = null;
            string sQuery = string.Empty;

            //-ReservaOnline

            switch (OPC)
            {
                case 1:

                    //-ReservaOnline
                    sQuery = string.Format(
                        "SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Estatus, CASE WHEN CATEGORIA='ACTIVOS FIJOS' THEN ISNULL(ActivoFDisponible.Disponible,0) ELSE ISNULL(ArtDisponible.Disponible,0) END Disponible,Impuesto1 as Impuesto,tipo as Tipo,unidad,grupo,ISNULL((SELECT SUM(ReservaOnline) FROM VTASHReservaOnline WHERE articulo = art.Articulo AND almacen = '{1}' AND EstatusReservacion = 'Reservado'  AND FechaReservacion <= GETDATE() + (SELECT CONVERT(INT,VALOR) FROM tablastd WHERE tablast = 'NumeroDiasReservaOnline')), 0) AS 'Reserva-Online' FROM Art WITH(NOLOCK) LEFT JOIN ArtDisponible WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo AND (ArtDisponible.Almacen ='{1}' or ArtDisponible.almacen is null) LEFT JOIN ActivoFDisponible WITH(NOLOCK) ON Art.Articulo = ActivoFDisponible.Articulo AND (ActivoFDisponible.Almacen ='{1}' or ActivoFDisponible.almacen is null)   " +
                        " WHERE Grupo IN ('MERCANCIA DE LINEA','INVENTARIOS','SERVICIOS A CLIENTES','MERCANCIA ESPECIAL','PRODUCTOS DIVERSOS') AND Categoria IN('ACTIVOS FIJOS','VENTA') AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' AND FAMILIA <>'VALERAS'  " +
                        " {0} {2} " +
                        " ORDER BY grupo,Art.Articulo", Articulo, Almacen, Condicion);
                    break;

                case 2:
                    sQuery = string.Format(
                        "SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Estatus, CASE WHEN CATEGORIA='ACTIVOS FIJOS' THEN ISNULL(ActivoFDisponible.Disponible,0) ELSE ISNULL(ArtDisponible.Disponible,0) END Disponible,Impuesto1 as Impuesto,tipo as Tipo,unidad,grupo,CASE WHEN reserva.EstatusReservacion = 'Reservado' THEN isnull(reserva.reservaonline,0) ELSE 0 END as 'Reserva-Online' FROM Art WITH(NOLOCK) LEFT JOIN ArtDisponible WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo AND (ArtDisponible.Almacen ='{1}' or ArtDisponible.almacen is null) LEFT JOIN ActivoFDisponible WITH(NOLOCK) ON Art.Articulo = ActivoFDisponible.Articulo AND (ActivoFDisponible.Almacen ='{1}' or ActivoFDisponible.almacen is null)   " +
                        " LEFT JOIN VTASHReservaOnline reserva ON(reserva.articulo = art.Articulo) WHERE Grupo IN ('MERCANCIA DE LINEA','INVENTARIOS','SERVICIOS A CLIENTES','MERCANCIA ESPECIAL','PRODUCTOS DIVERSOS') AND Categoria IN('ACTIVOS FIJOS','VENTA') AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' AND FAMILIA <>'VALERAS' " +
                        " {0} {2} " +
                        " ORDER BY grupo,Art.Articulo", Articulo, Almacen, Condicion);
                    break;

                case 3:
                    sQuery = string.Format(@"SELECT
                                              a.Articulo AS Codigo,
                                              a.descripcion1 AS Nombre,
                                              a.linea,
                                              a.estatus,
                                              ISNULL(ArtDisponible.Disponible,0) AS Disponible,
                                              A.Impuesto1 AS Impuesto,
                                              A.Tipo AS Tipo,
                                              A.Unidad,
                                              A.Grupo,
                                              ISNULL((SELECT
                                                SUM(ReservaOnline)
                                              FROM VTASHReservaOnline
                                              WHERE articulo = a.Articulo
                                              AND almacen = '{1}'
                                              AND EstatusReservacion = 'Reservado'
                                              AND FechaReservacion <= GETDATE() + (SELECT
                                                CONVERT(int, VALOR)
                                              FROM tablastd
                                              WHERE tablast = 'NumeroDiasReservaOnline')), 0) AS 'Reserva-Online'
                                            FROM COMSCConfiguracionArtDIMA cd WITH(NOLOCK)
                                            LEFT JOIN ArtFam f WITH(NOLOCK)
                                              ON cd.Familia = f.ClaveMES
                                            LEFT JOIN ArtLinea l WITH(NOLOCK)
                                              ON cd.Linea = l.ID
                                            INNER JOIN Art A WITH(NOLOCK)
                                              ON a.Familia = f.Familia
                                              AND ISNULL(a.Linea, '') = IIF(ISNULL(l.Linea, '') = '', ISNULL(a.Linea, ''), l.Linea)
										      AND ISNULL(a.MarcaE, '') = IIF(ISNULL(cd.Marca, '') = '', ISNULL(a.MarcaE, ''), cd.Marca)
                                              AND a.Articulo = IIF(ISNULL(cd.Codigo, '') = '', a.Articulo, cd.Codigo)
                                            LEFT JOIN ArtDisponible WITH(NOLOCK)
                                              ON A.Articulo = ArtDisponible.Articulo
	                                          AND (ArtDisponible.Almacen = '{1}'
	                                          OR ArtDisponible.almacen IS NULL)
                                            WHERE cd.TipoDima = '{0}'
											AND a.Estatus <> 'BAJA'
                                            {2}
                                            ORDER BY a.Familia, a.Linea, a.MarcaE, a.Articulo", sTipoDima, Almacen,
                        Condicion.Replace("Linea", "a.Linea"));
                    break;
            }


            try
            {
                SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_MPuntoDeVentaArt EmptyModel = new DM0312_MPuntoDeVentaArt();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MPuntoDeVentaArt model_ = new DM0312_MPuntoDeVentaArt();
                        model_.Codigo = dr["Codigo"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Linea = dr["Linea"].ToString();
                        model_.Estatus = dr["Estatus"].ToString();
                        model_.Disponible = dr["Disponible"].ToString();
                        model_.Impuesto = dr["Impuesto"].ToString();
                        model_.Tipo = dr["Tipo"].ToString();
                        model_.unidad = dr["unidad"].ToString();
                        model_.unidad = dr["Grupo"].ToString();
                        //-ReservaOnline
                        model_.ReservaOnline = int.Parse(dr["Reserva-Online"].ToString());
                        Lista.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Optiene los articulos adjudicados dependiendo de los filtros del usuario y que estos esten dados de alta
        /// </summary>
        /// <param name="almI">string</param>
        /// Developer: Erika Perez
        /// Date: 20/12/17
        public List<DM0312_M_ArticulosAdjudicados> BuscaArticulosADJ(string almI)
        {
            List<DM0312_M_ArticulosAdjudicados> Lista = new List<DM0312_M_ArticulosAdjudicados>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SpEDM0312_ArticulosADJ ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Almacen  ", SqlDbType.VarChar).Value = almI;
                dr = cmd.ExecuteReader();
                DM0312_M_ArticulosAdjudicados EmptyModel = new DM0312_M_ArticulosAdjudicados();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_M_ArticulosAdjudicados model_ = new DM0312_M_ArticulosAdjudicados();
                        model_.Codigo = dr["Codigo"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Linea = dr["Linea"].ToString();
                        model_.Estatus = dr["Estatus"].ToString();
                        model_.Disponible = dr["Disponible"].ToString();
                        model_.Impuesto = dr["Impuesto"].ToString();
                        model_.Tipo = dr["Tipo"].ToString();
                        model_.unidad = dr["unidad"].ToString();
                        Lista.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscaArticulosADJ", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Optiene el almacen I del almacen V
        /// </summary>
        /// <param name="almacen">string</param>
        /// Developer: Erika Perez
        /// Date: 03/01/18
        public string AlmacenI(string almacen)
        {
            string totalVenta = "";
            SqlDataReader dr = null;
            string query =
                "SELECT nombre FROM TablaStD with (nolock) WHERE TablaSt='AlmacenesAdjudicados' and valor='" + almacen +
                "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) totalVenta = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AlmacenI", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return totalVenta;
        }

        public DataTable BuscaArticulos_VentaDetalle(string Articulo, string Almacen, int iOpcion,
            string sTipoDima = "")
        {
            DataTable dataSet = new DataTable();
            SqlCommand sqlCommand = null;
            string sQuery = string.Empty;

            switch (iOpcion)
            {
                case 1:
                    //Query original
                    sQuery = string.Format(
                        "SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Estatus, CASE WHEN CATEGORIA='ACTIVOS FIJOS' THEN ISNULL(ActivoFDisponible.Disponible,0) ELSE ISNULL(ArtDisponible.Disponible,0) END Disponible,Impuesto1 as Impuesto,tipo as Tipo,unidad FROM Art WITH(NOLOCK) LEFT JOIN ArtDisponible WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo AND (ArtDisponible.Almacen ='{1}' or ArtDisponible.almacen is null) LEFT JOIN ActivoFDisponible WITH(NOLOCK) ON Art.Articulo = ActivoFDisponible.Articulo AND (ActivoFDisponible.Almacen ='{1}' or ActivoFDisponible.almacen is null) " +
                        " WHERE Grupo IN ('MERCANCIA DE LINEA','INVENTARIOS','SERVICIOS A CLIENTES','MERCANCIA ESPECIAL','PRODUCTOS DIVERSOS') AND Categoria IN('ACTIVOS FIJOS','VENTA') AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' AND FAMILIA <>'VALERAS' " +
                        " AND Art.Articulo='{0}' " +
                        " ORDER BY Art.Articulo", Articulo, Almacen);

                    break;

                case 2:

                    sQuery = string.Format(
                        "SELECT DISTINCT Art.Articulo as Codigo, Descripcion1 as Nombre, Linea, Estatus, CASE WHEN CATEGORIA='ACTIVOS FIJOS' THEN ISNULL(ActivoFDisponible.Disponible,0) ELSE ISNULL(ArtDisponible.Disponible,0) END Disponible,Impuesto1 as Impuesto,tipo as Tipo,unidad FROM Art WITH(NOLOCK) LEFT JOIN ArtDisponible WITH(NOLOCK) ON Art.Articulo = ArtDisponible.Articulo AND (ArtDisponible.Almacen ='{1}' or ArtDisponible.almacen is null) LEFT JOIN ActivoFDisponible WITH(NOLOCK) ON Art.Articulo = ActivoFDisponible.Articulo AND (ActivoFDisponible.Almacen ='{1}' or ActivoFDisponible.almacen is null) " +
                        " WHERE Grupo IN ('MERCANCIA DE LINEA','INVENTARIOS','SERVICIOS A CLIENTES','MERCANCIA ESPECIAL','PRODUCTOS DIVERSOS') AND Categoria IN('ACTIVOS FIJOS','VENTA') AND art.tipo IN('Juego','Servicio','Normal','Serie','Lote') AND Estatus IN ('ALTA','BLOQUEADO') AND Linea <>'' AND FAMILIA <>'VALERAS' " +
                        " AND Art.Articulo='{0}' " +
                        " ORDER BY Art.Articulo", Articulo, Almacen);
                    break;

                case 3:

                    //-DataLogic
                    sQuery = string.Format("SELECT" +
                                           "  inte.Codigo," +
                                           "  ISNULL(CodigoIntelisis, '') AS CodigoIntelisis," +
                                           "  Nombre," +
                                           "  inte.Tipo," +
                                           "  Prov," +
                                           "  Monto," +
                                           "  ISNULL(Acreedor, '') AS Acreedor," +
                                           "  ar.impuesto1 " +
                                           "FROM dm0216pagoexternoart inte WITH(NOLOCK)" +
                                           "INNER JOIN art ar WITH(NOLOCK)" +
                                           "  ON(inte.codigointelisis = ar.Articulo)" +
                                           "WHERE inte.tipo = 'TAE'" +
                                           "AND ar.Articulo = '{0}' " +
                                           "AND ar.Estatus <> 'BAJA' " +
                                           "AND inte.Estatus <> 'BAJA'", Articulo);
                    break;
                case 4:
                    sQuery = string.Format(@"SELECT
                                              a.Articulo AS Codigo,
                                              a.descripcion1 AS Nombre,
                                              a.linea,
                                              a.estatus,
                                              ISNULL(ArtDisponible.Disponible,0) AS Disponible,
                                              A.Impuesto1 AS Impuesto,
                                              A.Tipo AS Tipo,
                                              A.Unidad,
                                              A.Grupo
                                            FROM COMSCConfiguracionArtDIMA cd WITH(NOLOCK)
                                            LEFT JOIN ArtFam f WITH(NOLOCK)
                                              ON cd.Familia = f.ClaveMES
                                            LEFT JOIN ArtLinea l WITH(NOLOCK)
                                              ON cd.Linea = l.ID
                                            INNER JOIN Art A WITH(NOLOCK)
                                              ON a.Familia = f.Familia
                                              AND ISNULL(a.Linea, '') = IIF(ISNULL(l.Linea, '') = '', ISNULL(a.Linea, ''), l.Linea)
										      AND ISNULL(a.MarcaE, '') = IIF(ISNULL(cd.Marca, '') = '', ISNULL(a.MarcaE, ''), cd.Marca)
                                              AND a.Articulo = IIF(ISNULL(cd.Codigo, '') = '', a.Articulo, cd.Codigo)
                                            LEFT JOIN ArtDisponible WITH(NOLOCK)
                                              ON A.Articulo = ArtDisponible.Articulo
	                                          AND (ArtDisponible.Almacen = '{1}'
	                                          OR ArtDisponible.almacen IS NULL)
                                            WHERE cd.TipoDima = '{0}'
											AND a.Estatus <> 'BAJA'
                                            AND a.Articulo = '{2}'
                                            ORDER BY a.Familia, a.Linea, a.MarcaE, a.Articulo", sTipoDima, Almacen,
                        Articulo);
                    break;
            }

            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataSet;
        }

        /// <summary>
        ///     ya validados los telefonos del cliente los inserta
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Usuario">string</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Telefono">string</param>
        /// <param name="TipoTel">string</param>
        /// Developer: Erika Perez
        /// Date: 28/09/17
        public bool InsertaTelefonos(string Cliente, string Usuario, int Sucursal, string Telefono, string TipoTel)
        {
            bool Agrega = new bool();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("spMAVIDM0305GuardaValidacionTel ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = Telefono;
                cmd.Parameters.Add("@TipoTel", SqlDbType.VarChar).Value = TipoTel;
                cmd.Parameters.Add("@Origen", SqlDbType.Bit).Value = 1;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Agrega = true;
                else
                    Agrega = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertaTelefonos", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Agrega;
        }

        /// <summary>
        ///     crea el id de la venta con la informacion llenada por el usuario
        /// </summary>
        /// <param name="Empresa">string</param>
        /// <param name="Movimiento">string</param>
        /// <param name="Usuario">int</param>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Agente">string</param>
        /// <param name="Condicion">int</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Uen">int</param>
        /// <param name="NoCtaPago">string</param>
        /// <param name="Observaciones">string</param>
        /// <param name="Comentario">int</param>
        /// <param name="Concepto">string</param>
        /// <param name="FormaPago">string</param>
        /// <param name="Referencia">string</param>
        /// <param name="FormaEnvio">int</param>
        /// <param name="Opcion">int</param>
        /// <param name="AgenteTelefonico">string</param>
        /// <param name="pedComer">string</param>
        /// <param name="monederoRedimir">bool</param>
        /// <param name="comMayoreo">bool</param>
        /// <param name="custodia">int</param>
        /// <param name="iva">bool</param>
        /// <param name="imprimirComentario">string</param>
        /// <param name="nomina">string</param>
        /// <param name="formaCo">string</param>
        /// Developer: Erika Perez
        /// Date: 08/09/17
        public int IdVenta(string Empresa, string Movimiento, string Usuario, string Cliente, int Canal, string Almacen,
            string Agente, string Condicion, int Sucursal,
            int Uen, string NoCtaPago, string Observaciones, string Comentario, string Concepto, string FormaPago,
            string Referencia, string FormaEnvio, int Opcion,
            string AgenteTelefonico, string pedComer, bool monederoRedimir, bool comMayoreo, string custodia, bool iva,
            string imprimirComentario, string nomina, string formaCo)
        {
            int? entero = null;
            DateTime? fecha = null;
            decimal? doble = null;
            bool? bol = null;

            SqlDataReader dr = null;
            int var = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312PuntoDeVentaIdVenta", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = Empresa;
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = Movimiento;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Canal", SqlDbType.Int).Value = Canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = Almacen;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = Agente;
                cmd.Parameters.Add("@Condicion", SqlDbType.VarChar).Value = Condicion;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@Uen", SqlDbType.Int).Value = ClaseEstatica.Usuario.Uen;
                cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = "No Identificado";

                if (Observaciones == "")
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = Observaciones;


                cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = Comentario;
                if (Concepto == "")
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = Concepto;

                cmd.Parameters.Add("@FormaPago", SqlDbType.VarChar).Value = FormaPago;

                if (Referencia == "")
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = Referencia;

                if (FormaEnvio == "")
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = FormaEnvio;
                cmd.Parameters.Add("@idVenta", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Opc", SqlDbType.Int).Value = Opcion;
                cmd.Parameters.Add("@MovId", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Proyecto", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Moneda", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@TipoCambio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@Autorizacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@DocFuente", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@SituacionFecha", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@SituacionUsuario", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionNota", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Directo", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Prioridad", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@RenglonID", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@FechaOriginal", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@AlmacenDestino", SqlDbType.VarChar).Value = DBNull.Value;
                if (AgenteTelefonico == "")
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = AgenteTelefonico;
                cmd.Parameters.Add("@AgenteComision", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@HoraRequerida", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@FechaProgramadaEnvio", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@FechaOrdenCompra", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@ReferenciaOrdenCompra", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@OrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Vencimiento", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@CtaDinero", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Importe", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Impuestos", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Saldo", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposFacturados", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposImpuestos", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@DescuentoLineal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@CostoTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@PrecioTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ZonaImpuestos", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@CancelacionID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@GenerarOP", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@DesglosarImpuestos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuesto2", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Enganche", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@Bonificacion", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IVAFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IEPSFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@EstaImpreso", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@Periodicidad", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SubModulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Pagado", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@AF", SqlDbType.Bit).Value = 0;
                if (formaCo == "")
                    cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = formaCo;
                cmd.Parameters.Add("@Comisiones", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionesIVA", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@TieneTasaEsp", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@TasaEsp", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SobrePrecio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SincroC", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@SucursalDestino", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@MaviTipoVenta", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@EsCredilana", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@SucJuego", SqlDbType.Char).Value = DBNull.Value;
                cmd.Parameters.Add("@OrigenSucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FacDesgloseIva", SqlDbType.Bit).Value = iva;
                cmd.Parameters.Add("@RedimePtos", SqlDbType.Bit).Value = monederoRedimir;
                cmd.Parameters.Add("@ArtQ", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;

                if (pedComer == "")
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = pedComer;

                cmd.Parameters.Add("@comMayoreo", SqlDbType.Bit).Value = comMayoreo;
                if (custodia == "")
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = custodia;
                if (imprimirComentario == "")
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = imprimirComentario;
                cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = nomina;
                //cmd.CommandTimeout = 9999999;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        var = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("IdVenta", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return var;
        }

        /// <summary>
        ///     crea el id de la devolucion con la informacion llenada por el usuario
        /// </summary>
        /// <param name="Empresa">string</param>
        /// <param name="Movimiento">string</param>
        /// <param name="Usuario">int</param>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Agente">string</param>
        /// <param name="Condicion">int</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Uen">int</param>
        /// <param name="NoCtaPago">string</param>
        /// <param name="Observaciones">string</param>
        /// <param name="Comentario">int</param>
        /// <param name="Concepto">string</param>
        /// <param name="FormaPago">string</param>
        /// <param name="Referencia">string</param>
        /// <param name="FormaEnvio">int</param>
        /// <param name="Opcion">int</param>
        /// <param name="AgenteTelefonico">string</param>
        /// <param name="pedComer">string</param>
        /// <param name="monederoRedimir">bool</param>
        /// <param name="comMayoreo">bool</param>
        /// <param name="custodia">int</param>
        /// <param name="iva">bool</param>
        /// <param name="imprimirComentario">string</param>
        /// <param name="nomina">string</param>
        /// <param name="tipoVenta">string</param>
        /// Developer: Erika Perez
        /// Date: 08/09/17
        public int IdVentaD(string Empresa, string Movimiento, string Usuario, string Cliente, int Canal,
            string Almacen, string Agente, string Condicion, int Sucursal,
            int Uen, string NoCtaPago, string Observaciones, string Comentario, string Concepto, string FormaPago,
            string Referencia, string FormaEnvio, int Opcion,
            string AgenteTelefonico, string pedComer, bool monederoRedimir, bool comMayoreo, string custodia, bool iva,
            string imprimirComentario, string nomina, string tipoVenta)
        {
            int? entero = null;
            DateTime? fecha = null;
            decimal? doble = null;
            bool? bol = null;

            SqlDataReader dr = null;
            int var = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312PuntoDeVentaIdVenta", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = Empresa;
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = Movimiento;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Canal", SqlDbType.Int).Value = Canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = Almacen;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = Agente;
                cmd.Parameters.Add("@Condicion", SqlDbType.VarChar).Value = Condicion;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@Uen", SqlDbType.Int).Value = Uen;
                cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = "No Identificado";

                if (Observaciones == "")
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = Observaciones;


                cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = Comentario;
                if (Concepto == "")
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = Concepto;

                cmd.Parameters.Add("@FormaPago", SqlDbType.VarChar).Value = FormaPago;

                if (Referencia == "")
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = Referencia;

                if (FormaEnvio == "")
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = FormaEnvio;
                cmd.Parameters.Add("@idVenta", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Opc", SqlDbType.Int).Value = Opcion;
                cmd.Parameters.Add("@MovId", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Proyecto", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Moneda", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@TipoCambio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@Autorizacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@DocFuente", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@SituacionFecha", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@SituacionUsuario", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionNota", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Directo", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Prioridad", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@RenglonID", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@FechaOriginal", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@AlmacenDestino", SqlDbType.VarChar).Value = DBNull.Value;
                if (AgenteTelefonico == "")
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = AgenteTelefonico;
                cmd.Parameters.Add("@AgenteComision", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@HoraRequerida", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@FechaProgramadaEnvio", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@FechaOrdenCompra", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@ReferenciaOrdenCompra", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@OrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Vencimiento", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@CtaDinero", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Importe", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Impuestos", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Saldo", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposFacturados", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposImpuestos", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@DescuentoLineal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@CostoTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@PrecioTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ZonaImpuestos", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@CancelacionID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@GenerarOP", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@DesglosarImpuestos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuesto2", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Enganche", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@Bonificacion", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IVAFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IEPSFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@EstaImpreso", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@Periodicidad", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SubModulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Pagado", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@AF", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Comisiones", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionesIVA", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@TieneTasaEsp", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@TasaEsp", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SobrePrecio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SincroC", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@SucursalDestino", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@MaviTipoVenta", SqlDbType.VarChar).Value = tipoVenta;
                cmd.Parameters.Add("@EsCredilana", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@SucJuego", SqlDbType.Char).Value = DBNull.Value;
                cmd.Parameters.Add("@OrigenSucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FacDesgloseIva", SqlDbType.Bit).Value = iva;
                cmd.Parameters.Add("@RedimePtos", SqlDbType.Bit).Value = monederoRedimir;
                cmd.Parameters.Add("@ArtQ", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;

                if (pedComer == "")
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = pedComer;

                cmd.Parameters.Add("@comMayoreo", SqlDbType.Bit).Value = comMayoreo;
                if (custodia == "")
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = custodia;
                if (imprimirComentario == "")
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = imprimirComentario;
                cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = nomina;
                //cmd.CommandTimeout = 9999999;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        var = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("IdVentaD", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return var;
        }

        /// <summary>
        ///     actualiza la informacion en la tabla VENTA
        /// </summary>
        /// <param name="Empresa">string</param>
        /// <param name="Movimiento">string</param>
        /// <param name="Usuario">int</param>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Agente">string</param>
        /// <param name="Condicion">int</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Uen">int</param>
        /// <param name="NoCtaPago">string</param>
        /// <param name="Observaciones">string</param>
        /// <param name="Comentario">int</param>
        /// <param name="Concepto">string</param>
        /// <param name="FormaPago">string</param>
        /// <param name="Referencia">string</param>
        /// <param name="FormaEnvio">int</param>
        /// <param name="Opcion">int</param>
        /// <param name="AgenteTelefonico">string</param>
        /// <param name="pedComer">string</param>
        /// <param name="monederoRedimir">bool</param>
        /// <param name="comMayoreo">bool</param>
        /// <param name="custodia">int</param>
        /// <param name="iva">bool</param>
        /// <param name="imprimirComentario">string</param>
        /// <param name="nomina">string</param>
        /// <param name="formaCo">string</param>
        /// Developer: Erika Perez
        /// Date: 08/09/17
        public bool ActualizaIdVenta(string Empresa, string Movimiento, string Usuario, string Cliente, int Canal,
            string Almacen, string Agente, string Condicion, int Sucursal,
            int Uen, string NoCtaPago, string Observaciones, string Comentario, string Concepto, string FormaPago,
            string Referencia, string FormaEnvio, int Opcion, int idVenta, string estatus,
            string AgenteTelefonico, string pedComer, bool monederoRedimir, bool comMayoreo, bool iva, string custodia,
            string imprimirComentario, string nomina, string formaCo, double dImporte, double dImpuestos)
        {
            SqlDataReader dr = null;
            bool Actualiza = new bool();
            int? entero = null;
            DateTime? fecha = null;
            decimal? doble = null;
            bool? bol = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312PuntoDeVentaIdVenta", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = Empresa;
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = Movimiento;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Canal", SqlDbType.Int).Value = Canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = Almacen;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = Agente;
                cmd.Parameters.Add("@Condicion", SqlDbType.VarChar).Value = Condicion;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@Uen", SqlDbType.Int).Value = Uen;

                if (NoCtaPago == "")
                    cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = "No Identificado";
                else
                    cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = NoCtaPago;

                if (Observaciones == "")
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = Observaciones;
                cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = Comentario;

                if (Concepto == "")
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = Concepto;
                cmd.Parameters.Add("@FormaPago", SqlDbType.VarChar).Value = FormaPago;
                if (Referencia == "")
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = Referencia;

                if (FormaEnvio == "")
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = FormaEnvio;
                cmd.Parameters.Add("@idVenta", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@Opc", SqlDbType.Int).Value = Opcion;
                cmd.Parameters.Add("@MovId", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Proyecto", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Moneda", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@TipoCambio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@Autorizacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@DocFuente", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = estatus;
                cmd.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionFecha", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@SituacionUsuario", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionNota", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Directo", SqlDbType.Bit).Value = bol ?? SqlBoolean.False;
                cmd.Parameters.Add("@Prioridad", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@RenglonID", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@FechaOriginal", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@AlmacenDestino", SqlDbType.VarChar).Value = DBNull.Value;
                if (AgenteTelefonico == "")
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = AgenteTelefonico;
                cmd.Parameters.Add("@AgenteComision", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@HoraRequerida", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@FechaProgramadaEnvio", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@FechaOrdenCompra", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@ReferenciaOrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@OrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Vencimiento", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@CtaDinero", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Importe", SqlDbType.Money).Value = dImporte;
                cmd.Parameters.Add("@Impuestos", SqlDbType.Money).Value = dImpuestos;
                cmd.Parameters.Add("@Saldo", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposFacturados", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposImpuestos", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@DescuentoLineal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@CostoTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@PrecioTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ZonaImpuestos", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@CancelacionID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@GenerarOP", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@DesglosarImpuestos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuesto2", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Enganche", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@Bonificacion", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IVAFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IEPSFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@EstaImpreso", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@Periodicidad", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SubModulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Pagado", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@AF", SqlDbType.Bit).Value = 0;
                if (formaCo == "")
                    cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = formaCo;
                cmd.Parameters.Add("@Comisiones", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionesIVA", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@TieneTasaEsp", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@TasaEsp", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SobrePrecio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SincroC", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@SucursalDestino", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@MaviTipoVenta", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@EsCredilana", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@SucJuego", SqlDbType.Char).Value = DBNull.Value;
                cmd.Parameters.Add("@OrigenSucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FacDesgloseIva", SqlDbType.Bit).Value = iva;
                cmd.Parameters.Add("@RedimePtos", SqlDbType.Bit).Value = monederoRedimir;
                cmd.Parameters.Add("@ArtQ", SqlDbType.Bit).Value = bol ?? SqlBoolean.False;
                if (pedComer == "")
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = pedComer;
                cmd.Parameters.Add("@comMayoreo", SqlDbType.Bit).Value = comMayoreo;
                if (custodia == "")
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = custodia;
                if (imprimirComentario == "")
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = imprimirComentario;
                cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = nomina;
                //cmd.CommandTimeout = 9999999;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        Actualiza = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizaIdVenta", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Actualiza;
        }

        /// <summary>
        ///     actualiza la informacion de la devolucion en la tabla VENTA
        /// </summary>
        /// <param name="Empresa">string</param>
        /// <param name="Movimiento">string</param>
        /// <param name="Usuario">int</param>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Agente">string</param>
        /// <param name="Condicion">int</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Uen">int</param>
        /// <param name="NoCtaPago">string</param>
        /// <param name="Observaciones">string</param>
        /// <param name="Comentario">int</param>
        /// <param name="Concepto">string</param>
        /// <param name="FormaPago">string</param>
        /// <param name="Referencia">string</param>
        /// <param name="FormaEnvio">int</param>
        /// <param name="Opcion">int</param>
        /// <param name="AgenteTelefonico">string</param>
        /// <param name="pedComer">string</param>
        /// <param name="monederoRedimir">bool</param>
        /// <param name="comMayoreo">bool</param>
        /// <param name="custodia">int</param>
        /// <param name="iva">bool</param>
        /// <param name="imprimirComentario">string</param>
        /// <param name="nomina">string</param>
        /// <param name="formaCo">string</param>
        /// Developer: Erika Perez
        /// Date: 08/09/17
        public bool ActualizaIdVentaD(string Empresa, string Movimiento, string Usuario, string Cliente, int Canal,
            string Almacen, string Agente, string Condicion, int Sucursal,
            int Uen, string NoCtaPago, string Observaciones, string Comentario, string Concepto, string FormaPago,
            string Referencia, string FormaEnvio, int Opcion, int idVenta, string estatus,
            string AgenteTelefonico, string pedComer, bool monederoRedimir, bool comMayoreo, bool iva, string custodia,
            string imprimirComentario, string nomina, string tipoventa)
        {
            SqlDataReader dr = null;
            bool Actualiza = new bool();
            int? entero = null;
            DateTime? fecha = null;
            decimal? doble = null;
            bool? bol = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312PuntoDeVentaIdVenta", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = Empresa;
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = Movimiento;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Usuario;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Canal", SqlDbType.Int).Value = Canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = Almacen;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = Agente;
                cmd.Parameters.Add("@Condicion", SqlDbType.VarChar).Value = Condicion;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@Uen", SqlDbType.Int).Value = Uen;

                if (NoCtaPago == "")
                    cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = "No Identificado";
                else
                    cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = NoCtaPago;

                if (Observaciones == "")
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = Observaciones;
                cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = Comentario;

                if (Concepto == "")
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = Concepto;
                cmd.Parameters.Add("@FormaPago", SqlDbType.VarChar).Value = FormaPago;
                if (Referencia == "")
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = Referencia;

                if (FormaEnvio == "")
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = FormaEnvio;
                cmd.Parameters.Add("@idVenta", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@Opc", SqlDbType.Int).Value = Opcion;
                cmd.Parameters.Add("@MovId", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Proyecto", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Moneda", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@TipoCambio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@Autorizacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@DocFuente", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = estatus;
                cmd.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionFecha", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@SituacionUsuario", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SituacionNota", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Directo", SqlDbType.Bit).Value = bol ?? SqlBoolean.False;
                cmd.Parameters.Add("@Prioridad", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@RenglonID", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@FechaOriginal", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@AlmacenDestino", SqlDbType.VarChar).Value = DBNull.Value;
                if (AgenteTelefonico == "")
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = AgenteTelefonico;
                cmd.Parameters.Add("@AgenteComision", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@HoraRequerida", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@FechaProgramadaEnvio", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@FechaOrdenCompra", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@ReferenciaOrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@OrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Vencimiento", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@CtaDinero", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Importe", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Impuestos", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Saldo", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposFacturados", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@AnticiposImpuestos", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@DescuentoLineal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@CostoTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@PrecioTotal", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ZonaImpuestos", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@CancelacionID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@GenerarOP", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@DesglosarImpuestos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuesto2", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Enganche", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@Bonificacion", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IVAFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IEPSFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@EstaImpreso", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@Periodicidad", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SubModulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Pagado", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@AF", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Comisiones", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionesIVA", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@TieneTasaEsp", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@TasaEsp", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SobrePrecio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SincroC", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@SucursalDestino", SqlDbType.Int).Value = Sucursal;
                cmd.Parameters.Add("@MaviTipoVenta", SqlDbType.VarChar).Value = tipoventa;
                cmd.Parameters.Add("@EsCredilana", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@SucJuego", SqlDbType.Char).Value = DBNull.Value;
                cmd.Parameters.Add("@OrigenSucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FacDesgloseIva", SqlDbType.Bit).Value = iva;
                cmd.Parameters.Add("@RedimePtos", SqlDbType.Bit).Value = monederoRedimir;
                cmd.Parameters.Add("@ArtQ", SqlDbType.Bit).Value = bol ?? SqlBoolean.False;
                if (pedComer == "")
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = pedComer;
                cmd.Parameters.Add("@comMayoreo", SqlDbType.Bit).Value = comMayoreo;
                if (custodia == "")
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = custodia;
                if (imprimirComentario == "")
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = imprimirComentario;
                cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = nomina;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        Actualiza = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizaIdVenta", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Actualiza;
        }

        /// <summary>
        ///     elimina el movimiento de la tabla VENTA
        /// </summary>
        /// <param name="Opcion">int</param>
        /// <param name="idVenta">int</param>
        /// Developer: Erika Perez
        /// Date: 08/09/17
        public bool EliminarIdVenta(int Opcion, int idVenta)
        {
            bool Agrega = new bool();
            SqlDataReader dr = null;
            int? entero = null;
            DateTime? fecha = null;
            decimal? doble = null;
            bool? bol = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312PuntoDeVentaIdVenta", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Mov", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Canal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Condicion", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Uen", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@NoCtaPago", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Concepto", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@FormaPago", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@FormaEnvio", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@idVenta", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@Opc", SqlDbType.Int).Value = Opcion;
                cmd.Parameters.Add("@MovId", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Proyecto", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Moneda", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@TipoCambio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@Autorizacion", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@DocFuente", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                cmd.Parameters.Add("@Estatus", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Situacion", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@SituacionFecha", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@SituacionUsuario", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@SituacionNota", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Directo", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Prioridad", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@RenglonID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FechaOriginal", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@AlmacenDestino", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@AgenteServicio", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@AgenteComision", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@HoraRequerida", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@FechaProgramadaEnvio", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@FechaOrdenCompra", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@ReferenciaOrdenCompra", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@OrdenCompra", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Vencimiento", SqlDbType.DateTime).Value = fecha ?? SqlDateTime.Null;
                cmd.Parameters.Add("@CtaDinero", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Importe", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Impuestos", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Saldo", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@AnticiposFacturados", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@AnticiposImpuestos", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@DescuentoLineal", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@ComisionTotal", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@CostoTotal", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@PrecioTotal", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@ZonaImpuestos", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@CancelacionID", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@GenerarOP", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuestos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@DesglosarImpuesto2", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@Enganche", SqlDbType.Money).Value = 0.0;
                cmd.Parameters.Add("@Bonificacion", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IVAFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@IEPSFiscal", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@EstaImpreso", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@Periodicidad", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@SubModulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Pagado", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@AF", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@LineaCredito", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@Comisiones", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@ComisionesIVA", SqlDbType.Money).Value = DBNull.Value;
                cmd.Parameters.Add("@TieneTasaEsp", SqlDbType.Bit).Value = 0;
                cmd.Parameters.Add("@TasaEsp", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SobrePrecio", SqlDbType.Float).Value = doble ?? SqlDecimal.Null;
                cmd.Parameters.Add("@SincroC", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@SucursalDestino", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@MaviTipoVenta", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@EsCredilana", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@SucJuego", SqlDbType.Char).Value = DBNull.Value;
                cmd.Parameters.Add("@OrigenSucursal", SqlDbType.Int).Value = entero ?? SqlInt32.Null;
                ;
                cmd.Parameters.Add("@FacDesgloseIva", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@RedimePtos", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@ArtQ", SqlDbType.Bit).Value = bol ?? SqlBoolean.Null;
                cmd.Parameters.Add("@PedCommers", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@comMayoreo", SqlDbType.Bit).Value = bol ?? SqlBoolean.False;
                cmd.Parameters.Add("@Causa", SqlDbType.VarChar).Value = "";

                cmd.Parameters.Add("@imprimirComentario", SqlDbType.VarChar).Value = DBNull.Value;

                cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = "";
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Agrega = true;
                else
                    Agrega = false;
            }
            catch (Exception ex)
            {
                if (ex.Message != "El Movimiento Ya fue Afectado por Otro Usuario" &&
                    ex.Message != "No Puede Eliminar un Consecutivo Asignado") MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Agrega;
        }

        public int ValidaCampoExtra(string usuario, int idVenta)
        {
            int valTemp = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format(" SELECT dbo.fn_MaviDM0169CampoExtraActivo ('{0}','{1}')", usuario,
                    idVenta);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valTemp = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCampoExtra", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valTemp;
        }

        /// <summary>
        ///     Valida si ya se almacena campos extras en la tabla MovCampoExtra para realizar el Update a los registros
        ///     Developer: Victor Avila
        /// </summary>
        /// <param name="idVenta"></param>
        /// <returns></returns>
        public int ValidaRegistroCampoExtra(int idVenta)
        {
            int validaTemp = 0;
            SqlDataReader dr = null;
            try
            {
                string query = "SELECT COUNT(id) FROM MovCampoExtra WHERE id = " + idVenta + "";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) validaTemp = dr.GetInt32(0);
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaRegistroCampoExtra", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return validaTemp;
        }

        public bool ValidaEstatusCaja(string caja)
        {
            bool validaCaja = false;
            SqlDataReader dr = null;
            try
            {
                string query = "select estado from ctadinero with (nolock) where ctadinero= '" + caja + "'";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) validaCaja = dr.GetBoolean(0);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaEstatusCaja", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return validaCaja;
        }

        /// <summary>
        ///     Permite optener los registros para Campos Extras, para realizar el Update
        ///     Developer: Victor Avila
        /// </summary>
        /// <param name="idVenta"></param>
        /// <returns></returns>
        public List<DM0312_MPuntoVentaCampoExtra> ActualizaCamposExtras(int idVenta)
        {
            List<DM0312_MPuntoVentaCampoExtra> modelList = new List<DM0312_MPuntoVentaCampoExtra>();
            SqlDataReader dr = null;
            try
            {
                string query = "SELECT CampoExtra, Valor FROM MovCampoExtra with (nolock) WHERE id = " + idVenta + "";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MPuntoVentaCampoExtra model_ = new DM0312_MPuntoVentaCampoExtra();
                    model_.CampoExtra = dr["CampoExtra"].ToString();
                    model_.Valor = dr["Valor"].ToString();
                    modelList.Add(model_);
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizaCamposExtras", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return modelList;
        }

        public bool UsuarioCteActualiza(string usuario)
        {
            bool validaUsuario = false;
            int usuarioTemp = 0;
            string query = "SELECT COUNT(cliente) FROM CTE WITH (NOLOCK) WHERE Cliente = '" + usuario +
                           "' AND Canal <>76";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;

                dr = sqlCommand.ExecuteReader();

                while (dr.Read()) usuarioTemp = dr.GetInt32(0);

                if (usuarioTemp == 1)
                    validaUsuario = false;
                else
                    validaUsuario = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("UsuarioCteActualiza", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return validaUsuario;
        }

        public void DeleteEventoValera(int idVenta)
        {
            string query = "delete MovBitacora where id='" + idVenta +
                           "'  and clave in ('VTA00105','VTA00110','VTA00120','VTA00130','VTA00140')";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
        }

        public string ValidaCorreo(string cliente, string usuario)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                query = "select dbo.fnDM0138validaCte('" + cliente + "','" + usuario + "')";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCorreo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }

        public string ValidarCliente(string cliente)
        {
            string clienteR = "";
            SqlDataReader dr = null;
            string query = "select NOMBRE from cte  WITH (NOLOCK) WHERE estatus='alta' and cliente = '" + cliente + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        clienteR = dr[0].ToString();
                else
                    clienteR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarCliente", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return clienteR;
        }

        public string AlertaValidacionHuella(string cliente)
        {
            string Alerta = "";
            SqlDataReader dr = null;
            string query = "select sid from Fingerprints with (nolock) where (sid=0 or sid is null) and fingerid = '" +
                           cliente + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Alerta = dr[0].ToString();
                else
                    Alerta = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AlertaValidacionHuella", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Alerta;
        }

        public string ValidarNominaEmpleado(string nomina)
        {
            string nominaR = "";
            SqlDataReader dr = null;
            string query = "select Personal from personal  WITH (NOLOCK) where estatus='alta' and personal = '" +
                           nomina + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        nominaR = dr[0].ToString();
                else
                    nominaR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarNominaEmpleado", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return nominaR;
        }

        public string ValidarNominaEmpleadoDuplicado(string nomina, string cliente)
        {
            string nominaR = "";
            SqlDataReader dr = null;
            string query =
                "select TOP 1 nomina from CteEnviarA a with (nolock) inner join cte c on c.Cliente=a.Cliente where id=34 and a.cliente <>'" +
                cliente + "' and nomina= '" + nomina + "' and c.Estatus='alta' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        nominaR = dr[0].ToString();
                else
                    nominaR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarNominaEmpleado", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return nominaR;
        }

        public string ValidarClienteGenerico(string cliente)
        {
            string nominaR = "";
            SqlDataReader dr = null;
            string query =
                "Select CUENTA From ListaD with (nolock) Where Rama =  'CXC' And Lista = 'Ctes Genericos' and cuenta = '" +
                cliente + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        nominaR = dr[0].ToString();
                else
                    nominaR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarClienteGenerico", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return nominaR;
        }

        public string ValidarCanal(int canal)
        {
            string canalR = "";
            SqlDataReader dr = null;
            string query =
                "select distinct a.id from CteEnviarA a WITH(NOLOCK) inner join  VentasCanalMAVI v  WITH (NOLOCK) on a.id=v.id WHERE v.uen=" +
                ClaseEstatica.Usuario.Uen + " AND a.ID ='" + canal + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        canalR = dr[0].ToString();
                else
                    canalR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarCanal", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return canalR;
        }

        public string ValidarAlmacen(string almacen)
        {
            string almacenR = "";
            SqlDataReader dr = null;
            string query = "SELECT Almacen FROM Alm WITH(NOLOCK) WHERE Estatus = 'Alta' and Almacen='" + almacen + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        almacenR = dr[0].ToString();
                else
                    almacenR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarAlmacen", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return almacenR;
        }

        public string ValidarAgente(string agente, int suc)
        {
            string AgenteR = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;

            if (ClaseEstatica.Usuario.Uen == 1)
            {
                if (ClaseEstatica.Usuario.sucursal == 30)
                    query =
                        "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                        sucursal +
                        "'  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' and  agente='" +
                        agente + "' AND TIPO<>'AUDITOR'  ORDER BY Categoria desc,Agente,Nombre";
                else
                    query =
                        "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa='" +
                        sucursal +
                        "'  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' AND   agente='" +
                        agente +
                        "' and TIPO<>'AUDITOR'   union all select venta.AGENTE2,CASE WHEN venta.TIPO='EQUIPO' THEN p.ApellidoPaterno+' '+ApellidoMaterno+' '+p.Nombre ELSE venta.Nombre END ,venta.Tipo,venta.Categoria,venta.SucursalEmpresa from(select AGENTE2=CASE WHEN TIPO='EQUIPO' THEN  REPORTAA ELSE Agente END,Nombre, Tipo,Categoria,SucursalEmpresa from agente a   with(nolock) where  categoria ='ventas dima' and estatus ='alta')venta inner join Personal P ON p.Personal=venta.AGENTE2 where venta.AGENTE2='" +
                        agente + "'  ORDER BY Categoria desc,Agente,Nombre";
            }
            else
            {
                if (ClaseEstatica.Usuario.Uen == 3)
                    query =
                        "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa=" +
                        sucursal + " and estatus ='alta' and  agente='" + agente +
                        "'  ORDER BY Categoria desc,Agente,Nombre";
                else
                    query =
                        "select Agente,Nombre, Tipo,Categoria,SucursalEmpresa from agente a  with(nolock) where SucursalEmpresa=" +
                        sucursal +
                        "  and categoria in('ventas piso','REACTIVACION VENTAS','VENTAS AVANZADA') and estatus ='alta' AND TIPO<>'AUDITOR' and  agente='" +
                        agente + "'  ORDER BY Categoria desc,Agente,Nombre";
            }


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        AgenteR = dr[0].ToString();
                else
                    AgenteR = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarAgente", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return AgenteR;
        }

        public List<string> ValidacionTelefonos(string cliente)
        {
            SqlDataReader dr = null;
            List<string> telefonos = new List<string>();
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MaviDM0312TelefonosClientes", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        telefonos.Add(dr[0].ToString());
                        telefonos.Add(dr[1].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidacionTelefonos", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return telefonos;
        }

        public string TelefonoCorrecto(string telefono)
        {
            SqlDataReader dr = null;
            string telefonoR = "";
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MaviDM0312ValidacionTelefono", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = telefono;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        telefonoR = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TelefonoCorrecto", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return telefonoR;
        }

        public int? GetPropreListaID(int IdVenta_, string codart, bool monedero)
        {
            int monedero_ = Convert.ToInt32(monedero);

            int? val = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format("SELECT dbo.fnProprePrecioID({0}, '{1}', {2})", IdVenta_, codart,
                    monedero_);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (!dr.HasRows)
                    return 0;

                while (dr.Read())
                    if (dr[0].ToString() == string.Empty)
                        val = null;
                    else
                        val = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GetPropreListaID", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }

        public bool DeleteSeriesLotes(string SerieLote, int? idventa = null, string articulo = null)
        {
            if ((SerieLote == null) | (SerieLote == string.Empty))
                return true;

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312DeleteSerieLoteMov", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@SerieLote", SqlDbType.VarChar).Value = SerieLote;
                cmd.Parameters.Add("@IdVenta", SqlDbType.Int).Value = idventa;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = articulo;
                dr = cmd.ExecuteReader();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message + " DeleteSeriesLotes in___ DM0312_CPuntoDeVenta", "Error!!");
                return false;
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public string ValidaCaracter(string cuenta, string dominio)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                query = "select dbo.FN_DM0138ValidaCaracter('" + cuenta + "1','" + dominio + "1')";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
                else
                    Validacion = "0";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCaracter", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }

        public int GuardarCorreo(string cliente, string cuenta, string dominio)
        {
            SqlDataReader dr = null;
            int Validacion = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0138GuardaCorreo ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@Cuenta", SqlDbType.VarChar).Value = cuenta;
                cmd.Parameters.Add("@Dominio", SqlDbType.VarChar).Value = dominio;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarCorreo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }

        public void GuardarCorreoHist(string cliente, string usuario, int sucursal, string correo)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0138HistInsertCorreo ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuario;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                cmd.Parameters.Add("@Correo", SqlDbType.VarChar).Value = correo;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarCorreoHist", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public void InsertaCorreo(int id, string modulo, int uen, string correo)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0138InsertGuardaCorreomodulo ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = modulo;
                cmd.Parameters.Add("@UEN", SqlDbType.Int).Value = uen;
                cmd.Parameters.Add("@Correo", SqlDbType.VarChar).Value = correo;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertaCorreo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public void HistorialCorreo(string cliente, string movimiento, int bandera, int id, string modulo,
            string usuario, int sucursal, string correo)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0312ChecarAbrirVentana ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@Movimiento", SqlDbType.VarChar).Value = movimiento;
                cmd.Parameters.Add("@Bandera ", SqlDbType.Int).Value = bandera;
                cmd.Parameters.Add("@ID_Mov", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = modulo;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuario;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                cmd.Parameters.Add("@correo", SqlDbType.VarChar).Value = correo;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("HistorialCorreo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        //Autor:Rodolfo Sanchez
        //Modulo: Punto de venta
        //Metodo: Obtiene Sucursal
        //Fecha:25/10/2017
        public int GetSucursal(string Almacen)
        {
            int Sucursal = 0;
            SqlDataReader dr = null;
            string query = string.Format("select top 1 sucursal from alm  WITH (NOLOCK) where almacen='{0}'", Almacen);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Sucursal = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Sucursal;
        }

        /// <summary>
        ///     Developer : Victor Avila
        ///     Date : 14/11/2017
        /// </summary>
        /// <param name="Uen"></param>
        /// <returns>List<string></returns>
        public Image FillImage(int Uen, int numeroFoto)
        {
            SqlDataReader dr = null;
            Image bit = null;
            string query = "SELECT  Imagen FROM [AdminDoc].[dbo].[TREDM0312_Promociones]  WITH (NOLOCK) WHERE Uen = " +
                           Uen + " AND IdImagen = " + numeroFoto + "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                while (dr.Read())
                {
                    object exemplo = dr.GetValue(0);
                    byte[] contenido = (byte[])dr.GetValue(0);
                    MemoryStream memstr = new MemoryStream(contenido);
                    return bit = Image.FromStream(memstr);
                }

                Console.Write(bit);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            //finally { dr.Close(); }

            return null;
        }

        /// <summary>
        ///     Permite verificar si el usuario realizara la primera compra (Nuevo) o si ya cuenta con una venta en canal 76 (Casa)
        ///     Developer: Victor Avila
        ///     Date: 15/11/2017
        /// </summary>
        /// <param name="idVenta"></param>
        /// <returns>string</returns>
        public string ValidaFuncionNuevoCasa(int idVenta)
        {
            string valida = string.Empty;
            SqlDataReader dr = null;
            string query = string.Format("SELECT dbo.fnClientesNuevosCasaMAVI ('{0}')", idVenta);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valida = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return valida;
        }

        /// <summary>
        ///     Verifica si el usuario ya haya tenido una venta en canal 76,  concluida  y Mov =  factura
        ///     Developer : Victor Avila
        ///     Date : 15/11/2017
        /// </summary>
        /// <param name="cliente"></param>
        /// <returns>int</returns>
        public int validaVentaCanalAsociados(string cliente)
        {
            int totalVenta = 0;
            SqlDataReader dr = null;
            string query = "SELECT COUNT(*) FROM Venta WITH(NOLOCK) WHERE Cliente = '" + cliente +
                           "' AND Estatus = 'CONCLUIDO' AND Mov IN('FACTURA','CREDILANA') AND EnviarA = 76 ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) totalVenta = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return totalVenta;
        }

        public int CandadoEdadAños(string movimiento)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format(
                        "select valor from tablastd with (nolock) where tablast='MaximaEdadDelCliente' and nombre = '" +
                        movimiento + "'");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valor = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalRDP", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valor;
        }


        /// <summary>
        ///     Developer: Erika Jeanette Perez
        ///     <param name="idVenta"></param>
        ///     <returns></returns>
        public int CantidadPaquete(string art, string artP)
        {
            int cant = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    "SELECT cantidad FROM ArtJuego a   inner join ArtJuegod d  on a.Articulo=d.Articulo and a.Juego=d.Juego WHERE a.articulo='" +
                    artP + "' and d.opcion='" + art + "'";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) cant = int.Parse(dr[0].ToString());
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CantidadPaquete", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return cant;
        }


        /// <summary>
        ///     obtener la cantidad de cada componente vendido para poder devolver
        ///     Developer: Erika Jeanette Perez
        ///     <param name="idVenta"></param>
        ///     <returns></returns>
        public int CantidadPaqueteDev(string art, int id)
        {
            int cant = 0;
            SqlDataReader dr = null;
            try
            {
                string query = "SELECT cantidad FROM ventad v  WHERE v.articulo='" + art + "' and v.id='" + id + "'";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) cant = int.Parse(dr[0].ToString());
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CantidadPaqueteDev", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return cant;
        }

        /// <summary>
        ///     edita el campo de tipo DIMA del catalogo de clientes
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="nomina">string</param>
        /// <param name="opc">int</param>
        /// Developer: Erika Perez
        /// Date: 01/10/18
        public void UpdateTipoDima(string sCliente, string sTipoDima)
        {
            try
            {
                string sQuery = "UPDATE Cte WITH (ROWLOCK) SET TipoDIMA = @TipoDima WHERE Cliente = @Cliente";
                SqlParameter[] pars =
                {
                    new SqlParameter("@TipoDima", sTipoDima)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        ///     Obtener los dias vencidos configurado
        /// </summary>
        /// <returns></returns>
        public string DiasV()
        {
            string val = "";
            SqlDataReader dr = null;
            string query;
            query = "SELECT top 1 valor FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='CandadoMonederoVirtual' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = dr[0].ToString();
                else
                    val = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DiasV", "CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }


        /// <summary>
        ///     Mostrar los clientes Red DIMA
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 03/09/17
        public DataTable ClienteRed()
        {
            DataTable dataSet = new DataTable();
            string query =
                " select distinct e.cliente as Cliente,e.NOMBRE AS Nombre FROM Cte e  WITH(NOLOCK) inner join Venta v WITH(NOLOCK) on e.cliente=v.Cliente inner join  ventad d with(nolock) on v.id=d.id where (v.enviara=76 and v.Estatus='concluido' and v.mov IN ('FACTURA','CREDILANA') ) or(v.mov='analisis credito' and v.situacion like '%condicionado%' and v.estatus in('concluido','pendiente') and d.Articulo='VALR00001') ORDER BY e.Cliente   ";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }


        /// <summary>
        ///     metodo para validar si el cliente es correcto para red DIMA
        /// </summary>
        /// <param name="almacen">string</param>
        /// Developer: Erika Perez
        /// Date: 03/12/18
        public string ClienteRedV(string cte)
        {
            SqlDataReader dr = null;
            string cliente = "";
            try
            {
                string query = string.Empty;
                query =
                    "select distinct e.NOMBRE AS CLIENTE FROM Cte e  WITH(NOLOCK) inner join Venta v WITH(NOLOCK) on e.cliente=v.Cliente  inner join  ventad d with(nolock) on v.id=d.id  where (v.enviara=76 and v.Estatus='concluido' and v.mov IN ('FACTURA','CREDILANA')  and e.Cliente='" +
                    cte +
                    "' ) or(v.mov='analisis credito' and v.situacion like '%condicionado%' and v.estatus in('concluido','pendiente') and d.Articulo='VALR00001'  and e.Cliente='" +
                    cte + "' ) ";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        cliente = dr[0].ToString();
                else
                    cliente = "NO";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return cliente;
        }


        public int ValidaCuentasDimaR(string cliente, string clienteR)
        {
            SqlDataReader dr = null;
            int Validacion = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0264ValidaCuentasDimR_O ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@DimaR", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@DimO", SqlDbType.VarChar).Value = clienteR;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCuentasDimaR", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }


        /// <summary>
        ///     optiene los articulos del movimiento a modificar
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 12/01/19
        public List<MArticulosEditar> ArticulosEditar(int id)
        {
            List<MArticulosEditar> Lista = new List<MArticulosEditar>();
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;
                query = string.Format(
                    " SELECT DISTINCT articulo,cantidad,usuariodescuento,Isnull(precioanterior,'')precioanterior,isnull(precio,0) precio, renglon FROM ventad WITH(NOLOCK) WHERE id= " +
                    id + " ORDER BY Renglon ASC");

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
                MArticulosEditar EmptyModel = new MArticulosEditar();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MArticulosEditar model_ = new MArticulosEditar();
                        model_.Codigo = dr["articulo"].ToString();
                        model_.Cantidad = int.Parse(dr["cantidad"].ToString());
                        model_.sUsuarioDescuento = dr["usuariodescuento"].ToString();
                        model_.fPrecioAnterior = float.Parse(dr["precioanterior"].ToString());
                        model_.fPrecio = float.Parse(dr["precio"].ToString());
                        model_.iRenglon = int.Parse(dr["renglon"].ToString());
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ArticulosEditar", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        /// <summary>
        ///     Eliminar el detalle del pedido a modificar
        /// </summary>
        /// Developer: Erika Perez
        /// Date: 12/01/19
        public void ArticulosEliminar(int id)
        {
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;
                query = string.Format(" delete ventad  WHERE id= '" + id + "' ");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ArticulosEliminar", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }


        #region Registro Eliminacion de Pedido

        public void GuardarRegistroEliminado(string ip, int id)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASPedidoEliminado ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IdVenta  ", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Usuario  ", SqlDbType.VarChar).Value = ClaseEstatica.Usuario.Usser;
                cmd.Parameters.Add("@IP  ", SqlDbType.VarChar).Value = ip;
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarRegistroEliminado", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        #endregion

        //-ErrorIVA
        public double getIVA()
        {
            double iva = 0;
            SqlDataReader dr = null;

            string query = "select defimpuesto from EmpresaGral With(Nolock) where Empresa='MAVI'";

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;

                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                        {
                            string go = dr[0].ToString();
                            iva = double.Parse(dr[0].ToString()) / 100;
                            return iva;
                        }
                }
            }

            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getIVA", "DM0312_CPuntoDeVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return iva;
        }


        #region Vales

        public bool validarArticuloVale(string sArticulo)
        {
            bool bArticuloPuede = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede FROM art WHERE Articulo = '{0}' AND Linea = 'CREDILANA'", sArticulo);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bArticuloPuede = true;
                        else
                            bArticuloPuede = false;
                else
                    bArticuloPuede = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarArticuloDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return bArticuloPuede;
        }

        #endregion

        #region Datalogic

        /// <summary>
        ///     Metodo encargado de obtener las recargas a vender
        /// </summary>
        /// <returns>retorna lista de recargas</returns>
        /// Autor: Norberto Reyes C.
        public List<clsModeloRecarga> obtenerRecargas(int iOpcion, string sConsulta = "")
        {
            List<clsModeloRecarga> Lista = new List<clsModeloRecarga>();
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;

                if (iOpcion == 1)
                    query = string.Format("SELECT " +
                                          "pago.Codigo," +
                                          "ISNULL(CodigoIntelisis, '') AS CodigoIntelisis," +
                                          "Nombre," +
                                          "pago.Tipo," +
                                          "Prov," +
                                          "Monto," +
                                          "ISNULL(Acreedor, '') AS Acreedor " +
                                          "FROM dm0216pagoexternoart pago WITH (NOLOCK) " +
                                          "INNER JOIN art ar WITH (NOLOCK) " +
                                          "ON(ar.Articulo = pago.CodigoIntelisis) " +
                                          "WHERE ar.Estatus = 'ALTA' " +
                                          "AND pago.Tipo = 'TAE' " +
                                          "AND pago.Estatus <> 'BAJA' " +
                                          "ORDER BY CodigoIntelisis,Monto desc");
                if (iOpcion == 2) query = sConsulta;

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                clsModeloRecarga EmptyModel = new clsModeloRecarga();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        clsModeloRecarga model_ = new clsModeloRecarga();
                        model_.sCodigo = dr["Codigo"].ToString();
                        model_.sCodigoIntelisis = dr["CodigoIntelisis"].ToString();
                        model_.sNombre = dr["Nombre"].ToString();
                        model_.sTIpo = dr["Tipo"].ToString();
                        model_.sProv = dr["Prov"].ToString();
                        model_.sMonto = int.Parse(dr["Monto"].ToString());
                        model_.sAcreedor = dr["Acreedor"].ToString();
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        #endregion

        #region //-808

        /// <summary>
        ///     Metodo encargado de obtener el sku de articulo en base al codigo de barras
        /// </summary>
        /// <param name="sCodigoBarra"></param>
        /// <returns></returns>
        public string buscarArticuloCB(string sCodigoBarra, int iBusqueda)
        {
            string sArticulo = "";
            DataTable dt = new DataTable();
            try
            {
                string sQuery = string.Empty;
                switch (iBusqueda)
                {
                    case 1:
                        sQuery = "SELECT Cuenta AS Cuenta FROM cb WITH(NOLOCK) WHERE Codigo = @CodigoBarra";
                        break;
                    case 2:
                        sQuery = "SELECT Codigo AS Cuenta FROM cb WITH(NOLOCK) WHERE Cuenta = @CodigoBarra";
                        break;
                    default:
                        sQuery = string.Empty;
                        break;
                }

                SqlParameter[] pars =
                {
                    new SqlParameter("@CodigoBarra", sCodigoBarra)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sArticulo = item["Cuenta"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sArticulo;
        }

        #endregion

        #region //-Dineralia

        /// <summary>
        ///     Metodo encargado de obtener el ultimo moviemnto de dineralia del cliente
        /// </summary>
        /// <param name="sCliente">cliente dineralia</param>
        /// <returns>retorna el id de la tabla CREDICDatosSolicitudWebDineraliaTmp por el cliente</returns>
        public int obtenerIdDineralia(string sCliente)
        {
            int iIdDineralia = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select top 1 IdDatosSolicitudWebDineraliaTmp from CREDICDatosSolicitudWebDineraliaTmp where cliente = @Cliente order by IdDatosSolicitudWebDineraliaTmp desc";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        iIdDineralia = int.Parse(item["IdDatosSolicitudWebDineraliaTmp"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return iIdDineralia;
        }

        #endregion

        /// <summary>
        ///     Metodo encargado de obtener el tipo de cliente dima
        /// </summary>
        /// <param name="sCliente">Cliente dima</param>
        /// <returns>retorna un string con el tipo de cliente dima</returns>
        public string obtenerTipoDima(string sCliente)
        {
            string sTipoDima = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT ISNULL(TipoDima,'') AS TipoDima FROM Cte WITH(NOLOCK) WHERE Cliente = @Cliente";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        sTipoDima = row["TipoDima"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }


            return sTipoDima;
        }

        #region DimaForaneo

        public List<string> obtenerCondicionesForaneas()
        {
            dt = new DataTable();
            List<string> listaCondiciones = new List<string>();
            try
            {
                string sQuery =
                    "SELECT Nombre from tablastd WITH(NOLOCK) WHERE TablaSt = 'CONDICIONESDIMAFORANEO' AND Valor = 1";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaCondiciones.Add(row["Nombre"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaCondiciones;
        }

        #endregion

        #region //-1826

        public double obtenerDescuentoCategoria(int iIdVenta, string sArticulo)
        {
            dt = new DataTable();
            double dDescuento = 0;
            try
            {
                string sQuery = @"SELECT ISNULL(DescuentoCategoria,0) AS Descuento FROM Venta v WITH(NOLOCK) 
                                JOIN PropreListaDFinal pp WITH(NOLOCK)
                                ON pp.Articulo = @Articulo
                                JOIN Condicion C WITH(NOLOCK)
                                ON c.PROPREGrupo = pp.Condicion
                                AND c.Condicion = v.Condicion
                                WHERE v.ID = @IdVenta";
                SqlParameter[] pars =
                {
                    new SqlParameter("@IdVenta", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Articulo", sArticulo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        dDescuento = double.Parse(row["Descuento"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dDescuento;
        }

        #endregion

        //Fin de IdVenta

        #region VentaDetalle //Rodolfo

        public List<DM0312_MVentaDetalle> GetArtJuego(string codart)
        {
            List<DM0312_MVentaDetalle> ListArtJuegoD = new List<DM0312_MVentaDetalle>();

            SqlDataReader dr = null;

            try
            {
                string query =
                    string.Format(
                        " SELECT jd.Juego, jd.Opcion, jd.SubCuenta, a.Descripcion1, ISNULL(SUM(CONVERT(int, d.Disponible)), 0) " +
                        " FROM ArtJuegoD jd   WITH (NOLOCK) JOIN Art a  WITH (NOLOCK) ON a.Articulo = jd.Opcion LEFT OUTER JOIN ArtSubDisponibleDesc d  with (nolock) ON d.Empresa = 'MAVI' " +
                        " AND d.Articulo = jd.Opcion AND ISNULL(d.SubCuenta, '') = ISNULL(jd.SubCuenta, '') " +
                        " WHERE jd.Articulo = '{0}' GROUP BY jd.Juego, jd.Renglon, jd.Opcion, jd.SubCuenta, a.Descripcion1 " +
                        " ORDER BY jd.Juego, jd.Renglon, jd.Opcion, jd.SubCuenta, a.Descripcion1", codart);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (!dr.HasRows)
                    return null;

                while (dr.Read())
                {
                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                    model.Juego = dr[0].ToString();
                    model.Articulo = dr[1].ToString();
                    model.Descripcion = dr[3].ToString();
                    model.Disponible = Convert.ToInt32(dr[4].ToString());

                    ListArtJuegoD.Add(model);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "   -Error funcion GetArtJuego");
            }
            finally
            {
                dr.Close();
            }

            return ListArtJuegoD;
        }


        public double GetPrice(string codart, int idventa, int renglon, bool redimir, int canal = 0,
            string condicion = "", int suc = 0, string Mov = "")
        {
            string _renglon = string.Empty;
            if (renglon == 0)
                _renglon = "null";
            else
                _renglon = renglon.ToString();

            int redimir_ = Convert.ToInt32(redimir);

            double valTemp = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format(" SELECT dbo.fnProprePrecio ({0},'{1}',{2},{3})", idventa, codart,
                    _renglon, redimir_);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                    if (dr[0].ToString().Length > 0)
                        valTemp = double.Parse(dr[0].ToString());
                    else
                        valTemp = 0;

                if ((valTemp >= 99999.99) & (canal == 34))
                {
                    string res = controller.ActualizaPrecios(canal, condicion, suc, codart, idventa, redimir, Mov);

                    if (res != "OK") MessageBox.Show(res, "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    //return valTemp;
                    dr.Close();

                    dr = sqlCommand.ExecuteReader();
                    while (dr.Read()) valTemp = double.Parse(dr[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error funcion GetPrice");
            }
            finally
            {
                dr.Close();
            }

            return valTemp;
        }

        public float GetPropreListaDFinal(string codart, int idventa, bool redimir)
        {
            float valTemp = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format(" SELECT dbo.fnProprePrecioID({0},'{1}',{2})", idventa, codart, redimir);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valTemp = float.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error funcion GetPrice");
            }
            finally
            {
                dr.Close();
            }

            return valTemp;
        }

        public int GetRenglon(string codart)
        {
            int val = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format("select Renglon from VentaD  WITH (NOLOCK) where Articulo='{0}'", codart);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (!dr.HasRows)
                    return 0;

                while (dr.Read()) val = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error funcion GetRenglon");
            }
            finally
            {
                dr.Close();
            }

            return val;
        }

        //obtiene precio y clave de la garantia para agregarla como un articulo mas
        public DM0312_MVentaDetalle GetGarantias(string codart, string canal, int iOpcion = 1, string sGarantia = "")
        {
            int canalInt = Convert.ToInt32(canal);
            string sQuery = string.Empty;
            if (canalInt == 11)
                return null;

            if (iOpcion == 1)
                sQuery = string.Format("select GarantiaAmpliada,Costo from Propreart  WITH (NOLOCK) where Art='{0}'",
                    codart, sGarantia);
            if (iOpcion == 2)
                sQuery = string.Format(
                    "select GarantiaAmpliada,Costo from Propreart  WITH (NOLOCK) where Art='{0}' AND garantiaampliada = '{1}'",
                    codart, sGarantia);


            DM0312_MVentaDetalle Garantia = new DM0312_MVentaDetalle();

            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (!dr.HasRows)
                    return null;

                while (dr.Read())
                {
                    Garantia.Articulo = dr[0].ToString();
                    Garantia.Precio = Convert.ToDouble(dr[1].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error funcion GetGarantias");
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            if ((Garantia.Articulo != null) & (Garantia.Articulo != string.Empty))
                return Garantia;
            return null;
        }

        #endregion

        #region Costo by Rodolfo

        public void GetTipoCosteo()
        {
            SqlDataReader dr = null;

            string query = "select TipoCosteo from EmpresaCfg  WITH (NOLOCK) where empresa='MAVI'";

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 100;
                    cmd.CommandText = query;

                    dr = cmd.ExecuteReader();
                }

                if (dr.HasRows)
                    while (dr.Read())
                        ClaseEstatica.TipoCosteo = dr[0].ToString().Trim();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntodeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public double ExecspVerCosto(int sucursal, string articulo, string MovUnidad)
        {
            // spVerCosto 26, 'MAVI', NULL, 'MABE00475', NULL, 'PIEZA', 'Promedio', 'PESOS', 1, @Precio=4599

            string name = "spVerCosto";

            double rest = 0;

            SqlDataReader dr = null;

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = name;
                    cmd.CommandTimeout = 100;

                    cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                    cmd.Parameters.Add("@Empresa", SqlDbType.Char).Value = "MAVI";
                    cmd.Parameters.Add("@Proveedor", SqlDbType.Char).Value = "";
                    cmd.Parameters.Add("@Articulo", SqlDbType.Char).Value = articulo;
                    cmd.Parameters.Add("@SubCuenta", SqlDbType.VarChar).Value = "";
                    cmd.Parameters.Add("@MovUnidad", SqlDbType.VarChar).Value = MovUnidad;
                    cmd.Parameters.Add("@Cual", SqlDbType.Char).Value = ClaseEstatica.TipoCosteo;
                    cmd.Parameters.Add("@MovMoneda", SqlDbType.Char).Value = "PESOS";
                    cmd.Parameters.Add("@MovTipoCambio", SqlDbType.Float).Value = 1;

                    dr = cmd.ExecuteReader();
                }

                if (dr.HasRows)
                    while (dr.Read())
                        rest = Convert.ToDouble(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntodeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }

        public List<string> GetTiposMov()
        {
            string query = "SELECT Mov FROM MovTipo  WITH (NOLOCK)"
                           + " WHERE CLAVE IN (SELECT Nombre "
                           + " FROM TablaStD WITH (NOLOCK) WHERE TablaSt = 'ACCESO CONSULTAR COSTOS')";

            SqlDataReader dr = null;

            List<string> res = new List<string>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 100;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;

                    dr = cmd.ExecuteReader();
                }

                if (dr.HasRows)
                    while (dr.Read())
                        res.Add(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntodeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return res;
        }

        #endregion


        #region DetalleVenta //Rodolfo

        public bool ArticulosRepetidos(List<DM0312_MVentaDetalle> list, bool edit = false)
        {
            list.RemoveAll(x => x.Descripcion == null);

            if (list.Count == 0)
                return false;

            if (!edit)
            {
                IEnumerable<DM0312_MVentaDetalle> item = list.Where(x => x.Juego != null);

                if (item.Count() == list.Count)
                    return false;

                IEnumerable<DM0312_MVentaDetalle> itemList = list.Where(x => x.Juego == null);

                if (itemList.Count() >= 1)
                    return true;
                return false;
            }

            if (list.Count > 1)
                return true;
            return false;
        }

        public void EliminarGarantiasRepetidas(DM0312_MVentaDetalle modelActual, ref List<DM0312_MVentaDetalle> listAct,
            bool tipo = false)
        {
            DM0312_MVentaDetalle modeloVacio = new DM0312_MVentaDetalle();
            listAct.RemoveAll(x => x.Articulo == null);

            if (!tipo)
            {
                IEnumerable<DM0312_MVentaDetalle> items = listAct.Where(x => x.Articulo_Ligado == modelActual.Articulo);

                listAct.Remove(modelActual);


                DM0312_MVentaDetalle garantias = new DM0312_MVentaDetalle();
                garantias = items.Where(x => x.Articulo.Contains("GARA")).FirstOrDefault();

                if (garantias != null)
                {
                    if (garantias.Cantidad != modelActual.Cantidad)
                    {
                        if (garantias.Cantidad - modelActual.Cantidad <= 0)
                            garantias.Cantidad = 1;
                        else
                            garantias.Cantidad = garantias.Cantidad - modelActual.Cantidad;

                        listAct.Remove(garantias);

                        listAct.RemoveAll(x => x.Articulo_Ligado == modelActual.Articulo);

                        DM0312_MVentaDetalle item = listAct.Where(x => x.Articulo_Ligado == garantias.Articulo)
                            .FirstOrDefault();

                        if (item != null)
                            //listAct.RemoveAll(x => x.Descripcion == null);
                            //garantias.Articulo_Ligado = item.Articulo;
                            //listAct.Add(garantias);
                            //listAct.Add(modeloVacio);
                            Remove(ref listAct, ref garantias, item.Articulo);
                    }
                    else
                    {
                        listAct.Remove(garantias);

                        listAct.RemoveAll(x => x.Articulo_Ligado == modelActual.Articulo);

                        //listAct.Add(modeloVacio);

                        //var item = listAct.Where(x => x.Articulo_Ligado == garantias.Articulo).FirstOrDefault();

                        //if (item != null)
                        //{
                        //    //listAct.RemoveAll(x => x.Descripcion == null);

                        //    //garantias.Articulo_Ligado = item.Articulo;
                        //    //listAct.Add(garantias);
                        //    //listAct.Add(modeloVacio);
                        //    Remove(ref listAct, ref garantias, item.Articulo);
                        //}
                    }
                }
                else
                {
                    listAct.RemoveAll(x => x.Articulo_Ligado == modelActual.Articulo);
                }
            }
            else
            {
                List<DM0312_MVentaDetalle> items = listAct.Where(x => x.Articulo == modelActual.Articulo_Ligado)
                    .ToList();

                listAct.Remove(modelActual);

                DM0312_MVentaDetalle garantias = new DM0312_MVentaDetalle();
                if (items.Count > 0) garantias = items.Where(x => x.Articulo.Contains("GARA")).FirstOrDefault();


                if (garantias.Articulo != null)
                {
                    if (garantias.Cantidad != modelActual.Cantidad)
                    {
                        if (garantias.Cantidad - modelActual.Cantidad <= 0)
                            garantias.Cantidad = 1;
                        else
                            garantias.Cantidad = garantias.Cantidad - modelActual.Cantidad;

                        listAct.Remove(garantias);

                        DM0312_MVentaDetalle item_ = listAct.Where(x => x.Articulo == garantias.Articulo_Ligado)
                            .FirstOrDefault();

                        if (item_ != null) Remove(ref listAct, ref garantias, item_.Articulo);
                    }
                    else
                    {
                        listAct.Remove(garantias);

                        //listAct.Add(modeloVacio);
                    }
                }
            }
        }

        private void Remove(ref List<DM0312_MVentaDetalle> listAct, ref DM0312_MVentaDetalle garantias, string item)
        {
            DM0312_MVentaDetalle modeloVacio = new DM0312_MVentaDetalle();

            listAct.RemoveAll(x => x.Descripcion == null);

            garantias.Articulo_Ligado = item;
            listAct.Add(garantias);

            listAct.Add(modeloVacio);
        }

        private void GarantiasRemove(ref List<DM0312_MVentaDetalle> listAct, DM0312_MVentaDetalle garantias,
            DM0312_MVentaDetalle modelActual)
        {
            if (garantias.Cantidad != modelActual.Cantidad)
            {
                if (garantias.Cantidad - modelActual.Cantidad <= 0)
                    garantias.Cantidad = 1;
                else
                    garantias.Cantidad = garantias.Cantidad - modelActual.Cantidad;

                listAct.Remove(garantias);

                DM0312_MVentaDetalle item_ = listAct.Where(x => x.Articulo == garantias.Articulo_Ligado)
                    .FirstOrDefault();

                if (item_ != null) Remove(ref listAct, ref garantias, item_.Articulo);
            }
        }

        #endregion


        #region TiendaDepartamental

        /// <summary>
        ///     Obtiene la categoria
        /// </summary>
        /// <param name="Clave">string</param>
        /// <returns>string[]</returns>
        /// Developer: Erika Perez
        /// Date: 30/08/17
        public string ObtenerCategoriaT(string Clave)
        {
            string cat = "";

            SqlCommand sqlCommand =
                new SqlCommand("SELECT top 1 Categoria FROM VentasCanalMAVI WITH (NOLOCK) WHERE id = @Clave",
                    ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
            sqlCommand.Parameters.AddWithValue("@Clave", Clave);

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        cat = dr[0].ToString();
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCategoriaT", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerCategoriaCanal, class: CDetalleVenta.cs");
            }

            return cat;
        }


        /// <summary>
        ///     Detectar las categorias que aplican para tarjeta departamental
        /// </summary>
        /// <returns></returns>
        public string TarjetaDep(string categoria)
        {
            string val = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = "SELECT top 1 categoria FROM CXCDAsignarTarjeta c WITH(NOLOCK) WHERE c.categoria ='" + categoria +
                    "' and  c.uen ='" + ClaseEstatica.Usuario.Uen + "' and usoventa='1' and ACTIVA=1";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = "SI";
                else
                    val = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TarjetaDep", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }


        /// <summary>
        ///     Detectar si el cliente cuenta con tarjeta departamental
        /// </summary>
        /// <returns></returns>
        public string NumTarj(string cliente)
        {
            string val = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = "select isnull(IdCatalogoTarjetas,0) IdCatalogoTarjetas FROM cte WITH(NOLOCK) WHERE cliente ='" +
                    cliente + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = dr[0].ToString();
                else
                    val = "0";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("NumTarj", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }


        /// <summary>
        ///     Detectar si el cliente cuenta con tarjeta departamental
        /// </summary>
        /// <returns></returns>
        public string VentasMenudeo(string cliente)
        {
            string val = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query =
                "select TOP 1 mov from venta WITH(NOLOCK) where mov in(select mov from MovTipo WITH(NOLOCK) where clave='vtas.f') and enviara in (3,7,76,11) and cliente ='" +
                cliente + "' ";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = dr[0].ToString();
                else
                    val = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VentasMenudeo", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }


        /// <summary>
        ///     Detectar las sucursales que no aplican para tarjeta departamental
        /// </summary>
        /// <returns></returns>
        public string SucursalesSinTarjeta()
        {
            string val = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query =
                "SELECT top 1 nombre FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='SUCURSALES TARJETA DEPARTAMENTAL' and  nombre ='" +
                ClaseEstatica.Usuario.sucursal + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        val = "SI";
                else
                    val = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalesSinTarjeta", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return val;
        }

        #endregion


        #region -Die

        /// <summary>
        ///     Metodo encargado de validar si la sucursal activa puede activar el check die.
        /// </summary>
        /// <returns></returns>
        public bool ValidarSucursalDie()
        {
            bool bSucursalPuede = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede FROM tablastd WITH(NOLOCK) WHERE tablast='ACCESO DIE' AND VALOR = 1 AND Nombre = {0}",
                    ClaseEstatica.Usuario.sucursal);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bSucursalPuede = true;
                        else
                            bSucursalPuede = false;
                else
                    bSucursalPuede = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarSucursalDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return bSucursalPuede;
        }

        /// <summary>
        ///     Metodo encargado si el canal de venta puede hacer visible el check die
        /// </summary>
        /// <param name="iCanal">Canal de venta</param>
        /// <returns>retorna true si puede colocar visible el check, false si no se puede hacer visible</returns>
        public bool validarCanalVentaDie(int iCanal)
        {
            bool bPuedeCanal = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede from TablaStD WITH(NOLOCK) where tablast = 'CANALVENTADIE' AND VALOR = 1 AND Nombre = '{0}'",
                    iCanal);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bPuedeCanal = true;
                        else
                            bPuedeCanal = false;
                else
                    bPuedeCanal = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarCanalVentaDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return bPuedeCanal;
        }

        /// <summary>
        ///     Metodo encargado de validar si el articulo pertenece a la linea credilana si es asi se hace visible el check die
        /// </summary>
        /// <param name="sArticulo">Articulo a validar si es de la linea credilana y si es un dine</param>
        /// <returns>retorna true si cumple las condiciones y puede hacer visible el check de lo cantrario retorna false</returns>
        public bool validarArticuloDie(string sArticulo)
        {
            bool bArticuloPuede = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede FROM art WHERE Articulo = '{0}' AND Linea = 'CREDILANA'", sArticulo);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bArticuloPuede = true;
                        else
                            bArticuloPuede = false;
                else
                    bArticuloPuede = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarArticuloDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return bArticuloPuede;
        }

        #endregion

        #region -STP

        public bool ValidarSucursalSTP()
        {
            bool bSucursalPuede = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede FROM tablastd WITH(NOLOCK) WHERE tablast='ACCESO STP' AND VALOR = 1 AND Nombre = {0}",
                    ClaseEstatica.Usuario.sucursal);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bSucursalPuede = true;
                        else
                            bSucursalPuede = false;
                else
                    bSucursalPuede = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return bSucursalPuede;
        }

        public bool validarCanalVentaSTP(int iCanal)
        {
            bool bPuedeCanal = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede from TablaStD WITH(NOLOCK) where tablast = 'CANALVENTADIE' AND VALOR = 1 AND Nombre = '{0}'",
                    iCanal);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bPuedeCanal = true;
                        else
                            bPuedeCanal = false;
                else
                    bPuedeCanal = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bPuedeCanal;
        }

        /// <summary>
        ///     Metodo encargado de validar si el articulo pertenece a la linea credilana si es asi se hace visible el check die
        /// </summary>
        /// <param name="sArticulo">Articulo a validar si es de la linea credilana y si es un dine</param>
        /// <returns>retorna true si cumple las condiciones y puede hacer visible el check de lo cantrario retorna false</returns>
        public bool validarArticuloSTP(string sArticulo)
        {
            bool bArticuloPuede = false;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            try
            {
                sQuery = string.Format(
                    "SELECT COUNT(*) AS Puede FROM art WHERE Articulo = '{0}' AND Linea = 'CREDILANA'", sArticulo);
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Puede"].ToString()) == 1)
                            bArticuloPuede = true;
                        else
                            bArticuloPuede = false;
                else
                    bArticuloPuede = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bArticuloPuede;
        }

        #endregion

        #region -FlujoMonedero

        //-FlujoMonedero
        public bool checarPedidoContado(int canal)
        {
            string query =
                string.Format(@"SELECT Cadena FROM ventascanalmavi with(nolock) where Categoria='CONTADO' and id={0}",
                    canal);

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = null;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows) return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("checarPedidoContado", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }


        //-FlujoMonedero
        public bool checarAnticipos(int id)
        {
            string query = string.Format(@"select COUNT(V.ID) anticipos
                From Venta V With(Nolock)
                Join Cxc C With(Nolock) ON LEFT(C.Mov,8) in ('Anticipo','Enganche') and V.Mov+' '+V.MovID=C.Referencia and C.Estatus <> 'Cancelado'
                Where  V.ID={0} and  V.Mov='Pedido' and V.Estatus='Pendiente'", id);

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = null;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        if (dr.Read())
                            if (int.Parse(dr[0].ToString()) > 0)
                                return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("checarAnticipos", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }


        //-FlujoMonedero
        public bool puedeAfectarPedidoContado(int id)
        {
            string query = string.Format(@"select COUNT(*)
                         res From (
                        select (V.Importe+V.Impuestos) Venta, sum(ISnull(c.Importe,0)+Isnull(c.Impuestos,0)+isnull(m.importe,0))+1  Anticipo
                        From Venta V With(Nolock)
                        Left Join Cxc C With(Nolock) ON LEFT(C.Mov,8) in ('Anticipo','Enganche') and V.Mov+' '+V.MovID=C.Referencia and C.Estatus = 'CONCLUIDO'
						left join TarjetaSerieMovMAVI m with(nolock) on v.ID = m.ID
                        Where  V.ID={0} and  V.Mov='Pedido' and V.Estatus='Pendiente'
						group by V.Importe,V.Impuestos, m.Importe
                        ) T 
                        Where Anticipo >= Venta", id);


            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = null;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        if (dr.Read())
                            if (dr[0].ToString() == "1")
                                return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("puedeAfectarPedidoContado", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }


        //-FlujoMonedero
        public string devolucionAnticipos(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SpVTASDevAnticipos", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = ClaseEstatica.Usuario.Usser;
                    cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = ClaseEstatica.Usuario.Sucursal;
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;

                    SqlDataReader dr = null;
                    cmd.CommandTimeout = 300;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            return dr[0].ToString().Replace("<BR>", Environment.NewLine);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("devolucionAnticipos", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return "";
        }


        //-FlujoMonedero
        public bool ExcluirSucursales(int sucursal)
        {
            string query =
                string.Format(
                    @"select top 1 numero from tablanumd with(nolock) where tablanum='ExcluirSucursalesFlujoMonedero' and Numero={0}",
                    sucursal);

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = null;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows) return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ExcluirSucursales", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }

        #endregion

        #region //-921

        private DataTable dt = new DataTable();

        /// <summary>
        ///     Metodo encargado de obtener las observaciones para ventas mayoreo
        /// </summary>
        /// <returns>Una lista con las observaciones para mayoreo</returns>
        public List<string> obtenerObservaciones()
        {
            List<string> listaObservaciones = new List<string>();

            dt = new DataTable();
            try
            {
                string sQuery = "SELECT Observacion FROM Observacion with(nolock) where modulo= 'VTAS'";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        listaObservaciones.Add(item["Observacion"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaObservaciones;
        }

        /// <summary>
        ///     Metodo encargado de actualizar la referencia de la venta
        /// </summary>
        public void actualizarDatosCliente(int iId, string sCorreo, string sTelefonoMovil, string sTelefonoParticular)
        {
            dt = new DataTable();

            try
            {
                string sQuery =
                    "UPDATE Venta WITH(ROWLOCK) SET CorreoCliente = @Correo, TelefonoMovil = @TelMovil, TelefonoParticular = @TelParticular WHERE ID = @ID; SELECT @@RowCount";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Correo", sCorreo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@TelMovil", sTelefonoMovil)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@TelParticular", sTelefonoParticular)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public List<string> obtenerInformacionCliente(int iId)
        {
            List<string> listaInformacionCliente = new List<string>();
            dt = new DataTable();
            try
            {
                string sQuery = @"SELECT
                                  ISNULL(Observaciones, '') AS Observaciones,
                                  ISNULL(Comentarios, '') AS Comentarios,
                                  ISNULL(causa, '') AS causa,
                                  ISNULL(ServicioTipo, '') AS ServicioTipo,
                                  CONVERT(varchar,AfectaComisionMavi) AS AfectaComisionMavi,
                                  ISNULL(AgenteServicio, '') AgenteServicio,
                                  ISNULL(Condicion,'') AS Condicion,
                                  ISNULL(FormaEnvio,'') AS FormaEnvio,
                                  ISNULL(NoCtaPago,'') AS NoCtaPago,
                                  ISNULL(FacDesgloseIva,'') AS FacDesgloseIva
                                FROM Venta WITH(NOLOCK)
                                WHERE ID = @Id;";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                    {
                        listaInformacionCliente.Add(item["Observaciones"].ToString());
                        listaInformacionCliente.Add(item["Comentarios"].ToString());
                        listaInformacionCliente.Add(item["causa"].ToString());
                        listaInformacionCliente.Add(item["ServicioTipo"].ToString());
                        listaInformacionCliente.Add(item["AfectaComisionMavi"].ToString());
                        listaInformacionCliente.Add(item["AgenteServicio"].ToString());
                        listaInformacionCliente.Add(item["Condicion"].ToString());
                        listaInformacionCliente.Add(item["FormaEnvio"].ToString());
                        listaInformacionCliente.Add(item["NoCtaPago"].ToString());
                        listaInformacionCliente.Add(item["FacDesgloseIva"].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaInformacionCliente;
        }

        public void eliminarDescuento(int iId, string sArticulo, int iRenglon)
        {
            try
            {
                string sQuery =
                    "UPDATE VentaD WITH(ROWLOCK) SET UsuarioDescuento = null,PrecioAnterior = null WHERE Id = @Id AND Articulo = @Articulo AND Renglon = @Renglon ";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Articulo", sArticulo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Renglon", iRenglon)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void eliminarUsuarioDescuento(int iId, int iRenglon)
        {
            //DELETE FROM AutorizacionesUsuarioDescuentoMavi WHERE VtaId = 2 AND VtaRenglon = 1
            try
            {
                string sQuery =
                    "DELETE FROM AutorizacionesUsuarioDescuentoMavi WHERE VtaId = @Id AND VtaRenglon = @Renglon";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Renglon", iRenglon)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region 1030/1061

        /**
         * <summary>
         *     Busqueda de Codigo Recomendador Dima por codigo de Codigo de cliente
         * </summary>
         * <param name="Codigo">Codigo alfanumerico de Dima</param>
         * <returns>
         *     Lista con el nombre y direccion del cliente
         * </returns>
         * Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
         */
        public string CteCodigoRecomendadorDima(string sCliente, int iCanal)
        {
            dt = new DataTable();
            string sCodigo = string.Empty;

            try
            {
                string sQuery =
                    "SELECT ISNULL(CodigoRecomendado,'') AS CodigoRecomendador FROM cteenviara with(nolock)  where Cliente = @Cliente AND id = @Canal";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    SqlParameter[] pars =
                    {
                        new SqlParameter("@Cliente", sCliente)
                        {
                            SqlDbType = SqlDbType.VarChar
                        },
                        new SqlParameter("@Canal", iCanal)
                        {
                            SqlDbType = SqlDbType.Int
                        }
                    };

                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        sCodigo = row["CodigoRecomendador"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sCodigo;
        }

        public bool clienteTieneFacturaConcluidaCanal3o7(string Cliente, int Canal)
        {
            try
            {
                string sQuery =
                    @"IF EXISTS(SELECT TOP 1 EnviarA FROM Venta WITH (NOLOCK) WHERE Cliente = @Cliente AND mov in ('FACTURA', 'FACTURA VIU') AND EnviarA = @Canal AND Estatus = 'concluido') BEGIN SELECT 1 END ELSE BEGIN SELECT 0 END";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", Cliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Canal", Canal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            if (dr.Read())
                                if (int.Parse(dr[0].ToString()) == 1)
                                    return true;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }

        /**
         * <summary>
         *     Busqueda de clientes por codigo de Codigo Recomendador Dima
         * </summary>
         * <param name="CodigoRecomendadorDima">Codigo alfanumerico de Dima</param>
         * <returns>
         *     Lista con el nombre y direccion del cliente
         * </returns>
         * Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
         */
        public List<string> encontrarCteCodigoDimr(string CodigoRecomendadorDima)
        {
            string query =
                "Select top 1  Nombre, Direccion + ' ' + DireccionNumero + ' ' + Case when DireccionNumeroInt is null or LTRIM(DireccionNumeroInt) = '' then '' else 'Int ' + DireccionNumeroInt end As Direccion from CteEnviarA with (nolock) where CodigoRecomendador = '" +
                CodigoRecomendadorDima + "'";
            SqlDataReader dataReader = null;

            try
            {
                List<string> DatosCliente = new List<string>();
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    dataReader = sqlCommand.ExecuteReader();

                    while (dataReader.Read())
                    {
                        DatosCliente.Add(dataReader.GetString(0));
                        DatosCliente.Add(dataReader.GetString(1));
                    }
                }

                return DatosCliente;
            }
            catch (Exception ex)
            {
                if (ex.Source != null)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }

                return null;
            }
        }

        public List<string> encontrarCteCodigoMenudeo(string CodigoRecomendadorDima, string Cliente)
        {
            // 1442
            string query = @"Select Top 1  
                c.Nombre , 
                C.Direccion + ' ' + isnull(c.DireccionNumero, '') +  
                case when isnull (C.DireccionNumeroInt,'') = ''  then '' else 'NumInt '+C.DireccionNumeroInt end as Direccion  
              from CREDIDCodigoRecomendador cr
              with (nolock) join cte c
              on c.Cliente = cr.Cliente
            where Codigo Collate Latin1_General_CS_AS = @Codigo
            and cr.Cliente <> @Cliente";
            SqlDataReader dataReader = null;

            try
            {
                List<string> DatosCliente = new List<string>();
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.Add("@Codigo", CodigoRecomendadorDima);
                    sqlCommand.Parameters.Add("@Cliente", Cliente);

                    dataReader = sqlCommand.ExecuteReader();

                    while (dataReader.Read())
                    {
                        DatosCliente.Add(dataReader.GetString(0));
                        DatosCliente.Add(dataReader.GetString(1));
                    }
                }

                return DatosCliente;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        public string validaCodigoMenudeo(string CodigoRecomendadorDima, string Cliente)
        {
            string query = @"
            if EXISTS (Select 1 from CREDIDCodigoRecomendador with (nolock) where codigo Collate Latin1_General_CS_AS = @Codigo)
              BEGIN
                Select
                  case
                    when FechaCanjeado is not null Then 'Código ya canjeado'
                    else Case
                           When isnull(FechaVencimiento, '1950/01/01') < getdate() then 'Código Vencido'
                           else
                             case when @Cliente = Cliente then 'Este cliente no puede canjear el código' else 'OK' end
                      end
                    end
                from CREDIDCodigoRecomendador cr with (nolock)
                where Codigo Collate Latin1_General_CS_AS = @Codigo
              END
            ELSE
              BEGIN
                Select 'Código no encontrado o incorrecto'
              END";
            SqlDataReader dataReader;

            string mensaje = null;

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.Add("@Codigo", CodigoRecomendadorDima);
                    sqlCommand.Parameters.Add("@Cliente", Cliente);

                    dataReader = sqlCommand.ExecuteReader();

                    while (dataReader.Read()) mensaje = dataReader.GetString(0);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return mensaje;
        }


        public string validaCodigoMenudeoUEN(string CodigoRecomendadorDima, int Canal)
        {
            string query = @"
            if NOT EXISTS(Select 'Correcto'
                from CREDIDCodigoRecomendador CR with (nolock)
                       Join VentasCanalMavi VC on isnull(VC.UEN, -2) = isnull(CR.UEN, -1)
                  and VC.id = @CanalVenta
                where Codigo Collate Latin1_General_CS_AS = @Codigo)
              BEGIN
                Select 'Código no encontrado y/o incorrecto'
              end
            ELSE
              BEGIN
                Select 'OK'
              END";
            SqlDataReader dataReader;

            string mensaje = null;

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.Add("@Codigo", CodigoRecomendadorDima);
                    sqlCommand.Parameters.Add("@CanalVenta", Canal);

                    dataReader = sqlCommand.ExecuteReader();

                    while (dataReader.Read()) mensaje = dataReader.GetString(0);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return mensaje;
        }


        public bool validarCodigoYCanal(string sCodigoRecomendador, int iCanal)
        {
            bool bCanalValido = false;
            try
            {
                string sQuery = "select id From cteenviara where codigorecomendador = @Codigo and id = @Canal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigoRecomendador)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Canal", iCanal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bCanalValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bCanalValido;
        }

        // 1442 Buscar Codigo Recomendado en la base de ditas y ver que no este vencido
        public bool CodigoRecomendadoExistente(string Codigo, string Cliente)
        {
            bool codigoValido = false;
            try
            {
                string sQuery = @"Select 'Correcto'
                from CREDIDCodigoRecomendador with (nolock)
                where (isnull(FechaVencimiento, '1950-01-01') > GETDATE())
                  and Codigo Collate Latin1_General_CS_AS = @Codigo
                  and Cliente <> @Cliente
                ";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", Codigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", Cliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        codigoValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return codigoValido;
        }

        public bool validarCodigoRecomendador(string sCodigo, int iId)
        {
            bool bExiste = false;
            try
            {
                string sQuery =
                    "select id from cteenviara with(nolock) where codigorecomendador = @Codigo and id = @id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bExiste = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExiste;
        }

        public string obtenerDatosDimaRecomendador(string sCodigo, int iCanaVenta)
        {
            string sDatos = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select Nombre ,Direccion+ ' ' + DireccionNumero+ ' - ' + Colonia+ ' - ' + Delegacion+ ' - ' + estado AS Direccion from cteenviara where codigorecomendador = @Codigo and id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Id", iCanaVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sDatos = item["Nombre"] + "|" + item["Direccion"];
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sDatos;
        }

        public void actualizarCodigoDima(string sCliente, string sCodigo, int sCanal)
        {
            try
            {
                string sQuery =
                    "UPDATE cteenviara WITH(ROWLOCK) SET CodigoRecomendado = @Codigo where Cliente = @Cliente AND ID = @id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@id", sCanal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public bool actualizarCodigoMenudeo(string sCliente, string sCodigo, int sCanal)
        {
            bool respuesta = true;

            try
            {
                string sQuery =
                    "UPDATE cteenviara WITH(ROWLOCK) SET CodigoRecomendado = @Codigo where Cliente = @Cliente AND ID = @id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@id", sCanal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                respuesta = false;
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return respuesta;
        }

        public bool actualizarCanjeoCodigoMenudeo(string sCodigo)
        {
            bool respuesta = true;

            try
            {
                string sQuery =
                    "update CREDIDCodigoRecomendador set FechaCanjeado = getdate() where Codigo Collate Latin1_General_CS_AS = @Codigo";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Codigo", sCodigo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                respuesta = false;
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return respuesta;
        }

        #endregion

        #region //-Mops

        public bool validarArticulo(string sArticulo)
        {
            bool bCorrecto = false;

            try
            {
                string sQuery =
                    "select Articulo from art with(nolock) where Linea = 'CREDILANA' AND Articulo = @Articulo";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Articulo", sArticulo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bCorrecto = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bCorrecto;
        }


        public List<mopsModel> obtenerInformacionMops(string sCliente)
        {
            List<mopsModel> listaMops = new List<mopsModel>();
            dt = new DataTable();
            try
            {
                string sQuery = "SPVTASObtenerMopsCliente";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                DateTime dtFechaActual = c.FechaActualServidor();
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 999999;
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        listaMops.Add(new mopsModel
                        {
                            iId = int.Parse(item["id"].ToString()),
                            sCliente = item["cliente"].ToString(),
                            sMov = item["mov"].ToString(),
                            sMovId = item["movid"].ToString(),
                            dtFechaEmision = DateTime.Parse(item["fechaemision"].ToString()),
                            dtVencimineto = DateTime.Parse(item["vencimiento"].ToString()),
                            iCanalVenta = int.Parse(item["clienteenviara"].ToString()),
                            iNumeroDocumentos = int.Parse(item["danumerodocumentos"].ToString()),
                            iUen = int.Parse(item["uen"].ToString()),
                            dSaldo = double.Parse(item["saldo"].ToString()),
                            dtUltimaConclusion = DateTime.Parse(item["ultimaconclusion"].ToString()),
                            dtFechaPrimerPago = item["fechaprimerabono"].ToString().Length > 0
                                ? DateTime.Parse(item["fechaprimerabono"].ToString())
                                : dtFechaActual
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaMops;
        }

        public bool validaRs(int iUen, int iCanal, string sMov)
        {
            bool bExisteId = false;

            try
            {
                string sQuery =
                    "SELECT Id FROM RS_PARA WITH(NOLOCK) WHERE Para = 'MeseMoviNMop' AND UEN = @UEN AND Plaz = @Canal AND ValoAlfa = @Mov";

                SqlParameter[] pars =
                {
                    new SqlParameter("@UEN", iUen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Canal", iCanal)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Mov", sMov)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bExisteId = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExisteId;
        }

        public double obtenerRs(int iUen, int iCanal, string sMov)
        {
            double dValor = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT MIN(ValoNume) AS Valor FROM RS_PARA WITH(NOLOCK) WHERE Para = 'MeseMoviNMop' AND UEN = @UEN AND Plaz = @Canal AND ValoAlfa = @Mov";

                SqlParameter[] pars =
                {
                    new SqlParameter("@UEN", iUen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Canal", iCanal)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Mov", sMov)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        dValor = double.Parse(dataRow["Valor"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dValor;
        }

        public int obtenerDocumentos(string sCondicion)
        {
            int iNumeroDocumentos = 0;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT DANumeroDocumentos FROM condicion WITH(NOLOCK) where condicion = @Condicion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Condicion", sCondicion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        iNumeroDocumentos = int.Parse(dataRow["DANumeroDocumentos"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return iNumeroDocumentos;
        }

        public string obtenerUltimoEvento(int iId)
        {
            string sEvento = string.Empty;
            dt = new DataTable();
            try
            {
                //string sQuery = "select TOP 1 CONCAT(clave,'|',ISNULL(Evento, '')) AS Clave  from movbitacora WITH(NOLOCK) where modulo = 'vtas' and id = @ID /*AND Usuario <> @Usuario*/ order by id desc";
                string sQuery =
                    "select TOP 1 CONCAT(clave,'|',ISNULL(Evento, '')) AS Clave  from movbitacora WITH(NOLOCK) where modulo = 'vtas' and id = @ID order by id desc";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        sEvento = dataRow["Clave"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sEvento;
        }

        public string ultimoEventoUsuarioActivo(int iId)
        {
            string sEvento = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select TOP 1 Clave  from movbitacora WITH(NOLOCK) where modulo = 'vtas' and id = @ID AND Usuario = @Usuario order by id desc";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Usuario", ClaseEstatica.Usuario.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        sEvento = dataRow["Clave"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sEvento;
        }

        public List<double> obtenerMontosClienteCasa(string sTipoCliente, int iCanalVenta, int iPlazo, int iMops)
        {
            List<double> listaDatos = new List<double>();
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT ImportePorPolitica FROM CREDIDLimitePrestamosCasa WITH(NOLOCK) WHERE TipoDeCliente = @TipoCliente  and CanalDeVenta = @CanalVenta AND PlazoEje = @Plazo AND MopsMinimosRequeridos <= @Mops";

                SqlParameter[] pars =
                {
                    new SqlParameter("@TipoCliente", sTipoCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@CanalVenta", iCanalVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Plazo", iPlazo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Mops", iMops)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        listaDatos.Add(double.Parse(dataRow["ImportePorPolitica"].ToString()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaDatos;
        }

        public List<double> obtenerMontosPoliticas(string sTipoCliente, int iCanalVenta, int iPlazo,
            string sTipoPolitica)
        {
            List<double> listaDatos = new List<double>();
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT TotalPrestamo FROM CREDIDLimitePrestamosPolitica WITH(NOLOCK) WHERE TipoDeCliente = @TipoCliente  and CanalDeVenta = @CanalVenta AND PlazoEje = @Plazo AND TipoDePolitica = @TipoDePolitica";

                SqlParameter[] pars =
                {
                    new SqlParameter("@TipoCliente", sTipoCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@CanalVenta", iCanalVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Plazo", iPlazo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@TipoDePolitica", sTipoPolitica)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        listaDatos.Add(double.Parse(dataRow["TotalPrestamo"].ToString()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaDatos;
        }

        public string obtenerTipoCredito(string sTipoCliente)
        {
            string sTipoCredito = string.Empty;
            dt = new DataTable();
            try
            {
                /*string sQuery = "SELECT " +
                    "ISNULL(dm.tipoCredito, '') AS tipoCredito " +
                    "FROM cte c WITH(NOLOCK) " +
                    "INNER JOIN DM0299Tipodecliente dm WITH(NOLOCK) " +
                    "ON c.TipoCredito = dm.ID " +
                    "WHERE c.Cliente = @Cliente";*/

                string sQuery =
                    "SELECT ISNULL(Credito,'') AS tipoCredito from Cte with(nolock) where Cliente = @Cliente";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sTipoCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow dataRow in dt.Rows)
                        sTipoCredito = dataRow["tipoCredito"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sTipoCredito;
        }

        public string obtenerCategoriaVenta(int iCanal)
        {
            string sCategoria = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery = "select Categoria from ventascanalmavi where id = @Canal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Canal", iCanal)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sCategoria = item["Categoria"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sCategoria;
        }

        public string obtenerTipoVenta(string sCliente)
        {
            string sTipoCliente = "Nuevo";
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT top 1 mavitipoventa FROM Venta where Cliente = @Cliente and Enviara = 76 and mavitipoventa is not null order by id desc";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sTipoCliente = item["mavitipoventa"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sTipoCliente;
        }

        #endregion

        #region //-1120

        public List<string> llenarCondicionesDima()
        {
            dt = new DataTable();
            List<string> listaCondiciones = new List<string>();
            try
            {
                string sQuery = "SELECT Condicion FROM CREDICCondicion WITH(NOLOCK)";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaCondiciones.Add(row["Condicion"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaCondiciones;
        }

        public List<string> llenarCondicionesTipoDima(string sTipoDima)
        {
            dt = new DataTable();
            List<string> listaCondiciones = new List<string>();
            try
            {
                string sQuery = @"select c.Condicion from COMSCConfiguracionCondicionDIMA cd WITH(NOLOCK)
                                JOIN Condicion c WITH(NOLOCK)
                                ON cd.Condicion = c.IdCondicion
                                WHERE cd.TipoDima = @TipoDima";

                SqlParameter[] pars =
                {
                    new SqlParameter("@TipoDima", sTipoDima)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaCondiciones.Add(row["Condicion"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaCondiciones;
        }

        public bool validarVentaDima(float fMonto, string sCondicion)
        {
            bool bValido = false;
            try
            {
                string sQuery =
                    "select 1 AS Existe from CREDICCondicion with(nolock) where @Monto between Importeminimo and importemaximo AND Condicion = @Condicion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Monto", fMonto)
                    {
                        SqlDbType = SqlDbType.Money
                    },
                    new SqlParameter("@Condicion", sCondicion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bValido;
        }

        public string obtenerMontos(string sCondicion)
        {
            string sMontos = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select Importeminimo,importemaximo from CREDICCondicion with(nolock) where Condicion = @Condicion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Condicion", sCondicion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sMontos = item["Importeminimo"] + "|" + item["importemaximo"];
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sMontos;
        }

        #endregion


        #region //-1670

        /// <summary>
        ///     metodo encargado de obtener el monto de monedero que dara un articulo
        /// </summary>
        /// <param name="iIdVenta">id de la venta</param>
        /// <param name="sArticulo">articulo al cual se le calculara el monedero</param>
        /// <param name="dPrecio">Precio del articulo</param>
        /// <param name="iCantidadArt">cantidad de articulos</param>
        /// <returns></returns>
        public double obtenerMontoMonedero(int iIdVenta, string sArticulo, double dPrecio, int iCantidadArt)
        {
            double dMontoMonedero = 0;
            dt = new DataTable();

            try
            {
                string sQuery =
                    "SELECT dbo.FNVTASCalcularMonedero(@Id, @ArtEntrada, @PrecioEntrada, @CantidadEntrada) AS Monedero";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@ArtEntrada", sArticulo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@PrecioEntrada", dPrecio)
                    {
                        SqlDbType = SqlDbType.Float
                    },
                    new SqlParameter("@CantidadEntrada", iCantidadArt)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        dMontoMonedero = double.Parse(row["Monedero"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }


            return dMontoMonedero;
        }

        //1709
        public DataTable ObtenerBonificacionPagoInmediato(Abono Abono)
        {
            dt = new DataTable();

            try
            {
                string sQuery = @"SELECT
                                    C.Condicion,
                                    ISNULL(C.DiasVencimiento, 0) AS DiasVencimiento,
                                    ISNULL(C.DANumeroDocumentos,0) AS DANumeroDocumentos,
                                    C.DAPeriodo
                                  FROM Condicion AS C WITH(NOLOCK)
                                  WHERE C.Condicion = @Condicion";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Condicion", Abono.Condicion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dt;
        }

////////////////////METODO PARA TRAER LA BONIFICACION EN EL TIPO DE CLEINTE Y EL ARTICULO///////////////////////////
        // public DataTable PorcentajeBonif(Model.Abono Abono)
        public DataTable PorcentajeBFC(int iIdVenta, string iTipoVenta, List<AbonoDetalle> sArticulo)
        {
            // List<AbonoDetalle> sArticulos = new List<AbonoDetalle>();
            string idArticulos = string.Join(",", sArticulo.Select(x => x.Articulo).ToList());
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT dbo.FnVTASCalculaPorcBonifPP(@IdMovimiento,@TipoVenta,@Articulos) AS Bonifica";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@IdMovimiento", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@TipoVenta", iTipoVenta)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Articulos", idArticulos)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dt;
        }

////////////////////METODO PARA TRAER LA BONIFICACION EN EL TIPO DE CLEINTE Y EL ARTICULO///////////////////////////
        public DataTable ObtenerPrecioPPArticulos(string Condicion, string TipoCliente, int Sucursal, int Uen,
            string ListaVentaDetalle)
        {
            dt = new DataTable();

            try
            {
                string sQuery = @"SELECT
                                      P.ARTICULO,
                                      MIN(P.PRECIO) AS PrecioTN,
                                      MIN(ISNULL(G.PRECIO, 0)) AS PrecioTNGarantia,
                                      MIN(ISNULL(IIF(@TipoCliente='Casa',P.PrecioPP,P.PrecioPPCN), 0)) AS PrecioTP,
                                      MIN(ISNULL(IIF(@TipoCliente='Casa',G.PrecioPP,G.PrecioPPCN), 0)) AS PrecioTPGarantia
                                    FROM PROPRELISTADFINAL P WITH (NOLOCK)
                                    INNER JOIN Condicion C WITH (NOLOCK)
                                      ON P.Condicion = C.PROPREGrupo
                                    LEFT JOIN (SELECT
                                      G1.ARTICULO,
                                      G1.GARANTIA,
                                      PG.PRECIO,
                                      PG.PRECIOPP,
                                      PG.ABONOPP,
                                      C.CONDICION,
                                      PG.ABONO,
                                      PG.PrecioPPCN,
                                      pg.AbonoPPCN
                                    FROM PROPREARTGARANTIA G1 WITH (NOLOCK)
                                    INNER JOIN PROPRELISTADFINAL PG WITH (NOLOCK)
                                      ON G1.GARANTIA = PG.ARTICULO
                                    INNER JOIN Condicion C WITH (NOLOCK)
                                      ON PG.Condicion = C.PROPREGrupo
                                    WHERE
                                    PRECIOPP IS NOT NULL
                                    AND ABONOPP IS NOT NULL
                                    AND SUCURSAL NOT IN ('41', '90')
                                    AND C.NivelAcceso = '(Especifico)') G
                                      ON G.ARTICULO = P.ARTICULO
                                      AND G.CONDICION = C.CONDICION
                                    LEFT JOIN TablaStD std WITH (NOLOCK)
                                      ON std.TablaSt = 'CONDICIONES SELP PRECIO LLENO'
                                      AND std.Nombre = C.condicion
                                    WHERE C.NivelAcceso = '(Especifico)'
                                    AND SUCURSAL NOT IN ('41', '90')
                                    AND Sucursal = @Sucursal
                                    AND UEN = @UEN
                                    AND C.CONDICION = @Condicion
                                    AND P.ARTICULO IN ( "
                                + ListaVentaDetalle
                                + " ) GROUP BY P.ARTICULO";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@TipoCliente", TipoCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Condicion", Condicion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Sucursal", Sucursal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Uen", Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dt;
        }

        public int validarNotificacion()
        {
            dt = new DataTable();
            int iNotificaciones = 0;
            try
            {
                string sQuery =
                    "SELECT Count(IdVenta) AS Total FROM CREDIDNotificacionAnalista WITH(NOLOCK) WHERE Analista = @Usuario";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Usuario", ClaseEstatica.Usuario.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                foreach (DataRow item in dt.Rows) iNotificaciones = int.Parse(item["Total"].ToString());
            }
            catch (Exception ex)
            {
            }

            return iNotificaciones;
        }

        #endregion

        #region //-1592

        public bool acutalizarTransferenciaStp(bool bEstatus, int iIdVenta)
        {
            bool bActualizo = false;
            dt = new DataTable();

            try
            {
                string sQuery = "UPDATE Venta WITH(ROWLOCK) SET TransferenciaStp = @Valor WHERE Id = @Id";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Valor", bEstatus)
                    {
                        SqlDbType = SqlDbType.Bit
                    },
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        bActualizo = bool.Parse(row["Monedero"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bActualizo;
        }

        public string obtenerCuentaClave(string sCliente)
        {
            dt = new DataTable();
            string sCuentaClabe = string.Empty;
            try
            {
                string sQuery = @"SELECT
                                    ISNULL(c.ClabeCuenta, '') + '|' + conf.Participante AS Cuenta
                                FROM cte c WITH(NOLOCK)
                                JOIN CREDICConfiguracionSTP conf WITH(NOLOCK)
                                    ON SUBSTRING(c.ClabeCuenta, 1, 3) = SUBSTRING(conf.Clave,3,3)
                                WHERE c.Cliente = @Cliente
                                AND conf.TipoConfiguracion = 'INSTITUCIONESUC'";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        sCuentaClabe = row["Cuenta"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return sCuentaClabe;
        }

        public string obtenerCuentaTarjeta(string sCliente)
        {
            dt = new DataTable();
            string sCuentaClabe = string.Empty;
            try
            {
                string sQuery = @"SELECT
                                    ISNULL(c.ClabeCuenta, '') + '|' + c.Banco AS Cuenta
                                FROM cte c WITH(NOLOCK)
                                WHERE c.Cliente = @Cliente";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        sCuentaClabe = row["Cuenta"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return sCuentaClabe;
        }

        #endregion
    }
}