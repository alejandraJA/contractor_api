﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_CAnexoCta
    {
        public List<DM0312_MAnexoCta> GetFotos(string Cliente)
        {
            List<DM0312_MAnexoCta> ListaDirecciones = new List<DM0312_MAnexoCta>();

            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                //query = "SELECT IDR,Direccion,Alta,Cuenta FROM AnexoCta WITH(NOLOCK) WHERE Tipo = 'Imagen' AND";
                //query = query + " Nombre LIKE '%Foto%' AND Rama = 'CXC' AND ISNULL(Direccion,'')<>''";
                //query = query + " AND Cuenta='" + Cliente + "'";
                query = string.Format(
                    "SELECT ID_EXTERNO IDR,documento,FECHA Alta,CLAVE Cuenta FROM [AdminDoc].[dbo].[MAVI_DOC_CTE] WITH(NOLOCK)"
                    + " INNER JOIN [SID].[dbo].[SHM_BURO_CTED] WITH(NOLOCK) ON ID_EXTERNO=IdPrimario "
                    + " where aval=0 AND TipoCliente IN (1,2) and TIPO_DOC=14 AND CLAVE='{0}' ORDER BY FECHA DESC",
                    Cliente);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                //DM0312_MAnexoCta modelEmpty = new DM0312_MAnexoCta();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MAnexoCta model = new DM0312_MAnexoCta();

                        model.IDR = Convert.ToInt32(dr["IDR"].ToString());
                        model.Imagen = dr["documento"] as byte[];
                        model.FechaAlta = Convert.ToDateTime(dr["Alta"].ToString());
                        model.Cuenta = dr["Cuenta"].ToString();
                        if (model.Imagen != null && model.Imagen.Length != 0)
                            //Image imagen = Image.FromFile(model.Direccion, true);
                            //MemoryStream memory = new MemoryStream();
                            //imagen.Save(memory, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //model.Imagen = memory.ToArray();
                            //memory.Dispose();
                            ListaDirecciones.Add(model);
                    }
                else
                    return ListaDirecciones;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CAnexoCta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return ListaDirecciones.OrderBy(x => x.FechaAlta).ToList();
        }

        public List<DM0312_MAnexoCta> obtenerFotosHistorico(string Cliente)
        {
            List<DM0312_MAnexoCta> ListaDirecciones = new List<DM0312_MAnexoCta>();

            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                query = string.Format(
                    "SELECT ID_EXTERNO IDR,documento,FECHA Alta,CLAVE Cuenta FROM [AdminDocHistorico].[dbo].[MAVI_DOC_CTE] WITH(NOLOCK)"
                    + " INNER JOIN [SID].[dbo].[SHM_BURO_CTED] WITH(NOLOCK) ON ID_EXTERNO=IdPrimario "
                    + " where aval=0 AND TipoCliente IN (1,2) and TIPO_DOC=14 AND CLAVE='{0}' ORDER BY FECHA DESC",
                    Cliente);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionHistoricoAdminDoc);
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                //DM0312_MAnexoCta modelEmpty = new DM0312_MAnexoCta();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MAnexoCta model = new DM0312_MAnexoCta();

                        model.IDR = Convert.ToInt32(dr["IDR"].ToString());
                        model.Imagen = dr["documento"] as byte[];
                        model.FechaAlta = Convert.ToDateTime(dr["Alta"].ToString());
                        model.Cuenta = dr["Cuenta"].ToString();
                        if (model.Imagen != null && model.Imagen.Length != 0)
                            //Image imagen = Image.FromFile(model.Direccion, true);
                            //MemoryStream memory = new MemoryStream();
                            //imagen.Save(memory, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //model.Imagen = memory.ToArray();
                            //memory.Dispose();
                            ListaDirecciones.Add(model);
                    }
                else
                    return ListaDirecciones;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CAnexoCta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return ListaDirecciones.OrderBy(x => x.FechaAlta).ToList();
        }


        public DM0312_MAnexoCta GetFotoActual(string Cliente, string Movid)
        {
            List<DM0312_MAnexoCta> ListaDirecciones = new List<DM0312_MAnexoCta>();
            DM0312_MAnexoCta model_ = new DM0312_MAnexoCta();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                //query = string.Format("SELECT IDR,Direccion,Alta,Cuenta FROM AnexoCta WITH(NOLOCK) WHERE Tipo = 'Imagen' AND" +
                //" Nombre LIKE '%Foto%' AND Rama = 'CXC' AND ISNULL(Direccion,'')<>''" +
                // " AND Cuenta='{0}' AND IDR={1}", Cliente, IdVenta);

                query = string.Format(
                    "SELECT ID_EXTERNO IDR,documento,FECHA Alta,CLAVE Cuenta FROM [AdminDoc].[dbo].[MAVI_DOC_CTE] WITH(NOLOCK)"
                    + " INNER JOIN [SID].[dbo].[SHM_BURO_CTED] WITH(NOLOCK) ON ID_EXTERNO=IdPrimario "
                    + " where TIPO_DOC=14 AND CLAVE='{0}' AND ANALISIS='{1}' ORDER BY FECHA DESC", Cliente, Movid);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                //DM0312_MAnexoCta modelEmpty = new DM0312_MAnexoCta();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MAnexoCta model = new DM0312_MAnexoCta();

                        model.IDR = Convert.ToInt32(dr["IDR"].ToString());
                        model.Imagen = dr["documento"] as byte[];
                        model.FechaAlta = Convert.ToDateTime(dr["Alta"].ToString());
                        model.Cuenta = dr["Cuenta"].ToString();
                        if (model.Imagen != null && model.Imagen.Length != 0)
                            //System.IO.MemoryStream ms = new System.IO.MemoryStream(model.Imagen);
                            //System.Drawing.Image returnImage = System.Drawing.Image.FromStream(ms);
                            ////return returnImage;
                            ////Image imagen = Image.FromFile(model.Direccion, true);
                            //MemoryStream memory = new MemoryStream();
                            //imagen.Save(memory, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //model.Imagen = memory.ToArray();
                            //memory.Dispose();
                            ListaDirecciones.Add(model);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CAnexoCta", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            ListaDirecciones = ListaDirecciones.OrderBy(x => x.FechaAlta).ToList();

            model_ = ListaDirecciones.FirstOrDefault();

            return model_;
        }
    }
}