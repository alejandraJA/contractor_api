﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;
using PuntoVenta.Properties;

namespace PuntoVenta.Controller
{
    public class fusionAppControlador
    {
        private DataTable dt;

        /// <summary>
        ///     Metodo encargado de obtener las imagenes del cliente de la tabla MAVI_DOC_CTE
        /// </summary>
        /// <param name="sCliente">cuenta del cliente</param>
        /// <returns>Retorna una lista con las imagenes del cliente ADMIN_DOC</returns>
        public List<appFusionModel> obtenerImagenes(string sCliente)
        {
            List<appFusionModel> listaImagenes = new List<appFusionModel>();
            dt = new DataTable();
            try
            {
                string sQuery =
                    @"SELECT d.Id, td.Documento AS NombreDoc,d.DOCUMENTO ,d.TIPO_DOC FROM MAVI_DOC_CTE d WITH(NOLOCK)  
                                INNER JOIN MAVI_TIPO_DOC td
                                on d.TIPO_DOC = td.ID
                                where IDAPLICACION = 14 AND FORMATO = 'IMG' and CLAVE = @Clave
                                and Eliminar = 0";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Clave", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroid))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    Image imgEstatus = ScaleImage(Resources.Cancelar_50, 20, 20);


                    foreach (DataRow item in dt.Rows)
                    {
                        Image img = null;


                        if (item["DOCUMENTO"].ToString().Length > 0)
                        {
                            byte[] arrImage = (byte[])item["DOCUMENTO"];

                            MemoryStream ms = new MemoryStream(arrImage);

                            /*GESSY HOTFIX imagenes sin nada manda error de parametro*/
                            if (ms.Length > 10)
                            {
                                img = Image.FromStream(ms);
                                img = ScaleImage(img, 1294, 513);
                            }
                            else
                            {
                                img = ScaleImage(Resources.Cancelar_50, 1294, 513);
                            }


                            listaImagenes.Add(new appFusionModel
                            {
                                idImagen = int.Parse(item["TIPO_DOC"].ToString()),
                                imgImagen = img,
                                imgEstatus = imgEstatus,
                                sNombreImagen = item["NombreDoc"].ToString(),
                                bEstatusValidacion = false,
                                sIdImagen = item["Id"].ToString()
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaImagenes;
        }

        /// <summary>
        ///     Metodo que se utiliza para escalar imagenes
        /// </summary>
        /// <param name="image">Imagen que se le cambiara el tamaño</param>
        /// <param name="maxWidth">largo de la imagen</param>
        /// <param name="maxHeight">alto de la imagen</param>
        /// <returns>retorna una objeto imgage con las medidas de la imagen</returns>
        public Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            Bitmap newImage = new Bitmap(20, 20);
            try
            {
                double ratioX = (double)maxWidth / image.Width;
                double ratioY = (double)maxHeight / image.Height;
                double ratio = Math.Min(ratioX, ratioY);
                int newWidth = (int)(image.Width * ratio);
                int newHeight = (int)(image.Height * ratio);
                newImage = new Bitmap(newWidth, newHeight);
                Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return newImage;
        }

        /// <summary>
        ///     Metodo encargado de insertar en la tabla VTASCListadoImagen (IntelisisTmp)
        /// </summary>
        /// <param name="Insert">string con los valores que se insertaran</param>
        /// <returns>retorna true si inserta en la tabla de imagenes de lo contrario false</returns>
        public bool insertDocData(string Insert)
        {
            try
            {
                string query = "insert into VTASCListadoImagen (IdVenta, Imagen, Usuario, EstatusDeValidacion) values" +
                               Insert;

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Metodo encargado de validar si el id de venta ya se valido para no validar de nuevo las imagenes
        /// </summary>
        /// <param name="iIdVenta">id que hace referencia a la tabla venta</param>
        /// <returns></returns>
        public bool validarImagenesValidadas(int iIdVenta)
        {
            bool bValidado = false;
            try
            {
                string sQuery = "select IdVenta from VTASCListadoImagen WITH(NOLOCK) WHERE IdVenta = @IdVenta";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdVenta", iIdVenta)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bValidado = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bValidado;
        }

        /// <summary>
        ///     Metodo encargado de dar de baja las imagenes que presentan problemas (se pone 1 y las borra una tarea)
        /// </summary>
        /// <param name="cCliente">cuenta del cliente</param>
        /// <param name="sId">id de la imagen</param>
        public void borrarImagen(string cCliente, string sId)
        {
            string sQuery = @"UPDATE MAVI_DOC_CTE WITH(ROWLOCK)
                SET Eliminar = 1 WHERE IDAPLICACION = 14
                AND FORMATO = 'IMG'
                AND CLAVE = @cliente 
                AND Id = @Id";

            try
            {
                SqlParameter[] pars =
                {
                    new SqlParameter("@cliente", cCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Id", sId)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroid))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}