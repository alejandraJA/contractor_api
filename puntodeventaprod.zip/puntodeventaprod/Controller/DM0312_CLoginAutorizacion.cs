﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using fnPassword;

namespace PuntoVenta.Controller
{
    public class DM0312_CLoginAutorizacion
    {
        public bool Login(string user, string password)
        {
            try
            {
                using (SqlCommand cmd =
                       new SqlCommand("SELECT dbo.FN_DM0209ComprobarUsuarioContrasena (@Usuario, @Contrasena)",
                           ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Usuario", SqlDbType.VarChar) { Value = user.ToUpper() },
                        new SqlParameter("@Contrasena", SqlDbType.VarChar) { Value = Intelisis.getHash(password, "P") }
                    };

                    cmd.Parameters.AddRange(parametros.ToArray());
                    cmd.CommandTimeout = 60;
                    int res = (int)cmd.ExecuteScalar();

                    return res == 1 ? true : false;
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("Login", "DM0312_CLoginAutorizacion", e);
                MessageBox.Show(e.Message);
                return false;
            }
        }

        //1832
        public bool PermisoArticuloPequeno(string Usuario)
        {
            try
            {
                bool respuesta = false;
                string sql = @"SELECT 
                    top 1 Nombre
                FROM TablaStD WITH(NOLOCK)
                WHERE
                    TablaSt = '1832VALIDACION ARTÍCULOS PEQ'
                    and Nombre = (select Acceso from usuario where estatus = 'Alta' and usuario = @Usuario)";
                using (SqlCommand cmd = new SqlCommand(sql, ClaseEstatica.ConexionEstatica))
                {
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Usuario", SqlDbType.VarChar) { Value = Usuario.ToUpper() }
                    };

                    cmd.Parameters.AddRange(parametros.ToArray());
                    cmd.CommandType = CommandType.Text;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read()) respuesta = true;
                    }

                    return respuesta;
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("PermisoArticuloPequeno", "DM0312_CLoginAutorizacion", e);
                MessageBox.Show(e.Message);
                return false;
            }
        }
    }
}