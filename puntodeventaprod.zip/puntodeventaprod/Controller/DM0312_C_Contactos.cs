﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_Contactos
    {
        /// <summary>
        ///     Obtiene los contactos de la cuenta solicitada
        /// </summary>
        /// <param name="cliente">string</param>
        /// <returns>List<SerieArticulos></returns>
        /// Developer:Erika Perez
        /// Date: 28/08/17
        public DataTable DatosContactos(string cliente)
        {
            DataTable ListaContactos = new DataTable();

            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_DM0312PuntoVentaContactos", ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(ListaContactos);
                command.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosContactos", "DM0312_C_Contactos", ex);
                MessageBox.Show(ex.Message);
            }

            return ListaContactos;
        }
    }
}