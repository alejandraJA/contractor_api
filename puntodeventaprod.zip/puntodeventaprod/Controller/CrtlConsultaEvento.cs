﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CrtlConsultaEvento
    {
        /// <summary>
        ///     Metodo que permite llenar el dataGrid Eventos Historial Solicitudes
        ///     <param name="movimiento"></param>
        ///     <param name="tipoMovimiento"></param>
        ///     <returns>DataSet</returns>
        ///     Developer: Victor Avila
        ///     Date:04/08/2017
        ///     <summary>
        public List<DM0312_MConsultarEvento> LlenaConsultarEventos(string id, string Movimiento)
        {
            List<DM0312_MConsultarEvento> modelList = new List<DM0312_MConsultarEvento>();
            SqlDataReader dr = null;
            string query =
                "SELECT  mb.Fecha, mb.Clave, mb.Evento, mb.Usuario, u.Nombre  FROM MovBitacora mb WITH(NOLOCK) " +
                "INNER JOIN Usuario u WITH(NOLOCK) ON  u.Usuario = mb.Usuario " +
                "WHERE mb.ID = @Id  AND mb.Clave <> 'VTA99999' and mb.clave is not null  order by mb.fecha desc";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@id", id);
                sqlCommand.Parameters.AddWithValue("@Movimiento", Movimiento);
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MConsultarEvento model_ = new DM0312_MConsultarEvento();
                    model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                    model_.Clave = dr["Clave"].ToString();
                    model_.Evento = dr["Evento"].ToString();
                    model_.Usuario = dr["Usuario"].ToString();
                    model_.Nombre = dr["Nombre"].ToString();
                    modelList.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlConsultarEvento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return modelList;
        }

        /// <summary>
        ///     Metodo que permite llenar datagrid NotasCitas (Consultar)
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 04/08/2017
        public List<DM0312_MConsultarEvento> LlenaNotas(string data)
        {
            List<DM0312_MConsultarEvento> list = new List<DM0312_MConsultarEvento>();
            SqlDataReader dr = null;
            string query =
                "SELECT c.Fecha, c.Evento, u.Usuario, u.Nombre FROM ctaBitacora c WITH(NOLOCK) INNER JOIN Usuario u WITH(NOLOCK) ON u.Usuario = c.Usuario   WHERE Cuenta =@Cuenta";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Cuenta", data);
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MConsultarEvento model_ = new DM0312_MConsultarEvento();
                    model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                    model_.Evento = dr["Evento"].ToString();
                    model_.Usuario = dr["Usuario"].ToString();
                    model_.Nombre = dr["Nombre"].ToString();
                    list.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlConsultarEvento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return list;
        }

        /// <summary>
        ///     Metodo que permite llenar datagrid Consulta Citas (Consultar)
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 04/08/2017
        public List<DM0312_MConsultarEvento> LlenaConsultarCita(string idVenta, string usuario)
        {
            List<DM0312_MConsultarEvento> modelList = new List<DM0312_MConsultarEvento>();
            SqlDataReader dr = null;
            try
            {
                string query = "SELECT  mb.Fecha , mb.Evento, mb.Usuario, u.Nombre FROM MovBitacora mb WITH(NOLOCK)" +
                               "INNER JOIN Venta v WITH(NOLOCK) ON v.id=mb.Id " +
                               "INNER JOIN Usuario u WITH(NOLOCK) ON u.Usuario = mb.Usuario " +
                               "where Clave='VTA99999' AND  v.ID = @idVenta ";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@idVenta", idVenta);
                sqlCommand.Parameters.AddWithValue("@usuario", usuario);
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MConsultarEvento model_ = new DM0312_MConsultarEvento();
                    model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                    model_.Evento = dr["Evento"].ToString();
                    model_.Usuario = dr["Usuario"].ToString();
                    model_.Nombre = dr["Nombre"].ToString();
                    modelList.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlConsultaEvento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return modelList;
        }
    }
}