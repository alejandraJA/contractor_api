﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class DM0312_C_EscanearValeDigital
    {
        public int getEstatusVale(string valeDigital)
        {
            int respuesta = 5;
            //Posibles Respuesta del sp
            //0 - Vale Correcto
            //1 - Vale No existe
            //2 - Vale expirado
            //3 - Vale Cancelado
            //4 - Vale ya usado
            //5 - Error metodo/SP

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "validar" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = valeDigital }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                respuesta = int.Parse(dr[0].ToString());
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return respuesta;
        }


        public MValeDigital getDatosVale(string vale)
        {
            MValeDigital datosVale = new MValeDigital();

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "getDatosVale" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = vale }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                datosVale.id_vale = int.Parse(dr["idPedidoValeDigital"].ToString());
                                datosVale.cliente = dr["Cliente"].ToString();
                                datosVale.vale = dr["Vale"].ToString();
                                datosVale.tipo = int.Parse(dr["TipoPedido"].ToString());
                                datosVale.total = double.Parse(dr["Total"].ToString());
                                datosVale.correo = dr["Correo"].ToString();
                                datosVale.telefono = dr["Telefono"].ToString();
                                datosVale.canal = int.Parse(dr["Canal"].ToString());
                                datosVale.condicion = dr["Condicion"].ToString();
                                datosVale.beneficiarioFinal = dr["ClienteBF"].ToString();
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getDatosVale", "DM0312_C_EscanearValeDigital", ex);
                MessageBox.Show(ex.Message);
            }

            return datosVale;
        }


        public List<string> getProductosVale(int id)
        {
            List<string> productos = new List<string>();

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "getProductosVale" },
                        new SqlParameter("@id", SqlDbType.VarChar) { Value = id }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                string sku = dr["sku"].ToString();
                                productos.Add(sku);
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getProductosVale", "DM0312_C_EscanearValeDigital", ex);
                MessageBox.Show(ex.Message);
            }

            return productos;
        }


        public string getNipCliente(string cliente)
        {
            string NIP = "";

            try
            {
                string query = string.Format("Select NIP_VENTA From DM0244_CLAVES WITH(NOLOCK) Where Cuenta = '{0}'",
                    cliente);

                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                return dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getNipCliente", "DM0312_C_EscanearValeDigital", ex);
                MessageBox.Show(ex.Message);
            }

            return NIP;
        }


        public bool checarSiValeDigital(string valeDigital)
        {
            //Respuesta
            //0 - Vale Correcto
            //1 - Vale No existe

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "checarTipoVale" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = valeDigital }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                int res = int.Parse(dr[0].ToString());
                                if (res == 1) return true;
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("checarSiValeDigital", "DM0312_C_EscanearValeDigital", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }
    }
}