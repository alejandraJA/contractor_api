﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using fnPassword;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CReporteServicios
    {
        /// <summary>
        ///     Checa si la venta tiene articulos en reporte de servicios
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 21/11/17
        public bool ArticulosConReporte(int IDVenta)
        {
            bool ArticuloConReporte = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@ArticulosRelacionadoAReportes", true);
                SqlParameter returnParameter = sqlCommand.Parameters.Add("@ReturnVal", SqlDbType.Int);
                returnParameter.Direction = ParameterDirection.ReturnValue;
                sqlCommand.ExecuteNonQuery();
                object result = returnParameter.Value;
                if (result != null)
                    if (result.ToString() == "1")
                        return true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ArticulosConReporte", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: ArticulosConReporte, class: CReporteServicios");
            }

            return ArticuloConReporte;
        }

        /// <summary>
        ///     Checa si un movimiento tiene un reporte asignado
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 22/11/17
        public string MovConReporte(int IDVenta)
        {
            string ReporteServicio = "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@ChecarReporteAsignado", true);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr["ReporteServicio"] != null && dr["ReporteServicio"].ToString() != string.Empty)
                            ReporteServicio = dr["ReporteServicio"].ToString();
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MovConReporte", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: MovConReporte, class: CReporteServicios");
            }

            return ReporteServicio;
        }

        //-ReporteDescuento
        /// <summary>
        ///     Obtiene reporte de soporte
        /// </summary>
        /// <param name="Sucursal">int</param>
        /// <param name="Articulo">string</param>
        /// <returns>List<MReportesServicio></returns>
        /// Developer: Dan Palacios
        /// Date: 18/11/17
        public List<MReportesServicio> ObtenerReportes(int IDVenta, int Sucursal)
        {
            List<MReportesServicio> Reportes = new List<MReportesServicio>();

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@ObtenerReportes", true);

                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MReportesServicio NuevoMov = new MReportesServicio();
                        NuevoMov.ID = Convert.ToInt32(dr["ID"]);
                        NuevoMov.Movimiento = dr["Movimiento"].ToString();
                        NuevoMov.MovID = dr["MovID"].ToString();
                        NuevoMov.Origen = "Soporte";
                        Reportes.Add(NuevoMov);
                    }

                dr.Close();

                //-ReporteDescuento
                sqlCommand.Parameters.Clear();
                sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@opcion", "ConsultaReportesParaVenta");
                sqlCommand.Parameters.AddWithValue("@idSucursal", Sucursal);
                sqlCommand.Parameters.AddWithValue("@idVenta", IDVenta);

                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MReportesServicio NuevoMov = new MReportesServicio();
                        NuevoMov.ID = Convert.ToInt32(dr["IdReporteDescuento"]);
                        NuevoMov.Movimiento = dr["Mov"].ToString();
                        NuevoMov.MovID = dr["MovId"].ToString();
                        NuevoMov.Origen = "VTASDReporteDescuento";
                        Reportes.Add(NuevoMov);
                    }

                dr.Close();
                sqlCommand.Parameters.Clear();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerReportes", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerReportes, class: CReporteServicios");
            }

            return Reportes;
        }

        /// <summary>
        ///     Compara contraseña guardada y contraseña ingresada
        /// </summary>
        /// <param name="Usuario">string</param>
        /// <param name="Contraseña">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 21/11/17
        public bool ContraseñaValida(string Usuario, string Contraseña)
        {
            string md5ContraseñaGuardada = "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@ValidaUsuario", true);
                sqlCommand.Parameters.AddWithValue("@Usuario", Usuario);

                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        md5ContraseñaGuardada = (string)dr["Contrasena"] ?? "";
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ContraseñaValida", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: ContraseñaValida, class: CReporteServicios");
            }

            CDetalleVenta cDetalle = new CDetalleVenta();
            string ContraseñaIngresadaMd5 = Intelisis.getHash(Contraseña, "P"); //CDetalleVenta.MD5Hash(Contraseña);
            if (md5ContraseñaGuardada != string.Empty && ContraseñaIngresadaMd5 != string.Empty)
            {
                if (ContraseñaIngresadaMd5 != md5ContraseñaGuardada) return false;
            }
            else
            {
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Afecta reporte para que no se vuelva a mostrar
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <param name="Sucursal">int</param>
        /// <param name="AfectaReporte">int</param>
        /// Developer: Dan Palacios
        /// Date: 21/11/17
        public void AfectarReporte(int IDVenta, int Sucursal, int AfectaReporte)
        {
            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_RM1161AfectacionRepServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@ID", IDVenta);
                sqlCommand.Parameters.AddWithValue("@IDSoporte", Sucursal);
                sqlCommand.Parameters.AddWithValue("@Opcion", AfectaReporte);
                sqlCommand.CommandTimeout = 60;
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AfectarReporte", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: AfectarReporte, class: CReporteServicios");
            }
        }

        /// <summary>
        ///     Afecta reporte para que no se vuelva a mostrar
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// Developer: Dan Palacios
        /// Date: 21/11/17
        public void DesasignarReporte(int IDVenta)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@RemoverReporteServicio", true);
                sqlCommand.ExecuteNonQuery();

                //Borrar Reporte Descuento
                AfectarReporteDescuento(IDVenta, 0, 1);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DesasignarReporte", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: DesasignarReporte, class: CReporteServicios");
            }
        }

        #region ReporteDescuento

        public void AfectarReporteDescuento(int IDVenta, int IdReporteDescuento, int borrar = 0)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@idVenta", IDVenta);
                if (borrar == 0)
                    sqlCommand.Parameters.AddWithValue("@idReporteDescuento", IdReporteDescuento.ToString());
                sqlCommand.Parameters.AddWithValue("@opcion", "ActualizaVenta");
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AfectarReporteDescuento", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: AfectarReporte, class: CReporteServicios");
            }
        }


        public void checkReporteDecuento(int IDVenta)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@idVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@opcion", "ActualizaVenta");
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AfectarReporteDescuento", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: AfectarReporte, class: CReporteServicios");
            }
        }

        public bool ArticulosConReporteDescuento(int IDVenta)
        {
            bool ArticuloConReporte = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@opcion", "CheckProductosTienenReporte");
                sqlCommand.Parameters.AddWithValue("@IdVenta", IDVenta);
                SqlParameter returnParameter = sqlCommand.Parameters.Add("@ReturnVal", SqlDbType.Int);
                returnParameter.Direction = ParameterDirection.ReturnValue;
                sqlCommand.ExecuteNonQuery();
                object result = returnParameter.Value;
                if (result != null)
                    if (result.ToString() == "1")
                        return true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ArticulosConReporte", "CReporteServicios.cs", ex);
                MessageBox.Show(ex.Message + " function: ArticulosConReporte, class: CReporteServicios");
            }

            return ArticuloConReporte;
        }

        #endregion
    }
}