﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class clsControladorPromociones
    {
        /*1. Validar que el articulo Padre se encuentre en una promoción */

        /// <summary>
        ///     Metodo que obtiene las promociones por sucursal y canal de venta.
        /// </summary>
        /// <param name="iSucursal"></param>
        /// <param name="iCanalVenta"></param>
        /// <returns>Lista con id de promociones que aplican.</returns>
        public List<int> AplicaCanalSucursal(int iSucursal, int iCanalVenta)
        {
            List<int> lsAplica = new List<int>();
            SqlDataReader dr = null;
            string sQuery = "select s.IdCampanaPromocion from VTASCCampanaPromocionSucursal s with(nolock) " +
                            "inner join VTASCCampanaPromocionCanalVenta cv with(nolock) " +
                            "ON s.IdCampanaPromocion = cv.IdCampanaPromocion " +
                            $"where s.Sucursal = {iSucursal} and cv.CanalVenta = {iCanalVenta}";

            //sQuery = "update SaldoU set SaldoU = 10  where Cuenta = '232A00010' and grupo = 'V00132';";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        int vDato = int.Parse(dr["IdCampanaPromocion"].ToString());
                        lsAplica.Add(vDato);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return lsAplica;
        }

        /// <summary>
        ///     Metodo que obtiene la promocion por ID.
        /// </summary>
        /// <param name="iIdPromocion"></param>
        /// <returns></returns>
        public List<clsModeloPromocion> ObtenerPromocion(int iIdPromocion)
        {
            List<clsModeloPromocion> lsPromocion = new List<clsModeloPromocion>();
            SqlDataReader dr = null;
            string sQuery = "select IdCampanaPromocion, Nombre, FechaInicio, FechaFin, Estatus, UEN, MaxHijos " +
                            $"from VTASCCampanaPromocion where IdCampanaPromocion = {iIdPromocion} AND GETDATE() BETWEEN FechaInicio " +
                            $"AND FechaFin AND Uen = {ClaseEstatica.Usuario.Uen} AND Estatus = 'Aceptada'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        clsModeloPromocion promocion = new clsModeloPromocion
                        {
                            iIdPromocion = int.Parse(dr["IdCampanaPromocion"].ToString()),
                            sNombre = dr["Nombre"].ToString(),
                            sFechaInicio = dr["FechaInicio"].ToString(),
                            sFechaFin = dr["FechaFin"].ToString(),
                            sEstatus = dr["Estatus"].ToString(),
                            iUen = int.Parse(dr["UEN"].ToString()),
                            ArticulosPermitidos = (int)dr["MaxHijos"]
                        };
                        lsPromocion.Add(promocion);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return lsPromocion;
        }

        public int ExistenciaSucursal(string Articulo, int Sucursal)
        {
            double existencia = 0;
            string Query =
                @"SELECT Disponible = SUM(Disponible), 
                   ad.Articulo, 
                   alm.Sucursal
            FROM ArtDisponible ad WITH(NOLOCK)
                 INNER JOIN Alm WITH(NOLOCK) ON ad.Almacen = Alm.Almacen
                                                AND alm.Sucursal = @sucursal
            WHERE ad.Articulo = @articulo
            GROUP BY ad.Articulo, 
                     alm.Sucursal; ";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(Query, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@sucursal", Sucursal);
                sqlCommand.Parameters.AddWithValue("@articulo", Articulo);

                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read()) existencia = dr.GetDouble(0);
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return Convert.ToInt32(existencia);
        }

        /// <summary>
        ///     Metodo encargado de obtener la fecha del servidor
        /// </summary>
        /// <returns>retorna datetime con la fecha del servidor</returns>
        public DateTime getDate()
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            DateTime sFecha = new DateTime();
            query = "SELECT GETDATE() AS Fecha";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sFecha = DateTime.Parse(dr["Fecha"].ToString());
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "getDate", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return sFecha;
        }

        public List<clsModeloPromocionDetalle> ObtenerPromocionD(int iIdPromocion)
        {
            List<clsModeloPromocionDetalle> lsPromocionDetalle = new List<clsModeloPromocionDetalle>();
            SqlDataReader dr = null;
            string sQuery = @"SELECT 
                c.IdCampanaPromocion,
				ISNULL(c.FamiliaP, '') AS FamiliaP,
                ISNULL(c.LineaP, '') AS LineaP,
                ISNULL(c.ArticuloP, '') AS ArticuloP,
                ISNULL(c.DescripcionP, '') AS DescripcionP,
                ISNULL(c.ExcepcionP, '') AS ExcepcionP,
                RedimeMonP = CAST(IIF(UPPER(p.RedimeMonP)='SI',1,0) as BIT),
                GeneraMonP = CAST(IIF(UPPER(p.GeneraMonP)='SI',1,0) as BIT),
                RedimeMonH = CAST(IIF(UPPER(p.RedimeMonH)='SI',1,0) as BIT),
                ISNULL(p.PzaMin, 0) AS PzaMin,
                ISNULL(p.MontoMin, 0) AS MontoMin,
                c.FamiliaH,
                c.LineaH,
                c.ArticuloH,
                c.DescripcionH,
                c.PorcDesc,
                ISNULL(c.ExcepcionH, '') AS ExcepcionH,
                c.PzaMax,
				p.Nombre
                FROM VTASDConfiguracionCampanaPromocion c WITH(NOLOCK)
                INNER JOIN VTASCCampanaPromocion p
                ON c.IdCampanaPromocion = p.IdCampanaPromocion
                WHERE c.IdCampanaPromocion = @id;";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                sqlCommand.Parameters.AddWithValue("@id", iIdPromocion);
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        clsModeloPromocionDetalle d = new clsModeloPromocionDetalle
                        {
                            iIdConfiguracionPromocion = int.Parse(dr["IdCampanaPromocion"].ToString()),
                            iIdPromocion = int.Parse(dr["IdCampanaPromocion"].ToString()),
                            sFamiliaP = dr["FamiliaP"].ToString(),
                            sLineaP = dr["LineaP"].ToString(),
                            sArticuloP = dr["ArticuloP"].ToString(),
                            sDescripcionP = dr["DescripcionP"].ToString(),
                            sExcepcionP = dr["ExcepcionP"].ToString(),
                            bRedimeMonP = bool.Parse(dr["RedimeMonP"].ToString()),
                            bGeneraMonP = bool.Parse(dr["GeneraMonP"].ToString()),
                            iPzaMin = int.Parse(dr["PzaMin"].ToString()),
                            dMontoMin = double.Parse(dr["MontoMin"].ToString()),
                            sFamiliaH = dr["FamiliaH"].ToString(),
                            sLineaH = dr["LineaH"].ToString(),
                            sArticuloH = dr["ArticuloH"].ToString(),
                            sDescripcionH = dr["DescripcionH"].ToString(),
                            dPorcDesc = double.Parse(dr["PorcDesc"].ToString()),
                            sExcepcionH = dr["ExcepcionH"].ToString(),
                            bRedimeMonH = bool.Parse(dr["RedimeMonH"].ToString()),
                            iPzaMax = int.Parse(dr["PzaMax"].ToString()),
                            NombreCampana = dr["Nombre"].ToString()
                        };
                        lsPromocionDetalle.Add(d);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerPromocionD", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return lsPromocionDetalle;
        }

        public string ObtenerFamilia(string sArticulo)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            string sFamilia = string.Empty;
            query = string.Format("select Familia from art where Articulo = '{0}'", sArticulo);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sFamilia = dr["Familia"].ToString();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerFamilia", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return sFamilia;
        }

        public string ObtenerLinea(string sArticulo)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            string sLinea = string.Empty;
            query = string.Format("select Linea from art where Articulo = '{0}'", sArticulo);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sLinea = dr["Linea"].ToString();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerLinea", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sLinea;
        }

        public int ObtenerDisponibles(string sArticulo)
        {
            int iDisponibles = 0;
            string sQuery =
                "select sum(disponible) AS Disponible FROM ArtDisponible WITH(NOLOCK) where almacen <> 'V00097' " +
                $"and disponible > 0 and articulo = '{sArticulo}'";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        string x = dr["Disponible"].ToString();
                        iDisponibles = int.Parse(string.IsNullOrEmpty(x) ? "0" : x);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerDisponibles", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iDisponibles;
        }

        public Dictionary<string, string> ArticulosFamilia(string sFamilia)
        {
            Dictionary<string, string> dArticulos = new Dictionary<string, string>();
            string sQuery =
                $"select articulo, Descripcion1 from art where Familia = '{sFamilia}' and Estatus in('Alta','Bloqueado')";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        string vArt = dr["articulo"].ToString();
                        string vDesc = dr["Descripcion1"].ToString();
                        dArticulos.Add(vArt, vDesc);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ArticulosFamilia", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dArticulos;
        }

        public Dictionary<string, string> ArticulosFamiliaLinea(string sFamilia, string sLinea)
        {
            Dictionary<string, string> dArticulos = new Dictionary<string, string>();
            string sQuery =
                $"select articulo, Descripcion1 from art where Familia = '{sFamilia}' and Linea = '{sLinea}' " +
                "and Estatus in('Alta','Bloqueado')";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        string vArt = dr["articulo"].ToString();
                        string vDesc = dr["Descripcion1"].ToString();
                        dArticulos.Add(vArt, vDesc);
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ArticulosFamiliaLinea", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dArticulos;
        }

        public int ObtenerPzaPromocion(int iIdPromocion)
        {
            int iPzaMax = 0;
            string sQuery =
                $"select CASE WHEN MontoIncremental > 1 THEN MontoIncremental * MaxHijos ELSE MaxHijos END AS MaxHijos from VTASCCampanaPromocion with(nolock) where IdCampanaPromocion = {iIdPromocion}";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        iPzaMax = int.Parse(dr["MaxHijos"].ToString());
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerPzaPromocion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iPzaMax;
        }

        public double ObtenerDescuento(int iIdPromocion, string Articulo)
        {
            double dDesc = 0;
            string sQuery = $@"SELECT
                                ISNULL(cpa.PorcDescuento, cp.PorcDescuentoGlobal) AS PorcDescuento
                            FROM VTASDCampanaPromocionArticulo cpa WITH (NOLOCK)
                            FULL OUTER JOIN VTASCCampanaPromocion cp WITH (NOLOCK)
                                ON cp.IdCampanaPromocion = cpa.IdCampanaPromocion
                            WHERE cp.IdCampanaPromocion = {iIdPromocion}";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        string porcendesc = dr["PorcDescuento"].ToString();
                        if (porcendesc != "") dDesc = double.Parse(dr["PorcDescuento"].ToString());
                    }

                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerDescuento", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dDesc;
        }

        public int ObtenerIdPromo(int iIdConfiguracion)
        {
            int iIdPromo = 0;
            string sQuery =
                $"select IdCampanaPromocion from VTASDConfiguracionCampanaPromocion with(nolock) where IdConfiguracionCampanaPromocion = {iIdConfiguracion}";
            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        iIdPromo = int.Parse(dr["IdCampanaPromocion"].ToString());
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerIdPromo", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iIdPromo;
        }

        public string ObtenerNombrePromo(int iIdPromocion)
        {
            string sNombre = string.Empty;
            string sQuery =
                $"select Nombre from VTASCCampanaPromocion with(nolock) where IdCampanaPromocion = {iIdPromocion}";

            SqlDataReader dr = null;

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sNombre = dr["Nombre"].ToString();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ObtenerNombrePromo", ex);
                MessageBox.Show("Error " + ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sNombre;
        }

        public void ActualizarPrecio(DM0312_MVentaDetalle mVenta, int iIdVenta)
        {
            string sQuery =
                $"update VentaD WITH(ROWLOCK) set Precio = {mVenta.Precio}, PrecioSugerido = {mVenta.PrecioS} " +
                $"where id = {iIdVenta} and Renglon = {mVenta.Renglon} and RenglonID = {mVenta.RenglonID}";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                sqlCommand.ExecuteNonQuery();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ActualizarPrecio", ex);
                MessageBox.Show("Error " + ex.Message);
            }
        }

        public bool VerificarPromocionVencida(string MovId)
        {
            bool res = false;
            string sQuery =
                @"SELECT CAST(COUNT(*) AS BIT)
                FROM venta v WITH(NOLOCK)
                     INNER JOIN ventad vd WITH(NOLOCK) ON vd.ID = v.ID
                                                          AND vd.IdCampanaPromocion IS NOT NULL
                     INNER JOIN VTASCCampanaPromocion cp WITH(NOLOCK) ON cp.IdCampanaPromocion = vd.IdCampanaPromocion
                                                                         AND cp.FechaFin < GETDATE()
                WHERE v.MovID = '@MovId';";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovId", MovId);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read())
                {
                    res = (bool)dr[0];
                    res = res ? TieneDevolucion(MovId) : res;
                }

                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "VerificarPromocionVencida", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        private bool TieneDevolucion(string MovId)
        {
            bool res = false;
            string sQuery =
                "SELECT CAST(IIF(COUNT(*) > 0, 1, 0) AS BIT) FROM venta WHERE mov = 'Solicitud devolucion' AND referencia LIKE '%Factura%' AND movid = @MovId;";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovId", MovId);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read()) res = (bool)dr[0];
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        internal bool VerificarDisminucionPretenciones(string MovId)
        {
            bool res = false;
            string sQuery =
                @"SELECT CAST(iif(COUNT(*) > 0, 1, 0) AS bit) FROM MovBitacora b WITH (NOLOCK) JOIN venta v WITH (NOLOCK) ON v.MovID = @MovId AND v.Mov = 'Analisis Credito' AND v.ID = b.ID
                WHERE Clave IN (SELECT Nombre FROM TablaStD WHERE TablaSt = 'DISMINUCION DE PRETENCIONES') AND Modulo = 'VTAS';";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovId", MovId);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read()) res = (bool)dr[0];
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        internal void GetCLienteCanal(string MovId, out string cliente, out int canal)
        {
            cliente = null;
            canal = 0;

            string sQuery =
                @"
                declare @MovID varchar(20);
                select @MovID = OrigenID from Venta where MovID = @MovIDF and mov = 'factura'
                select cliente, EnviarA from venta where movid = @MovID and mov = 'pedido';";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovIDF", MovId);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read())
                {
                    cliente = (string)dr[0];
                    canal = (int)dr[1];
                }

                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }
        }

        internal List<DM0312_MVentaDetalle> GetArticulos(string factura)
        {
            List<DM0312_MVentaDetalle> res = new List<DM0312_MVentaDetalle>();

            string sQuery =
                @"
                declare @movid varchar(20), @id int;
                select @movid = OrigenID from Venta where MovID = @MovIDF and mov = 'factura'
                select @id = id from venta where movid = @movid and mov = 'pedido'
                select * from ventad where id = @id;";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovIDF", factura);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    string x = dr["IdCampanaPromocion"].ToString();
                    x = string.IsNullOrEmpty(x) ? "0" : x;
                    int promocion = int.Parse(x);

                    DM0312_MVentaDetalle articulo = new DM0312_MVentaDetalle
                    {
                        Renglon = int.Parse(((double)dr["Renglon"]).ToString()),
                        Tipo = dr["RenglonTipo"].ToString(),
                        Cantidad = int.Parse(((double)dr["Cantidad"]).ToString()),
                        Almacen = dr["Almacen"].ToString(),
                        Articulo = dr["Articulo"].ToString(),
                        Precio = (double)dr["Precio"],
                        impuesto = (double)dr["Impuesto1"],
                        Articulo_Ligado = dr["padre"].ToString(),
                        idPromocion = promocion
                    };

                    articulo.PrecioS = articulo.Precio.ToString("C", Thread.CurrentThread.CurrentCulture);
                    res.Add(articulo);
                }

                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        internal string GetMovId(int idVenta)
        {
            string res = "";
            string sQuery = @"select movid from venta with(nolock) where id = @id";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@id", idVenta);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                while (dr.Read()) res = dr[0].ToString();
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        internal DateTime Fecha()
        {
            DateTime res = DateTime.Now;
            string sQuery = @"select getdate();";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                while (dr.Read()) res = (DateTime)dr[0];
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        internal void spNotasPromocion(string movId, int idVenta1, int sucursal, string grupoEmpresa, string usuario,
            int idVenta2, string movID, DateTime fecha1, DateTime fecha2, int v1, int v2, string v3, string v4)
        {
            string sQuery = @"spVTASNotasPromocion";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandTimeout = 9999999;
                sqlCommand.Parameters.AddWithValue("@MovID", movId);
                sqlCommand.Parameters.AddWithValue("@Id", idVenta1);
                sqlCommand.Parameters.AddWithValue("@Sucursal", sucursal);
                sqlCommand.Parameters.AddWithValue("@Empresa", grupoEmpresa);
                sqlCommand.Parameters.AddWithValue("@Usuario", usuario);
                sqlCommand.Parameters.AddWithValue("@IDOrigen", idVenta2);
                sqlCommand.Parameters.AddWithValue("@MovOrigen", "pedido");
                sqlCommand.Parameters.AddWithValue("@MovIDOrigen", movID);
                sqlCommand.Parameters.AddWithValue("@FechaEmision", fecha1);
                sqlCommand.Parameters.AddWithValue("@FechaRegistro", fecha2);
                sqlCommand.Parameters.AddWithValue("@Importe", v1);
                sqlCommand.Parameters.AddWithValue("@ImporteC", v2);
                sqlCommand.Parameters.AddWithValue("@Accion", v3);
                sqlCommand.Parameters.AddWithValue("@Observaciones", v4);
                sqlCommand.Parameters.Add(new SqlParameter("@Ok", SqlDbType.NVarChar, 255)
                    { Direction = ParameterDirection.Output });
                sqlCommand.Parameters.Add(new SqlParameter("@OkRef", SqlDbType.NVarChar, 255)
                    { Direction = ParameterDirection.Output });
                SqlDataReader dr = sqlCommand.ExecuteReader();
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }
        }

        internal double GetPrecioAnterior(string Factura, string articulo)
        {
            double res = 0;
            string sQuery = @"declare @id int, @movid varchar(20);

            select @movid = OrigenID from venta with(nolock) where mov like 'factura%' and MovID = @movidf;
            select @id = id from venta with(nolock) where MovID = @movid and mov = 'pedido';
            select ISNULL(ventad.PrecioAnterior, 0) from ventad with(nolock) where id = @id and articulo = @articulo;";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandTimeout = 9999999;
                sqlCommand.Parameters.AddWithValue("@movidf", Factura);
                sqlCommand.Parameters.AddWithValue("@articulo", articulo);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.Read()) res = (double)dr[0];
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "TieneDevolucion", ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return res;
        }

        #region Mejoras Promociones

        private DataTable dt;

        /// <summary>
        ///     Metodo encargado de obtener las existencias del almacen seleccionado
        /// </summary>
        /// <param name="sXml">xml con los articulos a consultar</param>
        /// <param name="sAlmacen">almacen de donde se consultaran las existencias</param>
        /// <returns></returns>
        public List<clsModeloArtPromocion> obtenerExistencias(List<clsModeloArtPromocion> lsExistencias, string sXml,
            string sAlmacen)
        {
            dt = new DataTable();

            try
            {
                string sQuery = @"  SET QUOTED_IDENTIFIER ON
                                    declare @Articulos xml = @xml;
                                    SELECT
                                        a.Articulo, isnull(a.Disponible,0) as Disponible
                                    FROM @Articulos.nodes('Articulos/Articulo') AS Arts(e)
                                    INNER JOIN ArtDisponible a WITH(NOLOCK)
                                        ON a.Articulo = e.value('.', 'VARCHAR(50)')
                                    AND a.Almacen = @Almacen";

                SqlParameter[] pars =
                {
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Almacen", sAlmacen)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        lsExistencias
                            .Where(x => x.sArticulo == row["Articulo"].ToString().Trim())
                            .Select(x =>
                            {
                                x.iDisponible = int.Parse(row["Disponible"].ToString());
                                return x;
                            }).ToList();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            return lsExistencias;
        }

        /// <summary>
        ///     Metodo encargado de elimininar los articulos que no existene el en almacen
        /// </summary>
        /// <param name="sXml">xml con los articulos a buscar</param>
        /// <param name="sAlmacen">almacen donde buscara existencias</param>
        /// <returns>retorna una lista solo con los articulos que existen en el almacen seleccionado</returns>
        public List<string> eliminarSinAlmacen(string sXml, string sAlmacen)
        {
            dt = new DataTable();
            List<string> listaArticulos = new List<string>();
            try
            {
                string sQuery = @"  SET QUOTED_IDENTIFIER ON
                                    declare @Articulos xml = @xml;
                                    SELECT
                                        a.Articulo
                                    FROM @Articulos.nodes('Articulos/Articulo') AS Arts(e)
                                    INNER JOIN ArtDisponible a WITH(NOLOCK)
                                        ON a.Articulo = e.value('.', 'VARCHAR(50)')
                                    AND a.Almacen = @Almacen";

                SqlParameter[] pars =
                {
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Almacen", sAlmacen)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaArticulos.Add(row["Articulo"].ToString().Trim());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaArticulos;
        }

        /// <summary>
        ///     Metodo encargado de obtener los articulos de promocion por articulo especifico
        /// </summary>
        /// <param name="sArticulos"></param>
        /// <param name="iIdVenta"></param>
        /// <param name="iRenglon"></param>
        /// <param name="iCantArticulos"></param>
        /// <param name="dMontoArt"></param>
        /// <param name="dMontoVenta"></param>
        /// <param name="ArticulosIncluidos"></param>
        /// <returns></returns>
        public List<clsModeloArtPromocion> obtenerPromociones(int iIdPromocion, int iIdVenta, int iRenglon,
            string sAlmacen, List<DM0312_MVentaDetalle> ArticulosIncluidos, double dPrecioArticulo = 0,
            int iMaxHijos = 0)
        {
            List<clsModeloArtPromocion> listaRegalos = new List<clsModeloArtPromocion>();
            dt = new DataTable();
            try
            {
                string sQuery = @"SELECT
                                  *
                                FROM (SELECT
                                  Numero = ROW_NUMBER() OVER (PARTITION BY mph.Articulo ORDER BY ad.Disponible),
                                  mph.IdCampanaPromocion AS iIdPromocion,
                                  mph.Articulo AS sArticulo,
                                  ISNULL(mph.PorcDescuento, 0) AS dPorDec,
                                  ad.Disponible AS iDisponible,
                                  cp.Nombre AS sNombreCampaña,
                                  ar.Descripcion1 AS sDescripcion,
                                  ar.Familia AS sFamilia,
                                  ar.Linea AS sLInea,
                                  CASE ISNULL(mph.PorcDescuento, 0)
                                    WHEN 0 THEN mph.montototal
                                    ELSE dbo.fnProprePrecio(@IdVenta, mph.articulo, @Renglon, 0)
                                  END precioHijo,
                                  CASE ISNULL(cp.MontoMin, 0)
                                    WHEN 0 THEN CAST(1 AS bit)
                                    ELSE CAST(0 AS bit)
                                  END AS Tipo,
                                  ISNULL(mph.MontoTotal, 0) AS montoTotal,
                                  mph.PiezaMax,
                                  mph.TipoPromocion,
                                  mph.MontoIncremental,
                                  ISNULL(cp.montomin, 0) AS montomin
                                FROM VTASDModuloPromocionArticuloBase mph WITH (NOLOCK)
                                JOIN VTASCCampanaPromocion cp WITH (NOLOCK)
                                  ON mph.IdCampanaPromocion = cp.IdCampanaPromocion
                                JOIN ArtDisponible ad WITH (NOLOCK)
                                  ON mph.Articulo = ad.Articulo
                                JOIN Art ar WITH (NOLOCK)
                                  ON ar.Articulo = mph.Articulo
                                WHERE mph.TipoArticulo = 'HIJO'
                                AND mph.IdCampanaPromocion = @IdPromocion
                                AND cp.Uen = @Uen
                                AND GETDATE() BETWEEN cp.FechaInicio AND cp.fechafin
                                AND cp.Estatus = 'ACEPTADA'
                                GROUP BY mph.IdCampanaPromocion,
                                         mph.Articulo,
                                         mph.PorcDescuento,
                                         ad.Disponible,
                                         cp.Nombre,
                                         ar.Descripcion1,
                                         ar.Familia,
                                         ar.Linea,
                                         cp.MontoMin,
                                         mph.MontoTotal,
                                         mph.PiezaMax,
                                         mph.TipoPromocion,
                                         mph.MontoIncremental,
                                         cp.montomin) a
                                WHERE Numero = 1";
                SqlParameter[] pars =
                {
                    new SqlParameter("@IdVenta", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Renglon", iRenglon)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@IdPromocion", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Uen", ClaseEstatica.Usuario.Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                    {
                        if (double.Parse(item["precioHijo"].ToString()) == 99999.99) continue;

                        //Candado para articculos
                        if (double.Parse(item["montomin"].ToString()) > 0)
                        {
                            if (double.Parse(item["montomin"].ToString()) <
                                double.Parse(item["precioHijo"].ToString()))
                                continue;
                        }
                        else
                        {
                            if (dPrecioArticulo > 0)
                                if (dPrecioArticulo < double.Parse(item["precioHijo"].ToString()))
                                    continue;
                        }


                        listaRegalos.Add(new clsModeloArtPromocion
                        {
                            iIdPromocion = int.Parse(item["iIdPromocion"].ToString()),
                            sArticulo = item["sArticulo"].ToString(),
                            dPorDec = item["dPorDec"] + "%",
                            dPrecioFinal = double.Parse(item["dPorDec"].ToString()) == 100
                                ? 0.01
                                : double.Parse(item["precioHijo"].ToString()) *
                                  (1 - double.Parse(item["dPorDec"].ToString()) / 100),
                            iDisponible = int.Parse(item["iDisponible"].ToString()),
                            sNombreCampaña = item["sNombreCampaña"].ToString(),
                            sDescripcion = item["sDescripcion"].ToString(),
                            sFamilia = item["sFamilia"].ToString(),
                            sLinea = item["sLInea"].ToString(),
                            dPrecioHijo = double.Parse(item["precioHijo"].ToString()),
                            bTipoPromo = bool.Parse(item["Tipo"].ToString()),
                            dMontoTotal = double.Parse(item["montoTotal"].ToString()),
                            iPiezasMaximas = iMaxHijos == 0 ? int.Parse(item["PiezaMax"].ToString()) : iMaxHijos,
                            iCantidad = ArticulosIncluidos?.FirstOrDefault(a =>
                                a.Articulo == item["sArticulo"].ToString() &&
                                a.idPromocion == int.Parse(item["iIdPromocion"].ToString()))?.Cantidad ?? 0,
                            iTipoPromocion = int.Parse(item["TipoPromocion"].ToString()),
                            iMontoIncremental = int.Parse(item["MontoIncremental"].ToString())
                        });
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaRegalos;
        }

        /// <summary>
        ///     Metodo encargado de validar que promociones se activan por monto
        /// </summary>
        /// <param name="dMonto">monto total de la venta</param>
        /// <returns>retorna una lista con los id de campañas que se activan por monto</returns>
        public List<int> obtenerIdPromocionesFacturaGlobal(double dMonto, int iTipoPromo, string sXmlPromociones)
        {
            List<int> listaPorMonto = new List<int>();
            dt = new DataTable();

            try
            {
                string sQuery = @"
                                SET QUOTED_IDENTIFIER ON
                                Declare @Promociones xml = @Promos
                                SELECT
                                    cp.IdCampanaPromocion
                                FROM VTASDModuloPromocionArticuloBase pab WITH (NOLOCK)
                                JOIN VTASCCampanaPromocion cp WITH (NOLOCK)
                                    ON pab.IdCampanaPromocion = cp.IdCampanaPromocion
                                JOIN @Promociones.nodes('Promocion/IdPromocion') AS Prom (p)
                                    ON pab.IdCampanaPromocion = p.value('.','INT')
                                WHERE TipoPromocion = @Tipo
                                AND ISNULL(cp.MontoMin, 10000000) <= @Monto
                                AND cp.Uen = @Uen
                                GROUP BY cp.IdCampanaPromocion,
                                            pab.IdCampanaPromocion
                                ORDER BY pab.IdCampanaPromocion ASC";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Monto", dMonto)
                    {
                        SqlDbType = SqlDbType.Float
                    },
                    new SqlParameter("@Tipo", iTipoPromo)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Uen", ClaseEstatica.Usuario.Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Promos", sXmlPromociones)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPorMonto.Add(int.Parse(row["IdCampanaPromocion"].ToString().Trim()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + " " + ex.Message, "Punto De Venta",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaPorMonto;
        }

        public bool ArticuloProhibidaPorFamilia(string articulo)
        {
            bool bValida = false;
            dt = new DataTable();

            try
            {
                string sQuery = @"
                Select top 1 'Exist'
                from Art with (nolock)
                where Articulo = @Articulo
                  and Familia in (
                    'MOTOCICLETAS')
                  and Linea not in ('CASCOS', 'BATERIAS PARA MOTOCICLETAS', 'CAJAS PARA MOTO', 'LLANTAS PARA MOTO')";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Articulo", articulo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bValida = dr.HasRows;
                    }

                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + " " + ex.Message, "Punto De Venta",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bValida;
        }

        /// <summary>
        ///     Tipo Promocion 4
        /// </summary>
        /// <param name="sArticulo"></param>
        /// <returns></returns>
        public List<clsModeloTipoPromocion> obtenerIdPromocionesPorArticuloPadreDos(string sXml, int iTipoPromo,
            string sXmlPromociones)
        {
            List<clsModeloTipoPromocion> listaPorMonto = new List<clsModeloTipoPromocion>();
            dt = new DataTable();

            try
            {
                string sQuery = @"SET QUOTED_IDENTIFIER ON
                                declare @Articulos xml = @xml, @Promociones xml = @promos 
                                SELECT
                                    pb.Articulo,
                                    pb.IdCampanaPromocion
                                FROM VTASDModuloPromocionArticuloBase pb WITH (NOLOCK)
                                JOIN @Articulos.nodes('Articulos/Articulo') AS Arts (e)
                                    ON pb.articulo = e.value('.', 'VARCHAR(50)')
                                JOIN VTASCCampanaPromocion cp
	                                ON pb.IdCampanaPromocion = cp.IdCampanaPromocion
                                JOIN @Promociones.nodes('Promocion/IdPromocion') AS Prom (p)
                                    ON pb.IdCampanaPromocion = p.value('.','INT')
                                WHERE TipoPromocion = @TipoPromo
                                AND TipoArticulo = 'PADRE'
                                AND cp.Uen = @Uen";

                SqlParameter[] pars =
                {
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@TipoPromo", iTipoPromo)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Uen", ClaseEstatica.Usuario.Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@promos", sXmlPromociones)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPorMonto.Add(new clsModeloTipoPromocion
                        {
                            sArticulo = row["Articulo"].ToString().Trim(),
                            iTipoPromocion = int.Parse(row["IdCampanaPromocion"].ToString().Trim())
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaPorMonto;
        }

        /// <summary>
        ///     Tipo Promocion 5
        /// </summary>
        /// <param name="sXml"></param>
        /// <returns></returns>
        public List<clsModeloTipoPromocion> obtenerArticulosDePromocion(string sXml)
        {
            List<clsModeloTipoPromocion> lsPromociones = new List<clsModeloTipoPromocion>();
            dt = new DataTable();
            try
            {
                string sQuery = @"SET QUOTED_IDENTIFIER ON
                                declare @Articulos xml = @xml;
                                SELECT
                                    DISTINCT ab.Articulo
                                FROM @Articulos.nodes('Articulos/Articulo') AS Arts(e)
                                JOIN VTASDModuloPromocionArticuloBase ab WITH(NOLOCK)
	                                ON ab.Articulo = e.value('.', 'VARCHAR(50)')
                                AND TipoArticulo = 'PADRE'
                                AND TipoPromocion = 5
                                group by ab.Articulo,
                                         ab.IdCampanaPromocion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        lsPromociones.Add(new clsModeloTipoPromocion
                        {
                            sArticulo = row["Articulo"].ToString()
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return lsPromociones;
        }

        public List<clsModeloTipoPromocion> obtenerArticulosDePromocionDetalle(string sXml)
        {
            List<clsModeloTipoPromocion> lsPromociones = new List<clsModeloTipoPromocion>();
            dt = new DataTable();
            try
            {
                string sQuery = @"SET QUOTED_IDENTIFIER ON
                                declare @Articulos xml = @xml;
                                SELECT
                                    ab.Articulo,
                                    ab.IdCampanaPromocion
                                FROM @Articulos.nodes('Articulos/Articulo') AS Arts(e)
                                JOIN VTASDModuloPromocionArticuloBase ab WITH(NOLOCK)
	                                ON ab.Articulo = e.value('.', 'VARCHAR(50)')
                                AND TipoArticulo = 'PADRE'
                                AND TipoPromocion = 5
                                group by ab.Articulo,
                                         ab.IdCampanaPromocion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        lsPromociones.Add(new clsModeloTipoPromocion
                        {
                            sArticulo = row["Articulo"].ToString(),
                            iTipoPromocion = int.Parse(row["IdCampanaPromocion"].ToString())
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return lsPromociones;
        }


        /// <summary>
        ///     tipo 4
        /// </summary>
        /// <param name="iTotalArticulos"></param>
        /// <param name="sXml"></param>
        /// <returns></returns>
        public List<int> obtenerIdPromocionesMontoIncremental(string sXml, double dMontoPadres, int iIdPromo,
            int iTipoPromo, string sXmlPromociones)
        {
            List<int> listaPorMonto = new List<int>();
            dt = new DataTable();

            try
            {
                string sQuery = @"SET QUOTED_IDENTIFIER ON
                                    DECLARE @Articulos xml = @xml, @Promociones xml = @promos ;
                                    SELECT
                                    pb.Articulo,
                                    pb.IdCampanaPromocion
                                FROM VTASDModuloPromocionArticuloBase pb WITH (NOLOCK)
                                JOIN @Articulos.nodes('Articulos/Articulo') AS Arts (e)
                                    ON pb.articulo = e.value('.', 'VARCHAR(50)')
                                JOIN VTASCCampanaPromocion cp
	                                ON pb.IdCampanaPromocion = cp.IdCampanaPromocion
                                JOIN @Promociones.nodes('Promocion/IdPromocion') AS Prom (p)
                                    ON pb.IdCampanaPromocion = p.value('.','INT')
                                WHERE TipoPromocion = @TipoPromo
                                AND pb.IdCampanaPromocion = @IdPromo
                                AND cp.MontoMin <= @MontoPadres
                                AND cp.Uen = @Uen
                                AND TipoArticulo = 'PADRE'";

                SqlParameter[] pars =
                {
                    new SqlParameter("@MontoPadres", dMontoPadres)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@xml", sXml)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@IdPromo", iIdPromo)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@TipoPromo", iTipoPromo)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Uen", ClaseEstatica.Usuario.Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@promos", sXmlPromociones)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPorMonto.Add(int.Parse(row["IdCampanaPromocion"].ToString().Trim()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaPorMonto;
        }

        public List<clsModeloTipoPromocion> obtenerIdPromocionesPorArticulo(int iTotalArticulos, int iIdPromocion,
            string sXmlPromociones)
        {
            List<clsModeloTipoPromocion> listaPorMonto = new List<clsModeloTipoPromocion>();
            dt = new DataTable();

            try
            {
                string sQuery = @"  SET QUOTED_IDENTIFIER ON
                                    declare @Promociones xml = @Promos
                                    SELECT
                                      cp.IdCampanaPromocion
                                    FROM VTASDModuloPromocionArticuloBase pb WITH (NOLOCK)
                                    JOIN VTASCCampanaPromocion cp WITH (NOLOCK)
                                      ON pb.IdCampanaPromocion = cp.IdCampanaPromocion
                                    JOIN @Promociones.nodes('Promocion/IdPromocion') AS Prom (p)
                                        ON pb.IdCampanaPromocion = p.value('.','INT')
                                    WHERE pb.TipoPromocion = 5
                                    AND cp.PzaMin <= @PzaPromocion
                                    AND pb.TipoArticulo = 'PADRE'
                                    AND cp.UEN = @Uen
                                    AND pb.IdCampanaPromocion = @IdPromocion
                                    GROUP BY CP.IdCampanaPromocion";
                SqlParameter[] pars =
                {
                    new SqlParameter("@PzaPromocion", iTotalArticulos)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@IdPromocion", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Uen", ClaseEstatica.Usuario.Uen)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Promos", sXmlPromociones)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPorMonto.Add(new clsModeloTipoPromocion
                        {
                            iTipoPromocion = int.Parse(row["IdCampanaPromocion"].ToString().Trim())
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaPorMonto;
        }


        public bool validarSiEsPorMontoMinimo(int iIdPromocion)
        {
            bool bPromocionValida = false;
            try
            {
                string sQuery =
                    "select MontoMin from VTASCCampanaPromocion with(nolock) where IdCampanaPromocion = @IdPromo and ISNULL(MontoMin,0) > 0";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bPromocionValida = dr.HasRows;
                    }

                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bPromocionValida;
        }

        public int obtenerMontoIncremental(int iIdPromocion)
        {
            int dMontoIncremental = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select CASE MontoIncremental WHEN 0 THEN 1 ELSE MontoIncremental END AS MontoIncremental from VTASCCampanaPromocion with(nolock) where IdCampanaPromocion = @IdPromo and ISNULL(MontoMin,0) > 0";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMontoIncremental = int.Parse(item["MontoIncremental"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dMontoIncremental;
        }

        /// <summary>
        ///     Metodo encargado de validar si la venta aplica para promociones
        /// </summary>
        /// <param name="iIdVenta"></param>
        /// <returns></returns>
        public List<int> validarVentaAplicaPromocion(int iIdVenta)
        {
            dt = new DataTable();
            List<int> listaPromociones = new List<int>();
            try
            {
                //1829: En punto de venta debe de voltear a ver la fecha y hora dada de alta para el inicio y termino de las promociones
                string sQuery = @"
                                SELECT
                                    DISTINCT cp.IdCampanaPromocion
                                FROM Venta v WITH (NOLOCK)
                                JOIN VTASCCampanaPromocionCanalVenta cv WITH (NOLOCK)
                                    ON v.EnviarA = cv.CanalVenta
                                JOIN Condicion cond WITH (NOLOCK)
                                    ON v.Condicion = cond.Condicion
                                JOIN VTASCCampanaPromocionCondicionVenta condve WITH (NOLOCK)
                                    ON cond.IdCondicion = condve.CondicionVenta
                                JOIN VTASCCampanaPromocionSucursal ps WITH (NOLOCK)
                                    ON v.Sucursal = ps.Sucursal
                                JOIN VTASCCampanaPromocion cp WITH (NOLOCK)
                                    ON v.UEN = cp.UEN
                                WHERE v.ID = @Id
                                AND GETDATE() BETWEEN cp.FechaInicio AND cp.fechafin 
                                AND cp.Estatus = 'ACEPTADA'
                                AND cp.IdCampanaPromocion = condve.IdCampanaPromocion
                                AND cp.IdCampanaPromocion = ps.IdCampanaPromocion
                                AND cp.IdCampanaPromocion = cv.IdCampanaPromocion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                foreach (DataRow row in dt.Rows) listaPromociones.Add(int.Parse(row["IdCampanaPromocion"].ToString()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return listaPromociones;
        }

        /// <summary>
        ///     Metodo encargado de obtener el maximo de hijos que se puede llevar una promocion
        /// </summary>
        /// <param name="iIdPromocion">id de la promocion a validar</param>
        /// <returns>retorna el numero maximo de hijos que se puede llevar una promocion</returns>
        public int obtenerMaximoHijos(int iIdPromocion)
        {
            int dMaximoHijos = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT MaxHijos FROM VTASCCampanaPromocion WITH(NOLOCK) WHERE IdCampanaPromocion = @IdPromo";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMaximoHijos = int.Parse(item["MaxHijos"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dMaximoHijos;
        }

        public double obtenerMontoMinimoPromocion(int iIdPromocion)
        {
            double dMontoPorPromocion = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT MontoMin FROM VTASCCampanaPromocion WITH(NOLOCK) WHERE IdCampanaPromocion = @IdPromo";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMontoPorPromocion = double.Parse(item["MontoMin"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dMontoPorPromocion;
        }

        /// <summary>
        ///     Metodo encargado de obtener las piezas minimas para activar una promocion
        /// </summary>
        /// <param name="iIdPromocion">id de la promocion a validar</param>
        /// <returns>retorna el numero de articulos que se requieren para activar una promocion</returns>
        public int obtenerPiezasMinimasPromocion(int iIdPromocion)
        {
            int dMaximoHijos = 0;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT PzaMin FROM VTASCCampanaPromocion WITH(NOLOCK) WHERE IdCampanaPromocion = @IdPromo";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    cmd.Dispose();
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMaximoHijos = int.Parse(item["PzaMin"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dMaximoHijos;
        }

        /// <summary>
        ///     Metodo encargado de validar si una promocion alcanzo el maximo de hijos
        /// </summary>
        /// <param name="iIdPromocion">id de la promocion  validar</param>
        /// <param name="iHijos">hijos actuales de la promociones</param>
        /// <returns>retorna true si aun no cumple con el maximo de hijos de lo contrario false</returns>
        public bool validarPromocionCompleta(int iIdPromocion, int iHijos)
        {
            bool bMaximoHijos = false;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT MaxHijos FROM VTASCCampanaPromocion WITH(NOLOCK) WHERE IdCampanaPromocion = @IdPromo AND MaxHijos > @Hijos";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdPromo", iIdPromocion)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Hijos", iHijos)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bMaximoHijos = dr.HasRows;
                    }

                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bMaximoHijos;
        }

        #endregion
    }
}