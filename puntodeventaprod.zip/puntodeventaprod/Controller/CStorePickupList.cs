﻿//-PrimeraFaseDeAutomatizacion

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CStorePickupList
    {
        public List<MStorePickupList> getPedidosStorePickup()
        {
            List<MStorePickupList> table = new List<MStorePickupList>();

            //-Reserva-Online
            string query = string.Format(@"SELECT
                                            v.IDEcommerce,
                                            v.FechaRegistro,
                                            v.PrecioTotal,
                                            cr.Nombre,
                                            cr.Telefono,
											cr.Correo,
                                            v.SucursalDestino,
                                            vd.Articulo,
                                            ar.Descripcion1 as NomProductos,
                                            SUM(vd.Cantidad) AS Cantidad 
                                            FROM Venta v WITH (NOLOCK) 
                                            INNER JOIN VTASHReservaOnline ro WITH (NOLOCK) 
                                            ON v.IDEcommerce = ro.IdEcommerce 
                                            INNER JOIN TrWDM0285_CteRecoge cr WITH (NOLOCK) 
                                            ON v.IDEcommerce = cr.IdEcommerce 
                                            INNER JOIN VentaD vd WITH (NOLOCK) 
                                            ON v.ID = vd.ID 
                                            INNER JOIN Art ar WITH (NOLOCK) 
                                            ON vd.Articulo = ar.Articulo 
                                            WHERE ro.EstatusReservacion = 'Reservado' 
                                            AND v.SucursalDestino = {0} 
                                            AND ro.FechaReservacion + (SELECT CONVERT(INT,VALOR) FROM tablastd WHERE tablast = 'NumeroDiasReservaOnline') >= GETDATE()
                                            GROUP BY v.IDEcommerce, 
                                            v.FechaRegistro,
                                            v.PrecioTotal,
                                            cr.Nombre,
                                            cr.Telefono,
											cr.Correo,
                                            v.SucursalDestino,
                                            vd.Articulo,
                                            ar.Descripcion1", ClaseEstatica.Usuario.Sucursal);

            using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                SqlDataReader dr = null;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                        {
                            MStorePickupList row = new MStorePickupList();
                            row.idEcommerce = dr[0].ToString();
                            row.fecha = (DateTime)dr[1];
                            row.importe = double.Parse(dr[2].ToString());
                            row.nombre = dr[3].ToString();
                            row.telefono = dr[4].ToString();
                            row.correo = dr[5].ToString();
                            row.sku = dr[7].ToString();
                            row.qty = int.Parse(dr[9].ToString());
                            row.nom_articulos = dr[8].ToString();


                            table.Add(row);
                        }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getPedidosSucursal", "StorePickupList.cs", ex);
                    MessageBox.Show(ex.Message);
                }
            }


            return table;
        }


        public int getNumPedidos()
        {
            int numero = 0;

            //-Reserva-Online
            string sConsulta = string.Format(@"SELECT COUNT(DISTINCT v.idecommerce) AS Total 
FROM Venta v WITH (NOLOCK) 
INNER JOIN VTASHReservaOnline ro WITH (NOLOCK) 
ON v.IDEcommerce = ro.IdEcommerce 
INNER JOIN TrWDM0285_CteRecoge cr WITH (NOLOCK) 
ON v.IDEcommerce = cr.IdEcommerce 
INNER JOIN VentaD vd WITH (NOLOCK) 
ON v.ID = vd.ID 
INNER JOIN Art ar WITH (NOLOCK) 
ON vd.Articulo = ar.Articulo 
WHERE ro.EstatusReservacion = 'Reservado' 
AND v.SucursalDestino = {0} 
AND ro.FechaReservacion + (SELECT CONVERT(INT,VALOR) FROM tablastd WHERE tablast = 'NumeroDiasReservaOnline') >= GETDATE()",
                ClaseEstatica.Usuario.Sucursal);


            using (SqlCommand sqlCommand = new SqlCommand(sConsulta, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                SqlDataReader dr = null;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                            numero = int.Parse(dr[0].ToString());
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getPedidosSucursal", "StorePickupList.cs", ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return numero;
        }
    }
}