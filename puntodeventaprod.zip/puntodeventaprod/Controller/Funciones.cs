﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Reports;
using PuntoVenta.View;
using SortOrder = System.Windows.Forms.SortOrder;

namespace PuntoVenta.Controller
{
    internal class Funciones
    {
        /// <summary>
        ///     Metodo que permite imprimir el reporte PosicionMovimientoVenta
        /// </summary>
        /// <param name="movID"></param>
        /// <param name="mov"></param>
        /// <returns></returns>
        /// Developer: Victor Avila
        /// Date:13/07/2017
        public void FillReportePosicionMov(int idVenta, string mov)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaPosicionMovimiento",
                    ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@IdVenta", idVenta);
                sqlCommand.Parameters.AddWithValue("@Tipo", mov);
                using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    List<PosicionMovimientoData> list = new List<PosicionMovimientoData>();
                    dataTable.Load(sqlDataReader);

                    foreach (DataRow item in dataTable.Rows)
                    {
                        PosicionMovimientoData data = new PosicionMovimientoData();
                        data.MovId = Convert.ToString(item.ItemArray[0].ToString());
                        data.Mov = Convert.ToString(item.ItemArray[1].ToString());
                        data.Estatus = Convert.ToString(item.ItemArray[2].ToString());
                        list.Add(data);
                    }

                    DM0312_ReportePosicionMov enviaReporte = new DM0312_ReportePosicionMov(list, idVenta, mov);
                    enviaReporte.ShowDialog();
                    sqlDataReader.Close();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo que permite imprimir el reporte PosicionMovimientoVenta linea
        /// </summary>
        /// <param name="movID"></param>
        /// <param name="mov"></param>
        /// <returns></returns>
        /// Developer: Erika Perez
        /// Date:13/07/2017
        public void FillReportePosicionMovLinea(int idVenta, string mov)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand("SpVTASReporteMovimientos", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Id", idVenta);
                sqlCommand.Parameters.AddWithValue("@MovimientoInicial", "");
                using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    List<PosicionMovimientoData> list = new List<PosicionMovimientoData>();
                    dataTable.Load(sqlDataReader);

                    foreach (DataRow item in dataTable.Rows)
                    {
                        PosicionMovimientoData data = new PosicionMovimientoData();
                        data.MovId = Convert.ToString(item.ItemArray[0].ToString());
                        data.Mov = Convert.ToString(item.ItemArray[1].ToString());
                        data.Estatus = Convert.ToString(item.ItemArray[2].ToString());
                        list.Add(data);
                    }

                    DM0312_ReportePosicionMov enviaReporte = new DM0312_ReportePosicionMov(list, idVenta, mov);
                    enviaReporte.ShowDialog();
                    sqlDataReader.Close();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        ///     Developer : Victor Avila
        ///     Permite llenar el reporte Detalle Posicion Movimiento
        /// </summary>
        /// <param name="movId"></param>
        public void FillMovPosicion(string movId)
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaPosicionMovimientoDetalle",
                    ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParametre = new SqlParameter("@MovID", SqlDbType.VarChar);
                sqlParametre.Value = movId;
                sqlCommand.Parameters.Add(sqlParametre);
                using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                {
                    DataTable datatable = new DataTable();
                    List<MovPropiedadesData> list = new List<MovPropiedadesData>();
                    datatable.Load(sqlDataReader);
                    foreach (DataRow item in datatable.Rows)
                    {
                        MovPropiedadesData movPropiedadData = new MovPropiedadesData();
                        movPropiedadData.Mov = Convert.ToString(item.ItemArray[0].ToString());
                        movPropiedadData.MovId = Convert.ToString(item.ItemArray[1].ToString());
                        movPropiedadData.Estatus = Convert.ToString(item.ItemArray[2].ToString());
                        movPropiedadData.Proyecto = Convert.ToString(item.ItemArray[3].ToString());
                        movPropiedadData.FechaEmision = Convert.ToString(item.ItemArray[4].ToString());
                        movPropiedadData.Moneda = Convert.ToString(item.ItemArray[5].ToString());
                        movPropiedadData.Nombre = Convert.ToString(item.ItemArray[6].ToString());
                        movPropiedadData.Cliente = Convert.ToString(item.ItemArray[7].ToString());
                        movPropiedadData.Referencia = Convert.ToString(item.ItemArray[8].ToString());
                        movPropiedadData.Concepto = Convert.ToString(item.ItemArray[9].ToString());
                        movPropiedadData.Observaciones = Convert.ToString(item.ItemArray[10].ToString());
                        movPropiedadData.Articulo = Convert.ToString(item.ItemArray[11].ToString());
                        movPropiedadData.SubCuenta = Convert.ToString(item.ItemArray[12].ToString());
                        movPropiedadData.Descripcion1 = Convert.ToString(item.ItemArray[13].ToString());
                        movPropiedadData.Almacen = Convert.ToString(item.ItemArray[14].ToString());
                        movPropiedadData.Cantidad = Convert.ToSingle(item.ItemArray[15].ToString());
                        movPropiedadData.Precio = Convert.ToSingle(item.ItemArray[16].ToString());
                        movPropiedadData.Descuento = Convert.ToSingle(item.ItemArray[17].ToString());
                        movPropiedadData.PrecioImporte = Convert.ToSingle(item.ItemArray[18].ToString());
                        movPropiedadData.Anticipos = Convert.ToSingle(item.ItemArray[19].ToString());
                        movPropiedadData.Importe = Convert.ToSingle(item.ItemArray[20].ToString());
                        movPropiedadData.SumaAnticipos = Convert.ToSingle(item.ItemArray[21].ToString());
                        movPropiedadData.SubTotal = Convert.ToSingle(item.ItemArray[22].ToString());
                        list.Add(movPropiedadData);
                    }

                    DM0312_MovimientoData movPropiedades = new DM0312_MovimientoData(list);
                    movPropiedades.Show();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //TODO WIP(Agregar la barra de Estatus de ser posible esto solo a las vistas)
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }


        /// <summary>
        /// </summary>
        /// <param name="cliente"></param>
        /// <returns></returns>
        public DataSet FillDataGridVentanaEntrada(string cliente)
        {
            DataSet dataSet = new DataSet();
            string query = "SELECT * FROM( " +
                           "SELECT V.Cliente, e.Nombre,  v.FechaEmision ,  ROW_NUMBER()OVER(partition BY v.cliente ORDER BY v.fechaemision DESC )i " +
                           "FROM cte e WITH(NOLOCK)INNER JOIN  Venta v WITH(NOLOCK) ON e.Cliente = V.Cliente WHERE V.Cliente  LIKE  '%" +
                           cliente + "%' OR e.Nombre LIKE '%" + cliente + "%'  " +
                           "GROUP  BY V.Cliente, e.Nombre,  v.FechaEmision ) a WHERE i=1 ORDER BY FechaEmision DESC";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
            }

            return dataSet;
        }

        /// <summary>
        /// </summary>
        /// <param name="forma"></param>
        /// <returns></returns>
        public static List<DM0312_MComentariosVenta> ConsultaComentario(string forma)
        {
            List<DM0312_MComentariosVenta> modelComentario = new List<DM0312_MComentariosVenta>();
            string query =
                "SELECT  id, campo, modulo, comentario FROM DM0312_Comentarios  WITH(NOLOCK) WHERE modulo='" + forma +
                "' ";
            SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
            sqlCommand.CommandType = CommandType.Text;
            SqlDataReader dr = sqlCommand.ExecuteReader();
            try
            {
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MComentariosVenta comentario = new DM0312_MComentariosVenta();
                        comentario.Id = Convert.ToInt32(dr["Id"].ToString());
                        comentario.Campo = dr["Campo"].ToString();
                        comentario.Modulo = dr["Modulo"].ToString();
                        comentario.Comentario = dr["Comentario"].ToString();
                        modelComentario.Add(comentario);
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
            }
            finally
            {
                dr.Close();
            }

            return modelComentario;
        }

        /// <summary>
        ///     Metodo que permite llenar dataGrid pricipal de la forma AyudaAgente
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public DataTable AyudaAgente()
        {
            DataTable list = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            try
            {
                string query = "SELECT Agente.Agente,Agente.Nombre FROM Agente WITH(NOLOCK) WHERE Estatus='alta'";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                adapter.SelectCommand = sqlCommand;
                adapter.Fill(list);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
            }

            return list;
        }

        /// <summary>
        ///     Validacion para telefonos
        /// </summary>
        /// <param name="Telefono">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 02/10/17
        public bool ValidaTelefonos(string Telefono)
        {
            bool telefonoValido = true;
            try
            {
                if (Telefono.Length != 10) return false;

                if (Telefono.Distinct().Count() == 1 && Telefono != "0000000000") return false;

                char[] characters = Telefono.ToCharArray();
                if (characters[0] == '0' && Telefono != "0000000000") return false;

                if (Telefono == "0987654321" || Telefono == "0123456789"
                                             || Telefono == "9876543210" || Telefono == "1234567890")
                    return false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaTelefonos", "Funciones", ex);
                MessageBox.Show(ex.Message);
            }

            return telefonoValido;
        }

        /// <summary>
        ///     Ordena un gridview cuando tiene una lista como datasource
        /// </summary>
        /// <param name="dgv">DataGridView</param>
        /// <param name="columnIndex">int</param>
        /// <param name="ListaObjetos">List<object></param>
        /// <param name="Modelo">Type</param>
        /// Developer: Dan Palacios
        /// Date: 03/10/17
        public void OrderGridview(DataGridView dgv, int columnIndex, List<object> ListaObjetos, Type Modelo)
        {
            if (dgv.Rows.Count > 0)
            {
                int HScroll = dgv.HorizontalScrollingOffset;
                string strColumnName = dgv.Columns[columnIndex].Name;
                SortOrder SystemSortOrder = getSortOrder(dgv, columnIndex);

                ListaObjetos = OrdenarLista(strColumnName, SystemSortOrder, ListaObjetos, Modelo);

                dgv.DataSource = null;
                dgv.DataSource = ListaObjetos;
                dgv.Columns[columnIndex].HeaderCell.SortGlyphDirection = SystemSortOrder;
                dgv.HorizontalScrollingOffset = HScroll;
            }
        }

        public List<object> OrdenarList(string orderName, SortOrder SortOrder, List<object> lista)
        {
            if (SortOrder == SortOrder.Ascending)
                lista = lista.OrderBy(x => x.GetType().GetProperty(orderName).GetValue(x)).ToList();
            else
                lista = lista.OrderByDescending(x => x.GetType().GetProperty(orderName).GetValue(x)).ToList();

            return lista;
        }


        /// <summary>
        ///     Hace el order y retorna la lista referenciada
        /// </summary>
        /// <param name="dgv">DataGridView</param>
        /// <param name="columnIndex">int</param>
        /// <param name="ListaObjetos">ref List<object></param>
        /// <param name="Modelo">Type</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        public void OrderGridview(DataGridView dgv, int columnIndex, ref List<object> ListaObjetos, Type Modelo)
        {
            int[] array = new int[dgv.Columns.Count];
            int count = 0;

            if (dgv.Rows.Count > 0 && ListaObjetos.Count > 0)
            {
                int HScroll = dgv.HorizontalScrollingOffset;
                string strColumnName = dgv.Columns[columnIndex].Name;
                SortOrder SystemSortOrder = getSortOrder(dgv, columnIndex);

                ListaObjetos = OrdenarLista(strColumnName, SystemSortOrder, ListaObjetos, Modelo);
                foreach (DataGridViewColumn item in dgv.Columns)
                {
                    array[count] = item.Width;
                    count++;
                }

                dgv.DataSource = null;
                dgv.DataSource = ListaObjetos;
                dgv.Columns[columnIndex].HeaderCell.SortGlyphDirection = SystemSortOrder;
                dgv.HorizontalScrollingOffset = HScroll;
                for (int i = 0; i < dgv.Columns.Count; i++) dgv.Columns[i].Width = array[i];
            }
        }

        /// <summary>
        ///     Ordena lista de objetos de acuerdo al nombre de la columna y el ordenamiento anterior
        /// </summary>
        /// <param name="orderByString">string</param>
        /// <param name="SortOrder">SortOrder</param>
        /// <param name="lista">List<object></param>
        /// <param name="clase">Type</param>
        /// <returns>List<object></returns>
        /// Developer: Dan Palacios
        /// Date: 03/10/17
        private List<object> OrdenarLista(string orderByString, SortOrder SortOrder, List<object> lista, Type clase)
        {
            PropertyInfo[] propertyInfos = null;
            propertyInfos = clase.GetProperties();

            foreach (PropertyInfo item in propertyInfos)
                if (item != null && item.Name == orderByString)
                {
                    if (SortOrder == SortOrder.Ascending)
                        lista = lista.OrderBy(x => item.GetValue(x)).ToList();
                    else
                        lista = lista.OrderByDescending(x => item.GetValue(x)).ToList();
                    break;
                }

            return lista;
        }


        /// <summary>
        ///     Get the current sort order of the column and return it
        ///     set the new SortOrder to the columns.
        /// </summary>
        /// <param name="dgv">DataGridView</param>
        /// <param name="columnIndex">int</param>
        /// <returns>SortOrder of the current column</returns>
        /// Developer: Dan Palacios
        /// Date: 02/10/17
        public SortOrder getSortOrder(DataGridView dgv, int columnIndex)
        {
            if (dgv.Columns[columnIndex].HeaderCell.SortGlyphDirection == SortOrder.None ||
                dgv.Columns[columnIndex].HeaderCell.SortGlyphDirection == SortOrder.Descending)
            {
                dgv.Columns[columnIndex].HeaderCell.SortGlyphDirection = SortOrder.Ascending;
                return SortOrder.Ascending;
            }

            return SortOrder.Descending;
        }

        /// <summary>
        ///     Ordenar lista por propiedad
        /// </summary>
        /// <param name="dgv_TablaMovimientos">DataGridView</param>
        /// <param name="columnIndex">int</param>
        /// <param name="TempObjects">List<object></param>
        /// <param name="PropiedadAOrdenar">string</param>
        /// Developer: Dan Palacios
        /// Date: 28/11/17
        public void OrdenarLista(DataGridView dgv_TablaMovimientos, int columnIndex, List<object> TempObjects,
            string PropiedadAOrdenar)
        {
            if (dgv_TablaMovimientos.Columns.Count > 0)
            {
                SortOrder order = getSortOrder(dgv_TablaMovimientos, columnIndex);
                TempObjects = OrdenarList(PropiedadAOrdenar, order, TempObjects);
                dgv_TablaMovimientos.DataSource = null;
                dgv_TablaMovimientos.DataSource = TempObjects;
                dgv_TablaMovimientos.Columns[columnIndex].HeaderCell.SortGlyphDirection = order;
            }
        }

        /// <summary>
        ///     Permite verificar la congifuracion de VistaForma por Acceso (Usuario)
        ///     Developer: Victor Avila
        ///     Date : 2017/10/04
        /// </summary>
        /// <param name="acceso"></param>
        /// <returns></returns>
        public static List<DM0312_MVerificaConfiguracionUsuario> VerificaConfiguracionUsuario(string acceso)
        {
            SqlDataReader dr = null;
            List<DM0312_MVerificaConfiguracionUsuario> listModel = new List<DM0312_MVerificaConfiguracionUsuario>();
            string query =
                "SELECT Acceso, Forma, Campo, Estatus FROM DM0312ConfiguracionColumnas  WITH(NOLOCK) WHERE Acceso = '" +
                acceso + "'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MVerificaConfiguracionUsuario model_ = new DM0312_MVerificaConfiguracionUsuario();
                    model_.Acceso = dr["Acceso"].ToString();
                    model_.Forma = dr["Forma"].ToString();
                    model_.Campo = dr["Campo"].ToString();
                    model_.Estatus = Convert.ToBoolean(dr["Estatus"]);
                    listModel.Add(model_);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones", ex);
            }
            finally
            {
                dr.Close();
            }

            return listModel;
        }


        /// <summary>
        ///     Verificar forms abiertos para no abrir mas de dos veces
        ///     Y enviarlos enfrente aplica en los forms no modales
        /// </summary>
        /// <param name="NameForm">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 13/12/17
        public bool CheckFormsOpen(string NameForm)
        {
            bool res = false;

            foreach (Form frm in Application.OpenForms)
                if (frm.Name == NameForm)
                {
                    res = true;
                    frm.BringToFront();
                    //break;
                }

            return res;
        }


        public bool FileExist(string FolderName)
        {
            if (!File.Exists(FolderName))
            {
                MessageBox.Show("No existe la carpeta/archivo indicado");
                return false;
            }

            return true;
        }
    }
}

namespace Conversiones
{
    internal class Conv
    {
        public string enletras(string num)
        {
            string res, dec = "";
            long entero;
            int decimales;
            double nro;

            try
            {
                nro = Convert.ToDouble(num);
            }
            catch
            {
                return "";
            }

            entero = Convert.ToInt64(Math.Truncate(nro));
            decimales = Convert.ToInt32(Math.Round((nro - entero) * 100, 2));
            if (decimales > 0) dec = " CON " + decimales + "/100";

            res = toText(Convert.ToDouble(entero)) + dec;
            return res;
        }

        private string toText(double value)
        {
            string Num2Text = "";
            value = Math.Truncate(value);
            if (value == 0)
            {
                Num2Text = "CERO";
            }
            else if (value == 1)
            {
                Num2Text = "UNO";
            }
            else if (value == 2)
            {
                Num2Text = "DOS";
            }
            else if (value == 3)
            {
                Num2Text = "TRES";
            }
            else if (value == 4)
            {
                Num2Text = "CUATRO";
            }
            else if (value == 5)
            {
                Num2Text = "CINCO";
            }
            else if (value == 6)
            {
                Num2Text = "SEIS";
            }
            else if (value == 7)
            {
                Num2Text = "SIETE";
            }
            else if (value == 8)
            {
                Num2Text = "OCHO";
            }
            else if (value == 9)
            {
                Num2Text = "NUEVE";
            }
            else if (value == 10)
            {
                Num2Text = "DIEZ";
            }
            else if (value == 11)
            {
                Num2Text = "ONCE";
            }
            else if (value == 12)
            {
                Num2Text = "DOCE";
            }
            else if (value == 13)
            {
                Num2Text = "TRECE";
            }
            else if (value == 14)
            {
                Num2Text = "CATORCE";
            }
            else if (value == 15)
            {
                Num2Text = "QUINCE";
            }
            else if (value < 20)
            {
                Num2Text = "DIECI" + toText(value - 10);
            }
            else if (value == 20)
            {
                Num2Text = "VEINTE";
            }
            else if (value < 30)
            {
                Num2Text = "VEINTI" + toText(value - 20);
            }
            else if (value == 30)
            {
                Num2Text = "TREINTA";
            }
            else if (value == 40)
            {
                Num2Text = "CUARENTA";
            }
            else if (value == 50)
            {
                Num2Text = "CINCUENTA";
            }
            else if (value == 60)
            {
                Num2Text = "SESENTA";
            }
            else if (value == 70)
            {
                Num2Text = "SETENTA";
            }
            else if (value == 80)
            {
                Num2Text = "OCHENTA";
            }
            else if (value == 90)
            {
                Num2Text = "NOVENTA";
            }
            else if (value < 100)
            {
                Num2Text = toText(Math.Truncate(value / 10) * 10) + " Y " + toText(value % 10);
            }
            else if (value == 100)
            {
                Num2Text = "CIEN";
            }
            else if (value < 200)
            {
                Num2Text = "CIENTO " + toText(value - 100);
            }
            else if (value == 200 || value == 300 || value == 400 || value == 600 || value == 800)
            {
                Num2Text = toText(Math.Truncate(value / 100)) + "CIENTOS";
            }
            else if (value == 500)
            {
                Num2Text = "QUINIENTOS";
            }
            else if (value == 700)
            {
                Num2Text = "SETECIENTOS";
            }
            else if (value == 900)
            {
                Num2Text = "NOVECIENTOS";
            }
            else if (value < 1000)
            {
                Num2Text = toText(Math.Truncate(value / 100) * 100) + " " + toText(value % 100);
            }
            else if (value == 1000)
            {
                Num2Text = "MIL";
            }
            else if (value < 2000)
            {
                Num2Text = "MIL " + toText(value % 1000);
            }
            else if (value < 1000000)
            {
                Num2Text = toText(Math.Truncate(value / 1000)) + " MIL";
                if (value % 1000 > 0) Num2Text = Num2Text + " " + toText(value % 1000);
            }

            else if (value == 1000000)
            {
                Num2Text = "UN MILLON";
            }
            else if (value < 2000000)
            {
                Num2Text = "UN MILLON " + toText(value % 1000000);
            }
            else if (value < 1000000000000)
            {
                Num2Text = toText(Math.Truncate(value / 1000000)) + " MILLONES ";
                if (value - Math.Truncate(value / 1000000) * 1000000 > 0)
                    Num2Text = Num2Text + " " + toText(value - Math.Truncate(value / 1000000) * 1000000);
            }

            else if (value == 1000000000000)
            {
                Num2Text = "UN BILLON";
            }
            else if (value < 2000000000000)
            {
                Num2Text = "UN BILLON " + toText(value - Math.Truncate(value / 1000000000000) * 1000000000000);
            }

            else
            {
                Num2Text = toText(Math.Truncate(value / 1000000000000)) + " BILLONES";
                if (value - Math.Truncate(value / 1000000000000) * 1000000000000 > 0)
                    Num2Text = Num2Text + " " + toText(value - Math.Truncate(value / 1000000000000) * 1000000000000);
            }

            return Num2Text;
        }


        /// <summary>
        ///     convierte string a double quitando los simbolos de miles
        /// </summary>
        /// <param name="Money">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 13/12/17
        public double ConvertFormatMoney(string Money, bool Message = true)
        {
            if (Money == string.Empty)
                return 0;

            double money = 0;

            string numeroString = Money.Replace("$", "");

            string Numero = numeroString.Replace(",", "");

            try
            {
                money = Convert.ToDouble(Numero, CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                if (Message)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones Value=" + numeroString,
                        ex);
                    MessageBox.Show(ex.Message);
                }
                else
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "Funciones Value=" + numeroString,
                        ex);
                    return money;
                }
            }

            return money;
        }
    }
}