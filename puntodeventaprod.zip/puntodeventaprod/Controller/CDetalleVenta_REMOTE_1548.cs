﻿using iTextSharp.text.pdf;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.Reports;
using PuntoVenta.View;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PuntoVenta.Controller
{
    partial class CDetalleVenta
    {
        public double PuntosRedimidos { get; set; }
        public Funciones funciones = new Funciones();
        protected string RM0847Cont = string.Empty;
        protected string SubModuloVenta = string.Empty;
        string CadenaSiguienteMov = string.Empty;
        public static bool MovimientoGenerado = false;
        public List<string> ListaControles;
        public static bool EsMoto = false;
        public static int PaginadoActual = 0;
        public bool AfectaDesdeTablero = false;
        public bool FromDetalle = false;
        public bool TopArticulosSobrepasado = false;
        DataTable dt;
        public delegate bool ValAfectar(string[] Parametros, ref string msgPrecaucion);

        /// <summary>
        /// Verifica si un movimiento se puede cancelar
        /// </summary>
        /// <param name="recibeSucursal">int</param>
        /// <returns>int</returns>
        /// Developer: Dan Palacios
        /// Date: 27/07/2017
        public int ValidacionCancelacion(int? recibeSucursal, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {

            int BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoNoSePuedeCancelar;
            if (VentasSeleccionadas.Count > 0 && VentasSeleccionadas[PaginadoActual] != null)
            {

                #region declaracion variables

                DateTime FechaSQL = ObtenerFechaSQL();
                DateTime FechaEmision = Convert.ToDateTime(VentasSeleccionadas[PaginadoActual].ff);
                string CadenaMovimiento = VentasSeleccionadas[PaginadoActual].Mov;
                string CadenaEstatus = VentasSeleccionadas[PaginadoActual].Estatus;
                string CadenaTipoMovimiento = VentasSeleccionadas[PaginadoActual].MovTipo;
                string Empresa = "MAVI";
                string Modulo = "VTAS";
                string MovID = VentasSeleccionadas[PaginadoActual].MovId;
                string ID = VentasSeleccionadas[PaginadoActual].ID.ToString();
                string CancelarFactura = ObtenerCampoCancelarFactura(ID);

                int? SucursalOrigen = 0;
                if (VentasSeleccionadas[PaginadoActual].Sucursal != 0)
                {
                    SucursalOrigen = VentasSeleccionadas[PaginadoActual].Sucursal;
                }

                string AnticiposFacturados = string.Empty;
                if (VentasSeleccionadas[PaginadoActual].AnticiposFacturados != null
                    && VentasSeleccionadas[PaginadoActual].AnticiposFacturados != string.Empty)
                {
                    AnticiposFacturados = VentasSeleccionadas[PaginadoActual].AnticiposFacturados;
                }

                #endregion

                #region Factura de otra sucursal

                //Verifica si el movimiento es factura y es de otra sucursal
                if ((CadenaMovimiento == "Factura" || CadenaMovimiento == "Factura VIU") && SucursalOrigen != recibeSucursal)
                {
                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoFacturaDeOtraSucursal;
                }
                else
                {
                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                }

                #endregion

                #region Validacion de movimiento ya cancelado

                //Checar si el movimiento ya esta cancelado
                if (BanderaMovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar)
                {

                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoNoSePuedeCancelar;
                    int EstatusYaCancelado = 0;

                    if (CadenaTipoMovimiento == "VTAS.N")
                    {
                        string query = "SELECT COUNT(*) EstatusYaCancelado FROM Venta WITH (NOLOCK) " +
                            "WHERE Empresa=@Empresa AND OrigenTipo=@Modulo AND Origen=@Mov AND " +
                            "OrigenID=@MovID AND Estatus NOT IN ('SINAFECTAR', 'CANCELADO')";
                        try
                        {
                            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                            SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                            {
                                CommandType = CommandType.Text
                            };
                            sqlCommand.Parameters.AddWithValue("@Empresa", Empresa);
                            sqlCommand.Parameters.AddWithValue("@Modulo", Modulo);
                            sqlCommand.Parameters.AddWithValue("@Mov", CadenaMovimiento);
                            sqlCommand.Parameters.AddWithValue("@MovID", MovID);
                            SqlDataReader dr = sqlCommand.ExecuteReader();
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    EstatusYaCancelado = int.Parse(dr["EstatusYaCancelado"].ToString());
                                }
                            }
                            dr.Close();
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("ValidacionCancelacion", "CDetalleVenta.cs", ex);
                            MessageBox.Show(ex.Message + " function: ValidacionCancelacion, class: CDetalleVenta");
                        }
                    }

                    if (EstatusYaCancelado > 0)
                    {
                        BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoYaCancelado;
                    }
                    else
                    {
                        BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }
                }

                #endregion

                #region movimiento con nota pendiente

                //Checar si el movimiento tiene un nota
                if (BanderaMovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar)
                {
                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoNoSePuedeCancelar;


                    if (CadenaEstatus != "SINAFECTAR" && CadenaEstatus != "EstatusBorrador"
                        && CadenaEstatus != "EstatusPorConfirmar" && (CadenaTipoMovimiento == "VTAS.N" || CadenaTipoMovimiento == "VTAS.FM"))
                    {
                        return (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }
                    else
                    {
                        BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }

                }

                #endregion

                #region venta pendiente

                //venta pendiente
                if (BanderaMovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar)
                {
                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoNoSePuedeCancelar;
                    if (CadenaEstatus == "PENDIENTE" &&
                        (CadenaTipoMovimiento == "VTAS.P" || CadenaTipoMovimiento == "VTAS.S"))
                    {
                        return (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }
                    else
                    {
                        BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }
                }

                #endregion

                #region genera movimiento contrario

                //validacion que contendra el mensaje concatenado para 'seguro que desea cancelar este mov' el cual sera 
                //concatenado con 'esta cancelacion generara otro movimiento contrario'
                if (BanderaMovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar)
                {
                    BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoNoSePuedeCancelar;
                    if (AnticiposFacturados == string.Empty)
                    {
                        AnticiposFacturados = "0";
                    }
                    if (CancelarFactura != "No" & Convert.ToDouble(AnticiposFacturados) != 0.00 & CadenaEstatus != "SINAFECTAR" && CadenaEstatus != "EstatusBorrador" && CadenaEstatus != "EstatusPorConfirmar")
                    {
                        if (CadenaTipoMovimiento == "VTAS.F" || CadenaTipoMovimiento == "VTAS.FAR")
                        {
                            //Checar correctamente cancelarfactura de donde viene
                            if (FechaSQL.Month > FechaEmision.Month || FechaSQL.Year > FechaEmision.Year
                                || (CancelarFactura == "Cambio Dia" && FechaSQL.Day > FechaEmision.Day))
                            {
                                BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoGeneraMovContrario;
                            }
                        }

                    }
                    else
                    {
                        BanderaMovimientoSePuedeCancelar = (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar;
                    }
                }

                #endregion

            }

            return BanderaMovimientoSePuedeCancelar;
        }

        /// <summary>
        /// Cancela un movimiento
        /// </summary>
        /// <param name="ID">string</param>
        /// <param name="Mov">string</param>
        /// <param name="MovID">string</param>
        /// <param name="Usuario">string</param>
        /// <param name="Sucursal">int</param>
        /// <param name="EnviarA">int</param>
        /// <param name="IDECommerce">int</param>
        /// Developer: Dan Palacios
        /// Date: 31/07/2017
        public string CancelarMovimiento(string ID, string Mov, string MovID, string Usuario, int? Sucursal, int EnviarA, string IDECommerce, ref string tipomsgRef)
        {
            string MsgRespuesta = string.Empty;

            #region Cancelar
            string afectar = "Todo";
            if (Mov == "Pedido Mayoreo" && validarCancelarPendiente(int.Parse(ID)))
            {
                afectar = "Seleccion";
            }
            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            try
            {
                SqlCommand sqlCommand = new SqlCommand("spAfectar", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 600
                };
                sqlCommand.Parameters.AddWithValue("@Modulo", "VTAS");
                sqlCommand.Parameters.AddWithValue("@ID", ID);
                sqlCommand.Parameters.AddWithValue("@Accion", "CANCELAR");
                sqlCommand.Parameters.AddWithValue("@Base", afectar);
                sqlCommand.Parameters.AddWithValue("@GenerarMov", DBNull.Value);
                sqlCommand.Parameters.AddWithValue("@Usuario", Usuario);
                sqlCommand.Parameters.AddWithValue("@Estacion", ClaseEstatica.WorkStation.ToString());
                sqlCommand.Parameters.Add(okref);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CancelarMovimiento 1", "CDetalleVenta.cs", ex);
                MsgRespuesta = (ex.Message + " Error function CancelarMovimiento 1, CDetalleVenta.cs");
            }

            if (okref.Value != null && okref.Value.ToString() != string.Empty)
            {
                string CadenaSQL = "SELECT Descripcion, Tipo from MensajeLista WITH (NOLOCK) WHERE Mensaje = @Mensaje";
                string[] parametros = new string[] { "@Mensaje" };
                string[] parametrosAPasar = new string[]
                {
                    okref.Value.ToString()
                };
                string[] Datos = new string[] { "Descripcion", "Tipo" };
                List<string> DatosSQL = EjecutaSQLDataReader(CadenaSQL, parametros, parametrosAPasar, Datos);
                if (DatosSQL.Count > 0 && DatosSQL[1].ToString() != string.Empty && DatosSQL[1].ToString() != "INFO") //&& DatosSQL[1].ToString() != "PRECAUCION"
                {
                    MsgRespuesta = (DatosSQL[0].ToString());
                    tipomsgRef = DatosSQL[1].ToString();
                }
            }

            #endregion


            if (Mov == "Factura" || Mov == "Factura VIU")
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312ReporteServicio", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    sqlCommand.Parameters.AddWithValue("@IDVenta", ID);
                    sqlCommand.Parameters.AddWithValue("@RemoverReporteServicio", true);
                    sqlCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("CancelarMovimiento reporte servicio", "CDetalleVenta.cs", ex);
                    MsgRespuesta = (ex.Message + " Error function CancelarMovimiento reporte servicio, CDetalleVenta.cs");
                }

                //-ReporteDescuento
                try
                {
                    int idReporteDescuento = getIdReporteDescuento(int.Parse(ID));
                    if (idReporteDescuento != 0)
                    {
                        removeReporteDescuento(int.Parse(ID), idReporteDescuento);
                    }

                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("CancelarMovimiento reporte descuento", "CDetalleVenta.cs", ex);
                    MsgRespuesta = (ex.Message + " Error function CancelarMovimiento reporte descuento, CDetalleVenta.cs");
                }

            }

            #region MensajeDev

            string MensajeDev = string.Empty;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MensajeDevMonedero", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@Fac", Mov);
                sqlCommand.Parameters.AddWithValue("@FacID", MovID);
                sqlCommand.Parameters.AddWithValue("@Op", 2);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        MensajeDev = dr["Mensaje"].ToString();
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CancelarMovimiento mensaje dev", "CDetalleVenta.cs", ex);
                MsgRespuesta = (ex.Message + " Error function CancelarMovimiento mensaje dev, class CDetalleVenta.cs");
            }

            if (MensajeDev != string.Empty)
            {
                tipomsgRef = "Monedero";
                MsgRespuesta = (MensajeDev);
            }

            #endregion

            #region CanalMavi

            int Contador = 0;
            if (EnviarA != 0)
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("Select Count(*) Contador From VentasCanalMAVI WITH (NOLOCK) Where ID=@EnviarA and cadena='VENTA VALE'", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.Text
                    };
                    sqlCommand.Parameters.AddWithValue("@EnviarA", EnviarA);
                    SqlDataReader dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            Contador = (int)dr["Contador"];
                        }
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("CancelarMovimiento canalmavi1", "CDetalleVenta.cs", ex);
                    if (ex.Source != null)
                        MsgRespuesta = (ex.Message + " Error function canalmavi1 class: CDetalleVenta.cs");
                }
            }

            if (Contador > 0)
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("SP_DM0244NipValesVta", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    sqlCommand.Parameters.AddWithValue("@ID", ID);
                    sqlCommand.Parameters.AddWithValue("@Vale", "");
                    sqlCommand.Parameters.AddWithValue("@Bandera", "cancelar");
                    sqlCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("CancelarMovimiento canalmavi2", "CDetalleVenta.cs", ex);
                    if (ex.Source != null)
                        MsgRespuesta = (ex.Message + " Error function canalmavi2 class: CDetalleVenta.cs");
                }

            }


            if ((IDECommerce != "0" && !string.IsNullOrEmpty(IDECommerce)) && Mov == "Pedido" && (Sucursal == 41 || Sucursal == 90))
            {
                string ArgumentosPlugin = "VTASPEDIDO " + IDECommerce.ToString() + " " + "CANCELADO";
                EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe", ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
            }

            #endregion

            if ((IDECommerce != "0" && !string.IsNullOrEmpty(IDECommerce)) && (Sucursal == 41 || Sucursal == 90 || Sucursal == 504 || Sucursal == 505) && (Mov == "Solicitud Credito" || Mov == "Analisis Credito"))
            {
                //ejecutarMagento(IDECommerce, "mavi_cancelado");
                string ArgumentosPlugin = "VTASPEDIDO " + IDECommerce + " " + "CANCELADO";
                EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe", ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
            }
            else
            {
                if ((IDECommerce != "0" && !string.IsNullOrEmpty(IDECommerce)) && (Sucursal == 41 || Sucursal == 90 || Sucursal == 504 || Sucursal == 505))
                {
                    string ArgumentosPlugin = "VTASPEDIDO " + IDECommerce.ToString() + " " + "CANCELADO";
                    EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe", ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
                }
            }

            return MsgRespuesta;

        }

        public string AutorizaCancelacionSolicitud(string mov, string cliente)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 cliente FROM DM0287AutorizaCancelacion  WITH(NOLOCK) WHERE  solicitud=(select v.OrigenID from(select origen,origenid from venta WITH(NOLOCK) where mov='Pedido' and movid='" + mov + "')a inner join venta v WITH(NOLOCK) on a.Origen=v.mov and a.OrigenID=v.movid)  and cliente='" + cliente + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = "SI";
                    }
                }
                else
                {
                    estatus = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionValor", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }


        public bool CheckRedencion(int id)
        {
            bool redencion = false;
            SqlDataReader dr = null;
            string query;
            query = ("select top 1 isnull(RedimePtos,0) as RedimePtos from venta WITH (NOLOCK) where id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        redencion = dr.GetBoolean(0);
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CheckRedencion", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return redencion;
        }

        public string BeneficiarioFinal(int id)
        {
            string beneficiario = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("select top 1 ctefinal from venta WITH (NOLOCK) where  id='" + id + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        beneficiario = dr[0].ToString();
                    }
                }
                else
                {
                    beneficiario = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BeneficiarioFinal", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return beneficiario;
        }





        public List<string> DatosEntregaLinea(string idecommerce)
        {
            List<string> datosLinea = new List<string>();
            SqlDataReader dr = null;
            string query = ("select top 1 idecommerce,nombre,correo,telefono from TrWDM0285_CteRecoge a with (nolock) where idecommerce='" + idecommerce + "' ");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        datosLinea.Add(dr[0].ToString());
                        datosLinea.Add(dr[1].ToString());
                        datosLinea.Add(dr[2].ToString());
                        datosLinea.Add(dr[3].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosEntregaLinea", "CDETALLEVENTA", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return datosLinea;
        }

        public string EsAPPDIMA(int id)
        {
            string nominaR = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("select top 1 referencia from venta WITH (NOLOCK) where  id='" + id + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        nominaR = dr[0].ToString();
                    }
                }
                else
                {
                    nominaR = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarMostrarNomina", "DM0312_CPuntoDeVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return nominaR;
        }

        /// <summary>
        /// Checa si el movimiento se puede cancelar
        /// </summary>
        /// <param name="MovTipo">string</param>
        /// <param name="Estatus">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 05/08/17
        public bool ChecarSiSePuedeCancelar(string MovTipo, string Estatus, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            bool MovimientoCancelado = true;

            bool PermisosCancelacion = false;
            if (AccesosDeUsuario.CUsuario.Cancelar)
            {
                PermisosCancelacion = true;
            }
            if (!AccesosDeUsuario.CUsuario.CancelarOtrosMovs)
            {
                if (AccesosDeUsuario.CUsuario.Usuario != VentasSeleccionadas[PaginadoActual].Usuario)
                {
                    PermisosCancelacion = false;
                }
            }

            List<string> lMovTipo = new List<string>
            {
                "VTAS.D",
                "VTAS.DF",
                "VTAS.B",
                "VTAS.F",
                "VTAS.P"
            };
            string MovEstatusEncontrado = lMovTipo.SingleOrDefault(x => x == MovTipo);

            if (
                    (
                        PermisosCancelacion && VentasSeleccionadas[PaginadoActual].MovId != string.Empty
                        &&
                        VentasSeleccionadas[PaginadoActual].MovId != string.Empty
                    )
                    ||
                    MovEstatusEncontrado != null
               )
            {
                string Mov = MovTipo.Substring(0, 4);
                if (Mov == "VTAS")
                {
                    lMovTipo = new List<string>
                    {
                        //se añaden tipo de mov que van a validarse
                        "VTAS.C",
                        "VTAS.CS",
                        "VTAS.R",
                        "VTAS.P",
                        "VTAS.S",
                        "VTAS.VC",
                        "VTAS.VCR",
                        "VTAS.SD"
                    };
                    MovEstatusEncontrado = lMovTipo.SingleOrDefault(x => x == MovTipo);
                    if (MovEstatusEncontrado != null)
                    {
                        //Se añaden los estatus en la lista que se van a validar
                        lMovTipo = new List<string>
                        {
                            "sinafectar",
                            "pendiente"
                        };
                        MovEstatusEncontrado = lMovTipo.SingleOrDefault(x => x == Estatus.ToLower());
                        if (MovEstatusEncontrado == null)
                        {
                            MovimientoCancelado = false;
                        }
                    }
                    else
                    {
                        //Se añaden los estatus en la lista que se van a validar
                        lMovTipo = new List<string>
                        {
                            "sinafectar",
                            "pendiente",
                            "concluido"
                        };
                        MovEstatusEncontrado = lMovTipo.SingleOrDefault(x => x == Estatus.ToLower());
                        if (MovEstatusEncontrado == null)
                        {
                            MovimientoCancelado = false;
                        }
                    }
                }
            }
            else
            {
                MovimientoCancelado = false;
            }


            return MovimientoCancelado;
        }

        public bool SucursalSHMHV()
        {
            string CadenaSQL = "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK)WHERE TablaNum='SUCURSALES SHM' AND Numero=@Suc";
            string[] parametros = { "@Suc" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            string SucursalSHMHV = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, "");
            if (SucursalSHMHV != "0")
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// Obtiene la fecha de sql
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 28/07/2017
        public DateTime ObtenerFechaSQL()
        {
            DateTime SQLDate = new DateTime();
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SELECT GETDATE() SQLDate", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        SQLDate = Convert.ToDateTime(dr["SQLDate"]);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerFechaSQL", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerFechaSQL, class: CDetalleVenta.cs");
            }

            return SQLDate;
        }

        /// <summary>
        /// Campo para saber si la factura ha sido cancelada o no
        /// </summary>
        /// <param name="CadenaIDFactura">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 31/07/2017
        public string ObtenerCampoCancelarFactura(string CadenaIDFactura)
        {
            string CancelarFactura = string.Empty;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SELECT Estatus FROM cxc WITH (NOLOCK) WHERE ID = @IDFactura", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                sqlCommand.Parameters.AddWithValue("@IDFactura", CadenaIDFactura);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr["Estatus"].ToString() == "CANCELADO")
                        {
                            CancelarFactura = "Si";
                        }
                        else
                        {
                            CancelarFactura = "No";
                        }
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCampoCancelarFactura", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerCampoCancelarFactura, CDetalleVenta.cs");
            }

            return CancelarFactura;
        }



        /// <summary>
        /// Obtiene el ID del movimiento origen
        /// </summary>
        /// <param name="ID">int</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 22/11/17
        public string ObtenerMovOrigen(int ID)
        {
            string MovOrigen = "";

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SELECT Origen, OrigenID FROM Venta WITH (NOLOCK) WHERE ID = @ID", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                sqlCommand.Parameters.AddWithValue("@ID", ID);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        MovOrigen = dr["Origen"].ToString() ?? "";
                        MovOrigen = MovOrigen + " " + dr["OrigenID"].ToString() ?? "";
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerMovOrigen", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerMovOrigen, CDetalleVenta.cs");
            }

            return MovOrigen;
        }

        /// <summary>
        /// Obtiene todos los codigos postales
        /// </summary>
        /// <returns>List<CodigosPostales></returns>
        /// Developer: Dan Palacios
        /// Date: 05/08/17
        public List<MCodigosPostales> ObtenerCps()
        {
            List<MCodigosPostales> Cps = new List<MCodigosPostales>();


            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@ObtenerCodigoPostal", true);
                sqlCommand.Parameters.AddWithValue("@Articulo", DBNull.Value);
                sqlCommand.Parameters.AddWithValue("@Almacen", DBNull.Value);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                int Count = 0;
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        MCodigosPostales NuevosDatos = new MCodigosPostales
                        {
                            ID = Count,
                            Colonia = dr["Colonia"].ToString(),
                            CP = dr["CodigoPostal"].ToString(),
                            ColoniaYCodigo = dr["Colonia"].ToString() + " (" + dr["CodigoPostal"].ToString() + ")",
                            Estado = dr["Estado"].ToString(),
                            Delegacion = dr["Delegacion"].ToString()
                        };
                        Cps.Add(NuevosDatos);
                        Count = Count + 1;
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCps", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerCps, class: CDetalleVenta.cs");
            }

            return Cps;
        }

        /// <summary>
        /// Obtiener la bitacora de datos de entrega del cliente seleccionado
        /// </summary>
        /// <param name="IDCliente">string</param>
        /// <param name="IDDatosEntregaSeleccionado">ref string</param>
        /// <param name="IDVenta">string</param>
        /// <returns>List<DatosEntrega></returns>
        /// Developer: Dan Palacios
        /// Date: 05/08/17
        public List<DatosEntrega> ObtenerBitacoraEntregas(string IDCliente, ref string IDDatosEntregaSeleccionado, string IDVenta = "")
        {
            List<DatosEntrega> BitacoraEntregas = new List<DatosEntrega>();

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@ObtenerDatosEntrega", true);
                sqlCommand.Parameters.AddWithValue("@IDCliente", IDCliente);
                sqlCommand.Parameters.AddWithValue("@Articulo", DBNull.Value);
                sqlCommand.Parameters.AddWithValue("@Almacen", DBNull.Value);

                //Se pasa id de venta para saber si ya hay una direccion de las guardadas seleccionada o guardada
                //en VentaEntrega
                if (IDVenta != string.Empty)
                {
                    sqlCommand.Parameters.AddWithValue("@ID", IDVenta);
                }

                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DatosEntrega NuevosDatos = new DatosEntrega
                        {
                            ID = Convert.ToInt32(dr["ID"].ToString().Trim()),
                            IDCliente = IDCliente.Trim(),
                            Direccion = dr["Direccion"].ToString().Trim(),
                            Colonia = dr["Colonia"].ToString().Trim(),
                            Poblacion = dr["Poblacion"].ToString().Trim(),
                            CP = dr["CodigoPostal"].ToString().Trim(),
                            Estado = dr["Estado"].ToString().Trim(),
                            EntreCalles = dr["EntreCalles"].ToString().Trim(),
                            TelefonoMovil = dr["TelefonoMovil"].ToString().Trim(),
                            TelefonoParticular = dr["TelefonoParticular"].ToString().Trim(),
                            Referencia = dr["Referencia"].ToString().Trim(),
                            Seleccion = false,
                            NumExt = dr["NumExt"].ToString().Trim(),
                            NumInt = dr["NumInt"].ToString().Trim()
                        };
                        if (dr["VentaEntregaSeleccionada"].ToString() != "0")
                        {
                            NuevosDatos.Seleccion = true;
                            IDDatosEntregaSeleccionado = dr["ID"].ToString().Trim();
                        }
                        BitacoraEntregas.Add(NuevosDatos);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerBitacoraEntregas", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerBitacoraEntregas, class: CDetalleVenta.cs");
            }

            return BitacoraEntregas;
        }

        /// <summary>
        /// Llena datagrid de bitacora con lista de modelo
        /// </summary>
        /// <param name="BitacoraEntregas">List<DatosEntrega></param>
        /// <param name="dgv_datosEntrega">DataGridView</param>
        /// <param name="InsertCheckColumn">bool</param>
        /// Developer: Dan Palacios
        /// Date: 05/08/17
        public void FillDataGridDatosEntrega(List<DatosEntrega> BitacoraEntregas, ref DataGridView dgv_datosEntrega, int? BitacoraSeleccionada = null)
        {
            dgv_datosEntrega.DataSource = BitacoraEntregas;

            int YScroll = 0;
            bool ScrollMe = true;
            for (int i = 0; i < dgv_datosEntrega.Rows.Count; i++)
            {
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dgv_datosEntrega.Rows[i].Cells[0];
                if (i != BitacoraSeleccionada)
                {
                    chk.Value = false;
                    dgv_datosEntrega.Rows[i].Selected = false;
                    if ((dgv_datosEntrega.Rows.Count - 1) == i)
                    {
                        ScrollMe = false;
                    }
                }
                else
                {
                    chk.Value = true;
                    dgv_datosEntrega.Rows[i].Selected = true;
                    ScrollMe = false;
                }
                if (ScrollMe)
                {
                    YScroll = YScroll + 1;
                }
            }
            if (YScroll <= dgv_datosEntrega.Rows.Count && dgv_datosEntrega.Rows.Count > 0)
            {
                dgv_datosEntrega.FirstDisplayedCell = dgv_datosEntrega.Rows[YScroll].Cells[0];
            }
        }

        /// <summary>
        /// Obtener de la bitacora de entregas que esta seleccionado
        /// </summary>
        /// <param name="IDSeleccionado">string</param>
        /// <param name="BitacoraEntregas">List<DatosEntrega></param>
        /// <returns>int</returns>
        /// Developer: Dan Palacios
        /// Date: 08/08/17
        public int? ObtenerBitacoraSeleccionada(string IDSeleccionado, List<DatosEntrega> BitacoraEntregas)
        {
            int? BitacoraSeleccionada = null;
            if (IDSeleccionado != string.Empty)
            {
                for (int i = 0; i < BitacoraEntregas.Count; i++)
                {
                    if (BitacoraEntregas[i].ID == int.Parse(IDSeleccionado))
                    {
                        BitacoraSeleccionada = i;
                        break;
                    }
                }
            }

            return BitacoraSeleccionada;
        }

        /// <summary>
        /// Guarda los datos de la entrega
        /// </summary>
        /// <param name="selectedRows">DataGridViewSelectedRowCollection</param>
        /// <param name="BitacoraEntregas">List<DatosEntrega></param>
        /// <param name="Parametros">string []</param>
        /// <param name="NuevaEntrega">bool</param>
        /// Developer: Dan Palacios
        /// Date: 09/08/17
        public void GuardarDatosEntrega(DataGridViewSelectedRowCollection selectedRows,
            List<DatosEntrega> BitacoraEntregas, string[] Parametros, int IDVenta, int? Sucursal, bool NuevaEntrega = false)
        {
            //update
            SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure
            };
            sqlCommand.Parameters.AddWithValue("@UpdateDatosEntrega", true);
            if (selectedRows.Count > 0 && selectedRows[selectedRows.Count - 1].Index < BitacoraEntregas.Count && NuevaEntrega)
            {
                sqlCommand.Parameters.AddWithValue("@IDDatosEntrega", BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].ID);
            }
            sqlCommand.Parameters.AddWithValue("@ID", IDVenta);
            sqlCommand.Parameters.AddWithValue("@IDCliente", Parametros[(int)Enums.ParametrosDatosEntrega.IDCliente]);
            sqlCommand.Parameters.AddWithValue("@Direccion", Parametros[(int)Enums.ParametrosDatosEntrega.Direccion]);
            sqlCommand.Parameters.AddWithValue("@Colonia", Parametros[(int)Enums.ParametrosDatosEntrega.Colonia]);
            sqlCommand.Parameters.AddWithValue("@Poblacion", Parametros[(int)Enums.ParametrosDatosEntrega.Poblacion]);
            sqlCommand.Parameters.AddWithValue("@CodigoPostal", Parametros[(int)Enums.ParametrosDatosEntrega.CodigoPostal]);
            sqlCommand.Parameters.AddWithValue("@Estado", Parametros[(int)Enums.ParametrosDatosEntrega.Estado]);
            sqlCommand.Parameters.AddWithValue("@EntreCalles", Parametros[(int)Enums.ParametrosDatosEntrega.EntreCalles]);
            if (Parametros[(int)Enums.ParametrosDatosEntrega.TelefonoParticular] != string.Empty)
            {
                sqlCommand.Parameters.AddWithValue("@TelefonoParticular", Parametros[(int)Enums.ParametrosDatosEntrega.TelefonoParticular]);
            }
            if (Parametros[(int)Enums.ParametrosDatosEntrega.TelefonoMovil] != string.Empty)
            {
                sqlCommand.Parameters.AddWithValue("@TelefonoMovil", Parametros[(int)Enums.ParametrosDatosEntrega.TelefonoMovil]);
            }
            sqlCommand.Parameters.AddWithValue("@Referencia", Parametros[(int)Enums.ParametrosDatosEntrega.Referencia]);

            if (Parametros[(int)Enums.ParametrosDatosEntrega.NumExt] != string.Empty)
            {
                sqlCommand.Parameters.AddWithValue("@NumExt", Parametros[(int)Enums.ParametrosDatosEntrega.NumExt]);
            }

            if (Parametros[(int)Enums.ParametrosDatosEntrega.NumInt] != string.Empty)
            {
                sqlCommand.Parameters.AddWithValue("@NumInt", Parametros[(int)Enums.ParametrosDatosEntrega.NumInt]);
            }
            sqlCommand.Parameters.AddWithValue("@Sucursal", Sucursal);

            var returnParameter = sqlCommand.Parameters.Add("@ReturnVal", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;

            try
            {
                sqlCommand.CommandTimeout = 60;
                sqlCommand.ExecuteNonQuery();

                //Variable de retorno que regresa 1 si el dato ya existe
                var result = returnParameter.Value;
                if (result.ToString() != "0")
                {
                    MessageBox.Show("Información actualizada con éxito", "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Información guardada con éxito", "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarDatosEntrega", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function GuardarDatosEntrega, class: CDetalleVenta.cs");
            }
        }

        /// <summary>
        /// Obtener detalles venta
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>List<string></returns>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        public List<string> ObtenerDetallesVenta(string[] Parametros, ref string CategoriaEnviarA)
        {

            SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaDetalles", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure
            };

            string Mov = Parametros[(int)Enums.ParametrosDetallesVenta.Modulo].Substring(0, 4);
            sqlCommand.Parameters.AddWithValue("@EngancheAnticipo", true);
            sqlCommand.Parameters.AddWithValue("@Mov", Parametros[(int)Enums.ParametrosDetallesVenta.Mov]);
            sqlCommand.Parameters.AddWithValue("@MovID", Parametros[(int)Enums.ParametrosDetallesVenta.MovID]);
            sqlCommand.Parameters.AddWithValue("@Modulo", Mov);
            sqlCommand.Parameters.AddWithValue("@IDVenta", Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]);
            List<string> Detalles = new List<string>();
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr["Enganche"] != null && dr["Enganche"].ToString() != string.Empty && Parametros[(int)Enums.ParametrosDetallesVenta.MovID] != string.Empty)
                        {
                            Detalles.Add(((decimal)dr["Enganche"]).ToString("", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            Detalles.Add("0.00");
                        }
                        if (dr["RedMonedero"] != null && dr["RedMonedero"].ToString() != string.Empty && Parametros[(int)Enums.ParametrosDetallesVenta.MovID] != string.Empty)
                        {
                            Detalles.Add(Convert.ToDouble(dr["RedMonedero"]).ToString());
                        }
                        else
                        {
                            Detalles.Add("");
                        }
                        Detalles.Add(dr["AfectaComisionMavi"].ToString());
                        Detalles.Add(dr["FacDesgloseIva"].ToString());
                        Detalles.Add(dr["AgenteServicio"].ToString());

                        Detalles.Add(dr["Causa"].ToString());
                        Detalles.Add(dr["ServicioTipo"].ToString());
                        Detalles.Add(dr["Observaciones"].ToString());
                        Detalles.Add(dr["Comentarios"].ToString());
                        Detalles.Add(dr["FormaEnvio"].ToString());
                        Detalles.Add(dr["NoCtapago"].ToString());
                        Detalles.Add(dr["Origen"].ToString());
                        Detalles.Add(dr["OrigenID"].ToString());
                        Detalles.Add(dr["ReferenciaOrdenCompra"].ToString());
                        Detalles.Add(dr["Vencimiento"].ToString());
                        Detalles.Add(dr["OrigenTipo"].ToString());
                        Detalles.Add(dr["OrigenTipoMov"].ToString());
                        Detalles.Add(dr["Impuestos"].ToString());
                        Detalles.Add(dr["Importe"].ToString());
                        Detalles.Add(dr["UEN"].ToString());
                        Detalles.Add(dr["DescuentoGlobal"].ToString());
                        Detalles.Add(dr["Sobreprecio"].ToString());
                        Detalles.Add(dr["Retencion"].ToString());
                        Detalles.Add(dr["AnticiposFacturados"].ToString());

                        CategoriaEnviarA = dr["Categoria"].ToString();
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerDetallesVenta", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerDetallesVenta, class: CDetalleVenta.cs");
            }

            return Detalles;
        }

        /// <summary>
        /// Metodo que permite VerificarSucursal para poder llamar el PlugIn Hoja Verde
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Rodolfo Sanchez
        /// Date: 28/08/17
        public bool VerificarSucursal()
        {
            int res = 0;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK)" +
                    " WHERE TablaNum='{0}' and Numero='{1}'", "SUCURSALES SHM", ClaseEstatica.Usuario.sucursal);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        res = Convert.ToInt32(dr[0].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerDetallesVenta", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: ObtenerDetallesVenta class: CDetalleVenta.cs", "Error!");
            }

            finally { if (dr != null) dr.Close(); }

            if (res > 0)
                return true;
            else
                return false;

        }

        /// <summary>
        /// Metodo que permite VerificarSucursal para poder llamar el PlugIn Hoja Verde
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Rodolfo Sanchez
        /// Date: 28/08/17
        public bool VerificarPlugIn()
        {
            int res = 0;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK)" +
                    " WHERE TablaNum='{0}' and Numero={1}", "SUCURSALES RDP", ClaseEstatica.Usuario.sucursal);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        res = Convert.ToInt32(dr[0].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VerificarPlugIn", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: VerificarPlugIn class: CDetalleVenta.cs", "Error!");
            }

            finally { dr.Close(); }

            if (res == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Obtiene el ID y la categoria del canal
        /// </summary>
        /// <param name="Clave">string</param>
        /// <returns>string[]</returns>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        public string[] ObtenerCategoriaCanal(string Clave)
        {
            string[] NuevoString = { "", "" };

            SqlCommand sqlCommand = new SqlCommand("SELECT ID, Categoria FROM VentasCanalMAVI WITH (NOLOCK) WHERE Clave = @Clave", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.Parameters.AddWithValue("@Clave", Clave);

            int IDCanal = 0;
            int CategoriaCanal = 1;
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        NuevoString[IDCanal] = dr["ID"].ToString();
                        NuevoString[CategoriaCanal] = dr["Categoria"].ToString();
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCategoriaCanal", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerCategoriaCanal, class: CDetalleVenta.cs");
            }

            return NuevoString;
        }

        #region Impresion

        /// <summary>
        /// Metodo que permite imprimir el datalle de la Venta
        /// </summary>
        /// <param name="id">int</param>
        /// <param name="dateTime">string</param>
        /// Developer: Victor Avila
        /// Date: 10/08/17
        /// Modification description: Dan Palacios
        /// Modification date: 07/09/17
        /// Modification description: se modifica el sp y ya no retorna una lista
        public void ImpresionMaviCredRelPedXCliente(int id, string dateTime)
        {
            List<MRM0847MaviCredRelPedXClienteRepImp> list = new List<MRM0847MaviCredRelPedXClienteRepImp>();
            //if(!TopArticulosSobrepasado)
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312InformacionReportes", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    sqlCommand.Parameters.AddWithValue("@ID", id);
                    sqlCommand.Parameters.AddWithValue("@Fecha", dateTime);
                    using (SqlDataReader slqDataReader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(slqDataReader);

                        foreach (DataRow item in dataTable.Rows)
                        {
                            MRM0847MaviCredRelPedXClienteRepImp detalleVenta = new MRM0847MaviCredRelPedXClienteRepImp
                            {
                                Id = Convert.ToInt32(item["ID"].ToString()),
                                SucursalVenta = Convert.ToInt32(item["SucursalVenta"]),
                                Nombre = Convert.ToString(item["Nombre"]),
                                Mov = Convert.ToString(item["Mov"]),
                                MovId = Convert.ToString(item["MovID"])
                            };
                            if (item["FechaEmision"] != null && item["FechaEmision"].ToString() != string.Empty)
                            {
                                detalleVenta.FechaEmision = Convert.ToDateTime(item["FechaEmision"]);
                            }
                            if (item["FechaRegistro"] != null && item["FechaRegistro"].ToString() != string.Empty)
                            {
                                detalleVenta.FechaRegistro = Convert.ToDateTime(item["FechaRegistro"]);
                            }
                            detalleVenta.EnviarA = Convert.ToInt32(item["EnviarA"]);
                            detalleVenta.Cliente = Convert.ToString(item["Cliente"]);
                            detalleVenta.NombreCliente = Convert.ToString(item["NombreCliente"]);
                            detalleVenta.DireccionCte = Convert.ToString(item["DireccionCte"]);
                            detalleVenta.EstadoCliente = Convert.ToString(item["EstadoCliente"]);
                            detalleVenta.ColoniaCte = Convert.ToString(item["ColoniaCte"]);
                            detalleVenta.PoblacionCte = Convert.ToString(item["PoblacionCte"]);
                            if (item["CodigoPostalCte"] != null && item["CodigoPostalCte"].ToString() != string.Empty)
                            {
                                detalleVenta.CodigoPostalCte = Convert.ToInt32(item["CodigoPostalCte"]);
                            }

                            detalleVenta.Referencia = Convert.ToString(item["Referencia"]);
                            detalleVenta.OrdernCompra = Convert.ToString(item["OrdenCompra"]);
                            detalleVenta.Observacion = Convert.ToString(item["Observaciones"]);
                            detalleVenta.Condicion = Convert.ToString(item["Condicion"]);
                            detalleVenta.Cadena = Convert.ToString(item["Cadena"]);
                            detalleVenta.NumeroDocumentos = Convert.ToInt32(item["NumeroDocumentos"]);
                            detalleVenta.Agente = Convert.ToString(item["Agente"]);
                            detalleVenta.Situacion = Convert.ToString(item["Situacion"]);
                            detalleVenta.MaviTipoVenta = Convert.ToString(item["MaviTipoVenta"]);
                            detalleVenta.Vencimiento = Convert.ToDateTime(item["Vencimiento"]);
                            detalleVenta.Familia = Convert.ToString(item["Familia"]);
                            detalleVenta.Linea = Convert.ToString(item["Linea"]);
                            if (item["PrecioTotal"] != null && item["PrecioTotal"].ToString() != string.Empty)
                            {
                                detalleVenta.PrecioTotal = Convert.ToSingle(item["PrecioTotal"]);
                            }

                            detalleVenta.Solicito = Convert.ToString(item["Solicito"]);
                            detalleVenta.Comenta = Convert.ToString(item["Comenta"]);
                            if (item["FechaNacimiento"] != null && item["FechaNacimiento"].ToString() != string.Empty)
                            {
                                detalleVenta.FechaNacimiento = Convert.ToDateTime(item["FechaNacimiento"]);
                            }
                            detalleVenta.Telefono = Convert.ToString(item["Telefono"]);
                            detalleVenta.NombreDeArticulos = Convert.ToString(item["NombreDeArticulos"]);
                            detalleVenta.Articulo = Convert.ToString(item["Articulo"]);

                            if (item["ImporteArt"] != null && item["ImporteArt"].ToString() != string.Empty)
                            {
                                detalleVenta.ImporteArt = Convert.ToDouble(item["ImporteArt"]);
                            }

                            if (item["Precio"] != null && item["Precio"].ToString() != string.Empty)
                            {
                                detalleVenta.Precio = Convert.ToSingle(item["Precio"]);
                            }

                            detalleVenta.Cantidad = Convert.ToInt32(item["Cantidad"]);
                            detalleVenta.NombreAgente = Convert.ToString(item["NombreAgente"]);
                            detalleVenta.Usuario = Convert.ToString(item["Usuario"]);
                            detalleVenta.NombreAval = Convert.ToString(item["NombreAval"]);
                            detalleVenta.UsuarioNombre = Convert.ToString(item["UsuarioNombre"]);
                            detalleVenta.ColoniaAval = Convert.ToString(item["ColoniaAval"]);
                            detalleVenta.CodigoPostalAval = Convert.ToString(item["CodigoPostalAval"]);
                            detalleVenta.DireccionAval = Convert.ToString(item["DireccionAval"]);
                            detalleVenta.TelefonosAval = Convert.ToString(item["TelefonosAval"]);
                            detalleVenta.PoblacionAval = Convert.ToString(item["PoblacionAval"]);
                            detalleVenta.EstadoAval = Convert.ToString(item["EstadoAval"]);
                            detalleVenta.Leyenda = Convert.ToString(item["Leyenda"]);
                            detalleVenta.Factor = Convert.ToSingle(item["Factor"]);
                            list.Add(detalleVenta);
                        }
                        DM0312_MaviCredRelPedXClienteRepImp.detalleVenta = list;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ImpresionMaviCredRelPedXCliente", "CDetalleVenta.cs", ex);
                    MessageBox.Show(ex.Message + " function: ImpresionMaviCredRelPedXCliente, class: CDetalleVenta.cs");
                }

                DM0312_MaviCredRelPedXClienteRepImp detalleVentaData = new DM0312_MaviCredRelPedXClienteRepImp();
                detalleVentaData.ShowDialog();
            }
            //else
            //{
            //    MessageBox.Show("No se pueden imprimir mas de 14 artículos");
            //}
        }

        /// <summary>
        /// valida antes de imprimir
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 31/08/17
        public bool ValidacionesImprimir(string[] Parametros, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            bool ImpresionValida = false;

            //-CorreccionBotonImprimirMovSinAfectar
            //string[] movfinales = { "Factura", "Credilana", "Seguro Vida", "Factura VIU", "Prestamo Personal" };


            RM0847Cont = "0";
            string[] ParametrosSQL = { "@Cliente" };
            string[] ParametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] };
            string CadenaSQL = "Select Count(Aval) CountAval from AsignacionAvalesClientesJob WITH(NOLOCK) Where Aval=@Cliente";
            string CadenaALeer = "CountAval";
            int CountAval = int.Parse(EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer));

            //-QuitarINTL603BotonImprimir
            /*
            if (
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura"
                        || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana"
                        || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida"
                        || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU"
                        || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal"
                    )
                    &&
                    CountAval > 0
                )
            {
                ParametrosSQL[0] = "@ID";
                ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                CadenaSQL = "SELECT UEN FROM VENTA WITH(NOLOCK) WHERE ID = @ID";
                CadenaALeer = "UEN";
                string UEN = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
                string ArgumentosPlugin = Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + " "
                + ClaseEstatica.Usuario.usuario + " N 0 S " + UEN;
                EjecutarPlugins(ArgumentosPlugin, "INTL603.exe");
            }
            else
            {
                ImpresionValida = false;
            }*/

            //-CorreccionBotonImprimirMovSinAfectar
            //if (movfinales.Contains(Parametros[(int)Enums.ParametrosDetallesVenta.Mov]) && !Parametros[(int)Enums.ParametrosDetallesVenta.Estatus].ToUpper().Equals("CONCLUIDO"))
            //{
            //    MessageBox.Show("No puede imprimir el movimiento si no esta concluido.");

            //    return ImpresionValida;
            //}

            ParametrosSQL[0] = "@ID";
            ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
            CadenaSQL = "SET ANSI_WARNINGS ON SET ANSI_NULLS ON Select * from  dbo.FN_DM0275ImprimePedido (@ID)";
            CadenaALeer = string.Empty;

            string CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
            string Numero = "1";
            if (CadenaRetorno != string.Empty && CadenaRetorno == "NO")
            {
                Numero = "0";
            }

            CadenaSQL = "Select dbo.FN_ValidaImpresionPedido (@ID)";
            CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
            string DM0275ValidaImpresion = "1";
            if (CadenaRetorno != string.Empty && CadenaRetorno == "1")
            {
                DM0275ValidaImpresion = "0";
            }

            if (DM0275ValidaImpresion == "0" && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Factura" &&
                Numero == "0")
            {
                DialogResult result = MessageBox.Show("NO ES NECESARIO EL PEDIDO ¿DESEA IMPRIMIR?", "Imprimir", MessageBoxButtons.YesNo);
                if (result == DialogResult.No)
                {
                    ImpresionValida = false;
                    return ImpresionValida;
                }
            }

            if (Numero == "1" && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Factura"
                && DM0275ValidaImpresion == "0")
            {
                DialogResult result = MessageBox.Show("NO ES NECESARIO IMPIMIR EL PEDIDO ¿DESEA IMPRIMIR?", "Imprimir", MessageBoxButtons.YesNo);
                if (result == DialogResult.No)
                {
                    ImpresionValida = false;
                    return ImpresionValida;
                }
            }

            string fechaEmision = string.Empty;
            string ListaPedidosNew = string.Empty;

            if ((Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Mayoreo" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Mayoreo"
                )
                ||
                (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido Mayoreo"
                )
                && Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] != "Cancelado")
            {
                ParametrosSQL[0] = "@EnviarA";
                ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA];
                CadenaSQL = "SELECT CATEGORIA FROM VentasCanalMavi WITH(NOLOCK) WHERE ID=@EnviarA";
                CadenaALeer = "Categoria";
                CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                if (CadenaRetorno == "INSTITUCIONES" &&
                    (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito")
                    )
                {
                    //Imprimie sol credito B
                    ImprimirSolCreditoB(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                    fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                    ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                    RM0847Cont = "1";
                }
                else if (CadenaRetorno == "CREDITO MENUDEO" || CadenaRetorno == "CREDILANA EMPRESARIO")
                {
                    ParametrosSQL[0] = "@Cliente";
                    ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.Cliente];
                    CadenaSQL = "SELECT dbo.FN_DM0169ValidarPagares (@Cliente)";
                    CadenaALeer = "";
                    CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                    if (CadenaRetorno == "1")
                    {
                        SubModuloVenta = "RM0847MaviCredRelPedXClienteRepImp";
                        fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                        ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                        RM0847Cont = "0";
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("NO ES NECESARIO IMPIMIR EL PEDIDO ¿DESEA IMPRIMIR?", "Imprimir", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            SubModuloVenta = "RM0847MaviCredRelPedXClienteRepImp";
                            fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                            ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                            RM0847Cont = "0";
                        }
                        else
                        {
                            SubModuloVenta = "RM0847MaviCredRelPedXClienteRepImp";
                            RM0847Cont = "1";
                        }
                    }
                }
                else if (CadenaRetorno == "ASOCIADOS")
                {
                    //Cliente presente
                    ParametrosSQL[0] = "@Id";
                    ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                    CadenaSQL = "SELECT dbo.FnVTASValidarBfPresente (@Id) as clientepresente ";
                    CadenaALeer = "";
                    CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
                    if (CadenaRetorno == "NO")
                    {
                        DialogResult result = MessageBox.Show("NO ES NECESARIO IMPIMIR EL PEDIDO (BF NO PRESENTE) ¿DESEA IMPRIMIR?", "Imprimir", MessageBoxButtons.YesNo, MessageBoxIcon.Question); ;
                        if (result == DialogResult.Yes)
                        {
                            ImprimirSolCreditoF(VentasSeleccionadas[PaginadoActual].ID,
                            VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                            fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                            ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                            RM0847Cont = "1";
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }


                    ParametrosSQL[0] = "@Id";
                    ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                    CadenaSQL = "SELECT CteFinal FROM venta WITH(NOLOCK) where id = @Id";
                    CadenaALeer = "";
                    CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                    if (!string.IsNullOrEmpty(CadenaRetorno))
                    {
                        ParametrosSQL[0] = "@Cliente";
                        ParametrosAPasar[0] = CadenaRetorno;
                        CadenaSQL = "SELECT dbo.FN_DM0169ValidarPagares (@Cliente)";
                        CadenaALeer = "";
                        CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                        if (CadenaRetorno != "1")
                        {
                            DialogResult result = MessageBox.Show("NO ES NECESARIO IMPIMIR EL PEDIDO ¿DESEA IMPRIMIR?", "Imprimir", MessageBoxButtons.YesNo);
                            if (result == DialogResult.Yes)
                            {
                                ImprimirSolCreditoF(VentasSeleccionadas[PaginadoActual].ID,
                                VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                                fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                                ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                                RM0847Cont = "1";
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            ImprimirSolCreditoF(VentasSeleccionadas[PaginadoActual].ID,
                                VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                            fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                            ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                            RM0847Cont = "1";
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    SubModuloVenta = "RM0847MaviCredRelPedXClienteMayRepImp";
                    fechaEmision = Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision];
                    ListaPedidosNew = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                    RM0847Cont = "0";
                }

            }

            ParametrosSQL[0] = "@ID";
            ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA];
            CadenaSQL = "SELECT Cadena FROM VentasCanalMavi WITH(NOLOCK) WHERE ID = @ID";
            CadenaALeer = "Cadena";
            CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

            if ((CadenaRetorno == "VENTA VALE") &&
                    (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido"
                    )
                )
            {
                ParametrosSQL[0] = "@EnviarA";
                ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA];
                CadenaSQL = "SELECT CATEGORIA FROM VentasCanalMavi WITH(NOLOCK) WHERE ID=@EnviarA";
                CadenaALeer = "Categoria";
                CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
            }

            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Auto"
                )
            {

                string ArgumentosPlugin = "VTAS "
                                        + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + " "
                                        + ClaseEstatica.Usuario.usuario + " 1 "
                                        + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                        + ClaseEstatica.WorkStation;
                    EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");

                return false;
            }

            ParametrosSQL[0] = "@Aval";
            ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.Cliente];
            CadenaSQL = "SELECT COUNT(*) CountAsignacion FROM AsignacionAvalesClientesJob WITH(NOLOCK) WHERE Aval = @Aval";
            CadenaALeer = "CountAsignacion";
            CadenaRetorno = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
            if (int.Parse(CadenaRetorno) > 0 &&
                (Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] == "Factura" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] == "Credilana" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] == "Seguro Vida" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] == "Factura VIU" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] == "Prestamo Personal"
                ))
            {
                MessageBox.Show("Informar al cliente que su limite de crédito ha sido disminuido."
                                    + "Es aval de clientes con cuentas vencidas... Ver detalles en el recibo,"
                                    + "parte inferior");
            }
            else
            {
                ImpresionValida = true;
            }

            return ImpresionValida;
        }

        public int SucursalRDP(int sucursal)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format("SELECT COUNT(Numero) TabNum FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum='SUCURSALES RDP' AND CAST(Numero AS INT)=" + sucursal + "");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    valor = int.Parse(dr[0].ToString());
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalRDP", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            dr.Close();
            return valor;
        }
        public bool ValidarCanalVenta(int ventdaId)
        {
            try
            {
                int canal = 0;
                SqlCommand sqlCommand = new SqlCommand(@"SELECT 
	                                                        ISNULL(v.EnviarA, 0) EnviarA
                                                        FROM Venta v
                                                        LEFT JOIN VentasCanalMavi vc
                                                        ON v.EnviarA = vc.ID
                                                        WHERE v.ID = @IdVenta", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@IdVenta", ventdaId);
                var dr = sqlCommand.ExecuteReader();
                if (!dr.HasRows) return false;
                while (dr.Read())
                {
                    canal = int.Parse(dr["EnviarA"].ToString());
                }
                return canal == 80;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Metodo de impresion
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// Developer: Dan Palacios
        /// Date: 13/09/17
        public void Imprimir(string[] Parametros, List<DM0312_MExploradorVenta> VentasSeleccionadas, ref string msgPrecaucion)
        {
            #region variables _globales_
            //SolicitarTelefonoCliente(Parametros);
            string[] ParametrosSQL = { "@Mov" };
            string[] ParametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.Mov] };
            string CadenaSQL = "Select Count(Mov) CountMov from MovTipoCFDFlex WITH(NOLOCK) Where Modulo = 'VTAS' AND Mov = @Mov";
            string CadenaALeer = "CountMov";
            int CountMov = int.Parse(EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer));

            string lineaArticuloSeleccionado = ObtenerLineaArticulo(Parametros[(int)Enums.ParametrosDetallesVenta.ArticuloSeleccionado]);
            ParametrosSQL = new string[] { "@Linea" };
            ParametrosAPasar = new string[] { lineaArticuloSeleccionado };
            CadenaSQL = "SELECT Count(Nombre) ContadorNombre FROM TablaSTD WITH(NOLOCK) " +
                "WHERE TablaSt = 'EXCEPCIONES DM0116 IMPRESION CO' AND Nombre = @Linea";
            CadenaALeer = "ContadorNombre";
            string ContadorNombreTablaStd = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

            bool printed = false;

            #endregion

            if (CountMov > 0)
            {
                ParametrosSQL[0] = "@Usuario";
                ParametrosAPasar[0] = ClaseEstatica.Usuario.usuario;
                CadenaSQL = "Select COUNT(*) CountStd From TablaStd WITH(NOLOCK) where TablaSt='CFD PERFILES P/IMPRESION' and Nombre in (SELECT ACCESO FROM USUARIO WITH (NOLOCK) WHERE Usuario = @Usuario)";
                CadenaALeer = "CountStd";
                int CountStd = int.Parse(EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer));
                if (CountStd > 0)
                {
                    string CadenaTicket = SP_MaviDM0116BuscarCombinacion(Parametros, "4");
                    if (CadenaTicket == "TICKET")
                    {

                        string ArgumentosPlugin = "VTAS "
                                                + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + " "
                                                + ClaseEstatica.Usuario.usuario + " 1 "
                                                + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                                + ClaseEstatica.WorkStation;
                        EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                    }
                    else if (CadenaTicket == "CARTA")
                    {
                        #region Variables a usar en carta

                        ParametrosSQL = new string[] { "@Usuario" };
                        ParametrosAPasar = new string[] { ClaseEstatica.Usuario.usuario };
                        CadenaSQL = "Select Valor From TablaStd WITH(NOLOCK) WHERE TablaSt = 'CFD PERFILES P/IMPRESION' and " +
                            "Nombre in (SELECT ACCESO FROM USUARIO WITH(NOLOCK) WHERE Usuario = @Usuario)";
                        CadenaALeer = "Valor";
                        string ValorTablaStd = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
                        CadenaTicket = SP_MaviDM0116BuscarCombinacion(Parametros, "3");
                        int rightInt = ValorTablaStd.Length - 1;
                        string ValorTablaStdright = ValorTablaStd.Substring(rightInt, 1);

                        ParametrosSQL[0] = "@IDVenta";
                        ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                        CadenaSQL = "SELECT ISNULL(ContImpSimp,0) ContImpSimp FROM venta WITH(NOLOCK) WHERE ID= @IDVenta";
                        CadenaALeer = "ContImpSimp";
                        string ContImpSimp = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                        ParametrosSQL[0] = "@IDVenta";
                        ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                        CadenaSQL = "SELECT ISNULL(ContImpCiego,0) ContImpCiego FROM venta WITH(NOLOCK) WHERE ID= @IDVenta";
                        CadenaALeer = "ContImpCiego";
                        string ContImpCiego = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                        ParametrosAPasar[0] = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                        CadenaSQL = "SELECT ISNULL(ContImpCFD,0) ContImpCFD FROM venta WITH(NOLOCK) WHERE ID= @IDVenta";
                        CadenaALeer = "ContImpCFD";
                        string ContImpCFD = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);

                        #endregion

                        if (ValorTablaStd != string.Empty && ValorTablaStd.Substring(0, 1) == "1")
                        {

                            if (ValorTablaStdright == "1")
                            {
                                #region ValorTablaStdright igual a 1

                                if (CadenaTicket == "111")
                                {

                                    //ReporteImpresora linea 27
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                    if (printed)
                                    {
                                        //ReporteImpresora¿? linea 29
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");

                                        if (printed)
                                        {
                                            //linea 32 - 47
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else if (CadenaTicket == "110")
                                {
                                    //Reporte impresora linea 53
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");

                                    if (printed)
                                    {
                                        //linea 56 - 73
                                        FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else if (CadenaTicket == "101")
                                {
                                    //Reporte impresora linea 77
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                    if (printed)
                                    {
                                        //linea 80 - 96
                                        FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else if (CadenaTicket == "100")
                                {
                                    //linea 101 - 118
                                    FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                }
                                else if (CadenaTicket == "011")
                                {
                                    //Reporte impresora linea 122
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");

                                    //Reporte impresora linea 124
                                    if (printed)
                                    {
                                        ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else if (CadenaTicket == "010")
                                {
                                    //Reporte impresora linea 129
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                }
                                else if (CadenaTicket == "001")
                                {
                                    //Reporte impresora linea 134
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                }

                                #endregion
                            }
                            else
                            {
                                #region ValorTablaStdright diferente a 1


                                if (CadenaTicket == "111")
                                {
                                    if (int.Parse(ContImpSimp) == 0)
                                    {
                                        //Reporte impresora linea 148
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                    }
                                    else
                                    {
                                        //Reporte impresora linea 148
                                        msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                        msgPrecaucion = string.Empty;
                                    }

                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 156
                                        if (printed)
                                        {
                                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                            msgPrecaucion = string.Empty;
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }

                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //linea 164 - 181
                                        if (printed)
                                        {
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas, msgPrecaucion);
                                            msgPrecaucion = string.Empty;
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                }
                                else if (CadenaTicket == "110")
                                {
                                    if (int.Parse(ContImpSimp) == 0)
                                    {
                                        //Reporte impresora linea 190
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }

                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //linea 198 - 215
                                        if (printed)
                                        {
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas, msgPrecaucion);
                                            msgPrecaucion = "";
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                }
                                else if (CadenaTicket == "101")
                                {
                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 224
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }

                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //linea 232 - 249
                                        if (printed)
                                        {
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas, msgPrecaucion);
                                            msgPrecaucion = "";
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                }
                                else if (CadenaTicket == "100")
                                {
                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //linea 258 - 275
                                        FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas);
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        FacturaMAVIMayoreo12Imp(ContadorNombreTablaStd, Parametros, VentasSeleccionadas, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }
                                }
                                else if (CadenaTicket == "011")
                                {
                                    if (int.Parse(ContImpSimp) == 0)
                                    {
                                        //Reporte impresora linea 284
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }

                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 292
                                        if (printed)
                                        {
                                            printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                            msgPrecaucion = "";
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                }
                                else if (CadenaTicket == "010")
                                {
                                    if (int.Parse(ContImpSimp) == 0)
                                    {
                                        //Reporte impresora linea 302
                                        if (printed)
                                        {
                                            printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }
                                }
                                else if (CadenaTicket == "001")
                                {
                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 312
                                        if (printed)
                                        {
                                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        if (printed)
                                        {
                                            msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                            msgPrecaucion = "";
                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }
                                }

                                #endregion
                            }
                        }
                        else if (ValorTablaStdright == "1")
                        {
                            #region ValorTablaStdright igual a 1

                            if (CadenaTicket == "111")
                            {
                                //Reporte impresora linea 330
                                printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");

                                if (printed)
                                {
                                    //Reporte impresora linea 332
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                }
                                else
                                {
                                    return;
                                }

                                if (printed)
                                {
                                    //Reporte impresora linea 334
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "110")
                            {
                                //Reporte impresora linea 339
                                printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                if (printed)
                                {
                                    //Reporte impresora linea 341
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "101")
                            {
                                //Reporte impresora linea 346
                                printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                if (printed)
                                {
                                    //Reporte impresora linea 348
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "100")
                            {
                                //Reporte impresora linea 353
                                ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                            }
                            else if (CadenaTicket == "011")
                            {
                                //Reporte impresora linea 358
                                printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                if (printed)
                                {
                                    //Reporte impresora linea 360
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "010")
                            {
                                //Reporte impresora linea 365
                                ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                            }
                            else if (CadenaTicket == "001")
                            {
                                //Reporte impresora linea 370
                                ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                            }

                            #endregion
                        }
                        else
                        {
                            #region ValorTablaStdright diferente a 1

                            if (CadenaTicket == "111")
                            {
                                if (int.Parse(ContImpSimp) == 0)
                                {
                                    //Reporte impresora linea 384
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                    msgPrecaucion = "";
                                }

                                if (printed)
                                {
                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 392
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }

                                    if (printed)
                                    {
                                        if (int.Parse(ContImpCFD) == 0)
                                        {
                                            //Reporte impresora linea 400
                                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                        }
                                        else
                                        {
                                            msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                                            msgPrecaucion = "";
                                        }
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "110")
                            {
                                if (int.Parse(ContImpSimp) == 0)
                                {
                                    //Reporte impresora linea 410
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                    msgPrecaucion = "";
                                }

                                if (printed)
                                {
                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //Reporte impresora linea 418
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "101")
                            {
                                if (int.Parse(ContImpCiego) == 0)
                                {
                                    //Reporte impresora linea 428
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                    msgPrecaucion = "";
                                }

                                if (printed)
                                {
                                    if (int.Parse(ContImpCFD) == 0)
                                    {
                                        //Reporte impresora linea 436
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else if (CadenaTicket == "100")
                            {
                                if (int.Parse(ContImpCFD) == 0)
                                {
                                    //Reporte impresora linea 446
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'CFD' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                                    msgPrecaucion = "";
                                }
                            }
                            else if (CadenaTicket == "011")
                            {
                                if (int.Parse(ContImpSimp) == 0)
                                {
                                    //Reporte impresora linea 456
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                    msgPrecaucion = "";
                                }

                                if (printed)
                                {
                                    if (int.Parse(ContImpCiego) == 0)
                                    {
                                        //Reporte impresora linea 464
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                    }
                                    else
                                    {
                                        msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                        printed = ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                        msgPrecaucion = "";
                                    }
                                }
                            }
                            else if (CadenaTicket == "010")
                            {
                                if (int.Parse(ContImpSimp) == 0)
                                {
                                    //Reporte impresora linea 474
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "2");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 2, msgPrecaucion);
                                    msgPrecaucion = "";
                                }
                            }
                            else if (CadenaTicket == "001")
                            {
                                if (int.Parse(ContImpCiego) == 0)
                                {
                                    //Reporte impresora linea 484
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3);
                                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "1");
                                }
                                else
                                {
                                    msgPrecaucion = "Este reporte 'Copia embarque' ya fue impreso. Su perfil de usuario no cuenta con privilegios para poder hacer una reimpresión del mismo.";
                                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 3, msgPrecaucion);
                                    msgPrecaucion = "";
                                }
                            }

                            #endregion
                        }
                    }
                }
            }
            else if (VentasSeleccionadas[PaginadoActual].Mov == "Credilana" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Prestamo Personal" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Seguro Vida" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Seguro Auto")
            {

                //Reporte Impresora 504
                //Reporte Impresora 505
                if (SubModuloVenta == "RM0847MaviCredRelPedXClienteRepImp")
                {
                    ImpresionMaviCredRelPedXCliente(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"));
                    ImpresionMaviCredRelPedXCliente(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"));
                }
                else if (SubModuloVenta == "RM0847MaviCredRelPedXClienteMayRepImp")
                {
                    ImprimirMaviCredXClienteMay(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                    ImprimirMaviCredXClienteMay(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                }

            }
            else if (RM0847Cont == "0")
            {
                //Reporte Impresora 509
                if (SubModuloVenta == "RM0847MaviCredRelPedXClienteRepImp")
                {
                    ImpresionMaviCredRelPedXCliente(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"));
                }
                else if (SubModuloVenta == "RM0847MaviCredRelPedXClienteMayRepImp")
                {
                    ImprimirMaviCredXClienteMay(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yyyy-MM-dd"), VentasSeleccionadas);
                }
                else
                {
                    //Impresion default
                    ReporteVenta rVenta = new ReporteVenta();
                    rVenta.Show();
                }
            }

        }

        /// <summary>
        /// Obtener linea de articulo
        /// </summary>
        /// <param name="Articulo">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 01/09/17
        protected string ObtenerLineaArticulo(string Articulo)
        {
            string Linea = string.Empty;
            SqlCommand comm = new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure
            };
            comm.Parameters.AddWithValue("@Articulo", Articulo);
            try
            {
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Linea = dr["Linea"].ToString();
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerLineaArticulo", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: ObtenerLineaArticulo, class: CDetalleVenta.cs");
            }
            return Linea;
        }

        /// <summary>
        /// Short method to SP_MaviDM0116BuscarCombinacion
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 01/09/17
        protected string SP_MaviDM0116BuscarCombinacion(string[] Parametros, string Combinacion)
        {
            string[] ParametrosSQL = new string[]
            {
                "@Fase",
                "@Id",
                "@Sucursal",
                "@Mov",
                "@MovID",
                "@Condicion",
                "@Categoria"
            };
            string[] ParametrosAPasar = new string[]
            {
                Combinacion,
                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal],
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov],
                Parametros[(int)Enums.ParametrosDetallesVenta.MovID],
                Parametros[(int)Enums.ParametrosDetallesVenta.Condicion],
                Parametros[(int)Enums.ParametrosDetallesVenta.Categoria]
            };
            string CadenaSQL = "SP_MaviDM0116BuscarCombinacion";
            string CadenaALeer = string.Empty;
            string CadenaTicket = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer, true);

            return CadenaTicket;
        }

        /// <summary>
        /// Consecutivo sp
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 01/09/17
        protected void SpConsecutivoImpresion(string IDVenta, string Consecutivo)
        {
            string[] ParametrosSQL = new string[]
                                    {
                                        "@ID",
                                        "@TComp"
                                    };
            string[] ParametrosAPasar = new string[]
                                    {
                                        IDVenta,
                                        Consecutivo
                                    };
            string CadenaSQL = "spConsecutivoImpresion";
            EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, null, true);
        }

        /// <summary>
        /// metodo que se repite varias veces en impresion
        /// </summary>
        /// <param name="ContadorNombreTablaStd">string</param>
        /// <param name="Parametros">string[]</param>
        /// Developer: Dan Palacios
        /// Date: 15/09/17
        protected void FacturaMAVIMayoreo12Imp(string ContadorNombreTablaStd, string[] Parametros, List<DM0312_MExploradorVenta> VentasSeleccionadas, string msgPrecaucion = "")
        {
            if (int.Parse(ContadorNombreTablaStd) > 0)
            {
                //Reporte impresora¿? linea 34
                if (msgPrecaucion == "")
                {
                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                    SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                }
                else
                {
                    ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                    msgPrecaucion = "";
                }
            }
            else
            {
                string MaviCombinacion2 = SP_MaviDM0116BuscarCombinacion(Parametros, "2");
                if (MaviCombinacion2 == "0")
                {
                    //Reporte impresora ¿? linea 38
                    if (msgPrecaucion == "")
                    {
                        ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                        SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                    }
                    else
                    {
                        ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                        msgPrecaucion = "";
                    }
                }
                else
                {
                    string[] ParametrosSQL = new string[] { "@Mov", "@MovID" };
                    string[] ParametrosAPasar =
                        new string[]
                        {
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov],
                            Parametros[(int)Enums.ParametrosDetallesVenta.MovID]
                        };
                    string CadenaSQL = "Select Sum(A.Saldo) As Saldo From CxcPendiente A WITH(NOLOCK) Where A.PadreMavi = " +
                        " @Mov and A.PadreIdMavi = @MovID Group By A.PadreMavi, A.PadreIDMavi";
                    string CadenaALeer = "Saldo";
                    string SaldoPendiente = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer);
                    if (Convert.ToDouble(MaviCombinacion2) >= Convert.ToDouble(SaldoPendiente))
                    {
                        //Reporte impresora linea 45
                        if (msgPrecaucion == "")
                        {
                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1);
                            SpConsecutivoImpresion(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta], "3");
                        }
                        else
                        {
                            ImprimirMFacturaMayoreo(VentasSeleccionadas[PaginadoActual].ID, 1, msgPrecaucion);
                            msgPrecaucion = "";
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Obtiene CAT de funcion FN_RM0847TasaInternaRetorno
        /// </summary>
        /// <param name="numeroDocumentos">int</param>
        /// <param name="articulo">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 06/09/17
        public MTasaInternaRetorno ObtenerTasaInterna(int numeroDocumentos, string articulo)
        {
            MTasaInternaRetorno TasaInterna = new MTasaInternaRetorno();
            SqlCommand sqlCommand = new SqlCommand("SELECT CAT, Tasa, Contado, Credito, PagoCiclo" +
                " FROM FN_RM0847TasaInternaRetorno('" + numeroDocumentos.ToString() + "', '" + articulo + "')", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        TasaInterna.Cat = dr["Cat"].ToString();
                        TasaInterna.Tasa = dr["Tasa"].ToString();
                        if (dr["Contado"] != null && dr["Contado"].ToString() != string.Empty)
                        {
                            TasaInterna.Contado = Convert.ToDouble(dr["Contado"]).ToString("0.00");
                        }
                        else
                        {
                            TasaInterna.Contado = dr["Contado"].ToString();
                        }
                        if (dr["Credito"] != null && dr["Credito"].ToString() != string.Empty)
                        {
                            TasaInterna.Credito = Convert.ToDouble(dr["Credito"]).ToString("0.00");
                        }
                        else
                        {
                            TasaInterna.Credito = dr["Credito"].ToString();
                        }
                        if (dr["PagoCiclo"] != null && dr["PagoCiclo"].ToString() != string.Empty)
                        {
                            TasaInterna.PagoCiclo = Convert.ToDouble(dr["PagoCiclo"]).ToString("0.00");
                        }
                        else
                        {
                            TasaInterna.PagoCiclo = dr["PagoCiclo"].ToString();
                        }
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerTasaInterna", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerTasaInterna, class: CDetalleVenta.cs");
            }

            return TasaInterna;
        }

        /// <summary>
        /// obtiene cat promedio
        /// </summary>
        /// <param name="Mov">string</param>
        /// <param name="MovID">string</param>
        /// <param name="precioTotal">double</param>
        /// <param name="numeroDocumentos">int</param>
        /// <param name="condicion">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 06/09/17
        public string ObtenerCatPromedioSP_RM0847CatVersion2(string Mov, string MovID, double precioTotal, int numeroDocumentos, string condicion)
        {
            string CadenaSQL = "SP_RM0847CatVersion2";
            string CadenaALeer = "CatPromedio";
            string[] ParametrosSQL = new string[] { "@Mov", "@id", "@PrecioCredito", "@condicion", "@Cond" };
            string[] ParametrosAPasar = new string[]
                    {
                        Mov, MovID, precioTotal.ToString(), numeroDocumentos.ToString(), condicion
                    };
            string CatPromedio = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer, true);

            return CatPromedio;
        }

        /// <summary>
        /// obtiene DAPeriodo
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 06/09/17
        public string ObtenerDAPeriodo(string condicion)
        {
            string CadenaSQL = "SELECT DAPeriodo FROM Condicion WITH(NOLOCK) WHERE Condicion=@Condicion";
            string CadenaALeer = "DAPeriodo";
            string[] ParametrosSQL = new string[] { "@Condicion" };
            string[] ParametrosAPasar = new string[] { condicion };
            string DAPeriodo = EjecutaComandosSQL(CadenaSQL, ParametrosSQL, ParametrosAPasar, CadenaALeer).Trim();
            return DAPeriodo;
        }

        /// <summary>
        /// Obtener info cat
        /// </summary>
        /// Developre: Dan Palacios
        /// Date: 06/09/17
        public MInfoCat ObtenerInfoCat()
        {
            MInfoCat InfoCat = new MInfoCat();
            SqlCommand sqlCommand = new SqlCommand("SELECT Comisiones, CalculoInteres, Bonificacion " +
                "FROM RM0847InfoCat WITH(NOLOCK) WHERE id=1", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        InfoCat.Comisiones = dr["Comisiones"].ToString();
                        InfoCat.CalculoIntereses = dr["CalculoInteres"].ToString();
                        InfoCat.Bonificacion = dr["Bonificacion"].ToString();
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerInfoCat", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerInfoCat, class: CDetalleVenta.cs");
            }

            return InfoCat;
        }

        /// <summary>
        /// obtiene mov final segun familia
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 07/09/17
        public string MovFinalSegunFamilia(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            string CadenaSQL = "SELECT dbo.fnMovFinalSegunFamilia_MAVI('" + VentasSeleccionadas[PaginadoActual].ID.ToString() + "')";
            string CadenaALeer = "";
            string fnMovFinalSegunFamilia_MAVI = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            return fnMovFinalSegunFamilia_MAVI;
        }

        /// <summary>
        /// Llena info para impresion solicitud credito f
        /// </summary>
        /// <param name="ID">int</param>
        /// <param name="Fecha">string</param>
        /// Developer: Dan Palacios
        /// Date: 08/09/17
        public void ImprimirSolCreditoF(int ID, string Fecha, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            List<MRM0847FSolCredito> SolCreditoFDetalles = new List<MRM0847FSolCredito>();
            //if(!TopArticulosSobrepasado)
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("SP_MaviRM0847FSolCredVntVale", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    sqlCommand.Parameters.AddWithValue("@ID", ID);
                    sqlCommand.Parameters.AddWithValue("@Fecha", Fecha);
                    using (SqlDataReader dr = sqlCommand.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRM0847FSolCredito MRM0847FSolCreditoDetalle = new MRM0847FSolCredito
                                {
                                    ID = dr["ID"].ToString(),
                                    SucursalVenta = dr["SucursalVenta"].ToString(),
                                    Nombre = dr["Nombre"].ToString(),
                                    Mov = dr["Mov"].ToString(),
                                    MovID = dr["MovID"].ToString(),
                                    FechaEmision = dr["FechaEmision"].ToString(),
                                    FechaRegistro = dr["FechaRegistro"].ToString(),
                                    EnviarA = dr["EnviarA"].ToString(),
                                    Cliente = dr["Cliente"].ToString(),
                                    NombreCliente = dr["NombreCliente"].ToString(),
                                    DireccionCte = dr["DireccionCte"].ToString(),
                                    Cruces = dr["Cruces"].ToString(),
                                    RFC = dr["RFC"].ToString(),
                                    EstadoCliente = dr["EstadoCliente"].ToString(),
                                    ColoniaCte = dr["ColoniaCte"].ToString(),
                                    PoblacionCte = dr["PoblacionCte"].ToString(),
                                    CodigoPostalCte = dr["CodigoPostalCte"].ToString(),
                                    NombreClienteCF = dr["NombreClienteCF"].ToString(),
                                    ApellidoPaternoCF = dr["ApellidoPatClienteCF"].ToString(),
                                    ApellidoMatClienteCF = dr["ApellidoMatClienteCF"].ToString(),
                                    DireccionCteCF = dr["DireccionCteCF"].ToString(),
                                    CrucesCF = dr["CrucesCF"].ToString(),
                                    RFCCF = dr["RFCCF"].ToString(),
                                    CorreoCF = dr["CorreoCF"].ToString(),
                                    EstadoClienteCF = dr["EstadoClienteCF"].ToString(),
                                    ColoniaCteCF = dr["ColoniaCteCF"].ToString(),
                                    PoblacionCteCF = dr["PoblacionCteCF"].ToString(),
                                    CodigoPostalCteCF = dr["CodigoPostalCteCF"].ToString(),
                                    TelefonoCF = dr["TelefonoCF"].ToString(),
                                    Conyuge = dr["Conyuge"].ToString(),
                                    Referencia = dr["Referencia"].ToString(),
                                    OrdenCompra = dr["OrdenCompra"].ToString(),
                                    Observaciones = dr["Observaciones"].ToString(),
                                    Condicion = dr["Condicion"].ToString(),
                                    Cadena = dr["Cadena"].ToString(),
                                    NumeroDocumentos = dr["NumeroDocumentos"] != null ? Convert.ToInt32(dr["NumeroDocumentos"]) : 0,
                                    Agente = dr["Agente"].ToString(),
                                    Situacion = dr["Situacion"].ToString(),
                                    MaviTipoVenta = dr["MaviTipoVenta"].ToString(),
                                    Vencimiento = dr["Vencimiento"] != null && dr["Vencimiento"].ToString() != string.Empty ? Convert.ToDateTime(dr["Vencimiento"]).ToString("dd/MM/yyyy") : null,
                                    Familia = dr["Familia"].ToString(),
                                    Linea = dr["Linea"].ToString(),
                                    PrecioTotal = dr["PrecioTotal"] != null ? "$ " + Convert.ToDouble(dr["PrecioTotal"]).ToString("0.00") : "$ 0.00",
                                    DblPrecioTotal = dr["PrecioTotal"] != null ? Convert.ToDouble(dr["PrecioTotal"]) : 0,
                                    Solicito = dr["Solicito"].ToString(),
                                    Comenta = dr["Comenta"].ToString(),
                                    FechaNacimiento = dr["FechaNacimiento"] != null && dr["FechaNacimiento"].ToString() != string.Empty ? Convert.ToDateTime(dr["FechaNacimiento"]).ToString("dd/MM/yyyy") : null,
                                    Telefono = dr["Telefono"].ToString(),
                                    Articulo = dr["Articulo"].ToString(),
                                    NombreDeArticulos = dr["NombreDeArticulos"].ToString(),
                                    ImporteArt = dr["ImporteArt"] != null ? "$ " + Convert.ToDouble(dr["ImporteArt"]).ToString("0.00") : "$ 0.00",
                                    Precio = dr["Precio"].ToString(),
                                    DblPrecio = dr["Precio"] != null ? Convert.ToDouble(dr["Precio"]) : 0,
                                    Cantidad = dr["Cantidad"] != null ? Convert.ToInt32(dr["Cantidad"]) : 0,
                                    NombreAgente = dr["NombreAgente"].ToString(),
                                    Usuario = dr["Usuario"].ToString(),
                                    UsuarioNombre = dr["UsuarioNombre"].ToString(),
                                    Leyenda = dr["Leyenda"].ToString(),
                                    Factor = dr["Factor"].ToString(),
                                    Quincenas = dr["Quincenas"].ToString(),
                                    IDSol = dr["IDSol"].ToString(),
                                    MovIDSol = dr["MovIDSol"].ToString(),
                                    IDFin = dr["IDFin"].ToString()
                                };
                                SolCreditoFDetalles.Add(MRM0847FSolCreditoDetalle);
                                DM0312_SolCreditoF.SolCreditoFDetalles = SolCreditoFDetalles;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ImprimirSolCreditoF", "CDetalleVenta.cs", ex);
                    MessageBox.Show(ex.Message + " function ImprimirSolCreditoF, class: CDetalleVenta.cs");
                }

                DM0312_SolCreditoF ReporteDM0312_SolCreditoF = new DM0312_SolCreditoF(VentasSeleccionadas);
                ReporteDM0312_SolCreditoF.ShowDialog();
            }
            //else
            //{
            //    MessageBox.Show("No se pueden imprimir mas de 8 articulos");
            //}
        }

        /// <summary>
        /// Llena info para impresion solicitud credito B
        /// </summary>
        /// <param name="ID">int</param>
        /// <param name="Fecha">string</param>
        /// Developer: Dan Palacios
        /// Date: 08/09/17
        public void ImprimirSolCreditoB(int ID, string Fecha, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_BSolCreditoInsPisoRep.SolCreditoBDetalles = new List<MRM0847BSolCredito>();

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviRM0847BSolCreditoInsPisoRep", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@ID", ID);
                sqlCommand.Parameters.AddWithValue("@Fecha", Fecha);
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            MRM0847BSolCredito MBSolCreditoInsPisoRepDetalle = new MRM0847BSolCredito
                            {
                                MovID = dr["MovID"].ToString(),
                                FechaEmision = dr["FechaEmision"].ToString(),
                                Cliente = dr["Cliente"].ToString(),
                                Observaciones = dr["Observaciones"].ToString(),
                                Condicion = dr["Condicion"].ToString(),
                                Agente = dr["Agente"].ToString(),
                                Situacion = dr["Situacion"].ToString(),
                                SucursalVenta = dr["SucursalVenta"].ToString(),
                                MaviTipoVenta = dr["MaviTipoVenta"].ToString(),
                                Vencimiento = dr["Vencimiento"].ToString(),
                                PrecioTotal = dr["PrecioTotal"] != null ? Convert.ToDouble(dr["PrecioTotal"]) : 0,
                                Solicito = dr["Solicito"].ToString(),
                                Comenta = dr["Comenta"].ToString(),
                                Enviara = dr["Enviara"].ToString(),
                                Referencia = dr["Referencia"].ToString(),
                                OrdenCompra = dr["OrdenCompra"].ToString(),
                                Precio = dr["Precio"].ToString(),
                                FechaRegistro = dr["FechaRegistro"].ToString(),
                                ID = dr["ID"].ToString(),
                                Mov = dr["Mov"].ToString(),
                                FechaNacimiento = dr["FechaNacimiento"] != null && dr["FechaNacimiento"].ToString() != string.Empty ? Convert.ToDateTime(dr["FechaNacimiento"]).ToString("dd/MM/yyyy") : null,
                                Telefono = dr["Telefono"].ToString(),
                                NombreDeArticulos = dr["NombreDeArticulos"].ToString(),
                                ImporteArt = dr["ImporteArt"] != null ? Convert.ToDouble(dr["ImporteArt"]) : 0,
                                Cantidad = dr["Cantidad"] != null ? Convert.ToInt32(dr["Cantidad"]) : 0,
                                NombreAgente = dr["NombreAgente"].ToString(),
                                Usuario = dr["Usuario"].ToString(),
                                Cadena = dr["Cadena"].ToString(),
                                Nombre = dr["Nombre"].ToString(),
                                NombreCliente = dr["NombreCliente"].ToString(),
                                DireccionCte = dr["DireccionCte"].ToString(),
                                EstadoCliente = dr["EstadoCliente"].ToString(),
                                ColoniaCte = dr["ColoniaCte"].ToString(),
                                PoblacionCte = dr["PoblacionCte"].ToString(),
                                CodigoPostalCte = dr["CodigoPostalCte"].ToString(),
                                Articulo = dr["Articulo"].ToString(),
                                UsuarioNombre = dr["UsuarioNombre"].ToString(),
                                NumeroDocumentos = dr["NumeroDocumentos"] != null ? Convert.ToInt32(dr["NumeroDocumentos"]) : 0,
                                Leyenda = dr["Leyenda"].ToString(),
                                Factor = dr["Factor"].ToString(),
                                Familia = dr["Familia"].ToString(),
                                Linea = dr["Linea"].ToString(),
                                Cruces = dr["Cruces"].ToString(),
                                RFC = dr["RFC"].ToString(),
                                Estado = dr["Estado"].ToString(),
                                AvalNombres = dr["AvalNombres"].ToString(),
                                AvalDomicilio = dr["AvalDomicilio"].ToString(),
                                AvalCruces = dr["AvalCruces"].ToString(),
                                AvalColonia = dr["AvalColonia"].ToString(),
                                AvalMpio = dr["AvalMpio"].ToString(),
                                AvalEmpresa = dr["AvalEmpresa"].ToString(),
                                AvalJefe = dr["AvalJefe"].ToString(),
                                AvalDomLabora = dr["AvalDomLabora"].ToString(),
                                AvalRFC = dr["AvalRFC"].ToString(),
                                AvalTelefono = dr["AvalTelefono"].ToString(),
                                AvalExtLabora = dr["AvalExtLabora"].ToString(),
                                AvalEdad = dr["AvalEdad"].ToString(),
                                AvalCP = dr["AvalCP"].ToString(),
                                AvalPuesto = dr["AvalPuesto"].ToString(),
                                AvalAntiguedad = dr["AvalAntiguedad"].ToString(),
                                AvalCollabora = dr["AvalCollabora"].ToString(),
                                Recom01Nombre = dr["RECOM01NOMBRE"].ToString(),
                                Recom01Domicilio = dr["Recom01Domicilio"].ToString(),
                                Recom01Mpio = dr["Recom01Mpio"].ToString(),
                                Recom01Parentesco = dr["Recom01Parentesco"].ToString(),
                                Recom01Telefono = dr["Recom01Telefono"].ToString(),
                                Recom01Colonia = dr["Recom01Colonia"].ToString(),
                                Recom02Nombre = dr["Recom02Nombre"].ToString(),
                                Recom02Domicilio = dr["Recom02Domicilio"].ToString(),
                                Recom02Mpio = dr["Recom02Mpio"].ToString(),
                                Recom02Parentesco = dr["Recom02Parentesco"].ToString(),
                                Recom02Telefono = dr["Recom02Telefono"].ToString(),
                                Recom02Colonia = dr["Recom02Colonia"].ToString(),
                                Conyuge = dr["Conyuge"].ToString(),
                                InstColonia = dr["InstColonia"].ToString(),
                                InstCruces = dr["InstCruces"].ToString(),
                                InstDomicilio = dr["InstDomicilio"].ToString(),
                                InstMpio = dr["InstMpio"].ToString(),
                                InstTelefono = dr["InstTelefono"].ToString(),
                                Quincenas = dr["Quincenas"].ToString(),
                                AvalPaterno = dr["AvalPaterno"].ToString(),
                                AvalMaterno = dr["AvalMaterno"].ToString(),
                                AvalTelLabora = dr["AvalTelLabora"].ToString(),
                                IDSol = dr["IDSol"].ToString(),
                                MovIDSol = dr["MovIDSol"].ToString(),
                                MovSol = dr["MovSol"].ToString(),
                                IDFin = dr["IDFin"].ToString()
                            };
                            DM0312_BSolCreditoInsPisoRep.SolCreditoBDetalles.Add(MBSolCreditoInsPisoRepDetalle);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ImprimirSolCreditoB", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function ImprimirSolCreditoB, class: CDetalleVenta.cs");
            }

            DM0312_BSolCreditoInsPisoRep BSolCreditoInsPisoRep = new DM0312_BSolCreditoInsPisoRep(VentasSeleccionadas);
            BSolCreditoInsPisoRep.ShowDialog();

        }

        /// <summary>
        /// Llena info para impresion FacturaMaviMayoreo
        /// </summary>
        /// <param name="ID">int</param>
        /// <param name="DM0116Fase">int</param>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        public bool ImprimirMFacturaMayoreo(int ID, int DM0116Fase, string msgPrecaucion = "")
        {
            DM0312_FacturaMAVIMayoreo12Imp.FacturaMaviMayoreo = new List<MFacturaMAVIMayoreo12Imp>();
            string doc = "";
            string custodia = "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand("spFacturaMAVI", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@ID", ID);
                sqlCommand.Parameters.AddWithValue("@Formato", DM0116Fase);
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            MFacturaMAVIMayoreo12Imp MFacturaMAVIMayoreo12Imp = new MFacturaMAVIMayoreo12Imp
                            {
                                ID = Convert.ToInt32(dr["ID"]),
                                IDMod = dr["IDMod"].ToString()
                            };
                            if (dr["NSucursal"] != null && dr["NSucursal"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.NSucursal = Convert.ToInt32(dr["NSucursal"]);
                            }
                            MFacturaMAVIMayoreo12Imp.SucVta = dr["SucVta"] != null ? Convert.ToInt32(dr["SucVta"]) : 0;
                            MFacturaMAVIMayoreo12Imp.FMov = dr["FMov"].ToString();
                            MFacturaMAVIMayoreo12Imp.FMovID = dr["FMovID"].ToString();
                            MFacturaMAVIMayoreo12Imp.Codigo = dr["Codigo"].ToString();
                            MFacturaMAVIMayoreo12Imp.Condicion = dr["Condicion"].ToString();
                            MFacturaMAVIMayoreo12Imp.NCanalVenta = dr["NCanalVenta"].ToString();
                            MFacturaMAVIMayoreo12Imp.Importe = dr["Importe"] != null ? Convert.ToDouble(dr["Importe"]) : 0;
                            MFacturaMAVIMayoreo12Imp.Impuestos = dr["Impuestos"] != null ? Convert.ToDouble(dr["Impuestos"]) : 0;
                            MFacturaMAVIMayoreo12Imp.FormaPago = dr["FormaPago"].ToString();
                            MFacturaMAVIMayoreo12Imp.FormaEnvio = dr["FormaEnvio"].ToString();
                            MFacturaMAVIMayoreo12Imp.Observaciones = dr["Observaciones"].ToString();
                            MFacturaMAVIMayoreo12Imp.AlmNom = dr["AlmNom"].ToString();
                            MFacturaMAVIMayoreo12Imp.CodigoAgente = dr["CodigoAgente"].ToString();
                            MFacturaMAVIMayoreo12Imp.CanalVenta = dr["CanalVenta"].ToString();
                            MFacturaMAVIMayoreo12Imp.Agente = dr["Agente"].ToString();
                            MFacturaMAVIMayoreo12Imp.PMov = dr["PMov"].ToString();
                            MFacturaMAVIMayoreo12Imp.PMovID = dr["PMovID"].ToString();
                            MFacturaMAVIMayoreo12Imp.SucNom = dr["SucNom"].ToString();
                            MFacturaMAVIMayoreo12Imp.SDireccion = dr["SDireccion"].ToString();
                            MFacturaMAVIMayoreo12Imp.SNumero = dr["SNumero"].ToString();
                            MFacturaMAVIMayoreo12Imp.SColonia = dr["SColonia"].ToString();
                            MFacturaMAVIMayoreo12Imp.SCodigoPostal = dr["SCodigoPostal"].ToString();
                            MFacturaMAVIMayoreo12Imp.SDelegacion = dr["SDelegacion"].ToString();
                            MFacturaMAVIMayoreo12Imp.SEstado = dr["SEstado"].ToString();
                            MFacturaMAVIMayoreo12Imp.SPais = dr["SPais"].ToString();
                            MFacturaMAVIMayoreo12Imp.SRFC = dr["SRFC"].ToString();
                            MFacturaMAVIMayoreo12Imp.Cliente = dr["Cliente"].ToString();
                            MFacturaMAVIMayoreo12Imp.DirCte = dr["DirCte"].ToString();
                            MFacturaMAVIMayoreo12Imp.CDireccion = dr["CDireccion"].ToString();
                            MFacturaMAVIMayoreo12Imp.CNumero = dr["CNumero"].ToString();
                            MFacturaMAVIMayoreo12Imp.CCodigoPostal = dr["CCodigoPostal"].ToString();
                            MFacturaMAVIMayoreo12Imp.CEntre = dr["CEntre"].ToString();
                            MFacturaMAVIMayoreo12Imp.CColonia = dr["CColonia"].ToString();
                            MFacturaMAVIMayoreo12Imp.CDelegacion = dr["CDelegacion"].ToString();
                            MFacturaMAVIMayoreo12Imp.CEstado = dr["CEstado"].ToString();
                            MFacturaMAVIMayoreo12Imp.VDireccion = dr["VDireccion"].ToString();
                            MFacturaMAVIMayoreo12Imp.VNumero = dr["VNumero"].ToString();
                            MFacturaMAVIMayoreo12Imp.VColonia = dr["VColonia"].ToString();
                            MFacturaMAVIMayoreo12Imp.VCodigoPostal = dr["VCodigoPostal"].ToString();
                            MFacturaMAVIMayoreo12Imp.VRef = dr["VRef"].ToString();
                            MFacturaMAVIMayoreo12Imp.VDelegacion = dr["VDelegacion"].ToString();
                            MFacturaMAVIMayoreo12Imp.VEstado = dr["VEstado"].ToString();
                            MFacturaMAVIMayoreo12Imp.Articulo = dr["Articulo"].ToString();
                            MFacturaMAVIMayoreo12Imp.Tipo = dr["Tipo"].ToString();
                            MFacturaMAVIMayoreo12Imp.SerieLote = dr["SerieLote"].ToString();
                            MFacturaMAVIMayoreo12Imp.PropiedadSerie = dr["PropiedadSerie"].ToString();
                            MFacturaMAVIMayoreo12Imp.Pedimento = dr["Pedimento"].ToString();
                            MFacturaMAVIMayoreo12Imp.Color = dr["Color"].ToString();
                            MFacturaMAVIMayoreo12Imp.Modelo = dr["Modelo"].ToString();
                            MFacturaMAVIMayoreo12Imp.FechaAduana = dr["FechaAduana"].ToString();
                            MFacturaMAVIMayoreo12Imp.Aduana = dr["Aduana"].ToString();
                            MFacturaMAVIMayoreo12Imp.Comentarios = dr["Comentarios"].ToString();
                            MFacturaMAVIMayoreo12Imp.RutaEmbarque = dr["RutaEmbarque"].ToString();
                            MFacturaMAVIMayoreo12Imp.Plazo = dr["Plazo"].ToString();
                            MFacturaMAVIMayoreo12Imp.PrimerPago = dr["PrimerPago"] != null && dr["PrimerPago"].ToString() != string.Empty ? Convert.ToDateTime(dr["PrimerPago"]).ToString("dd/MMM/yyyy") : null;
                            MFacturaMAVIMayoreo12Imp.Precio = dr["Precio"] != null ? Convert.ToDouble(dr["Precio"]) : 0;
                            MFacturaMAVIMayoreo12Imp.Cantidad = dr["Cantidad"].ToString();
                            MFacturaMAVIMayoreo12Imp.GeneraDoc = dr["GeneraDoc"].ToString();
                            if (dr["ImporteAbono"] != null && dr["ImporteAbono"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.ImporteAbono = Convert.ToDouble(dr["ImporteAbono"]);
                            }
                            MFacturaMAVIMayoreo12Imp.Telefono = dr["Telefono"].ToString();
                            MFacturaMAVIMayoreo12Imp.CRFC = dr["CRFC"].ToString();
                            MFacturaMAVIMayoreo12Imp.ArtDescripcion = dr["ArtDescripcion"].ToString();
                            MFacturaMAVIMayoreo12Imp.FechaEmision = dr["FechaEmision"].ToString();
                            MFacturaMAVIMayoreo12Imp.CantidadM = dr["CantidadM"] != null ? Convert.ToInt32(dr["CantidadM"]) : 0;
                            MFacturaMAVIMayoreo12Imp.Sello = dr["sello"].ToString();
                            MFacturaMAVIMayoreo12Imp.Nocertificado = dr["nocertificado"].ToString();
                            MFacturaMAVIMayoreo12Imp.Cadenaoriginal = dr["cadenaoriginal"].ToString();
                            MFacturaMAVIMayoreo12Imp.Aprobacion = dr["aprobacion"].ToString();
                            MFacturaMAVIMayoreo12Imp.Mayor12meses = dr["mayor12meses"].ToString();
                            MFacturaMAVIMayoreo12Imp.Desglosarimpuestos = dr["desglosarimpuestos"].ToString();
                            MFacturaMAVIMayoreo12Imp.FacdesgloseIVA = dr["facdesgloseIVA"].ToString();
                            MFacturaMAVIMayoreo12Imp.Unidad = dr["unidad"].ToString();
                            MFacturaMAVIMayoreo12Imp.Fecha = dr["fecha"].ToString();
                            MFacturaMAVIMayoreo12Imp.Estatus = dr["estatus"].ToString();
                            if (dr["Retencion"] != null && dr["Retencion"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.Retencion = Convert.ToDouble(dr["Retencion"]);
                            }
                            MFacturaMAVIMayoreo12Imp.PorcentajeImp = dr["PorcentajeImp"].ToString();
                            MFacturaMAVIMayoreo12Imp.EsQuince = dr["EsQuince"].ToString();
                            MFacturaMAVIMayoreo12Imp.HayRetencion = dr["HayRetencion"].ToString();
                            MFacturaMAVIMayoreo12Imp.HayDesglose = dr["HayDesglose"].ToString();
                            MFacturaMAVIMayoreo12Imp.Total = dr["Total"].ToString();
                            if (dr["ImporteFactor"] != null && dr["ImporteFactor"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.ImporteFactor = Convert.ToDouble(dr["ImporteFactor"]);
                            }
                            MFacturaMAVIMayoreo12Imp.PrecioTotal = dr["PrecioTotal"] != null ? Convert.ToDouble(dr["PrecioTotal"]) : 0;
                            MFacturaMAVIMayoreo12Imp.Vencimiento = dr["Vencimiento"].ToString();
                            MFacturaMAVIMayoreo12Imp.MovAnticipo = dr["MovAnticipo"].ToString();
                            if (dr["SaldoAnticipo"] != null && dr["SaldoAnticipo"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.SaldoAnticipo = Convert.ToDouble(dr["SaldoAnticipo"]);
                            }
                            MFacturaMAVIMayoreo12Imp.ContImpCiego = dr["ContImpCiego"].ToString();
                            MFacturaMAVIMayoreo12Imp.ContImpCFD = dr["ContImpCFD"].ToString();
                            MFacturaMAVIMayoreo12Imp.ContImpSimp = dr["ContImpSimp"].ToString();
                            MFacturaMAVIMayoreo12Imp.LeyendaN = dr["LeyendaN"].ToString();
                            MFacturaMAVIMayoreo12Imp.LeyendaN2 = dr["LeyendaN2"].ToString();
                            MFacturaMAVIMayoreo12Imp.FactorN = dr["FactorN"].ToString();
                            if (dr["SucursalDestino"] != null && dr["SucursalDestino"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.SucursalDestino = Convert.ToInt32(dr["SucursalDestino"]);
                            }
                            MFacturaMAVIMayoreo12Imp.Categoria = dr["Categoria"].ToString();
                            MFacturaMAVIMayoreo12Imp.Web = dr["Web"].ToString();
                            if (dr["SaldoFact"] != null && dr["SaldoFact"].ToString() != string.Empty)
                            {
                                MFacturaMAVIMayoreo12Imp.SaldoFact = Convert.ToDouble(dr["SaldoFact"]);
                            }
                            else
                            {
                                MFacturaMAVIMayoreo12Imp.SaldoFact = 0;
                            }
                            MFacturaMAVIMayoreo12Imp.CteTel = dr["CteTel"].ToString();
                            MFacturaMAVIMayoreo12Imp.UEN = dr["UEN"].ToString();
                            MFacturaMAVIMayoreo12Imp.Linea = dr["Familia"].ToString();
                            MFacturaMAVIMayoreo12Imp.Descripcion9 = dr["Descripcion9"].ToString();
                            MFacturaMAVIMayoreo12Imp.DANumeroDocumentos = dr["DANumeroDocumentos"].ToString();
                            MFacturaMAVIMayoreo12Imp.ImpComentarios = dr["ImpComentarios"].ToString();
                            MFacturaMAVIMayoreo12Imp.MetodoPago = dr["MetodoPago"].ToString();
                            MFacturaMAVIMayoreo12Imp.CuentaPago = dr["CuentaPago"].ToString();
                            MFacturaMAVIMayoreo12Imp.Letra = dr["Letra"].ToString();
                            MFacturaMAVIMayoreo12Imp.Letra2 = dr["Letra2"].ToString();
                            MFacturaMAVIMayoreo12Imp.Formato = dr["Formato"].ToString();
                            MFacturaMAVIMayoreo12Imp.IDCXC = dr["IDCXC"].ToString();
                            MFacturaMAVIMayoreo12Imp.BuenFin = dr["BuenFin"].ToString();
                            MFacturaMAVIMayoreo12Imp.BuenFin2 = dr["BuenFin2"].ToString();
                            MFacturaMAVIMayoreo12Imp.BFID = dr["BFID"].ToString();
                            MFacturaMAVIMayoreo12Imp.ESBF = dr["ESBF"].ToString();
                            MFacturaMAVIMayoreo12Imp.Factor = dr["Factor"].ToString();
                            MFacturaMAVIMayoreo12Imp.TelefonoVtaEntrega = dr["TelefonoVtaEntrega"].ToString();
                            MFacturaMAVIMayoreo12Imp.IDCXCBarra = CreateBarCode128(dr["IDCXC"].ToString());

                            MFacturaMAVIMayoreo12Imp.Documento = DocumentosFacturaMayoreo(dr["FMovID"].ToString());
                            doc = DocumentosFacturaMayoreo(dr["FMovID"].ToString());

                            // GESSY 1206 Agregar el Campo de Custodia en el reporte
                            MFacturaMAVIMayoreo12Imp.Custodia = FacturaMayoreoEnCustodia(dr["FMovID"].ToString());//"FACTURA EN CUSTODIA";//DocumentosFacturaMayoreo(dr["FMovID"].ToString());
                            custodia = FacturaMayoreoEnCustodia(dr["FMovID"].ToString());

                            DM0312_FacturaMAVIMayoreo12Imp.FacturaMaviMayoreo.Add(MFacturaMAVIMayoreo12Imp);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FacturaMaviMayoreo", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function FacturaMaviMayoreo, class: CDetalleVenta.cs");
            }

            foreach (MFacturaMAVIMayoreo12Imp MFacturaMAVIMayoreo12Imp in DM0312_FacturaMAVIMayoreo12Imp.FacturaMaviMayoreo)
            {
                MFacturaMAVIMayoreo12Imp.MontoImpuesto = Convert.ToDouble(ObtenerImpuesto(MFacturaMAVIMayoreo12Imp.Articulo));
                MFacturaMAVIMayoreo12Imp.IVAArticulo = CalcularIVA(MFacturaMAVIMayoreo12Imp.MontoImpuesto);
                MFacturaMAVIMayoreo12Imp.ImpuestoBase = ObtenerImpuestoBase(MFacturaMAVIMayoreo12Imp.IDMod);
            }

            bool VistaPrevia = false;
            if (msgPrecaucion != string.Empty)
            {
                MessageBox.Show(msgPrecaucion);
                VistaPrevia = true;
            }
            DM0312_FacturaMAVIMayoreo12Imp FacturaMAVIMayoreo12Imp = new DM0312_FacturaMAVIMayoreo12Imp(VistaPrevia, doc, custodia);
            FacturaMAVIMayoreo12Imp.ShowDialog();

            return FacturaMAVIMayoreo12Imp.Printed;
        }

        /// <summary>
        /// Revisa si la factura es una Factura en custodia
        /// </summary>
        /// <param name="MovID">string</param>
        /// <return>el texto de Factura en Custodia al estar activado el campo</return>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// 1206 GESSY Check Custodia  
        public string FacturaMayoreoEnCustodia(string MovID)
        {
            try
            {
                String custodia = "";
                SqlCommand sqlCommand = new SqlCommand(
                    " Select top 1 Causa from venta where MovID = @MovID and mov = 'Factura Mayoreo'"
                    , ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovID", MovID);
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr["Causa"].ToString() == "CUSTODIA")
                            {
                                custodia = "\r\n                      FACTURA EN CUSTODIA\r\n\r\n";
                            }
                            else
                            {
                                custodia = "\r\n";
                            }
                        }
                    }
                }

                return custodia;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return "The requested records could not be found";
        }

        /// <summary>
        /// Busca los Documentos Pendientes de la factura Mayoreo en el formato DDDD-DD/MM/AAAA
        /// </summary>
        /// <param name="MovID">string</param>
        /// <return>Mensaje con los documentos o mensaje de fallo</return>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// Date:
        /// 1052 GESSY Reporte Factura Mayoreo 
        public string DocumentosFacturaMayoreo(string MovID)
        {
            try
            {
                String documento = "";
                SqlCommand sqlCommand = new SqlCommand(
                    " SELECT CASE WHEN format(Vencimiento, 'dddd') = 'Monday' THEN 'Lunes'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Tuesday' THEN 'Martes'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Wednesday' THEN 'Miercoles'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Thursday' THEN 'Jueves'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Friday' THEN 'Viernes'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Saturday' THEN 'Sabado'+format(Vencimiento, '-dd/MM/yyyy') ELSE CASE WHEN format(Vencimiento, 'dddd') = 'Sunday' THEN 'Domingo'+format(Vencimiento, '-dd/MM/yyyy') END     END END     END END     END END as Documento    FROM CXC WITH (NOLOCK) WHERE mov = 'Documento' AND PadreMAVI = 'Factura Mayoreo' AND PadreIDMAVI = @MovID ORDER BY id ASC"
                    , ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@MovID", MovID);
                int i = 1;
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            documento = documento + "\t\t" + i.ToString() + "        " + dr["Documento"].ToString() +
                                        "\r\n";
                            i++;
                        }
                    }
                }

                return documento;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FacturaMaviMayoreo", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function DocumentosPendientesFacturaMayoreo, class: CDetalleVenta.cs");
            }

            return "The requested records could not be found";
        }

        /// <summary>
        /// Llena info para impresion RM0847MaviCredRelPedXClienteMayRepImp
        /// </summary>
        /// <param name="ID">int</param>
        /// <param name="string">fecha</param>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        public void ImprimirMaviCredXClienteMay(int ID, string Fecha, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_MaviCredMayRepImp.MaviClienteMay = new List<MRM0847MaviCredRelPedXClienteMayRepImp>();

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_MaviRM0847MaviCredRelPedXCliente", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };

                Fecha = obtenerFechaMov(ID);
                sqlCommand.Parameters.AddWithValue("@ID", ID);
                sqlCommand.Parameters.AddWithValue("@Fecha", Fecha);
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            MRM0847MaviCredRelPedXClienteMayRepImp MAVIMayoreoCliente = new MRM0847MaviCredRelPedXClienteMayRepImp
                            {
                                ID = Convert.ToInt32(dr["ID"]),
                                SucursalVenta = dr["SucursalVenta"].ToString().Length > 0 ? dr["SucursalVenta"].ToString() : "",
                                Nombre = dr["Nombre"].ToString().Length > 0 ? dr["Nombre"].ToString() : "",
                                Mov = dr["Mov"].ToString().Length > 0 ? dr["Mov"].ToString() : "",
                                MovID = dr["MovID"].ToString().Length > 0 ? dr["MovID"].ToString() : "",
                                FechaEmision = dr["FechaEmision"].ToString().Length > 0 ? dr["FechaEmision"].ToString() : "",
                                FechaRegistro = dr["FechaRegistro"].ToString().Length > 0 ? dr["FechaRegistro"].ToString() : "",
                                EnviarA = dr["EnviarA"].ToString().Length > 0 ? dr["EnviarA"].ToString() : "",
                                Cliente = dr["Cliente"].ToString().Length > 0 ? dr["Cliente"].ToString() : "",
                                NombreCliente = dr["NombreCliente"].ToString().Length > 0 ? dr["NombreCliente"].ToString() : "",
                                DireccionCte = dr["DireccionCte"].ToString().Length > 0 ? dr["DireccionCte"].ToString() : "",
                                EstadoCliente = dr["EstadoCliente"].ToString().Length > 0 ? dr["EstadoCliente"].ToString() : "",
                                ColoniaCte = dr["ColoniaCte"].ToString().Length > 0 ? dr["ColoniaCte"].ToString() : "",
                                PoblacionCte = dr["PoblacionCte"].ToString().Length > 0 ? dr["PoblacionCte"].ToString() : "",
                                CodigoPostalCte = dr["CodigoPostalCte"].ToString().Length > 0 ? dr["CodigoPostalCte"].ToString() : "",
                                Referencia = dr["Referencia"].ToString().Length > 0 ? dr["Referencia"].ToString() : "",
                                OrdenCompra = dr["OrdenCompra"].ToString().Length > 0 ? dr["OrdenCompra"].ToString() : "",
                                Observaciones = dr["Observaciones"].ToString().Length > 0 ? dr["Observaciones"].ToString() : "",
                                Condicion = dr["Condicion"].ToString().Length > 0 ? dr["Condicion"].ToString() : "",
                                Cadena = dr["Cadena"].ToString().Length > 0 ? dr["Cadena"].ToString() : "",
                                NumeroDocumentos = dr["NumeroDocumentos"].ToString().Length > 0 && dr["NumeroDocumentos"].ToString() != string.Empty ? Convert.ToInt32(dr["NumeroDocumentos"]) : 0,
                                Agente = dr["Agente"].ToString().Length > 0 ? dr["MaviTipoVenta"].ToString() : "",
                                Situacion = dr["situacion"].ToString().Length > 0 ? dr["MaviTipoVenta"].ToString() : "",
                                MaviTipoVenta = dr["MaviTipoVenta"].ToString().Length > 0 ? dr["MaviTipoVenta"].ToString() : "",
                                Vencimiento = dr["Vencimiento"].ToString().Length > 0 && dr["Vencimiento"].ToString() != string.Empty ? Convert.ToDateTime(dr["Vencimiento"]).ToString("dd/MM/yyyy") : null,
                                Familia = dr["Familia"].ToString().Length > 0 ? dr["Familia"].ToString() : "",
                                Preciototal = dr["preciototal"].ToString().Length > 0 ? Convert.ToDouble(dr["preciototal"]) : 0,
                                Solicito = dr["Solicito"].ToString().Length > 0 ? dr["Solicito"].ToString() : "",
                                Comenta = dr["Comenta"].ToString().Length > 0 ? dr["Comenta"].ToString() : "",
                                FechaNacimiento = dr["FechaNacimiento"].ToString().Length > 0 ? dr["FechaNacimiento"].ToString() : "",
                                Telefono = dr["Telefono"].ToString().Length > 0 ? dr["Telefono"].ToString() : "",
                                NombreDeArticulos = dr["NombreDeArticulos"].ToString().Length > 0 ? dr["NombreDeArticulos"].ToString() : "",
                                NombreAgente = dr["NombreAgente"].ToString().Length > 0 ? dr["NombreAgente"].ToString() : "",
                                Articulo = dr["Articulo"].ToString().Length > 0 ? dr["Articulo"].ToString() : "",
                                ImporteArt = dr["ImporteArt"].ToString().Length > 0 ? "$ " + Convert.ToDouble(dr["ImporteArt"]).ToString("0.00") : "$ 0.00",
                                Precio = dr["Precio"].ToString().Length > 0 ? "$ " + Convert.ToDouble(dr["Precio"]).ToString("0.00") : "$ 0.00",
                                Cantidad = dr["Cantidad"].ToString().Length > 0 ? Convert.ToInt32(dr["Cantidad"]) : 0,
                                Usuario = dr["Usuario"].ToString().Length > 0 ? dr["Usuario"].ToString() : "",
                                UsuarioNombre = dr["UsuarioNombre"].ToString().Length > 0 ? dr["UsuarioNombre"].ToString() : "",
                                NombreAval = dr["NombreAval"].ToString().Length > 0 ? dr["NombreAval"].ToString() : "",
                                ColoniaAval = dr["ColoniaAval"].ToString().Length > 0 ? dr["ColoniaAval"].ToString() : "",
                                CodigoPostalAval = dr["CodigoPostalAval"].ToString().Length > 0 ? dr["CodigoPostalAval"].ToString() : "",
                                DireccionAval = dr["DireccionAval"].ToString().Length > 0 ? dr["DireccionAval"].ToString() : "",
                                TelefonosAval = dr["TelefonosAval"].ToString().Length > 0 ? dr["TelefonosAval"].ToString() : "",
                                PoblacionAval = dr["PoblacionAval"].ToString().Length > 0 ? dr["PoblacionAval"].ToString() : "",
                                EstadoAval = dr["EstadoAval"].ToString().Length > 0 ? dr["EstadoAval"].ToString() : "",
                                Leyenda = dr["Leyenda"].ToString().Length > 0 ? dr["Leyenda"].ToString() : "",
                                Factor = dr["Factor"].ToString().Length > 0 ? dr["Factor"].ToString() : ""
                            };
                            DM0312_MaviCredMayRepImp.MaviClienteMay.Add(MAVIMayoreoCliente);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            DM0312_MaviCredMayRepImp MAVIClienteMayoreo = new DM0312_MaviCredMayRepImp(VentasSeleccionadas);
            MAVIClienteMayoreo.ShowDialog();
        }

        public string obtenerFechaMov(int iIdaVenta)
        {
            string fecha = string.Empty;
            DataTable dt = new DataTable();
            try
            {
                string sQuery = "select convert(varchar,FechaEmision,121) AS FechaEmision  from venta WITH(NOLOCK) where id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdaVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        fecha = (item["FechaEmision"].ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return fecha;
        }

        /// <summary>
        /// Obtiene el pais del cliente
        /// </summary>
        /// <param name="codigo">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        public string GetCountry(string codigo)
        {
            string CadenaSQL = "Select Pais from cte WITH(NOLOCK) where cliente = @Cliente";
            string[] parametros = { "@Cliente" };
            string[] parametrosAPasar = { codigo };
            string CadenaALeer = "Pais";
            string Country = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            return Country;
        }

        /// <summary>
        /// Obtiene tiempo 
        /// </summary>
        /// <param name="Condicion">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        public string ObtenerTiempo(string Condicion)
        {

            string CadenaSQL = "SELECT IsNull(Isnull(DANumeroDocumentos,convert(int,(DiasVencimiento/30))),1) Tiempo FROM Condicion WITH(NOLOCK) WHERE Condicion = @Condicion";
            string[] parametros = { "@Condicion" };
            string[] parametrosAPasar = { Condicion };
            string CadenaALeer = "Tiempo";
            string Tiempo = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            return Tiempo;
        }

        /// <summary>
        /// Obtiene impuesto1 de articulo 
        /// </summary>
        /// <param name="Condicion">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        protected string ObtenerImpuesto(string articulo)
        {

            string CadenaSQL = "Select Impuesto1 From Art WITH(NOLOCK) where articulo = @art";
            string[] parametros = { "@art" };
            string[] parametrosAPasar = { articulo };
            string CadenaALeer = "Impuesto1";
            string Impuesto1 = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            return Impuesto1;
        }

        /// <summary>
        /// Formula IVA
        /// </summary>
        /// <param name="MontoImpuesto">double</param>
        /// <returns>double</returns>
        /// Developer: Dan Palacios
        /// Date: 11/09/17
        protected double CalcularIVA(double MontoImpuesto)
        {
            if (MontoImpuesto < 1)
            {
                MontoImpuesto = 1;
            }
            else
            {
                MontoImpuesto = (MontoImpuesto / 100) + 1;
            }

            return MontoImpuesto;
        }

        /// <summary>
        /// Obtiene impuesto base
        /// </summary>
        /// <param name="IDMod">string</param>
        /// <returns>double</returns>
        /// Developer: Dan Palacios
        /// Date: 12/09/17
        protected double ObtenerImpuestoBase(string IDMod)
        {
            string CadenaSQL = "SELECT sum(((Precio)-((Precio)/((Case When Impuesto1 = 0 Then 1 Else Impuesto1 End/100)+1)))*Cantidad) ImpuestoBase FROM Ventad WITH(NOLOCK) WHERE ID = @IDMod AND Impuesto1 in (0,15,16)";
            string[] parametros = { "@IDMod" };
            string[] parametrosAPasar = { IDMod };
            string CadenaALeer = "ImpuestoBase";
            string ImpuestoBase = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            double ImpuestoBaseDouble = 0;
            if (ImpuestoBase != string.Empty)
            {
                ImpuestoBaseDouble = Convert.ToDouble(ImpuestoBase);
            }

            return ImpuestoBaseDouble;
        }

        /// <summary>
        /// Obtiene aviso de la pagina
        /// </summary>
        /// <param name="sucursal">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 12/09/17
        public string ObtenerAvisoPagina(string sucursal)
        {
            string CadenaSQL = "SELECT PagAviso = T.Valor FROM TablaStD T WITH(NOLOCK) INNER JOIN Sucursal S ON S.wUEN = T.Nombre WHERE TablaSt='WEB AVISO DE PRIVACIDAD' AND Sucursal = @Suc";
            string[] parametros = { "@Suc" };
            string[] parametrosAPasar = { sucursal };
            string CadenaALeer = "PagAviso";
            string PagAviso = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            return PagAviso;
        }

        /// <summary>
        /// Crea byte array de string en codigo de barras 128
        /// </summary>
        /// <param name="inputCode">string</param>
        /// <returns>byte[]</returns>
        /// Developer: Dan Palacios
        /// Date: 12/09/17
        protected byte[] CreateBarCode128(string inputCode)
        {
            byte[] bmarray = null;
            try
            {
                Barcode128 codigobarras = new Barcode128
                {
                    Code = inputCode
                };

                Bitmap bm = new Bitmap(codigobarras.CreateDrawingImage(Color.Black, Color.White));
                using (MemoryStream ms = new MemoryStream())
                {
                    bm.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    bmarray = ms.ToArray();
                    ms.Dispose();
                    ms.Flush();
                }
                bm.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CreateBarCode128", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function CreateBarCode128 class: CDetalleVenta.cs");
            }

            return bmarray;
        }

        #endregion

        #region Afectar

        /// <summary>
        /// validaciones antes de ejecutar una afectacion
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 15/09/17
        public bool ValidacionesAfectar(string[] Parametros, ref string msgPrecaucion)
        {
            bool AfectacionEsValida = false;

            #region variables globales

            string CadenaSQL = "Select dbo.fnClientesNuevosCasaMAVI('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string CadenaALeer = string.Empty;
            string fnClientesNuevosCasaMAVI = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            CadenaSQL = "SHM_Valida_Analisis";
            string[] parametros = { "@ID" };
            string[] parametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string valido = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);

            CadenaSQL = "Select count(*) CountVentaD From VentaD with(nolock) Where Articulo like '%VALR%' And ID = @ID";
            string CountVentaD = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            CadenaSQL = "select count(*) CountVenta from Venta with(nolock) where ISNULL(Liberado,0) = 1 and ID = @ID";
            string CountVenta = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            CadenaSQL = "Select dbo.fn_MaviDM0244ValeAsignado('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string fn_MaviDM0244ValeAsignado = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            string InfoID = string.Empty;

            #endregion

            #region validacion solicitudes valera (linea 1- 50)

            //Validacion linea 1
            if
            (
                fnClientesNuevosCasaMAVI == "Nuevo" &&
                valido == "0" &&
                CountVentaD == "0" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
            )
            {
                CadenaSQL = "select count(*) CountMovBitacora from MovBitacora with(nolock) where ID = @ID and Clave in (select Evento from SHM_ValorDeEventosValera with(nolock))";
                string CountMovBitacora = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                //Validacion linea 17
                if (CountMovBitacora == "0")
                {
                    msgPrecaucion = "No cuenta con el evento solicitud valera";
                    return false;
                }
                else
                {
                    CadenaSQL = "select count(*) CountFolios from DM0244_FOLIOS_VALES With(NoLock) where IDSOLVTAVAL = @ID";
                    string CountFolios = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                    //Validacion linea 23
                    if (CountFolios == "0")
                    {
                        msgPrecaucion = "favor de imprimir valera y capturar el primer vale por concepto de este movimiento";
                        //Validacion linea 28
                        if (fn_MaviDM0244ValeAsignado == "0")
                        {
                            InfoID = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];

                            //Checar para que o si es necesario abrir forma 'DM0244NipValesVtaFrm'
                            return false;
                        }
                    }
                }
            }
            //Validacion linea 39
            else if
            ((
             Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal") &&
            Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR" && CountVenta == "0" &&
            (Parametros[(int)Enums.ParametrosDetallesVenta.Almacen] != "V00039" && Parametros[(int)Enums.ParametrosDetallesVenta.Almacen] != "V00502") &&
            Parametros[(int)Enums.ParametrosDetallesVenta.Canal] != "80")
            {
                CadenaSQL = "SELECT COUNT(Numero) TabNum FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum='SUCURSALES RDP' AND CAST(Numero AS INT)=@Suc";
                parametros = new string[] { "@Suc" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] };
                string TabNum = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);
                //Validacion linea 50 se ejecuta plugins de ruta ticket y shm
                if (TabNum == "1")
                {
                    string ArgumentosPlugin = "SHM8 "
                                            + ClaseEstatica.Usuario.usuario + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                            + ClaseEstatica.WorkStation;
                    EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                    return false;
                }
                else
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"].ToString() + @"SHM.exe"))
                    {
                        string ArgumentosPlugin = " MACH " + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + " "
                        + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente];
                        EjecutarPlugins(ArgumentosPlugin, "SHM.exe", ConfigurationManager.AppSettings["CarpetaSHM"].ToString());
                    }
                    return false;
                }
            }

            #endregion

            #region condicion pago (linea 65 - 70)

            string InfoIDMAVI = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
            string InfoUEN = Parametros[(int)Enums.ParametrosDetallesVenta.UEN];
            string InfoMov = Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
            CadenaSQL = "SP_MAVIDM0173RedimeOGeneraMONE";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[] { InfoIDMAVI };
            string MensajeSP_MAVIDM0173RedimeOGeneraMONE = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);

            //Validacion linea 65
            if (MensajeSP_MAVIDM0173RedimeOGeneraMONE != string.Empty)
            {
                msgPrecaucion = MensajeSP_MAVIDM0173RedimeOGeneraMONE;
            }
            else
            {
                AfectacionEsValida = true;
            }

            //Validacion linea 70
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Condicion] == string.Empty)
            {
                msgPrecaucion = "No se ha especificado la condición de pago";
                return false;
            }

            #endregion

            #region movimientos directos y uens (linea 77 - 163)

            string msg = string.Empty;

            //Validacion linea 77
            if (InfoMov == "Factura")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar facturas directas";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Credilana")
            {
                //Validacion linea 92
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar este movimiento directo";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Factura VIU")
            {
                //Validacion linea 110
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar este facturas VIU directas";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Prestamo Personal")
            {
                //Validacion linea 119
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar prestamos personales directos";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Seguro Vida")
            {
                //Validacion linea 121
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar seguros de vida directos";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Seguro Auto")
            {
                //Validacion linea 134
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar seguros de auto directos";
                    return false;
                }
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2")
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Analisis Credito")
            {
                //Validacion linea 152
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    msgPrecaucion = "No se pueden realizar análisis de crédito directos";
                    return false;
                }
            }
            else if (InfoMov == "Pedido")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
                {
                    //Validacion linea 163
                    CadenaSQL = "Select TipoCondicion from Condicion WITH(NOLOCK) where condicion=@Condicion";
                    parametros = new string[] { "@Condicion" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.Condicion] };
                    string TipoCondicion = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);
                    if (TipoCondicion != "Contado")
                    {
                        msgPrecaucion = "No se pueden realizar pedidos directos si la condición de pago es a crédito";
                        return false;
                    }
                }
            }
            else if (InfoMov == "Analisis Mayoreo" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            {
                msgPrecaucion = "No se pueden realizar análisis mayoreo directos";
                return false;
            }
            //else if (InfoMov == "Pedido Mayoreo" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            //{
            //    msgPrecaucion = "No se pueden realizar pedido de mayoreo directos";
            //    return false;
            //}
            else if (InfoMov == "Factura Mayoreo" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            {
                msgPrecaucion = "No se pueden realizar facturas mayoreo directas";
                return false;
            }
            else if (InfoMov == "Devolucion Venta" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            {
                msgPrecaucion = "No se pueden realizar devoluciones de venta directas";
                return false;
            }
            else if (InfoMov == "Devolucion VIU" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            {
                msgPrecaucion = "No se pueden realizar devoluciones VIU directas";
                return false;
            }
            else if (InfoMov == "Devolucion Mayoreo" && Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty)
            {
                msgPrecaucion = "No se pueden realizar devoluciones de mayoreo directas";
                return false;
            }

            #endregion

            //linea 183-230 checar de donde salen las variables ¿?

            #region movimientos directos y uens2 (linea 230 - 235)

            //validaciones linea 230-235
            if (InfoMov == "Devolucion VIU")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2"
                    )
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Devolucion Venta")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1"
                    )
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Devolucion Mayoreo")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "3"
                    )
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Cancela Prestamo")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "2"
                    )
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }
            else if (InfoMov == "Cancela Credilana")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != string.Empty &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.UEN] != "1"
                    )
                {
                    msgPrecaucion = "La UEN no corresponde con el movimiento";
                    return false;
                }
            }

            #endregion

            #region monedero (linea 237 - 263)

            CadenaSQL = "xpVerificarMovMonederoMAVI";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string CadenaxpVerificarMovMonederoMAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);
            bool BanderaxpVerificarMovMonederoMAVI = false;

            //validacion linea 237
            if (CadenaxpVerificarMovMonederoMAVI != string.Empty)
            {
                BanderaxpVerificarMovMonederoMAVI = Convert.ToBoolean(CadenaxpVerificarMovMonederoMAVI);
            }

            double InfoImporte = 0;

            CadenaSQL = "SELECT SUM(ISNULL(ImporteTotal,0.0)) FROM VentaTCalc WITH(NOLOCK) WHERE ID = @ID";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string ImporteTotal = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            if (BanderaxpVerificarMovMonederoMAVI)
            {
                DM0312_Redime redime = new DM0312_Redime();
                int IdVenta = Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]);
                string Cliente = Convert.ToString(Parametros[(int)Enums.ParametrosDetallesVenta.Cliente]);

                CadenaSQL = "xpVerificarRedimeMAVI";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                string CadenaxpVerificarRedimeMAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);
                bool BanderaxpVerificarRedimeMAVI = false;

                if (CadenaxpVerificarRedimeMAVI != string.Empty)
                {
                    BanderaxpVerificarRedimeMAVI = Convert.ToBoolean(CadenaxpVerificarRedimeMAVI);
                }

                //validacion linea 239
                if (BanderaxpVerificarRedimeMAVI)
                {
                    CadenaSQL = "SELECT COUNT(*) CountMonedero FROM TarjetaMonederoMAVI WITH(NOLOCK) WHERE estatus = 'ACTIVA' AND TipoMonedero = 'VIRTUAL' AND Cliente = @Cliente";
                    parametros = new string[] { "@Cliente" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] };
                    string CountMonedero = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                    CadenaSQL = "SELECT COUNT(*) CountMonVirtual FROM SHM_MonVirtual_RegistraRedencion WITH(NOLOCK) WHERE IDSol = @ID";
                    parametros = new string[] { "@ID" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                    string CountMonVirtual = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                    //Validacion linea 241
                    if (CountMonedero != string.Empty && Convert.ToInt32(CountMonedero) > 0 && CountMonVirtual == "0")
                    {
                        if (ImporteTotal != string.Empty)
                        {
                            InfoImporte = Convert.ToDouble(ImporteTotal);
                        }
                        //abre forma 'TipoMonederoDIMAfrm' (linea 250)
                        redime.EnviarA = 76;
                        redime.idVenta = IdVenta;
                        redime.cliente = Cliente;
                        redime.iUen = int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.UEN]);

                        redime.ShowDialog();

                        if (!redime.IsCancel)
                        {
                            //msgPrecaucion = "No se redimio Monedero";
                            return false;
                        }

                        //AfectacionEsValida = false;
                        //return AfectacionEsValida;
                    }
                    else if (CountMonVirtual == "0")
                    {
                        if (ImporteTotal != string.Empty)
                        {
                            InfoImporte = Convert.ToDouble(ImporteTotal);
                        }
                        //abre forma 'TarjetaSerieMovMAVIRedimir' (linea 257)

                        redime.origen = true;
                        redime.idVenta = IdVenta;
                        redime.cliente = Cliente;

                        redime.ShowDialog();

                    }
                }
                else
                {
                    if (ImporteTotal != string.Empty)
                    {
                        InfoImporte = Convert.ToDouble(ImporteTotal);
                    }
                    //abre forma 'TarjetaSerieMovMAVIAplicar' (linea 263)

                    redime.origen = false;
                    redime.idVenta = IdVenta;
                    redime.cliente = Cliente;
                    redime.iUen = int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.UEN]);
                    redime.ShowDialog();

                }

                if (redime.bRedimio)
                {
                    MessageBox.Show("Se Redimio monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (redime.bGeneroMonedero)
                {
                    MessageBox.Show("Se genero monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            #endregion

            #region garantiaDetalle (linea 267 - 275)

            //CadenaSQL = "SELECT dbo.fn_MaviDM0169GarantiaDetalle('" + Parametros[(int)Enums.ParametrosDetallesVenta.Mov] + "',' " + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            //string cadenafn_MaviDM0169GarantiaDetalle = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //Validacion linea 268
            //if(cadenafn_MaviDM0169GarantiaDetalle == "0")
            //{
            //    CadenaSQL = "SP_DM0169GarantiasVenta";
            //    parametros = new string[] { "@ID", "@Sucursal", "@Almacen" };
            //    parametrosAPasar = new string[] 
            //    {
            //        Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
            //        Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal],
            //        Parametros[(int)Enums.ParametrosDetallesVenta.Almacen] 
            //    };
            //    string cadenaSP_DM0169GarantiasVenta = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, null, true);
            //    msgPrecaucion = "Ofrecer garantias ampliadas, si no las requiere favor de borrarlas";
            //    return false;
            //}

            #endregion

            #region Ultimas funciones (linea 278 - 329)

            CadenaSQL = "SELECT dbo.fn_MaviDM0169CampoExtraActivo('" + ClaseEstatica.Usuario.usuario + "',' " + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string cadenafn_MaviDM0169CampoExtraActivo = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //validacion linea 278
            if (cadenafn_MaviDM0169CampoExtraActivo != string.Empty && Convert.ToInt32(cadenafn_MaviDM0169CampoExtraActivo) >= 1)
            {
                //general campo extra
            }

            CadenaSQL = "SELECT dbo.fnClientesNuevosCasaMAVI('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string cadenafnClientesNuevosCasaMAVI = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);


            CadenaSQL = "select COUNT(*) from DM0244_FOLIOS_VALES With(NoLock) where CUENTA = '" + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente].Trim() + "' AND ESTATUS = 1";
            string cadenaDM0244_FOLIOS_VALES = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            CadenaSQL = "Select count(*) From VentaD with(nolock) Where Articulo like '%VALR%' And ID = " + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
            string cadenaVentaD = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //Validacion linea 319
            if (
                (
                    cadenafnClientesNuevosCasaMAVI == "Casa" ||
                    (cadenaDM0244_FOLIOS_VALES != string.Empty && Convert.ToInt32(cadenaDM0244_FOLIOS_VALES) > 0)
                )
                &&
                cadenaVentaD == "0"
                &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito"
                &&
                Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
              )
            {
                //validacion 329
                if (fn_MaviDM0244ValeAsignado == "0")
                {
                    InfoID = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];

                    //Checar para que o si es necesario abrir forma 'DM0244NipValesVtaFrm'
                    msgPrecaucion = "No puede agregar el vale por que ya esta en uso en otra solicitud";
                    AfectacionEsValida = false;
                    return AfectacionEsValida;
                }
                else
                {
                    //AfectacionEsValida = false;
                }
            }

            #endregion

            #region ultimas consultas (linea 343 - 360)


            CadenaSQL = "select SUBSTRING(Nombre,1,14) from Sucursal WITH(NOLOCK) Where Sucursal= @Suc";
            parametros = new string[] { "@Suc" };
            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] };
            string NombreSucursal = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            //Validacion linea 343

            if (NombreSucursal != string.Empty && NombreSucursal == "VENTA EN LINEA" && Parametros[(int)Enums.ParametrosDetallesVenta.Categoria] == "CONTADO")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.ReferenciaOrdenCompra] == "")
                {
                    msgPrecaucion = "El campo pedido ecommerce es obligatorio";
                    return false;
                }
            }

            CadenaSQL = "SELECT dbo.FN_DM0292ValidaAplica('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string cadenaFN_DM0292ValidaAplica = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //Validacion linea 350
            if (cadenaFN_DM0292ValidaAplica == "1")
            {
                CadenaSQL = "SP_DM0292ValidaArtsQ";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                string cadenaSP_DM0292ValidaArtsQ = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                //Validacion linea 354
                if (cadenaSP_DM0292ValidaArtsQ == "Candidato para oferta articulos Q")
                {
                    DialogResult result = MessageBox.Show("Candidato para promocion de Calzado Q ¿Seguro que desea avanzar?", "Afectar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        return false;
                    }
                }
                else
                {
                    msgPrecaucion = cadenaSP_DM0292ValidaArtsQ;
                }
            }

            CadenaSQL = "SELECT dbo.fn_DM0297CandadoArtSegu('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string cadenafn_DM0297CandadoArtSegu = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //Validacion linea 360
            if (cadenafn_DM0297CandadoArtSegu != "1")
            {
                msgPrecaucion = "Debe ingresar el teléfono en los datos de entrega";
                return false;
            }

            #endregion

            return AfectacionEsValida;

        }

        public string PedidoVehiculo(string movid)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT * from dbo.FnAFListMovPendVehiculo ('{0}','{1}')", "MOVID", movid);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        puede = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("PedidoVehiculo", "cdetalleventa", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return puede;
        }


        public string PedidoVehiculoSituacion(string movid)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format("select situacion from venta with (nolock) where mov='pedido mayoreo' and movid='" + movid + "'");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        puede = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("PedidoVehiculoSituacion", "cdetalleventa", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return puede;
        }

        /// <summary>
        /// Validaciones de condicion para afectar
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 25/09/17
        public bool CondicionAfectar(string[] Parametros, ref string msgPrecaucion)
        {
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE" && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido Mayoreo")
            {
                string situacion;
                situacion = PedidoVehiculoSituacion(Parametros[(int)Enums.ParametrosDetallesVenta.MovID]);
                if (situacion == "Liberado")
                {
                    string mensajerespuesta;
                    mensajerespuesta = PedidoVehiculo(Parametros[(int)Enums.ParametrosDetallesVenta.MovID]);
                    if (mensajerespuesta != "")
                    {
                        msgPrecaucion = "El pedido cuenta con los siguientes movimientos pendientes " + mensajerespuesta + " favor de concluirlos para poder continuar";
                        return false;
                    }
                }

            }

            string CadenaSQL = "SELECT COUNT(ESTATUS) AS VALOR FROM DM0238VIGENCIASINSTITUCIONES DM WITH(NOLOCK) JOIN" +
                " VENTASCANALMAVI VC WITH(NOLOCK) ON DM.CANAL_VENTA=VC.ID WHERE VC.CATEGORIA IN ('INSTITUCIONES','CREDITO MENUDEO') AND " +
                "CANAL_VENTA=@CanalVenta AND (ESTATUS='CANCELADO')";
            string CadenaALeer = string.Empty;
            string[] parametros = { "@CanalVenta" };
            string[] parametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] };
            string ValorEstatus = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            if (ValorEstatus != "0" && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida")
            {
                msgPrecaucion = "Canal de venta suspendido o cancelado";
                return false;
            }
            else if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != string.Empty &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Almacen] != string.Empty)
            {
                CadenaSQL = "SELECT COUNT(*) FROM MOVTIPO WITH(NOLOCK) WHERE MOV = @Mov AND  Modulo = 'VTAS' and Clave in ('VTAS.P','VTAS.F' )";
                CadenaALeer = string.Empty;
                parametros = new string[] { "@Mov" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.Mov] };
                string CountMovTipo = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR" &&
                    CountMovTipo == "0")
                {

                }
                else
                {
                    CadenaSQL = "SP_MAVIDM0197DEVMenosVTA";
                    parametros = new string[] { "@ID" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                    string cadenaSP_MAVIDM0197DEVMenosVTA = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);
                    if (cadenaSP_MAVIDM0197DEVMenosVTA != "0")
                    {
                        msgPrecaucion = "La devolución debe contener el total de artículos vendidos";
                        return false;
                    }
                }
            }

            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura"
                && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU")
            {

                CadenaSQL = "SP_RM1161AfectacionRepServicio";
                parametros = new string[] { "@ID", "@IDSoporte", "@Opcion" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                    Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal],
                     "2"
                };
                string cadenaSP_RM1161AfectacionRepServicio = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);
                if (cadenaSP_RM1161AfectacionRepServicio == "1")
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Afecta el movimiento seleccionado
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// Developer: Dan Palacios
        /// Date: 19/09/17
        public bool Afectar(string[] Parametros, ref string msgPrecaucion, ref string msgTitulo, List<DM0312_MExploradorVenta> VentasSeleccionadas = null)
        {

            bool MovAfectado = false;

            if (ClaseEstatica.Usuario.Acceso.Contains("VENTP") && Parametros[(int)Enums.ParametrosDetallesVenta.Mov].Equals("Solicitud Credito") && Parametros[(int)Enums.ParametrosDetallesVenta.Estatus].Equals("PENDIENTE"))
            {
                msgPrecaucion = "El usuario no tiene acceso a editar el movimiento: " + Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                return false;
            }

            string sUsuario = string.Empty;
            //sUsuario
            if (DM0312_DetalleVenta.almacen96Afectar || DM0312_DetalleVenta.almacen2000Afectar)
            {
                if (DM0312_DetalleVenta.almacen96Afectar)
                {
                    sUsuario = DM0312_DetalleVenta.usuarioAlmacen96;
                }
                else if (DM0312_DetalleVenta.almacen2000Afectar)
                {
                    sUsuario = DM0312_DetalleVenta.usuarioAlmacen2000;
                }
            }
            else
            {
                sUsuario = ClaseEstatica.Usuario.usuario;
            }


            #region variables globales

            string CadenaSQL = "Select dbo.FnCXCValidaTelCte('" + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + "', '" + ClaseEstatica.Usuario.usuario + "')";
            string CadenaALeer = string.Empty;
            string[] parametros = { "@ID" };
            string[] parametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string InfoCantidadInventario = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            //Validacion linea 4
            //if (InfoCantidadInventario != "0" && Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito")
            //{
            //    string ArgumentosPlugin = Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + " "
            //        + ClaseEstatica.Usuario.usuario + " " + InfoCantidadInventario;
            //    EjecutarPlugins(ArgumentosPlugin, "DM0305ValidaTelefono.exe");
            //    //return false;
            //}

            CadenaSQL = "Select dbo.fnDM0138validaCte('" + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + "', '" + ClaseEstatica.Usuario.usuario + "')";
            string CadenafnDM0138validaCte = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            CadenaSQL = "Select Count(*) From VentasCanalMAVI WITH(NOLOCK) Where ID = @EnviarA and Cadena in('VENTA VALE','CREDITAZZO')";
            parametros = new string[] { "@EnviarA" };
            parametrosAPasar = new string[]
            {
                Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA]
            };
            string CountCanalMavi = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            CadenaSQL = "Select count(*) From VentaD with(nolock) where ID = @ID and Articulo like '%VALR%'";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[]
            {
                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
            };
            string CountArt = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            #endregion 

            #region validacion linea 13 - 360

            //Validacion linea 13
            if
            (!FromDetalle &&
            (
                CadenafnDM0138validaCte == "SI" &&
                (Parametros[(int)Enums.ParametrosDetallesVenta.Origen] == "" || Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == "") &&
                (
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Devolucion Venta" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Devolucion Mayoreo" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Devolucion VIU" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Sol Dev Mayoreo" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] != "Solicitud Devolucion"
                )
            ))
            {
                msgPrecaucion = "Se necesita capturar correo";

                return false;
                //abrir forma 'DM0138CapturaCorreo'
            }
            else if
            (
                //Validacion linea 22
                (
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Credilana" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Prestamo" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Seg Auto" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Seg Vida" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancelacion Factura" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion Mayoreo" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion Venta" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion VIU" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura Mayoreo" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Auto" ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida"
                )
                &&
                (
                    Parametros[(int)Enums.ParametrosDetallesVenta.Origen] == string.Empty ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.OrigenID] == string.Empty
                )
            )
            {
                msgPrecaucion = "Movimiento no se puede afectar";
                return false;
            }
            else
            {

                #region linea 32 - 48

                //validacion linea 32
                if
                (
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] != "CONCLUIDO" &&
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU"
                    )
                    &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.MovID] == string.Empty
                )
                {
                    CadenaSQL = "spConsecutivoGral";
                    parametros = new string[] { "@ID", "@Modulo", "@AplicaManual" };
                    parametrosAPasar = new string[]
                    {
                        Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                        "VTAS",
                        "0"
                    };
                    EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, null, true);
                }

                string InfoID = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta];
                string InfoMov = Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                string InfoMovID = Parametros[(int)Enums.ParametrosDetallesVenta.MovID];

                CadenaSQL = "SELECT Mov FROM MovTipo WITH(NOLOCK) WHERE Clave = 'VTAS.P' AND Modulo = 'VTAS'";
                List<string> Movs = EjecutaSQLDataReader(CadenaSQL, null, null);

                CadenaSQL = "Select count(*) from VentaD WITH(NOLOCK) where ID = @ID";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                string CountVentaD = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                //validacion linea 42
                if
                (
                    Movs.Contains(Parametros[(int)Enums.ParametrosDetallesVenta.Mov]) &&
                    CountVentaD != string.Empty && Convert.ToInt32(CountVentaD) > 0
                )
                {
                    CadenaSQL = "spValidarFamilia_MAVI";
                    parametros = new string[] { "@VENTAID" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                    string cadenaspValidarFamilia_MAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                    //validacion linea 48
                    if (cadenaspValidarFamilia_MAVI == "0")
                    {
                        msgPrecaucion = "Se agregaron códigos incompatibles";
                        return false;
                    }
                }

                CadenaSQL = "SELECT Mov FROM MovTipo WITH(NOLOCK) WHERE Clave IN('VTAS.SD','VTAS.B','VTAS.D')  AND Modulo = 'VTAS'";
                Movs = EjecutaSQLDataReader(CadenaSQL, null, null);

                #endregion

                #region validacion 54 - 60

                //validacion linea 54
                if
                (
                    Movs.Contains(Parametros[(int)Enums.ParametrosDetallesVenta.Mov]) &&
                    CountVentaD != string.Empty && Convert.ToInt32(CountVentaD) > 0
                )
                {
                    CadenaSQL = "spTipoCondicionMAVI";
                    parametros = new string[] { "@ID" };
                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                    string cadenaspValidarFamilia_MAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                    //validacion linea 60
                    if (cadenaspValidarFamilia_MAVI == "0")
                    {
                        msgPrecaucion = "Se agregaron artículos que provienen de movimientos con condiciones mayores y menores a 12 meses";
                        return false;
                    }
                }

                #endregion

                #region linea 70 - 100

                //validacion linea 70
                if
                (
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Credilana" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Prestamo" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Seg Auto" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Seg Vida" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion Venta" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion VIU" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Auto" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida"
                    )
                    &&
                    CountVentaD != string.Empty && Convert.ToInt32(CountVentaD) > 0
                )
                {
                    CadenaSQL = "spValidarFamiliaAlFacturar_MAVI";
                    parametros = new string[] { "@VENTAID", "@MOV" };
                    parametrosAPasar = new string[]
                    {
                        Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov]
                    };
                    string cadenaspValidarFamiliaAlFacturar_MAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                    //validacion linea 80
                    if (cadenaspValidarFamiliaAlFacturar_MAVI == "0")
                    {
                        msgPrecaucion = "Hay códigos incompatibles con el movimiento";
                        return false;
                    }
                }


                //validacion Config.VentaActualizarPrecioMoneda (linea 84 - 95)
                CadenaSQL = "Select VentaActualizarPrecioMoneda From EmpresaCfg WITH(NOLOCK) where Empresa = 'MAVI'";
                string VentaActualizarPrecioMoneda = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty, false);

                CadenaSQL = "spVentaActualizarPreciosChecar";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[]
                {
                        Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                };
                string spVentaActualizarPreciosChecar = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                if (VentaActualizarPrecioMoneda == "1" && VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR" && Convert.ToBoolean(spVentaActualizarPreciosChecar))
                {
                    DialogResult result = MessageBox.Show("¿ Desea actualizar los precios otras monedas ?", "Afectar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        CadenaSQL = "spVentaActualizarPrecios";
                        parametros = new string[] { "@ID" };
                        parametrosAPasar = new string[]
                        {
                        Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                        };
                        string spVentaActualizarPrecios = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
                    }
                    return false;
                }

                //validacion General.OFER (linea 97)


                //validacion Info.MovProcesar linea 100


                #endregion

                #region validacion 100 - 360

                //asignaciones 104 - 115
                bool FechasValidas = true;
                DateTime FechaVencimiento = new DateTime();
                DateTime FechaEmision = new DateTime();
                try
                {
                    FechaVencimiento = DateTime.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.FechaVencimiento]);
                    FechaEmision = DateTime.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision]);
                }
                catch (Exception ex)
                {
                    FechasValidas = false;
                    Console.Write(ex.Message + " Fecha vencimiento / emision no es valida");
                }

                CadenaSQL = "Select VentaLiquidaIntegral From EmpresaCfg WITH(NOLOCK) where Empresa = 'MAVI'";
                string VentaLiquidaIntegral = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty, false);

                //Validaciones linea 116 - 148
                if
                (FechasValidas && (
                #region validaciones linea 104 - 148

                    Parametros[(int)Enums.ParametrosDetallesVenta.ImporteEnAfectar] != "0"
                    &&
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "EstatusBorrador" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "EstatusPorConfirmar"
                    )
                    &&
                    (
                        (
                            (
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.N" ||
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.FM"
                            )
                            &&
                            (
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovID] != "" ||
                                VentaLiquidaIntegral == "1"
                            )
                        //Config.VentaLiquidaIntegral (linea 125)

                        //Venta:Condicion.ControlAnticipos¿? (linea 127)
                        )
                        //||
                        //(
                        //    (
                        //        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.S" ||
                        //        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.P" ||
                        //        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.VP" ||
                        //        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.SD" ||
                        //        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.B"
                        //    )
                        //    //Venta:Condicion.ControlAnticipos¿? linea 133
                        //)
                        ||
                        (
                            //Config.FacturaCobroIntegrado¿?    linea 141 
                            //Venta:Condicion.ControlAnticipos¿?    143
                            false &&
                            (
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.F" ||
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.FAR" ||
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.FB" ||
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.D" ||
                                Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.DF"
                            )
                            &&
                            (
                                Parametros[(int)Enums.ParametrosDetallesVenta.FechaVencimiento] != string.Empty &&
                                Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision] != string.Empty &&
                                FechaVencimiento <= FechaEmision
                            )
                            &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.OrigenTipo] != "VMOS"
                        )
                    )
                #endregion
                ))
                {
                    //abre forma 'VentaCobro' linea 152
                }
                else if
                (
                    //validacion linea 154
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "EstatusBorrador" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "EstatusPorConfirmar"
                    )
                    ||
                    Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.S" &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "EstatusPorConfirmar"
                )
                {

                    #region validaciones 161 - 173

                    CadenaSQL = "Select CompraVentaSinIVA From EmpresaCfg WITH(NOLOCK) where Empresa = 'MAVI'";
                    string CompraVentaSinIVA = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty, false);

                    //config.CompraVentasinIVA linea 161
                    if (CompraVentaSinIVA == "1" && Parametros[(int)Enums.ParametrosDetallesVenta.SumaImpuesto] != string.Empty &&
                        Convert.ToDouble(Parametros[(int)Enums.ParametrosDetallesVenta.SumaImpuesto], CultureInfo.InvariantCulture) == 0 &&
                        Parametros[(int)Enums.ParametrosDetallesVenta.SumaImporte] != string.Empty &&
                        Convert.ToDouble(Parametros[(int)Enums.ParametrosDetallesVenta.SumaImporte], CultureInfo.InvariantCulture) > 0)
                    {
                        DialogResult result = MessageBox.Show("Movimiento sin impuestos" + Environment.NewLine + "¿Desea continuar?", "Afectar", MessageBoxButtons.YesNo);
                        if (result == DialogResult.No)
                        {
                            return false;
                        }
                    }

                    //EMPRESACFD linea 170
                    CadenaSQL = "SELECT CFD FROM MovTipo WITH(NOLOCK) WHERE Modulo = 'VTAS' AND Mov = @Mov";
                    parametros = new string[] { "@Mov" };
                    parametrosAPasar = new string[]
                    {
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov]
                    };
                    string CFDMovTipo = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                    if (Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] != "SINAFECTAR" || ClaseEstatica.ListaPermisosCreacion.Where(x => x == "VTAS." + Parametros[(int)Enums.ParametrosDetallesVenta.Mov]).Any())
                    {
                        if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" && Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR")
                        {
                            if (Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] != "" && VentasSeleccionadas != null)
                            {
                                if (!ValidarMovimientoCoincidencias(int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta])))
                                {
                                    guardarEvento(ValidarCoincidenciasCliente(Parametros[(int)Enums.ParametrosDetallesVenta.Cliente], int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta])), Parametros);
                                }
                            }
                        }

                        //validacion linea 170
                        if (CFDMovTipo != string.Empty && Convert.ToBoolean(CFDMovTipo))
                        {
                            /*
                             * AGREGAR 1709 Evento
                             * */

                            CadenaSQL = "spAfectar";
                            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
                            parametros = new string[] { "@Modulo", "@ID", "@Accion", "@Base", "@GenerarMov", "@Usuario", "@Estacion" };
                            parametrosAPasar = new string[]
                            {
                                "VTAS",
                                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                "CONSECUTIVO",
                                "Todo",
                                null,
                                sUsuario, //-PrimeraFaseDeAutomatizacion //-ReservaOnline
                                ClaseEstatica.WorkStation.ToString()
                            };
                            EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, okref, true);

                            if (okref.Value != null && okref.Value.ToString() != string.Empty)
                            {
                                CadenaSQL = "SELECT Descripcion, Tipo from MensajeLista WITH(NOLOCK) WHERE Mensaje = @Mensaje";
                                parametros = new string[] { "@Mensaje" };
                                parametrosAPasar = new string[]
                                {
                                    okref.Value.ToString()
                                };
                                string[] Datos = new string[] { "Descripcion", "Tipo" };
                                List<string> DatosSQL = EjecutaSQLDataReader(CadenaSQL, parametros, parametrosAPasar, Datos);
                                if (DatosSQL.Count > 0 && DatosSQL[1].ToString() != string.Empty && DatosSQL[1].ToString() != "INFO" && DatosSQL[1].ToString() != "PRECAUCION")
                                {
                                    msgPrecaucion = DatosSQL[0].ToString();
                                    msgTitulo = okref.Value.ToString();
                                    return false;
                                }
                            }

                            //linea 173 SI(no CFD.Generar(Afectar.Modulo, Afectar.ID),  Forma.ActualizarForma AbortarOperacion)

                            CadenaSQL = "SELECT EnviarAlAfectar FROM EmpresaCFD WITH(NOLOCK) WHERE Empresa=@Empresa";
                            parametros = new string[] { "@Empresa", };
                            parametrosAPasar = new string[] { "MAVI" };
                            EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, null, true);


                            return true;
                        }
                    }
                    else
                    {
                        msgPrecaucion = "El usuario no tiene acceso a editar el movimiento: " + Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                        return false;
                    }

                    #endregion

                    /*
                    SI
						Config.Partidas y (MovTipo('VTAS', Venta:Venta.Mov)=VTAS.R)
					ENTONCES
						Forma('AfectarPartidasRemision')
					SINO
                        Afectar(Afectar.Modulo, Afectar.ID, Afectar.Mov, Afectar.MovID, 'Todo', '', 'Venta')
                    */

                    //linea 197 - 201
                    if (Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] == "VTAS.R")
                    {

                    }
                    else
                    {
                        if (Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] != "SINAFECTAR" || ClaseEstatica.ListaPermisosCreacion.Where(x => x == "VTAS." + Parametros[(int)Enums.ParametrosDetallesVenta.Mov]).Any())
                        {
                            CadenaSQL = "spAfectar";
                            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
                            parametros = new string[] { "@Modulo", "@ID", "@Accion", "@Base", "@GenerarMov", "@Usuario", "@Estacion" };
                            parametrosAPasar = new string[]
                            {
                                "VTAS",
                                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                "AFECTAR",
                                "Todo",
                                null,
                                sUsuario, //-PrimeraFaseDeAutomatizacion //-ReservaOnline
                                ClaseEstatica.WorkStation.ToString()
                            };
                            EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, okref, true);

                            if (okref.Value != null && okref.Value.ToString() != string.Empty)
                            {
                                CadenaSQL = "SELECT Descripcion, Tipo from MensajeLista WITH(NOLOCK) WHERE Mensaje = @Mensaje";
                                parametros = new string[] { "@Mensaje" };
                                parametrosAPasar = new string[]
                                {
                                    okref.Value.ToString()
                                };
                                string[] Datos = new string[] { "Descripcion", "Tipo" };
                                List<string> DatosSQL = EjecutaSQLDataReader(CadenaSQL, parametros, parametrosAPasar, Datos);
                                if (DatosSQL.Count > 0 && DatosSQL[1].ToString() != string.Empty && DatosSQL[1].ToString() != "INFO" && DatosSQL[1].ToString() != "PRECAUCION")
                                {
                                    msgPrecaucion = DatosSQL[0].ToString();
                                    msgTitulo = okref.Value.ToString();
                                    return false;
                                }

                            }

                            string NuevoMovID = SelectMovIDActualizado(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]);
                            Parametros[(int)Enums.ParametrosDetallesVenta.MovID] = NuevoMovID;

                            CadenaSQL = "SELECT COUNT(ID) FROM dbo.Venta WITH(NOLOCK) WHERE ID = @ID AND Estatus = 'PENDIENTE'";
                            parametros = new string[] { "@ID" };
                            parametrosAPasar = new string[]
                            {
                                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                            };
                            string CountPendientes = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                            //validacion linea 204
                            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" && CountPendientes == "1")
                            {

                                #region var globales

                                CadenaSQL = "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK)WHERE TablaNum = 'SUCURSALES SHM' AND Numero = @Sucursal";
                                parametros = new string[] { "@Sucursal" };
                                parametrosAPasar = new string[]
                                {
                                    Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal]
                                };
                                string CountNumSuc = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                                CadenaSQL = "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum = 'SUCURSALES RDP' AND CAST(Numero AS INT) = @Suc";
                                parametros = new string[] { "@Suc" };
                                parametrosAPasar = new string[]
                                {
                                    Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal]
                                };
                                string CountSucursalesRDP = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                                #endregion

                                //validaciones linea 208
                                if (CountNumSuc == "0" && (CountCanalMavi == "0" || Convert.ToInt32(CountArt) > 0))
                                {
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito")
                                    {
                                        string ArgumentosPlugin = Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + " "
                                            + ClaseEstatica.Usuario.usuario;
                                        EjecutarPlugins(ArgumentosPlugin, "DM0221LiberadorAuto.exe");
                                    }
                                }
                                else
                                {

                                    #region validaciones linea 223 - 287

                                    //validacion linea 223
                                    if (CountCanalMavi == "0" || Convert.ToInt32(CountArt) > 0)
                                    {
                                        CadenaSQL = "SP_SHM_APARTAMOV";
                                        parametros = new string[] { "@IdVta", "@Suc" };
                                        parametrosAPasar = new string[]
                                        {
                                            Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                            Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal]
                                        };
                                        EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                                        //validacion linea 229
                                        if (CountSucursalesRDP == "1")
                                        {
                                            //ruta ticket¡!
                                            string ArgumentosPlugin = "SHM " + Parametros[(int)Enums.ParametrosDetallesVenta.MovID] + " "
                                                + ClaseEstatica.Usuario.usuario + " "
                                                + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + " "
                                                + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                                + ClaseEstatica.WorkStation;
                                            EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                                        }
                                        else if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"].ToString() + @"SHM.exe"))
                                        {
                                            string ArgumentosPlugin = " " + ClaseEstatica.Usuario.usuario + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.MovID] + " "
                                            + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente];
                                            EjecutarPlugins(ArgumentosPlugin, "SHM.exe", ConfigurationManager.AppSettings["CarpetaSHM"].ToString());
                                        }
                                    }

                                    CadenaSQL = "Select Cadena From VentasCanalMAVI WITH(NOLOCK) Where ID = @ID";
                                    parametros = new string[] { "@ID" };
                                    parametrosAPasar = new string[]
                                    {
                                        Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA]
                                    };
                                    string CadenaVentaVale = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                                    CadenaSQL = "select COUNT(*) from Venta With(NoLock) where Cliente = @Cliente AND ESTATUS = 'CONCLUIDO' and Mov in ('Factura','Credilana') and EnviarA = 76";
                                    parametros = new string[] { "@Cliente" };
                                    parametrosAPasar = new string[]
                                    {
                                        Parametros[(int)Enums.ParametrosDetallesVenta.Cliente]
                                    };
                                    string CountClienteCredi = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                                    //validaciones linea 239
                                    if ((CadenaVentaVale == "VENTA VALE" || CadenaVentaVale == "CREDITAZZO" ||
                                        (new string[] { "76", "80" }).Contains(Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA])) && CountArt == "0")
                                    {

                                        CadenaSQL = "Select dbo.fnClientesNuevosCasaMAVI('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
                                        string CadenafnClientesNuevosCasaMAVI = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty);

                                        //validaciones linea 246
                                        if (
                                            CadenafnClientesNuevosCasaMAVI == "Nuevo" &&
                                            Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] == "Solicitud Credito" &&
                                            Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76" &&
                                            CountClienteCredi == "0"
                                            )
                                        {
                                            CadenaSQL = "Select Count(*) From MovBitacora with(nolock) where ID = @ID And Clave in (select valor from SHM_ValorDeEventosValera with(nolock))";
                                            parametros = new string[] { "@ID" };
                                            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                                            string CountMovBitacora = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                                            //validaciones linea 257
                                            if (CountMovBitacora == "0")
                                            {
                                                msgPrecaucion = "Agregar evento para valera";
                                                //Forma 'MovBitacoraAgregar' linea 263
                                            }
                                        }

                                        //validacion linea 267
                                        int numV = SucursalRDP(ClaseEstatica.Usuario.sucursal);
                                        if (numV == 1)
                                        {
                                            CadenaSQL = "SP_DM0244ActualizaSertipoope";
                                            parametros = new string[] { "@ID" };
                                            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                                            EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                                            string ArgumentosPlugin = "SHM3 "
                                                    + Parametros[(int)Enums.ParametrosDetallesVenta.MovID] + " "
                                                    + ClaseEstatica.Usuario.usuario + " "
                                                    + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + " "
                                                    + '"' + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " " + Parametros[(int)Enums.ParametrosDetallesVenta.BeneficiarioFinal] + '"' + " "
                                                    + ClaseEstatica.WorkStation;
                                            EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                                        }
                                        else
                                        {
                                            CadenaSQL = "SP_DM0244ActualizaSertipoope";
                                            parametros = new string[] { "@ID" };
                                            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                                            EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
                                            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"].ToString() + @"SHM.exe"))
                                            {
                                                string ArgumentosPlugin = " CLIENTEFINAL " + ClaseEstatica.Usuario.usuario + " "
                                                                    + Parametros[(int)Enums.ParametrosDetallesVenta.MovID] + " "
                                                                    + Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] + " "
                                                                    + Parametros[(int)Enums.ParametrosDetallesVenta.BeneficiarioFinal];
                                                EjecutarPlugins(ArgumentosPlugin, "SHM.exe", ConfigurationManager.AppSettings["CarpetaSHM"].ToString());
                                            }
                                        }
                                    }

                                    #endregion

                                }
                            }
                            MovAfectado = true;

                            //-CorreccionVale
                            afectarVale(int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), "", "afectar");

                            //return true;
                        }
                        else
                        {
                            msgPrecaucion = "El usuario no tiene acceso a editar el movimiento: " + Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                            return false;
                        }
                    }

                    //SI(Afectar.EnviarCFD, CFD.Enviar(Afectar.Modulo, Afectar.ID)) linea 287
                }
                else
                {
                    //string AfectarBase = "Pendiente";
                    //string AfectarGenerarMov = "";
                    //string AfectarFormaCaptura = "Venta";

                    //ConfigModulo(Info.Modulo, 'FlujoAbierto') = 'Si') linea 297 (Info.Modulo = 'VTAS)
                    if (
                        (
                        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] != "VTAS.F" &&
                        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] != "VTAS.FAR" &&
                        Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] != "VTAS.FB"
                        )
                        || DM0312_DetalleVenta.VerCantidadPendiente)
                    {
                        //if Forma('GenerarMovFlujo') ¿¿??
                        //else

                        //Info.MovGenerar¿?
                        //validaciones linea 302 - 331

                        if (DM0312_DetalleVenta.VerCantidadPendiente && ClaseEstatica.ListaPermisosCreacion.Where(x => x == "VTAS." + CadenaSiguienteMov).Any())
                        {


                            CadenaSQL = "spAfectar";
                            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
                            parametros = new string[] { "@Modulo", "@ID", "@Accion", "@Base", "@GenerarMov", "@Usuario", "@Estacion" };
                            parametrosAPasar = new string[]
                            {
                                "VTAS",
                                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                "GENERAR",
                                "Seleccion",
                                "Factura Mayoreo",
                                sUsuario, //-PrimeraFaseDeAutomatizacion //-ReservaOnline
                                ClaseEstatica.WorkStation.ToString()
                            };
                            string CadenaRetornada = EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, okref, true);

                            if (okref.Value != null && okref.Value.ToString() != string.Empty)
                            {
                                CadenaSQL = "SELECT Descripcion, Tipo from MensajeLista WITH(NOLOCK) WHERE Mensaje = @Mensaje";
                                parametros = new string[] { "@Mensaje" };
                                parametrosAPasar = new string[]
                                {
                                    okref.Value.ToString()
                                };
                                string[] Datos = new string[] { "Descripcion", "Tipo" };
                                List<string> DatosSQL = EjecutaSQLDataReader(CadenaSQL, parametros, parametrosAPasar, Datos);

                                /////////////////////////QUITAR PRECAUCION
                                if (DatosSQL.Count > 0 && DatosSQL[1].ToString() != string.Empty && DatosSQL[1].ToString() != "INFO" && DatosSQL[1].ToString() != "PRECAUCION")
                                {
                                    msgPrecaucion = DatosSQL[0].ToString();
                                    msgTitulo = okref.Value.ToString();
                                    return false;
                                }
                            }

                            if (CadenaRetornada != string.Empty)
                            {
                                MovimientoGenerado = true;
                                if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito"
                                    || (!ChecaSituaciones(Convert.ToInt32(CadenaRetornada))))
                                {
                                    AfectaMovimientoSinAfectarCreado(Convert.ToInt32(CadenaRetornada), ref msgPrecaucion, ref msgTitulo, VentasSeleccionadas);
                                }

                                CargaMovimientoCreado(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), Convert.ToInt32(CadenaRetornada), VentasSeleccionadas);
                                if (!AfectaDesdeTablero)
                                {
                                    CargaMovimientoCreado(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), VentasSeleccionadas, true);
                                }

                            }

                            return true;

                        }

                        CadenaSiguienteMov = string.Empty;

                        //CHECAR SI ES PEDIDO Y NO ES DE CONTADO (6,1,2,5) MUESTRA LAS OPCIONES PARA CONVERTIR
                        if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido" &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.Canal] != "6" &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.Canal] != "1" &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.Canal] != "2" &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.Canal] != "5"
                           )
                        {
                            CadenaSQL = "select dbo.fnMovFinalSegunFamilia_MAVI(" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + ")";
                            CadenaSiguienteMov = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);
                            //Form GenerarPedido = DialogoSeleccionaMov(Parametros[(int)Enums.ParametrosDetallesVenta.UEN]);
                            //GenerarPedido.ShowDialog();
                            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
                            TextInfo textInfo = cultureInfo.TextInfo;
                            if (CadenaSiguienteMov == "FACTURA VIU")
                            {
                                CadenaSiguienteMov = "Factura VIU";
                            }
                            else
                            {
                                if (CadenaSiguienteMov != "Factura VIU")
                                {
                                    CadenaSiguienteMov = textInfo.ToTitleCase(textInfo.ToLower(CadenaSiguienteMov));
                                }
                            }

                        }
                        else
                        {
                            CadenaSiguienteMov = SiguienteMov(Parametros[(int)Enums.ParametrosDetallesVenta.Mov], Parametros[(int)Enums.ParametrosDetallesVenta.UEN], Parametros[(int)Enums.ParametrosDetallesVenta.Referencia]);
                        }

                        if (CadenaSiguienteMov == string.Empty)
                        {
                            //-CorrecionReferencia
                            CadenaSQL = "SELECT top 1 a.Linea FROM Art a WITH(NOLOCK) INNER JOIN VentaD vd WITH(NOLOCK) ON a.articulo = vd.articulo WHERE vd.ID = @Id order by vd.Renglon asc";
                            parametros = new string[] { "@Id" };
                            parametrosAPasar = new string[]
                            {
                                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                            };

                            string sLinea = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                            switch (sLinea)
                            {
                                case "SEGUROS DE VIDA":
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "1" || Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "2")
                                    {
                                        CadenaSiguienteMov = "Cancela Seg Vida";
                                    }
                                    break;
                                case "CREDILANA":
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "1")
                                    {
                                        CadenaSiguienteMov = "Cancela Credilana";
                                    }
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "2")
                                    {
                                        CadenaSiguienteMov = "Cancela Prestamo";
                                    }
                                    break;
                                case "SEGUROS DE AUTOMOVILES":
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "1" || Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "2")
                                    {
                                        CadenaSiguienteMov = "Cancela Seg Auto";
                                    }
                                    break;
                                default:

                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "1")
                                    {
                                        CadenaSiguienteMov = "Devolucion Venta";
                                    }
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "2")
                                    {
                                        CadenaSiguienteMov = "Devolucion VIU";
                                    }
                                    if (Parametros[(int)Enums.ParametrosDetallesVenta.UEN] == "3")
                                    {
                                        CadenaSiguienteMov = "Devolucion Mayoreo";
                                    }
                                    break;
                            }

                            if (string.IsNullOrEmpty(CadenaSiguienteMov))
                            {
                                return false;
                            }
                        }

                        if (ClaseEstatica.ListaPermisosCreacion.Where(x => x == "VTAS." + CadenaSiguienteMov).Any())
                        {
                            CadenaSQL = "spAfectar";
                            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
                            parametros = new string[] { "@Modulo", "@ID", "@Accion", "@Base", "@GenerarMov", "@Usuario", "@Estacion" };
                            parametrosAPasar = new string[]
                            {
                                "VTAS",
                                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                "GENERAR",
                                DM0312_DetalleVenta.VerCantidadPendiente ? "SELECCION" : Parametros[(int)Enums.ParametrosDetallesVenta.Estatus],
                                CadenaSiguienteMov,
                                sUsuario, //-PrimeraFaseDeAutomatizacion //-ReservaOnline
                                ClaseEstatica.WorkStation.ToString()
                            };
                            string CadenaRetornada = string.Empty;
                            CadenaRetornada = EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, okref, true);


                            if (okref.Value != null && okref.Value.ToString() != string.Empty)
                            {
                                CadenaSQL = "SELECT Descripcion, Tipo from MensajeLista WITH(NOLOCK) WHERE Mensaje = @Mensaje";
                                parametros = new string[] { "@Mensaje" };
                                parametrosAPasar = new string[]
                                {
                                    okref.Value.ToString()
                                };
                                string[] Datos = new string[] { "Descripcion", "Tipo" };
                                List<string> DatosSQL = EjecutaSQLDataReader(CadenaSQL, parametros, parametrosAPasar, Datos);
                                if (DatosSQL.Count > 0 && DatosSQL[1].ToString() != string.Empty && DatosSQL[1].ToString() != "INFO" && DatosSQL[1].ToString() != "PRECAUCION")
                                {
                                    msgPrecaucion = DatosSQL[0].ToString();
                                    msgTitulo = okref.Value.ToString();
                                    return false;
                                }
                            }

                            if (CadenaRetornada != string.Empty)
                            {

                                //insertar serie en devoluciones
                                if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Devolucion"
                                    || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Sol Dev Mayoreo"
                                    || Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Sol Dev Unicaja")
                                {
                                    CadenaSQL = "Insert Into SerieLoteMov (Empresa, Modulo, ID, RenglonID, Articulo," +
                                        "SubCuenta, SerieLote, Cantidad, CantidadAlterna, Propiedades, Ubicacion, " +
                                        "Cliente, Localizacion, Sucursal, ArtCostoInv)" +
                                        " Select Empresa, Modulo, " + CadenaRetornada + ", RenglonID, Articulo," +
                                        "SubCuenta, SerieLote, Cantidad, CantidadAlterna, Propiedades, Ubicacion, " +
                                        "Cliente, Localizacion, Sucursal, ArtCostoInv from SerieLoteMov WITH(NOLOCK) WHERE ID = @ID";
                                    parametros = new string[] { "@ID" };
                                    parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                                    EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, null);
                                }

                                MovimientoGenerado = true;
                                if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito"
                                    || (!ChecaSituaciones(Convert.ToInt32(CadenaRetornada))))
                                {
                                    AfectaMovimientoSinAfectarCreado(Convert.ToInt32(CadenaRetornada), ref msgPrecaucion, ref msgTitulo, VentasSeleccionadas);
                                }

                                CargaMovimientoCreado(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), Convert.ToInt32(CadenaRetornada), VentasSeleccionadas);

                                if (!AfectaDesdeTablero)
                                {
                                    CargaMovimientoCreado(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), VentasSeleccionadas, true);
                                }

                                //Eliminar movimiento cuando hay un error en el spafectar
                                if (msgPrecaucion != "" &&
                                    (
                                        VentasSeleccionadas[PaginadoActual].MovTipo == "VTAS.D" ||
                                        VentasSeleccionadas[PaginadoActual].MovTipo == "VTAS.F"
                                    )
                                    && VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                                {
                                    EliminarMovimiento(VentasSeleccionadas);

                                    if (VentasSeleccionadas.Count > 1)
                                    {
                                        VentasSeleccionadas.RemoveAt(PaginadoActual);
                                        if (PaginadoActual > 0)
                                        {
                                            PaginadoActual = PaginadoActual - 1;
                                        }
                                        CDetalleVenta.MovimientoGenerado = true;
                                    }
                                }

                                //Actualiza la factura para que quede con el mismo reporte que el pedido
                                CadenaSQL = "SP_MaviDM0312ReporteServicio";
                                parametros = new string[] { "@IDVenta", "@OrigenID", "@InsertaEnFactura" };
                                parametrosAPasar = new string[]
                                {
                                    CadenaRetornada,
                                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                                    "True"
                                };
                                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                                //ReporteDescuento

                                int idReporteDescuento = getIdReporteDescuento(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]));

                                if (idReporteDescuento != 0)
                                {
                                    addReporteDescuento(VentasSeleccionadas[PaginadoActual].ID, idReporteDescuento, VentasSeleccionadas[PaginadoActual].MovId);
                                }
                            }

                            MovAfectado = true;

                            //-CorreccionVale
                            afectarVale(VentasSeleccionadas[PaginadoActual].ID, "", "afectar");

                            Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] = VentasSeleccionadas[PaginadoActual].Estatus;
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] = VentasSeleccionadas[PaginadoActual].Mov;
                            Parametros[(int)Enums.ParametrosDetallesVenta.MovID] = VentasSeleccionadas[PaginadoActual].MovId;
                            Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] = VentasSeleccionadas[PaginadoActual].ID.ToString();
                            Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] = VentasSeleccionadas[PaginadoActual].Cliente;
                            Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] = VentasSeleccionadas[PaginadoActual].EnviarA;
                            Parametros[(int)Enums.ParametrosDetallesVenta.FechaEmision] = VentasSeleccionadas[PaginadoActual].FechaAlta.ToString();
                            Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] = VentasSeleccionadas[PaginadoActual].Sucursal.ToString();
                            Parametros[(int)Enums.ParametrosDetallesVenta.Condicion] = VentasSeleccionadas[PaginadoActual].Condicion;
                            Parametros[(int)Enums.ParametrosDetallesVenta.Almacen] = VentasSeleccionadas[PaginadoActual].Almacen;
                            Parametros[(int)Enums.ParametrosDetallesVenta.MovTipo] = VentasSeleccionadas[PaginadoActual].MovTipo;
                            Parametros[(int)Enums.ParametrosDetallesVenta.IDEcommerce] = VentasSeleccionadas[PaginadoActual].IDEcommerce;

                            //return true;
                        }
                        else
                        {
                            msgPrecaucion = "El usuario no tiene acceso a editar el movimiento: " + CadenaSiguienteMov;
                            return false;
                        }
                    }
                    else
                    {
                        //validaciones linea 334 - 346
                        if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido")
                        {
                            Form GenerarPedido = new Form();
                            GenerarPedido.ShowDialog();
                        }
                    }
                }

                //validaciones 352 - 358

                CadenaSQL = "SP_MensajeDevMonedero";
                parametros = new string[] { "@Fac", "@FacID", "@Op" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov],
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                    "3"
                };
                string CadenaSP_MensajeDevMonedero = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

                //validacion 360
                if (CadenaSP_MensajeDevMonedero != string.Empty)
                {
                    msgPrecaucion = CadenaSP_MensajeDevMonedero;
                }

                #endregion

            }

            #endregion

            #region validaciones linea 370 - 394

            //validaciones linea 370 - 375
            if (CountCanalMavi != string.Empty && Convert.ToInt32(CountCanalMavi) > 0)
            {
                //linea 373
            }

            CadenaSQL = "SELECT CATEGORIA FROM VentasCanalMavi WITH(NOLOCK) WHERE ID = @EnviarA";
            parametros = new string[] { "@EnviarA" };
            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] };
            string CATEGORIAEnviarA = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            //validacion linea 384
            if (
                    (
                        (
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura VIU" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Prestamo Personal" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Seguro Vida" ||
                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura"
                        )
                        &&
                            Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] != "CANCELADO"
                    )
                    &&
                        CATEGORIAEnviarA == "CREDITO MENUDEO"
               )
            {
                CadenaSQL = "SP_DM0169AcutalizaBanderaVenta";
                parametros = new string[] { "@Cliente", "@Mov", "@MovID", "@Accion" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.Cliente],
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov],
                    Parametros[(int)Enums.ParametrosDetallesVenta.MovID],
                    "1"
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            //validacion linea 389
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito")
            {
                CadenaSQL = "SP_DM0257ListaNegra";
                parametros = new string[] { "@PROSPECTO", "@USUARIO", "@SUCURSAL", "@ID", "@MovID" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.Cliente],
                    ClaseEstatica.Usuario.usuario,
                    Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal],
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                    Parametros[(int)Enums.ParametrosDetallesVenta.MovID]
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            //validaciones linea 394
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido")
            {
                CadenaSQL = "SP_DM0270ConsecPedido";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            #endregion

            #region validaciones linea 397 - 406

            CadenaSQL = "select propiedades from SerieLoteMov WITH(NOLOCK) where modulo = 'VTAS' AND id = @ID";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string propiedades = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            //validacion 397 - 401

            //CadenaSQL = "select dbo.FN_DM0169PrecioContadoItalika(" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + ")";
            //parametros = new string[] { "@ID" };
            //parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            //string propiedades = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            CadenaSQL = "Select ISNULL(Valor,0) From TablaStD WITH(NOLOCK) Where TablaSt = 'PRERASTREO COINCIDENCIAS' and Nombre = 'Prerastreo Ventas'";
            string Valor = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty);

            //1709
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito" && Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR")
            {
                if (Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] != "")
                {
                    if (!ValidarMovimientoCoincidencias(int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta])))
                    {
                        guardarEvento(ValidarCoincidenciasCliente(Parametros[(int)Enums.ParametrosDetallesVenta.Cliente], int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta])), Parametros);
                    }
                }
            }

            //Validacion linea 403
            if (Valor != string.Empty && Convert.ToInt32(Valor) == 1)
            {
                CadenaSQL = "SELECT COUNT(*) FROM VENTA WHERE Mov = 'Solicitud Credito' AND Estatus = 'PENDIENTE' AND id = @ID";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[] { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
                string sCoincidencias = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

                //Validacion linea 406
                if (sCoincidencias == "1")
                {
                    CadenaSQL = "Select ISNULL(Valor,0) From TablaStD WITH(NOLOCK) Where TablaSt = 'PRERASTREO COINCIDENCIAS' and Nombre = 'Prerastreo Tipo'";
                    string ValorTipo = EjecutaComandosSQL(CadenaSQL, null, null, string.Empty);
                    if (ValorTipo == "Nuevo")
                    {
                        CadenaSQL = "SELECT MAVITIPOVENTA FROM Venta WITH(NOLOCK) WHERE ID = @ID";
                        parametros = new string[] { "@ID" };
                        parametrosAPasar = new string[]
                        {
                            Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                        };
                        string MAVITIPOVENTA = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);
                        if (MAVITIPOVENTA == "Nuevo")
                        {
                            frmCoincidencias frmCoincidencias = new frmCoincidencias(Parametros);
                            frmCoincidencias.Show();
                            frmCoincidencias.Hide();
                        }
                    }
                }
            }

            #endregion

            #region validaciones finales linea 422 - 460

            //validaciones linea 422
            if (Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "SINAFECTAR")
            {

                CadenaSQL = "SP_CLONAR_EVENTO_VALERA";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            CadenaSQL = "Select dbo.fnClientesNuevosCasaMAVI(" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + ")";
            string cadenafnClientesNuevosCasaMAVI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            CadenaSQL = "select COUNT(*) from DM0244_FOLIOS_VALES With(NoLock) where CUENTA = '" + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + "' AND ESTATUS = 1";
            string countDM0244_FOLIOS_VALES = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            //validaciones linea 424
            if (
                    (
                        cadenafnClientesNuevosCasaMAVI == "Nuevo" ||
                        countDM0244_FOLIOS_VALES == "0"
                    )
                &&
                    CountArt == "0"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
               )
            {
                CadenaSQL = "Select dbo.fn_MaviDM0244ValeAsignado(" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + ")";
                string cadenafn_MaviDM0244ValeAsignado = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);
                if (cadenafn_MaviDM0244ValeAsignado == "0")
                {
                    //abre forma 'DM0244NipValesVtaFrm' linea 443
                }
            }

            //validaciones linea 446
            if (
                    (
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Factura" ||
                        Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Credilana"
                    )
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "CONCLUIDO"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
                )
            {
                CadenaSQL = "SHM_InsertImporte_Cte";
                parametros = new string[] { "@ID", "@Cuenta" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                    Parametros[(int)Enums.ParametrosDetallesVenta.Cliente]
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            //validaciones linea 448
            if
            (
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion Venta" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Devolucion VIU" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Credilana" ||
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Cancela Prestamo"
            )
            {
                CadenaSQL = "SPDM0274NotaCgoDevVenta";
                parametros = new string[] { "@ID" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            //validaciones linea 455
            if
            (
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE"
            )
            {
                CadenaSQL = "SP_MaviDM0286AgregarEventoAnalisis";
                parametros = new string[] { "@ID", "@Sucursal", "@Usuario" };
                parametrosAPasar = new string[]
                {
                    Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                    Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal],
                    ClaseEstatica.Usuario.usuario
                };
                EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);
            }

            CadenaSQL = "SP_MaviDM0263ActAgente";
            parametros = new string[] { "@Cte", "@ID", "@Sucursal" };
            parametrosAPasar = new string[]
            {
                Parametros[(int)Enums.ParametrosDetallesVenta.Cliente],
                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal]
            };

            //SP_MaviDM0263ActAgente linea 459
            EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty, true);

            //validaciones linea 460
            //if
            //(
            //    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Pedido" &&
            //    (
            //        Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] == "41" ||
            //        Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal] == "90"
            //    )
            //)
            //{
            //    string ArgumentosPlugin = "VTASPEDIDO " + Parametros[(int)Enums.ParametrosDetallesVenta.IDEcommerce] + " "
            //                            + "PROCESADO";
            //    EjecutarPlugins(ArgumentosPlugin, "ActualizaEcommers.exe");
            //}

            #endregion

            return MovAfectado;

        }

        /// <summary>
        /// Checa si el movimiento se puede afectar por el usuario
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 20/09/17
        public bool PuedeAfectar(string Usuario, string Estatus, string Situacion, string Mov)
        {

            bool PuedeAfectar = true;

            if (!AccesosDeUsuario.CUsuario.Afectar)
            {
                PuedeAfectar = false;
                return PuedeAfectar;
            }

            if (!AccesosDeUsuario.CUsuario.AfectarOtrosMovs)
            {
                if (AccesosDeUsuario.CUsuario.Usuario != Usuario)
                {
                    PuedeAfectar = false;
                    return PuedeAfectar;
                }
            }

            if (Estatus != "SINAFECTAR" &&
                Estatus != "PENDIENTE")
            {
                PuedeAfectar = false;
                return PuedeAfectar;
            }

            if (Situacion != string.Empty)
            {
                string[] Parametros = new string[]
                {
                    "@Mov",
                    "@Estatus",
                    "@Situacion"
                };

                string[] Variables = new string[]
                {
                    Mov,
                    Estatus,
                    Situacion
                };

                string comando = "SELECT Count(PermiteAfectacion) FROM MovSituacion WITH(NOLOCK) WHERE Mov = @Mov AND Modulo = 'VTAS' " +
                    "AND Estatus = @Estatus AND Situacion = @Situacion And PermiteAfectacion = 1";

                string cadenaPuedeAfectar = EjecutaComandosSQL(comando, Parametros, Variables, "");

                if (cadenaPuedeAfectar == "0")
                {
                    PuedeAfectar = false;
                }
            }
            else if (Estatus == "SINAFECTAR")
            {
                string comando = "SELECT PermiteAfectacion FROM MovSituacion WITH(NOLOCK) WHERE Estatus='SINAFECTAR' and Modulo='VTAS' AND Mov = @Mov AND Flujo='Inicial Todas'";
                SqlCommand sqlCommand = new SqlCommand(comando, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                string[] Parametros = new string[] { "@Mov" };
                string[] Variables = new string[] { Mov };
                string cadenaPuedeAfectar = EjecutaComandosSQL(comando, Parametros, Variables, "");

                if (cadenaPuedeAfectar == "False")
                {
                    PuedeAfectar = false;
                }
                else
                {
                    PuedeAfectar = true;
                }
            }

            return PuedeAfectar;
        }

        /// <summary>
        /// Checar que movimiento continua al afectar
        /// </summary>
        /// <param name="MovActual">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 22/09/17
        private string SiguienteMov(string MovActual, string UEN, string Referencia)
        {
            string sigMov = string.Empty;

            switch (MovActual)
            {
                case "Solicitud Credito":
                    sigMov = "Analisis Credito";
                    break;
                case "Analisis Credito":
                    sigMov = "Pedido";
                    break;
                case "Pedido":
                    if (UEN == "1")
                    {
                        sigMov = "Factura";
                    }
                    else
                    {
                        sigMov = "Factura VIU";
                    }
                    break;
                case "Pedido Mayoreo":
                    sigMov = "Factura Mayoreo";
                    break;
                case "Solicitud Devolucion":
                    //Checar que mov de devolucion se va a generar
                    string RefMov = Referencia.Substring(0, Referencia.LastIndexOf(" "));
                    sigMov = MovDevolucion(RefMov);
                    break;
                case "Sol Dev Unicaja":
                    sigMov = "Devolucion Venta";
                    break;
                case "Sol Dev Mayoreo":
                    sigMov = "Devolucion Mayoreo";
                    break;
            }

            return sigMov;
        }

        /// <summary>
        /// Devolucion mov
        /// </summary>
        /// <param name="RefMov">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 12/01/18
        private string MovDevolucion(string RefMov)
        {
            string NextMov = "";
            if (RefMov == "Factura")
            {
                NextMov = "Devolucion Venta";
            }
            else if (RefMov == "Factura VIU")
            {
                NextMov = "Devolucion VIU";
            }
            else if (RefMov == "Credilana")
            {
                NextMov = "Cancela Credilana";
            }
            else if (RefMov == "Prestamo Personal")
            {
                NextMov = "Cancela Prestamo";
            }
            else if (RefMov == "Seguro Auto")
            {
                NextMov = "Cancela Seg Auto";
            }
            else if (RefMov == "Seguro Vida")
            {
                NextMov = "Cancela Seg Vida";
            }
            return NextMov;
        }

        #region metodos para afectar siguiente movimiento

        /// <summary>
        /// Crea forma o dialogo para seleccionar el siguiente movimiento a generar al afectar
        /// </summary>
        /// <param name="UEN">string</param>
        /// <returns>Form</returns>
        /// Developer: Dan Palacios
        /// Date: 26/09/17
        protected Form DialogoSeleccionaMov(string UEN)
        {
            Form FormaGenerarPedido = new Form
            {
                FormBorderStyle = FormBorderStyle.FixedSingle,
                ControlBox = false,
                MaximizeBox = false,
                MinimizeBox = false,
                Width = 220,
                Height = 140,

                StartPosition = FormStartPosition.CenterScreen
            };
            ComboBox cb_siguienteMov = new ComboBox();
            FormaGenerarPedido.BackColor = Color.White;
            cb_siguienteMov.DropDownStyle = ComboBoxStyle.DropDownList;
            if (UEN == "1")
            {
                cb_siguienteMov.Items.Add("Factura");
                cb_siguienteMov.Text = "Factura";
            }
            else
            {
                cb_siguienteMov.Items.Add("Factura VIU");
                cb_siguienteMov.Text = "Factura VIU";
            }

            CadenaSiguienteMov = cb_siguienteMov.Text;

            int xPositionControls = FormaGenerarPedido.Width / 2;
            int yPositionControls = FormaGenerarPedido.Height / 2;

            cb_siguienteMov.Items.Add("Credilana");
            cb_siguienteMov.Items.Add("Seguro Vida");
            cb_siguienteMov.Items.Add("Seguro Auto");
            cb_siguienteMov.Location = new Point(xPositionControls - (cb_siguienteMov.Width / 2), yPositionControls - cb_siguienteMov.Height - 25);
            cb_siguienteMov.SelectedIndexChanged += MovCambia;
            FormaGenerarPedido.Controls.Add(cb_siguienteMov);

            Button btnSeleccionaSiguienteMov = new Button
            {
                Text = "Aceptar"
            };
            btnSeleccionaSiguienteMov.Click += SeleccionarMovimiento;
            btnSeleccionaSiguienteMov.Location = new Point(xPositionControls - (btnSeleccionaSiguienteMov.Width / 2), yPositionControls - btnSeleccionaSiguienteMov.Height + 15);
            btnSeleccionaSiguienteMov.BackColor = SystemColors.ControlLight;
            FormaGenerarPedido.Controls.Add(btnSeleccionaSiguienteMov);

            Button btnCancelar = new Button
            {
                Text = "Cancelar"
            };
            btnCancelar.Click += CancelarMovimiento;
            btnCancelar.Location = new Point(xPositionControls - (btnCancelar.Width / 2), yPositionControls - btnCancelar.Height + 45);
            btnCancelar.BackColor = SystemColors.ControlLight;
            FormaGenerarPedido.Controls.Add(btnCancelar);


            return FormaGenerarPedido;
        }

        /// <summary>
        /// Selecciona movimiento del combobox y cierra el dialogo de seleccion
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/09/17
        protected void SeleccionarMovimiento(object sender, EventArgs e)
        {
            Control btn = (Control)sender;
            btn.FindForm().Close();
        }

        /// <summary>
        /// cancela el movimiento seleccionado y cierra el dialogo de seleccion
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/09/17
        protected void CancelarMovimiento(object sender, EventArgs e)
        {
            CadenaSiguienteMov = string.Empty;
            Control btn = (Control)sender;
            btn.FindForm().Close();
        }

        /// <summary>
        /// Cambia el movimiento al seleccionado por el combobox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/09/17
        protected void MovCambia(object sender, EventArgs e)
        {
            ComboBox cb_siguienteMov = (ComboBox)sender;
            CadenaSiguienteMov = cb_siguienteMov.Text;
        }

        /// <summary>
        /// Afecta un movimiento que ha sido creado por spafectar(doble afectacion
        /// </summary>
        /// <param name="idVentaGenerado">int</param>
        /// Developer: Dan Palacios
        /// Date: 27/09/17
        protected void AfectaMovimientoSinAfectarCreado(int idVentaGenerado, ref string msgPrecaucion, ref string msgTitulo, List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            SqlCommand command = new SqlCommand("SELECT v.Mov, v.MovID, v.OrigenSucursal SucursalOrigen, cte.Cliente, "
                + "v.Condicion, ImporteTotal = CASE WHEN v.DescuentoGlobal IS NULL THEN ((v.importe + v.Impuestos)) ELSE (((v.importe*(v.DescuentoGlobal/100)) + v.Impuestos)) END, "
                + "v.MaviTipoVenta, "
                + "v.Estatus, v.ReferenciaOrdenCompra,"
                + "FechaAlta = CONVERT(Datetime, (Select DBO.Fn_MaviServicasaServicredFechaAlta(v.ID,'')), 100), "
                + "v.Almacen, v.Id, v.referenciaordencompra as IDEcommerce, "
                + "v.UEN, v.OrigenID, v.Origen, v.Vencimiento, v.OrigenTipo, v.Impuestos,"
                + "v.Importe, mv.Clave OrigenTipoMov, cea.Categoria CategoriaEnviarA,"
                + "v.EnviarA, "
                + "MovTipo = (SELECT Clave FROM MovTipo mt WITH(NOLOCK) WHERE mt.Mov = v.Mov AND mt.Modulo = 'VTAS')"
                + " FROM VENTA v WITH(NOLOCK) INNER JOIN Cte WITH(NOLOCK) ON v.Cliente = Cte.Cliente "
                + " LEFT JOIN MovTipo mv WITH(NOLOCK) ON mv.Mov = v.Origen AND mv.Modulo = 'VTAS'"
                + " LEFT JOIN CteEnviarA cea WITH(NOLOCK) ON cea.ID = v.EnviarA AND cea.Cliente = v.Cliente "
                + " WHERE v.ID = @ID", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            command.Parameters.AddWithValue("@ID", idVentaGenerado);

            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        string importeTotal = "0";
                        if (dr["ImporteTotal"] != null && dr["ImporteTotal"].ToString() != string.Empty)
                        {
                            importeTotal = dr["ImporteTotal"].ToString();
                        }
                        string[] Parametros =
                        {
                            dr["Mov"].ToString(),
                            dr["MovId"].ToString(),
                            "VTAS",
                            dr["ID"].ToString(),
                            dr["Cliente"].ToString(),
                            dr["Estatus"].ToString(),
                            dr["EnviarA"].ToString(),
                            dr["FechaAlta"] != null ? Convert.ToDateTime(dr["FechaAlta"]).ToString() : null,
                            dr["SucursalOrigen"].ToString(),
                            dr["Condicion"].ToString(),
                            dr["CategoriaEnviarA"].ToString(),
                            "",
                            dr["Almacen"].ToString(),
                            dr["UEN"].ToString(),
                            dr["OrigenID"].ToString(),
                            dr["ReferenciaOrdenCompra"].ToString(),
                            dr["Origen"].ToString(),
                            importeTotal,
                            dr["MovTipo"].ToString(),
                            dr["Vencimiento"].ToString(),
                            dr["OrigenTipo"].ToString(),
                            dr["Impuestos"].ToString(),
                            dr["Importe"].ToString(),
                            dr["OrigenTipoMov"].ToString(),
                            dr["IDEcommerce"].ToString(),
                            dr["EnviarA"].ToString()
                        };
                        if (ValidacionesAfectar(Parametros, ref msgPrecaucion))
                        {
                            if (CondicionAfectar(Parametros, ref msgPrecaucion))
                            {
                                Afectar(Parametros, ref msgPrecaucion, ref msgTitulo, VentasSeleccionadas);
                            }
                        }
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AfectaMovimientoSinAfectarCreado", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function AfectaMovimientoSinAfectarCreado, class: CDetalleVenta.cs");
            }
        }

        /// <summary>
        /// Obtiene info de movimiento donde el id coincida
        /// </summary>
        /// <param name="idVenta">int</param>
        /// <returns>DM0312_MExploradorVenta</returns>
        /// Developer: Dan Palacios
        /// Date: 27/09/17
        public DM0312_MExploradorVenta ModeloDeMovimiento(int idVenta)
        {
            SqlCommand command = new SqlCommand("SELECT v.Mov, v.MovID, v.OrigenSucursal SucursalOrigen, cte.Cliente, cte.Nombre, "
                + "v.Situacion, v.Condicion, ImporteTotal = CASE WHEN v.DescuentoGlobal IS NULL THEN ((v.importe + v.Impuestos)) ELSE (((v.importe*(v.DescuentoGlobal/100)) + v.Impuestos)) END, "
                + "v.MaviTipoVenta, VCM.Clave CanalVenta, Monedero = CASE WHEN ISNULL(v.Redimeptos,0) = 1 THEN 'Si' ELSE 'No' END, "
                + "v.Estatus, Cte.MaviRecomendadoPor RELACIONADO, ReferenciaAnterior = (Select DBO.Fn_MaviServicasaServicredMovAnterior(v.ID,'')), "
                + "Reactivacion=CASE WHEN (Select DBO.Fn_MaviServicasaServicredUltimaCalificacionReactivacion(v.ID,'')) = 'VTA00001' THEN 'REACTIVACION' ELSE '' END, "
                + "Grupo=LTRIM(RTRIM(SUBSTRING((Select DBO.Fn_MaviServicasaServicredUltimaCalificacion(v.ID,'')),10,1))), "
                + "FechaAlta = CONVERT(Datetime, (Select DBO.Fn_MaviServicasaServicredFechaAlta(v.ID,'')), 100), v.Concepto,"
                + "Calificacion = (SUBSTRING((Select DBO.Fn_MaviServicasaServicredUltimaCalificacion(v.ID,'')),1,9)) + (SUBSTRING((Select DBO.Fn_MaviServicasaServicredUltimaCalificacion(v.ID,'')),12,(CHARINDEX('/9/',(Select DBO.Fn_MaviServicasaServicredUltimaCalificacion(v.ID,''))))-13)), "
                + "cte.Poblacion, v.Agente, v.Almacen, v.Id, v.Usuario, v.Referenciaordencompra as IDEcommerce, v.AnticiposFacturados, "
                + "Seguimiento = (DBO.Fn_MaviServicasaServicredUsuarioUltimaModificacion(v.ID,'')), "
                + "v.FechaEmision ff, v.Sucursal, v.SucursalDestino, "
                + "FUM = Convert(Datetime, (Select DBO.Fn_MaviServicasaServicredFUM(v.ID,'')), 100), v.EnviarA, "
                + "GrupoTrabajo = (SELECT u.GrupoTrabajo FROM Usuario u WITH(NOLOCK) WHERE u.Usuario = v.Usuario),"
                + "MovTipo = (SELECT Clave FROM MovTipo mt WITH(NOLOCK) WHERE mt.Mov = v.Mov AND mt.Modulo = 'VTAS')"
                + "FROM VENTA v WITH(NOLOCK) INNER JOIN Cte WITH(NOLOCK) ON v.Cliente = Cte.Cliente "
                + "LEFT JOIN VENTASCANALMAVI VCM WITH(NOLOCK) ON v.ENVIARA = VCM.ID "
                + "WHERE v.ID = @ID", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            command.Parameters.AddWithValue("@ID", idVenta);
            DM0312_MExploradorVenta model = new DM0312_MExploradorVenta();
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        model.Movimiento = dr["Mov"].ToString() + " " + dr["MovId"].ToString();
                        if (dr["SucursalOrigen"] != null && dr["SucursalOrigen"].ToString() != string.Empty)
                        {
                            model.Suc = Convert.ToInt32(dr["SucursalOrigen"].ToString());
                        }
                        model.Cliente = dr["Cliente"].ToString();
                        model.Nombre = dr["Nombre"].ToString();
                        model.Situacion = dr["Situacion"].ToString();
                        model.Condicion = dr["Condicion"].ToString();
                        model.ImporteTotal = dr["ImporteTotal"].ToString();
                        model.TipoCliente = dr["MaviTipoVenta"].ToString();
                        model.Canal = dr["CanalVenta"].ToString();
                        model.Monedero = dr["Monedero"].ToString();
                        model.Estatus = dr["Estatus"].ToString();
                        model.Reactivacion = dr["Reactivacion"].ToString();
                        model.Grupo = dr["Grupo"].ToString();
                        model.Relacionado = dr["Relacionado"].ToString();
                        model.ReferenciaAnterior = dr["ReferenciaAnterior"].ToString();
                        if (dr["FechaAlta"] != null && dr["FechaAlta"].ToString() != string.Empty)
                        {
                            model.FechaAlta = Convert.ToDateTime(dr["FechaAlta"]);
                        }
                        model.Calificaciones = dr["Calificacion"].ToString();
                        model.Poblacion = dr["Poblacion"].ToString();
                        model.Seguimiento = dr["Seguimiento"].ToString();
                        model.Agente = dr["Agente"].ToString();
                        if (dr["FUM"] != null && dr["FUM"].ToString() != string.Empty)
                        {
                            model.FechaUltimaMod = Convert.ToDateTime(dr["FUM"]);
                        }
                        model.Almacen = dr["Almacen"].ToString();
                        model.Mov = dr["mov"].ToString();
                        model.MovId = dr["MovID"].ToString();
                        model.ID = Convert.ToInt32(dr["Id"].ToString());
                        model.Usuario = dr["Usuario"].ToString();
                        model.IDEcommerce = dr["IDEcommerce"].ToString();
                        model.AnticiposFacturados = dr["AnticiposFacturados"].ToString();
                        model.GrupoTrabajo = dr["GrupoTrabajo"].ToString();
                        //model.TipoCredito = dr["TipoCredito"].ToString();
                        model.Concepto = dr["Concepto"].ToString();
                        model.EnviarA = dr["EnviarA"].ToString();
                        model.MaviTipoVenta = dr["MaviTipoVenta"].ToString();
                        model.MovTipo = dr["MovTipo"].ToString();
                        model.ff = dr["ff"].ToString();
                        model.Sucursal = dr["Sucursal"] != null && dr["Sucursal"].ToString() != string.Empty ? Convert.ToInt32(dr["Sucursal"]) : 0;
                        model.SucursalDestino = dr["SucursalDestino"] != null && dr["SucursalDestino"].ToString() != string.Empty ? Convert.ToInt32(dr["SucursalDestino"]) : 0;
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ModeloDeMovimiento", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function ModeloDeMovimiento, class: CDetalleVenta.cs");
            }

            return model;
        }

        /// <summary>
        /// Carga la informacion para el modelo del movimiento creado
        /// </summary>
        /// <param name="idVentaAnterior">int</param>
        /// <param name="idVentaGenerado">int</param>
        /// Developer: Dan Palacios
        /// Date: 27/09/17
        public void CargaMovimientoCreado(int idVentaAnterior, int idVentaGenerado, List<DM0312_MExploradorVenta> VentasSeleccionadas, bool Actualizar = false)
        {

            DM0312_MExploradorVenta ModeloGenerado = ModeloDeMovimiento(idVentaGenerado);
            //Busca la posicion del modelo que genero le movimiento para inserta enseguida de este
            int index = 0;
            foreach (DM0312_MExploradorVenta venta in VentasSeleccionadas)
            {
                index++;
                if (venta.ID == idVentaAnterior)
                {
                    break;
                }
            }

            if (Actualizar)
            {
                index = index - 1;
                VentasSeleccionadas.RemoveAt(index);
                VentasSeleccionadas.Insert(index, ModeloGenerado);
            }
            else
            {
                VentasSeleccionadas.Insert(index, ModeloGenerado);
                PaginadoActual = index;
            }

        }

        /// <summary>
        /// Checar si el movimiento tiene situaciones
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 02/11/17
        protected bool ChecaSituaciones(int IDVenta)
        {
            bool MovConSituaciones = false;
            List<MSituaciones> ListaSituaciones = new List<MSituaciones>();
            DM0312_DetalleSituaciones.IDVenta = IDVenta;
            DM0312_DetalleSituaciones.Estatus = "SINAFECTAR";
            DM0312_DetalleSituaciones.Mov = "Factura";
            ListaSituaciones = CSituaciones.ObtenerSituaciones();
            if (ListaSituaciones.Count > 0)
            {
                MovConSituaciones = true;
            }
            return MovConSituaciones;
        }

        #endregion

        #endregion

        #region Ejecuciones SQL-Plugins

        /// <summary>
        /// ejecuta un query de sql
        /// </summary>
        /// <param name="Comando">string</param>
        /// <param name="ParametrosSQL">string[]</param>
        /// <param name="ParametrosAPasar">string[]</param>
        /// <param name="CadenaALeer">string, pasar empty string para que el data reader devuelva la primera columna</param>
        /// <param name="EjecutaStoredProcedure">bool</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 31/08/17
        public string EjecutaComandosSQL(string Comando, string[] ParametrosSQL, string[] ParametrosAPasar, string CadenaALeer, bool EjecutaStoredProcedure = false)
        {
            string StringADevolver = "";

            SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 600
            };
            if (EjecutaStoredProcedure)
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
            }

            if (ParametrosSQL != null)
            {
                for (int i = 0; i < ParametrosSQL.Length; i++)
                {
                    sqlCommand.Parameters.AddWithValue(ParametrosSQL[i], ParametrosAPasar[i]);
                }
            }

            try
            {
                if (CadenaALeer != null)
                {
                    SqlDataReader dr = sqlCommand.ExecuteReader();

                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (CadenaALeer != string.Empty)
                            {
                                StringADevolver = dr[CadenaALeer].ToString();
                            }
                            else
                            {
                                StringADevolver = dr[0].ToString();
                            }
                        }
                    }
                    dr.Close();
                }
                else
                {
                    sqlCommand.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaComandosSQL comando/sp: " + Comando, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutaComandosSQL comando/sp: " + Comando + ", class: CDetalleVenta.cs");
            }

            return StringADevolver;
        }

        /// <summary>
        /// ejecuta un query de sql
        /// </summary>
        /// <param name="Comando">string</param>
        /// <param name="ParametrosSQL">string[]</param>
        /// <param name="ParametrosAPasar">string[]</param>
        /// <param name="CadenaALeer">string</param>
        /// <param name="EjecutaStoredProcedure">bool</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 31/08/17
        private string EjecutaComandosSQLWithReturn(string Comando, string[] ParametrosSQL, string[] ParametrosAPasar, string CadenaALeer, SqlParameter returnValue, bool EjecutaStoredProcedure = false)
        {
            string StringADevolver = "";

            SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 600
            };
            if (EjecutaStoredProcedure)
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
            }

            if (ParametrosSQL != null)
            {
                for (int i = 0; i < ParametrosSQL.Length; i++)
                {
                    sqlCommand.Parameters.AddWithValue(ParametrosSQL[i], ParametrosAPasar[i]);
                }
            }

            if (returnValue != null)
            {
                sqlCommand.Parameters.Add(returnValue);
            }

            var returnParameter = sqlCommand.Parameters.Add("@ReturnVal", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;

            try
            {
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaComandosSQLWithReturn comando/sp: " + Comando, "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function EjecutaComandosSQLWithReturn, CDetalleVenta.cs");
            }

            var result = returnParameter.Value;
            if (result != null)
            {
                StringADevolver = result.ToString();
            }

            return StringADevolver;
        }

        /// <summary>
        /// Ejecuta sql data reader
        /// </summary>
        /// <param name="Comando">string</param>
        /// <param name="ParametrosSQL">string[]</param>
        /// <param name="ParametrosAPasar">string[]</param>
        /// <param name="EjecutaStoredProcedure">bool</param>
        /// <returns>List<string></returns>
        /// Developer: Dan Palacios
        /// Date: 19/09/17
        public List<string> EjecutaSQLDataReader(string Comando, string[] ParametrosSQL, string[] ParametrosAPasar, string[] Fields = null, bool EjecutaStoredProcedure = false)
        {
            List<string> DataReader = new List<string>();
            SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 600
            };
            if (EjecutaStoredProcedure)
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
            }

            if (ParametrosSQL != null)
            {
                for (int i = 0; i < ParametrosSQL.Length; i++)
                {
                    sqlCommand.Parameters.AddWithValue(ParametrosSQL[i], ParametrosAPasar[i]);
                }
            }

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (Fields != null)
                        {
                            foreach (string st in Fields)
                            {
                                DataReader.Add(dr[st].ToString());
                            }
                        }
                        else
                        {
                            DataReader.Add(dr[0].ToString());
                        }
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaDataReader comando/sp:" + Comando, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutaDataReader, class: CDetalleVenta");
            }

            return DataReader;
        }

        /// <summary>
        /// Ejecuta el plugin seleccionado
        /// </summary>
        /// <param name="Argumentos">string</param>
        /// <param name="plugin">string</param>
        /// Developer: Dan Palacios
        /// Date: 31/08/17
        public void EjecutarPlugins(string Argumentos, string pluginName, string folderName = "")
        {
            if (folderName == "")
            {
                //-CambioRutaPlugins
                //folderName = ConfigurationManager.AppSettings["plugInsCubos"].ToString();
                folderName = ClaseEstatica.plugInPath;
            }
            try
            {
                Process NewProcess = new Process();
                NewProcess.StartInfo.WorkingDirectory = folderName;
                NewProcess.StartInfo.FileName = folderName + @"" + pluginName;
                NewProcess.StartInfo.Verb = "runas";
                NewProcess.StartInfo.UseShellExecute = false;
                if (Argumentos != string.Empty)
                {
                    NewProcess.StartInfo.Arguments = Argumentos;
                }
                NewProcess.Start();

                //-Revision de Procesos 2019-05-28
                //NewProcess.WaitForExit();
                if (pluginName != "SHM.exe")
                {
                    NewProcess.WaitForExit();
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutarPlugins, plugin:" + pluginName, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutarPlugins, class: CDetalleVenta.cs");
            }
        }

        public string EjecutarPluginsVideoLlamada(string Argumentos, string folderName = "")
        {
            string pluginName = "autenticacionVideoLlamada.exe";
            string respuesta = "NO";

            if (folderName == "")
            {
                //-CambioRutaPlugins
                //folderName = ConfigurationManager.AppSettings["plugInsCubos"].ToString();
                folderName = ClaseEstatica.plugInPath;
            }
            try
            {
                string[] separarArgumentos = Argumentos.Split(' ');
                if (!validarGeneracionVideollamada(int.Parse(separarArgumentos[0])))
                {
                    Process NewProcess = new Process();
                    NewProcess.StartInfo.WorkingDirectory = folderName;
                    NewProcess.StartInfo.FileName = folderName + @"" + pluginName;
                    NewProcess.StartInfo.Verb = "runas";
                    NewProcess.StartInfo.UseShellExecute = false;
                    NewProcess.StartInfo.RedirectStandardOutput = true;
                    NewProcess.StartInfo.RedirectStandardError = true;

                    if (Argumentos != string.Empty)
                    {
                        NewProcess.StartInfo.Arguments = Argumentos;
                    }
                    NewProcess.Start();

                    NewProcess.WaitForExit();

                    respuesta = NewProcess.StandardOutput.ReadToEnd().Replace("\r\n", "");
                }
                else
                {
                    MessageBox.Show("Este usuario ya ha sido validado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                return respuesta;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutarPluginsVideoLlamada, plugin:" + pluginName, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutarPluginsVideoLlamada, class: CDetalleVenta.cs");
                return "NO";
            }
        }

        public bool validarGeneracionVideollamada(int idVenta)
        {
            bool respuesta = true;
            using (SqlCommand comando = new SqlCommand("SpCREDIInformacionVideoLlamada", ClaseEstatica.ConexionEstatica))
            {
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@Id", idVenta);
                using (SqlDataReader dr = comando.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read()) respuesta = Boolean.Parse(dr["TelefonoVal"].ToString());
                    }
                }
            }
            return respuesta;
        }

        #endregion

        /// <summary>
        /// Calcula importe de un movimiento
        /// </summary>
        /// <param name="Detalles">List<string></param>
        /// <returns>double</returns>
        /// Developer: Dan Palacios
        /// Date: 20/09/17
        public double CalculaImporte(List<string> Detalles)
        {
            double ImporteTotal = 0;

            double Importe = 0;
            if (Detalles[(int)Enums.DetallesVenta.Importe] != string.Empty)
            {
                Importe = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.Importe]);
            }
            double Impuesto = 0;
            if (Detalles[(int)Enums.DetallesVenta.Impuestos] != string.Empty)
            {
                Impuesto = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.Impuestos]);
            }
            double DescGlobal = 0;
            if (Detalles[(int)Enums.DetallesVenta.DescGlobal] != string.Empty)
            {
                DescGlobal = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.DescGlobal]);
            }
            double SobrePrecio = 0;
            if (Detalles[(int)Enums.DetallesVenta.SobrePrecio] != string.Empty)
            {
                SobrePrecio = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.SobrePrecio]);
            }

            double AnticiposFacturados = 0;
            if (Detalles[(int)Enums.DetallesVenta.AnticiposFacturados] != string.Empty)
            {
                AnticiposFacturados = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.AnticiposFacturados]);
            }

            double Retencion = 0;
            if (Detalles[(int)Enums.DetallesVenta.Retencion] != string.Empty)
            {
                Retencion = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.Retencion]);
            }

            ImporteTotal = Importe + Impuesto - DescGlobal + SobrePrecio - AnticiposFacturados + Retencion;

            return ImporteTotal;
        }

        public void SMSCompras(int id, string cuenta, int nuevo)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("SpCREDISMSCompras ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@IdMov  ", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Cliente  ", SqlDbType.VarChar).Value = cuenta;
                cmd.Parameters.Add("@CteNuevo  ", SqlDbType.Int).Value = nuevo;
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMSCompras", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Deshabilita controles en una forma
        /// </summary>
        /// <param name="estado">bool</param>
        /// <param name="forma">Form</param>
        /// Developer: Dan Palacios
        /// Date: 27/09/17
        public void DesabilitarControles(bool estado, Form forma)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in forma.Controls)
                {
                    if (!item.Enabled)
                    {
                        ListaControles.Add(item.Name);

                    }
                    else
                        item.Enabled = estado;
                }
            }
            else
            {
                foreach (Control item in forma.Controls)
                {
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
                }
            }
            forma.AutoScroll = estado;
        }

        /// <summary>
        /// Obtiene el nuevo MovID creado
        /// </summary>
        /// <param name="IDVenta">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private string SelectMovIDActualizado(string IDVenta)
        {
            string MovID = "";
            string[] Parametros = new string[]
            {
                "@ID"
            };

            string[] Variables = new string[]
            {
                IDVenta
            };

            string comando = "SELECT MovID FROM Venta WITH(NOLOCK) WHERE ID = @ID";

            MovID = EjecutaComandosSQL(comando, Parametros, Variables, "");

            return MovID;

        }

        #region Series

        /// <summary>
        /// Elimina las series cuando se cambia de almacen
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 04/10/17
        public void EliminaSeries()
        {
            SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaSerieArticulos", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure
            };
            sqlCommand.Parameters.AddWithValue("@IDVenta", DM0312_DetalleCambiarAlmacen.IDVenta);
            sqlCommand.Parameters.AddWithValue("@BorrarSerie", true);
            try
            {
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminaSeries", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function EliminaSeries, class: CDetalleVenta");
            }
        }

        /// <summary>
        /// Login para serie que son motos
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        public bool LoginSerieMotos()
        {
            bool AbrirLogin = false;
            EsMoto = false;

            SqlCommand sqlCommand = new SqlCommand("select ID  from ArtLinea al with(nolock) INNER JOIN Art a with(nolock) ON a.Linea = al.Linea where id in ('625', '626', '627', '628', '629', '630') AND a.Articulo = @Articulo", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };

            sqlCommand.Parameters.AddWithValue("@Articulo", DM0312_DetalleSerieArticulo.ArticuloSeleccionado);
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (ClaseEstatica.Usuario.usuario.Substring(0, 5) == "VENTP")
                    {
                        AbrirLogin = true;
                    }
                    EsMoto = dr.HasRows;
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LoginSerieMotos", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function: LoginSerieMotos, clase: CDetalleVenta.cs");
            }

            return AbrirLogin;
        }

        #endregion

        #region Embarques

        /// <summary>
        /// Embarcar facturas
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 13/10/17
        public bool Embarcar(string[] Parametros)
        {
            bool Embarcado = false;

            string[] parametros = new string[]
            { "@Empresa", "@Modulo", "@ID", "@Mov", "@MovID", "@Estatus", "@DesEmbarcar" };
            string[] parametrosAPasar = new string[]
            {
                "MAVI",
                "VTAS",
                Parametros[(int)Enums.Embarques.ID],
                Parametros[(int)Enums.Embarques.Mov],
                Parametros[(int)Enums.Embarques.MovID],
                Parametros[(int)Enums.Embarques.Estatus],
                "0"
            };

            List<string> spEmbarqueManual = EjecutaSQLDataReader("spEmbarqueManual", parametros, parametrosAPasar, null, true);
            if (spEmbarqueManual.Count > 1 && spEmbarqueManual[1] != "")
            {
                MessageBox.Show(spEmbarqueManual[1]);
            }
            else
            {
                MessageBox.Show("Movimiento: " + Parametros[(int)Enums.Embarques.Mov] + " " + Parametros[(int)Enums.Embarques.MovID] + " embarcado con exito", "Embarque", MessageBoxButtons.OK, MessageBoxIcon.Information); ;
            }

            return Embarcado;
        }

        /// <summary>
        /// Checa si el mov esta embarcado
        /// </summary>
        /// <param name="MovID">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan palacios
        /// Date: 13/10/17
        public bool MovEmbarcado(string MovID)
        {
            bool MovEmbarcado = false;
            SqlCommand sqlCommand = new SqlCommand("SELECT Count(ID) EmbarqueExiste FROM EmbarqueMov WITH(NOLOCK) where MovID = @MovID AND Modulo = 'VTAS' AND MovEstatus <> 'CANCELADO'", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.Parameters.AddWithValue("@MovID", MovID);

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr["EmbarqueExiste"] != null && dr["EmbarqueExiste"].ToString() != string.Empty && Convert.ToInt32(dr["EmbarqueExiste"]) != 0)
                        {
                            MovEmbarcado = true;
                        }
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MovEmbarcado", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function MovEmbarcado clase: CDetalleVenta");
            }
            return MovEmbarcado;
        }

        #endregion

        #region NIP y vales

        /// <summary>
        /// Muestra vales nip
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 17/10/17
        public bool ShowNipVales(string[] Parametros, int valedigital)
        {
            bool ShowVales = false;

            string CadenaSQL = "Select dbo.fnClientesNuevosCasaMAVI('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string CadenaALeer = string.Empty;
            string fnClientesNuevosCasaMAVI = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            CadenaSQL = "SHM_Valida_Analisis";
            string[] parametros = { "@ID" };
            string[] parametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] };
            string valido = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);

            CadenaSQL = "Select count(*) CountVentaD From VentaD with(nolock) Where Articulo like '%VALR%' And ID = @ID";
            string CountVentaD = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            CadenaSQL = "Select dbo.fn_MaviDM0244ValeAsignado('" + Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta] + "')";
            string fn_MaviDM0244ValeAsignado = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            if
            (
                fnClientesNuevosCasaMAVI == "Nuevo" &&
                valido == "0" &&
                CountVentaD == "0" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE" &&
                Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
            )
            {
                CadenaSQL = "select count(*) CountMovBitacora from MovBitacora with(nolock) where ID = @ID and Clave in (select Evento from SHM_ValorDeEventosValera with(nolock))";
                string CountMovBitacora = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                //Validacion linea 17
                if (CountMovBitacora != "0")
                {
                    CadenaSQL = "select count(*) CountFolios from DM0244_FOLIOS_VALES With(NoLock) where IDSOLVTAVAL = @ID";
                    string CountFolios = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

                    //Validacion linea 23
                    if (CountFolios == "0" && fn_MaviDM0244ValeAsignado == "0")
                    {
                        ShowVales = true;
                        return ShowVales;
                    }
                }
            }

            CadenaSQL = "select COUNT(*) from DM0244_FOLIOS_VALES With(NoLock) where CUENTA = '" + Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] + "' AND ESTATUS = 1";
            string cadenaDM0244_FOLIOS_VALES = EjecutaComandosSQL(CadenaSQL, null, null, CadenaALeer);

            if (
                    (
                        fnClientesNuevosCasaMAVI == "Casa" ||
                        (cadenaDM0244_FOLIOS_VALES != string.Empty && Convert.ToInt32(cadenaDM0244_FOLIOS_VALES) > 0)
                    )
                &&
                    CountVentaD == "0"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Solicitud Credito"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
              )
            {
                //validacion 329
                if (fn_MaviDM0244ValeAsignado == "0")
                {
                    ShowVales = true;
                    return ShowVales;
                }
            }

            CadenaSQL = "Select count(*) From VentaD with(nolock) where ID = @ID and Articulo like '%VALR%'";
            parametros = new string[] { "@ID" };
            parametrosAPasar = new string[]
            {
                Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]
            };
            string CountArt = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            //validaciones linea 424
            if (
                    (
                        fnClientesNuevosCasaMAVI == "Nuevo" ||
                        cadenaDM0244_FOLIOS_VALES == "0"
                    )
                &&
                    CountArt == "0"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Mov] == "Analisis Credito"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.Estatus] == "PENDIENTE"
                &&
                    Parametros[(int)Enums.ParametrosDetallesVenta.EnviarA] == "76"
               )
            {

                if (fn_MaviDM0244ValeAsignado == "0")
                {
                    ShowVales = true;
                    return ShowVales;
                }
            }

            if (valedigital == 1)
            {
                ShowVales = true;
                return ShowVales;
            }


            return ShowVales;
        }

        /// <summary>
        /// Validar NIP y vale
        /// </summary>
        /// <param name="msgPrecaucion">ref string</param>
        /// <param name="Parametros">string[]</param>
        /// <param name="Vale">string</param>
        /// <param name="NIP">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 17/10/17
        public bool ValidarNipVale(ref string msgPrecaucion, string[] Parametros, string Vale, string NIP, int valeDigital)
        {
            bool NipValeValido = false;

            //-ValeDigital
            if (valeDigital == 0)
            {
                DM0312_C_EscanearValeDigital controladorValeDigital = new DM0312_C_EscanearValeDigital();
                if (controladorValeDigital.checarSiValeDigital(Vale))
                {
                    msgPrecaucion = "El folio del vale ingresado corresponde a un vale digial. Por favor, capturar en el módulo correspondiente.";
                    return NipValeValido;

                }
            }


            string CadenaSQL = "Select NIP_VENTA From DM0244_CLAVES WITH(NOLOCK) Where Cuenta = @Cliente";
            string CadenaALeer = string.Empty;
            string[] parametros = { "@Cliente" };
            string[] parametrosAPasar = { Parametros[(int)Enums.ParametrosDetallesVenta.Cliente] };
            string NIP_VENTA = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer);

            if (NIP_VENTA != "")
            {
                NIP = (valeDigital == 1) ? NIP : MD5Hash(NIP);
                if (NIP == NIP_VENTA)
                {
                    CadenaSQL = "SP_DM0244ValidaVales";
                    CadenaALeer = string.Empty;
                    parametros = new string[] { "@cliente", "@Vale" };
                    parametrosAPasar = new string[]
                    {
                        Parametros[(int)Enums.ParametrosDetallesVenta.Cliente],
                        Vale
                    };
                    string EstatusValido = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);

                    if (EstatusValido == "1")
                    {
                        CadenaSQL = "SP_DM0244ValeRelacionId";
                        CadenaALeer = string.Empty;
                        parametros = new string[] { "@id", "@Vale" };
                        parametrosAPasar = new string[]
                        {
                            Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta],
                            Vale
                        };
                        EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, CadenaALeer, true);
                        NipValeValido = true;
                    }
                    else
                    {
                        msgPrecaucion = "Vale no valido";
                    }
                }
                else
                {
                    msgPrecaucion = "NIP no valido";
                }
            }
            else
            {
                msgPrecaucion = "NIP inexistente";
            }


            return NipValeValido;
        }

        /// <summary>
        /// Hash para MD5
        /// </summary>
        /// <param name="text">string</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        public static string MD5Hash(string text)
        {
            StringBuilder strBuilder = new StringBuilder();

            try
            {
                MD5 md5 = new MD5CryptoServiceProvider();

                //compute hash from the bytes of text
                md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

                //get hash result after compute it
                byte[] result = md5.Hash;

                for (int i = 0; i < result.Length; i++)
                {
                    //change it into 2 hexadecimal digits
                    //for each byte
                    strBuilder.Append(result[i].ToString("x2"));
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MD5Hash", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function MD5Hash, class: CDetalleVenta.cs");
            }

            return strBuilder.ToString();
        }

        #endregion

        #region Anticipos

        /// <summary>
        /// inserta anticipos en CXC
        /// </summary>
        /// <param name="ValorParametros">string[]</param>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 02/11/17
        public string InsertAnticipos(string[] ValorParametros, out int NuevoID)
        {
            NuevoID = 0;
            string[] parametros = new string[]
            {
                "@Mov", "@Usuario", "@Referencia", "@Cliente", "@EnviarA", "@CtaDinero", "@Importe", "@Impuestos",
                "@MetodoPago1", "@MetodoPago2", "@MetodoPago3", "@MetodoPago4", "@MetodoPago5",
                "@Referencia1", "@Referencia2", "@Referencia3", "@Referencia4", "@Referencia5",
                "@Importe1", "@Importe2", "@Importe3", "@Importe4", "@Importe5", "@Agente", "@Sucursal",
                "@SucursalOrigen", "@Cajero", "@UEN", "@Estacion"
            };

            SqlCommand command = new SqlCommand("SP_MaviDM0312InsertAnticipos", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure,
                CommandTimeout = 600
            };
            if (parametros != null)
            {
                for (int i = 0; i < parametros.Length; i++)
                {
                    if (ValorParametros[i] != string.Empty)
                    {
                        command.Parameters.AddWithValue(parametros[i], ValorParametros[i]);
                    }
                    else
                    {
                        command.Parameters.AddWithValue(parametros[i], DBNull.Value);
                    }
                }
            }
            DM0312_MExploradorVenta model = new DM0312_MExploradorVenta();
            string respuesta = "";
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr.FieldCount > 2)
                        {
                            if (dr[2].ToString() == "ERROR")
                            {
                                respuesta = dr[1].ToString();
                                return respuesta;
                            }
                        }
                        else
                        {
                            respuesta = dr[0].ToString();
                        }
                    }
                    if (dr.NextResult())
                    {
                        while (dr.Read())
                        {
                            NuevoID = Convert.ToInt32(dr["ID"]);
                        }
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertAnticipos", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function InsertAnticipos, class: CDetalleVenta.cs");
            }

            return respuesta;
        }

        /// <summary>
        /// Imprime anticipos
        /// </summary>
        /// <param name="AnticipoID">int</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        public void ImprimirAnticipos(int AnticipoID)
        {
            DialogResult dialogResult = MessageBox.Show("Imprimir anticipos", "Impresion", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {


                    string ArgumentosPlugin = "CXC "
                                        + AnticipoID.ToString() + " "
                                        + ClaseEstatica.Usuario.usuario + " 1 "
                                        + ClaseEstatica.Usuario.sucursal + " "
                                        + ClaseEstatica.WorkStation;
                    EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");

                    //Process NewProcess = new Process();
                    //NewProcess.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["plugInsCubos"].ToString();
                    //NewProcess.StartInfo.FileName = ConfigurationManager.AppSettings["plugInsCubos"].ToString() + @"Cobro.exe";
                    //NewProcess.StartInfo.Verb = "runas";
                    //NewProcess.StartInfo.Arguments = AnticipoID.ToString() + " " + ClaseEstatica.Usuario.usuario + " 1";
                    //NewProcess.StartInfo.UseShellExecute = false;
                    //NewProcess.Start();
                    //NewProcess.WaitForExit();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ImprimirAnticipos", "CDetalleVenta.cs", ex);
                    MessageBox.Show(ex.Message + " function ImprimirAnticipos, class: CDetalleVenta.cs");
                }
            }
        }

        #endregion

        /// <summary>
        /// Checa si un movimiento tiene articulos de valera
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 24/11/17
        public bool MovEsValera(int IDVenta)
        {
            string CadenaSQL = "SpEDM0312_IdentificarValeras";
            string[] parametros = new string[] { "@IDVenta" };
            string[] parametrosAPasar = new string[] { IDVenta.ToString() };
            string RetornaValera = EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, null, true);
            if (RetornaValera == "0")
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Actualiza Costo o precio dependiendo de que se actualizo
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <param name="PrecioCostoArticulo">double</param>
        /// <param name="PrecioCostoTotal">double</param>
        /// <param name="Articulo">string</param>
        /// <param name="EsCosto">bool</param>
        /// <param name="Importe">double?</param>
        /// <param name="Impuestos">double?</param>
        /// Developer: Dan Palacios
        /// Date: 27/11/17
        public void ActualizaCostoPrecio(int IDVenta, double PrecioCostoArticulo, double PrecioCostoTotal, string Articulo, bool EsCosto = false, double? Importe = null, double? Impuestos = null)
        {
            string CadenaSQL = "SP_MaviDM0312PuntoVentaDetalles";
            string CadenaEsCosto = "@ActualizarPrecio";
            string[] parametros = null;
            string[] parametrosAPasar = null;
            if (EsCosto)
            {
                CadenaEsCosto = "@ActualizarCosto";
                parametros = new string[] { "@IDVenta", "@NuevoPrecioCosto", "@CostoPrecioTotal", "@Articulo", CadenaEsCosto };
                parametrosAPasar = new string[]
                {
                    IDVenta.ToString(),
                    PrecioCostoArticulo.ToString("0.0000"),
                    PrecioCostoTotal.ToString("0.0000"),
                    Articulo,
                    "True"
                };
            }
            else
            {
                parametrosAPasar = new string[]
                {
                    IDVenta.ToString(),
                    PrecioCostoArticulo.ToString("0.0000"),
                    PrecioCostoTotal.ToString("0.0000"),
                    Articulo,
                    "True",
                    (Importe != null ? Convert.ToDouble(Importe).ToString("0.0000") : ""),
                    (Impuestos != null ? Convert.ToDouble(Impuestos).ToString("0.0000") : "")
                };
                parametros = new string[] { "@IDVenta", "@NuevoPrecioCosto", "@CostoPrecioTotal", "@Articulo", CadenaEsCosto, "@Importe", "@Impuestos" };
            }
            EjecutaComandosSQLWithReturn(CadenaSQL, parametros, parametrosAPasar, null, null, true);
        }

        /// <summary>
        /// Checar si viene aceptado y remover de la lista (solo si el mov contiene articulos de valr)
        /// </summary>
        /// <param name="ListaSituaciones">List<MSituaciones></param>
        /// <returns>List<MSituaciones></returns>
        /// Developer: Dan Palacios
        /// Date: 28/11/17
        public List<MSituaciones> SituacionAceptadoValera(List<MSituaciones> ListaSituaciones)
        {
            //Checar si viene aceptado y remover de la lista (solo si el mov contiene articulos de valr)
            MSituaciones MSituacion = ListaSituaciones.FirstOrDefault(x => x.Situacion == "Aceptado");
            if (MSituacion != null)
            {
                ListaSituaciones.Remove(MSituacion);
            }
            return ListaSituaciones;
        }

        /// <summary>
        /// Si la situacion es aceptado condicionado el mov ha sido finalizado y tiene articulos en valera
        /// </summary>
        /// <param name="SituacionActual">string</param>
        /// <param name="MovActual">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 28/11/17
        public bool SituacionesValera(string SituacionActual, string MovActual)
        {
            if ((SituacionActual == "Rechazado" || SituacionActual == "Condicionado" || SituacionActual == "Inicia Proceso" || SituacionActual == "Aceptado Condicionado") && MovActual == "Analisis Credito")
            {
                return false;
            }

            return true;
        }

        public string origenID(string mov, string movid)
        {
            string origenid = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;

            query = ("select origenid from venta WITH (NOLOCK) where mov='" + mov + "' and movid='" + movid + "'");


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        origenid = dr[0].ToString();
                    }
                }
                else
                {
                    origenid = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("origenID", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return origenid;
        }

        /// <summary>
        /// Ejecuta plugin de SHM
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// <param name="MovEsValera">bool</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        public void EjecutaSHM(List<DM0312_MExploradorVenta> VentasSeleccionadas, bool MovEsValera)
        {
            if ((VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" || VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito")
                && VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
            {
                string CadenaSQL = "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum='SUCURSALES RDP' AND CAST(Numero AS INT)= @Suc";
                string[] parametros = { "@Suc" };
                string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
                string countSucursalesRDP = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, "");

                CadenaSQL = "Select Cadena From VentasCanalMAVI WITH(NOLOCK) Where ID = @EnviarA";
                parametros = new string[] { "@EnviarA" };
                parametrosAPasar = new string[] { VentasSeleccionadas[PaginadoActual].EnviarA };
                string VentasCanalMavi = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, "");

                string ArgumentosPlugin = string.Empty;

                int numS = SucursalRDP(ClaseEstatica.Usuario.sucursal);

                if (numS == 1)
                {
                    bool bVentaVale = false;
                    if (VentasCanalMavi == "VENTA VALE" || VentasCanalMavi == "CREDITAZZO" || (new string[] { "76", "80" }).Contains(VentasSeleccionadas[PaginadoActual].EnviarA))
                    {
                        bVentaVale = true;
                    }
                    string SHMParametro = "SHM ";
                    if (!bVentaVale || MovEsValera)
                    {
                        SHMParametro = "SHM ";
                    }
                    else
                    {
                        SHMParametro = "SHM3 ";
                    }
                    if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito")
                    {
                        string movid;
                        movid = origenID(VentasSeleccionadas[PaginadoActual].Mov, VentasSeleccionadas[PaginadoActual].MovId);

                        ArgumentosPlugin = SHMParametro +
                               movid + " " +
                               ClaseEstatica.Usuario.usuario + " " +
                               VentasSeleccionadas[PaginadoActual].Cliente + " " +
                                VentasSeleccionadas[PaginadoActual].Suc + " " +
                               ClaseEstatica.WorkStation;
                    }
                    else
                    {
                        ArgumentosPlugin = SHMParametro +
                              VentasSeleccionadas[PaginadoActual].MovId + " " +
                              ClaseEstatica.Usuario.usuario + " " +
                              VentasSeleccionadas[PaginadoActual].Cliente + " " +
                               VentasSeleccionadas[PaginadoActual].Suc + " " +
                              ClaseEstatica.WorkStation;
                        //+ " " + "Solicitud Credito"
                    }

                }
                else
                {
                    if (VentasCanalMavi != "VENTA VALE" || MovEsValera)
                    {
                        if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito")
                        {
                            string movid;
                            movid = origenID(VentasSeleccionadas[PaginadoActual].Mov, VentasSeleccionadas[PaginadoActual].MovId);

                            ArgumentosPlugin = ClaseEstatica.Usuario.usuario + " " + VentasSeleccionadas[PaginadoActual].Suc
                        + " " + movid + " " +
                        VentasSeleccionadas[PaginadoActual].Cliente;
                            //+ " " + "Analisis Credito"
                        }
                        else
                        {
                            ArgumentosPlugin = ClaseEstatica.Usuario.usuario + " " + VentasSeleccionadas[PaginadoActual].Suc
                         + " " + VentasSeleccionadas[PaginadoActual].MovId + " " +
                         VentasSeleccionadas[PaginadoActual].Cliente;
                            //+ " " + "Solicitud Credito"
                        }

                    }
                    else
                    {
                        if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito")
                        {
                            string movid;
                            movid = origenID(VentasSeleccionadas[PaginadoActual].Mov, VentasSeleccionadas[PaginadoActual].MovId);

                            ArgumentosPlugin = "CLIENTEFINAL " + ClaseEstatica.Usuario.usuario
                               + " " + movid + " " +
                               VentasSeleccionadas[PaginadoActual].Suc;
                            //+ " " + "Analisis Credito"
                        }
                        else
                        {
                            ArgumentosPlugin = "CLIENTEFINAL " + ClaseEstatica.Usuario.usuario
                                + " " + VentasSeleccionadas[PaginadoActual].MovId + " " +
                                VentasSeleccionadas[PaginadoActual].Suc;
                            //+ " " + "Solicitud Credito"
                        }
                    }
                }
                if (numS == 1)
                {
                    EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");

                }
                else
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"].ToString() + @"SHM.exe"))
                    {
                        EjecutarPlugins(ArgumentosPlugin, "SHM.exe", ConfigurationManager.AppSettings["CarpetaSHM"].ToString());
                    }
                }

            }
            else
            {
                MessageBox.Show("No se puede ejecutar el plugin con estas condiciones");
            }
        }

        //-DIE
        #region -DIE
        public bool VerificarDie(int iId)
        {
            bool res = false;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("SELECT CONVERT(BIT, COUNT(*)) AS EsDie FROM ventad v WITH(NOLOCK) " +
                     "INNER JOIN art ar WITH(NOLOCK) " +
                     "ON v.Articulo = ar.Articulo WHERE " +
                     "v.id = {0} " +
                     "AND ar.Linea = 'CREDILANA'", iId);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        res = dr.GetBoolean(0);
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VerificarDie", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: ObtenerDetallesVenta class: CDetalleVenta.cs", "Error!");
            }

            finally { if (dr != null) dr.Close(); }


            return res;

        }


        public string validaEsDie(int id)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT dbo.FnVTASValSucursalodie ('{0}')", id);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text; //-DIE
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        puede = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaEsDie", "CDetalleventa", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
            return puede;
        }


        public string VTASsucoDie(int id)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASsucoDie ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID  ", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@UsrAfecta  ", SqlDbType.Char).Value = ClaseEstatica.Usuario.Usser;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        puede = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VTASsucoDie", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return puede;
        }


        public string validaCancelaDIE(int id)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT dbo.FnVTASCancelaDie ('{0}')", id);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        puede = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaCancelaDIE", "CDetalleventa", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return puede;
        }

        public bool obtenerEstatusDie(int iId)
        {
            bool res = false;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("SELECT CONVERT(BIT,pagodie) AS pagodie FROM VENTA WITH(NOLOCK) WHERE ID = {0}", iId);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        res = dr.GetBoolean(0);
                    }
                }

            }
            catch (Exception ex)
            {

                DM0312_ErrorLog.RegistraError("obtenerEstatusDie", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: obtenerEstatusDie class: CDetalleVenta.cs", "Error!");
            }

            finally { if (dr != null) dr.Close(); }


            return res;

        }
        #endregion



        /// <summary>
        /// Checa si la sucursal es de SHM
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        public bool SucursalSHM()
        {
            string CadenaSQL = "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK)WHERE TablaNum='SUCURSALES RDP' AND Numero=@Suc";
            string[] parametros = { "@Suc" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            string SucursalSHM = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, "");
            if (SucursalSHM != "0")
            {
                return true;
            }

            return false;
        }


        public string EstatusActual(int id)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("select estatus from venta WITH (NOLOCK) where id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = dr[0].ToString();
                    }
                }
                else
                {
                    estatus = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EstatusActual", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }

        public void InsertCantidadAAfectar(int IDVenta, List<ArticulosDetalleVenta> DatosDetalles)
        {
            DataTable dt = new DataTable("VentaD");
            DataColumn dc = new DataColumn("ID");
            dt.Columns.Add(dc);
            dc = new DataColumn("CantidadA");
            dt.Columns.Add(dc);
            dc = new DataColumn("Renglon");
            dt.Columns.Add(dc);

            foreach (ArticulosDetalleVenta articulos in DatosDetalles)
            {
                DataRow newRow = dt.NewRow();
                newRow["ID"] = IDVenta;
                newRow["CantidadA"] = articulos.CantidadAAfectar;
                if (articulos.RenglonID != 0)
                {
                    newRow["Renglon"] = articulos.RenglonID;
                }
                else
                {
                    newRow["Renglon"] = DBNull.Value;
                }
                dt.Rows.Add(newRow);
            }

            try
            {
                SqlCommand sqlcomm = new SqlCommand("CREATE TABLE #TmpTable(ID INT NOT NULL, CantidadA INT NOT NULL, RenglonID INT NOT NULL)", ClaseEstatica.ConexionEstatica);
                sqlcomm.ExecuteNonQuery();
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                {
                    try
                    {
                        bulkCopy.DestinationTableName = "#TmpTable";
                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(dt);
                        bulkCopy.Close();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("BulkUpdateDataTable 1", "CDetalleVenta.cs", ex);
                        MessageBox.Show(ex.Message + " function: BulkUpdateDataTable 1. class:CDetalleVenta.cs");
                    }
                }
                sqlcomm.CommandText = "UPDATE T SET T.CantidadA = Temp.CantidadA " +
                    "FROM " + dt.TableName + " T INNER JOIN #TmpTable Temp ON t.ID = temp.ID AND t.RenglonID = temp.RenglonID; DROP TABLE #TmpTable;";
                sqlcomm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BulkUpdateDataTable 2", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function: BulkUpdateDataTable 2, class: CDetalleVenta.cs");
            }
        }

        /// <summary>
        /// Metodo para eliminar un movimiento
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 27/08/17
        public string EliminarMovimiento(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            string ErrorMsg = string.Empty;
            SqlCommand sqlCommand = new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.StoredProcedure
            };
            sqlCommand.Parameters.AddWithValue("@ID", VentasSeleccionadas[PaginadoActual].ID);
            sqlCommand.Parameters.AddWithValue("@Almacen", DBNull.Value);
            sqlCommand.Parameters.AddWithValue("@Articulo", DBNull.Value);
            sqlCommand.Parameters.AddWithValue("@EliminarMovimiento", true);
            try
            {
                sqlCommand.ExecuteNonQuery();
                ErrorMsg = "Registro eliminado satisfactoriamente";
            }
            catch (Exception ex)
            {
                if (ex.Message != "No Puede Eliminar un Consecutivo Asignado")
                {
                    DM0312_ErrorLog.RegistraError("EliminarMovimiento", "DM0312_DetalleVenta.cs", ex);
                    ErrorMsg = ex.Message + " Error function EliminarMovimiento, class: DM0312_DetalleVenta.cs";
                }
                else
                {
                    ErrorMsg = "Registro eliminado satisfactoriamente";
                }
            }

            return ErrorMsg;
        }

        public void UpdateComentarios(int id, string comentario)
        {
            SqlDataReader dr = null;
            string query = string.Empty;


            query = string.Format("	UPDATE venta WITH (ROWLOCK) SET Comentarios='" + comentario + "'  WHERE id = '" + id + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("UpdateComentarios", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public string ObtenerNomina(string cliente)
        {
            string CadenaSQL = "select Empleado from TcA_RelacionCteFinalEmpleado Where Cliente = @Cliente";
            string[] parametros = { "@Cliente" };
            string[] valorParametros = { cliente };
            return EjecutaComandosSQL(CadenaSQL, parametros, valorParametros, "");
        }

        public string FormaCobroLUpdate(int id, string forma)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("update VENTA WITH (ROWLOCK) set formacobro='" + forma + "' where id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                //sqlCommand.CommandTimeout = 9999999;
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FormaCobroLUpdate", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }

        /// <summary>
        /// Valida la informacion del cliente y separa el correo por cuenta y dominio
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer: Erika Perez
        /// Date: 17/09/17
        public void EstatusMonedero(int id, string estatus)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASActualizaEstatusTarjeta ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID ", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@EstatusMovimiento  ", SqlDbType.VarChar).Value = estatus;
                //cmd.CommandTimeout = 9999999;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EstatusMonedero", "DM0312_CPuntoDeVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }


        public string FormaCobroL(int id)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT FormaCobro FROM VENTA WITH(NOLOCK) where id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = dr[0].ToString();
                    }
                }
                else
                {
                    estatus = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FormaCobroL", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }


        public string SMStablaConversion(int canal)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 nombre FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='NotificacionSMScanales' and nombre='" + canal + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = dr[0].ToString();
                    }
                }
                else
                {
                    estatus = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversion", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }


        public string SMStablaConversionSeguros()
        {
            string importe = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 nombre FROM TablaStD WITH(NOLOCK) WHERE TablaSt ='IMPORTE SEGURO VIDA' ");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        importe = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionSeguros", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return importe;
        }


        public string SMStablaConversionValor(int canal)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 valor FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='NotificacionSMScanales' and nombre='" + canal + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionValor", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }

        public string SMStablaConversionSegurosValor()
        {
            string importe = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 valor FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='IMPORTE SEGURO VIDA' ");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        importe = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionSegurosValor", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return importe;
        }



        public string SMStablaCandadoRedimirValor()
        {
            string importe = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 valor FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='CandadoMonederoVirtual' ");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        importe = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionSegurosValor", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return importe;
        }

        public string ArticuloCredilana(int id)
        {
            string art = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 articulo FROM ventad WITH(NOLOCK) WHERE id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        art = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ArticuloCredilana", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return art;
        }

        public double CapitalCredilana(string art)
        {
            double capital = 0;
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 capital FROM art WITH(NOLOCK) WHERE articulo='" + art + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        capital = double.Parse(dr[0].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CapitalCredilana", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return capital;
        }


        public string AutorizaCancelacion(string mov, string cliente)
        {
            string estatus = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 cliente FROM DM0287AutorizaCancelacion  WITH(NOLOCK) WHERE  solicitud='" + mov + "' and cliente='" + cliente + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        estatus = "SI";
                    }
                }
                else
                {
                    estatus = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMStablaConversionValor", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return estatus;
        }


        public bool ConsultarVentaCredilana(string Id)
        {
            string CadenaSQL = "select top 1 linea from art where articulo = (select top 1 Articulo from ventad where id = '" + Id + "')";
            string[] parametros = { "" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            string VentaCredilana = EjecutaSQLSHM4(CadenaSQL);
            if (VentaCredilana == "CREDILANA" || VentaCredilana == "credilana")
            {
                return true;
            }

            return false;
        }

        public bool SegundaVentaSHM(string Cliente)
        {
            string CadenaSQL = "select top 10 Mov from VENTA where cliente = '" + Cliente + "' AND ESTATUS='CONCLUIDO' and mov in ('credilana', 'prestamo personal') ";
            string[] parametros = { "" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            List<string> SegundaVenta = EjecutaSQLSHM2(CadenaSQL);
            if (SegundaVenta.Count >= 1)
            {
                return true;
            }

            return false;
        }

        public bool SeguroVidaSHM(string Cliente)
        {
            string CadenaSQL = "select top 10 Articulo from V_MaviVentasNetas where cliente = '" + Cliente + "' and familia = 'SEGUROS DE VIDA'";
            string[] parametros = { "" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            List<string> SeguroVida = EjecutaSQLSHM2(CadenaSQL);
            if (SeguroVida.Count >= 1)
            {
                return true;
            }

            return false;
        }

        public bool VentaCampo(string Cliente, string movid)
        {
            string CadenaSQL = "SELECT Cambaceo FROM MAVIANDROID01.SID.DBO.SHM_BURO_CTED WHERE cuenta = '" + Cliente + "' and cambaceo = '1' and analisis='" + movid + "'";
            string[] parametros = { "" };
            string[] parametrosAPasar = { ClaseEstatica.Usuario.sucursal.ToString() };
            List<string> VentaCampo = EjecutaSQLSHM3(CadenaSQL);
            if (VentaCampo.Count >= 1)
            {
                return true;
            }

            return false;
        }


        public List<string> EjecutaSQLSHM2(string Comando)
        {
            List<string> DataReader = new List<string>();
            SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 600
            };

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataReader.Add(dr[0].ToString());
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaDataReader comando/sp:" + Comando, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutaDataReader, class: CDetalleVenta");
            }

            return DataReader;
        }

        public List<string> EjecutaSQLSHM3(string Comando)
        {
            List<string> DataReader = new List<string>();
            SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 600
            };

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataReader.Add(dr[0].ToString());
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaDataReader comando/sp:" + Comando, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutaDataReader, class: CDetalleVenta");
            }

            return DataReader;
        }

        public string EjecutaSQLSHM4(string Comando)
        {
            string StringADevolver = "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(Comando, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text,
                    CommandTimeout = 600
                };
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        StringADevolver = dr[0].ToString();
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaComandosSQL comando/sp: " + Comando, "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function EjecutaComandosSQL comando/sp: " + Comando + ", class: CDetalleVenta.cs");
            }

            return StringADevolver;
        }


        /// <summary>
        /// Detectar las sucursales que no aplican para seguro de vida 
        /// </summary>
        /// <returns></returns>
        public string SucursalesSinSeguro(int suc)
        {
            string val = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 valor FROM TablaStD ST WITH(NOLOCK) WHERE TablaSt ='SUCURSALES SIN CANDADO SEGURO' and  nombre ='" + suc + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        val = "SI";
                    }
                }
                else
                {
                    val = "NO";
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalesSinSeguro", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return val;
        }


        /// <summary>
        /// Afecta el movimiento seleccionado
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// Developer: Dan Palacios
        /// Date: 19/09/17
        public void LiberarLinea(string idEcommerce)
        {
            if (!string.IsNullOrEmpty(idEcommerce) && idEcommerce != "0")
            {
                string ArgumentosPlugin = "VTASPEDIDO " + idEcommerce + " "
                                     + "PROCESADO";
                EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe", ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
            }
            //EjecutarPlugins(ArgumentosPlugin, "ActualizaEcommers.exe");
        }


        public string ClienteFinal(int id)
        {
            string art = "";
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;
            query = ("SELECT top 1 ctefinal FROM venta WITH(NOLOCK) WHERE id='" + id + "'");
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        art = dr[0].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteFinal", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
            return art;
        }


        public void SMSBeneficiarioFinal(int id, string cuenta, string ClienteFinal)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("SpCREDISMSComprasVales ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@IdMov  ", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Cliente  ", SqlDbType.VarChar).Value = cuenta;
                cmd.Parameters.Add("@CteFinal   ", SqlDbType.VarChar).Value = ClienteFinal;
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SMSBeneficiarioFinal", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Elimina de tarjetamonederomavi si se elimina el registro en venta
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="nomina">string</param>
        /// <param name="opc">int</param>
        /// Developer: Erika Perez
        /// Date: 07/11/17
        public void DeleteTarjetaMonMavi(int id)
        {
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SPVTASEliminaMonederoPendiente ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DeleteTarjetaMonMavi", "DM0312_CPuntoDeVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /// <summary>
        /// Al cancelar un pedido y que este venga de sucursales en lineas agregar el motivo de cancelacion
        /// </summary>
        /// <param name="cliente">string</param>
        /// <param name="nomina">string</param>
        /// <param name="opc">int</param>
        /// Developer: Erika Perez
        /// Date: 23/11/18
        public void MotivoCancelacion(string obs, int id)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("	UPDATE venta WITH (ROWLOCK) SET  observaciones= '" + obs + "' WHERE id = '" + id + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MotivoCancelacion", "CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /// <summary>
        /// al cambiar de sucursal actualiza
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// Developer: Erika Perez
        /// Date: 22/11/18
        public void CambiarSuc(string Parametros)
        {
            string ArgumentosPlugin = "VTASPEDIDO  " + Parametros + " ENVIADO" + " " + "STN "
                                     + "sucursal";
            EjecutarPlugins(ArgumentosPlugin, "ActualizaEcommers.exe");
        }


        #region -TarjetaDepartamental

        /// <summary>
        /// Obtiene la categoria
        /// </summary>
        /// <param name="Clave">string</param>
        /// <returns>string[]</returns>
        /// Developer: Erika Perez
        /// Date: 30/08/17
        public string ObtenerCategoriaT(string Clave)
        {
            string cat = "";

            SqlCommand sqlCommand = new SqlCommand("SELECT top 1 Categoria FROM VentasCanalMAVI WITH (NOLOCK) WHERE id = @Clave", ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.Parameters.AddWithValue("@Clave", Clave);

            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        cat = dr[0].ToString();
                    }
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCategoriaT", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function ObtenerCategoriaCanal, class: CDetalleVenta.cs");
            }

            return cat;
        }

        #endregion


        #region -CandadoSegurosdeVida

        //-CambioCandadoSegurosdeVida 
        //-(2019-03-30)
        //-(2019-09-04)
        public double getCantidadSaldoPendiente(string Cliente)
        {
            double cantidad = 0;
            SqlDataReader dr = null;

            string query = string.Format(@"
            SELECT
                SUM(saldo) Total
              FROM (SELECT
                ISNULL(v.Saldo, 0) saldo
              FROM Venta v WITH(NOLOCK)
              INNER JOIN [IntelisisTmp].[dbo].[Venta] S WITH(NOLOCK) ON V.Origen = S.Mov AND V.OrigenID = S.MovID
              INNER JOIN [IntelisisTmp].[dbo].[VentaD] D WITH(NOLOCK) ON D.ID = S.ID  
              INNER JOIN [IntelisisTmp].[dbo].[Art] Ar WITH(NOLOCK) ON Ar.Articulo = D.Articulo
              INNER JOIN [IntelisisTmp].[dbo].[CteEnviarA] e WITH(NOLOCK) ON e.Cliente = v.Cliente AND e.ID = v.enviara
              LEFT JOIN [IntelisisTmp].[dbo].[CONDICION] C WITH (NOLOCK) ON C.condicion = v.condicion
              WHERE v.Estatus = 'Pendiente' 
              AND ( V.Situacion IN ('Aceptado', 'Aceptado Condicionado', 'Liberado', '') or V.Situacion is null)
              AND (V.Mov = 'Analisis Credito' OR V.Mov = 'Pedido')
              AND (D.Articulo LIKE '%DINE%' OR D.Articulo LIKE '%PEFE%' OR D.Articulo LIKE '%DINU%')
              AND e.ID IN (3, 7)
              AND s.Cliente = '{0}'
              AND v.MovID NOT IN (SELECT
                MovID
              FROM [IntelisisTmp].[dbo].Cxcpendiente c
              WHERE cliente = '{0}')
  
              union all

              select sum(saldo) from [IntelisisTmp].[dbo].[cxc] with(nolock) where estatus='PENDIENTE' and Mov='Documento' and cliente = '{0}' and Padremavi in ('Credilana','Prestamo personal') and ClienteEnviarA in (3, 7)
  
              ) y
            ", Cliente);
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr[0].ToString() != "")
                            {
                                cantidad = double.Parse(dr[0].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getCantidadSaldoPendiente", "DM0312_CDetalleVenta", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }

            }

            return cantidad;
        }


        //Cambio Candado Seguros de Vida (2019-03-30)
        public double getLimiteSaldoSeguroDeVida(int uen)
        {
            double cantidad = 0;
            SqlDataReader dr = null;

            string tipoCredito = (uen == 2) ? "Prestamo personal" : "Credilana";

            string query = string.Format("select top 1 valor from TablaSTD with(nolock) where tablaSt='LimiteSaldoParaSeguroDeVida' and nombre='{0}'", tipoCredito);
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr[0].ToString() != "")
                            {
                                cantidad = double.Parse(dr[0].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getLimiteSaldoSeguroDeVida", "DM0312_CDetalleVenta", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }

            }

            return cantidad;
        }



        public string getMovIDSolicitud(string idPedido)
        {
            string movIdOrigen = "";
            SqlDataReader dr = null;

            string query = string.Format(@"select top 1 A.OrigenID  From Venta P With(Nolock)
            Join Venta A With(Nolock) ON P.Origen = A.Mov and P.OrigenID = A.MovID
            Where P.ID= '{0}'", idPedido);
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            movIdOrigen = dr[0].ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getMovIDSolicitud", "DM0312_CDetalleVenta", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }

            }

            return movIdOrigen;
        }

        #endregion


        #region -ReporteDescuento

        public int getIdReporteDescuento(int idVenta)
        {

            string query;
            SqlDataReader dr = null;
            SqlCommand sqlCommand;
            int idReporteDescuento = 0;


            query = string.Format("Select ReporteDescuento from Venta with(nolock) where ID = '{0}'", idVenta);

            sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandTimeout = 600;

            try
            {
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr[0].ToString() != "")
                        {
                            idReporteDescuento = int.Parse(dr[0].ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getIdReporteDescuento", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return idReporteDescuento;
        }


        //ReporteDescuento
        public void removeReporteDescuento(int idVenta, int idReporteDescuento)
        {
            int idVentaOrigen = 0;
            string[] opciones = new string[3] { "Factura", "VentaDeProducto", "ActualizaVenta" };

            for (int i = 0; i < opciones.Count(); i++)
            {
                using (var sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    try
                    {
                        sqlCommand.Parameters.AddWithValue("@opcion", opciones[i].ToString());
                        if (opciones[i] == "Factura" || opciones[i] == "VentaDeProducto") { sqlCommand.Parameters.AddWithValue("@idReporteDescuento", idReporteDescuento); }
                        if (opciones[i] == "VentaDeProducto") { sqlCommand.Parameters.AddWithValue("@valorVenta", 0); }
                        if (opciones[i] == "ActualizaVenta") { sqlCommand.Parameters.AddWithValue("@idVenta", idVenta); }
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("removeReporteDescuento", "DM0312_CDetalleVenta", ex);
                        System.Windows.Forms.MessageBox.Show(ex.Message);
                    }
                }
            }

            //Se elimina el id del ReporteDescuento del Pedido
            //1. Se obtiene el id del pedido
            idVentaOrigen = getIdVentaOrigen(idVenta);

            //2. Si el valor de la variable es diferente a 0 se procede a borrar el id del reporte en el pedido
            if (idVentaOrigen != 0)
            {
                using (var sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@opcion", "ActualizaVenta");
                    sqlCommand.Parameters.AddWithValue("@idVenta", idVentaOrigen);
                    sqlCommand.ExecuteNonQuery();

                }
            }

        }

        //ReporteDescuento
        public void addReporteDescuento(int idVenta, int idReporteDescuento, string factura)
        {
            string[] opciones = new string[2] { "Factura", "VentaDeProducto" };

            for (int i = 0; i < opciones.Count(); i++)
            {
                using (var sqlCommand = new SqlCommand("SpVTASDReporteDescuento", ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    try
                    {
                        sqlCommand.Parameters.AddWithValue("@opcion", opciones[i].ToString());
                        if (opciones[i] == "Factura" || opciones[i] == "VentaDeProducto")
                        {
                            sqlCommand.Parameters.AddWithValue("@idReporteDescuento", idReporteDescuento);
                            sqlCommand.Parameters.AddWithValue("@factura", factura);
                        }
                        if (opciones[i] == "VentaDeProducto") { sqlCommand.Parameters.AddWithValue("@valorVenta", 1); }
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("addReporteDescuento", "DM0312_CDetalleVenta", ex);
                        System.Windows.Forms.MessageBox.Show(ex.Message);
                    }
                }
            }

        }


        //ReporteDescuento
        public int getIdVentaOrigen(int idVenta)
        {
            int idVentaOrigen = 0;
            SqlDataReader dr = null;

            string query = string.Format("select top 1 id from venta with(nolock) where Mov='Pedido' and MovID=(Select OrigenID from Venta where ID = '{0}')", idVenta.ToString());
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 600;

                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr[0].ToString() != "")
                            {
                                idVentaOrigen = int.Parse(dr[0].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("getIdVentaOrigen", "DM0312_CDetalleVenta", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }

            }


            return idVentaOrigen;
        }

        #endregion


        #region -CorreccionVale

        //-CorreccionVale
        public void afectarVale(int id, string vale, string bandera)
        {
            //Banderas segun SP: 'afectar', 'cancelar'

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand("SP_DM0244NipValesVta", ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@ID", id);
                    sqlCommand.Parameters.AddWithValue("@Vale", vale);
                    sqlCommand.Parameters.AddWithValue("@Bandera", bandera);
                    sqlCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("afectarVale", "CDetalleVenta.cs", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        #endregion

        //-ReporteDima
        #region -ReporteDima

        /// <summary>
        /// metodo encargado de validar si el cliente dima es el beneficiario final
        /// </summary>
        /// <param name="iIdVenta">id de la venta: Analisis Credito</param>
        /// <returns>retorna true si el cliente dima es el beneficiario final, de lo contrario false</returns>
        public bool validarClienteDimaFinal(int iIdVenta)
        {
            bool bDimaEsFinal = false;

            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format("select COUNT(*) AS Existe from Venta v WITH(NOLOCK) " +
                "INNER JOIN cte c WITH(NOLOCK) " +
                "ON v.Cliente = c.Cliente " +
                "INNER JOIN Cte_Final cf WITH(NOLOCK) " +
                "ON v.CteFinal = cf.ClienteF AND SUBSTRING(c.RFC,0,10) = SUBSTRING(cf.RFC,0,10) " +
                "where v.ID = {0}", iIdVenta);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (dr.Read())
                    {
                        if (int.Parse(dr["Existe"].ToString()) >= 1)
                        {
                            bDimaEsFinal = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarClienteDimaFinal", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return bDimaEsFinal;

        }

        /// <summary>
        /// Metodo encargado de obtener el codigo del vale en base al mov y movid de la venta
        /// </summary>
        /// <param name="sMov">movimiento de la venta</param>
        /// <param name="sMovId">id del movimiento de la venta</param>
        /// <returns></returns>
        public string obtenerCodigoBarra(string sMov, string sMovId)
        {
            string sCodigoBarra = string.Empty;
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format("SELECT " +
                "CODIGOBARRAS " +
                "FROM venta v1 WITH(NOLOCK) " +
                "JOIN venta v2 WITH(NOLOCK) " +
                "ON v2.movid = v1.origenid " +
                "JOIN DM0244_FOLIOS_VALES WITH(NOLOCK) " +
                "ON IDSOLVTAVAL = v2.id " +
                "WHERE v1.MOV = '{0}' " +
                "AND v1.movid = '{1}'", sMov, sMovId);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (dr.Read())
                    {
                        sCodigoBarra = dr["CODIGOBARRAS"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerCodigoBarra", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sCodigoBarra;
        }

        /// <summary>
        /// metodo encargado de obtener el historial de movimientos de un id
        /// </summary>
        /// <param name="iIdVenta">id venta</param>
        /// <returns>retorna una lista con el historial de moviemientos de un id venta</returns>
        public List<modeloHistorialId> obtenerHistoriaId(int iIdVenta)
        {
            List<modeloHistorialId> listaHistorial = new List<modeloHistorialId>();
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SpVTASReporteMovimientos", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@Id", iIdVenta);
                sqlCommand.Parameters.AddWithValue("@movimientoinicial", "");
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        listaHistorial.Add(new modeloHistorialId
                        {
                            sMov = dr["mov"].ToString(),
                            sMovId = dr["movId"].ToString(),
                            sEstatus = dr["estatus"].ToString(),
                        });
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerHistoriaId", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return listaHistorial;
        }

        /// <summary>
        /// Metodo encargado de obtener si el beneficiario final esta presente o no
        /// </summary>
        /// <param name="iIdSolicitud">id de la solicitud de credito</param>
        /// <returns>Retorna si cual el beneficiario final este presente en la venta</returns>
        public string obtenerFinalPresente(int iIdSolicitud)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            string sFinalPresente = string.Empty;
            sQuery = string.Format("select ISNULL(Beneficiario_Final_Presente,'NO') AS Final  from AnexoCta_ctefinal WITH(NOLOCK)  WHERE Id_Solicitud = {0}", iIdSolicitud);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidSid);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (dr.Read())
                    {
                        sFinalPresente = dr["Final"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerFinalPresente", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sFinalPresente;
        }

        /// <summary>
        /// Metodo encargado de obtener el id de la solicitud de credito
        /// </summary>
        /// <param name="sMov">movimiento Solicitid Credito</param>
        /// <param name="sMovId">mov id del movimiento</param>
        /// <returns>retorna el id de la solicitud</returns>
        public int obtenerIdSolicitudCredito(string sMov, string sMovId)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            int iIdSolicitud = 0;
            sQuery = string.Format("select ID from venta WITH(NOLOCK) where mov = '{0}' and MovID = '{1}'", sMov, sMovId);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (dr.Read())
                    {
                        iIdSolicitud = int.Parse(dr["ID"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerIdSolicitudCredito", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iIdSolicitud;
        }

        #endregion


        #region -PrimeraFaseDeAutomatizacion
        //-PrimeraFaseDeAutomatizacion

        public bool verExistenciaProductosPedido()
        {
            bool afectar = true;
            string productosMsj = "";

            for (int i = 0; i < DM0312_DetalleVenta.ListaDetalles.Count; i++)
            {
                //-CorreccionAutomatizacion
                if (DM0312_DetalleVenta.ListaDetalles[i].Tipo != "Servicio" && DM0312_DetalleVenta.ListaDetalles[i].Tipo != "Juego")
                {
                    if (!existenciaProducto(DM0312_DetalleVenta.ListaDetalles[i].Articulo, int.Parse(DM0312_DetalleVenta.ListaDetalles[i].Cantidad)))
                    {
                        productosMsj += DM0312_DetalleVenta.ListaDetalles[i].Articulo + " " + DM0312_DetalleVenta.ListaDetalles[i].Descripcion + Environment.NewLine;
                        afectar = false;
                    }
                }
            }

            if (!afectar)
            {
                MessageBox.Show("No se puede afectar automaticamente el pedido debido a que no hay existencia suficiente de los siguientes productos:" + Environment.NewLine + Environment.NewLine + productosMsj);
            }

            return afectar;
        }


        public bool existenciaProducto(string sku, int qty)
        {

            SqlDataReader dr = null;

            string query = string.Format(@"SELECT
 				 D.Articulo,Total = D.Disponible , D.Almacen,Alm.Sucursal
				FROM ArtDisponible D With(NoLock) 
				INNER JOIN Alm With(NoLock) ON D.Almacen = Alm.Almacen  
			 	INNER JOIN Art With(NoLock) ON D.Articulo = Art.Articulo AND IsNull(Art.Categoria,'') NOT IN ('ACTIVOS FIJOS','F FISCAL')  
	 		    INNER JOIN Sucursal S With(NoLock) ON S.Sucursal = Alm.Sucursal
				Where D.Articulo in ('{0}') and  
				IsNull(D.Disponible,0) >= {1}				
				and D.Almacen='V00096'", sku, qty);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();

                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("existenciaProducto", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }

            return false;
        }


        #endregion

        //PrimeraFaseDeAutomatizacion //-ReservaOnline
        #region -ReservaOnline
        /// <summary>
        /// Metodo encargado de insertar en la tabla VTASHReservaOnline
        /// </summary>
        /// <param name="ArtReservacion">Cantidad de articulos a reservar</param>
        /// <param name="sArticulo">Articulo a reservar</param>
        /// <param name="sAlmacen">almacen donde se reservaran los articulo</param>
        /// <param name="sIdEcommerce">id de la venta en line</param>
        /// Autor: Norberto Reyes C.
        public void insertarReservacionArticulo(int ArtReservacion, string sArticulo, string sAlmacen, string sIdEcommerce)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format("INSERT INTO VTASHReservaOnline (ReservaOnline,Articulo,Almacen,FechaReservacion,EstatusReservacion,IdEcommerce) VALUES " +
                "('{0}','{1}','{2}',GETDATE(),'Reservado','{3}')", ArtReservacion, sArticulo, sAlmacen, sIdEcommerce);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("insertarReservacionArticulo", "DM0312_CPuntoDeVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        /// <summary>
        /// Valida si el articulo a reservar cuenta con 2 o mas unidades en el almacen
        /// </summary>
        /// <param name="sArticulo">articulo a validar</param>
        /// <param name="sAlmacen">almacen donde se validara</param>
        /// <returns>retorna true si se puede validar</returns>
        /// Autor: Norberto Reyes C.
        public bool validarArticulosAReservar(string sArticulo, string sAlmacen)
        {
            SqlDataReader dr = null;
            bool bPuedeReservar = false;
            string query = string.Format("SELECT " +
                "DISTINCT Art.Articulo AS Codigo," +
                "Descripcion1 AS Nombre," +
                "CASE  WHEN CATEGORIA = 'ACTIVOS FIJOS' THEN ISNULL(ActivoFDisponible.Disponible, 0) " +
                "ELSE ISNULL(ArtDisponible.Disponible, 0) " +
                "END Disponible " +
                "FROM Art WITH(NOLOCK) " +
                "LEFT JOIN ArtDisponible WITH(NOLOCK) " +
                "ON Art.Articulo = ArtDisponible.Articulo AND(ArtDisponible.Almacen = '{0}'  OR ArtDisponible.almacen IS NULL) " +
                "LEFT JOIN ActivoFDisponible WITH(NOLOCK) " +
                "ON Art.Articulo = ActivoFDisponible.Articulo " +
                "AND(ActivoFDisponible.Almacen = '{0}' OR ActivoFDisponible.almacen IS NULL) " +
                "WHERE Grupo IN('MERCANCIA DE LINEA', 'INVENTARIOS', 'SERVICIOS A CLIENTES', 'MERCANCIA ESPECIAL', 'PRODUCTOS DIVERSOS') " +
                "AND Categoria IN('ACTIVOS FIJOS', 'VENTA') " +
                "AND art.tipo IN('Juego', 'Servicio', 'Normal', 'Serie', 'Lote') " +
                "AND Estatus IN('ALTA', 'BLOQUEADO') " +
                "AND Linea <> '' " +
                "AND FAMILIA <> 'VALERAS' " +
                "AND ArtDisponible.Disponible > 0 " +
                "AND Art.Articulo = '{1}'" +
                "ORDER BY Art.Articulo", sAlmacen, sArticulo);
            int valorMinimo = getMinimoExistencia();
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();

                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (int.Parse(dr["Disponible"].ToString()) >= valorMinimo)
                            {
                                bPuedeReservar = true;
                            }
                            else
                            {
                                bPuedeReservar = false;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return bPuedeReservar;
        }

        /// <summary>
        /// Valida si la sucursal se encuentra disponible para recoger  
        /// </summary>
        /// <param name="sAlmacen">Almacén donde se validará</param>
        /// <returns>Regresa true/false si el almacén es validado</returns>
        /// Autor: Emir Tapia
        public bool validarSucursal(string sAlmacen)
        {
            SqlDataReader dr = null;
            bool bPuedeReservar = false;
            string query = string.Format("SELECT TOP 1 Nombre FROM TablaStd WITH(NOLOCK) WHERE TablaSt = 'SUCURSALNORESERVAMERCANCIA' AND Nombre = '{0}' AND Valor = 1", sAlmacen);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();

                    dr = sqlCommand.ExecuteReader();
                    bPuedeReservar = dr.HasRows;
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }
            return bPuedeReservar;
        }


        /// <summary>
        /// Obtiene el valor minimo de existencia de un articulo
        /// </summary>
        /// <returns>Retorna el valor entero de existencia de un articulo</returns>
        public int getMinimoExistencia()
        {
            SqlDataReader dr = null;
            string sQuery = "SELECT MAX(Numero) FROM tablanumd WITH(NOLOCK) WHERE tablanum = 'EXISTENCIAENVIOSUCURSAL'";
            int valorMinimo = 0;
            using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();

                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (!string.IsNullOrEmpty(dr[0].ToString()))
                            {
                                valorMinimo = Convert.ToInt32(Math.Round(Convert.ToDouble(dr[0].ToString())));
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }
            return valorMinimo;
        }

        /// <summary>
        /// Se obtiene la lista de arculos a reservar
        /// </summary>
        /// <param name="sIdeEcommerce">id ecomerce, se usa para enlazar la venta y obtener los articulo</param>
        /// <returns>retorna la lista de articulos a reservar</returns>
        /// Autor: Norberto Reyes C.
        public List<string> obtenerarticulosAReservar(string sIdeEcommerce)
        {
            List<string> listaArticulos = new List<string>();

            SqlDataReader dr = null;
            string query = string.Empty;
            //query = string.Format("select vd.articulo as Articulo from venta v WITH(NOLOCK) INNER JOIN ventaD vd WITH(NOLOCK) ON(v.id = vd.id) where IDEcommerce = '{0}'", sIdeEcommerce);
            query = string.Format(@"select vd.articulo as Articulo 
                    from venta v WITH(NOLOCK) 
                    INNER JOIN ventaD vd WITH(NOLOCK) 
                    ON(v.id = vd.id) 
                    INNER JOIN Art a WITH(NOLOCK)
                    ON vd.articulo = a.articulo
                    where IDEcommerce = '{0}'
                    AND v.Mov = 'Pedido'
                    and a.Unidad <> 'SERVICIO'", sIdeEcommerce);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        listaArticulos.Add(dr["Articulo"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerarticulosAValidarr", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return listaArticulos;
        }

        /// <summary>
        /// metodo encargado de obtener la cantidad de articulos a reservar
        /// </summary>
        /// <param name="sIdeEcommerce">id de la venta en linea</param>
        /// <param name="sArticulo">articulo del cual se obtendra la cantidad de articulos vendidos</param>
        /// <returns>retorna uun entero con la cantidad de articulos a reservar</returns>
        /// Autor: Norberto Reyes C.
        public int obtenerCantidadArticulos(string sIdeEcommerce, string sArticulo)
        {
            int iCantidadArticulos = 0;
            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("select vd.Cantidad as Cantidad from venta v WITH(NOLOCK) " +
                "INNER JOIN ventaD vd WITH(NOLOCK) ON(v.id = vd.id) " +
                "where IDEcommerce = '{0}' AND vd.articulo = '{1}'", sIdeEcommerce, sArticulo);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        iCantidadArticulos = int.Parse(dr["Cantidad"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerCantidadArticulos", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iCantidadArticulos;
        }

        /// <summary>
        /// Metodo encargado se obtener si existe una reservacion ya registrada, de ser asi actualizara el almacen
        /// </summary>
        /// <param name="sIdEcommerce">identificador de registro</param>
        /// <returns>retorna true si ya existe una reservacion </returns>
        /// Autor: Norberto Reyes C.
        public bool validarExistenciaReserva(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            bool bPuedeReservar = false;
            string query = string.Format("SELECT 1 AS Existe FROM VTASHReservaOnline WITH(NOLOCK) WHERE IdEcommerce = '{0}'", sIdEcommerce);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();

                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (int.Parse(dr["Existe"].ToString()) == 1)
                            {
                                bPuedeReservar = true;
                            }
                            else
                            {
                                bPuedeReservar = false;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("validarExistenciaReserva", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }

            return bPuedeReservar;
        }

        /// <summary>
        /// Metodo encargado de acutalizar una reservacion en caso de exister
        /// </summary>
        /// <param name="sIdEcommerce">identificador de la venta en linea</param>
        /// <param name="sNuevoAlmacen">nuevo almacen al que se cambio</param>
        /// <param name="sArticulo">articulo a reserver</param>
        /// <returns>retorna true si todo salio bien</returns>
        /// Autor: Norberto Reyes C.
        public bool actualizarAlmacen(string sIdEcommerce, string sNuevoAlmacen, string sArticulo)
        {
            SqlDataReader dr = null;
            bool bActualizo = false;
            string query = string.Empty;
            query = string.Format("UPDATE VTASHReservaOnline WITH (ROWLOCK) SET Almacen = '{0}' " +
                "WHERE IdEcommerce = '{1}' AND articulo = '{2}'; SELECT @@ROWCOUNT As Row", sNuevoAlmacen, sIdEcommerce, sArticulo);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    if (dr.Read())
                    {
                        if (int.Parse(dr["Row"].ToString()) == 1)
                        {
                            bActualizo = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("actualizarAlmacen", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return bActualizo;
        }

        public List<string> obtenerCorreos(int? iSucursal)
        {
            List<string> listaArticulos = new List<string>();

            string sCaja = "CAJA SUC. ";
            if (iSucursal < 10)
            {
                sCaja += "0" + iSucursal.ToString();
            }
            else
            {
                sCaja += iSucursal.ToString();
            }

            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("Select * FROM OPENQUERY ( WEBMYSQL, 'SELECT * FROM intranet_home.directoriogral_intelisis WHERE Nombre = ''{0}''')", sCaja);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        listaArticulos.Add(dr["mailinterno"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerCorreos", "DM0312_CDetalleVenta", ex);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return listaArticulos;
        }

        public int obtenerUen(int? iSucursal)
        {
            SqlDataReader dr = null;
            int iUen = 0;
            string query = string.Format("select wUen from sucursal WHERE Sucursal = '{0}'", iSucursal);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            iUen = int.Parse(dr["wUen"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("validarExistenciaReserva", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }

            return iUen;
        }

        public void actualizarReservaOnline(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            int iActualizar = 0;
            string query = string.Format("UPDATE vtashreservaonline WITH(ROWLOCK) SET EstatusReservacion = 'Entregado' WHERE IdEcommerce = '{0}'; SELECT @@ROWCOUNT AS Row", sIdEcommerce);
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            iActualizar = int.Parse(dr["Row"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("actualizarReservaOnline", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
        }

        public void eliminarClave(string sIdEcommerce)
        {

        }

        /// <summary>
        /// metodo encargado de validar si la venta que se esta afectando es recoger en sucursal
        /// </summary>
        /// <param name="sIdEcommerce">id de la venta online</param>
        /// <returns>retorna true si la venta es recoger en sucursal</returns>
        public bool validarRecogerSucursal(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            bool bRecogeSucursal = false;
            string query = string.Format("Select COUNT(*) AS Total from TrWDM0285_CteRecoge where IdEcommerce = '{0}'", sIdEcommerce);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (int.Parse(dr["Total"].ToString()) > 0)
                            {
                                bRecogeSucursal = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("validarArticulosAReservar", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
            return bRecogeSucursal;
        }

        /// <summary>
        /// Metodo encargado de dar de baja el articulo reservado
        /// </summary>
        /// <param name="sIdEcommerce">id ecomerce al que hace referencia la venta en linea</param>
        public void cancelarReservacion(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            int iActualizo = 0;
            string query = string.Format("UPDATE VTASHReservaOnline WITH(ROWLOCK) SET EstatusReservacion = 'Cancelado' WHERE IdEcommerce = '{0}'; SELECT @@ROWCOUNT AS Actualizo", sIdEcommerce);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (int.Parse(dr["Actualizo"].ToString()) > 0)
                            {
                                iActualizo = int.Parse(dr["Actualizo"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("cancelarReservacion", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
        }

        /// <summary>
        /// metodo encargado de validar si existe registro en la tabla TrWDM0285_CteRecoge para validar si se puede reservar el articulo
        /// </summary>
        /// <param name="sIdEcommerce">idecommerce de la venta</param>
        /// <returns>retorna true el idecommerce existe en la tabla si no existe retorna false</returns>
        public bool validarCteRecoge(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            bool bExiste = false;
            string query = string.Format("SELECT 1 AS Existe FROM TrWDM0285_CteRecoge WITH (NOLOCK) WHERE IdEcommerce = '{0}'", sIdEcommerce);

            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            if (int.Parse(dr["Existe"].ToString()) >= 1)
                            {
                                bExiste = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("validarCteRecoge", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
            return bExiste;
        }


        public string obtenerArticulosYDetalle(int iIdVenta)
        {
            SqlDataReader dr = null;
            string sCadena = string.Empty;
            string query = string.Format("SELECT " +
                "ar.Articulo," +
                "ar.Descripcion1, " +
                "vd.Precio, " +
                "vd.Cantidad " +
                "FROM ventad AS vd " +
                "INNER JOIN art AS ar " +
                "ON vd.Articulo = ar.Articulo " +
                "WHERE vd.ID = '{0}'", iIdVenta);
            using (var sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {

                        while (dr.Read())
                        {
                            sCadena += @"
                           <table class='email - items' style='width: 70 % !important; '>
                           <tr >
                               <td colspan = '2' align = 'center' valign = 'middle' height = '35%' >
                                    <h3 style = 'font-weight: 700;' > Modelo: " + dr["Articulo"].ToString() + @"<hr style = 'border: 1px solid #888888;' /></h3 >
                                </td >
                            </tr >
                            <tr align = 'left' >
                                <td colspan = '2' height = '25%' >
                                    <h5 style = 'font-weight: 700;' > " + dr["Descripcion1"].ToString() + @" </h5 >
                                </td >
                            </tr >
                            <tr align = 'right' valign = 'top'>
                                <td > Producto </td >
                                <td >" + string.Format("{0:C}", Convert.ToDouble(dr["Precio"].ToString())) + @" </td >
                            </tr >
                            <tr align = 'right' valign = 'top' >
                            <td > Cantidad </ td >
                            <td >" + dr["Cantidad"].ToString() + @" </td >
                            </tr >
                            </table >";
                        }

                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("obtenerNombreCliente", "CDetalleVenta.cs", ex);
                    MessageBox.Show(ex.Message);
                }
            }
            return sCadena;

        }

        /// <summary>
        /// metodo encargado de obtener el nombre y apellido del cliente
        /// </summary>
        /// <param name="sCliente">numero de cliente</param>
        /// <returns>retorna nombre y apellido del cliente</returns>
        public string obtenerNombreCliente(string sCliente, int iOpcion = 1)
        {
            SqlDataReader dr = null;
            string sNombreCliente = string.Empty;

            string sQuery = string.Empty;
            string sColumna = string.Empty;

            if (iOpcion == 1)
            {
                sQuery = string.Format("select nombre from cte WITH(NOLOCK) where cliente = '{0}'", sCliente);
                sColumna = "nombre";
            }
            if (iOpcion == 2)
            {
                sQuery = string.Format("select ISNULL(email1,'SIN CORREO') as Correo from cte WITH(NOLOCK) where cliente = '{0}'", sCliente);
                sColumna = "Correo";
            }

            using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            sNombreCliente = dr[sColumna].ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("obtenerNombreCliente", "CDetalleVenta.cs", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
            }
            return sNombreCliente;

        }

        /// <summary>
        /// metodo encargado de obtener la contraseña del cliente en base a su idecommerce
        /// </summary>
        /// <param name="sIdEcommerce">idecommerce de la venta</param>
        /// <returns>retorna la clave para recoger en sucursal, esta se adunta al correo del cliente</returns>
        public string obtenerClaveCliente(string sIdEcommerce)
        {
            SqlDataReader dr = null;
            string sClave = string.Empty;
            string sQuery = string.Format("SELECT ClaveVenta FROM TrWDM0285_CteRecoge WHERE idEcommerce = '{0}'", sIdEcommerce);
            using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {

                        while (dr.Read())
                        {
                            sClave = dr["ClaveVenta"].ToString();
                        }

                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }
            return sClave;
        }

        /// <summary>
        /// Metodo encargado de obtener la sucursal que se mostrara en el correo del cliente
        /// </summary>
        /// <param name="iSucursal">sucursal destino</param>
        /// <returns>retorna la direccion completa de la sucursal seleccionada por el cliente</returns>
        public string direccionSucursal(int? iSucursal)
        {
            SqlDataReader dr = null;
            string sDireccion = string.Empty;
            string sQuery = string.Format("SELECT Direccion +' '+ DireccionNumero+' '+ Colonia +', '+ Delegacion +' '+ Estado +' / Tienda '+ Nombre AS Direccion from Sucursal WITH(NOLOCK) WHERE Sucursal = {0}", iSucursal);
            using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                try
                {
                    sqlCommand.ExecuteNonQuery();
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {

                        while (dr.Read())
                        {
                            sDireccion = dr["Direccion"].ToString();
                        }

                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }
            return sDireccion;
        }
        public string ObtenerTelefonos(int iUen)
        {
            {
                SqlDataReader dr = null;
                string sTelefonos = string.Empty;
                string sQuery = string.Format("SELECT Valor FROM tablastd WITH(NOLOCK) WHERE tablast='CONFIGTEL' AND Nombre = {0}", iUen);
                using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    try
                    {
                        sqlCommand.ExecuteNonQuery();
                        dr = sqlCommand.ExecuteReader();
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                sTelefonos += @"<p>" + dr["Valor"].ToString() + @"</p>";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                        MessageBox.Show(ex.Message);
                    }
                }

                return sTelefonos;
            }
        }
        #endregion

        #region //-CambioAgente Dev. Norberto Reyes C. 21/10/2019

        /// <summary>
        /// Metodo encargado de validar si la sucursal se encuentra habilitada para poder realizar el cambio de agente
        /// </summary>
        /// <param name="iSucursal">sucursal a validar</param>
        /// <returns>retorna true si la </returns>
        public bool validarSucursal(int iSucursal)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            bool bSucursalValida = false;
            sQuery = string.Format("SELECT NUMERO FROM tablanumd WITH(NOLOCK) WHERE tablanum = 'SUCURSAL VIRTUAL' and valor = 1 and Numero = {0}", iSucursal);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    bSucursalValida = true;
                }
                else
                {
                    bSucursalValida = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarSucursal", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return bSucursalValida;
        }

        /// <summary>
        /// metodo encargado de obtener el numero de agente del usuario firmado
        /// </summary>
        /// <param name="sUsuario">Usuario firmado en la sesion</param>
        /// <returns>returna el numero de agente en base al usuario firmado</returns>
        public string obtenerAgenteDeUsuario(string sUsuario)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            string sAgente = string.Empty;
            sQuery = string.Format("SELECT propiedad FROM Prop WITH(NOLOCK) WHERE Cuenta = '{0}'", sUsuario);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        sAgente = dr["propiedad"].ToString();
                    }
                }
                else
                {
                    sAgente = string.Empty;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerAgenteDeUsuario", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sAgente;
        }

        /// <summary>
        /// metodo encargado de actualizar el estatus a todos los movimientos de la tabla venta
        /// </summary>
        /// <param name="sMov">movimiento de la venta</param>
        /// <param name="sMovId">mov id de la venta</param>
        /// <param name="sEstatus">estatus de la venta</param>
        /// <param name="sAgente">agenta que se colocara en vez del generico</param>
        /// <returns>retorna true si actualizo el agente de lo contrario false</returns>
        public bool actualizarVenta(modeloHistorialId mVenta, string sAgente)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            bool bActualizo = false;
            sQuery = string.Format("UPDATE venta WITH(ROWLOCK) SET Agente = '{0}' WHERE Mov = '{1}' AND MovId = '{2}' And Estatus = '{3}'; SELECT @@ROWCOUNT As Row", sAgente, mVenta.sMov, mVenta.sMovId, mVenta.sEstatus);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (int.Parse(dr["Row"].ToString()) == 1)
                        {
                            bActualizo = true;
                        }
                    }
                }
                else
                {
                    bActualizo = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("actualizarVenta", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return bActualizo;
        }

        /// <summary>
        /// metodo encargado de obtener el agente de la venta seleccionada
        /// </summary>
        /// <param name="iIdVenta">id de la venta seleccionada</param>
        /// <returns></returns>
        public string obtenerAgenteDeLaVenta(int iIdVenta)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            string sAgente = string.Empty;
            sQuery = string.Format("select agente from venta WITH(NOLOCK) where id = {0}", iIdVenta);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        sAgente = dr["agente"].ToString();
                    }
                }
                else
                {
                    sAgente = string.Empty;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerAgenteDeLaVenta", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sAgente;

        }

        #endregion

        #region ValeDigital
        public int cancelarVale(string sVale)
        {
            int iActualizo = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "cancelarVale" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = sVale }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                iActualizo = int.Parse(dr[0].ToString());
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("cancelarVale", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return iActualizo;
        }

        public string obtenerNumeroVale(int iIdVenta)
        {
            SqlDataReader dr = null;
            string sVale = string.Empty;
            try
            {
                string sQuery = string.Format("select codigobarras from DM0244_FOLIOS_VALES  with(nolock)where idsolvtaval = {0}", iIdVenta);
                SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        sVale = dr["codigobarras"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerNumeroVale", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }
            return sVale;
        }
        #endregion

        #region  //-MejorasMayoreo

        public void updateConMayoreo(int check, int id)
        {

            string query = string.Format("update venta with(rowlock) set AfectaComisionMavi={0} where id={1}", check, id);

            try
            {
                using (SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region //-596AlmacenensVirtuales

        /// <summary>
        /// Metodo encargado de validar si la sucursal en la que esta firmado el usuario puede habilitar los botones ecoommerce
        /// </summary>
        /// <param name="iSucursal">sucursal donde se encuentra firmado el usuario</param>
        /// <returns>retorna true si la sucursal puede ver y editar los campos ecommerce </returns>
        public bool validarSucursalAlmacenVirtual()
        {
            bool bAcceso = false;
            dt = new DataTable();
            try
            {
                string sQuery = "select nombre from tablastd WITH(NOLOCK) where tablast = 'CONFVTLMKPL' and nombre = @Sucursal AND Valor = 1";

                using (var vComando = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    SqlParameter[] pars = new SqlParameter[] {
                        new SqlParameter("@Sucursal", ClaseEstatica.Usuario.Sucursal) {
                            SqlDbType = SqlDbType.VarChar
                        }
                    };

                    vComando.CommandType = CommandType.Text;
                    vComando.Parameters.AddRange(pars);
                    using (SqlDataReader dr = vComando.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return bAcceso;
        }
        #endregion

        #region -DataLogic
        public int valdiarRecarga(int iTicket)
        {
            int iResultado = 0;

            SqlDataReader dr = null;

            string query = string.Empty;
            query = string.Format("SELECT COUNT(*) FROM DM0216PagoExternoVtas WITH(NOLOCK) WHERE Ticket = {0} AND ESTATUS = 'CONCLUIDO'", iTicket);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        iResultado = int.Parse(dr[0].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iResultado;
        }

        /// <summary>
        /// metodo encargado de validar si en la venta realizada se vendio un celular.
        /// </summary>
        /// <param name="iId">id venta</param>
        /// <returns>retorna el numero de celulares que se vendio</returns>
        public int ValidarVentaCelular(int iId)
        {
            int iResultado = 0;

            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("select count(*) from ventad vd WITH (NOLOCK) " +
                "inner join art ar WITH(NOLOCK) " +
                "ON(vd.articulo = ar.articulo) " +
                "where vd.id = {0} " +
                "AND ar.Linea LIKE '%CELULAR%'", iId);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        iResultado = int.Parse(dr[0].ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iResultado;

        }

        /// <summary>
        /// metodo encargado de validar si el canal de venta pertenece a la categoria credito menudeo
        /// </summary>
        /// <param name="iCanal">canal de venta a validar</param>
        /// <returns>retorna true si el canal de venta es credito menudeo</returns>
        public bool validarCanalVenta(int iCanal)
        {
            bool bAccesoCorrecto = false;
            try
            {
                string sQuery = "select top 1 id from ventascanalmavi with(nolock) where categoria = 'CREDITO MENUDEO' and id = @Canal";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Canal", iCanal) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAccesoCorrecto = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return bAccesoCorrecto;
        }

        #endregion

        #region //-VentaCredito

        public void ejecutarMagento(string sIdEcommerce, string sEstatus)
        {
            try
            {
                string fecha = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
#if PRODUCCION
                string xml = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:viu=\" http://www.viu.mx/soap/viu?services=entrepidsRunImportInterfacesRunImportV1\">" +
                "<soap:Header/> " +
                 "<soap:Body> " +
                  "<viu:entrepidsRunImportInterfacesRunImportV1ImportRequest> " +
                   "<importData> " +
                   "<interfaceName>ifSalesStatus</interfaceName> " +
                   "<data> " +
                   "<![CDATA[" +
                   "<record> " +
                   "<increment_id>" + sIdEcommerce + "</increment_id>" +
                   "<status>" + sEstatus + "</status>" +
                   "<status_date>" + fecha + "</status_date>" +
                   "</record> " +
                   "]]> " +
                   "</data> " +
                   "</importData> " +
                   "</viu:entrepidsRunImportInterfacesRunImportV1ImportRequest> " +
                   " </soap:Body> " +
                   "</soap:Envelope> ";

                XDocument docxml = XDocument.Parse(xml);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://www.viu.mx/soap/viu?services=entrepidsRunImportInterfacesRunImportV1");
#elif CUBOS || PROSERVER
                string xml = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:viu=\"http://magentotest-viu.grupomavi.com/soap/viu?services=entrepidsRunImportInterfacesRunImportV1\">" +
                "<soap:Header/> " +
                 "<soap:Body> " +
                  "<viu:entrepidsRunImportInterfacesRunImportV1ImportRequest> " +
                   "<importData> " +
                   "<interfaceName>ifSalesStatus</interfaceName> " +
                   "<data> " +
                   "<![CDATA[" +
                   "<record> " +
                   "<increment_id>" + sIdEcommerce + "</increment_id>" +
                   "<status>" + sEstatus + "</status>" +
                   "<status_date>" + fecha + "</status_date>" +
                   "</record> " +
                   "]]> " +
                   "</data> " +
                   "</importData> " +
                   "</viu:entrepidsRunImportInterfacesRunImportV1ImportRequest> " +
                   " </soap:Body> " +
                   "</soap:Envelope> ";

                XDocument docxml = XDocument.Parse(xml);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://magentotest-viu.grupomavi.com/soap/viu?services=entrepidsRunImportInterfacesRunImportV1");
#endif

                request.Headers.Add(@"Authorization: Bearer ljm71ppw7vv8xkxbl39easgr56m6dh1t");
                request.Method = "POST";
                request.ContentType = "text/xml";

                byte[] arreglo = Encoding.UTF8.GetBytes(docxml.ToString());

                request.ContentLength = arreglo.Length;
                Stream dataStream = request.GetRequestStream();
                dataStream.Write(arreglo, 0, arreglo.Length);
                dataStream.Close();

                WebResponse response = request.GetResponse();
                StreamReader responseStreamReader = new StreamReader(response.GetResponseStream());
                string result = responseStreamReader.ReadToEnd();
                XDocument docxmlResult = XDocument.Parse(result);
                string sResult = docxmlResult.Descendants("result").First().Value;
                responseStreamReader.Close();
                Console.WriteLine("Respuesta Api Magento -> " + sResult);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error en el metodo -> " + MethodBase.GetCurrentMethod().Name + " En la clase -> " + MethodBase.GetCurrentMethod().DeclaringType.Name + ", Error -> " + ex.Message, "Dineralia");
            }
        }

        #endregion


        #region //-CorreccionFamiliaLinea
        /// <summary>
        /// Metodo encargado de validar si la familia del articulo es de las nuevas familias de motos
        /// </summary>
        /// <param name="sLinea">Linea del articulo</param>
        /// <returns></returns>
        public bool validarFamiliaLinea(string sLinea)
        {
            bool bAcceso = false;
            try
            {
                string sQuery = "select ID  from ArtLinea with (nolock) where id in ('625','626','627','628','629','630') AND LINEA = @Linea";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Linea", sLinea) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        #endregion

        #region //-731

        /// <summary>
        /// Metodo encargado de validar si el acceso del usuario puede habilitar el boton de eventos
        /// </summary>
        /// <returns>retorna true si el acceso del usuario puede habilitar el boton de eventos de lo contrario false</returns>
        public bool accesoBotonEventos()
        {
            bool bAcceso = false;
            try
            {
                string sQuery = "SELECT Nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'USUARIOS CON PERMISO AL ICONO DE EVENTO' and Nombre= @Acceso";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }


        #endregion

        #region //-Dineralia
        /// <summary>
        /// Metodo encargado de obtener el numero de tarjeta del cliente
        /// </summary>
        /// <param name="sCliente">Cuenta del cliente</param>
        /// <returns>retorna el numero de tarjeta</returns>
        public string obtenerNumeroTarjeta(string sCliente, int iOpcion)
        {
            string sRetorno = string.Empty;
            dt = new DataTable();
            string sCampo = string.Empty;
            switch (iOpcion)
            {
                case 1:
                    sCampo = "numerotarjetadineralia";
                    break;
                case 2:
                    sCampo = "nombre";
                    break;
                default:
                    break;
            }
            try
            {
                string sQuery = "select " + sCampo + " from cte WITH(NOLOCK) where Cliente = @Cliente";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sRetorno = row[sCampo].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sRetorno;
        }

        /// <summary>
        /// metodo encargado de obtener la fecha de la solicitud de credito
        /// </summary>
        public DateTime obtnerFechaSolicitud(int iIdVenta)
        {
            string sRetorno = string.Empty;
            dt = new DataTable();
            DateTime dtFecha = new DateTime();
            try
            {
                string sQuery = "SELECT v.FechaEmision FROM Venta V WITH (NOLOCK) " +
                    "INNER JOIN Venta vd WITH(NOLOCK) " +
                    "on v.Origen = vd.Mov and v.origenid = vd.MovID " +
                    "WHERE v.ID = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        dtFecha = DateTime.Parse(row["FechaEmision"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return dtFecha;
        }

        /// <summary>
        /// metodo encargado de validar los eventos y la situacion para enviar correo
        /// </summary>
        /// <param name="iIdVenta"></param>
        /// <param name="sSituacion"></param>
        /// <returns></returns>
        public string validarCorreo(int iIdVenta, string sSituacion)
        {
            string sCorreo = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery = "select  CASE WHEN st.Valor = 'ACEPTADO' THEN 'CreditoAprobado' WHEN st.Valor = 'RECHAZADO' THEN 'CreditoNoAprobado' WHEN st.valor = 'CONDICIONADO' THEN 'CreditoAprobadoAjuste' END AS Correo " +
                    "from venta v with(nolock) " +
                    "inner join movbitacora mb with(nolock) " +
                    "on v.ID = mb.id " +
                    "inner join tablastd st with(nolock) " +
                    "on mb.Clave = st.Nombre and st.TablaSt = 'EventosTransaccionalDineralia' " +
                    "where v.ID = @Id and st.Valor = @Situacion";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Situacion", sSituacion) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sCorreo = item["Correo"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sCorreo;
        }

        public string obtenerSituacion(int iId)
        {
            dt = new DataTable();
            string sSituacion = string.Empty;
            try
            {
                string sQuery = "SELECT Situacion FROM Venta WITH(NOLOCK) WHERE Id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sSituacion = item["Situacion"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sSituacion;
        }

        /// <summary>
        /// Metodo encargado de actualizar el envio de correo
        /// </summary>
        /// <param name="iId">id venta</param>
        public void actualizarCorreoEnviado(int iId)
        {
            try
            {
                string sQuery = "UPDATE VTASHSolicitudesDineralia WITH(ROWLOCK) SET EnvioCorreo = 1 WHERE IdVenta = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// metodo encargado de validar que no exista correo enviado
        /// </summary>
        /// <param name="iId">id venta</param>
        /// <returns>retorna true si no tiene correo de lo contrario false</returns>
        public bool validarCorreoEnviado(int iId)
        {
            bool bCorreoValido = false;
            try
            {
                string sQuery = "SELECT Cliente FROM VTASHSolicitudesDineralia WITH(NOLOCK) WHERE IdVenta = @Id AND ISNULL(EnvioCorreo,0) = 0";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bCorreoValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return bCorreoValido;
        }

        /// <summary>
        /// Metodo encargado de obtener el monto solicitado del cliente
        /// </summary>
        /// <param name="iId">id del analisis de credito</param>
        /// <returns>retorna el precio de la dineralia</returns>
        public string obtenerMontoSolicitado(int iId)
        {
            string sMonto = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT a.Capital FROM VentaD v WITH(NOLOCK) " +
                    "INNER JOIN Art a WITH(NOLOCK) " +
                    "ON v.Articulo = a.Articulo " +
                    "WHERE v.ID = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sMonto = row["Capital"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sMonto;
        }

        public string obtenernCapital(int iId)
        {
            string sMonto = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "select st.Valor as Monto from venta v WITH(NOLOCK) " +
                    "INNER JOIN MovBitacora mv WITH(NOLOCK) " +
                    "on v.ID = mv.ID " +
                    "INNER JOIN TablaStd st WITH(NOLOCK) " +
                    "ON st.Nombre = mv.Clave and st.TablaSt = 'MONTOEVENTOSTRANSACCIONALDINERALIA' " +
                    "WHERE v.id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sMonto = row["Monto"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sMonto;
        }

        /// <summary>
        /// Metodo encargado de obtener el monto solicitado del cliente
        /// </summary>
        /// <param name="iId">id del analisis de credito</param>
        /// <returns>retorna el precio de la dineralia</returns>
        public string obtenerInformacionDineralia()
        {
            string sRetorno = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT Nombre, Valor FROM TablaStd WITH(NOLOCK) WHERE Tablast = 'CorreosTransaccionalesDineralia'";

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sRetorno = row["Nombre"].ToString() + "|" + row["Valor"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sRetorno;
        }

        #endregion

        #region //-430

        /// <summary>
        /// Metodo encargado de validar si el dima es cliente nuevo
        /// </summary>
        /// <param name="sCliente">numero de cuenta del cliente dima</param>
        /// <returns>retorna true si el cliente dima es nuevo de lo contrario regresa false</returns>
        public bool validarDimaNuevo(int iId)
        {
            bool bAcceso = false;
            try
            {
                string sQuery = "select id from venta where id = @Id and mavitipoventa = 'Nuevo'";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        public string obtenerEstatusVenta(int iId)
        {
            dt = new DataTable();
            string sEstatus = string.Empty;
            try
            {
                string sQuery = "select Estatus from venta WITH(NOLOCK) where ID = @ID";
                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@ID", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sEstatus = row["Estatus"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sEstatus;
        }

        public string obtenerAgente(string sMovid)
        {
            dt = new DataTable();
            string sAgente = string.Empty;
            try
            {
                string sQuery = "select Coordinador from VTASHSeguimientoDIMANuevo with(nolock) where movid = @Movid and Movimiento = 'Solicitud Credito'";
                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Movid", sMovid) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sAgente = row["Coordinador"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sAgente;
        }

        public void actualiarHistorialDima(DM0312_MExploradorVenta mVenta, string sCalificacion = "", string sEstatusReal = "")
        {
            dt = new DataTable();
            try
            {
                //string sQuery = "UPDATE VTASHSeguimientoDIMANuevo WITH(ROWLOCK) SET EstatusReal = 'CONCLUIDO', Calificacion = @Calificacion,Observaciones = @Observaciones, FechaUltimoMovimiento = convert(varchar,GETDATE(),23) WHERE Mov = @Mov and movid = @movid";
                string sQuery = "UPDATE VTASHSeguimientoDIMANuevo WITH(ROWLOCK) SET FechaUltimoMovimiento = convert(varchar,GETDATE(),23), EstatusReal = @EstatusReal, Calificacion = @Calificacion WHERE Movimiento = @Mov and movid = @movid";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@movid", mVenta.MovId) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Mov", mVenta.Mov) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@EstatusReal", sEstatusReal = string.IsNullOrEmpty(sEstatusReal) ? "CONCLUIDO" : mVenta.Estatus) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Calificacion", sCalificacion) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public List<string> ObtenerComentarios(string sMovid, string sMov)
        {
            List<string> lsDatos = new List<string>() { "", "" };

            string sQuery = $"select Calificacion, Observaciones from VTASHSeguimientoDIMANuevo with(nolock) " +
                $"where movid = '{sMovid}' and Movimiento = '{sMov}'";
            try
            {
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                lsDatos.Add(dr[0].ToString());
                                lsDatos.Add(dr[1].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return lsDatos;
        }

        public void guardarHistorialDima(DM0312_MExploradorVenta mVenta, List<string> lsDatos, string sEstatus = "", bool bEstatus = false, string sAgente = "")
        {
            dt = new DataTable();
            if (bEstatus)
            {
                sEstatus = "CONCLUIDO";
            }
            else
            {
                if (string.IsNullOrEmpty(sEstatus))
                {
                    sEstatus = "CANCELADO";

                }
            }
            try
            {
                string sQuery = "INSERT INTO VTASHSeguimientoDIMANuevo (Coordinador,MovId,Movimiento,EstatusReal,FechaEmision, Calificacion ,Observaciones,FechaUltimoMovimiento,EstatusAnterior,EstatusActual, FechaActualizacion,DiasSinMovimiento,Comentarios,FechaRecordatorio) VALUES (@Coordinador, @MovID,@Movimiento,@Estatus,convert(varchar,GETDATE(),23),@calificacion,@obvervaciones,convert(varchar,GETDATE(),23),null,null,null,null,null,null)";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Coordinador", mVenta.Agente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@MovID", mVenta.MovId) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Movimiento", mVenta.Mov) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Estatus", sEstatus == "" ? "PENDIENTE" : sEstatus) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@calificacion", lsDatos[0]) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@obvervaciones", lsDatos[1]) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public bool validarFecha(string sMov, string sMovid)
        {
            bool bExisteFecha = false;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT CONVERT(varchar,ISNULL(fechaactualizacion,''),112) AS Fecha FROM VTASHSeguimientoDIMANuevo WITH(NOLOCK) WHERE MovId = @MovId AND Movimiento = @Movimiento";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@MovId", sMov) {
                        SqlDbType = SqlDbType.VarChar
                    },
                     new SqlParameter("@Movimiento", sMovid) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        if (item["Fecha"].ToString() != "19000101")
                        {
                            bExisteFecha = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExisteFecha;
        }

        public void ActualizarHistorialEventos(string estatus, string mov, string movid, string calificacion, string observaciones)
        {
            try
            {
                string sQuery = $"UPDATE VTASHSeguimientoDIMANuevo WITH(ROWLOCK) SET FechaUltimoMovimiento = convert(varchar,GETDATE(),23), " +
                    $"EstatusReal = '{estatus}', Observaciones = '{observaciones}', Calificacion = '{calificacion}' WHERE Movimiento = '{mov}' and movid = '{movid}'";

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public List<string> FechaActualizacion(DM0312_MExploradorVenta mVenta, string sEstatus)
        {
            List<string> listaDatos = new List<string>();
            string sQuery = $"select Coordinador, MovId, Movimiento, EstatusReal, Calificacion, Observaciones, FechaUltimoMovimiento from VTASHSeguimientoDIMANuevo with(nolock) " +
                $"where MovId = '{mVenta.MovId}' and Movimiento = '{mVenta.Mov}' and EstatusReal = '{sEstatus}' and FechaActualizacion <> ''";

            try
            {
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                listaDatos.Add(dr[0].ToString());
                                listaDatos.Add(dr[1].ToString());
                                listaDatos.Add(dr[2].ToString());
                                listaDatos.Add(dr[3].ToString());
                                listaDatos.Add(dr[4].ToString());
                                listaDatos.Add(dr[5].ToString());
                                listaDatos.Add(dr[6].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return listaDatos;
        }

        public void GuardaNuevoRegistro(List<string> datos, string sEstatus)
        {
            string sQuery = $"INSERT INTO VTASHSeguimientoDIMANuevo(Coordinador, MovId, Movimiento, EstatusReal, FechaEmision, Calificacion , Observaciones, " +
                $"FechaUltimoMovimiento, EstatusAnterior, EstatusActual, FechaActualizacion, DiasSinMovimiento, Comentarios, FechaRecordatorio) " +
                $"VALUES('{datos[0]}', '{datos[1]}', '{datos[2]}', '{sEstatus}', convert(varchar, GETDATE(), 23), '{datos[4]}', '{datos[5]}', " +
                $"convert(varchar, GETDATE(), 23), null, null, null, null, null, null)";
            try
            {
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region //-DomicilioCliente
        public clsDatosEntregaCliente obtenerDatosCliente(string sCliente)
        {
            clsDatosEntregaCliente datosCliente = new clsDatosEntregaCliente();
            dt = new DataTable();
            try
            {
                string sQuery = @"SELECT
                                ISNULL(Direccion, '') AS Direccion,
                                ISNULL(DireccionNumero, 's/n') AS DireccionNumero,
                                ISNULL(DireccionNumeroInt, 's/n') AS DireccionNumeroInt,
                                ISNULL(Colonia, '') AS Colonia,
                                ISNULL(CodigoPostal, 0) AS CodigoPostal,
                                ISNULL(Poblacion, '') AS Poblacion,
                                ISNULL(Estado, '') AS Estado,
                                ISNULL(EntreCalles, '') AS EntreCalles,
                                ISNULL(Nombre, '') AS Nombre,
                                ISNULL(Email1, ISNULL(Email2, '')) AS Email
                                FROM cte
                                WHERE cliente = @Cliente";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        datosCliente = new clsDatosEntregaCliente
                        {
                            sDireccion = item["Direccion"].ToString(),
                            sNumeroExt = item["DireccionNumero"].ToString(),
                            sNumeroInt = item["DireccionNumeroInt"].ToString(),
                            sColonia = item["Colonia"].ToString(),
                            sCodigoPostal = item["CodigoPostal"].ToString(),
                            sPoblacion = item["Poblacion"].ToString(),
                            sEstado = item["Estado"].ToString(),
                            sEntreCalles = item["EntreCalles"].ToString(),
                            sNombreC = item["Nombre"].ToString(),
                            sCorreo = item["Email"].ToString(),
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return datosCliente;
        }

        #endregion

        #region//-634
        /// <summary>
        /// Obtener los comentarios de cancelacion venta en linea
        /// </summary> 
        /// <return>Lista de comentarios de cancelacion venta en linea</return>
        /// Developer: Emir Tapia
        /// Date: 03/04/20
        public List<string> ObtenerComentariosCancelacion()
        {
            List<string> sComentarios = new List<string>();

            SqlDataReader dr = null;
            string sQuery = string.Format("SELECT Nombre FROM tablastd WHERE tablast = 'COMENTARIOS DE CANCELACION VENTA EN LINEA'");

            using (var sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
            {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                try
                {
                    dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            sComentarios.Add(dr["Nombre"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ObtenerComentariosCancelacion", "CDetalleVenta", ex);
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
                return sComentarios;
            }
        }
        #endregion


        /// <summary>
        /// Buscar Padre Credilana(Pedido) Para Cancelarlo movimiento
        /// </summary>
        /// <param name="ID">string</param>
        /// <param name="Mov">string</param>
        /// <param name="MovID">string</param>
        /// <param name="Usuario">string</param>
        /// <param name="Sucursal">int</param>
        /// <param name="EnviarA">int</param>
        /// <param name="IDECommerce">int</param>
        /// <param name="tipomsgRef">string</param>
        /// <returns>Retorna Mensaje de que movimiento se cancelo</returns> 
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ 
        /// 864 GESSY Mejoras DIE
        public string CancelarMovPadreCredilana(string ID, string Mov, string MovID, string Usuario, int? Sucursal,
            int EnviarA, string IDECommerce, ref string tipomsgRef)
        {
            int Id = Int32.Parse(ID);

            string padre = ObtenerMovOrigen(Id);

            string MovOrigen = "";
            string PadreID = "";
            string PadreMov = "";
            string PadreMovID = "";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(
                    "SELECT VP.id as id, VP.mov as Mov, VP.MovId as MovId from Venta VH with (nolock) join Venta VP with (nolock) on VP.MovID = VH.OrigenID where VH.MovID = @MOVID and VH.Mov = 'CREDILANA' and VP.Mov = 'Pedido'",
                    ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                sqlCommand.Parameters.AddWithValue("@MOVID", MovID);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        MovOrigen = dr["id"].ToString() ?? "";
                        PadreID = dr["id"].ToString() ?? "";

                        MovOrigen = MovOrigen + " " + dr["Mov"].ToString() ?? "";
                        PadreMov = dr["Mov"].ToString() ?? "";

                        MovOrigen = MovOrigen + " " + dr["MovId"].ToString() ?? "";
                        PadreMovID = dr["MovId"].ToString() ?? "";
                    }
                }

                dr.Close();

                CancelarMovimiento(PadreID, PadreMov, PadreMovID, Usuario, Sucursal, EnviarA, IDECommerce,
                    ref tipomsgRef);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getCancelarMovPadreCredilana", "CDetalleVenta.cs", ex);
                if (ex.Source != null)
                    MessageBox.Show(ex.Message + " function getCancelarMovPadreCredilana, CDetalleVenta.cs");
            }

            return "Movimiento  " + MovOrigen + " Cancelado!!!";
        }


        #region //-1235
        public bool obtenerDetalle(int iId)
        {
            bool bTieneRegistro = false;
            try
            {
                string sQuery = "SELECT ID FROM VentaD WITH(NOLOCK) WHERE Id = @ID";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bTieneRegistro = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bTieneRegistro;
        }

        #endregion

        #region //-1220
        public float obtenerImpuesto(int iIdVenta)
        {
            float iImpuesto = 0;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT TOP 1 Impuesto1 FROM VentaD WITH(NOLOCK) where id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id",iIdVenta ) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        iImpuesto = float.Parse(item["Impuesto1"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return iImpuesto;
        }

        public float obtenerImpuestosVenta(int iIdVenta)
        {
            float iImpuesto = 0;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT TOP 1 Impuestos FROM Venta WITH(NOLOCK) where id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id",iIdVenta ) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        iImpuesto = float.Parse(item["Impuestos"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return iImpuesto;
        }
        #endregion
        #region //-997
        /// <summary>
        /// Metodo encargado de validar si el movimiento tiene un evento de rechazo
        /// </summary>
        /// <param name="iIdVenta">id del analisis</param>
        /// <returns>retorna true si tiene rechazo</returns>
        /// //-997
        public bool validarEvento(int iIdVenta)
        {
            bool bAcceso = false;
            try
            {
                string sQuery = @"
                            SELECT st.Nombre FROM TablaStd st WITH(NOLOCK)
                            INNER JOIN MovBitacora mb WITH(NOLOCK)
                            ON st.Nombre = mb.Clave
                            WHERE mb.id = @Id
                            AND Modulo = 'VTAS' AND st.Valor = 'RECHAZADO'
                            and st.TablaSt = 'EVENTOSTRANSACCIONALDINERALIA'";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }


        /// <summary>
        /// metodo encargado de insertar datos que se requieren para enviar 
        /// </summary>
        /// <param name="sCliente">cliente</param>
        /// <param name="sClave">Evento</param>
        /// <param name="iIdVenta">id de la venta</param>
        public void insertarDatosSms(string sCliente, string sClave, int iIdVenta, string sTipoSms, string sNombreCliente)
        {
            try
            {
                string sQuery = "INSERT INTO VTASDMensajeDisminucionPretencion (Cliente,Clave,IdVenta,NombreCliente, TipoMensaje ) VALUES (@Cliente, @Clave, @Id, @NombreCliente, @TipoSms)";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Clave", sClave){
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Id", iIdVenta){
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@TipoSms", sTipoSms){
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@NombreCliente", sNombreCliente){
                        SqlDbType = SqlDbType.VarChar
                    }

                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    int inserto = cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Metodo encargado de insertar el sms con disminucion de pretenciones
        /// </summary>
        /// <param name="sCliente">cuenta del cliente</param>
        /// <param name="sTelefono">Numero de telefono del cliente</param>
        /// <param name="iIdVenta">Id de la venta o el valor del campo idRegistro</param>
        /// <param name="iSms">id del sms que se enviara</param>
        public void insertarSms(string sCliente, int iIdVenta, int iSms)
        {
            string sNumero = obtenerNumeroTelefonoCliente(sCliente);
            try
            {
                string sQuery =
                    @"INSERT INTO TcAAEA00030_EnvioMensajes(IdMensaje,idRegistro, Cliente,FechaEnvio,EstatusEnvio,Tipo,IntentoRespuesta,IntentoEnvio,Telefono) VALUES(@Sms, @id,@Cliente, GETDATE(), 1, 0, 0, 0, @Telefono)";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Telefono", sNumero) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Sms", iSms) {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);
                    int inserto = cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Metodo encargado de obtener el total de la venta
        /// </summary>
        /// <param name="iIdVenta">id de la venta</param>
        /// <returns>retorna la suma de importe + impuestos de la tabla venta</returns>
        public string obtenerTotalVenta(int iIdVenta)
        {
            string sPrecio = string.Empty;
            try
            {
                string sQuery = "select precio from ventad WITH(NOLOCK)  where id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var vComando = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    vComando.Parameters.AddRange(pars);
                    using (SqlDataReader dtReader = vComando.ExecuteReader())
                    {
                        dt.Load(dtReader);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sPrecio = item["precio"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sPrecio;
        }

        /// <summary>
        /// Metodo encargado de obtener el numero de telefono del cliente
        /// </summary>
        /// <param name="sCliente">cuenta del cliente</param>
        /// <returns>retorna el numero del cliente de la tabla ctetel</returns>
        public string obtenerNumeroTelefonoCliente(string sCliente)
        {
            string sNumero = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery = "select top 1 lada + telefono AS Telefono from ctetel where cliente = @Cliente and tipo = 'Movil' order by Fecha Desc";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var vComando = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    vComando.Parameters.AddRange(pars);
                    using (SqlDataReader dtReader = vComando.ExecuteReader())
                    {
                        dt.Load(dtReader);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sNumero = item["Telefono"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sNumero;
        }

        /// <summary>
        /// Metodo encargado de obtener el ultimo evento que se le agrego a la venta
        /// </summary>
        /// <param name="iId">id de venta</param>
        /// <returns>ultimo evento insertado a la venta</returns>
        public string obtenerUltimoEvento(int iId)
        {
            string sClave = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "select top 1 clave from movbitacora where id = @id and modulo = 'vtas' order by rid desc";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iId) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        sClave = row["clave"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return sClave;
        }
        #endregion

        #region //-1030/1061
        /// <summary>
        /// Funcion para hacer update a el campo de CodigoRecomendador 
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        //  1030/1061 DIMA GESSY CODIGORECOMENDADO
        public void actualizarCodigoRecomendadorDima(string Cliente)
        {
            dt = new DataTable();

            try
            {
                string sQuery =
                    "IF EXISTS(Select top 1 CodigoRecomendador from CteEnviarA with (nolock) where Cliente = @cliente and ID = 3 and CodigoRecomendador is null) BEGIN UPDATE CEA with (rowlock) Set CEA.CodigoRecomendador = ( CASE WHEN CEA.ID in (3,76) THEN 'MA0' + SUBSTRING ( CEA.Cliente ,2 , 10 ) Else CASE WHEN CEA.ID in (7) THEN 'VIU' + SUBSTRING ( CEA.Cliente ,2 , 10 ) END END)  from CteEnviarA CEA where CEA.estatus = 'ALTA' AND CEA.Categoria in ('CREDITO MENUDEO', 'ASOCIADOS') and CEA.Cliente = @Cliente END";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", Cliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Funcion para obtener codigo recomendado
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="iCanalVenta">int</param>
        /// <returns>retorna un string con el codigoRecomendado</returns>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        //  1030/1061 DIMA GESSY CODIGORECOMENDADO
        public string obtenerCodigoRecomendado(string Cliente, int iCanalVenta)
        {
            string CodigoRecomendador = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "Select CodigoRecomendado from CteEnviarA with(nolock) where Cliente = @Cliente AND Id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", Cliente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Id", iCanalVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        CodigoRecomendador = item["CodigoRecomendado"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return CodigoRecomendador;
        }

        /// <summary>
        /// revisa si tiene Analisis de Creditos aceptados concluidos en canal 76
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <returns>retorna un true al encontrar resultados</returns>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        //  1030/1061 DIMA GESSY CODIGORECOMENDADO
        public bool tieneAnalisisCreditoAceptado76(string Cliente)
        {
            bool bExiste = true;
            try
            {
                string sQuery =
                    "Select TOP 1 id From Venta with (nolock) where mov = 'Analisis Credito' and Estatus = 'Concluido' and EnviarA = 76 and Cliente = @Cliente";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", Cliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bExiste = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExiste;
        }

        /// <summary>
        /// hace update para el campo CodigoRecomendador
        /// </summary>
        /// <param name="Clave">string</param>
        /// <param name="CanalVenta">int</param>
        /// <returns>retorna un true al encontrar resultados</returns>
        /// Developer: Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        //  1030/1061 DIMA GESSY CODIGORECOMENDADO
        public void actualizarCodigoRecomendador(string Clave, int CanalVenta)
        {
            dt = new DataTable();
            try
            {
                string sQuery =
                    "UPDATE CEA WITH (ROWLOCK) SET CodigoRecomendador = CASE WHEN UEN = 2 THEN 'VIU' + SUBSTRING(@Clave, 2, LEN(@Clave) - 1) ELSE 'MA0' + SUBSTRING(@Clave, 2, LEN(@Clave) - 1) END FROM CteEnviara CEA INNER JOIN VentasCanalMAVI VCM WITH (NOLOCK) ON VCM.ID = CEA.ID WHERE CEA.Cliente = @Clave and VCM.ID = @CanalVenta";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Clave", Clave) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@CanalVenta", CanalVenta) {
                        SqlDbType = SqlDbType.VarChar
                    },
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Metodo encargado de generar la red dima
        /// </summary>
        /// <param name="sCliente"></param>
        /// <returns></returns>
        public string generarRedDima(string sCliente, string sNombreCliente)
        {
            dt = new DataTable();
            string sRespuesta = string.Empty;
            DateTime dtFechaActual = ObtenerFechaSQL();
            string sDimaR = obtenerDimaRecomendador(sCliente);
            string sNombreRecomendador = obtenerNombreRecomendador(sDimaR);

            try
            {
                string sQuery = "SP_DM0264InsertaDimaR";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@FechaEmision", dtFechaActual) {
                        SqlDbType = SqlDbType.DateTime
                    },
                    new SqlParameter("@Cliente", sDimaR) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@ClienteNombre", sNombreRecomendador) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@DimaR", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sRespuesta = item[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sRespuesta;
        }

        public string obtenerNombreRecomendador(string sCliente)
        {
            string sClienteR = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery =
                    "select nombre from cte with(nolock) where Cliente  = @Cliente";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sClienteR = item["nombre"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sClienteR;
        }


        /// <summary>
        /// Metodo encargado de validar si existe una red dima
        /// </summary>
        /// <param name="sCliente"></param>
        /// <returns>retorna true si ya existe una red dima para el recomendado y el cliente</returns>
        public bool validarRedDima(string sCliente)
        {
            bool bEnRed = false;
            try
            {
                string sDimaR = obtenerDimaRecomendador(sCliente);

                if (string.IsNullOrEmpty(sDimaR))
                {
                    return true;
                }

                string sQuery = "select id from DM0264RedDimas where cliente = @Recomendador and ComisionN1 = @Recomendado";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Recomendador", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Recomendado", sDimaR) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEnRed = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bEnRed;
        }

        /// <summary>
        /// Metodo encargado de obtener el dima recomendador
        /// </summary>
        /// <param name="sCliente">Cliente que recomienda</param>
        /// <returns>retorna el clinte recomendador</returns>
        public string obtenerDimaRecomendador(string sCliente)
        {
            dt = new DataTable();
            string sRecomendador = string.Empty;
            try
            {
                string sQuery = @"select ea.Cliente from CteEnviarA ce WITH(NOLOCK)--p
                                INNER JOIN CteEnviarA ea WITH(NOLOCK)--s
                                ON ce.codigorecomendado = ea.CodigoRecomendador
                                WHERE ce.Cliente = @Cliente
                                and ce.ID = 76";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sRecomendador = item["Cliente"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sRecomendador;
        }

        #endregion

        #region //-ValidarPedidos

        /// <summary>
        /// Metodo Encargado de validar si otro pedido tiene el mismo origen
        /// </summary>
        /// <param name="iIdVenta"></param>
        /// <returns></returns>
        public bool pedidoDoble(int iIdVenta)
        {
            bool bPedidoDoble = false;
            dt = new DataTable();
            try
            {
                string sQuery = @"SELECT COUNT(vt.id) AS Pedidos FROM Venta v WITH(NOLOCK) --PEdido
                                JOIN Venta vd WITH(NOLOCK) --Analisis
                                ON v.Origen = vd.Mov AND v.OrigenId = vd.Movid
                                JOIN Venta vt WITH(NOLOCK)
                                ON vt.Origen = vd.Mov AND vt.OrigenId = vd.MovId
                                WHERE v.id = @Id
                                AND vt.Estatus <> 'CANCELADO'";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id",iIdVenta ) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        if (int.Parse(item["Pedidos"].ToString()) > 1)
                        {
                            bPedidoDoble = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bPedidoDoble;

        }

        public bool validarSiguientePedido(string sOrigen, string sOrigenId)
        {
            bool bExistePedidoSiguiente = false;
            try
            {
                string sQuery = @"select id from venta with(nolock) where origen = @Origen and OrigenID = @OrigenId AND Estatus = 'SINAFECTAR'";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Origen",sOrigen ) {
                        SqlDbType = SqlDbType.VarChar
                    },
                       new SqlParameter("@OrigenId",sOrigenId ) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bExistePedidoSiguiente = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExistePedidoSiguiente;
        }

        #endregion

        /// <summary>
        /// Metodo encargado de obtener el almacen de la venta actual, ya que al editar no alcanza a refrescar la venta
        /// </summary>
        /// <param name="iIdVenta">id de la venta</param>
        /// <returns>retorna un string con el almacen de la venta</returns>
        public string obtenerAlmace(int iIdVenta)
        {
            string sAlmacen = string.Empty;

            dt = new DataTable();

            try
            {
                string sQuery = @"SELECT Almacen FROM Venta WITH(NOLOCK) WHERE id = @Id";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id",iIdVenta ) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        sAlmacen = item["Almacen"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sAlmacen;
        }

        #region //-1449
        /// <summary>
        /// Metodo encargado de actualizar las existencias a facturar
        /// </summary>
        /// <param name="iIdVenta">Id de la venta para ver los articulos en el detalle</param>
        /// <param name="sAlmacen">Almacen del cual tendremos las existencias</param>
        /// <returns>retorna true si actualizo algun registro </returns>
        public bool actualizarCantidadAfectar(int iIdVenta, string sAlmacen)
        {
            bool bActualizo = false;
            dt = new DataTable();
            try
            {

                string sQuery = @"UPDATE vd
                        SET vd.CantidadA = CASE WHEN  ad.disponible >= vd.Cantidad THEN vd.Cantidad ELSE IIF(ad.disponible = 0,null,ad.disponible) END
                        FROM VentaD vd WITH(ROWLOCK)
                        JOIN ArtDisponible ad WITH(NOLOCK)
                        ON vd.Articulo = ad.Articulo
                        WHERE vd.ID = @IdVenta AND ad.almacen = @Almacen;
                        SELECT @@ROWCOUNT AS Respuesta";
                SqlParameter[] pars = new SqlParameter[2] {
                    new SqlParameter("@IdVenta", iIdVenta) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Almacen", sAlmacen) {
                        SqlDbType = SqlDbType.VarChar
                    },
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        if (int.Parse(row["Respuesta"].ToString()) > 0)
                        {
                            bActualizo = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            return bActualizo;
        }

        /// <summary>
        /// Metodo encargado de validar si un articulo requiere ser segmentado
        /// </summary>
        /// <param name="iIdVenta">id de la venta</param>
        /// <param name="sAlmacen">almacen a validar</param>
        /// <returns></returns>
        public bool validarExistencia(int iIdVenta, string sAlmacen)
        {
            bool bSegmentar = false;
            List<int> listaRespuetas = new List<int>();
            dt = new DataTable();
            try
            {

                string sQuery = @"SELECT
                                      CASE
                                        WHEN vd.Cantidad > ad.Disponible THEN 1
                                        ELSE 0
                                      END AS Aprobo
                                    FROM VentaD vd WITH (NOLOCK)
                                    JOIN ArtDisponible ad
                                      ON vd.articulo = ad.articulo
                                    WHERE vd.id = @IdVenta
                                    AND ad.almacen = @Almacen";
                SqlParameter[] pars = new SqlParameter[2] {
                    new SqlParameter("@IdVenta", iIdVenta) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Almacen", sAlmacen) {
                        SqlDbType = SqlDbType.VarChar
                    },
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        listaRespuetas.Add(int.Parse(row["Aprobo"].ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            if (listaRespuetas.Contains(1))
            {
                bSegmentar = true;
            }

            return bSegmentar;
        }

        public void realizarTraspasos(int iId, string sAlmacenOrigen, string sAlmacenDestino, string sReferencia)
        {
            dt = new DataTable();
            try
            {
                string sQuery = "SpINVOrdenesAutomaticas";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@id",iId) {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@AlmacenOrigen", sAlmacenOrigen) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@AlmacenDestino", sAlmacenDestino) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Referencia", sReferencia) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(pars);
                    cmd.CommandTimeout = 99999;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool validarTraspaso(string sReferencia)
        {
            bool result = false;
            try
            {
                string cmdText = @"SELECT
                                      iv.id
                                    FROM inv i WITH (NOLOCK) --salida traspaso
                                    JOIN inv iv WITH (NOLOCK) --Recibo Traspaso
                                      ON iv.Referencia = i.Mov + ' ' + i.MovID
                                    WHERE i.Mov = 'Salida Traspaso'
                                    AND i.Referencia = @Referencia
                                    AND iv.Estatus = 'CONCLUIDO'
                                    AND iv.Mov = 'Recibo Traspaso'";
                SqlParameter[] values = new SqlParameter[1]
                {
                    new SqlParameter("@Referencia", sReferencia)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand sqlCommand = new SqlCommand(cmdText, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddRange(values);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        result = sqlDataReader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return result;
        }

        /// <summary>
        /// Metodo encargado de validar si el movimiento requiere un traspaso
        /// </summary>
        /// <param name="iIdVenta">id de venta para obtener los articulos</param>
        /// <returns>retorna true si no requiere un traspaso de lo contrario false</returns>
        public int cantidadDisponibles(int iIdVenta)
        {
            int iTotal = 0;
            dt = new DataTable();
            try
            {
                string cmdText = @"SELECT 
                                    count(ad.disponible) as disponible
                                FROM VentaD vd WITH (NOLOCK)
                                JOIN ArtDisponible ad WITH (NOLOCK)
                                    ON vd.articulo = ad.articulo
                                WHERE vd.id = @Id
                                AND vd.Cantidad <= ad.Disponible
                                AND ad.Almacen = 'V02000'";
                SqlParameter[] values = new SqlParameter[1]
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand sqlCommand = new SqlCommand(cmdText, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddRange(values);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        dt.Load(sqlDataReader);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        iTotal = int.Parse(item["disponible"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return iTotal;
        }

        public bool validarVentaConSerie(int iIdVenta)
        {
            bool result = false;
            try
            {
                string cmdText = @"select a.Tipo from VentaD vd with(nolock)
                                   join Art a with(nolock)
                                  on vd.Articulo = a.Articulo
                                where ID = @Id
                                AND a.Tipo = 'Serie'";
                SqlParameter[] values = new SqlParameter[1]
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand sqlCommand = new SqlCommand(cmdText, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddRange(values);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        result = sqlDataReader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return result;
        }

        public bool validarExistenciasParcialidad(int iIdVenta)
        {
            bool bRequiere = false;
            try
            {
                string cmdText = @"SELECT 
                                    vd.id
                                FROM VentaD vd WITH (NOLOCK)
                                JOIN ArtDisponible ad WITH (NOLOCK)
                                    ON vd.articulo = ad.articulo
                                WHERE vd.id = @Id
                                AND ad.Disponible > 0
                                AND ad.Almacen = 'V00096'";
                SqlParameter[] values = new SqlParameter[1]
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand sqlCommand = new SqlCommand(cmdText, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddRange(values);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        bRequiere = sqlDataReader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            return bRequiere;
        }

        public void actualizarSituacion(int iIdPedido, string sMovId)
        {
            bool bRequiere = false;
            try
            {
                string cmdText = @"UPDATE v
                                SET v.Situacion = 'Forma de Entrega Parcial'
                                FROM Venta v WITH (ROWLOCK)
                                JOIN Venta vd WITH (ROWLOCK)
                                  ON v.Mov = vd.Origen
                                  AND v.MovID = vd.OrigenID
                                WHERE v.ID = @Id
                                AND v.Mov IN( 'Pedido', 'Pedido Mayoreo')
                                AND v.MovID = @MovId";
                SqlParameter[] values = new SqlParameter[2]
                {
                    new SqlParameter("@Id", iIdPedido)
                    {
                        SqlDbType = SqlDbType.Int
                    }, new SqlParameter("@MovId", sMovId)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand sqlCommand = new SqlCommand(cmdText, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddRange(values);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        bRequiere = sqlDataReader.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }
        #endregion

        #region //-1450
        /// <summary>
        /// Metodo encargado de embarcar un movimiento de forma manual
        /// </summary>
        /// <param name="sParametros">Pametros para embarcar</param>
        /// <returns>Retorna el mensaje que se mostrara al usuario</returns>
        public string embarqueManual(string[] sParametros)
        {
            string sRespuesta = string.Empty;
            string[] parametros = new string[]
            {
                "@Empresa",
                "@Modulo",
                "@ID",
                "@Mov",
                "@MovID",
                "@Estatus",
                "@DesEmbarcar"
            };
            string[] parametrosAPasar = new string[]
            {
                "MAVI",
                "VTAS",
                sParametros[(int)Enums.Embarques.ID],
                sParametros[(int)Enums.Embarques.Mov],
                sParametros[(int)Enums.Embarques.MovID],
                sParametros[(int)Enums.Embarques.Estatus],
                sParametros[4],
            };

            List<string> spEmbarqueManual = EjecutaSQLDataReader("spEmbarqueManual", parametros, parametrosAPasar, null, true);
            if (spEmbarqueManual.Count > 1 && spEmbarqueManual[1] != "")
            {
                sRespuesta = (spEmbarqueManual[1]);
            }
            else
            {
                sRespuesta = "Movimiento: " + sParametros[(int)Enums.Embarques.Mov] + " " + sParametros[(int)Enums.Embarques.MovID] + " embarcado con exito";
            }

            return sRespuesta;
        }

        /// <summary>
        /// Metodo encargado de validar si el movimiento esta embarcado
        /// </summary>
        /// <param name="iIdVenta">id del movimiento</param>
        /// <returns>retorna true si el movimiento esta embarcado de lo contrario false</returns>
        public bool validarEmbarcado(int iIdVenta)
        {
            bool bEmbarcardo = false;
            try
            {
                string sQuery = "SELECT id FROM Venta WITH(NOLOCK) WHERE id = @Id and EmbarqueEstado = 'Entregado'";

                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Id", iIdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEmbarcardo = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return bEmbarcardo;
        }

        #endregion

        #region //-1627

        /// <summary>
        /// metodo encargado de obtener el id de la credilana generada
        /// </summary>
        /// <param name="iIdPedido">id del pediod</param>
        /// <returns>retorna el id de la credilana</returns>
        public int obtenerIdGenerado(int iIdPedido)
        {
            dt = new DataTable();
            int iIdCredilana = 0;
            try
            {
                string sQuery = @"
                                SELECT
                                  v.id
                                FROM Venta v WITH (NOLOCK) --credilana
                                JOIN Venta vd WITH (NOLOCK) -- Pedido
                                  ON v.Origen = vd.Mov
                                  AND v.OrigenID = vd.MovID
                                WHERE vd.ID = @IdVenta
                                AND v.Estatus = 'CONCLUIDO'";
                SqlParameter[] pars = new SqlParameter[1] {
                    new SqlParameter("@IdVenta", iIdPedido) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        iIdCredilana = int.Parse(row["id"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
            }
            return iIdCredilana;
        }

        #endregion

        public bool EsTransferenciaSpei(string MovIdCredilana)
        {
            bool EsTransferenciaSpei = false;
            string query =
                @"SELECT
                  COUNT(1) AS EsTansferenciaSPEI
                FROM TrAAea00030_RegistroPeticiones AS RegistroPeticiones WITH(NOLOCK)
                WHERE RegistroPeticiones.ServicioSalida = 'Bancomer'
                AND RegistroPeticiones.NombreMetodoCobro = 'TRANSFERENCIA SPEI'
                AND RegistroPeticiones.IdEstatus = 10
                AND RegistroPeticiones.MovIdCredilana = @MovIdCredilana";
            SqlDataReader dr = null;
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.Add("@MovIdCredilana", MovIdCredilana);
                    cmd.CommandType = CommandType.Text;
                    using (dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            EsTransferenciaSpei = ((int.Parse(dr["EsTansferenciaSPEI"].ToString()) > 0) ? true : false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " + MethodBase.GetCurrentMethod().Name, ex);
            }

            return EsTransferenciaSpei;
        }

        public bool EsEcommerce(int IDVenta, string IDEcommerce)
        {
            bool esEcommerce = false;
            string query = @"
            SELECT ReferenciaOrdenCompra
            FROM Venta WITH (NOLOCK)
            WHERE IDEcommerce = '0'
              AND ID = @IDVenta ";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add("@IdVenta", IDVenta);
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            if (dr["ReferenciaOrdenCompra"].ToString() == IDEcommerce)
                            {
                                esEcommerce = true;
                            }
                        }
                    }
                }
                return esEcommerce;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        //1709 Validar coincidencias del cliente
        public bool ValidarCoincidenciasCliente(string IdCliente, int IdVenta)
        {
            bool Coincidencias = false;

            try
            {
                PreRastreo(IdCliente, IdVenta);
                SqlParameter[] parametros = new SqlParameter[] {
                    new SqlParameter("@opc", "ObtenerCoincidencias") {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente ", IdCliente) {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@IdVenta ", IdVenta) {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (var cmd = new SqlCommand("SPCREDICoincidencias", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Coincidencias = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return Coincidencias;
        }

        //1709 Guardar evento coincidencias en Analisis o Solicitud
        public void guardarEvento(bool ClienteCoincidencias, string[] Parametros)
        {
            EventoController EventoC = new EventoController();
            EventoC.InsertaEvento(getModeloEventoNuevo(ClienteCoincidencias, Parametros));
        }

        //1709 Crea el modelo para el Evento coincidencias
        private ModelAgregaEvento getModeloEventoNuevo(bool ClienteCoincidencias, string[] Parametros)
        {
            ModelAgregaEvento eventoNuevo = new ModelAgregaEvento();
            sqlHelper sqlH = new sqlHelper();
            AgenteController agente = new AgenteController();

            try
            {
                eventoNuevo.agente = agente.datosAgente(ClaseEstatica.Usuario.usuario).Clave ?? "";
                eventoNuevo.clave = (ClienteCoincidencias ? "MEN07005" : "MEN07006");
                eventoNuevo.modulo = "VTAS";
                eventoNuevo.idVenta = int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]);
                eventoNuevo.fecha = sqlH.getFechaActualServidor().ToString("yyyy/MM/dd HH:mm");
                eventoNuevo.evento = "Rastreo automático";
                eventoNuevo.sucursal = int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.Sucursal]);
#if PRODUCCION
                eventoNuevo.usuario = "CREDI00993";
#elif CUBOS
                eventoNuevo.usuario = "CREDI00923";
#elif PROSERVER
                eventoNuevo.usuario = "CREDI00923";
#endif
                eventoNuevo.tipo = "Comentario";
                eventoNuevo.estuatus = Parametros[(int)Enums.ParametrosDetallesVenta.Estatus];
                eventoNuevo.situacion = String.Empty;
                eventoNuevo.TipoEvento = "EVENTO";
                eventoNuevo.mov = Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                eventoNuevo.cliente = Parametros[(int)Enums.ParametrosDetallesVenta.Cliente];
                eventoNuevo.citaFecha = DateTime.Now;
                eventoNuevo.citaHora = "00:00 am  - 00:00 am";

            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            return eventoNuevo;
        }

        //1709 Valida y graba las coincidencias del cliente
        private void PreRastreo(string IdCliente, int IdVenta)
        {
            Pruebas.Controller.CoincidenciasController CoincidenciasC = new Pruebas.Controller.CoincidenciasController();

            CoincidenciasC.BuscarCoincidencias(
               IdCliente
               , IdVenta
               , ClaseEstatica.Usuario.usuario);
        }

        //1709 Valida si la venta es Solicitud o Analisis y aún no tiene el evento Coincidencias
        public bool ValidarMovimientoCoincidencias(int IDVenta)
        {
            bool resultado = false;
            string query = string.Empty;
            try
            {
                query = @"SELECT Id FROM Venta WITH(NOLOCK) WHERE Mov in('Solicitud Credito','Analisis Credito') and Id = @IdVenta";
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add(
                        new SqlParameter("@IdVenta", IDVenta)
                        {
                            SqlDbType = SqlDbType.Int
                        });
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            resultado = true;
                        }
                    }
                }

                if (resultado)
                {
                    resultado = false;
                    query = @"
                            SELECT
                                mb.id
                            FROM MovBitacora mb WITH(NOLOCK)
                            LEFT JOIN MAVIClaveSeguimiento cg WITH(NOLOCK)
                              ON cg.Clave = mb.Clave
                            LEFT JOIN CREDICConfiguracionSTP st WITH(NOLOCK)
                              on st.TipoCOnfiguracion = 'CALIFICACIONESUC'
                              and mb.clave = st.clave
                            WHERE 
							    mb.Clave IN ('MEN07006', 'MEN07005')
							    AND mb.id = @IdVenta";
                    using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                    {
                        cmd.Parameters.Add(
                        new SqlParameter("@IdVenta", IDVenta)
                        {
                            SqlDbType = SqlDbType.Int
                        });
                        cmd.CommandType = CommandType.Text;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                resultado = true;
                            }
                        }
                    }
                }
                return resultado;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        //1832
        public bool EsArticuloPequeno(int Sucursal, string Articulo, int Disponible)
        {
            bool esArticuloPequeno = false;

            try
            {
                SqlParameter[] parametros = new SqlParameter[] {
                    new SqlParameter("@Sucursal", Sucursal) {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Articulo", Articulo) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand("SpVTASValidarArticuloPequeno", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt = new DataTable();
                        dt.Load(dr);
                        if (dt.Rows.Count == 1)
                        {
                            if (!bool.Parse(dt.Rows[0]["EnSucursal"].ToString()))
                            {
                                if (bool.Parse(dt.Rows[0]["EnCatalogo"].ToString()))
                                {
                                    if (Disponible > 0)
                                    {
                                        esArticuloPequeno = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return esArticuloPequeno;
        }


        #region //-1592

        public bool validarCuentaClabe(string sCliente)
        {
            bool bCuentaClabeValida = false;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT dbo.FnVTASValidarCuentaCliente(@Cliente)  AS Respuesta";
                SqlParameter[] pars = new SqlParameter[] {
                    new SqlParameter("@Cliente", sCliente) {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (var cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        bCuentaClabeValida = bool.Parse(item["Respuesta"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return bCuentaClabeValida;
        }

        public bool obtenerEstatusStp(int iId)
        {
            bool res = false;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("SELECT CONVERT(BIT,TransferenciaSTP) AS pagodie FROM VENTA WITH(NOLOCK) WHERE ID = {0}", iId);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        res = dr.GetBoolean(0);
                    }
                }

            }
            catch (Exception ex)
            {

                DM0312_ErrorLog.RegistraError("obtenerEstatusDie", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: obtenerEstatusDie class: CDetalleVenta.cs", "Error!");
            }

            finally { if (dr != null) dr.Close(); }


            return res;

        }


        public int realizarDispersion(int iIdVenta)
        {
            int iActualizo = 0;
            try
            {
                string sClaveRastreo = generarClaveRastreo();
                int iReferenciaNumerica = GenerarReferenciaNumerica();
                using (SqlCommand cmd = new SqlCommand("SpVTASGuardarDispersionStp", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@IdVenta", SqlDbType.Int) { Value = iIdVenta },
                        new SqlParameter("@Aplicacion", SqlDbType.VarChar) { Value = "PuntoDeVenta" },
                        new SqlParameter("@ClaveRastreo", SqlDbType.VarChar) { Value = sClaveRastreo},
                        new SqlParameter("@ReferenciaNumerica", SqlDbType.Int) { Value = iReferenciaNumerica },
                        new SqlParameter("@Usuario", SqlDbType.VarChar) { Value = ClaseEstatica.Usuario.usuario }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                iActualizo = int.Parse(dr[0].ToString());
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("cancelarVale", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return iActualizo;
        }

        public string generarClaveRastreo()
        {
            var seed = Environment.TickCount;
            var random = new Random(seed);
            string cadenaAleatoria = "";
            for (int i = 0; i <= 5; i++)
            {
                cadenaAleatoria += random.Next(0, 9).ToString();
            }
            return "PuntoVenta00" + cadenaAleatoria;
        }

        public int GenerarReferenciaNumerica()
        {
            var seed = Environment.TickCount;
            var random = new Random(seed);
            string cadenaAleatoria = "";
            for (int i = 0; i <= 5; i++)
            {
                cadenaAleatoria += random.Next(0, 9).ToString();
            }
            return int.Parse(cadenaAleatoria);
        }
        #endregion

        #region //2164
        public int VerificaEvento(int id, string evento)
        {
            int valor = 0;
            string query = @"SELECT Count( mb.Clave) as Cantidad ";
            query += "FROM MovBitacora mb WITH (NOLOCK) ";
            query += "LEFT JOIN MAVIClaveSeguimiento cg WITH (NOLOCK) ON cg.Clave = mb.Clave ";
            query += "WHERE mb.id = @Id and mb.Clave = @Evento ";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add(new SqlParameter("@Id", id) { SqlDbType = SqlDbType.Int });
                    cmd.Parameters.Add(new SqlParameter("@Evento", evento) { SqlDbType = SqlDbType.VarChar });
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            valor = Convert.ToInt32(dr["Cantidad"].ToString());
                        }
                    }
                }

            }

            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);

            }

            return valor;
        }

        #endregion

        public void SolicitarTelefonoCliente(string[] Parametros)
        {
            try
            {
                var fmrSolicitudtelefono = new DM0312SolicitudTelefonoCliente(parametros: Parametros);
                fmrSolicitudtelefono.ShowDialog();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SolicitarTelefonoCliente", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }


        public bool validarCancelarPendiente(int iIdVenta)
        {

            bool res = false;
            string query = string.Empty;
            SqlDataReader dr = null;
            try
            {
                query = string.Format("select id from ventad with(nolock) where id = {0} and CantidadA > 0", iIdVenta);

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };

                dr = sqlCommand.ExecuteReader();

                res = dr.HasRows;

            }
            catch (Exception ex)
            {

                DM0312_ErrorLog.RegistraError("obtenerEstatusDie", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + "function: obtenerEstatusDie class: CDetalleVenta.cs", "Error!");
            }

            finally { if (dr != null) dr.Close(); }


            return res;
        }

        /// <summary>
        /// Esta función valida que la venta que se haya seleccionado sea una credilana o prestamo personal
        /// y que ya este concluida la venta.
        /// </summary>
        /// <param name="VentasSeleccionadas"></param>
        /// <returns>bool</returns>
        /// Desarrollador: Moises Camacho
        public bool validarCancelacionMovimiento(int idVenta)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("SpVTASValidarCancelacionDispersion", ClaseEstatica.ConexionEstatica))
                {
                    bool cancelar = true;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", idVenta);

                    var response = command.ExecuteReader();
                    while(response.Read()) cancelar = response["VALIDADO"].ToString().Contains("1");
                    return cancelar;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                return true;
            }
        }
    }
}
