﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    //Autor: Rodolfo Sanchez
    //Modulo: Investigacion Telefonica
    //Fecha: 30/08/2017
    public class DM0312_CContactos
    {
        public DM0312_MCteContacto GetContactoSeleccionado_(string cuenta, int idContacto)
        {
            DM0312_MCteContacto model = new DM0312_MCteContacto();

            SqlDataReader dr = null;
            SqlCommand cmd = new SqlCommand();

            string query = string.Empty;
            try
            {
                query = string.Format(
                    "SELECT DISTINCT C.Cliente,CT.Nombre,(SELECT TOP 1 Nombre+' '+ApellidoPaterno+' '+ApellidoMaterno FROM CteCto WITH(NOLOCK) WHERE Cliente = C.Cliente AND Tipo = 'CONYUGE')" +
                    " AS Cónyuge,C.Nombre+' '+C.ApellidoPaterno+' '+C.ApellidoMaterno AS Contacto," +
                    " CASE WHEN C.LadaMAVI IS NULL OR C.LadaMAVI = '' THEN C.Telefonos ELSE C.LadaMAVI+' '+C.Telefonos END AS Telefonos," +
                    " D.Direccion+' '+D.MaviNumero AS Direccion, D.Colonia, D.Poblacion, E.Empresa, CONVERT(VARCHAR(50),E.Funciones) AS Funciones," +
                    " C.BeneF AS CteFinal" +
                    " FROM CteCto C WITH(NOLOCK) INNER JOIN Cte CT ON C.Cliente = CT.Cliente" +
                    " LEFT JOIN CteCtoDireccion D ON C.Cliente = D.Cliente AND C.ID = D.ID AND D.Tipo = 'Particular'" +
                    " LEFT JOIN MaviCteCtoEmpleo E ON E.Cliente = C.Cliente AND E.ID = C.ID " +
                    " WHERE 1=1    AND C.Cliente = '{0}'    AND C.ID ={1}", cuenta, idContacto);

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        model.Cuenta = dr[0].ToString();
                        model.NombreCliente = dr[1].ToString();
                        model.Conyuge = dr[2].ToString();
                        model.Contacto = dr[3].ToString();
                        model.Telefonos = dr[4].ToString();
                        model.Direccion = dr[5].ToString();
                        model.Colonia = dr[6].ToString();
                        model.Poblacion = dr[7].ToString();
                        model.Empresa = dr[8].ToString();
                        model.Funciones = dr[9].ToString();
                        model.cteFinal = dr[10].ToString();
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                dr.Close();
            }

            return model;
        }

        public string GetAgente(string nomina)
        {
            string res = string.Empty;
            SqlDataReader dr = null;
            SqlCommand cmd = new SqlCommand();

            string query = string.Empty;
            try
            {
                query = string.Format(
                    "select ApellidoPaterno +' ' + ApellidoMaterno + ' ' + Nombre as Nombre from Personal With(Nolock) where Personal='{0}'",
                    nomina);

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = dr[0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public Dictionary<int, string> GetParentesco()
        {
            Dictionary<int, string> res = new Dictionary<int, string>();
            SqlDataReader dr = null;
            SqlCommand cmd = new SqlCommand();

            string query = string.Empty;
            try
            {
                query = string.Format("SELECT DISTINCT Parentesco FROM PARENTESCO WITH(NOLOCK)", "");

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    int i = 0;
                    while (dr.Read())
                    {
                        string p = dr[0].ToString();
                        res.Add(i, p);
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        #region DM0312_MRefLaboral

        public DM0312_MRefLaboral _ExecRefLaboral(DM0312_MRefLaboral model, int op)
        {
            DM0312_MRefLaboral model_ = new DM0312_MRefLaboral();

            SqlDataReader dr = null;


            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASGetRefLaboral", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PuestoLaboral", model.PuestoLaboral ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@PuestoLaboral", SqlDbType.VarChar).Value = model.PuestoLaboral;
                cmd.Parameters.AddWithValue("@Departamento", model.Departamento ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Departamento", SqlDbType.VarChar).Value = model.Departamento;
                cmd.Parameters.AddWithValue("@Antiguedad", model.Antiguedad ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Antiguedad", SqlDbType.VarChar).Value = model.Antiguedad;
                cmd.Parameters.AddWithValue("@Nomina", model.Nomina ?? DBNull.Value.ToString());
                ////cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = model.Nomina;
                cmd.Parameters.AddWithValue("@Domicilio", model.Domicilio ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Domicilio", SqlDbType.VarChar).Value = model.Domicilio;
                cmd.Parameters.AddWithValue("@IngresoMens", model.IngresoMens ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@IngresoMens", SqlDbType.VarChar).Value = model.IngresoMens;
                cmd.Parameters.AddWithValue("@Comprobable", model.Comprobable ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Comprobable", SqlDbType.VarChar).Value = model.Comprobable;
                cmd.Parameters.AddWithValue("@Observaciones", model.Observaciones ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Observaciones", SqlDbType.VarChar).Value = model.Observaciones;
                cmd.Parameters.AddWithValue("@DomicilioPer", model.DomicilioPer ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@DomicilioPer", SqlDbType.VarChar).Value = model.DomicilioPer;
                cmd.Parameters.AddWithValue("@PlanEmpresa", model.PlanEmpresa ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@PlanEmpresa", SqlDbType.VarChar).Value = model.PlanEmpresa;
                cmd.Parameters.AddWithValue("@FormaRecom", model.FormaRecom ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@FormaRecom", SqlDbType.VarChar).Value = model.FormaRecom;
                cmd.Parameters.AddWithValue("@NombreInfo", model.NombreInfo ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@NombreInfo", SqlDbType.VarChar).Value = model.NombreInfo;
                cmd.Parameters.AddWithValue("@PuestoInfo", model.PuestoInfo ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@PuestoInfo", SqlDbType.VarChar).Value = model.PuestoInfo;
                cmd.Parameters.AddWithValue("@Comentarios", model.Comentarios ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Comentarios", SqlDbType.VarChar).Value = model.Comentarios;
                cmd.Parameters.Add("@IdContacto", SqlDbType.Int).Value = model.IDContacto;
                cmd.Parameters.Add("@Cuenta", SqlDbType.VarChar).Value = model.Cuenta;
                cmd.Parameters.Add("@IDMovimiento", SqlDbType.Int).Value = model.IDMovimiento;
                cmd.Parameters.Add("@Movimiento", SqlDbType.VarChar).Value = model.Movimiento;
                cmd.Parameters.Add("@Consecutivo", SqlDbType.VarChar).Value = model.Consecutivo;
                cmd.Parameters.Add("@Op", SqlDbType.Int).Value = op;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        model_.Cuenta = dr[0].ToString();
                        model_.IDContacto = Convert.ToInt32(dr[1].ToString());
                        model_.IDMovimiento = Convert.ToInt32(dr[2].ToString());
                        model_.Movimiento = dr[3].ToString();
                        model_.Consecutivo = dr[4].ToString();
                        model_.PuestoLaboral = dr[5].ToString();
                        model_.Departamento = dr[6].ToString();
                        model_.Antiguedad = dr[7].ToString();
                        model_.Domicilio = dr[8].ToString();
                        model_.IngresoMens = dr[9].ToString();
                        model_.Comprobable = dr[10].ToString();
                        model_.Observaciones = dr[11].ToString();
                        model_.DomicilioPer = dr[12].ToString();
                        model_.PlanEmpresa = dr[13].ToString();
                        model_.FormaRecom = dr[14].ToString();
                        model_.NombreInfo = dr[15].ToString();
                        model_.PuestoInfo = dr[16].ToString();
                        model_.Comentarios = dr[17].ToString();
                        model_.Nomina = dr[18].ToString();
                        model_.Fecha = dr[19].ToString(); //Convert.ToDateTime(dr[18].ToString());
                        model_.Hora = dr[20].ToString();
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            finally
            {
                dr.Close();
            }

            return model_;
        }

        public DM0312_MRefLaboral _SelectRefLaboral(int idContacto)
        {
            DM0312_MRefLaboral Res = new DM0312_MRefLaboral();
            DM0312_MRefLaboral item = new DM0312_MRefLaboral();
            item.IDContacto = idContacto;
            item.IDMovimiento = 1;
            item.Movimiento = DBNull.Value.ToString();
            item.Consecutivo = DBNull.Value.ToString();
            item.PuestoLaboral = DBNull.Value.ToString();
            item.Departamento = DBNull.Value.ToString();
            item.Antiguedad = DBNull.Value.ToString();
            item.Domicilio = DBNull.Value.ToString();
            item.IngresoMens = DBNull.Value.ToString();
            item.Comprobable = DBNull.Value.ToString();
            item.Observaciones = DBNull.Value.ToString();
            item.DomicilioPer = DBNull.Value.ToString();
            item.PlanEmpresa = DBNull.Value.ToString();
            item.FormaRecom = DBNull.Value.ToString();
            item.NombreInfo = DBNull.Value.ToString();
            item.PuestoInfo = DBNull.Value.ToString();
            item.Comentarios = DBNull.Value.ToString();
            item.Nomina = DBNull.Value.ToString();
            item.Cuenta = DBNull.Value.ToString();

            Res = _ExecRefLaboral(item, 1);

            return Res;
        }

        public DM0312_MRefLaboral _UpdateInsertRefLaboral(DM0312_MRefLaboral M_)
        {
            DM0312_MRefLaboral Res = new DM0312_MRefLaboral();
            try
            {
                _ExecRefLaboral(M_, 2);

                Res = _SelectRefLaboral(M_.IDContacto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            return Res;
        }

        #endregion

        #region DM0312_MRefPersonal

        public DM0312_MRefPersonal _ExecRefPersonal(DM0312_MRefPersonal model, int op)
        {
            DM0312_MRefPersonal model_ = new DM0312_MRefPersonal();

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASGetRefPersonal", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@nombre", model.Nombre ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@nombre", SqlDbType.VarChar).Value = model.Nombre;
                cmd.Parameters.AddWithValue("@TiempoCono", model.TiempoCono ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@TiempoCono", SqlDbType.VarChar).Value = model.TiempoCono;
                cmd.Parameters.AddWithValue("@Parentesco", model.Parentesco ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Parentesco", SqlDbType.VarChar).Value = model.Parentesco;
                cmd.Parameters.AddWithValue("@ViveEn", model.ViveEn ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ViveEn", SqlDbType.VarChar).Value = model.ViveEn;
                cmd.Parameters.AddWithValue("@ViveDesde", model.ViveDesde ?? DBNull.Value.ToString());
                cmd.Parameters.AddWithValue("@ViveDe", model.ViveDe ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ViveDe", SqlDbType.VarChar).Value = model.ViveDe;
                cmd.Parameters.AddWithValue("@Nomina", model.Nomina ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Nomina", SqlDbType.VarChar).Value = model.Nomina;
                cmd.Parameters.AddWithValue("@ViveMas", model.ViveMas ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ViveMas", SqlDbType.VarChar).Value = model.ViveMas;
                cmd.Parameters.AddWithValue("@Quienes", model.Quienes ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Quienes", SqlDbType.VarChar).Value = model.Quienes;
                cmd.Parameters.AddWithValue("@ClienteDedica", model.ClienteDedica ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ClienteDedica", SqlDbType.VarChar).Value = model.ClienteDedica;
                cmd.Parameters.AddWithValue("@ConyugeDedica", model.ConyugeDedica ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ConyugeDedica", SqlDbType.VarChar).Value = model.ConyugeDedica;
                cmd.Parameters.AddWithValue("@ProblemasPago", model.ProblemasPago ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@ProblemasPago", SqlDbType.VarChar).Value = model.ProblemasPago;
                cmd.Parameters.AddWithValue("@CualesPro", model.CualesPro ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@CualesPro", SqlDbType.VarChar).Value = model.CualesPro;
                cmd.Parameters.Add("@IdContacto", SqlDbType.Int).Value = model.IDContacto;
                cmd.Parameters.AddWithValue("@Cuenta", model.Cuenta ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Cuenta", SqlDbType.VarChar).Value = model.Cuenta;
                cmd.Parameters.Add("@IDMovimiento", SqlDbType.Int).Value = model.IDMovimiento;
                cmd.Parameters.AddWithValue("@Movimiento", model.Movimiento ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Movimiento", SqlDbType.VarChar).Value = model.Movimiento;
                cmd.Parameters.AddWithValue("@Consecutivo", model.Consecutivo ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Consecutivo", SqlDbType.VarChar).Value = model.Consecutivo;
                cmd.Parameters.Add("@Op", SqlDbType.Int).Value = op;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        model_.IDContacto = Convert.ToInt32(dr[0].ToString());
                        model_.IDMovimiento = Convert.ToInt32(dr[1].ToString());
                        model_.Movimiento = dr[2].ToString();
                        model_.Consecutivo = dr[3].ToString();
                        model_.Nombre = dr[4].ToString();
                        model_.TiempoCono = dr[5].ToString();
                        model_.Parentesco = dr[6].ToString();
                        model_.ViveEn = dr[7].ToString();
                        model_.ViveDesde = dr[8].ToString();
                        model_.ViveDe = dr[9].ToString();
                        model_.Nomina = dr[10].ToString();
                        model_.ViveMas = dr[11].ToString();
                        model_.Quienes = dr[12].ToString();
                        model_.ClienteDedica = dr[13].ToString();
                        model_.ConyugeDedica = dr[14].ToString();
                        model_.ProblemasPago = dr[15].ToString();
                        model_.CualesPro = dr[16].ToString();
                        model_.Fecha = dr[17].ToString(); //Convert.ToDateTime(dr[17].ToString());
                        model_.Hora = dr[18].ToString();
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            finally
            {
                dr.Close();
            }

            return model_;
        }

        public DM0312_MRefPersonal _SelectRefPersonal(int idContacto)
        {
            DM0312_MRefPersonal Res = new DM0312_MRefPersonal();
            DM0312_MRefPersonal item = new DM0312_MRefPersonal();
            item.IDContacto = idContacto;
            item.IDMovimiento = 1;
            item.Movimiento = DBNull.Value.ToString();
            item.Consecutivo = DBNull.Value.ToString();
            item.Nombre = DBNull.Value.ToString();
            item.TiempoCono = DBNull.Value.ToString();
            item.Parentesco = DBNull.Value.ToString();
            item.ViveEn = DBNull.Value.ToString();
            item.ViveDesde = DBNull.Value.ToString();
            item.ViveDe = DBNull.Value.ToString();
            item.ViveMas = DBNull.Value.ToString();
            item.Quienes = DBNull.Value.ToString();
            item.ClienteDedica = DBNull.Value.ToString();
            item.ConyugeDedica = DBNull.Value.ToString();
            item.ProblemasPago = DBNull.Value.ToString();
            item.CualesPro = DBNull.Value.ToString();
            item.Nomina = DBNull.Value.ToString();
            item.Cuenta = DBNull.Value.ToString();

            Res = _ExecRefPersonal(item, 1);

            return Res;
        }

        public DM0312_MRefPersonal _UpdateInsertRefPersonal(DM0312_MRefPersonal M_)
        {
            DM0312_MRefPersonal Res = new DM0312_MRefPersonal();
            try
            {
                _ExecRefPersonal(M_, 2);


                Res = _SelectRefPersonal(M_.IDContacto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!!");
            }

            return Res;
        }

        #endregion

        #region Beneficiario final

        public DM0312_MExploradorVenta getUltimoMovimiento(string cteFinal)
        {
            SqlDataReader dr = null;
            SqlCommand cmd = new SqlCommand();
            string query = string.Empty;
            DM0312_MExploradorVenta mov = new DM0312_MExploradorVenta();
            try
            {
                query = string.Format(
                    "SELECT TOP 1 Mov, MovID FROM Venta WITH(NOLOCK)" +
                    " WHERE ctefinal = '{0}' and Mov IN('FACTURA','CREDILANA') ORDER BY FechaEmision DESC", cteFinal);

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        mov.Mov = dr[0].ToString();
                        mov.MovId = dr[1].ToString();
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return mov;
        }

        public bool _ExecReferenciaBeneficiarioFinal(MBeneficiarioFinal mBeneficiarioFinal)
        {
            bool respuesta = false;
            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIRefBeneficiarioFinal", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Nombre", mBeneficiarioFinal.nombre ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@ProductoOPrestamo",
                        mBeneficiarioFinal.productoOPrestamo ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@ProductoOPrestamoMovID",
                        mBeneficiarioFinal.productoOPrestamoMovID ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@Parentesco",
                        mBeneficiarioFinal.parentesco ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@DondeConoceDistribuidor",
                        mBeneficiarioFinal.dondeConoceDistribuidor ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@CanjeoValeConNIP", mBeneficiarioFinal.canjeoValeConNIP);
                    cmd.Parameters.AddWithValue("@QuienTecleoNIPEnTienda",
                        mBeneficiarioFinal.quienTecleoNIPEnTienda ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@Agente", mBeneficiarioFinal.agente ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@ParaQuienFueLaCompra",
                        mBeneficiarioFinal.paraQuienFueLaCompra ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@DondeHaraPagos",
                        mBeneficiarioFinal.dondeHaraPagos ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@DomicilioActual",
                        mBeneficiarioFinal.domicilioActual ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@Observaciones",
                        mBeneficiarioFinal.observaciones ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@AtencionEnTienda",
                        mBeneficiarioFinal.atencionEnTienda ?? DBNull.Value.ToString());
                    cmd.Parameters.Add("@IdCteCto", SqlDbType.Int).Value = mBeneficiarioFinal.idCteCto;
                    cmd.Parameters.AddWithValue("@Cuenta", mBeneficiarioFinal.cuenta ?? DBNull.Value.ToString());
                    cmd.Parameters.Add("@IdVenta", SqlDbType.Int).Value = mBeneficiarioFinal.idVenta;
                    cmd.Parameters.AddWithValue("@Mov", mBeneficiarioFinal.mov ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@MovID", mBeneficiarioFinal.movID ?? DBNull.Value.ToString());

                    cmd.ExecuteReader();
                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return respuesta;
        }

        public MBeneficiarioFinal _SelectReferenciaBeneficiarioFinal(int idContacto)
        {
            MBeneficiarioFinal beneficiarioFinalSet = new MBeneficiarioFinal();
            string query = @"SELECT TOP 1 IdCteCto, IdVenta, Mov, MovID, Nombre, ProductoOPrestamo, Parentesco,
            DondeConoceDistribuidor, CanjeoValeConNIP, QuienTecleoNIPEnTienda, Agente, ParaQuienFueLaCompra,
            DondeHaraPagos, DomicilioActual, Observaciones, AtencionEnTienda, FechaRegistro
            FROM CREDIDRefBeneficiarioFinal WITH (NOLOCK) WHERE IdCteCto = @IdCteCto";

            using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                cmd.Parameters.AddWithValue("@IdCteCto", idContacto);

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        beneficiarioFinalSet.idCteCto = Convert.ToInt32(dr[0]);
                        beneficiarioFinalSet.idVenta = Convert.ToInt32(dr[1]);
                        beneficiarioFinalSet.mov = dr[2].ToString();
                        beneficiarioFinalSet.movID = dr[3].ToString();
                        beneficiarioFinalSet.nombre = dr[4].ToString();
                        beneficiarioFinalSet.productoOPrestamo = dr[5].ToString();
                        beneficiarioFinalSet.dondeConoceDistribuidor = dr[7].ToString();
                        beneficiarioFinalSet.quienTecleoNIPEnTienda = dr[9].ToString();
                        beneficiarioFinalSet.paraQuienFueLaCompra = dr[11].ToString();
                        beneficiarioFinalSet.dondeHaraPagos = dr[12].ToString();
                        beneficiarioFinalSet.atencionEnTienda = dr[15].ToString();
                        beneficiarioFinalSet.domicilioActual = dr[13].ToString();
                        beneficiarioFinalSet.observaciones = dr[14].ToString();
                        beneficiarioFinalSet.agente = dr[10].ToString();
                        beneficiarioFinalSet.parentesco = dr[6].ToString();
                        beneficiarioFinalSet.canjeoValeConNIP = Convert.ToBoolean(dr[8]);
                    }
                }
            }

            return beneficiarioFinalSet;
        }

        #endregion
    }
}