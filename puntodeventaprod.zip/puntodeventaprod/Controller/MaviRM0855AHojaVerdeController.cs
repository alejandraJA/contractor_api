﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class MaviRM0855AHojaVerdeController
    {
        public string obtenerBanco(string sCliente)
        {
            DataTable dt = new DataTable();
            string sbanco = string.Empty;

            try
            {
                string sQuery =
                    "select ISNULL(Banco,'') AS Banco from CREDICDatosSolicitudWebDineraliaTmp WITH(NOLOCK) WHERE Cliente = @Cliente";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sbanco = item["Banco"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sbanco;
        }

        public MaviRM0855AHojaVerde GetReport(string codCliente, string sBanco, int iCanalVenta)
        {
            List<MaviRM0855AHojaVerde> Lista = new List<MaviRM0855AHojaVerde>();
            MaviRM0855AHojaVerde item;
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_MaviRM0855AHojaVerde", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = codCliente;
                cmd.CommandTimeout = 600;
                dr = cmd.ExecuteReader();

                DM0312_MRegistroCte EmptyModel = new DM0312_MRegistroCte();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MaviRM0855AHojaVerde model = new MaviRM0855AHojaVerde();
                        //cliente
                        model.C_clienteNom = dr["Nombre"].ToString();

                        if (dr["FechaHoy"].ToString() == null || dr["FechaHoy"].ToString() == string.Empty)
                        {
                            model.FechaHoy = string.Empty;
                        }
                        else
                        {
                            char delimiter = '/';

                            string Fecha = Convert.ToDateTime(dr["FechaHoy"]).ToString("dd/MMMM/yyyy");

                            int Month = Convert.ToDateTime(dr["FechaHoy"]).Month;

                            string Month_ = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);

                            string Month_Mayus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Month_);

                            string[] substrings = Fecha.Split(delimiter);

                            model.FechaHoy = substrings[0] + "/" + Month_Mayus + "/" + substrings[2];
                        }

                        //DateTime? dt = model.FechaHoy;
                        //string s = String.Format("{0:dd/MMMMMM/yyyy}", dt);
                        model.C_clienteCod = codCliente;
                        model.C_edad = dr["Edad"].ToString();

                        if (dr["FechaNacimiento"].ToString() == null ||
                            dr["FechaNacimiento"].ToString() == string.Empty)
                        {
                            model.C_FechaNacimiento = string.Empty;
                        }
                        else
                        {
                            //model.C_FechaNacimiento = Convert.ToDateTime(dr["FechaNacimiento"].ToString());
                            char delimiter = '/';

                            string Fecha = Convert.ToDateTime(dr["FechaNacimiento"]).ToString("dd/MMMM/yyyy");

                            int Month = Convert.ToDateTime(dr["FechaNacimiento"]).Month;

                            string Month_ = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);

                            string Month_Mayus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Month_);

                            string[] substrings = Fecha.Split(delimiter);

                            model.C_FechaNacimiento = substrings[0] + "/" + Month_Mayus + "/" + substrings[2];
                        }

                        model.C_EdoCivil = dr["EdoCivil"].ToString();
                        model.C_Domicilio = dr["Domicilio"].ToString();
                        model.C_Antiguedad = dr["AntigCte"].ToString();
                        model.C_Cruces = dr["EntreCallesCte"].ToString();
                        model.C_Colonia = dr["ColoniaCte"].ToString();
                        model.C_cp = dr["CodigoPostalCte"].ToString();
                        model.C_Telefono1 = dr["TelefonoCte"].ToString();
                        model.C_Telefono2 = dr["TelefonoCte2"].ToString();
                        model.C_Municipio = dr["Poblacion"].ToString();
                        model.C_DomAnterior = dr["DomicilioAnt"].ToString();
                        model.C_Colonia2 = dr["ColoniaAnt"].ToString();
                        model.C_cp2 = dr["CodigoPostalAnt"].ToString();
                        model.C_Vivede = dr["ViveEnCalidadCte"].ToString();
                        model.C_Recomendado = dr["Recomendado"].ToString();
                        model.C_DireccionRecom = dr["DireccionRecom"].ToString();
                        model.C_Parentezco = dr["Parentesco"].ToString();
                        model.C_Observaciones = dr["TextoAMostrar"].ToString();
                        model.Conyuge = dr["NombreCyge"].ToString();
                        model.Con_edad = dr["EdadCyge"].ToString();

                        if (dr["FechaNaCyge"].ToString() == null || dr["FechaNaCyge"].ToString() == string.Empty)
                        {
                            model.Con_FechaNacimiento = string.Empty;
                        }
                        else
                        {
                            //model.Con_FechaNacimiento = Convert.ToDateTime(dr["FechaNaCyge"].ToString());
                            char delimiter = '/';

                            string Fecha = Convert.ToDateTime(dr["FechaNaCyge"]).ToString("dd/MMMM/yyyy");

                            int Month = Convert.ToDateTime(dr["FechaNaCyge"]).Month;

                            string Month_ = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);

                            string Month_Mayus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Month_);

                            string[] substrings = Fecha.Split(delimiter);

                            model.Con_FechaNacimiento = substrings[0] + "/" + Month_Mayus + "/" + substrings[2];
                        }

                        //EmpleoCliente
                        model.EC_empresa = dr["EEmpresa"].ToString();
                        model.EC_Funciones = dr["EFunciones"].ToString().Length > 45
                            ? dr["EFunciones"].ToString().Substring(0, 45)
                            : dr["EFunciones"].ToString();
                        model.EC_Departamento = dr["EtipoNegocio"].ToString().Length > 35
                            ? dr["EtipoNegocio"].ToString().Substring(0, 35)
                            : dr["EtipoNegocio"].ToString();
                        model.EC_JefeIn = dr["EJefeInmediato"].ToString();
                        model.EC_PuestoJefe = dr["EPuestoJefeInmediato"].ToString();
                        model.EC_Antig = dr["AntigEmpl"].ToString();

                        //if (dr["Eingresos"].ToString() == string.Empty || dr["Eingresos"].ToString() == null)
                        //    model.EC_Ingresos = 0;
                        //else
                        model.EC_Ingresos = dr["Eingresos"].ToString().Length > 0
                            ? dr["Eingresos"].ToString().Remove(dr["Eingresos"].ToString().Length - 2, 2)
                            : dr["Eingresos"].ToString();

                        model.EC_PeriodoIng = dr["EPeriodoIngresos"].ToString();
                        model.EC_Domicilio = dr["EDireccion"] + " " + dr["EDomNumero"];
                        model.EC_Colonia = dr["EColonia"].ToString();
                        model.EC_Cruces = dr["ECruces"].ToString();
                        model.EC_Tel = dr["Telefono"].ToString();
                        model.EC_Municipio = dr["EDelegacion"].ToString();
                        model.EC_TrabjAnterior = dr["ETrabajoAnterior"].ToString();
                        model.EC_Colonia2 = dr["ETAColonia"].ToString();
                        model.EC_Municipio2 = dr["ETADelegacion"].ToString();

                        //EmpleoConyuge
                        model.ECon_Empresa = dr["EmpresaCyge"].ToString();
                        model.ECon_Funciones = dr["FuncionesCyge"].ToString().Length > 50
                            ? dr["FuncionesCyge"].ToString().Substring(0, 50)
                            : dr["FuncionesCyge"].ToString();
                        model.ECon_Departamento = dr["DepartamentoCyge"].ToString();
                        model.ECon_JefeIn = dr["JefeCyge"].ToString();
                        model.ECon_PuestoJefe = dr["PuestoJefeCyge"].ToString();
                        model.ECon_Antig = dr["AntigCyge"].ToString();

                        //if (dr["IngresosCyge"].ToString() == string.Empty || dr["IngresosCyge"].ToString() == null)
                        //    model.ECon_Ingresos = 0;
                        //else
                        model.ECon_Ingresos = dr["IngresosCyge"].ToString().Length > 0
                            ? dr["IngresosCyge"].ToString().Remove(dr["IngresosCyge"].ToString().Length - 2, 2)
                            : dr["IngresosCyge"].ToString();

                        model.ECon_PeriodoIng = dr["PeriodoIngresosCyge"].ToString();
                        model.ECon_Domicilio = dr["DomEmprCyge"].ToString();
                        model.ECon_Colonia = dr["ColoniaEmprCyge"].ToString();
                        model.ECon_Cruces = dr["CrucesEmprCyge"].ToString();
                        model.ECon_Tel = dr["TelEmprCyge"].ToString();
                        model.ECon_Municipio = dr["MnpioEmprCyge"].ToString();
                        model.ECon_TrabjAnterior = dr["TrabAntCyge"].ToString();
                        model.ECon_Colonia2 = dr["TrabAntColCyge"].ToString();
                        model.ECon_Municipio2 = dr["TrabAntMpioCyge"].ToString();

                        //Referencias Personales 1
                        model.Ref_Nombre = dr["Ref1Nombre"].ToString();
                        model.Ref_Parentezco = dr["Ref1Parentezco"].ToString();
                        model.Ref_Telefono = dr["Ref1Tel"].ToString();
                        model.Ref_Domi = dr["Ref1Dom"] + " " + dr["Ref1DomNum"];
                        model.Ref_Col = dr["Ref1Col"].ToString();
                        model.Ref_Municipio = dr["Ref1Mpio"].ToString();
                        model.Ref_escliente = false; //??
                        model.Ref_Cuenta = ""; //??

                        //Referencias Personales 2
                        model.Ref2_Nombre = dr["Ref2Nombre"].ToString();
                        model.Ref2_Parentezco = dr["Ref2Parentezco"].ToString();
                        model.Ref2_Telefono = dr["Ref2Tel"].ToString();
                        model.Ref2_Domi = dr["Ref2Dom"] + " " + dr["Ref2DomNum"];
                        model.Ref2_Col = dr["Ref2Col"].ToString();
                        model.Ref2_Municipio = dr["Ref2Mpio"].ToString();
                        model.Ref2_escliente = false; //??
                        model.Ref2_Cuenta = ""; //??


                        //Referencias Comerciales
                        //Referencias bancarias
                        model.RefBan_Tarjeta_ = dr["Ref1BNombre"].ToString();
                        model.RefBan_Tarjeta_1 = dr["Ref2BNombre"].ToString();
                        model.RefBan_EmisorTarjeta_ = dr["Ref1CNombre"].ToString();
                        model.RefBan_EmisorTarjeta_1 = dr["Ref2CNombre"].ToString();

                        //Generales Aval
                        model.A_Parentezco = dr["AvalParentezco"].ToString();
                        model.A_Vivede = dr["AvalViveEnCalidad"].ToString();
                        model.A_Nom = dr["AvalNombre"].ToString();
                        model.A_edad = dr["AvalEdad"].ToString();

                        if (dr["AvalFechaNac"].ToString() == null || dr["AvalFechaNac"].ToString() == string.Empty)
                        {
                            model.A_FechaNacimiento = string.Empty;
                        }
                        else
                        {
                            //model.A_FechaNacimiento = Convert.ToDateTime(dr["AvalFechaNac"].ToString());
                            char delimiter = '/';

                            string Fecha = Convert.ToDateTime(dr["AvalFechaNac"]).ToString("dd/MMMM/yyyy");

                            int Month = Convert.ToDateTime(dr["AvalFechaNac"]).Month;

                            string Month_ = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);

                            string Month_Mayus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Month_);

                            string[] substrings = Fecha.Split(delimiter);

                            model.A_FechaNacimiento = substrings[0] + "/" + Month_Mayus + "/" + substrings[2];
                        }

                        model.A_Conyuge = dr["AvalCygeNombre"].ToString();
                        model.ACon_edad = dr["AvalCygeEdad"].ToString();

                        if (dr["AvalCygeFechaNac"].ToString() == null ||
                            dr["AvalCygeFechaNac"].ToString() == string.Empty)
                        {
                            model.ACon_FechaNacimiento = string.Empty;
                        }
                        else
                        {
                            // model.ACon_FechaNacimiento = Convert.ToDateTime(dr["AvalCygeFechaNac"].ToString());
                            char delimiter = '/';

                            string Fecha = Convert.ToDateTime(dr["AvalCygeFechaNac"]).ToString("dd/MMMM/yyyy");

                            int Month = Convert.ToDateTime(dr["AvalCygeFechaNac"]).Month;

                            string Month_ = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);

                            string Month_Mayus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Month_);

                            string[] substrings = Fecha.Split(delimiter);

                            model.ACon_FechaNacimiento = substrings[0] + "/" + Month_Mayus + "/" + substrings[2];
                        }

                        model.A_Domicilio = dr["AvalDom"] + " " + dr["AvalDomNum"];
                        model.A_Antiguedad = dr["AvalAntig"].ToString();
                        model.A_Colonia = dr["AvalCol"].ToString();
                        model.A_cp = dr["AvalCP"].ToString();
                        model.A_Telefono = dr["AvalTel"].ToString();
                        model.A_Cruces = dr["AvalCruces"].ToString();
                        model.A_Municipio = dr["AvalMpio"].ToString();
                        model.A_DomAnterior = dr["AvalMpioAnt"].ToString();
                        model.A_Colonia2 = dr["AvalColant"].ToString();
                        model.A_Municipio2 = dr["AvalMpioAnt"].ToString();
                        model.A_EdoCivil = dr["AvalEdoCivil"].ToString();

                        //Datos Empleo Aval
                        model.EA_empresa = dr["AvalEmpl"].ToString();
                        model.EA_Funciones = dr["AvalFunc"].ToString().Length > 50
                            ? dr["AvalFunc"].ToString().Substring(0, 50)
                            : dr["AvalFunc"].ToString();
                        //model.EA_Funciones = dr["AvalFunc"].ToString();
                        model.EA_Departamento = dr["AvalDpto"].ToString();
                        model.EA_JefeIn = dr["AvalJefe"].ToString();
                        model.EA_PuestoJefe = dr["AvalJefePsto"].ToString();
                        model.EA_Antig = dr["AvalEmprAntig"].ToString();

                        //if (dr["AvalIngr"].ToString() == string.Empty || dr["AvalIngr"].ToString() == null)
                        //    model.EA_Ingresos = 0;
                        //else
                        model.EA_Ingresos = dr["AvalIngr"].ToString().Length > 0
                            ? dr["AvalIngr"].ToString().Remove(dr["AvalIngr"].ToString().Length - 2, 2)
                            : dr["AvalIngr"].ToString();

                        model.EA_PeriodoIng = dr["AvalPago"].ToString();
                        model.EA_Domicilio = dr["AvalDomEmpr"] + " " + dr["AvalDomEmprNum"];
                        model.EA_Colonia = dr["AvalEmprCol"].ToString();
                        model.EA_CP = dr["AvalEmprCP"].ToString();
                        model.EA_Cruces = dr["AvalEmprCruce"].ToString();
                        model.EA_Tel = dr["AvalEmprTel"].ToString();
                        model.EA_Municipio = dr["AvalEmprMpio"].ToString();
                        model.EA_TrabjAnterior = dr["AvalEmprAntNom"].ToString();
                        model.EA_Colonia2 = dr["AvalEmprAntCol"].ToString();
                        model.EA_Municipio2 = dr["AvalEmprAntMpio"].ToString();

                        //Datos empleo conyuge Aval
                        model.EACon_Empresa = dr["AvalEmplCyg"].ToString();

                        model.EACon_Funciones = dr["AvalFuncCyg"].ToString().Length > 50
                            ? dr["AvalFuncCyg"].ToString().Substring(0, 50)
                            : dr["AvalFuncCyg"].ToString();
                        //model.EACon_Funciones = dr["AvalFuncCyg"].ToString();
                        model.EACon_Departamento = dr["AvalDptoCyg"].ToString();
                        model.EACon_JefeIn = dr["AvalJefeCyg"].ToString();
                        model.EACon_PuestoJefe = dr["AvalJefePstoCyg"].ToString();
                        model.EACon_Antig = dr["AvalEmprAntigCyg"].ToString();

                        //if (dr["AvalIngrCyg"].ToString() == string.Empty || dr["AvalIngrCyg"].ToString() == null)
                        //    model.EACon_Ingresos = 0;
                        //else
                        model.EACon_Ingresos = dr["AvalIngrCyg"].ToString().Length > 0
                            ? dr["AvalIngrCyg"].ToString().Remove(dr["AvalIngrCyg"].ToString().Length - 2, 2)
                            : dr["AvalIngrCyg"].ToString();

                        model.EACon_PeriodoIng = dr["AvalPagoCyg"].ToString();
                        model.EACon_Domicilio = dr["AvalDomEmprCyg"] + " " + dr["AvalDomEmprNumCyg"];
                        model.EACon_Colonia = dr["AvalEmprColCyg"].ToString();
                        model.EACon_CP = dr["AvalEmprCPCyg"].ToString();
                        model.EACon_Cruces = dr["AvalEmprCruceCyg"].ToString();
                        model.EACon_Tel = dr["AvalEmprTelCyg"].ToString();
                        model.EACon_Municipio = dr["AvalEmprMpioCyg"].ToString();
                        model.EACon_TrabjAnterior = dr["AvalEmprAntNomCyg"].ToString();
                        model.EACon_Colonia2 = dr["AvalEmprAntColCyg"].ToString();
                        model.EACon_Municipio2 = dr["AvalEmprAntMpioCyg"].ToString();

                        //Observaciones
                        model.Observaciones = dr["Observaciones"].ToString();
                        if (iCanalVenta == 77) model.RefBan_Tarjeta_ = dr["NumeroTarjetaDineralia"] + " " + sBanco;

                        Lista.Add(model);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "MaviRM0855AHojaVerdeController", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();

                item = new MaviRM0855AHojaVerde();

                if (Lista.Count > 1)
                    item = Lista.FirstOrDefault();
            }


            return item;
        }
    }
}