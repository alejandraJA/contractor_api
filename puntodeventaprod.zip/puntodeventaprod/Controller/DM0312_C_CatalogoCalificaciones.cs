﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_CatalogoCalificaciones
    {
        /// <summary>
        ///     Obtiene la todas las claves de calificacion dependiendo el Usuario
        /// </summary>
        /// <param name="Buscador">string</param>
        /// Developer: Erika Perez
        /// Date: 17/09/17
        public DataTable CatalagoCalifiaciones(string Buscador)
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_MaviDM0312BuscadorCatalogoCal", ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Buscar", SqlDbType.VarChar).Value = Buscador;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CatalogoCalificaciones", "DM0312_C_CatalogoCalificaciones", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }
    }
}