﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;
using PuntoVenta.Model;
//using System.Globalization;

namespace PuntoVenta.Controller
{
    internal partial class CDetalleVenta
    {
        /// <summary>
        ///     Inserta en salida diversa y afecta el mov creado
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 08/12/17
        public string InsertarSalidaDiversa(List<DM0312_MExploradorVenta> VentasSeleccionadas, ref bool SalidaCreada,
            ref string MovIDSalidaDiversa)
        {
            if (SalidaDiversaExiste(VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId)) return "";
            string messageError = "";

            string CadenaSQL = "SELECT DISTINCT " +
                               "ArtDisponible.Almacen " +
                               "FROM Art a WITH(NOLOCK) " +
                               "INNER JOIN ArtDisponible WITH(NOLOCK) " +
                               "ON a.Articulo = ArtDisponible.Articulo " +
                               "INNER JOIN ALM WITH(NOLOCK) " +
                               "ON ArtDisponible.Almacen = ALM.almacen " +
                               "INNER JOIN Ventad vd WITH(NOLOCK) " +
                               "ON a.articulo = vd.Articulo " +
                               "WHERE a.Grupo = 'MERCANCIA ESPECIAL' " +
                               "AND a.Categoria = 'VENTA' " +
                               "AND a.tipo IN('Juego', 'Servicio', 'Normal', 'Serie', 'Lote')  " +
                               "AND a.Estatus IN('ALTA', 'BLOQUEADO') " +
                               "AND Linea<> '' " +
                               "AND ArtDisponible.Disponible = 1 " +
                               "AND Alm.Categoria = 'ADJUDICACION' " +
                               "AND ALM.ALMACEN IN(SELECT Nombre FROM TablaStd WITH(NOLOCK) WHERE Valor = @Almacen  AND TablaSt = 'AlmacenesAdjudicados') " +
                               "AND vd.id = @Id";
            string[] parametros = { "@Almacen", "@Id" };
            string[] parametrosAPasar =
                { VentasSeleccionadas[PaginadoActual].Almacen, VentasSeleccionadas[PaginadoActual].ID.ToString() };
            string AlmacenI = EjecutaComandosSQL(CadenaSQL, parametros, parametrosAPasar, string.Empty);

            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312SalidaDiversa", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@IDVenta", VentasSeleccionadas[PaginadoActual].ID);
                sqlCommand.Parameters.AddWithValue("@FechaEmision",
                    DateTime.Now.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture));
                sqlCommand.Parameters.AddWithValue("@Concepto",
                    ConfigurationManager.AppSettings["ConceptoSalidaDiversa"]);
                sqlCommand.Parameters.AddWithValue("@Referencia",
                    VentasSeleccionadas[PaginadoActual].Mov + " " + VentasSeleccionadas[PaginadoActual].MovId);
                sqlCommand.Parameters.AddWithValue("@Almacen", AlmacenI);
                sqlCommand.Parameters.AddWithValue("@Vencimiento",
                    DateTime.Now.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture));
                sqlCommand.Parameters.AddWithValue("@Usuario", ConfigurationManager.AppSettings["UsuarioInventario"]);
                sqlCommand.Parameters.AddWithValue("@UltimoCambio", DateTime.Now);
                sqlCommand.Parameters.AddWithValue("@FechaRequerida",
                    DateTime.Now.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture));
                sqlCommand.Parameters.AddWithValue("@Sucursal", VentasSeleccionadas[PaginadoActual].Sucursal);
                sqlCommand.Parameters.AddWithValue("@SucursalOrigen", VentasSeleccionadas[PaginadoActual].Sucursal);
                sqlCommand.Parameters.AddWithValue("@UEN", ClaseEstatica.Usuario.Uen);
                sqlCommand.Parameters.AddWithValue("@SubModulo", "INV");
                sqlCommand.Parameters.AddWithValue("@Estacion", ClaseEstatica.WorkStation);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        if (dr.FieldCount > 2)
                        {
                            if (dr[2].ToString() == "ERROR" || dr[2].ToString() == "PRECAUCION")
                            {
                                messageError = dr[1].ToString();
                                SalidaCreada = false;
                                return messageError;
                            }
                        }
                        else
                        {
                            messageError = dr[0].ToString();
                        }

                        if (dr.NextResult())
                            while (dr.Read())
                            {
                                messageError = "Salida diversa: " + dr["MovID"] + " creada correctamente";
                                MovIDSalidaDiversa = dr["MovID"].ToString();
                                SalidaCreada = true;
                                return messageError;
                            }
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertarSalidaDiversa", "CDetalleVenta.SalidaDiversa.cs", ex);
                MessageBox.Show(ex.Message + " Error function InsertarSalidaDiversa, CDetalleVenta.SalidaDiversa.cs");
            }

            return messageError;
        }

        /// <summary>
        ///     Checa si ya existe la salida diversa
        /// </summary>
        /// <param name="Mov">string</param>
        /// <param name="MovID">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 08/12/17
        private bool SalidaDiversaExiste(string Mov, string MovID)
        {
            bool Existente = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312SalidaDiversa", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlCommand.Parameters.AddWithValue("@ObtenerSalidaDiversa", true);
                sqlCommand.Parameters.AddWithValue("@Referencia", Mov + " " + MovID);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr["Existente"] != null && dr["Existente"].ToString() != "" &&
                            dr["Existente"].ToString() != "0")
                            Existente = true;
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SalidaDiversaExiste", "CDetalleVenta.SalidaDiversa.cs", ex);
                MessageBox.Show(ex.Message + " Error function SalidaDiversaExiste, CDetalleVenta.SalidaDiversa.cs");
            }

            return Existente;
        }

        /// <summary>
        ///     Cancelacion salida diversa
        /// </summary>
        /// <param name="MovIDSalidaDiversa">string</param>
        /// Developer: Dan Palacios
        /// Date: 12/01/18
        public void CancelarSalidaDiversa(string MovIDSalidaDiversa)
        {
            string CommandSalidaID = "SELECT ID FROM INV WHERE MOV = 'Salida Diversa' AND MovID = @MovID";
            string[] parametros = { "@MovID" };
            string[] valorParametros =
            {
                MovIDSalidaDiversa
            };
            string IDSalidaDiversa = EjecutaComandosSQL(CommandSalidaID, parametros, valorParametros, string.Empty);

            string CadenaSQL = "spAfectar";
            SqlParameter okref = new SqlParameter("@Ok", SqlDbType.NVarChar, 255)
                { Direction = ParameterDirection.Output };
            parametros = new[] { "@Modulo", "@ID", "@Accion", "@Base", "@GenerarMov", "@Usuario", "@Estacion" };
            valorParametros = new[]
            {
                "INV",
                IDSalidaDiversa,
                "CANCELAR",
                "Todo",
                null,
                ClaseEstatica.Usuario.usuario,
                ClaseEstatica.WorkStation.ToString()
            };
            EjecutaComandosSQLWithReturn(CadenaSQL, parametros, valorParametros, null, okref, true);
        }


        public string Obtener
            (string cliente)
        {
            string CadenaSQL = "select Empleado from TcA_RelacionCteFinalEmpleado Where Cliente = @Cliente";
            string[] parametros = { "@Cliente" };
            string[] valorParametros = { cliente };
            return EjecutaComandosSQL(CadenaSQL, parametros, valorParametros, "");
        }
    }
}