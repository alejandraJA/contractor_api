﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class SolicitudCancelacionesController
    {
        /*
         *<
         *
         */
        public List<SolicitudCancelaciones> getSolicitudesCancelacion()
        {
            List<SolicitudCancelaciones> solicitudes = new List<SolicitudCancelaciones>();

            string query = @"
            SELECT
              V.id,V.Cliente,V.Condicion,V.Mov,V.MovID,V.Mov + ' ' + MovID AS Movimiento,V.Estatus,
              CONVERT(FLOAT,V.PrecioTotal) AS CostoTotal,MB.Fecha,MB.Agente,V.Almacen,MB.Evento,v.EnviarA,
              MB.Rid,MB.Clave
            FROM (
              SELECT
                ROW_NUMBER() OVER (PARTITION BY MB.id ORDER BY MB.RID DESC) AS Fila,
                MB.ID,
                MB.RID,
                MB.Clave
              FROM Venta V WITH (NOLOCK)
              JOIN MovBitacora MB WITH (NOLOCK)
                ON MB.Id = V.Id
              WHERE MB.Clave IN ('VTA99998', 'VTA99997')
                AND v.Estatus = 'PENDIENTE'
            ) SQ
            JOIN Venta V WITH (NOLOCK)
              ON V.ID = SQ.ID
            JOIN MovBitacora MB WITH (NOLOCK)
              ON SQ.RID = MB.RID
            WHERE SQ.Fila = 1
              AND SQ.Clave = 'VTA99998'
            ORDER BY V.ID,MB.Rid DESC";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                SolicitudCancelaciones sol = new SolicitudCancelaciones();

                                sol.Id = Convert.ToInt32(dr["id"]);
                                sol.Cliente = dr["Cliente"].ToString();
                                sol.Condicion = dr["Condicion"].ToString();
                                sol.Mov = dr["Mov"].ToString();
                                sol.MovID = dr["MovID"].ToString();
                                sol.Movimiento = dr["Movimiento"].ToString();
                                sol.Estatus = dr["Estatus"].ToString();
                                sol.Importe = Convert.ToDouble(dr["CostoTotal"]);
                                sol.Fecha = Convert.ToDateTime(dr["Fecha"]);
                                sol.Agente = dr["Agente"].ToString();
                                sol.Almacen = dr["Almacen"].ToString();
                                sol.Motivo = dr["Evento"].ToString();
                                sol.EnviarA = Convert.ToInt32(dr["EnviarA"]);
                                sol.Rid = Convert.ToInt32(dr["Rid"]);
                                sol.Clave = dr["Clave"].ToString();

                                solicitudes.Add(sol);
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return solicitudes;
        }

        public List<int> ListaSucursalVirtual()
        {
            List<int> sucursalVirtual = new List<int>();

            try
            {
                string sQuery = @"
                       SELECT CAST(Numero AS INT) AS sucursalVirtual
                         FROM tablanumd WITH (NOLOCK)
                        WHERE tablanum = 'sucursal virtual' ";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read()) sucursalVirtual.Add(int.Parse(dr["sucursalVirtual"].ToString()));
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return sucursalVirtual;
        }
    }
}