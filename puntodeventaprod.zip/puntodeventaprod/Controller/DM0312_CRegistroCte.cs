﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_CRegistroCte
    {
        public List<DM0312_MRegistroCte> ExecStore(string Codigo, int Operacion, DM0312_MRegistroCte model)
        {
            List<DM0312_MRegistroCte> Lista = new List<DM0312_MRegistroCte>();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SpVTASRegistroDeHuellaCliente", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Op", SqlDbType.Int).Value = Operacion;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = model.ID;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = model.Codigo;
                cmd.Parameters.Add("@Valido", SqlDbType.Bit).Value = model.Valido;
                cmd.Parameters.AddWithValue("@Usuario", model.UsuarioValido ?? DBNull.Value.ToString());
                //cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = model.UsuarioValido;
                cmd.Parameters.AddWithValue("@IdVenta", model.IdMov);

                dr = cmd.ExecuteReader();

                DM0312_MRegistroCte EmptyModel = new DM0312_MRegistroCte();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        //AccesoUsuario au = new AccesoUsuario();
                        DM0312_MRegistroCte model_ = new DM0312_MRegistroCte();
                        model_.Codigo = dr["Codigo"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Registro = dr["Registro"].ToString();
                        if (dr["Fecha"].ToString() != string.Empty)
                            model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                        model_.Sucursal = Convert.ToInt32(dr["Sucursal"].ToString());
                        model_.Motivo = dr["Motivo"].ToString();
                        model_.Pregunta1 = dr["Pregunta1"].ToString(); //Respuesta1
                        model_.Respuesta1 = dr["Respuesta1"].ToString();
                        model_.Pregunta2 = dr["Pregunta2"].ToString();
                        model_.Respuesta2 = dr["Respuesta2"].ToString();
                        model_.Pregunta3 = dr["Pregunta3"].ToString();
                        model_.Respuesta3 = dr["Respuesta3"].ToString();
                        model_.Pregunta4 = dr["Pregunta4"].ToString();
                        model_.Respuesta4 = dr["Respuesta4"].ToString();
                        model_.Pregunta5 = dr["Pregunta5"].ToString();
                        model_.Respuesta5 = dr["Respuesta5"].ToString();
                        if (dr["Valido"].ToString() != "")
                            model_.Valido = Convert.ToBoolean(dr["Valido"].ToString());
                        model_.UsuarioValido = dr["UsuarioValido"].ToString();
                        if (dr["FechaValido"].ToString() != string.Empty)
                            model_.FechaValido = Convert.ToDateTime(dr["FechaValido"].ToString());
                        model_.ID = Convert.ToInt32(dr["ID"].ToString());
                        if (dr["IdMov"].ToString() != string.Empty)
                            model_.IdMov = Convert.ToInt32(dr["IdMov"].ToString());
                        model_.Recomendado = dr["Recomendado"].ToString();

                        Lista.Add(model_);
                    }
                }
                else
                {
                    if (Operacion == 2)
                    {
                        EmptyModel.Motivo = "OK";
                        Lista.Add(EmptyModel);
                    }
                }
            }
            catch (Exception ex)
            {
                //DM0312_CRegistroCte
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CRegistroCte", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }


            return Lista;
        }

        public DM0312_MRegistroCte ExecFuncion(string Codigo, int IdVenta)
        {
            DM0312_MRegistroCte model = new DM0312_MRegistroCte();
            SqlDataReader dr = null;

            try
            {
                string query = string.Format("SELECT * FROM FN_DM0312_RegistroDeHuellaCliente('{0}',{1})", Codigo,
                    IdVenta);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        //AccesoUsuario au = new AccesoUsuario();
                        DM0312_MRegistroCte model_ = new DM0312_MRegistroCte();
                        model_.Codigo = dr["Codigo"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Registro = dr["Registro"].ToString();
                        if (dr["Fecha"].ToString() != string.Empty)
                            model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                        model_.Sucursal = Convert.ToInt32(dr["Sucursal"].ToString());
                        model_.Motivo = dr["Motivo"].ToString();
                        model_.Pregunta1 = dr["Pregunta1"].ToString(); //Respuesta1
                        model_.Respuesta1 = dr["Respuesta1"].ToString();
                        model_.Pregunta2 = dr["Pregunta2"].ToString();
                        model_.Respuesta1 = dr["Respuesta1"].ToString();
                        model_.Pregunta3 = dr["Pregunta3"].ToString();
                        model_.Respuesta3 = dr["Respuesta3"].ToString();
                        model_.Pregunta4 = dr["Pregunta4"].ToString();
                        model_.Respuesta4 = dr["Respuesta4"].ToString();
                        model_.Pregunta5 = dr["Pregunta5"].ToString();
                        model_.Respuesta5 = dr["Respuesta5"].ToString();
                        if (dr["Valido"].ToString() != "")
                            model_.Valido = Convert.ToBoolean(dr["Valido"].ToString());
                        model_.UsuarioValido = dr["UsuarioValido"].ToString();
                        if (dr["FechaValido"].ToString() != string.Empty)
                            model_.FechaValido = Convert.ToDateTime(dr["FechaValido"].ToString());
                        model_.ID = Convert.ToInt32(dr["ID"].ToString());
                        if (dr["IdMov"].ToString() != string.Empty)
                            model_.IdMov = Convert.ToInt32(dr["IdMov"].ToString());
                        model_.Recomendado = dr["Recomendado"].ToString();

                        model = model_;
                        //Lista.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CRegistroCte", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }


            return model;
        }


        public List<DM0312_MRegistroCte> FiltrarListas(string Codigo, string Sucursal)
        {
            List<DM0312_MRegistroCte> ListRegistro = new List<DM0312_MRegistroCte>();

            List<DM0312_MRegistroCte> ListRegistroRet = new List<DM0312_MRegistroCte>();

            DM0312_MRegistroCte model = new DM0312_MRegistroCte();

            model.Codigo = Codigo;
            model.Valido = false;
            model.ID = 1234;
            model.UsuarioValido = "Codigo";

            DateTime Dt = new DateTime();

            bool Fechas = false;

            Fechas = ClaseEstatica.DM0312_RegistroDeHuellaFechas;

            int sucursal = 0;

            ListRegistro = ExecStore(Codigo, 1, model).OrderBy(x => x.FechaValido).ToList();

            if (Sucursal != "Todas")
            {
                sucursal = getSucursal(Sucursal);

                if (Fechas)
                {
                    List<DM0312_MRegistroCte> ListReturn = new List<DM0312_MRegistroCte>();
                    ListRegistroRet = ListRegistro.Where(x => x.Sucursal == sucursal).ToList();

                    if (ClaseEstatica.FechaInicio != Dt && ClaseEstatica.FechaFin != Dt)
                    {
                        IEnumerable<DM0312_MRegistroCte> between = from v in ListRegistroRet
                            where v.Fecha >= ClaseEstatica.FechaInicio
                                  && v.Fecha <= ClaseEstatica.FechaFin
                            select v;

                        ListReturn = between.ToList();

                        return ListReturn;
                    }

                    return ListRegistroRet;
                }

                return ListRegistroRet = ListRegistro.Where(x => x.Sucursal == sucursal).ToList();
            }

            if (Fechas)
            {
                List<DM0312_MRegistroCte> ListReturn = new List<DM0312_MRegistroCte>();
                if (ClaseEstatica.FechaInicio != Dt && ClaseEstatica.FechaFin != Dt)
                {
                    IEnumerable<DM0312_MRegistroCte> between = from v in ListRegistro
                        where v.Fecha >= ClaseEstatica.FechaInicio
                              && v.Fecha <= ClaseEstatica.FechaFin
                        select v;

                    ListReturn = between.ToList();

                    return ListReturn;
                }

                return ListRegistro;
            }

            return ListRegistro;
        }

        public DM0312_MRegistroCte RegistroHuellaIdVenta(string Codigo, int idVenta)
        {
            DM0312_MRegistroCte Registro = new DM0312_MRegistroCte();

            List<DM0312_MRegistroCte> ListRegistro = new List<DM0312_MRegistroCte>();

            DM0312_MRegistroCte model = new DM0312_MRegistroCte();

            model.Codigo = Codigo;
            model.Valido = false;
            model.ID = 1234;
            model.UsuarioValido = "Codigo";
            model.IdMov = idVenta;

            ListRegistro = ExecStore(Codigo, 3, model).OrderBy(x => x.FechaValido).ToList();

            Registro = ListRegistro.FirstOrDefault();

            if (Registro.Codigo == null && Registro.IdMov == 0)
                return null;
            return Registro;
        }

        public int getSucursal(string text)
        {
            if (!string.IsNullOrWhiteSpace(text))
            {
                int charLocation = text.IndexOf("-", StringComparison.Ordinal);

                if (charLocation > 0)
                {
                    string tex = text.Substring(0, charLocation);
                    return Convert.ToInt32(tex);
                }

                return Convert.ToInt32(text);
            }

            return 0;
        }

        public List<DM0312_MRegistroCte> ValidaHuellas(string Codigo, string Sucursal,
            List<DM0312_MRegistroCte> ListaUpdate)
        {
            List<DM0312_MRegistroCte> L = new List<DM0312_MRegistroCte>();

            DM0312_MRegistroCte M = new DM0312_MRegistroCte();

            try
            {
                foreach (DM0312_MRegistroCte item in ListaUpdate) L = ExecStore(Codigo, 2, item);
                M = L.Where(x => x.Motivo == "OK").FirstOrDefault();

                if (M != null)
                {
                    MessageBox.Show("Registro Actualizado", "Aviso!");
                    L = FiltrarListas(Codigo, Sucursal);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CRegistroCte", ex);
                MessageBox.Show(ex.Message);
            }

            return L;
        }
    }
}