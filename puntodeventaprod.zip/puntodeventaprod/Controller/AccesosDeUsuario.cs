﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class AccesosDeUsuario
    {
        public static ConfiguracionesUsuario CUsuario = new ConfiguracionesUsuario();
        public static List<AccesoUsuario> AccesosUsuario = new List<AccesoUsuario>();
        private Dictionary<string, bool> AccesosVentas = new Dictionary<string, bool>();

        /// <summary>
        ///     Obtiene los permisos de acceso o vista del usuario
        /// </summary>
        /// <param name="Usuario">string</param>
        /// <returns>List<AccesoUsuario></returns>
        /// Developer: Dan Palacios
        /// Date: 20/07/2017
        public List<AccesoUsuario> ObtenerAccesos(string Usuario)
        {
            SqlCommand command =
                new SqlCommand("SP_MaviDM0312PuntoVentaAccesoUsuarios", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@Usuario", Usuario);
            command.CommandType = CommandType.StoredProcedure;

            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        AccesoUsuario au = new AccesoUsuario
                        {
                            campo = dr["Campo"].ToString(),
                            nombreForma = dr["Forma"].ToString()
                        };
                        AccesosUsuario.Add(au);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerAccesos", "AccesosDeUsuario.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerAccesos, class: AccesosDeUsuario.cs");
            }

            return AccesosUsuario;
        }

        /// <summary>
        ///     Aplica las vistas de el form seleccionado
        /// </summary>
        /// <param name="Forma">Form</param>
        /// <param name="AccesosUsuario">List<AccesoUsuario></param>
        /// <returns>Form</returns>
        /// Developer: Dan Palacios
        /// Date: 20/07/2017
        public Form AplicarVistas(Form Forma)
        {
            List<AccesoUsuario> model = AccesosUsuario.Where(x => x.nombreForma == Forma.Name).ToList();
            foreach (AccesoUsuario au in model)
            {
                Control[] ctrls = Forma.Controls.Find(au.campo, true);
                int i = 0;
                foreach (Control ctrl in ctrls)
                {
                    i++;
                    ctrl.Visible = false;
                    break;
                }

                if (i == 0)
                {
                    bool breakpoint = false;

                    FieldInfo fiComponents = Forma.GetType()
                        .GetField("components", BindingFlags.Instance | BindingFlags.NonPublic);
                    if (fiComponents != null)
                    {
                        IContainer components = fiComponents.GetValue(Forma) as IContainer;
                        if (components != null)
                            for (int j = 0; j < components.Components.Count; j++)
                            {
                                if (components.Components[j] is ContextMenuStrip)
                                {
                                    ContextMenuStrip cms = (ContextMenuStrip)components.Components[j];
                                    foreach (ToolStripMenuItem item in cms.Items)
                                        if (item.Name == au.campo)
                                        {
                                            item.Visible = false;
                                            breakpoint = true;
                                            if (item.Name == "MenuItem_Afectar")
                                                DM0312_ExploradorVentas.AfectarVisible = false;
                                            if (item.Name == "MenuItem_nuevo") DM0312_ExploradorVentas.nuevoCd = false;
                                            if (item.Name == "MenuItem_TiempoTotal")
                                                DM0312_ExploradorVentas.tiempototal = false;
                                            if (item.Name == "MenuItem_MonederoRedimir")
                                                DM0312_ExploradorVentas.monederoPorRedimir = false;
                                            if (item.Name == "MenuItem_ActualizacionDatos")
                                                DM0312_ExploradorVentas.VerActualizacionDeDatos = false;
                                            if (item.Name == "agregarActualizacionDeDatosCrtlJToolStripMenuItem")
                                                DM0312_ExploradorVentas.AgregarActualizacionDatosV = false;
                                            if (item.Name == "MenuItem_ClienteExpress")
                                                DM0312_ExploradorVentas.RM0855ClienteExpres = false;
                                            if (item.Name == "camposExtrasToolStripMenuItem")
                                                DM0312_ExploradorVentas.CamposExtras = false;
                                            if (item.Name == "consultarBuroToolStripMenuItem")
                                                DM0312_ExploradorVentas.consultaBuro = false;
                                            if (item.Name == "MenuItem_Excel") DM0312_ExploradorVentas.Excel = false;
                                            if (item.Name == "MenuItem_KardexClienteFinal")
                                                DM0312_ExploradorVentas.Kardexclientefinal = false;

                                            if (item.Name == "copiarClienteToolStripMenuItem")
                                                DM0312_ExploradorVentas.CopiarCliente = false;
                                            if (item.Name == "MenuItem_Relacionado")
                                                DM0312_ExploradorVentas.CopiarClienteRelacionado = false;
                                            if (item.Name == "capturaDeRelacionadoToolStripMenuItem")
                                                DM0312_ExploradorVentas.CapturaRelacionado = false;
                                            if (item.Name == "matrizDeAutorizacionToolStripMenuItem")
                                                DM0312_ExploradorVentas.MatrizDeAutorizacion = false;
                                            if (item.Name == "envioCorreoWebCrtlF9ToolStripMenuItem")
                                                DM0312_ExploradorVentas.CorreoWeb = false;
                                            if (item.Name == "reanalisisToolStripMenuItem")
                                                DM0312_ExploradorVentas.reanalisisV = false;
                                            break;
                                        }
                                }

                                if (breakpoint) break;
                            }
                    }
                }
            }

            return Forma;
        }

        /// <summary>
        ///     Aplica las vista en los controles dados
        /// </summary>
        /// <param name="Controles">List<Control></param>
        /// <param name="NombreForma">string</param>
        /// Developer: Dan Palacios
        public void AplicarVistas(Control.ControlCollection Controles, string NombreForma)
        {
            List<AccesoUsuario> model = AccesosUsuario.Where(x => x.nombreForma == NombreForma).ToList();
            foreach (AccesoUsuario au in model)
            {
                Control[] ctrls = Controles.Find(au.campo, true);
                foreach (Control ctrl in ctrls)
                    if (ctrl.Name == au.campo)
                    {
                        ctrl.Visible = false;
                        break;
                    }
            }
        }

        /// <summary>
        ///     Obtiene las configuraciones de usuario
        /// </summary>
        /// <param name="Usuario">string</param>
        /// <returns>ConfiguracionesUsuario</returns>
        /// Developer: Dan Palacios
        /// Date: 25/07/2017
        public ConfiguracionesUsuario ObtenerConfiguracionUsuario(string Usuario, string grupoUsuario = "")
        {
            ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
            CUsuario.Usuario = Usuario;
            CUsuario.GrupoUsuario = grupoUsuario;
            SqlCommand command =
                new SqlCommand("SP_MaviDM0312PuntoVentaAccesoUsuarios", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@Usuario", Usuario);
            command.Parameters.AddWithValue("@ConfiguracionUsuario", true);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        CUsuario.Afectar = (bool)dr["Afectar"];
                        CUsuario.Cancelar = (bool)dr["Cancelar"];
                        //CUsuario.Desafectar = (bool)dr["Desafectar"];
                        CUsuario.Autorizar = (bool)dr["Autorizar"];
                        CUsuario.AutorizarVenta = (bool)dr["AutorizarVenta"];
                        //CUsuario.AutorizarCxp = (bool)dr["AutorizarCxp"];
                        //CUsuario.AutorizarGasto = (bool)dr["AutorizarGasto"];
                        //CUsuario.AutorizarDinero = (bool)dr["AutorizarDinero"];
                        //CUsuario.AutorizarPV = (bool)dr["AutorizarPV"];
                        //CUsuario.AutorizarCompra = (bool)dr["AutorizarCompra"];
                        CUsuario.AutorizarSeriesLotes = (bool)dr["AutorizarSeriesLotes"];
                        CUsuario.AfectarOtrosMovs = (bool)dr["AfectarOtrosMovs"];
                        CUsuario.CancelarOtrosMovs = (bool)dr["CancelarOtrosMovs"];
                        CUsuario.ConsultarOtrosMovs = (bool)dr["ConsultarOtrosMovs"];
                        CUsuario.ConsultarOtrosMovsGrupo = (bool)dr["ConsultarOtrosMovsGrupo"];
                        CUsuario.ConsultarOtrasEmpresas = (bool)dr["ConsultarOtrasEmpresas"];
                        CUsuario.ConsultarOtrasSucursales = (bool)dr["ConsultarOtrasSucursales"];
                        //CUsuario.AccesarOtrasSucursalesEnLinea = (bool)dr["AccesarOtrasSucursalesEnLinea"];
                        CUsuario.ModificarOtrosMovs = (bool)dr["ModificarOtrosMovs"];
                        //CUsuario.ModificarVencimientos = (bool)dr["ModificarVencimientos"];
                        //CUsuario.ModificarEntregas = (bool)dr["ModificarEntregas"];
                        //CUsuario.ModificarEnvios = (bool)dr["ModificarEnvios"];
                        CUsuario.ModificarReferencias = (bool)dr["ModificarReferencias"];
                        CUsuario.ModificarSituacion = (bool)dr["ModificarSituacion"];
                        CUsuario.ModificarAgente = (bool)dr["ModificarAgente"];
                        CUsuario.ModificarUsuario = (bool)dr["ModificarUsuario"];
                        CUsuario.ModificarListaPrecios = (bool)dr["ModificarListaPrecios"];
                        //CUsuario.ModificarSucursalDestino = (bool)dr["ModificarSucursalDestino"];
                        //CUsuario.ModificarProyUENActCC = (bool)dr["ModificarProyUENActCC"];
                        CUsuario.AgregarCteExpress = (bool)dr["AgregarCteExpress"];
                        CUsuario.AgregarArtExpress = (bool)dr["AgregarArtExpress"];
                        CUsuario.Costos = (bool)dr["Costos"];
                        CUsuario.BloquearCostos = (bool)dr["BloquearCostos"];
                        //CUsuario.VerInfoDeudores = (bool)dr["VerInfoDeudores"];
                        //CUsuario.VerComisionesPendientes = (bool)dr["VerComisionesPendientes"];
                        //CUsuario.BloquearEncabezadoVenta = (bool)dr["BloquearEncabezadoVenta"];
                        //CUsuario.BloquearCxcCtaDinero = (bool)dr["BloquearCxcCtaDinero"];
                        //CUsuario.BloquearCxpCtaDinero = (bool)dr["BloquearCxpCtaDinero"];
                        //CUsuario.BloquearDineroCtaDinero = (bool)dr["BloquearDineroCtaDinero"];
                        CUsuario.EnviarExcel = (bool)dr["EnviarExcel"];
                        CUsuario.ImprimirMovs = (bool)dr["ImprimirMovs"];
                        CUsuario.PreliminarMovs = (bool)dr["PreliminarMovs"];
                        //CUsuario.Reservar = (bool)dr["Reservar"];
                        //CUsuario.DesReservar = (bool)dr["DesReservar"];
                        //CUsuario.Asignar = (bool)dr["Asignar"];
                        //CUsuario.DesAsignar = (bool)dr["DesAsignar"];
                        //CUsuario.ModificarAlmacenPedidos = (bool)dr["ModificarAlmacenPedidos"];
                        //CUsuario.ModificarConceptos = (bool)dr["ModificarConceptos"];
                        //CUsuario.ModificarReferenciasSiempre = (bool)dr["ModificarReferenciasSiempre"];
                        //CUsuario.ModificarAgenteCxcPendiente = (bool)dr["ModificarAgenteCxcPendiente"];
                        //CUsuario.ModificarMovsNominaVigentes = (bool)dr["ModificarMovsNominaVigentes"];
                        //CUsuario.BloquearPrecios = (bool)dr["BloquearPrecios"];
                        //CUsuario.BloquearDescGlobal = (bool)dr["BloquearDescGlobal"];
                        //CUsuario.BloquearDescLinea = (bool)dr["BloquearDescLinea"];
                        //CUsuario.BloquearCondiciones = (bool)dr["BloquearCondiciones"];
                        //CUsuario.BloquearAlmacen = (bool)dr["BloquearAlmacen"];
                        //CUsuario.BloquearMoneda = (bool)dr["BloquearMoneda"];
                        //CUsuario.BloquearAgente = (bool)dr["BloquearAgente"];
                        //CUsuario.BloquearFechaEmision = (bool)dr["BloquearFechaEmision"];
                        //CUsuario.BloquearProyecto = (bool)dr["BloquearProyecto"];
                        //CUsuario.BloquearFormaPago = (bool)dr["BloquearFormaPago"];
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerConfiguracionUsuario", "AccesosDeUsuario.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerConfiguracionUsuario, class: AccesosDeUsuario.cs");
            }

            ObtenerPermisosCreacion();

            return CUsuario;
        }

        /// <summary>
        ///     Obtiene los permisos para crear movimientos al afectar
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 30/09/17
        public void ObtenerPermisosCreacion()
        {
            ClaseEstatica.ListaPermisosCreacion = new List<string>();

            SqlCommand command =
                new SqlCommand("SP_MaviDM0312PuntoVentaAccesoUsuarios", ClaseEstatica.ConexionEstatica);
            //SqlCommand command = new SqlCommand("SELECT MovsEdicion FROM USUARIOACCESO WHERE USUARIO = @Usuario", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@Usuario", ClaseEstatica.Usuario.usuario);
            command.Parameters.AddWithValue("@ObtenerPermisosCreacion", true);
            command.CommandType = CommandType.StoredProcedure;
            string movsEdicion = string.Empty;
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        movsEdicion = dr["MovsEdicion"].ToString();
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerPermisosCreacion", "AccesosDeUsuario.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerPermisosCreacion, class: AccesosDeUsuario.cs");
            }

            if (movsEdicion != string.Empty)
                ClaseEstatica.ListaPermisosCreacion = movsEdicion.Replace("\n", "")
                    .Split(new[] { '\r' }, StringSplitOptions.None).ToList();
        }

        /// <summary>
        ///     Selecciona los campos de detalle venta
        /// </summary>
        /// <param name="Mov">string</param>
        /// <returns>Dictionary<string, bool></returns>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        public Dictionary<string, bool> ObtenerAccesosVentas(string Mov)
        {
            AccesosVentas = new Dictionary<string, bool>();
            string query = "SELECT ccv.Control, ccv.Visible FROM DM0312ConfiguracionControlesVenta ccv WITH(NOLOCK)" +
                           "INNER JOIN DM0312GruposConfiguracionVenta gcv WITH(NOLOCK) ON ccv.Grupo = gcv.Grupo " +
                           "WHERE gcv.Mov = @Mov";
            SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.Parameters.AddWithValue("@Mov", Mov);
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        AccesosVentas.Add(dr["Control"].ToString(), Convert.ToBoolean(dr["Visible"]));
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerAccesosVentas", "AccesosDeUsuario.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerAccesosVentas, class: AccesosDeUsuario.cs");
            }

            return AccesosVentas;
        }


        /// <summary>
        ///     Aplica las vista en los controles dados
        /// </summary>
        /// <param name="Controles">List<Control></param>
        /// <param name="NombreForma">string</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        public void AplicarVistasDetalle(Control.ControlCollection Controles)
        {
            foreach (KeyValuePair<string, bool> ctrlToEnable in AccesosVentas)
            {
                Control[] ctrls = Controles.Find(ctrlToEnable.Key, true);
                foreach (Control ctrl in ctrls)
                    if (ctrl.Name == ctrlToEnable.Key)
                    {
                        ctrl.Visible = ctrlToEnable.Value;
                        break;
                    }
            }
        }
    }
}