﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_CCapRelacionado
    {
        public List<string> GetDataCliente(string cliente)
        {
            List<string> Rest = new List<string>();

            string query = string.Empty;

            query = string.Format("SELECT Cliente, Nombre , "
                                  + "Direccion +' '+ DireccionNumero +' '+ DireccionNumeroInt +' '+Colonia+' '+Delegacion+' '+Estado AS Dir  "
                                  + "FROM cte WITH(NOLOCK) where Cliente = '{0}'", cliente);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Rest.Add(dr["Cliente"].ToString());
                        Rest.Add(dr["Nombre"].ToString());
                        Rest.Add(dr["Dir"].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CapRelacionado", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Rest;
        }

        public List<string> CteExpressParent()
        {
            List<string> Rest = new List<string>();

            string query = string.Empty;

            query =
                "SELECT Parentesco FROM Parentesco WITH(NOLOCK) WHERE Parentesco NOT IN ('AVALADO','CONCUBINA','CONCUBINO','EL','ELLA','EMPLEADO','NOVIA','NOVIO','PATRON')";

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Rest.Add(dr["Parentesco"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CapRelacionado", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Rest;
        }

        public string ExecRelacionado(string relacionado, string cuenta, string Parentesco, string Opcion)
        {
            //EXEC SP_RM0855RelaiconadoIntelisis 'C00000001','C01680435','Genera','AMISTAD','Si'

            string rest = string.Empty;

            string query = "SP_RM0855RelaiconadoIntelisis";

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandTimeout = 100;
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@ClienteRecomienda", SqlDbType.VarChar).Value = relacionado;
                cmd.Parameters.Add("@Prospecto", SqlDbType.VarChar).Value = cuenta;
                cmd.Parameters.Add("@Accion", SqlDbType.VarChar).Value = "Genera";
                cmd.Parameters.Add("@parentesco", SqlDbType.VarChar).Value = Parentesco;
                cmd.Parameters.Add("@SiNo", SqlDbType.VarChar).Value = Opcion;


                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CapRelacionado", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }

        public int ExecRecomienda(string relacionado, string cuenta)
        {
            //EXEC SpRM0855A_CtoConyuAvalRecomienda 'C00000001','C01680435','Genera',0

            int rest = 0;

            string query = "SpRM0855A_CtoConyuAvalRecomienda";

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandTimeout = 100;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ClienteRecomienda", relacionado);
                cmd.Parameters.AddWithValue("@Prospecto", cuenta);
                cmd.Parameters.AddWithValue("@Accion", "Genera");
                cmd.Parameters.AddWithValue("@IDgenerado", 0);

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CapRelacionado", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }
    }
}