﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CInfoSerieArticulos
    {
        /// <summary>
        ///     Obtener series de articulos
        /// </summary>
        /// <param name="SerieLote">string</param>
        /// <returns>List<MInfoSerieArticulos></returns>
        /// Developer: Dan Palacios
        /// Date: 05/09/17
        public static List<MInfoSerieArticulos> ObtenerInfoSeriesArticulos(string SerieLote)
        {
            List<MInfoSerieArticulos> SeriesArticulos = new List<MInfoSerieArticulos>();


            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_MaviDM0312PuntoVentaSerieArticulos", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                sqlCommand.Parameters.AddWithValue("@SerieLote", SerieLote);
                sqlCommand.Parameters.AddWithValue("@GetSerieLoteInfo", true);

                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MInfoSerieArticulos NuevoMov = new MInfoSerieArticulos
                        {
                            Movimiento = dr["Mov"] + " " + dr["MovID"],
                            FechaEmision = Convert.ToDateTime(dr["FechaEmision"]).ToString("dd-MM-yyyy"),
                            Referencia = dr["Referencia"].ToString(),
                            Concepto = dr["Concepto"].ToString(),
                            Proyecto = dr["Proyecto"].ToString(),
                            Observaciones = dr["Observaciones"].ToString()
                        };
                        SeriesArticulos.Add(NuevoMov);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerInfoSeriesArticulos", "CInfoSerieArticulos.cs", ex);
                MessageBox.Show(ex.Message + " function ObtenerInfoSeriesArticulos, class: CInfoSerieArticulos");
            }

            return SeriesArticulos;
        }
    }
}