﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class ConfigColumnas
    {
        public static List<AccesoColumnas> AccesoColumnas = new List<AccesoColumnas>();

        /// <summary>
        ///     Obtiene la lista de configuracion de columnas del usuario seleccionado
        /// </summary>
        /// Developer: Dan Palacios
        /// DatE: 02/08/2017
        public void ObtenerColumnasTablero()
        {
            ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
            SqlCommand command =
                new SqlCommand("SP_MaviDM0312PuntoVentaAccesoUsuarios", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@Usuario", CUsuario.Usuario);
            command.Parameters.AddWithValue("@ConfiguracionColumnas", true);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        AccesoColumnas TempAccesoColumnas = new AccesoColumnas
                        {
                            ID = (int)dr["ID"],
                            NombreColumna = (string)dr["Campo"],
                            Orden = dr["Orden"] != null && dr["Orden"].ToString() != string.Empty
                                ? Convert.ToInt32(dr["Orden"])
                                : 0,
                            Estatus = dr["Estatus"] != null && dr["Estatus"].ToString() != string.Empty
                                ? Convert.ToBoolean(dr["Estatus"])
                                : false,
                            UpdateConfig = dr["UpdateConfig"] != null && dr["UpdateConfig"].ToString() != string.Empty
                                ? Convert.ToBoolean(dr["UpdateConfig"])
                                : false
                        };
                        AccesoColumnas.Add(TempAccesoColumnas);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerColumnasTablero", "ConfigColumnas.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerColumnasTablero, class: ConfigColumnas.cs");
            }
        }

        /// <summary>
        ///     Añade las columnas que estan en uso a la lista principal
        /// </summary>
        /// <param name="dgviewAdded">DataGridView</param>
        /// Developer: Dan Palacios
        /// Date: 04_08_17
        public void GetDatagridEstatus(DataGridView dgviewAdded)
        {
            foreach (AccesoColumnas AccesosColumnas in AccesoColumnas)
                try
                {
                    AccesosColumnas.Estatus = false;
                    int validaOrden = 0;
                    foreach (DataGridViewRow gvrow in dgviewAdded.Rows)
                    {
                        if (AccesosColumnas.NombreColumna == gvrow.Cells[gvrow.Cells.Count - 1].Value.ToString())
                        {
                            //AccesoColumnas AColumnas = AccesoColumnas.FirstOrDefault(x => x.NombreColumna == gvrow.Cells[gvrow.Cells.Count - 1].Value.ToString());
                            //if (AColumnas != null)
                            //{
                            AccesosColumnas.Orden = validaOrden;
                            AccesosColumnas.Estatus = true;
                            break;
                        }

                        AccesosColumnas.Orden = 0;
                        validaOrden++;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("GetDatagridEstatus", "ConfigColumnas.cs", ex);
                    MessageBox.Show(ex.Message + " function: GetDatagridEstatus, class: ConfigColumnas.cs");
                }
        }

        /// <summary>
        ///     Bulk insert new data
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        public void BulkInsertDataTable()
        {
            DataTable dt = new DataTable("DM0312ColumnasUsuarios");
            DataColumn dc = new DataColumn("ID");
            dt.Columns.Add(dc);
            dc = new DataColumn("Usuario");
            dt.Columns.Add(dc);
            dc = new DataColumn("Campo");
            dt.Columns.Add(dc);
            dc = new DataColumn("Estatus");
            dt.Columns.Add(dc);
            dc = new DataColumn("Orden");
            dt.Columns.Add(dc);

            ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
            foreach (AccesoColumnas AColumna in AccesoColumnas)
            {
                DataRow newRow = dt.NewRow();
                newRow["Usuario"] = CUsuario.Usuario;
                newRow["Campo"] = AColumna.NombreColumna;
                newRow["Estatus"] = AColumna.Estatus;
                newRow["Orden"] = AColumna.Orden;
                dt.Rows.Add(newRow);
            }

            try
            {
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                {
                    bulkCopy.DestinationTableName = dt.TableName;
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(dt);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BulkInsertDataTable", "ConfigColumnas.cs", ex);
                MessageBox.Show(ex.Message + " function: BulkInsertDataTable, class: ConfigColumnas.cs");
            }

            //Actualiza el datatable actual
            foreach (AccesoColumnas AColumna in AccesoColumnas) AColumna.UpdateConfig = true;
        }

        /// <summary>
        ///     Bulk update data
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        public void BulkUpdateDataTable()
        {
            DataTable dt = new DataTable("DM0312ColumnasUsuarios");
            DataColumn dc = new DataColumn("ID");
            dt.Columns.Add(dc);
            dc = new DataColumn("Usuario");
            dt.Columns.Add(dc);
            dc = new DataColumn("Campo");
            dt.Columns.Add(dc);
            dc = new DataColumn("Estatus");
            dt.Columns.Add(dc);
            dc = new DataColumn("Orden");
            dt.Columns.Add(dc);

            ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
            foreach (AccesoColumnas AColumna in AccesoColumnas)
            {
                DataRow newRow = dt.NewRow();
                newRow["ID"] = AColumna.ID;
                newRow["Usuario"] = CUsuario.Usuario;
                newRow["Campo"] = AColumna.NombreColumna;
                newRow["Estatus"] = AColumna.Estatus;
                newRow["Orden"] = AColumna.Orden;
                dt.Rows.Add(newRow);
            }

            try
            {
                SqlCommand sqlcomm =
                    new SqlCommand(
                        "CREATE TABLE #TmpTable(ID int NOT NULL, Usuario varchar(10) NULL, Campo varchar (50) NULL, Estatus bit NULL, Orden int null)",
                        ClaseEstatica.ConexionEstatica);
                sqlcomm.ExecuteNonQuery();
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                {
                    try
                    {
                        bulkCopy.DestinationTableName = "#TmpTable";
                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(dt);
                        bulkCopy.Close();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("BulkUpdateDataTable 1", "ConfigColumnas.cs", ex);
                        MessageBox.Show(ex.Message + " function: BulkUpdateDataTable 1. class:ConfigColumnas.cs");
                    }
                }

                sqlcomm.CommandText =
                    "UPDATE T SET T.Usuario = Temp.Usuario, T.Campo = Temp.Campo, T.Estatus = Temp.Estatus, T.Orden = Temp.Orden " +
                    "FROM " + dt.TableName + " T INNER JOIN #TmpTable Temp ON t.ID = temp.ID; DROP TABLE #TmpTable;";
                sqlcomm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BulkUpdateDataTable 2", "ConfigColumnas.cs", ex);
                MessageBox.Show(ex.Message + " function: BulkUpdateDataTable 2, class: ConfigColumnas.cs");
            }
        }


        public void updateColumnas(string usuario, string campo, int orden, bool estatus)
        {
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = "update DM0312ColumnasUsuarios WITH (ROWLOCK) set orden =" + orden + " , estatus ='" + estatus +
                        "'  where usuario='" + usuario + "' and campo='" + campo + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("updateColumnas", "ConfigColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }


        public void InsertColumnas(string campo, int orden, bool estatus)
        {
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = "INSERT INTO DM0312ColumnasUsuarios (Usuario, Campo,Estatus,Orden) VALUES ('" +
                        ClaseEstatica.Usuario.Usser + "','" + campo + "','" + estatus + "','" + orden + "')";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertColumnas", "ConfigColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public string UsuarioConfigurado(string campo)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                query = "SELECT usuario  FROM DM0312ColumnasUsuarios with (nolock) where usuario = '" +
                        ClaseEstatica.Usuario.Usser + "' and campo = '" + campo + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TipoColor", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }

        public string TipoColor(string acceso)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                query = "SELECT top 1 Descripcioncampo  FROM DM0312ConfiguracionColumnas with (nolock) WHERE acceso='" +
                        acceso + "' and campo='Color' and forma='ConfiguracionColumnas' and estatus=1";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TipoColor", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }


        public string ActualizarColor(string color, string acceso, int opc)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                if (opc == 1)
                    query =
                        "UPDATE DM0312ConfiguracionColumnas SET ESTATUS=1 WHERE CAMPO='Color' and descripcioncampo='" +
                        color + "' and acceso= '" + acceso + "'";
                else
                    query =
                        "UPDATE DM0312ConfiguracionColumnas SET ESTATUS=0 WHERE CAMPO='Color' and descripcioncampo='" +
                        color + "' and acceso= '" + acceso + "'";


                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TipoColor", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }
    }
}