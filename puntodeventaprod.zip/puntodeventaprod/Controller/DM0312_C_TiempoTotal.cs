﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_TiempoTotal
    {
        /// <summary>
        ///     Inserta o elimina el detalle de venta de valera
        /// </summary>
        /// <param name="mov">string</param>
        /// <param name="id">int</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public DataTable DatosTiempoTotal(string mov, int id)
        {
            DataTable listaTiempoTotal = new DataTable();
            string query = "select* from Fn_DM0112TiempototalServicasaCred('" + mov + "'," + id + ")";
            SqlCommand command = null;
            try
            {
                command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.Text;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(listaTiempoTotal);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosTiempoTotal", "DM0312_C_TiempoTotal", ex);
                MessageBox.Show(ex.Message);
            }

            return listaTiempoTotal;
        }
    }
}