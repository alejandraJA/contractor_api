﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class CLimiteCredito
    {
        public List<MLimiteCredito> obteneLimiteCredito()
        {
            List<MLimiteCredito> limiteCredito = new List<MLimiteCredito>();

            try
            {
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Opcion", "ConsultarLimite")
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand("SpVTASLimiteCreditoDima", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                            limiteCredito.Add(new MLimiteCredito
                            {
                                idLimiteCredito = Convert.ToInt32(dr["IdLimTipoDIMA"].ToString()),
                                Mov = dr["Mov"].ToString(),
                                TipoDima = dr["TipoDIMA"].ToString(),
                                PorLimFactDima = Convert.ToInt32(dr["PorcLimFactDIMA"].ToString()),
                                LimiteCredito = float.Parse(dr["LimiteCredito"].ToString()),
                                Clasificacion = dr["Clasificacion"].ToString()
                            });
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }


            return limiteCredito;
        }

        public double obtenerImporteCliente(string sCliente)
        {
            double dImporte = 0;
            try
            {
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Opcion", "ImporteCliente")
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand("SpVTASLimiteCreditoDima", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read()) dImporte = double.Parse(dr["CRMCantidad"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dImporte;
        }

        public int actualizarSaldos(string sCliente, double dImporteCredilana, double dImporteFactura, string sTipoDima)
        {
            int iActualizo = 0;
            try
            {
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Opcion", "ActualizarSaldos")
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@ImporteFacura", dImporteFactura)
                    {
                        SqlDbType = SqlDbType.Money
                    },
                    new SqlParameter("@ImporteCredilana", dImporteCredilana)
                    {
                        SqlDbType = SqlDbType.Money
                    },
                    new SqlParameter("@TipoDima", sTipoDima)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand("SpVTASLimiteCreditoDima", ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read()) iActualizo = int.Parse(dr["Total"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return iActualizo;
        }
    }
}