﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_SolicitudValera
    {
        /// <summary>
        ///     Optiene la informacion de la valera
        /// </summary>
        /// <param name="Val">string</param>
        /// Developer:Erika Perez
        /// Date: 14/11/17
        public DataTable InformacionValera(string Val)
        {
            DataTable dataSet = new DataTable();
            SqlCommand sqlCommand = null;
            string query =
                "select articulo as Articulo,Descripcion1 as Descripcion,Unidad,Impuesto1 as Impuesto,Observaciones='' from art WITH (NOLOCK) where articulo = @Valera";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlParameter sqlParameter = new SqlParameter("@Valera", SqlDbType.VarChar);
                sqlParameter.Value = Val;
                sqlCommand.Parameters.Add(sqlParameter);
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InformacionValera", "DM0312_C_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Inserta o elimina el detalle de venta de valera
        /// </summary>
        /// <param name="item">model</param>
        /// <param name="IdVenta">int</param>
        /// <param name="canal">int</param>
        /// <param name="almacen">string</param>
        /// <param name="agente">string</param>
        /// <param name="op">int</param>
        /// <param name="costo">double</param>
        /// Developer:Erika Perez
        /// Date: 14/11/17
        public bool InsertVentaDSolVal(DM0312_MSolicitudValera item, int IdVenta, int canal, string almacen,
            string agente, int op, double costo)
        {
            DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
            int sucursal = controlador.GetSucursal(almacen);

            int defaultInt = 0;

            string res = string.Empty;

            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0312OperacionesInsDelVentaD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.AddWithValue("@Renglon", 2048);
                cmd.Parameters.AddWithValue("@RenglonSub", defaultInt);
                cmd.Parameters.AddWithValue("@RenglonID", 1);
                cmd.Parameters.Add("@RenglonTipo", SqlDbType.Char).Value = "N";
                cmd.Parameters.Add("@EnviarA", SqlDbType.Int).Value = canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = almacen;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Cantidad", SqlDbType.Float).Value = item.Cantidad;
                cmd.Parameters.Add("@Precio", SqlDbType.Float).Value = item.PrecioUnitario;
                cmd.Parameters.Add("@PrecioSugerido", SqlDbType.Float).Value = item.PrecioUnitario;
                cmd.Parameters.Add("@Impuesto1", SqlDbType.Float).Value = item.impuesto;
                cmd.Parameters.Add("@Costo", SqlDbType.Float).Value = costo;
                cmd.Parameters.AddWithValue("@Paquete", Convert.DBNull);
                cmd.Parameters.Add("@ContUso", SqlDbType.VarChar).Value = almacen;
                cmd.Parameters.Add("@Factor", SqlDbType.Float).Value = 1;
                cmd.Parameters.Add("@Unidad", SqlDbType.VarChar).Value = item.Unidad;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = agente;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                cmd.Parameters.Add("@SucursalOrigen", SqlDbType.Int).Value = ClaseEstatica.Usuario.sucursal;
                cmd.Parameters.Add("@UEN", SqlDbType.Int).Value = ClaseEstatica.Usuario.Uen;
                cmd.Parameters.Add("@PropreListaID", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@OP", SqlDbType.Int).Value = op;
                cmd.Parameters.Add("@DescripcionExtra", SqlDbType.VarChar).Value = item.Observaciones;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res != "OK")
                {
                    MessageBox.Show(res, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaDSolVal", "DM0312_C_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return true;
        }
    }
}