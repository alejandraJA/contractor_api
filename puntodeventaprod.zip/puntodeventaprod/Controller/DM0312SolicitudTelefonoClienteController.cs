﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading;
using Org.BouncyCastle.Utilities.Encoders;
using PuntoVenta.Security;
using PuntoVenta.Utilidades;

namespace PuntoVenta.Controller
{
    public class DM0312SolicitudTelefonoClienteController
    {
        private static DM0312SolicitudTelefonoClienteController _instance;

        public DM0312SolicitudTelefonoClienteController()
        {
            mutex = new Mutex();
        }

        private Mutex mutex { get; }

        public static DM0312SolicitudTelefonoClienteController Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DM0312SolicitudTelefonoClienteController();
                return _instance;
            }
        }

        public string Cliente { get; private set; }
        public string Telefono { get; private set; }
        public string Agente { get; private set; }
        public int IdVenta { get; private set; }

        public void SetCliente(string cliente)
        {
            Cliente = cliente;
        }

        public void SetTelefono(string telefono)
        {
            Telefono = telefono;
        }

        public void SetTelefonoAgente(string agente)
        {
            Agente = agente;
        }

        public void SetIdVenta(int idVenta)
        {
            IdVenta = idVenta;
        }

        private bool TieneMensajesPorEnviar()
        {
            try
            {
                using (SqlCommand command =
                       new SqlCommand(
                           "SELECT IdRegistro FROM TcAAEA00030_EnvioMensajes WITH(NOLOCK) WHERE IdRegistro = @Id AND FechaEnvio = 1 AND IdMensaje = 51",
                           ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    command.CommandType = CommandType.Text;
                    command.Parameters.AddWithValue("@Id", IdVenta);
                    SqlDataReader dr = command.ExecuteReader();
                    return dr.HasRows;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string EnviarSMS()
        {
            try
            {
                mutex.WaitOne();
                string nombreArchivo = string.Empty;
                if (!Telefono.IsPhone()) return "Telefono del Cliente no Valido";
                if (Telefono.Equals(Agente) || string.IsNullOrEmpty(Telefono) || string.IsNullOrEmpty(Agente))
                    return "El numero telefonico del Coordinador y BF no pueden ser iguales";
                using (SqlCommand command = new SqlCommand("SpVTASImpresionFactura", ClaseEstatica.ConexionEstatica))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", IdVenta);
                    command.Parameters.AddWithValue("@UrlArchivo", string.Empty);
                    command.Parameters.AddWithValue("@Tipo", 3);
                    command.Parameters.AddWithValue("@SeEnvio", Telefono);
                    SqlDataReader dt = command.ExecuteReader();
                    while (dt.Read())
                        nombreArchivo = dt["NombreArchivo"].ToString().Replace("-", "_");

                    string escape = new AESSecurityManager().CifrarAES256(nombreArchivo);
                    byte[] arrayEscape = Encoding.UTF8.GetBytes(escape);
                    string encode = Encoding.UTF8.GetString(UrlBase64.Encode(arrayEscape));
                    nombreArchivo = $"https://factura.creditazzo.mx:7212/api/Factura/DescargarFactura/{encode}";
                    dt?.Close();
                    if (TieneMensajesPorEnviar())
                        throw new Exception("Aun hay mensajes por enviar, favor de esperar un momento");
                    /*CONFIGURACION PARA ENVIO DE LINK PARA COORDINADOR*/
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@Id", IdVenta);
                    command.Parameters.AddWithValue("@UrlArchivo", nombreArchivo);
                    command.Parameters.AddWithValue("@Tipo", 1);
                    command.Parameters.AddWithValue("@SeEnvio", Agente);
                    command.ExecuteNonQuery();
                    Utilidades.Utilidades.SendSMSCanal80(Agente, Cliente, IdVenta);
                    /*CONFIGURACION PARA ENVIO DE LINK PARA CLIENTE*/
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@Id", IdVenta);
                    command.Parameters.AddWithValue("@UrlArchivo", nombreArchivo);
                    command.Parameters.AddWithValue("@Tipo", 1);
                    command.Parameters.AddWithValue("@SeEnvio", Telefono);
                    SqlDataReader resultado = command.ExecuteReader();
                    Utilidades.Utilidades.SendSMSCanal80(Telefono, Cliente, IdVenta);
                    while (resultado.Read()) return "Mensaje enviado";
                    throw new Exception("Ocurrio algo al enviar mensaje, intente de nuevo");
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                mutex.ReleaseMutex();
            }
        }
    }
}