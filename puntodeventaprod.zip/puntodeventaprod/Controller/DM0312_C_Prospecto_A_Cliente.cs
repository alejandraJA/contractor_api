﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_Prospecto_A_Cliente
    {
        private readonly DM0312_CVentanaEntrada CVentanaEntrada;

        public DM0312_C_Prospecto_A_Cliente()
        {
            CVentanaEntrada = new DM0312_CVentanaEntrada();
        }

        public string CodCliente { get; set; }
        //DM0312_CVentanaEntrada

        public string CambiarProspectos()
        {
            string User = string.Empty;
            int i = 0;
            User = ClaseEstatica.Usuario.Usser;

            string Usuario = string.Empty;
            try
            {
                if (User.Contains("VENTP"))
                {
                    int iUser = 0;
                    iUser = CVentanaEntrada.permisosCanal(CodCliente);
                    // Valida si el User de ventas puede cambiar dichos canales de venta
                    if (iUser > 0)
                    {
                        i = CVentanaEntrada.permisoCambiar(CodCliente);
                        //Valida si hay movimiento del User para cambiarlo
                        if (i == 1)
                        {
                            List<string> cambios = new List<string>();
                            cambios = CVentanaEntrada.cambiaCliente(CodCliente, 8, User);
                            if (int.Parse(cambios[0]) == 1 && cambios.Count > 0)
                            {
                                CVentanaEntrada.GuardarDomicilioActual(CodCliente);
                                if (cambios[1] != "") Usuario = cambios[1];
                            }
                            else
                            {
                                MessageBox.Show(
                                    "No se pudo cambiar el tipo debido a que el tipo actual del cliente no es prospecto o el tipo ya habia sido cambiado mediante la herramienta",
                                    "Error");
                            }
                        }
                        else
                        {
                            MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente", "Error");
                        }
                        //Fin de validacion movimiento del User para cambiarlo
                    }
                    else
                    {
                        MessageBox.Show("Usuario sin permiso en este canal para asignar cuenta", "Error");
                    }
                }
                else
                {
                    i = CVentanaEntrada.permisoCambiar(CodCliente);
                    //Valida si hay movimiento del usuario para cambiarlo
                    if (i == 1)
                    {
                        List<string> cambios = new List<string>();
                        cambios = CVentanaEntrada.cambiaCliente(CodCliente, 8, User);
                        if (int.Parse(cambios[1]) == 1)
                        {
                            if (cambios[2] != "") Usuario = cambios[2];
                        }
                        else
                        {
                            MessageBox.Show(
                                "No se pudo cambiar el tipo debido a que el tipo actual del cliente no es prospecto o el tipo ya habia sido cambiado mediante la herramienta",
                                "Error");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente", "Error");
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message + " Error en CambiarProspectos", "Error!!");
            }

            return Usuario;
        }

        public void CambiarProspectoSid(string sProspecto, string sCliente)
        {
            try
            {
                SqlParameter[] parametros =
                {
                    new SqlParameter("@vProspecto", sProspecto)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@vCliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand("SHM_ACTUALIZAR_PROSPECTO",
                           ClaseEstatica.ConexionEstaticaAndroidSid))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parametros);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public IDictionary<int, double> GetLineaCredito(int iOpcion)
        {
            SqlDataReader dr = null;

            IDictionary<int, double> Diccionario = new Dictionary<int, double>();
            try
            {
                string query = string.Empty;
                switch (iOpcion)
                {
                    case 1:
                        query = "Select ID,Importe from DM0192ImporteLineaCred WITH(NOLOCK) order by Importe";
                        break;
                    case 2:
                        query =
                            "Select ID,Importe from DM0192ImporteLineaCred WITH(NOLOCK) WHERE tipocredito = 'Dineralia' order by Importe";
                        break;
                }

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        int id = int.Parse(dr[0].ToString());
                        double dato = Convert.ToDouble(dr[1].ToString());
                        Diccionario.Add(id, dato);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Diccionario;
        }

        public string ActualizaLineaCreditoCte(string Cliente, double importe, string CredEsp)
        {
            string return_ = string.Empty;
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0192ActualizaLineaCreditoCte", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@LineaC", SqlDbType.Money).Value = importe;
                cmd.Parameters.Add("@AutCredEspecial", SqlDbType.Char).Value = CredEsp;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        return_ = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show("Metodo ActualizaLineaCreditoCte " + ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return return_;
        }

        public void InsertPolitica(string cliente, string politica)
        {
            string query = string.Empty;
            query = string.Format("UPDATE cte SET CREDITO='" + politica + "' WHERE CLIENTE= '" + cliente + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertPolitica", "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public List<string> LlenaPoliticas()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = "SELECT Credito FROM CteCredito where empresa='mavi'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_MComentariosVenta EmptyModel = new DM0312_MComentariosVenta();
                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaPoliticas", "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }

        public List<DM0312_MCte> GetAvales(string Cliente)
        {
            List<DM0312_MCte> Lista = new List<DM0312_MCte>();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0169FiltroClienteAval", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@ClienteNuevo", SqlDbType.VarChar).Value = Cliente;

                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MCte model = new DM0312_MCte();
                        model.Cliente = dr[0].ToString();
                        model.Nombre = dr[1].ToString();
                        model.Direccion = dr[2].ToString();
                        if (dr[3].ToString() != string.Empty)
                            model.FechaNac = (DateTime)dr[3];
                        model.Colonia = dr[4].ToString();

                        Lista.Add(model);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show("Metodo GetAvales " + ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }

        public string GeneracionCuentaAval(string Aval, string Opcion)
        {
            string res = string.Empty;
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0169GeneracionCuentaAval", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Aval;
                cmd.Parameters.Add("@bandera", SqlDbType.VarChar).Value = Opcion;
                cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = ClaseEstatica.Usuario.Usser;

                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show("Metodo GeneracionCuentaAval " + ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return res;
        }

        public string InsertaAvalCliente(string cliente, string Aval, string Opcion)
        {
            string res = string.Empty;
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0169INSERTAVALCLIENTE", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@cliente", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@idAval", SqlDbType.VarChar).Value = Aval;
                cmd.Parameters.Add("@Proceso", SqlDbType.VarChar).Value = Opcion;
                cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = ClaseEstatica.Usuario.Usser;

                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show("Metodo GeneracionCuentaAval " + ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return res;
        }

        public int CteCtoAvales(string cliente)
        {
            string query =
                string.Format("SELECT Count(Cliente) FROM CteCto With(NoLock) WHERE Tipo ='Aval' and Cliente ='{0}'",
                    cliente);

            int res = 0;

            SqlDataReader dr = null;

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandTimeout = 100;

                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            res = Convert.ToInt32(dr[0].ToString());
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return res;
        }


        //-CreditoEmpresario
        public string GetDescripcionLineaCredito(int id)
        {
            string query = string.Format("select Politica from DM0192ImporteLineaCred with(nolock) WHERE ID ='{0}'",
                id);
            string res = "";

            SqlDataReader dr = null;

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;

                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            return string.IsNullOrEmpty(dr[0].ToString()) ? "" : dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return res;
        }

        //-471
        /// <summary>
        ///     metodo encargado de validar la linea de credito para dineralia
        /// </summary>
        /// <param name="dImporte">importe puesto por el usuario</param>
        /// <returns>retorna true si el importe que se ingresa es menor no igual al establecido</returns>
        public bool validarLineaCredito(double dImporte)
        {
            DataTable dt = new DataTable();
            bool bImporteCorreco = false;
            try
            {
                string sQuery =
                    "select ISNULL(Importe,0) AS Importe from DM0192ImporteLineaCred WHERE TipoCredito = 'Dineralia'";


                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        if (dImporte <= double.Parse(row["Importe"].ToString()))
                            bImporteCorreco = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bImporteCorreco;
        }

        #region //-Dineralia

        public bool validarDineraliaCliente(string sCliente)
        {
            SqlDataReader dr = null;
            bool bDineralia = false;

            try
            {
                string query = "select top 1 sucursal from venta where cliente = '" + sCliente + "' and sucursal = 502";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                bDineralia = dr.HasRows;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return bDineralia;
        }

        public void actualizarLineaCredito(string sCliente)
        {
            SqlDataReader dr = null;

            try
            {
                string query = "UPDATE Cte WITH(ROWLOCK) SET CRMIMPORTE = null WHERE Cliente = '" + sCliente + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }
        }

        public void actualizarMonto(string cliente, double monto)
        {
            string query = string.Empty;
            query = string.Format("UPDATE cte SET CreditoDineralia	= 1, LimiteDineralia = " + monto +
                                  " WHERE CLIENTE= '" + cliente + "'");

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("actualizarMonto", "DM0312_C_Prospecto_A_Cliente", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
    }
}