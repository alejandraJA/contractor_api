﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_CAdminDoc
    {
        public static List<int> ListaTipos;

        public static List<DM0312_MAdminDoc> ListMAdminDoc;

        private List<DM0312_MAdminDoc> ObtenerDocumentosCuenta(string Cuenta, string MovID)
        {
            List<DM0312_MAdminDoc> Lista = new List<DM0312_MAdminDoc>();
            SqlDataReader dr = null;

            string query = string.Empty;

            query =
                "SELECT DISTINCT DOC.[ID] ,[TIPO_DOC],[CLAVE],[DOCUMENTO],[IDAPLICACION],[ID_EXTERNO],[FORMATO],[ID_FOTO],[DIR],[FECHA]" +
                "FROM [AdminDoc].[dbo].[MAVI_DOC_CTE] DOC WITH(NOLOCK)  INNER JOIN [SID].[dbo].[SHM_BURO_CTED]  SD WITH(NOLOCK) ON ID_EXTERNO=IdPrimario  INNER JOIN [ERPMAVI].[INTELISISTMP].[dbo].[VENTA] V WITH(NOLOCK) ON V.OrigenID=Analisis where TIPO_DOC in (19,73,25,38,13) AND CLAVE='" +
                Cuenta + "' AND (ANALISIS='" + MovID + "' OR V.MOVID='" + MovID + "')";

            try
            {
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);

                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        byte[] array;
                        DM0312_MAdminDoc model_ = new DM0312_MAdminDoc();
                        Guid guid = new Guid(dr["ID"].ToString());
                        model_.ID = guid;
                        model_.TIPO_DOC = Convert.ToInt32(dr["TIPO_DOC"].ToString());
                        model_.CLAVE = dr["Clave"].ToString();
                        model_.IDAPLICACION = Convert.ToInt32(dr["IDAPLICACION"].ToString());
                        if (dr["ID_EXTERNO"].ToString() != string.Empty)
                            model_.ID_EXTERNO = Convert.ToInt32(dr["ID_EXTERNO"].ToString());
                        model_.FORMATO = dr["FORMATO"].ToString();
                        model_.ID_FOTO = Convert.ToInt32(dr["ID_FOTO"].ToString());
                        model_.DIR = dr["DIR"].ToString();
                        model_.Fecha = Convert.ToDateTime(dr["Fecha"].ToString());
                        if (File.Exists(model_.DIR)) model_.Imagen = Image.FromFile(model_.DIR, true);
                        array = (byte[])dr["DOCUMENTO"];
                        if (array.Length > 0)
                        {
                            model_.DOCUMENTO = (byte[])dr["DOCUMENTO"];

                            Lista.Add(model_);
                        }
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CAdminDoc", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        public List<DM0312_MAdminDoc> DocumentosAdjuntos(string CodCliente, string MovID)
        {
            List<DM0312_MAdminDoc> Res = new List<DM0312_MAdminDoc>();
            ListMAdminDoc = ObtenerDocumentosCuenta(CodCliente, MovID);

            return ListMAdminDoc;
        }
    }
}