﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using fnPassword;

//Autor:Rodolfo Sanchez
//Modulo:Punto de venta
//Descripcion: Redimir o generar puntos
//Fecha:31/10/2017
namespace PuntoVenta.Controller
{
    public class DM0312_C_Redime
    {
        #region GeneraDima

        //-Cambio Monedero VIU
        public string GetSerieMonedero(int idventa)
        {
            string rest = string.Empty;

            string query = string.Format(
                "SELECT DISTINCT CASE WHEN (V.UEN=2) THEN C.SerieMonederoVIU Else C.SerieMonedero END SerieMonedero FROM dbo.Venta V WITH(NOLOCK)"
                + " JOIN dbo.Cte C WITH(NOLOCK) ON C.Cliente=V.Cliente "
                + " JOIN dbo.VentasCanalMAVI VC WITH(NOLOCK) ON VC.ID=V.EnviarA "
                + " JOIN dbo.TablaRangoStD MV WITH(NOLOCK) ON Mv.TablaRangoSt='MODALIDAD MONEDERO VIRTUAL' "
                + " AND (CASE ISNULL(MV.NumeroD,0) WHEN 0 THEN V.UEN ELSE MV.NumeroD END) = V.UEN "
                + " AND (CASE WHEN (ISNULL(MV.NumeroA,0) <1) THEN V.Sucursal ELSE MV.NumeroA END) = V.Sucursal "
                + " AND (CASE ISNULL(MV.Nombre,'')WHEN ('') THEN VC.Categoria ELSE MV.Nombre END) = VC.Categoria "
                + "     AND V.ID={0}", idventa);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr["SerieMonedero"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }


            return rest;
        }

        #endregion

        #region Redime

        public bool RedimirMonedero(int IdVenta)
        {
            string name = "spRedimirMovMonederoMAVI";

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = name;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;

                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;

                    cmd.CommandTimeout = 100;

                    cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return false;
            }

            return true;
        }

        #endregion

        #region Genera

        public bool CondicionEjecutar(int idventa)
        {
            bool read = false;

            SqlDataReader dr = null;

            string qery = string.Empty;

            qery = string.Format(
                "SELECT COUNT(1) FROM dbo.Venta V WITH(NOLOCK) JOIN dbo.VentasCanalMAVI VC WITH(NOLOCK) ON VC.ID=V.EnviarA " +
                " JOIN dbo.TablaRangoStD MV WITH(NOLOCK) ON Mv.TablaRangoSt='MODALIDAD MONEDERO VIRTUAL' " +
                " AND (CASE ISNULL(MV.NumeroD,0) WHEN 0 THEN V.UEN ELSE MV.NumeroD END) = V.UEN " +
                " AND (CASE WHEN ISNULL(MV.NumeroA,0) < 1 THEN V.Sucursal ELSE MV.NumeroA END) = V.Sucursal " +
                " AND (CASE ISNULL(MV.Nombre,'') WHEN '' THEN VC.Categoria ELSE MV.Nombre END) = VC.Categoria " +
                " AND V.ID={0}", idventa);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = qery;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read())
                {
                    int res_ = Convert.ToInt32(dr[0].ToString());
                    read = Convert.ToBoolean(res_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return read;
        }

        public bool GenerarMonedero(int IdVenta)
        {
            string name = "spGenerarMovMonederoMAVI";

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = name;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;

                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;

                    cmd.CommandTimeout = 100;

                    cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return false;
            }

            return true;
        }

        public bool InsertInTarjetaSerieMovMAVI(int idventa, string serie, int sucursal, double importe)
        {
            string res = string.Empty;

            SqlDataReader dr = null; // new SqlDataReader();

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0312TarjetaSerieMovMAVI";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 100;

                cmd.Parameters.Add("@IdVenta", SqlDbType.Int).Value = idventa;
                cmd.Parameters.Add("@Serie", SqlDbType.VarChar).Value = serie;
                cmd.Parameters.Add("@Sucursal", SqlDbType.VarChar).Value = sucursal;
                if (importe == 0)
                    cmd.Parameters.Add("@importe", SqlDbType.Money).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("@importe", SqlDbType.Money).Value = importe;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res == "OK")
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return false;
            }

            finally
            {
                dr.Close();
            }
        }

        public bool validarCanal76(int idVenta)
        {
            int res = 0;

            SqlDataReader dr = null;

            string query = string.Format("Select count(*) From Venta With(NoLock) Where EnviarA=76 and ID={0}",
                idVenta);

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandTimeout = 100;

                    dr = cmd.ExecuteReader();
                }

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return false;
            }

            finally
            {
                dr.Close();
            }

            if (res == 0)
                return true;
            return false;
        }

        public bool AutorizaMonedero(int idventa, string user, string pwd)
        {
            DM0312_C_UsuarioDescuentoIncremento cnn = new DM0312_C_UsuarioDescuentoIncremento();
            int res = 0;

            SqlDataReader dr = null;

            string pwd_ = string.Empty;


            //pwd_ = cnn.EncriptMD5(pwd);
            pwd_ = Intelisis.getHash(pwd, "P");

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "SP_MAVIDM0173AutorizaMonedero";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandTimeout = 100;

                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idventa;
                    cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = user;
                    cmd.Parameters.Add("@Contrasena", SqlDbType.VarChar).Value = pwd_;


                    dr = cmd.ExecuteReader();
                }

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            if (res != 0)
            {
                MessageBox.Show("Usuario Y/O Contraseña no valida", "Error");
                return false;
            }

            return true;
        }

        #endregion

        #region RedimeDima

        public string GetMonederoVirtual(string cliente, int iUen)
        {
            string read = string.Empty;
            SqlDataReader dr = null;
            string qery =
                string.Format(
                    "SELECT Serie FROM TarjetaMonederoMAVI WITH(NOLOCK) WHERE estatus = 'ACTIVA' AND TipoMonedero = 'VIRTUAL' AND Cliente = '{0}' and Uen = {1}",
                    cliente, iUen);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = qery;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return string.Empty;

                while (dr.Read()) read = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime ", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return read;
        }

        public double importeMon(int idVenta)
        {
            double importe = 0.0;
            SqlDataReader dr = null;
            string qery = string.Empty;

            qery = string.Format(" select preciototal from venta WITH(NOLOCK) where id= '{0}'", idVenta);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = qery;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();


                if (dr.HasRows)
                    while (dr.Read())
                        importe = Convert.ToDouble(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime ", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return importe;
        }


        public bool ValidarUsuarios(int idventa, bool flag)
        {
            int monedero = 0;

            int venta = 0;

            string Monedero = string.Format("SELECT N=COUNT(ID) FROM DM0173UsrValidoMonedero WITH(NOLOCK) WHERE ID={0}",
                idventa);

            string Venta = string.Format("Select Count(*) From  Venta WITH(NOLOCK) where EnviarA=76 and ID={0}",
                idventa);

            SqlDataReader drm = null;

            SqlDataReader dr = null;

            try
            {
                //DM0173UsrValidoMonedero
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = Monedero;

                drm = cmd.ExecuteReader();

                if (drm.HasRows)
                    while (drm.Read())
                        monedero = Convert.ToInt32(drm[0].ToString());

                //Venta
                SqlCommand cmd_ = new SqlCommand();
                cmd_.Connection = ClaseEstatica.ConexionEstatica;
                cmd_.CommandType = CommandType.Text;
                cmd_.CommandText = Venta;

                dr = cmd_.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        venta = Convert.ToInt32(dr[0].ToString());

                if (flag)
                {
                    if (venta == 1)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
                drm.Close();
            }

            if ((monedero > 0) & (venta > 0))
                return true;
            return false;
        }

        public bool TablaNumD()
        {
            int res = 0;

            string TablaNumD =
                string.Format(
                    "SELECT COUNT(Numero) FROM dbo.TablaNumD WITH(NOLOCK) WHERE TablaNum='SUCURSALES RDP' AND CAST(Numero AS INT)={0}",
                    ClaseEstatica.Usuario.sucursal);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = TablaNumD;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());
                else
                    return false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            if (res == 1)
                return true;
            return false;
        }

        public bool RegistraRedencion(int idVenta, string serie, double importe)
        {
            try
            {
                //execute SP_InsertaTarjetaMonVirtual
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "SP_InsertaTarjetaMonVirtual";
                    cmd.CommandTimeout = 99999;

                    cmd.Parameters.Add("@Emp", SqlDbType.VarChar).Value = "MAVI";
                    cmd.Parameters.Add("@Mod", SqlDbType.VarChar).Value = "VTAS";
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idVenta;
                    cmd.Parameters.Add("@Ser", SqlDbType.VarChar).Value = serie;
                    cmd.Parameters.Add("@Imp", SqlDbType.Money).Value = importe;
                    cmd.Parameters.Add("@Suc", SqlDbType.Int).Value = ClaseEstatica.Usuario.sucursal;

                    cmd.ExecuteNonQuery();
                }

                //execute  spRedimirMovMonederoMAVI
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "spRedimirMovMonederoMAVI";
                    cmd.CommandTimeout = 100;

                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idVenta;

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);

                return false;
            }


            return true;
        }

        #endregion

        #region adicionales

        public string GetMonedero(string cliente)
        {
            string read = string.Empty;
            SqlDataReader dr = null;
            string qery = string.Empty;

            qery = string.Format("SELECT Serie FROM TarjetaMonederoMAVI WITH(NOLOCK) where Cliente='{0}'", cliente);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = qery;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return string.Empty;

                while (dr.Read()) read = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime ", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return read;
        }

        public double GetSaldo(string cuenta)
        {
            double res = 0;
            SqlDataReader dr = null;
            string query = string.Format(" SELECT dbo.FnVTASCalcularSaldo('{0}','{1}')", cuenta,
                ClaseEstatica.Usuario.Uen);


            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.CommandTimeout = 100;

                    dr = cmd.ExecuteReader();
                }

                if (!dr.HasRows)
                    return 0;

                while (dr.Read())
                    if ((dr[0].ToString() == string.Empty) | (dr[0].ToString() == null))
                        return 0;
                    else
                        res = Convert.ToDouble(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return 0;
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public int MostrarUsrValido(int idventa)
        {
            SqlDataReader dr = null;

            int res = 0;

            string query = string.Format("Select count(*) From Venta With(NoLock) Where EnviarA=76 AND ID={0}",
                idventa);

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.CommandTimeout = 100;

                    dr = cmd.ExecuteReader();
                }

                if (!dr.HasRows)
                    return 0;

                while (dr.Read()) res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
                return 0;
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public bool ValidaTablasSHM(int idVenta, string serie)
        {
            bool res = false;

            int countTarSerie = 0;

            int countSHM_MonVirtual = 0;

            string TarjetaSerie =
                string.Format("SELECT COUNT(*) FROM TarjetaSerieMovMAVI WITH(NOLOCK) WHERE ID={0} AND Serie='{1}'",
                    idVenta, serie);

            string SHM_MonVirtual = string.Format(
                "SELECT COUNT(*) FROM SHM_MonVirtual_RegistraRedencion WITH(NOLOCK) WHERE IDSol={0}" +
                " AND Serie='{1}'", idVenta, serie);

            SqlDataReader dr = null;


            try
            {
                //TarjetaSerieMovMavi
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = TarjetaSerie;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) countTarSerie = Convert.ToInt32(dr[0].ToString());

                if (countTarSerie == 0)
                    return false;
                else
                    res = true;

                dr.Close();

                dr = null;


                //SHM_MonVirtual
                SqlCommand cmd_ = new SqlCommand();
                cmd_.Connection = ClaseEstatica.ConexionEstatica;
                cmd_.CommandText = SHM_MonVirtual;
                cmd_.CommandType = CommandType.Text;

                dr = cmd_.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) countSHM_MonVirtual = Convert.ToInt32(dr[0].ToString());

                if (countSHM_MonVirtual == 0)
                    return false;
                else
                    res = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }


            return res;
        }


        public bool validarMonedero(string codigo, int nuevo)
        {
            SqlDataReader dr = null;
            bool flag = false;
            try
            {
                string query = string.Format(" SELECT dbo.fnMonederoDV('{0}','{1}')", codigo, nuevo);
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        flag = Convert.ToBoolean(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return flag;
        }


        public int GetCanalVenta(int idventa)
        {
            int rest = 0;

            string query = string.Format("select EnviarA from venta with(nolock) where id={0}", idventa);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = Convert.ToInt32(dr["EnviarA"].ToString().Trim());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Redime", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }


        /// <summary>
        ///     Consultar si el usuario a validar monedero es correcto
        /// </summary>
        /// <param name="TipoCanal">string</param>
        /// Developer: Erika Perez
        /// Date: 17/11/18
        public List<string> ValidaUsrMone(string usuario)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = string.Format(
                    "SELECT top 1 Usuario,Contrasena FROM Usuario WITH (NOLOCK)  WHERE estatus='alta' and Usuario = '{0}' ",
                    usuario);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Lista.Add(dr[0].ToString());
                        Lista.Add(dr[1].ToString());
                    }
                else
                    Lista.Add("NO");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaUsrMone", "DM0312_CMonederoxRedimir", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        /// <summary>
        ///     ya validados los telefonos del cliente los inserta
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Usuario">string</param>
        /// <param name="Sucursal">int</param>
        /// <param name="Telefono">string</param>
        /// <param name="TipoTel">string</param>
        /// Developer: Erika Perez
        /// Date: 28/09/17
        public int ValidaContraMenu(int id, string usuario, string contra)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MAVIDM0173AutorizaMonedero ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuario;
                cmd.Parameters.Add("@Contrasena", SqlDbType.VarChar).Value = contra.ToUpper();
                //cmd.CommandTimeout = 9999999;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        valor = int.Parse(dr[0].ToString());
                else
                    valor = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaContraMenu", "DM0312_CRedime", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return valor;
        }

        #endregion
    }
}