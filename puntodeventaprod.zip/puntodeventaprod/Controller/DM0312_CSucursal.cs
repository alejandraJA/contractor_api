﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_CSucursal
    {
        private List<DM0312_MSucursal> ListaSucursal;

        public List<DM0312_MSucursal> ObtenerSucursales()
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;

                query = "SELECT Sucursal, Nombre, Direccion, DireccionNumero, DireccionNumeroInt," +
                        " Delegacion, Colonia, Poblacion, Estado,Pais, CodigoPostal, Grupo " +
                        " FROM Sucursal order by Sucursal";

                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                DM0312_MSucursal EmptyModel = new DM0312_MSucursal();

                ListaSucursal = new List<DM0312_MSucursal>();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MSucursal model = new DM0312_MSucursal();

                        model.Sucursal = Convert.ToInt32(dr["Sucursal"].ToString());
                        model.Nombre = dr["Nombre"].ToString();
                        model.Direccion = dr["Direccion"].ToString();
                        model.DireccionNumero = dr["DireccionNumero"].ToString();
                        model.DireccionNumeroInt = dr["DireccionNumeroInt"].ToString();
                        model.Delegacion = dr["Delegacion"].ToString();
                        model.Colonia = dr["Colonia"].ToString();
                        model.Poblacion = dr["Poblacion"].ToString();
                        model.Estado = dr["Estado"].ToString();
                        model.Pais = dr["Pais"].ToString();
                        model.CodigoPostal = dr["CodigoPostal"].ToString();
                        model.Grupo = dr["Grupo"].ToString();

                        ListaSucursal.Add(model);
                    }
                else
                    ListaSucursal.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                dr.Close();
            }

            return ListaSucursal;
        }
    }
}