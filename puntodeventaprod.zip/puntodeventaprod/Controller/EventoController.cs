﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

// 1286 Reactivacion GESSY
namespace PuntoVenta.Controller
{
    public class EventoController
    {
        private readonly CDetalleVenta detalleVentaControlador = new CDetalleVenta();

        public bool InsertaEvento(ModelAgregaEvento EventoNuevo)
        {
            bool respuesta = false;

            try
            {
                int validaInsert = 0;
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312InsertaEventos", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                sqlCommand.Parameters.AddWithValue("@Agente", EventoNuevo.agente);
                sqlCommand.Parameters.AddWithValue("@Clave", EventoNuevo.clave);
                sqlCommand.Parameters.AddWithValue("@Modulo", EventoNuevo.modulo);
                sqlCommand.Parameters.AddWithValue("@Id", EventoNuevo.idVenta);
                sqlCommand.Parameters.AddWithValue("@Fecha", EventoNuevo.fecha);
                sqlCommand.Parameters.AddWithValue("@Evento", EventoNuevo.evento);
                sqlCommand.Parameters.AddWithValue("@Sucursal", EventoNuevo.sucursal);
                sqlCommand.Parameters.AddWithValue("@Usuario", EventoNuevo.usuario);
                sqlCommand.Parameters.AddWithValue("@Tipo", EventoNuevo.tipo);
                sqlCommand.Parameters.AddWithValue("@Estatus", EventoNuevo.estuatus);
                sqlCommand.Parameters.AddWithValue("@Situacion", EventoNuevo.situacion);
                sqlCommand.Parameters.AddWithValue("@CitaCliente", EventoNuevo.citaCliente);
                sqlCommand.Parameters.AddWithValue("@CitaAval", EventoNuevo.citaaval);
                sqlCommand.Parameters.AddWithValue("@CitaFecha", EventoNuevo.citaFecha);
                sqlCommand.Parameters.AddWithValue("@CitaHora", EventoNuevo.citaHora);
                sqlCommand.Parameters.AddWithValue("@TipoEvento", EventoNuevo.TipoEvento);

                validaInsert = sqlCommand.ExecuteNonQuery();

                if (validaInsert > 0 || validaInsert == -1)
                {
                    respuesta = true;

                    //-RQ Forma de Pago Negativa Buro
                    if (EventoNuevo.mov == "Analisis Credito" &&
                        (EventoNuevo.clave == "MEN06872" || EventoNuevo.clave == "MEN06940"))
                    {
                        int check = 0;
                        if (EventoNuevo.clave == "MEN06872") check = 1;
                        else if (EventoNuevo.clave == "MEN06940") check = 0;

                        updateCheckNegativaBC(EventoNuevo.cliente, check);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return respuesta;
        }


        public Agente datosAgente(string Usuario)
        {
            Agente agenteM = new Agente();

            string query =
                @"SELECT top 1 
                p.Cuenta, 
                p.Propiedad, u.Nombre
                  FROM prop p WITH (NOLOCK)
                INNER JOIN Usuario u WITH (NOLOCK) ON p.cuenta = u.Usuario 
                AND p.Tipo = 'Giro' AND u.Usuario = @Usuario";

            SqlDataReader dr = null;
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add("@Usuario", Usuario);
                    cmd.CommandType = CommandType.Text;
                    using (dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            agenteM.ClaveAgente = dr["Cuenta"].ToString();
                            agenteM.Clave = dr["Propiedad"].ToString();
                            agenteM.NombreAgente = dr["Nombre"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return agenteM;
        }


        /// <summary>
        ///     Metodo que permite ingresar registro en la DB tabla CtaBitacora
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public bool InsertaNota(string modulo, string cuenta, string evento, string usuario)
        {
            bool temp = false;
            try
            {
                int validaInsert = 0;
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312InsertaNotas", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Modulo", modulo);
                sqlCommand.Parameters.AddWithValue("@Cuenta", cuenta);
                sqlCommand.Parameters.AddWithValue("@Evento", evento);
                sqlCommand.Parameters.AddWithValue("@Usuario", usuario);
                validaInsert = sqlCommand.ExecuteNonQuery();

                if (validaInsert > 0 || validaInsert == -1)
                    temp = true;
                else
                    temp = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return temp;
        }

        /// <summary>
        ///     Metodo para mandar llamar los agentes dependiendo la sucursal en la que se este
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public List<ModelAgregaEvento> fillAgent(string usuario)
        {
            List<ModelAgregaEvento> list = new List<ModelAgregaEvento>();
            string query =
                "SELECT p.Cuenta, p.Propiedad,  u.Nombre  FROM  prop  p WITH(NOLOCK) INNER JOIN Usuario u WITH(NOLOCK) ON p.cuenta = u.Usuario AND p.Tipo = 'Giro' AND u.Usuario =  '" +
                usuario + "'";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    ModelAgregaEvento addEvent = new ModelAgregaEvento();
                    addEvent.ClaveAgente = dr["Cuenta"].ToString();
                    addEvent.Clave = dr["Propiedad"].ToString();
                    addEvent.NombreAgente = dr["Nombre"].ToString();
                    list.Add(addEvent);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return list;
        }

        public string nombreAgente(string agente)
        {
            string nombre = "  ";
            string query = @"SELECT top 1 Nombre
                FROM Agente WITH (NOLOCK)
                where agente = @Agente";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Agente", agente);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read()) nombre = dr[0].ToString();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return nombre;
        }

        public string nombreUsuario(string Usuario)
        {
            string nombre = null;
            string query = @"Select nombre
            from usuario
            where usuario = @usuario";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Usuario", Usuario);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read()) nombre = dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return nombre;
        }

        public string getDescripcionEvento(string ClaveEvento)
        {
            string descripcion = null;
            string query = @"Select Descripcion
            from MAVIClaveSeguimiento with (nolock)
            where Clave = @Clave";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Clave", ClaveEvento ?? "");
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read()) descripcion = dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return descripcion;
        }

        public ModelAgregaEvento ultimoEvento(int Id)
        {
            ModelAgregaEvento eventoNuevo = new ModelAgregaEvento();

            string query = @"
            SELECT top 1 
              mb.Clave,
              cg.Descripcion,
              mb.Evento
            FROM MovBitacora mb WITH (NOLOCK)
              LEFT JOIN MAVIClaveSeguimiento cg WITH (NOLOCK) ON cg.Clave = mb.Clave
            WHERE mb.CLAVE like 'MEN%'
              and mb.id = @id
            order by mb.fecha desc";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@id", Id);
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            eventoNuevo.clave = dr[0].ToString();
                            eventoNuevo.descripcion = dr[1].ToString();
                            eventoNuevo.comentario = dr[2].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return eventoNuevo;
        }

        public string ultimaDescripcion(int Id)
        {
            string ultimoEvento = "";

            string query = @"
            SELECT top 1
                  mb.Evento
            FROM MovBitacora mb WITH(NOLOCK) 
                INNER JOIN Usuario u WITH(NOLOCK) ON  u.Usuario = mb.Usuario 
                INNER JOIN MAVIClaveSeguimiento sg WITH(NOLOCK) ON sg.Clave = mb.Clave 
            WHERE mb.id=@Id 
            and mb.Clave in ('VTA10000','VTA00012')
            order by mb.fecha desc";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@id", Id);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                        ultimoEvento = dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return ultimoEvento;
        }

        public string getUltimoUsuarioReactivacion(int Id)
        {
            string usuario = "";

            string query = @"
            SELECT top 1 mb.Agente 
            FROM MovBitacora mb WITH (NOLOCK)
                   INNER JOIN Usuario u WITH (NOLOCK) ON u.Usuario = mb.Usuario
                   INNER JOIN MAVIClaveSeguimiento sg WITH (NOLOCK) ON sg.Clave = mb.Clave
            WHERE mb.Clave in ('VTA10000', 'VTA00012','VTA00050')
              and mb.id = @Id";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@id", Id);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                        usuario = dr[0].ToString();
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, e);
            }

            return usuario;
        }

        public string getNombreCliente(string Cliente)
        {
            SqlDataReader dr;
            string nombre = null;
            string query = @" select top 1 nombre from cte WITH (NOLOCK) where cliente = @cliente";

            try
            {
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.Parameters.AddWithValue("@cliente", Cliente);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        nombre = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return nombre;
        }


        /// <summary>
        ///     Metodo para obtener la situacion dependiendo la clave de evento seleccionada
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public string Situacion(string clave)
        {
            string situacionE = "";

            string query = @"select situacion from MAVIClaveSeguimiento with (nolock) where Clave= @Clave";
            SqlDataReader dr = null;
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Clave", clave);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            situacionE = dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return situacionE;
        }

        /// <summary>
        ///     Metodo que permite llenar forma Clave Seguimiento
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public List<DM0312_MClaveSeguimiento> LlenaComboClaveEvento()
        {
            List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
            SqlDataAdapter adapter = new SqlDataAdapter();
            try
            {
                string query =
                    "SELECT MAVIClaveSeguimiento.Clave, MAVIClaveSeguimiento.Modulo, MAVIClaveSeguimiento.Descripcion, MAVIClaveSeguimiento.Grupo, " +
                    "MAVIClaveSeguimiento.Situacion FROM MAVIClaveSeguimiento WITH(NOLOCK) " +
                    "JOIN Modulo WITH(NOLOCK) ON MAVIClaveSeguimiento.Modulo = Modulo.Modulo " +
                    "WHERE MAVIClaveSeguimiento.Clave <> 'VTA99999' AND Clave IN (Select Clave From dbo.Fn_MaviDM0114VisualCalif('" +
                    ClaseEstatica.Usuario.Usser + "'))";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    DM0312_MClaveSeguimiento model_ = new DM0312_MClaveSeguimiento();
                    model_.Clave = sqlDataReader["Clave"].ToString();
                    model_.Modulo = sqlDataReader["Modulo"].ToString();
                    model_.Descripcion = sqlDataReader["Descripcion"].ToString();
                    model_.Grupo = sqlDataReader["Grupo"].ToString();
                    model_.Situacion = sqlDataReader["Situacion"].ToString();
                    listModel.Add(model_);
                }

                sqlDataReader.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listModel;
        }


        //-RQ Forma de Pago Negativa Buro
        public void updateCheckNegativaBC(string cliente, int check)
        {
            DateTime fecha = DateTime.Now;
            string query =
                string.Format(
                    "update cte with(rowlock) set NegativaBC = {0}, Usuario='{1}', UltimoCambio='{2}'  where Cliente='{3}'",
                    check, ClaseEstatica.Usuario.Usser, fecha.ToString("yyyy-MM-dd HH:mm:ss"), cliente);

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public bool accesoPorNomina(string nomina, string password)
        {
            bool valid = false;

            string query = @"select top 1 * from PA_USUARIOS_ANDROID where NOMINA = '" + nomina +
                           "' and PASSWORD = LOWER(CONVERT(varchar(32), HASHBYTES('MD5', '" + password + "'), 2))";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroidS);

                SqlDataReader dr = command.ExecuteReader();
                valid = dr.HasRows;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return valid;
        }

        public int getCantidadDeCitas(int id)
        {
            int citas = 0;

            string query = @"SELECT Count('Citas') as Citas
            FROM MovBitacora mb WITH (NOLOCK)
                   LEFT JOIN MAVIClaveSeguimiento cg WITH (NOLOCK) ON cg.Clave = mb.Clave
            WHERE mb.id = @Id
              and mb.Clave = 'VTA10001'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                command.Parameters.AddWithValue("@id", id);

                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        citas = (int)dr["citas"];
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return citas;
        }


        public int getStdMAXCITAS()
        {
            int maxCitasAllowed = 0;

            string query =
                "select top 1 valor as  valor from tablaSTD with (nolock) where tablaST = 'CONFDIASAGENDACITA' and nombre = 'MAXCITAS'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        maxCitasAllowed = Convert.ToInt32(dr["valor"]);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return maxCitasAllowed;
        }

        public int getStdDIASHABIL()
        {
            int DIASHABIL = 0;

            string query = @"select valor
              from tablaSTD with (nolock)
              where tablaST = 'CONFDIASAGENDACITA'
                and nombre = 'DIASHABIL'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        DIASHABIL = Convert.ToInt32(dr["valor"] ?? 0);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
            }

            return DIASHABIL;
        }

        public int getCantidadReactivaciones(string usuario)
        {
            int respuesta = 0;

            string query = @"SELECT dbo.FnCREDICantidadReactivaciones('" + usuario + "')";

            string CadenafnDM0138validaCte =
                detalleVentaControlador.EjecutaComandosSQL(query, null, null, string.Empty);

            try
            {
                respuesta = Convert.ToInt32(CadenafnDM0138validaCte);
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                //sbp_EstatusPrograma.Text = @"Error: " + e.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return respuesta;
        }


        public DateTime FechaActualServidor()
        {
            DateTime fecha = new DateTime();
            string query = "select GETDATE()";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) fecha = Convert.ToDateTime(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    "DM0312_C_ExploradorVenta", ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fecha;
        }


        #region //-ListaNegra

        public bool updateEventoDeMovBitacora(int id, int rid, string comentario)
        {
            bool result = false;
            string query = @"UPDATE MovBitacora WITH (ROWLOCK)
            SET Evento = @comentario
            WHERE id = @id
              and rid = @rid";

            try
            {
                SqlCommand sCMD = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                sCMD.Parameters.AddWithValue("@id", id);
                sCMD.Parameters.AddWithValue("@rid", rid);
                sCMD.Parameters.AddWithValue("@comentario", comentario);

                sCMD.CommandType = CommandType.Text;
                sCMD.CommandTimeout = 9999999;
                sCMD.ExecuteReader();
                result = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return result;
        }

        #endregion


        public string ultimoEvento(int Id, string ClavesEventos, string sAnd = "")
        {
            string ultimoEvento = "";

            string query = @" 
            select TOP 1 'SIP' from (
              select top 1 clave
                from MovBitacora MB with (nolock)
              where
              mb.id=@Id
              order by mb.rid desc
            ) Evento
            where Clave in (" + ClavesEventos + ")";

            if (!string.IsNullOrEmpty(sAnd))
                query = @" 
            select TOP 1 'SIP' from (
              select top 1 clave, evento as usuario
                from MovBitacora MB with (nolock)
              where
              mb.id=@Id
              order by mb.rid desc
            ) Evento
            where Clave in (" + ClavesEventos + ") " + sAnd;

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@id", Id);

                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows) ultimoEvento = "SI";
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return ultimoEvento;
        }

        /// <summary>
        ///     Validar el acceso del usuario, se oculata el boton Reanalisis
        /// </summary>
        /// <returns></returns>
        public bool ValidarPermiso()
        {
            bool bandera = false;
            using (SqlCommand cmd = new SqlCommand(@"SELECT  *
                                            FROM
                                                TablaStd(NOLOCK)
                                            WHERE
                                            tablast LIKE '%Acceso modulo de reanalisis%' AND
                                            Nombre = @acceso", ClaseEstatica.ConexionEstatica))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@acceso", ClaseEstatica.Usuario.Acceso);
                SqlDataReader dr = cmd.ExecuteReader();
                bandera = dr.HasRows;
            }

            return bandera;
        }

        #region // 2164 Viveollamada

        public List<MClaveEvento> ValidaEvento(int IdVenta)
        {
            List<MClaveEvento> lista = new List<MClaveEvento>();

            MClaveEvento datos = new MClaveEvento();

            datos.MEN00144 = "NO";
            datos.MEN00119 = "NO";
            datos.MEN00120 = "NO";
            datos.MEN00121 = "NO";
            datos.MEN00125 = "NO";
            datos.MEN00133 = "NO";
            datos.MEN00134 = "NO";

            lista.Add(datos);

            string query = "select Clave from MovBitacora WITH(NOLOCK) ";
            query += " where ID = " + IdVenta +
                     " and Clave in('MEN00144', 'MEN00119', 'MEN00120', 'MEN00121', 'MEN00125', 'MEN00133', 'MEN00134')";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                        {
                            if (dr["Clave"].ToString() == "MEN00144") lista[0].MEN00144 = "SI";
                            if (dr["Clave"].ToString() == "MEN00119") lista[0].MEN00119 = "SI";
                            if (dr["Clave"].ToString() == "MEN00120") lista[0].MEN00120 = "SI";
                            if (dr["Clave"].ToString() == "MEN00121") lista[0].MEN00121 = "SI";
                            if (dr["Clave"].ToString() == "MEN00125") lista[0].MEN00125 = "SI";
                            if (dr["Clave"].ToString() == "MEN00133") lista[0].MEN00133 = "SI";
                            if (dr["Clave"].ToString() == "MEN00134") lista[0].MEN00134 = "SI";
                        }
                }

                return lista;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lista;
            }
        }

        /// <summary>
        ///     Metodo encargado de validar si esta encendida la video llamada
        /// </summary>
        /// <returns>retorna true si esta encendida</returns>
        public bool validarVideoLlamada()
        {
            bool bVideollamada = false;

            string query =
                @"select valor from TablaStD with(nolock) where TablaSt = 'DisposicionVideollamada' and CAST(valor AS INT) = 1";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();
                bVideollamada = dr.HasRows;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return bVideollamada;
        }

        #endregion
    }
}