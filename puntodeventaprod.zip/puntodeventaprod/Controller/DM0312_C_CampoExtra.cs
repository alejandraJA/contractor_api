﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta.Controller
{
    internal class DM0312_C_CampoExtra
    {
        private DataTable dt;

        /// <summary>
        ///     Permite obtener  el Estado a partir de la Sucursal
        ///     <returns></returns>
        public string ValidaEstado(int sucursal)
        {
            string estado = "";
            string query = "Select Estado From Sucursal WITH(NOLOCK) Where Sucursal = '" + sucursal +
                           "' order by Estado asc";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) estado = dr.GetString(0);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return estado;
        }

        /// <summary>
        ///     Permite obtener la Delegacion a partir de la Sucursal
        ///     <returns></returns>
        public string ValidaDelegacion(int sucursal)
        {
            string delegacion = string.Empty;
            string query = "Select Delegacion From Sucursal WITH(NOLOCK) Where Sucursal= '" + sucursal +
                           "' order by Delegacion asc";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader rd = sqlCommand.ExecuteReader();
                while (rd.Read()) delegacion = rd.GetString(0);
                rd.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }

            return delegacion;
        }

        /// <summary>
        ///     Permite llenar dataGrid AyudaCodigoPostal
        /// </summary>
        /// <returns>List<DM0312_MCamposExtra></returns>
        public List<DM0312_MCamposExtra> GetDataSucursal(string estado, string delegacion, int codigoPostal,
            DM0312_AyudaCodigoPostal campoExtra)
        {
            List<DM0312_MCamposExtra> modelList = new List<DM0312_MCamposExtra>();
            string query = string.Empty;
            string codigoPostalTemp = string.Empty;
            codigoPostalTemp = Convert.ToString(codigoPostal);
            SqlDataReader dr = null;

            if (codigoPostalTemp != "0")
                query =
                    "SELECT CodigoPostal.Estado, CodigoPostal.Delegacion, CodigoPostal.Colonia, CodigoPostal.CodigoPostal " +
                    "FROM CodigoPostal WITH(NOLOCK) WHERE CodigoPostal.Estado = '" + estado +
                    "' AND CodigoPostal.Delegacion = '" + delegacion + "' AND CodigoPostal.CodigoPostal = " +
                    codigoPostal + " ";
            if (codigoPostalTemp == "0")
                query =
                    "SELECT CodigoPostal.Estado, CodigoPostal.Delegacion, CodigoPostal.Colonia, CodigoPostal.CodigoPostal " +
                    "FROM CodigoPostal WITH(NOLOCK) WHERE CodigoPostal.Estado = '" + estado +
                    "' AND CodigoPostal.Delegacion = '" + delegacion + "'";

            if (campoExtra.txt_Buscar.Text != "")
                query =
                    "SELECT CodigoPostal.Estado, CodigoPostal.Delegacion, CodigoPostal.Colonia, CodigoPostal.CodigoPostal " +
                    "FROM CodigoPostal WITH(NOLOCK) WHERE CodigoPostal.Estado = '" + estado +
                    "' AND CodigoPostal.Delegacion = '" + delegacion + "' AND CodigoPostal.Colonia LIKE '%" +
                    campoExtra.txt_Buscar.Text + "%'  or CodigoPostal.CodigoPostal = '" + campoExtra.txt_Buscar.Text +
                    "' ";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MCamposExtra model_ = new DM0312_MCamposExtra();
                    model_.Estado = dr["Estado"].ToString();
                    model_.Delegacion = dr["Delegacion"].ToString();
                    model_.Colonia = dr["Colonia"].ToString();
                    model_.CodigoPostal = Convert.ToInt32(dr["CodigoPostal"].ToString());
                    modelList.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return modelList;
        }

        /// <summary>
        ///     Permite llenar el comboBox Estado
        ///     Developer: Victor Avila
        /// </summary>
        /// <returns>List<DM0312_MCamposExtra></returns>
        public List<DM0312_MCamposExtra> FillComboEstado()
        {
            List<DM0312_MCamposExtra> modelList = new List<DM0312_MCamposExtra>();
            string query = "Select Estado From CodigoPostal WITH(NOLOCK) Group By estado order by estado asc";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MCamposExtra model_ = new DM0312_MCamposExtra();
                    model_.Estado = dr["Estado"].ToString();
                    modelList.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return modelList;
        }

        /// <summary>
        ///     Permite llenar el comboBox Estado
        ///     Developer: Victor Avila
        /// </summary>
        /// <returns>List<DM0312_MCamposExtra></returns>
        public List<DM0312_MCamposExtra> FillComboDelegacion(string estado)
        {
            List<DM0312_MCamposExtra> modelList = new List<DM0312_MCamposExtra>();
            string query = "Select Delegacion From CodigoPostal WITH(NOLOCK) WHERE Estado = '" + estado +
                           "' Group By Delegacion order by Delegacion asc ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MCamposExtra model_ = new DM0312_MCamposExtra();
                    model_.Delegacion = dr["Delegacion"].ToString();
                    modelList.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return modelList;
        }

        /// <summary>
        ///     Permite ingresar el registro de campos extras a la tabla MovCampoExtra
        /// </summary>
        /// <param name="modulo"></param>
        /// <param name="mov"></param>
        /// <param name="idVenta"></param>
        /// <param name="campoExtra"></param>
        /// <param name="valor"></param>
        public int InsertaCampoExtra(string modulo, string mov, int idVenta, string campoExtra, string valor)
        {
            int valida = 0;
            if (valor != null)
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("SpMovCampoExtra", ClaseEstatica.ConexionEstatica);
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@Modulo", modulo);
                    sqlCommand.Parameters.AddWithValue("@Mov", mov);
                    sqlCommand.Parameters.AddWithValue("@ID", idVenta);
                    sqlCommand.Parameters.AddWithValue("@CampoExtra", campoExtra);
                    sqlCommand.Parameters.AddWithValue("@Valor", valor);
                    valida = sqlCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                    MessageBox.Show(ex.Message);
                }

            return valida;
        }

        /// <summary>
        /// </summary>
        /// <param name="opcion"></param>
        /// <param name="cliente"></param>
        /// <param name="idVenta"></param>
        /// <param name="sucursal"></param>
        /// <param name="usuario"></param>
        public void InsertaVentaCampoExtra(int opcion, string cliente, int idVenta, int? sucursal = null,
            string usuario = null)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_DM0169VentaCamposExtra", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Opcion", opcion);
                sqlCommand.Parameters.AddWithValue("@Cliente", cliente);
                sqlCommand.Parameters.AddWithValue("@ID", idVenta);
                sqlCommand.Parameters.AddWithValue("@Sucursal", sucursal);
                sqlCommand.Parameters.AddWithValue("@Usuario", usuario);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_CampoExtra", ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de insertar eventos
        /// </summary>
        /// <param name="iIdVenta"></param>
        /// <param name="sEstatus"></param>
        /// <param name="sAgente"></param>
        /// <param name="sClave"></param>
        /// <returns></returns>
        public bool insertarEvento(int iIdVenta, string sEstatus, string sAgente, string sClave, string sComentario)
        {
            bool bInserto = false;
            try
            {
                string sQuery =
                    "INSERT INTO MovBitacora (Modulo, ID, Fecha, Evento, Tipo, Sucursal, Usuario, MovEstatus, Agente, Clave) " +
                    "VALUES('VTAS', @Id, GETDATE(), 'Campos Extra', 'Comentario', @Sucursal, @Usuario, @MovEstatus, @Agente, @Clave); SELECT @@IDENTITY AS [@@IDENTITY]";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.sucursal)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Usuario", ClaseEstatica.Usuario.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@MovEstatus", sEstatus)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Agente", sAgente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Clave", sClave)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bInserto = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bInserto;
        }

        /// <summary>
        ///     Metodo encargado de obtener el tipo de cliente Casa, Nuevo
        /// </summary>
        /// <param name="sCliente">Cliente de la validacion</param>
        /// <param name="iCanal">Canal de venta</param>
        /// <returns>retorna el tipo de cliente Casa, Nuevo</returns>
        public string obtenerTipoCliente(string sCliente, int iCanal)
        {
            string sTipoCliente = string.Empty;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT dbo.fnVTASClienteNuevoCasa(@Cliente,@Canal) AS TipoCliente";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Canal", iCanal)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sTipoCliente = item["TipoCliente"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sTipoCliente;
        }


        /// <summary>
        ///     Metotodo encargado de validar si un cliente tiene un telefono validado
        /// </summary>
        /// <param name="sCliente">cliente a validar el telefono</param>
        /// <returns>retorna true si en clietne tiene un telefono validado</returns>
        public bool verificarTelefonoValido(string sCliente)
        {
            bool bTelefonoValido = false;
            try
            {
                string sQuery = @"SELECT
                                  RowNum,
                                  ValidacionTel
                                FROM(SELECT
                                  ROW_NUMBER() OVER(ORDER BY id_tel DESC) AS RowNum,
                                  ValidacionTel
                                FROM CteTel
                                WHERE cliente = @Cliente) a
                                WHERE RowNum = 1
                                AND ValidacionTel = 1";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bTelefonoValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bTelefonoValido;
        }
    }
}