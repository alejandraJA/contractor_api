﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_ComentariosVenta
    {
        /// <summary>
        ///     Obtiene los modulos de los cuales se agregaron comentarios
        /// </summary>
        public DataTable ObtieneModulos()
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_PuntoDeVentaComentarios", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@opc  ", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = "";
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneModulos", "DM0312_C_ComentariosVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene los comentarios guardados en la tabla fija: DM0312_Comentarios
        /// </summary>
        public List<DM0312_MComentariosVenta> ObtieneComentarios()
        {
            List<DM0312_MComentariosVenta> Lista = new List<DM0312_MComentariosVenta>();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_PuntoDeVentaComentarios", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 2;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = "";
                dr = cmd.ExecuteReader();

                DM0312_MComentariosVenta EmptyModel = new DM0312_MComentariosVenta();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MComentariosVenta model_ = new DM0312_MComentariosVenta();
                        model_.Campo = dr["Campo"].ToString();
                        model_.Modulo = dr["Modulo"].ToString();
                        model_.Comentario = dr["Comentario"].ToString();
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneComentarios", "DM0312_C_ComentariosVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Inserta los comentarios a la tabla fija: DM0312_Comentarios
        /// </summary>
        public bool Inserta(string Campo, string Modulo, string Comentario)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_PuntoDeVentaComentarios", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 3;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = Modulo;
                cmd.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = Comentario;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        existe = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Inserta", "DM0312_C_ComentariosVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }

        /// <summary>
        ///     Actualiza los comentarios a la tabla fija: DM0312_Comentarios
        /// </summary>
        public bool Actualiza(string Campo, string Modulo, string Comentario)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_PuntoDeVentaComentarios", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 4;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = Modulo;
                cmd.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = Comentario;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        existe = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Actualiza", "DM0312_C_ComentariosVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }

        /// <summary>
        ///     Elimina los comentarios a la tabla fija: DM0312_Comentarios
        /// </summary>
        public bool Elimina(string Campo, string Modulo, string Comentario)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_PuntoDeVentaComentarios", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 5;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = Modulo;
                cmd.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = Comentario;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        existe = true; //bool.Parse(dr["Estatus"].ToString()); ;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Elimina", "DM0312_C_ComentariosVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }
    }
}