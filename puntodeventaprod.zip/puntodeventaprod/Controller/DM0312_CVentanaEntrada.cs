﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_CVentanaEntrada
    {
        private DataTable dt;

        public string CambiarTextoVentaPublicoGeneral(int idRecarga = 0)
        {
            return idRecarga > 0 ? "Tiempo Aire Publico General" : "Venta Publico General";
        }

        /// <summary>
        ///     Consulta el buscador de cliente, dependiendo los campos que llene el usuario se realizara una busqueda para
        ///     encontrar el cliente
        /// </summary>
        /// <param name="cuenta">string</param>
        /// <param name="cliente">string</param>
        /// <param name="direccion">string</param>
        /// <param name="telefono">string</param>
        /// Developer:Erika Perez
        /// Date: 02/10/17
        public List<DM0312_MVentanaEntrada> ConsultaClientes(string cuenta, string cliente, string direccion,
            string telefono, string CodigoPostal)
        {
            List<DM0312_MVentanaEntrada> Lista = new List<DM0312_MVentanaEntrada>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_MaviDM0312BuscadorClientes", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@BuscarCuenta", SqlDbType.VarChar).Value = cuenta;
                cmd.Parameters.Add("@BuscarNombre", SqlDbType.VarChar).Value = cliente;
                cmd.Parameters.Add("@BuscarDireccion", SqlDbType.VarChar).Value = direccion;
                cmd.Parameters.Add("@BuscarTelefono", SqlDbType.VarChar).Value = telefono;
                cmd.Parameters.Add("@CodigoPostal", SqlDbType.VarChar).Value = CodigoPostal;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MVentanaEntrada model_ = new DM0312_MVentanaEntrada();
                        model_.Codigo = dr["Cliente"].ToString();
                        model_.Nombre = dr["Nombre"].ToString();
                        model_.Direccion = dr["Direccion"].ToString();
                        model_.Telefono = dr["Telefono"].ToString();
                        Lista.Add(model_);
                    }

                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaClientes", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     CLIENTES DADOS DE BAJA
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string ClienteBaja(string Cliente)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = " select cliente from cte WITH (NOLOCK) where cliente = '" + Cliente + "' and estatus='baja'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteExpressCred", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     Optiene la categoria y Uen del canal seleccionado
        /// </summary>
        /// <param name="canal">int</param>
        /// Developer:Erika Perez
        /// Date: 02/10/17
        public List<DM0312_MVentanaEntrada> ConsultaCanal(int canal)
        {
            List<DM0312_MVentanaEntrada> Lista = new List<DM0312_MVentanaEntrada>();
            SqlDataReader dr = null;
            try
            {
                string query;
                query = "SELECT Categoria, Uen FROM VentasCanalMAVI WITH (NOLOCK) WHERE ID = " + canal + " ";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MVentanaEntrada model = new DM0312_MVentanaEntrada();
                        model.Categoria = dr["Categoria"].ToString();
                        model.Uen = int.Parse(dr["Uen"].ToString());
                        Lista.Add(model);
                    }
                else
                    Lista.Add(EmptyModel);

                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaCanal", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Genera el consecutivo para los prospectos de Clientes para la parte de Cliente Express
        /// </summary>
        /// <param name="Tienda">string</param>
        /// Developer:Erika Perez
        /// Date: 10/10/17
        public string ConsultaIdClienteNuevo(string Tienda)
        {
            SqlDataReader dr = null;
            string Codigo = "";
            try
            {
                SqlCommand cmd = new SqlCommand("SP_GeneraConsecutivoCteMavi", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Empresa", SqlDbType.VarChar).Value = Tienda;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MVentanaEntrada model = new DM0312_MVentanaEntrada();
                        model.Codigo = dr[0].ToString();
                        Codigo = model.Codigo;
                    }

                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaIdClienteNuevo", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Codigo;
        }

        /// <summary>
        ///     Valida si el cliente tiene ventas en los canales de contado o apartado
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public int permisosCanal(string Cliente)
        {
            SqlDataReader dr = null;
            int valido = 0;
            try
            {
                string query;

                query =
                    " SELECT DISTINCT CASE WHEN  Count(CteEnviarA.id) >0 THEN 1 ELSE 0 END resultado FROM Cte WITH (NOLOCK) INNER JOIN CteEnviarA WITH (NOLOCK) ON Cte.Cliente = CteEnviarA.Cliente " +
                    " WHERE CteEnviarA.id IN (1,2,5,6) AND Cte.Cliente = '" + Cliente + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        valido = int.Parse(dr[0].ToString());
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("permisosCanal", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return valido;
        }

        /// <summary>
        ///     VERIFICA EL ESTADO DE LAS SUPERVICIONES PARA HACER EL CAMBIO A CUENTA POR 1 REFERENCIA
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public int permisoCambiar(string Cliente)
        {
            SqlDataReader dr = null;
            int puede = 0;
            try
            {
                string query;

                query = " SELECT * FROM  DBO.FN_DM0296ValidaCambioACtaPorEstado ('" + Cliente + "')";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = int.Parse(dr[0].ToString());
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("permisoCambiar", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        /// <summary>
        ///     Optiene la cuenta nueva del cliente despues de pasar por el cliente express
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string ClienteExpressCred(string Cliente)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = " select cliente from cte WITH (NOLOCK) where cliente = '" + Cliente + "'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteExpressCred", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     Metodo para cambiar un prospecto a cliente de manera automatica y mandar llamar la venta
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Digitos">int</param>
        /// <param name="Usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 20/10/17
        public List<string> cambiaCliente(string Cliente, int Digitos, string Usuario)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("spCambiarProspectoACteMAVI", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Prospecto", SqlDbType.VarChar).Value = Cliente;
                cmd.Parameters.Add("@Digitos  ", SqlDbType.Int).Value = Digitos;
                cmd.Parameters.Add("@UsuarioAltaC", SqlDbType.VarChar).Value = Usuario;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Lista.Add(dr[0].ToString());
                        Lista.Add(dr[1].ToString());
                        Lista.Add(dr[2].ToString());
                    }

                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("cambiaCliente", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Manda consultar las valeras existentes y que esten con estatus alta
        /// </summary>
        /// Developer:Erika Perez
        /// Date: 22/10/17
        public List<string> LlenaValera()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                string query = string.Empty;
                query = " select articulo from art WITH (NOLOCK) where FAMILIA='VALERAS' and estatus ='alta'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaValera", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     Guarda el domicilio actual del cliente en el catalogo de datos de entrega
        /// </summary>
        /// <param name="cte">string</param>
        /// Developer:Erika Perez
        /// Date: 20/01/18
        public void GuardarDomicilioActual(string cte)
        {
            try
            {
                string query =
                    "insert into DM0312DatosEntrega(Direccion, Colonia, Poblacion, CodigoPostal, Estado, EntreCalles, TelefonoParticular, TelefonoMovil, Referencia, IDCliente, NumInt, NumExt)  "
                    + $"select Direccion, Colonia, poblacion, codigopostal, estado, entrecalles, 0, 0, '', '{cte}', direccionnumero, direccionnumeroint from cte with(nolock) where Cliente='{cte}'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarDomicilioActual", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public DateTime FechaNacimientoCliente(string cliente)
        {
            DateTime fecha = new DateTime();
            string query = "select top 1 fechanacimiento from cte with (nolock) where cliente ='" + cliente + "'";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr[0].ToString() == "")
                        {
                        }
                        else
                        {
                            fecha = Convert.ToDateTime(dr[0].ToString());
                        }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CVentanaEntrada", ex);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fecha;
        }


        public bool CheckInterv(string codigo)
        {
            bool flag = false;
            string query = "select top 1 SinBonifDIMA from cte with (nolock) where cliente ='" + codigo + "'";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        flag = Convert.ToBoolean(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CVentanaEntrada", ex);
            }
            finally
            {
                dr.Close();
            }

            return flag;
        }

        /// <summary>
        ///     Inserta la direccion actual del cliente siempre y cuando no este agregada en el catalogo de direcciones del cliente
        /// </summary>
        /// <param name="cte">string</param>
        /// Developer:Erika Perez
        /// Date: 21/01/18
        public void GuardarDomicilioActualCasa(string cte)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SpEDM0312_DirecEntrega", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cte;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarDomicilioActualCasa", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }


        public string AccesoVenta(string usuario, int op)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query = string.Empty;
                if (op == 1)
                {
                    query =
                        "select A.USUARIO from UsuarioAcceso  a with (nolock) inner join usuario u with (nolock) on a.usuario=u.usuario where (a.movsedicion like '%vtas.pedido%' OR a.movsedicion like '%vtas.Solicitud Credito%') and u.estatus='alta' and a.Usuario = '" +
                        usuario + "' ";
                }
                else
                {
                    if (op == 2)
                    {
                        query =
                            "select A.USUARIO from UsuarioAcceso  a with (nolock) inner join usuario u with (nolock) on a.usuario=u.usuario where (a.movsedicion like '%vtas.solicitud devolucion%' OR a.movsedicion like '%vtas.sol dev mayoreo%') and u.estatus='alta' and a.Usuario = '" +
                            usuario + "' ";
                    }
                    else
                    {
                        if (op == 3)
                            query =
                                "select A.USUARIO from UsuarioAcceso  a with (nolock) inner join usuario u with (nolock) on a.usuario=u.usuario where a.movsedicion like '%vtas.sol dev unicaja%' and u.estatus='alta' and a.Usuario = '" +
                                usuario + "' ";
                    }
                }

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AccesoVenta", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        /// <summary>
        ///     Manda consultar los movimientos posibles para devolver
        /// </summary>
        /// Developer:Erika Perez
        /// Date: 14/01/17
        public List<string> LlenaMovDev()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            try
            {
                //-CambioMovimientosDevolucion

                //string query = string.Empty;
                //query = string.Format("select mov from movtipo WITH (NOLOCK) where clave='VTAS.F'");
                string query = string.Format(@"SELECT mov.Mov FROM UsuarioAcceso UA WITH(NOLOCK)
                        OUTER APPLY dbo.fnSplit(CAST(UA.MovsEdicion AS VARCHAR(MAX)), CHAR(13)+CHAR(10)) F
                        join movtipo mov with(nolock) on concat(mov.Modulo,'.',mov.Mov)=f.item and mov.Clave='VTAS.F'
                        WHERE UA.Usuario ='{0}'", ClaseEstatica.Usuario.Usser);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaValera", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }

        /// <summary>
        ///     ValidarRFC
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string ValidarRFC(string Cliente)
        {
            SqlDataReader dr = null;
            string rfc = "";
            try
            {
                string query;

                query = " select top 1 rfc from cte WITH (NOLOCK) where cliente = '" + Cliente + "' and estatus='alta'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        rfc = dr[0].ToString();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarRFC", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rfc;
        }

        /// <summary>
        ///     Buscar nombre del cliente
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string NombreCliente(string cte)
        {
            SqlDataReader dr = null;
            string validarRFC = "";
            try
            {
                string query;

                query = " select top 1 nombre from cte WITH (NOLOCK) where cliente = '" + cte + "' and estatus='alta'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        validarRFC = dr[0].ToString();
                else
                    validarRFC = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("NombreCliente", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return validarRFC;
        }

        public string validaVentasFinales(string Cliente, int Canal)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format("select  top 1 mov from venta with (nolock) where cliente= '" + Cliente +
                                      "' and mov in('factura','factura viu','credilana','prestamo personal') and estatus='concluido' and (enviara ='" +
                                      Canal + "'or enviara =76 )");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
                else
                    puede = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaCasa", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        /// <summary>
        ///     Buscar RFC en tabla de clientes finales
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string ValidarRFCBeneficiario(string rfc, string nombre)
        {
            SqlDataReader dr = null;
            string validarRFC = "";
            try
            {
                string query;

                query = " select top 1 clientef from Cte_Final WITH (NOLOCK) where rfc like '" + rfc +
                        "%' and cte_final.ApellidoPaterno+' '+ cte_final.ApellidoMaterno+' '+ cte_final.Nombre='" +
                        nombre + "' and estatus='alta'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        validarRFC = dr[0].ToString();
                else
                    validarRFC = "NO";
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarRFCBeneficiario", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return validarRFC;
        }

        /// <summary>
        ///     Buscar si el cliente tiene facturas pendiente de pago
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string ValidarFacturaSaldo(string cliente)
        {
            SqlDataReader dr = null;
            string fac = "";
            try
            {
                string query;

                query = " select top 1 saldo from cxc  WITH (NOLOCK) where CteFinal = '" + cliente +
                        "' and estatus='pendiente' and mov='documento'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        fac = "SI";
                else
                    fac = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarRFCBeneficiario", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fac;
        }

        /// <summary>
        ///     Buscar RFC en tabla de clientes finales
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string DiasDelUltimoPago(string cliente)
        {
            SqlDataReader dr = null;
            string dias = "";
            try
            {
                string query;

                query = " select top 1 datediff(day,ultimocambio,getdate()) as dias from cxc where CteFinal = '" +
                        cliente + "' and mov ='documento' and estatus='concluido' order by UltimoCambio desc";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        dias = dr[0].ToString();
                else
                    dias = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DiasDelUltimoPago", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dias;
        }

        /// <summary>
        ///     OBTENER LOS DIAS DE LA TABLA DE CONVERCION CREDICDiasTranscurrir
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public int DiasDeCREDICDiasTranscurrir()
        {
            SqlDataReader dr = null;
            int dias = 0;
            try
            {
                string query;

                query = " select top 1 DIAS from CREDICDiasTranscurrir";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        dias = int.Parse(dr[0].ToString());
                else
                    dias = 0;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DiasDelUltimoPago", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dias;
        }


        /// <summary>
        ///     Buscar RFC en tabla de personal de comercializadora
        /// </summary>
        /// <param name="Cliente"></param>
        /// <returns></returns>
        public string ValidarRFCPersonal(string rfc)
        {
            SqlDataReader dr = null;
            string validarRFC = "";
            try
            {
                string query;


                query =
#if CUBOS
                    " select top 1 personal from mavicubos.comercializadora.dbo.personal  WITH (NOLOCK) where registro2 like '" +
                    rfc + "%' and estatus='alta'"
#elif PRODUCCION
                    " select top 1 personal from erpmavi.comercializadora.dbo.personal  WITH (NOLOCK) where registro2 like '" + rfc + "%' and estatus='alta'"
#elif PROSERVER
                    " select top 1 personal from proserver.comercializadora.dbo.personal  WITH (NOLOCK) where registro2 like '" + rfc + "%' and estatus='alta'"
#endif
                    ;
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        validarRFC = dr[0].ToString();
                else
                    validarRFC = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidarRFCPersonal", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return validarRFC;
        }


        /// <summary>
        ///     valida si entra en las reglas de telemarketing y puede afectar segun el total
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string ReglasTelemarketingPrecio(double precio)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = " select precio from VTASCReglasTelemarketing WITH (NOLOCK) where precio >= '" + precio + "'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ReglasTelemarketingPrecio", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     obtiene el tipo de sucursal
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string TipoSuc()
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = " select top 1 tipo from sucursal WITH (NOLOCK) where sucursal = '" +
                        ClaseEstatica.Usuario.sucursal + "' ";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteExpressCred", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     valida si el cliente tiene documentos con saldo pendiente
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string SaldoP(string cte)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = "select top 1 saldo  from cxc with (nolock) where cliente = '" + cte +
                        "' and mov='documento' and estatus='pendiente'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteExpressCred", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     Obtener los dias vencidos de un cliente
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 11/11/17
        public int DiasVencidos(string Cliente)
        {
            SqlDataReader dr = null;
            int Dvencidos = 0;
            try
            {
                string query;
                query = string.Format(
                    "select  top 1 cx.MaxDiasVencidosMAVI from CxcMavi cx with (nolock) inner join cxc c with (nolock) on cx.id=c.id where cliente ='" +
                    Cliente + "' order by cx.MaxDiasVencidosMAVI desc");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        Dvencidos = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DiasVencidos", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Dvencidos;
        }

        /// <summary>
        ///     la fecha de ultima compra del cliente
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Erika Jeanette
        /// Date: 28/07/2018
        public DateTime FechaUltimaCompra(string cte)
        {
            DateTime fecha = new DateTime();
            //string query = ("select top 1 ultimocambio  from cxc with (nolock) where cliente ='" + cte + "' and mov='documento' and estatus='concluido' order by ultimocambio desc");
            /*GESSY 1182 */
            string query =
                "SELECT top 1 c.ultimocambio FROM Cxc c WITH (NOLOCK) INNER JOIN Venta v WITH (NOLOCK) ON c.PadreMAVI = v.Mov AND c.PadreIDMAVI = v.MovID INNER JOIN VentaD vd WITH (NOLOCK) ON v.ID = vd.ID INNER JOIN Art ar WITH (NOLOCK) ON vd.Articulo = ar.Articulo WHERE c.Mov = 'Documento' AND c.Estatus = 'concluido' AND c.Cliente = '" +
                cte +
                "' and  Familia + '-' + linea not in ( SELECT Familia + '-' + linea FROM VTASDExcluidoTelemarketing WITH (NOLOCK) ) order by  C.UltimoCambio desc";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;

                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) fecha = Convert.ToDateTime(dr[0].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_VentanaEntrada", ex);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fecha;
        }


        /// <summary>
        ///     valida si entra en las reglas de telemarketing
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string ReglasTelemarketing(int diasVencidos, int diasUltimaCompra, string tipoS)
        {
            /*GESSY 1182 */
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query =
                    " select top 1 diasvencidos from VTASCReglasTelemarketing WITH (NOLOCK) where tiposucursal = '" +
                    tipoS + "' and diasvencidos >= '" + diasVencidos + "' and diasultimacompra <= '" +
                    diasUltimaCompra + "'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ClienteExpressCred", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     valida si entra en las reglas de telemarketing y puede afectar segun el total
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public double precioMD(int op)
        {
            SqlDataReader dr = null;
            double Precio = 0;
            try
            {
                string query;
                if (op == 1)
                    query =
                        " select top 1 precio from VTASCReglasTelemarketing WITH (NOLOCK) where tipomovimiento='Mercancia'";
                else
                    query =
                        " select top 1 precio from VTASCReglasTelemarketing WITH (NOLOCK) where tipomovimiento='Dinero'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Precio = double.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("precioM", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Precio;
        }


        /// <summary>
        ///     valida si entra en las reglas de telemarketing y puede afectar segun el total
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 14/10/17
        public string ReglasTelemarketingPrecio(double precio, string tipo)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query;

                query = " select precio from VTASCReglasTelemarketing WITH (NOLOCK) where precio >= '" + precio +
                        "' and tipomovimiento = '" + tipo + "' ";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ReglasTelemarketingPrecio", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        public string validaVentasFinalesInternet(string Cliente)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format("select  top 1 mov from venta with (nolock) where cliente= '" + Cliente +
                                      "' and mov in('factura','factura viu','credilana','prestamo personal') and estatus='concluido' and enviara in (3,7)");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaCasa", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        ///// <summary>
        ///// Obtener los dias vencidos de dima de un cliente 
        ///// </summary>
        ///// <param name="Cliente">string</param>
        ///// <param name="Canal">int</param>
        ///// Developer: Erika Perez
        ///// Date: 30/11/18
        //public int DiasVencidosDIMA(string Cliente)
        //{
        //    SqlDataReader dr = null;
        //    int Dvencidos = 0;
        //    try
        //    {
        //        //string query;
        //        //query = string.Format("select  top 1 cx.DiasVencActMAVI from CxcMavi cx with (nolock) inner join cxc c with (nolock) on cx.id=c.id where clienteenviara=76 and  cliente ='" + Cliente + "' order by cx.DiasVencActMAVI desc");
        //        //SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
        //        //cmd.CommandType = System.Data.CommandType.Text;
        //        //dr = cmd.ExecuteReader();

        //        SqlCommand cmd = new SqlCommand("SpCREDIDiasVencidos76", ClaseEstatica.ConexionEstatica);
        //        cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        dr = cmd.ExecuteReader();

        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Dvencidos = int.Parse(dr[0].ToString());
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        DM0312_ErrorLog.RegistraError("DiasVencidosDIMA", "DM0312_CVentanaEntrada", ex);
        //        System.Windows.Forms.MessageBox.Show(ex.Message);
        //    }
        //    finally
        //    {
        //        if (dr != null)
        //            dr.Close();
        //    }
        //    return Dvencidos;
        //}

        /// <summary>
        ///     Obtener los dias vencidos de dima de un cliente
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 30/11/18
        public int DiasVencidosDIMA(string Cliente)
        {
            SqlDataReader dr = null;
            int Dvencidos = 0;
            try
            {
                //string query;
                //query = string.Format("select  top 1 cx.DiasVencActMAVI from CxcMavi cx with (nolock) inner join cxc c with (nolock) on cx.id=c.id where clienteenviara=76 and  cliente ='" + Cliente + "' order by cx.DiasVencActMAVI desc");
                //SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                //cmd.CommandType = System.Data.CommandType.Text;
                //dr = cmd.ExecuteReader();

                SqlCommand cmd = new SqlCommand("SpCREDIDiasVencidos76", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = Cliente;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Dvencidos = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DiasVencidosDIMA", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Dvencidos;
        }

        //-ClienteAfiliador
        public string clienteAfiliador(string cliente)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query = string.Empty;
                query = "select top 1 cliente from DM0264RedDimas a with (nolock) where a.comisionn1 = '" + cliente +
                        "' ";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("clienteAfiliador", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        public string TablastdValeras(string valera)
        {
            SqlDataReader dr = null;
            string puede = "";
            try
            {
                string query = string.Empty;
                query =
                    "select top 1 nombre from tablastd a with (nolock) where a.tablast='ValeMonederoRedDIMA' and a.nombre = '" +
                    valera + "' ";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = "SI";
                else
                    puede = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TablastdValeras", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        #region //-624-BloqueoCuentasGenericas

        /// <summary>
        ///     Metodo encargado de obtener la informacion de la tabla std para validar los accesos y las cuentas genericas
        /// </summary>
        /// <returns>retorna una lista de las cuentas genericas</returns>
        public List<string> obtenerInformacionStd()
        {
            List<string> slistaInformacion = new List<string>();
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT Nombre,valor from tablastd where tablast = 'CUENTAS BLOQUEADAS CONTADO'";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        slistaInformacion.Add(row["Nombre"] + "|" + row["valor"]);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return slistaInformacion;
        }

        #endregion

        /*GESSY 1182 */
        public string validaDocumentosPendientes(string Cliente)
        {
            SqlDataReader dr = null;
            string puede = "NO";

            try
            {
                string query;
                query = string.Format("BEGIN DECLARE @CLIENTE varchar(10) = '" + Cliente +
                                      "' IF EXISTS(SELECT c.movid FROM Cxc c WITH (NOLOCK) INNER JOIN Venta v WITH (NOLOCK) ON c.PadreMAVI = v.Mov AND c.PadreIDMAVI = v.MovID INNER JOIN VentaD vd WITH (NOLOCK) ON v.ID = vd.ID INNER JOIN Art ar WITH (NOLOCK) ON vd.Articulo = ar.Articulo WHERE c.Mov = 'Documento' AND c.Estatus = 'PENDIENTE' AND c.Cliente = @CLIENTE and ar.Familia + '-' + ar.Linea not in ( SELECT Familia + '-' + linea FROM VTASDExcluidoTelemarketing WITH (NOLOCK))) BEGIN select 1 END ELSE BEGIN SELECT 0 END END");
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();

                if (dr.HasRows)
                {
                    while (dr.Read())
                        if (dr[0].ToString() == "1")
                            puede = "SI";
                }
                else
                {
                    puede = "NO";
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validaDocumentosPendientes", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return puede;
        }

        #region //-DimaForaneo

        public bool botonDimaForaneo()
        {
            bool bAcceso = false;
            try
            {
                string sQuery =
                    "select Numero from TablaNumD WITH(NOLOCK) where tablanum = 'DIMASCAMBACEOSUC' AND cast(numero AS INT) = @Sucursal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.sucursal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        #endregion

        #region ValidarVentaCreditazzo

        public int validarVentaCreditazzo(string sCliente)
        {
            int iRespuesta = 0;
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT Valida FROM FnVTASValidaVentaCreditazzo(@Cliente)";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        iRespuesta = int.Parse(item["Valida"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return iRespuesta;
        }

        #endregion


        #region -TarjetaDepartamental

        /// <summary>
        ///     Metodo encargado de obtener el cliente cuando se escanea la tarjeta
        /// </summary>
        /// <param name="sCliente">numero de la tarjeta</param>
        /// <returns></returns>
        public string obtenerClienteCTE(string sTarjeta)
        {
            SqlDataReader dr = null;
            string sCliente = string.Empty;
            try
            {
                string query = string.Empty;
                query = string.Format("select cliente from cte where idCatalogoTarjetas = '{0}'", sTarjeta);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sCliente = dr[0].ToString();
                else
                    sCliente = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerClienteCTE", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sCliente;
        }

        /// <summary>
        ///     Metodo encargado de obtener el cliente cuando se escanea la tarjeta
        /// </summary>
        /// <param name="sCliente">numero de la tarjeta</param>
        /// <returns></returns>
        public string obtenerEstatusCliente(string sCliente)
        {
            SqlDataReader dr = null;
            string sEstatus = string.Empty;
            try
            {
                string query = string.Empty;
                query = string.Format("select estatus from cte where Cliente = '{0}'", sCliente);
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sEstatus = dr[0].ToString();
                else
                    sEstatus = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenerEstatusCliente", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sEstatus;
        }

        #endregion


        #region //-BloqueoVentaCruzadaSuc501

        /// <summary>
        ///     Metodo encargado de obtener todas las sucursales en las que el cliente a realizado alguna compra
        /// </summary>
        /// <param name="sCliente">Numero de cliente</param>
        /// <returns>retorna una lista de todas las sucursales en las que el cliente a realizado alguna compra</returns>
        public List<int> obtenerSucursalesCliente(string sCliente)
        {
            List<int> listaSucursales = new List<int>();

            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format("SELECT DISTINCT(Sucursal) FROM Venta WITH(NOLOCK) WHERE Cliente = '{0}'", sCliente);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        listaSucursales.Add(int.Parse(dr["Sucursal"].ToString()));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return listaSucursales;
        }

        /// <summary>
        ///     metodo encargado de obtener las sucursales que se encuentran registradas en la tablanumerica
        /// </summary>
        /// <returns>Retorna una lista de las sucursales dadas de alta en la tabla numerica</returns>
        public modeloSucursalesVentaCruzadas obtenerSucursalesConfiguradas()
        {
            modeloSucursalesVentaCruzadas modeloSucConfiguradas = new modeloSucursalesVentaCruzadas();

            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery =
                "SELECT CONVERT(INT,nombre) AS Nombre , CONVERT(INT,valor) AS Valor from tablastd  WITH(NOLOCK) WHERE tablast = 'MAXDIASPORSUCURSAL'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        modeloSucConfiguradas = new modeloSucursalesVentaCruzadas();
                        modeloSucConfiguradas.iSucursal = int.Parse(dr["Nombre"].ToString());
                        modeloSucConfiguradas.iDias = int.Parse(dr["Valor"].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return modeloSucConfiguradas;
        }

        /// <summary>
        ///     Metodo encargado de validar si el cliente tiene un movimiento final con estatus concluido
        /// </summary>
        /// <param name="sCliente">Cliente la que se le validaran los movimientos finales</param>
        /// <param name="iSucursal">Sucursal en la que se realizaron los movimientos (501)</param>
        /// <returns>retorna true si tiene movimientos finales, de lo contrario false</returns>
        public bool validarMovimientosFinales(string sCliente, int iSucursal)
        {
            bool bTieneMovimientosFinales = false;

            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format(
                "SELECT COUNT(*) AS Final FROM Venta WHERE Cliente = '{0}' and mov IN( 'Factura', 'Credilana') AND Estatus = 'CONCLUIDO' AND SucursalVenta = {1}",
                sCliente, iSucursal);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    if (dr.Read())
                        if (int.Parse(dr["Final"].ToString()) >= 1)
                            bTieneMovimientosFinales = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return bTieneMovimientosFinales;
        }

        /// <summary>
        ///     Metodo encargado de obtener la fecha del primer movimiento de venta cruzada del cliente
        /// </summary>
        /// <param name="sCliente">cliente al cual se le buscara la fecha del primer movimiento</param>
        /// <param name="iSucursal">sucursal de la venta cruzada</param>
        /// <returns>retorna la fecha del primer movimiento de la venta cruzada</returns>
        public DateTime obtenerFechaPrimerCompra(string sCliente, int iSucursal)
        {
            DateTime dt = new DateTime();
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = string.Format(
                "SELECT TOP 1 FechaEmision AS Fecha FROM Venta WHERE Cliente = '{0}' and Sucursal = {1} order by FechaEmision ASC",
                sCliente, iSucursal);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        dt = DateTime.Parse(dr["Fecha"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dt;
        }

        /// <summary>
        ///     Metodo encargado de obtener la fecha actual del servidor
        /// </summary>
        /// <returns>retorna datetime con la fecha actual</returns>
        public DateTime obtenerFechaActual()
        {
            DateTime dt = new DateTime();
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            sQuery = "SELECT GETDATE() AS Fecha";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        dt = DateTime.Parse(dr["Fecha"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return dt;
        }

        #endregion

        #region Datalogic

        /// <summary>
        ///     Metodo encargado de validar si la caja se encuentra abierta
        /// </summary>
        /// <param name="sCajero">Cajero de la sesion</param>
        /// <param name="sCtaDinero">Cajero de la sesion</param>
        /// <returns>retorna 1 si la caja se encuentra abierta 0 si esta cerrada</returns>
        public int validarCajaAbierta(string sCajero, string sCtaDinero)
        {
            SqlDataReader dr = null;
            int iCajaAbierta = 0;

            try
            {
                string sQuery = string.Empty;
                sQuery = string.Format("SELECT " +
                                       "COUNT(c.CtaDinero) CtaDinero " +
                                       "FROM CtaDinero c WITH(NOLOCK) " +
                                       "JOIN CtaDineroCajero E WITH(NOLOCK) " +
                                       "ON E.CtaDinero = c.CtaDinero " +
                                       "WHERE C.Grupo = 'Cajas' " +
                                       "AND C.Estado = 1 " +
                                       "AND E.Cajero = '{0}' " +
                                       "AND C.CtaDinero = '{1}'", sCajero, sCtaDinero);
                SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        iCajaAbierta = int.Parse(dr[0].ToString());
                else
                    iCajaAbierta = 0;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return iCajaAbierta;
        }

        /// <summary>
        ///     Metodo encargado de validar si la sucursal puede ver los botones de recarga y pago de servicios
        /// </summary>
        /// <returns>Retorna true si la sucursal se encuentra registrada </returns>
        public bool AccesoDatalogic()
        {
            bool bAcceso = false;
            try
            {
                string sQuery =
                    "SELECT Nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'DM0312AccesoDatalogic' and Nombre= @Sucursal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.sucursal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        #endregion

        //-ValidacionTelefonoNip

        #region -ValidacionTelefonoNip

        public string getIdVenta(string cliente)
        {
            try
            {
                string sql = string.Format("select max(id) as id from venta with(nolock) where Cliente='{0}'", cliente);

                using (SqlCommand sqlCommand = new SqlCommand(sql, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    using (SqlDataReader dr = sqlCommand.ExecuteReader())
                    {
                        if (dr.HasRows)
                            if (dr.Read())
                                return !string.IsNullOrEmpty(dr[0].ToString()) ? dr[0].ToString() : "";
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("getIdVenta", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return "";
        }

        public bool LineaCredito(string cliente)
        {
            try
            {
                string sql =
                    string.Format(
                        "select top 1 count(cliente) from cte with(nolock) where CRMImporte is not null and CRMImporte>0 and Cliente='{0}'",
                        cliente);

                using (SqlCommand sqlCommand = new SqlCommand(sql, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    using (SqlDataReader dr = sqlCommand.ExecuteReader())
                    {
                        if (dr.HasRows)
                            if (dr.Read())
                                return int.Parse(dr[0].ToString()) >= 1 ? true : false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LineaCredito", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }

        public bool checkCliente(string cliente)
        {
            try
            {
                string sql = string.Format("select top 1 count(cliente) from cte with(nolock) where Cliente='{0}'",
                    cliente);

                using (SqlCommand sqlCommand = new SqlCommand(sql, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    using (SqlDataReader dr = sqlCommand.ExecuteReader())
                    {
                        if (dr.HasRows)
                            if (dr.Read())
                                return int.Parse(dr[0].ToString()) >= 1 ? true : false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("checkCliente", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return false;
        }

        #endregion
    }
}