﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_Login
    {
        private DataTable dt;

        public List<Usuario> IngresaLogin()
        {
            List<Usuario> list = new List<Usuario>();
            string query =
                " SELECT  ISNULL(Usuario.Nombre,'')Nombre, ISNULL(Usuario.Acceso,'')Acceso, ISNULL(Usuario.Usuario,'')Usuario, ISNULL(Usuario.Sucursal,'')Sucursal, ISnULL(CASE WHEN Sucursal.Grupo = 'MUEBLES AMERICA'THEN 'MA' ELSE Sucursal.Grupo END,'')GrupoEmpresa, ISNULL(GrupoTrabajo,'')GrupoTrabajo,  Sucursal.wUEN as Uen, ISNULL(defCtaDinero,'') AS defCtaDinero,ISNULL(defCajero,'') AS defCajero " +
                " FROM Usuario WITH(NOLOCK) INNER JOIN Sucursal WITH(NOLOCK) ON Usuario.Sucursal = Sucursal.Sucursal and Usuario.Estatus = 'ALTA'";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                if (sqlDataReader.HasRows)
                    while (sqlDataReader.Read())
                    {
                        Usuario model = new Usuario();
                        model.Nombre = sqlDataReader["Nombre"].ToString();
                        model.Acceso = sqlDataReader["Acceso"].ToString();
                        model.Usser = sqlDataReader["Usuario"].ToString();
                        //model.Sucursal = Convert.ToInt32(sqlDataReader["Sucursal"]);
                        model.GrupoEmpresa = sqlDataReader["GrupoEmpresa"].ToString();
                        model.Grupo = sqlDataReader["GrupoTrabajo"].ToString();
                        model.sRefCtaDinero = sqlDataReader["defCtaDinero"].ToString();
                        model.sRefCtaCajero = sqlDataReader["defCajero"].ToString();
                        //if (sqlDataReader["Uen"] != null && sqlDataReader["Uen"].ToString() != string.Empty)
                        //{
                        //    model.Uen = Convert.ToInt32(sqlDataReader["Uen"]);
                        //}
                        list.Add(model);
                    }

                sqlDataReader.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("IngresaLogin", "DM0312_CLogin.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return list;
        }

        //obtener el numero de nomina del usuario
        public void AgenteU()
        {
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText =
                    "select propiedad from prop  with (nolock) where tipo='giro' and rama='USR' and cuenta='" +
                    ClaseEstatica.Usuario.Usser + "'";
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        ClaseEstatica.AgenteU = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Login", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public int Uen(int suc)
        {
            int Uen = 0;
            string query = " SELECT  Sucursal.wUEN as Uen FROM  Sucursal WITH(NOLOCK) where sucursal=" + suc + "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                if (sqlDataReader.HasRows)
                    while (sqlDataReader.Read())
                    {
                        Usuario model = new Usuario();

                        if (sqlDataReader["Uen"] != null && sqlDataReader["Uen"].ToString() != string.Empty)
                            model.Uen = Convert.ToInt32(sqlDataReader["Uen"]);
                        Uen = model.Uen;
                    }

                sqlDataReader.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Uen", "DM0312_CLogin.cs", ex);
                MessageBox.Show(ex.Message);
            }

            return Uen;
        }


        public void SPID()
        {
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "select @@SPID";
                cmd.CommandType = CommandType.Text;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        ClaseEstatica.SPID = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_Login", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }


        public string TipoColor(string acceso)
        {
            SqlDataReader dr = null;
            string Validacion = "";
            try
            {
                string query = string.Empty;
                query = "SELECT top 1 Descripcioncampo  FROM DM0312ConfiguracionColumnas with (nolock) WHERE acceso='" +
                        acceso + "' and campo='Color' and forma='ConfiguracionColumnas' and estatus=1";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Validacion = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TipoColor", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Validacion;
        }

        public List<string> SucursalesAcceso()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;
                query = "SELECT NOMBRE FROM TablaStD WITH (NOLOCK) WHERE TABLAST='SUCURSALESPUNTOVENTA'";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        Lista.Add(dr[0].ToString());
                else
                    Lista = new List<string>();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SucursalesAcceso", "DM0312_C_Login", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        #region -CerradoIntelisis

        //-CerradoIntelisis
        public string GetSessionID(string usuario)
        {
            string sId = string.Empty;
            string query =
                string.Format(
                    "SELECT MAX(Token) FROM acceso WITH(NOLOCK) WHERE Usuario='{0}' and FechaSalida is null and Token = '{1}'",
                    usuario, ClaseEstatica.loginID);

            using (SqlCommand sql = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                sql.CommandType = CommandType.Text;
                SqlDataReader dr = null;

                try
                {
                    sql.ExecuteNonQuery();

                    dr = sql.ExecuteReader();
                    if (dr.HasRows)
                        while (dr.Read())
                            sId = dr[0].ToString();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("existenciaProducto", "CDetalleVenta.cs", ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return sId;
        }


        public void checkSession()
        {
            //var currentSessionId = ClaseEstatica.loginID;
            //var sessionIdDb = GetSessionID(ClaseEstatica.Usuario.Usser);

            //if (currentSessionId != sessionIdDb)
            //{
            //    MessageBox.Show("La sesion anterior ha caducado. Porfavor ingrese de nuevo al punto de venta desde Intelisis.");
            //    Application.Exit();
            //}


#if PRODUCCION && !PRODDEBUG
            //int currentSessionId = ClaseEstatica.loginID;
            //int sessionIdDb = GetSessionID(ClaseEstatica.Usuario.Usser);

            //if (currentSessionId != sessionIdDb)
            //{
            //    MessageBox.Show("La sesion anterior ha caducado. Porfavor ingrese de nuevo al punto de venta desde Intelisis.");
            //    System.Windows.Forms.Application.Exit();
            //}
#endif
        }

        #endregion

        #region CambioVentana

        public bool validarVenta(int iId)
        {
            bool bAcceso = false;
            try
            {
                string sQuery = "SELECT id FROM Venta WITH(NOLOCK) WHERE id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        public DM0312_MExploradorVenta llenarVenta(int iId)
        {
            DM0312_MExploradorVenta venta = new DM0312_MExploradorVenta();
            dt = new DataTable();
            try
            {
                string sQuery = "SELECT id,Cliente,Movid,Mov,Situacion,Sucursal FROM Venta WITH(NOLOCK) WHERE id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        venta = new DM0312_MExploradorVenta
                        {
                            Cliente = item["Cliente"].ToString(),
                            MovId = item["Movid"].ToString(),
                            Mov = item["Mov"].ToString(),
                            Situacion = item["Situacion"].ToString(),
                            Suc = int.Parse(item["Sucursal"].ToString()),
                            ID = int.Parse(item["id"].ToString())
                        };
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return venta;
        }

        #endregion
    }
}