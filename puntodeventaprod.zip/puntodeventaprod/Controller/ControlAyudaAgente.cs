﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class ControlAyudaAgente
    {
        /// <summary>
        ///     Metodo que permite buscar a los Agentes por medio de un TextBox
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public DataTable AyudaAgenteTextoBuscar(string data)
        {
            DataTable list = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            try
            {
                string query =
                    "SELECT Agente.Agente,Agente.Nombre FROM Agente WITH(NOLOCK) WHERE Estatus='alta' AND Agente.Agente LIKE '%" +
                    data + "%' OR Agente.Nombre LIKE '%" + data + "%'";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                adapter.SelectCommand = sqlCommand;
                adapter.Fill(list);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ControlAyudaAgente", ex);
            }

            return list;
        }

        /// <summary>
        ///     Metodo que permite llenar dataGrid pricipal de la forma AyudaAgente
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public DataTable AyudaAgente(int sucursal)
        {
            DataTable list = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            try
            {
                string query =
                    "SELECT a.Agente, a.Nombre FROM Agente a WITH(NOLOCK) INNER JOIN Sucursal s WITH(NOLOCK) ON s.Sucursal = a.SucursalEmpresa" +
                    " WHERE a.Estatus='Alta'  AND a.Categoria IN ('Ventas piso', 'Reactivacion Ventas', 'Ventas Avanzada') AND a.SucursalEmpresa = " +
                    sucursal + " ";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                adapter.SelectCommand = sqlCommand;
                adapter.Fill(list);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "ControlAyudaAgente", ex);
            }

            return list;
        }
    }
}