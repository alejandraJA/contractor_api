﻿//-FlujoMonedero

using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using fnPassword;

namespace PuntoVenta.Controller
{
    internal class DM0312__CLoginCancelacion
    {
        public bool LoginCancelacion(string user, string password)
        {
            try
            {
                using (SqlCommand cmd =
                       new SqlCommand("SELECT dbo.FN_DM0209ComprobarUsuarioContrasena (@Usuario, @Contrasena)",
                           ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Usuario", SqlDbType.VarChar) { Value = user.ToUpper() },
                        new SqlParameter("@Contrasena", SqlDbType.VarChar) { Value = Intelisis.getHash(password, "P") }
                    };

                    cmd.Parameters.AddRange(parametros.ToArray());
                    cmd.CommandTimeout = 60;
                    int res = (int)cmd.ExecuteScalar();

                    return res == 1 ? true : false;
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("LoginCancelacion", "DM0312_CLoginCancelacion", e);
                MessageBox.Show(e.Message);
                return false;
            }
        }

        public bool PermisosCancelacion(string user)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT dbo.FN_DM0209ComprobarPermisos (@Usuario, @Contrasena)",
                           ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;

                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Usuario", SqlDbType.VarChar) { Value = user.ToUpper() },
                        new SqlParameter("@Contrasena", SqlDbType.VarChar)
                            { Value = "" } //SP pide contraseña pero nunca la usa
                    };

                    cmd.Parameters.AddRange(parametros.ToArray());
                    cmd.CommandTimeout = 60;
                    int res = (int)cmd.ExecuteScalar();

                    return res == 1 ? true : false;
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("PermisosCancelacion", "DM0312_CLoginCancelacion", e);
                MessageBox.Show(e.Message);
                return false;
            }
        }
    }
}