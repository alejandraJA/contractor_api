﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CtrlClaveSeguimiento
    {
        /// <summary>
        ///     Metodo que permite llenar el area de texto de la forma Clave Seguimiento
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public List<DM0312_MClaveSeguimiento> LlenaTextoClaveSeguimiento(string data)
        {
            List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlDataReader sqlDataReader = null;
            try
            {
                string query =
                    "SELECT MAVIClaveSeguimiento.Clave, MAVIClaveSeguimiento.Modulo, MAVIClaveSeguimiento.Descripcion, MAVIClaveSeguimiento.Grupo, " +
                    "MAVIClaveSeguimiento.Situacion " +
                    "FROM MAVIClaveSeguimiento WITH(NOLOCK) " +
                    "JOIN Modulo WITH(NOLOCK) ON MAVIClaveSeguimiento.Modulo=Modulo.Modulo WHERE (MAVIClaveSeguimiento.Clave LIKE '%" +
                    data + "%' AND Clave IN (Select Clave From dbo.Fn_MaviDM0114VisualCalif('" +
                    ClaseEstatica.Usuario.Usser +
                    "')) and MAVIClaveSeguimiento.Clave <> 'VTA99999' ) OR (MAVIClaveSeguimiento.Descripcion LIKE '%" +
                    data + "%'  AND Clave IN (Select Clave From dbo.Fn_MaviDM0114VisualCalif('CREDI00001')))";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataReader = sqlCommand.ExecuteReader();
                if (sqlDataReader.HasRows)
                    while (sqlDataReader.Read())
                    {
                        DM0312_MClaveSeguimiento model_ = new DM0312_MClaveSeguimiento();
                        model_.Clave = sqlDataReader["Clave"].ToString();
                        model_.Modulo = sqlDataReader["Modulo"].ToString();
                        model_.Descripcion = sqlDataReader["Descripcion"].ToString();
                        model_.Grupo = sqlDataReader["Grupo"].ToString();
                        model_.Situacion = sqlDataReader["Situacion"].ToString();
                        listModel.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlClaveSeguimiento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlDataReader != null) sqlDataReader.Close();
            }

            return listModel;
        }


        /// <summary>
        ///     Metodo que permite llenar forma Clave Seguimiento
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public List<DM0312_MClaveSeguimiento> LlenaComboClaveEvento()
        {
            List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlDataReader sqlDataReader = null;
            try
            {
                string query =
                    "SELECT MAVIClaveSeguimiento.Clave, MAVIClaveSeguimiento.Modulo, MAVIClaveSeguimiento.Descripcion, MAVIClaveSeguimiento.Grupo, " +
                    "MAVIClaveSeguimiento.Situacion FROM MAVIClaveSeguimiento WITH(NOLOCK) " +
                    "JOIN Modulo WITH(NOLOCK) ON MAVIClaveSeguimiento.Modulo = Modulo.Modulo " +
                    "WHERE MAVIClaveSeguimiento.Clave <> 'VTA99999' AND Clave IN (Select Clave From dbo.Fn_MaviDM0114VisualCalif('" +
                    ClaseEstatica.Usuario.Usser + "'))";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataReader = sqlCommand.ExecuteReader();
                if (sqlDataReader.HasRows)
                    while (sqlDataReader.Read())
                    {
                        DM0312_MClaveSeguimiento model_ = new DM0312_MClaveSeguimiento();
                        model_.Clave = sqlDataReader["Clave"].ToString();
                        model_.Modulo = sqlDataReader["Modulo"].ToString();
                        model_.Descripcion = sqlDataReader["Descripcion"].ToString();
                        model_.Grupo = sqlDataReader["Grupo"].ToString();
                        model_.Situacion = sqlDataReader["Situacion"].ToString();
                        listModel.Add(model_);
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlClaveSeguimiento", ex);
            }
            finally
            {
                sqlDataReader.Close();
            }

            return listModel;
        }

        /// <summary>
        ///     Metodo que permite llenar lista para validar las situacion por claves
        ///     Developer: Victo Avila
        ///     <param name="usuario"></param>
        ///     <returns>List<string></returns>
        /// </summary>
        public List<MSituaciones> ValidaClaveUsser()
        {
            List<MSituaciones> list = new List<MSituaciones>();
            string query =
                "SELECT DISTINCT Situacion, Flujo FROM MovsituacionUsuario u WITH(NOLOCK) INNER JOIN Movsituacion m WITH(NOLOCK) ON u.id = m.id";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MSituaciones model_ = new MSituaciones();
                        model_.Situacion = dr["Situacion"].ToString();
                        model_.Flujo = dr["Flujo"].ToString();
                        list.Add(model_);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CtrlClaveSeguimiento", ex);
                MessageBox.Show(ex.Message);
            }

            return list;
        }
    }
}