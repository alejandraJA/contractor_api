﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CInfoArticulos
    {
        /// <summary>
        ///     Consulta informacion de los articulos y almacen
        /// </summary>
        /// <param name="Articulo">string</param>
        /// <param name="Almacen">string</param>
        /// <returns>DataSet</returns>
        /// Developer: Dan Palacios
        /// Date: 18/07/2017
        public DataTable ConsultaInfoArticulos(string Articulo, string Almacen = "")
        {
            DataTable dt = new DataTable();
            SqlCommand comm =
                new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
            comm.Parameters.AddWithValue("@Articulo", Articulo);
            if (Almacen != string.Empty)
                comm.Parameters.AddWithValue("@Almacen", Almacen);
            else
                comm.Parameters.AddWithValue("@Almacen", DBNull.Value);
            SqlDataAdapter sda = new SqlDataAdapter();

            try
            {
                sda.SelectCommand = comm;
                sda.Fill(dt);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaInfoArticulos", "CInfoArticulos.cs", ex);
                MessageBox.Show(ex.Message + " function: ConsultaInfoArticulos, class: CInfoArticulos.cs");
            }

            return dt;
        }

        /// <summary>
        ///     Obtiene los almacenes del articulo en cuestion
        /// </summary>
        /// <param name="Articulo">string</param>
        /// <param name="Almacen">string</param>
        /// <returns>List<ArticuloAlmacenes></returns>
        /// Developer: Dan Palacios
        /// Date: 15/08/17
        public List<ArticuloAlmacenes> ObtenerAlmacenes(string Articulo, string Almacen)
        {
            List<ArticuloAlmacenes> Almacenes = new List<ArticuloAlmacenes>();

            SqlCommand comm =
                new SqlCommand("SP_MaviDM0312PuntoVentaInformacionArticulos", ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.StoredProcedure
                };
            comm.Parameters.AddWithValue("@Articulo", Articulo);
            comm.Parameters.AddWithValue("@Almacen", string.Empty);

            try
            {
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        ArticuloAlmacenes AlmacenAñadido = Almacenes.Where(x => x.Almacen == dr["Almacen"].ToString())
                            .SingleOrDefault();
                        if (AlmacenAñadido != null)
                        {
                            AlmacenAñadido.Disponible = AlmacenAñadido.Disponible + Convert.ToDouble(dr["Disponible"]);
                            AlmacenAñadido.Transito = AlmacenAñadido.Transito + Convert.ToDouble(dr["Transito"]);
                            AlmacenAñadido.Total = AlmacenAñadido.Total + Convert.ToDouble(dr["Total"]);
                        }
                        else
                        {
                            ArticuloAlmacenes NuevoAlmacen = new ArticuloAlmacenes
                            {
                                GrupoAlmacen = dr["GrupoAlmacen"].ToString(),
                                Almacen = dr["Almacen"].ToString().ToUpper(),
                                Disponible = Convert.ToDouble(dr["Disponible"]),
                                Transito = Convert.ToDouble(dr["Transito"]),
                                Total = Convert.ToDouble(dr["Total"])
                            };
                            if (dr["Minimo"] != null && dr["Minimo"].ToString() != string.Empty)
                                NuevoAlmacen.Minimo = Convert.ToDouble(dr["Minimo"]);
                            else
                                NuevoAlmacen.Minimo = 0;
                            if (dr["Maximo"] != null && dr["Maximo"].ToString() != string.Empty)
                                NuevoAlmacen.Maximo = Convert.ToDouble(dr["Maximo"]);
                            else
                                NuevoAlmacen.Maximo = 0;
                            Almacenes.Add(NuevoAlmacen);
                        }
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerAlmacenes", "CInfoArticulos.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerAlmacenes, class: CInfoArticulos");
            }

            Almacenes = FiltroAlmacenes(Almacen, Almacenes);

            return Almacenes;
        }

        /// <summary>
        ///     Filtra los almacenes
        /// </summary>
        /// <param name="FiltroAlmacen">string</param>
        /// <param name="Almacenes">List<ArticuloAlmacenes></param>
        /// <returns>List<ArticuloAlmacenes></returns>
        /// Developer: Dan Palacios
        /// Date: 15/08/17
        protected List<ArticuloAlmacenes> FiltroAlmacenes(string FiltroAlmacen, List<ArticuloAlmacenes> Almacenes)
        {
            List<ArticuloAlmacenes> AlmacenesFiltrados = new List<ArticuloAlmacenes>();
            FiltroAlmacen = FiltroAlmacen.Trim();
            if (FiltroAlmacen == "TODOS")
            {
                List<ArticuloAlmacenes> TempAlmacenesFiltrados =
                    Almacenes.Where(x => x.Almacen.StartsWith("V")).ToList();

                AlmacenesFiltrados = TempAlmacenesFiltrados;
            }
            else if (FiltroAlmacen == "BODEGA")
            {
                List<ArticuloAlmacenes> TempAlmacenesFiltrados =
                    Almacenes.Where(x => x.Almacen.ToUpper().StartsWith("V00096")).ToList();
                AlmacenesFiltrados = TempAlmacenesFiltrados;
                if (AlmacenesFiltrados.Count == 0)
                {
                    List<ArticuloAlmacenes> TempAlmacenesFiltrados2 =
                        Almacenes.Where(x => x.Almacen.StartsWith("v00096")).ToList();

                    AlmacenesFiltrados = TempAlmacenesFiltrados2;
                }
            }
            else if (FiltroAlmacen == "OTROS")
            {
                List<ArticuloAlmacenes> TempAlmacenesFiltrados = Almacenes.Where
                (
                    x => x.Almacen.StartsWith("V") && x.Almacen != "V00096"
                                                   && !x.GrupoAlmacen.StartsWith("AME") &&
                                                   !x.GrupoAlmacen.StartsWith("VIU")
                ).ToList();

                AlmacenesFiltrados = TempAlmacenesFiltrados;
            }
            else if (FiltroAlmacen == "MAVI")
            {
                List<ArticuloAlmacenes> TempAlmacenesFiltrados =
                    Almacenes.Where(x => x.GrupoAlmacen.StartsWith("AME")).ToList();

                AlmacenesFiltrados = TempAlmacenesFiltrados;
            }
            else if (FiltroAlmacen == "VIU")
            {
                List<ArticuloAlmacenes> TempAlmacenesFiltrados =
                    Almacenes.Where(x => x.GrupoAlmacen.StartsWith("VIU")).ToList();

                AlmacenesFiltrados = TempAlmacenesFiltrados;
            }

            return AlmacenesFiltrados;
        }
    }
}