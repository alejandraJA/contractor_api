﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CSerieArticulos
    {
        /// <summary>
        ///     Obtiene la lista de catalogos del almacen del articulo en cuestion
        /// </summary>
        /// <param name="IDVenta">string</param>
        /// <param name="Articulo">string</param>
        /// <param name="Almacen">string</param>
        /// <param name="Sucursal">int</param>
        /// <returns>List<SerieArticulos></returns>
        /// Developer: Dan Palacios
        /// Date: 17/08/17
        public List<MSerieArticulos> ObtenerCatalogos(int IDVenta, string Articulo, string Almacen, int? SucursalOrigen,
            string SerieSeleccionada = "")
        {
            List<MSerieArticulos> Catalogos = new List<MSerieArticulos>();

            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_MaviDM0312PuntoVentaSerieArticulos", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@Articulo", Articulo);
                sqlCommand.Parameters.AddWithValue("@Almacen", Almacen);
                sqlCommand.Parameters.AddWithValue("@SucursalOrigen", SucursalOrigen);
                SqlParameter returnParameter = sqlCommand.Parameters.Add("@ReturnVal", SqlDbType.Int);
                returnParameter.Direction = ParameterDirection.ReturnValue;

                SqlDataReader dr = sqlCommand.ExecuteReader();
                int result = 1;
                if (returnParameter.Value != null) result = (int)returnParameter.Value;

                if (result == 1)
                    if (dr.HasRows)
                        while (dr.Read())
                            //SerieArticulos sa = ClaseEstatica.SeriesArticulos.SingleOrDefault(x => x.Serie == dr["Serie"].ToString());
                            //Se valida que no se haya seleccionado la serie o que no sea la serie seleccionada
                            if (SerieSeleccionada == string.Empty || dr["Serie"].ToString() != SerieSeleccionada)
                            {
                                MSerieArticulos NuevoCatalogo = new MSerieArticulos
                                {
                                    Serie = dr["Serie"].ToString(),
                                    Pedimento = dr["PedimentoTipo"].ToString(),
                                    Color = dr["Color"].ToString(),
                                    Modelo = dr["Modelo"].ToString()
                                };
                                if (dr["Fecha"] != null && dr["Fecha"].ToString() != string.Empty)
                                    NuevoCatalogo.FechaAduana = Convert.ToDateTime(dr["Fecha"]).ToString("dd-MM-yyyy");
                                NuevoCatalogo.Aduana = dr["Aduana"].ToString();
                                NuevoCatalogo.Cuadro = dr["Cuadro"].ToString();
                                Catalogos.Add(NuevoCatalogo);
                            }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCatalogos", "CSerieArticulos.cs", ex);
                MessageBox.Show(ex.Message + " function ObtenerCatalogos, class: CSerieArticulos.cs");
            }

            return Catalogos;
        }

        /// <summary>
        ///     Obtener series de articulos
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <param name="Articulo">string</param>
        /// <returns>List<SerieArticulos></returns>
        /// Developer: Dan Palacios
        /// Date: 18/08/17
        public List<MSerieArticulos> ObtenerSeriesArticulos(int IDVenta, string Articulo)
        {
            List<MSerieArticulos> SeriesArticulos = new List<MSerieArticulos>();


            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_MaviDM0312PuntoVentaSerieArticulos", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                sqlCommand.Parameters.AddWithValue("@IDVenta", IDVenta);
                sqlCommand.Parameters.AddWithValue("@Articulo", Articulo);
                sqlCommand.Parameters.AddWithValue("@GetSerieLotes", true);

                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MSerieArticulos NuevoCatalogo = new MSerieArticulos
                        {
                            Serie = dr["Serie"].ToString(),
                            Pedimento = dr["PedimentoTipo"].ToString(),
                            Color = dr["Color"].ToString(),
                            Modelo = dr["Modelo"].ToString(),
                            Aduana = dr["Aduana"].ToString()
                        };
                        if (dr["Fecha"] != null && dr["Fecha"].ToString() != string.Empty)
                            NuevoCatalogo.FechaAduana = Convert.ToDateTime(dr["Fecha"]).ToString("dd-MM-yyyy");
                        NuevoCatalogo.Cuadro = dr["Cuadro"].ToString();
                        SeriesArticulos.Add(NuevoCatalogo);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerSeriesArticulos", "CSerieArticulos.cs", ex);
                MessageBox.Show(ex.Message + " function ObtenerSeriesArticulos, class: CSerieArticulos.cs");
            }

            return SeriesArticulos;
        }

        /// <summary>
        ///     Cambiar serie de articulo
        /// </summary>
        /// <param name="SerieSeleccionada">string</param>
        /// <param name="SerieSeleccionadaCatalogo">SerieArticulos</param>
        /// Developer: Dan Palacios
        /// Date: 19/08/17
        public void CambiarSerie(string SerieSeleccionada, MSerieArticulos SerieSeleccionadaCatalogo)
        {
            foreach (MSerieArticulos SerieArticulo in ClaseEstatica.SeriesArticulos.Where(x =>
                         x.Serie == SerieSeleccionada))
                if (SerieArticulo.Serie == SerieSeleccionada)
                {
                    SerieArticulo.Serie = SerieSeleccionadaCatalogo.Serie;
                    SerieArticulo.Pedimento = SerieSeleccionadaCatalogo.Pedimento;
                    SerieArticulo.Modelo = SerieSeleccionadaCatalogo.Modelo;
                    SerieArticulo.FechaAduana = SerieSeleccionadaCatalogo.FechaAduana;
                    SerieArticulo.Cuadro = SerieSeleccionadaCatalogo.Cuadro;
                    SerieArticulo.Color = SerieSeleccionadaCatalogo.Color;
                    SerieArticulo.Aduana = SerieSeleccionadaCatalogo.Aduana;
                }
        }

        /// <summary>
        ///     Actualiza serie de los articulos
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <param name="Articulo">string</param>
        /// Developer: Dan Palacios
        /// Date: 19/08/17
        public void ActualizarSerie(int IDVenta, string Articulo)
        {
            DataTable dt = new DataTable("SerieLoteMov");
            DataColumn dc = new DataColumn("Empresa");
            dt.Columns.Add(dc);
            dc = new DataColumn("Modulo");
            dt.Columns.Add(dc);
            dc = new DataColumn("ID");
            dt.Columns.Add(dc);
            dc = new DataColumn("RenglonID");
            dt.Columns.Add(dc);
            dc = new DataColumn("Articulo");
            dt.Columns.Add(dc);
            dc = new DataColumn("SubCuenta");
            dt.Columns.Add(dc);
            dc = new DataColumn("SerieLote");
            dt.Columns.Add(dc);
            dc = new DataColumn("Cantidad");
            dt.Columns.Add(dc);
            dc = new DataColumn("CantidadAlterna");
            dt.Columns.Add(dc);
            dc = new DataColumn("OldSerie");
            dt.Columns.Add(dc);
            dc = new DataColumn("Propiedades");
            dt.Columns.Add(dc);
            dc = new DataColumn("Ubicacion");
            dt.Columns.Add(dc);
            dc = new DataColumn("Cliente");
            dt.Columns.Add(dc);
            dc = new DataColumn("Localizacion");
            dt.Columns.Add(dc);
            dc = new DataColumn("Sucursal");
            dt.Columns.Add(dc);
            dc = new DataColumn("ArtCostoInv");
            dt.Columns.Add(dc);

            if (DM0312_DetalleSerieArticulo.OldSeriesArticulos.Count > 0)
            {
                for (int i = 0; i < DM0312_DetalleSerieArticulo.OldSeriesArticulos.Count; i++)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["ID"] = IDVenta;
                    newRow["Articulo"] = Articulo;
                    newRow["SerieLote"] = ClaseEstatica.SeriesArticulos[i].Serie;
                    newRow["OldSerie"] = DM0312_DetalleSerieArticulo.OldSeriesArticulos[i].Serie;
                    newRow["Propiedades"] = ClaseEstatica.SeriesArticulos[i].Cuadro;
                    dt.Rows.Add(newRow);
                }

                dt.Columns.Remove("Empresa");
                dt.Columns.Remove("Modulo");
                dt.Columns.Remove("RenglonID");
                dt.Columns.Remove("Cantidad");
                dt.Columns.Remove("Sucursal");
                dt.Columns.Remove("SubCuenta");
                dt.Columns.Remove("CantidadAlterna");
                dt.Columns.Remove("Cliente");
                dt.Columns.Remove("Localizacion");
                dt.Columns.Remove("ArtCostoInv");
                dt.Columns.Remove("Ubicacion");

                SqlCommand sqlcomm = new SqlCommand("", ClaseEstatica.ConexionEstatica);

                try
                {
                    sqlcomm.CommandText = "CREATE TABLE #TmpTable(ID int NOT NULL, Articulo VARCHAR(10) NULL," +
                                          " SerieLote VARCHAR (50) NULL, OldSerie VARCHAR (50) NULL, Propiedades VARCHAR(20) NULL)";

                    sqlcomm.ExecuteNonQuery();
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                    {
                        try
                        {
                            bulkCopy.DestinationTableName = "#TmpTable";
                            // Write from the source to the destination.
                            bulkCopy.WriteToServer(dt);
                            bulkCopy.Close();
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("ActualizarSerie bulk insert 1", "CSerieArticulos.cs", ex);
                            MessageBox.Show(ex.Message +
                                            " Function: ActualizarSerie bulk insert, class: CSerieArticulos.cs");
                        }
                    }

                    sqlcomm.CommandText =
                        "UPDATE T SET T.SerieLote = Temp.SerieLote, T.Propiedades = Temp.Propiedades " +
                        "FROM " + dt.TableName +
                        " T INNER JOIN #TmpTable Temp ON t.SerieLote = temp.OldSerie AND T.ID=TEMP.ID; DROP TABLE #TmpTable;";
                    sqlcomm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ActualizarSerie bulk update1", "CSerieArticulos.cs", ex);
                    MessageBox.Show(ex.Message + " Function: ActualizarSerie bulkupdate, class: CSerieArticulos.cs");
                }
            }
            else if (ClaseEstatica.SeriesArticulos.Count > 0)
            {
                dt.Columns.Remove("OldSerie");
                for (int i = 0; i < ClaseEstatica.SeriesArticulos.Count; i++)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["ID"] = IDVenta;
                    newRow["Articulo"] = Articulo;
                    newRow["SerieLote"] = ClaseEstatica.SeriesArticulos[i].Serie;
                    newRow["Propiedades"] = ClaseEstatica.SeriesArticulos[i].Cuadro;
                    newRow["Empresa"] = "MAVI";
                    newRow["Modulo"] = "VTAS";
                    newRow["RenglonID"] = DM0312_DetalleSerieArticulo.RenglonID;
                    newRow["Cantidad"] = 1;
                    newRow["Sucursal"] = DM0312_DetalleSerieArticulo.SucursalOrigen;

                    newRow["SubCuenta"] = "";
                    newRow["CantidadAlterna"] = DBNull.Value;
                    newRow["Cliente"] = DBNull.Value;
                    newRow["Localizacion"] = DBNull.Value;
                    newRow["ArtCostoInv"] = DBNull.Value;
                    dt.Rows.Add(newRow);
                }

                try
                {
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                    {
                        bulkCopy.DestinationTableName = dt.TableName;

                        try
                        {
                            // Write from the source to the destination.
                            bulkCopy.WriteToServer(dt);
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("ActualizarSerie bulk insert 2", "CSerieArticulos.cs", ex);
                            MessageBox.Show(ex.Message +
                                            " Function: ActualizarSerie bulk insert 2, class: CSerieArticulos.cs");
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ActualizarSerie bulk update2", "CSerieArticulos.cs", ex);
                    MessageBox.Show(ex.Message + " Function: ActualizarSerie bulk update2, class: CSerieArticulos.cs");
                }
            }
        }

        /// <summary>
        ///     obtener serie del articulo
        /// </summary>
        /// <param name="idVenta">int</param>
        /// <param name="articulo">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 13/11/17
        public string GetSerie(int idVenta, string articulo)
        {
            string rest = string.Empty;

            string query =
                string.Format("SELECT SerieLote FROM SerieLoteMov WITH(NOLOCK) WHERE ID={0} and Articulo='{1}'",
                    idVenta, articulo);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = ClaseEstatica.ConexionEstatica,
                    CommandType = CommandType.Text,
                    CommandText = query,
                    CommandTimeout = 100
                };

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CSerieArticulos", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }


        /// <summary>
        ///     obtener serie del articulo
        /// </summary>
        /// <param name="almacen">string</param>
        /// <param name="articulo">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 17/11/17
        public MSerieArticulos GetSerieLote(string almacen, string articulo)
        {
            MSerieArticulos ret = new MSerieArticulos();

            string rest = string.Empty;

            string query =
                string.Format(
                    "SELECT SerieLote, Propiedades FROM SerieLote WITH(NOLOCK) WHERE Almacen='{0}' and Articulo='{1}' order by UltimaEntrada desc",
                    almacen, articulo);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = ClaseEstatica.ConexionEstatica,
                    CommandType = CommandType.Text,
                    CommandText = query,
                    CommandTimeout = 100
                };

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                    {
                        ret.Serie = dr[0].ToString();
                        ret.Propiedades = dr[1].ToString();
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CSerieArticulos", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return ret;
        }

        /// <summary>
        ///     obtener serie del articulo
        /// </summary>
        /// <param name="almacen">string</param>
        /// <param name="articulo">string</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 17/11/17
        public string GetSerieLote(int idVenta, string articulo)
        {
            string rest = string.Empty;

            string query =
                string.Format("SELECT SerieLote FROM SerieLoteMov WITH(NOLOCK) WHERE id={0} and Articulo='{1}'",
                    idVenta, articulo);

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = ClaseEstatica.ConexionEstatica,
                    CommandType = CommandType.Text,
                    CommandText = query,
                    CommandTimeout = 100
                };

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CSerieArticulos", ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }


        #region SeriesDevolucion

        public List<MSerieArticulos> GetSeriesDev(string Referencia, string Articulo, int IdVentaFactura)
        {
            List<MSerieArticulos> res = new List<MSerieArticulos>();

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SpEDM0312_SerieLoteMovDev";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 100;

                cmd.Parameters.Add("@Referencia", SqlDbType.VarChar).Value = Referencia;
                cmd.Parameters.Add("@ART", SqlDbType.VarChar).Value = Articulo;
                cmd.Parameters.Add("@IDV", SqlDbType.Int).Value = IdVentaFactura;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return res;

                while (dr.Read())
                {
                    MSerieArticulos model = new MSerieArticulos();
                    model.Serie = dr[0].ToString();

                    model.Pedimento = dr["PedimentoTipo"].ToString();
                    model.Color = dr["Color"].ToString();
                    model.Modelo = dr["Modelo"].ToString();
                    model.Aduana = dr["Aduana"].ToString();

                    if (dr["Fecha"] != null && dr["Fecha"].ToString() != string.Empty)
                        model.FechaAduana = Convert.ToDateTime(dr["Fecha"]).ToString("dd-MM-yyyy");
                    model.Cuadro = dr["Cuadro"].ToString();

                    res.Add(model);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CSerieArticulos", ex);
                MessageBox.Show(ex.Message + "IN CSerieArticulos");
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return res;
        }


        /// <summary>
        ///     Actualiza serie de los articulos
        /// </summary>
        /// <param name="IDVenta">int</param>
        /// <param name="Articulo">string</param>
        /// <param name="ListOldSeries">List</param>
        /// <param name="ListInIdDevolucion">List</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 12/12/17
        public void ActualizarSerie(int IDVenta, string Articulo, List<MSerieArticulos> ListOldSeries,
            List<MSerieArticulos> ListInIdDevolucion, int SucursalOrigen, int RenglonID)
        {
            DataTable dt = new DataTable("SerieLoteMov");
            DataColumn dc = new DataColumn("Empresa");
            dt.Columns.Add(dc);
            dc = new DataColumn("Modulo");
            dt.Columns.Add(dc);
            dc = new DataColumn("ID");
            dt.Columns.Add(dc);
            dc = new DataColumn("RenglonID");
            dt.Columns.Add(dc);
            dc = new DataColumn("Articulo");
            dt.Columns.Add(dc);
            dc = new DataColumn("SubCuenta");
            dt.Columns.Add(dc);
            dc = new DataColumn("SerieLote");
            dt.Columns.Add(dc);
            dc = new DataColumn("Cantidad");
            dt.Columns.Add(dc);
            dc = new DataColumn("CantidadAlterna");
            dt.Columns.Add(dc);
            dc = new DataColumn("OldSerie");
            dt.Columns.Add(dc);
            dc = new DataColumn("Propiedades");
            dt.Columns.Add(dc);
            dc = new DataColumn("Ubicacion");
            dt.Columns.Add(dc);
            dc = new DataColumn("Cliente");
            dt.Columns.Add(dc);
            dc = new DataColumn("Localizacion");
            dt.Columns.Add(dc);
            dc = new DataColumn("Sucursal");
            dt.Columns.Add(dc);
            dc = new DataColumn("ArtCostoInv");
            dt.Columns.Add(dc);

            if (ListOldSeries.Count > 0)
            {
                for (int i = 0; i < ListOldSeries.Count; i++)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["ID"] = IDVenta;
                    newRow["Articulo"] = Articulo;
                    newRow["SerieLote"] = ListInIdDevolucion[i].Serie;
                    newRow["OldSerie"] = ListOldSeries[i].Serie;
                    newRow["Propiedades"] = ListInIdDevolucion[i].Propiedades;
                    dt.Rows.Add(newRow);
                }

                dt.Columns.Remove("Empresa");
                dt.Columns.Remove("Modulo");
                dt.Columns.Remove("RenglonID");
                dt.Columns.Remove("Cantidad");
                dt.Columns.Remove("Sucursal");
                dt.Columns.Remove("SubCuenta");
                dt.Columns.Remove("CantidadAlterna");
                dt.Columns.Remove("Cliente");
                dt.Columns.Remove("Localizacion");
                dt.Columns.Remove("ArtCostoInv");
                dt.Columns.Remove("Ubicacion");

                SqlCommand sqlcomm = new SqlCommand("", ClaseEstatica.ConexionEstatica);

                try
                {
                    sqlcomm.CommandText = "CREATE TABLE #TmpTable(ID int NOT NULL, Articulo VARCHAR(10) NULL," +
                                          " SerieLote VARCHAR (50) NULL, OldSerie VARCHAR (50) NULL, Propiedades VARCHAR(20) NULL)";

                    sqlcomm.ExecuteNonQuery();
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                    {
                        try
                        {
                            bulkCopy.DestinationTableName = "#TmpTable";
                            // Write from the source to the destination.
                            bulkCopy.WriteToServer(dt);
                            bulkCopy.Close();
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("ActualizarSerie bulk insert 1", "CSerieArticulos.cs", ex);
                            MessageBox.Show(ex.Message +
                                            " Function: ActualizarSerie bulk insert, class: CSerieArticulos.cs");
                        }
                    }

                    sqlcomm.CommandText =
                        "UPDATE T SET T.SerieLote = Temp.SerieLote, T.Propiedades = Temp.Propiedades " +
                        "FROM " + dt.TableName +
                        " T INNER JOIN #TmpTable Temp ON t.SerieLote = temp.OldSerie AND T.ID=TEMP.ID; DROP TABLE #TmpTable;";
                    sqlcomm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ActualizarSerie bulk update1", "CSerieArticulos.cs", ex);
                    MessageBox.Show(ex.Message + " Function: ActualizarSerie bulkupdate, class: CSerieArticulos.cs");
                }
            }
            else if (ListInIdDevolucion.Count > 0)
            {
                dt.Columns.Remove("OldSerie");
                for (int i = 0; i < ListInIdDevolucion.Count; i++)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["ID"] = IDVenta;
                    newRow["Articulo"] = Articulo;
                    newRow["SerieLote"] = ListInIdDevolucion[i].Serie;
                    newRow["Propiedades"] = ListInIdDevolucion[i].Propiedades;
                    newRow["Empresa"] = "MAVI";
                    newRow["Modulo"] = "VTAS";
                    newRow["RenglonID"] = RenglonID;
                    newRow["Cantidad"] = 1;
                    newRow["Sucursal"] = SucursalOrigen;

                    newRow["SubCuenta"] = "";
                    newRow["CantidadAlterna"] = DBNull.Value;
                    newRow["Cliente"] = DBNull.Value;
                    newRow["Localizacion"] = DBNull.Value;
                    newRow["ArtCostoInv"] = DBNull.Value;
                    dt.Rows.Add(newRow);
                }

                try
                {
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ClaseEstatica.ConexionEstatica))
                    {
                        bulkCopy.DestinationTableName = dt.TableName;

                        try
                        {
                            // Write from the source to the destination.
                            bulkCopy.WriteToServer(dt);
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("ActualizarSerie bulk insert 2", "CSerieArticulos.cs", ex);
                            MessageBox.Show(ex.Message +
                                            " Function: ActualizarSerie bulk insert 2, class: CSerieArticulos.cs");
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ActualizarSerie bulk update2", "CSerieArticulos.cs", ex);
                    MessageBox.Show(ex.Message + " Function: ActualizarSerie bulk update2, class: CSerieArticulos.cs");
                }
            }
        }

        #endregion
    }
}