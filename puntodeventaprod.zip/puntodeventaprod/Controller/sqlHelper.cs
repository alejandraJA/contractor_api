﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace PuntoVenta.Controller
{
    public class sqlHelper
    {
        public DateTime getFechaActualServidor()
        {
            DateTime fecha = new DateTime();
            string query = "select GETDATE()";
            SqlDataReader dr = null;
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    dr = sqlCommand.ExecuteReader();
                    while (dr.Read()) fecha = Convert.ToDateTime(dr[0]);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return fecha;
        }
    }
}