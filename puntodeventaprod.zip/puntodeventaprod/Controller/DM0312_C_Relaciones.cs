﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_Relaciones
    {
        /// <summary>
        ///     Manda llamar las relaciones del cliente
        /// </summary>
        /// <param name="cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 03/09/17
        public DataTable DatosRelaciones(string cliente)
        {
            DataTable dataSet = new DataTable();
            string query =
                "  SELECT CteRelacion.Cliente AS Cliente,Cte.Nombre as Nombre,Cte.Estatus as Estatus,CteRelacion.MaviEstatus as TipoCliente,CteRelacion.Relacion as Relacion,CteDestino.Nombre as NombreRelacionado,CteRelacion.TipoRelacionMAVI as TipoRelacion,CteRelacion.CoincidenciaMAVI as Coincidencia,CteRelacion.FechaBusqueda,CteRelacion.FechaValidacion,CteRelacion.UsuarioValidacion,CteRelacion.Observaciones,CteRelacion.UltimoCambioB,CteRelacion.UsuarioUltimoCambioB,CteRelacion.UltimoCambioV,CteRelacion.UsuarioUltimoCambioV,CteRelacion.Situacion FROM  CteRelacion WITH (NOLOCK)   JOIN Cte WITH (NOLOCK) ON CteRelacion.Cliente=Cte.Cliente JOIN Cte CteDestino WITH (NOLOCK) ON CteRelacion.Relacion=CteDestino.Cliente where cte.Cliente=@Cliente ORDER BY CteRelacion.Relacion ASC ";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlParameter sqlParameter = new SqlParameter("@Cliente", SqlDbType.VarChar);
                sqlParameter.Value = cliente;
                sqlCommand.Parameters.Add(sqlParameter);
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosRelaciones", "DM0312_C_Relaciones", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }
    }
}