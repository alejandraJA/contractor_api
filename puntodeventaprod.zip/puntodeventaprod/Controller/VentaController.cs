﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.View;

namespace PuntoVenta.Controller
{
    public class VentaController
    {
        public static DM0312_CPuntoDeVenta controladorV = new DM0312_CPuntoDeVenta();

        private bool Afectando;

        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();

        private enumTablaSTD.TablaSTD std;

        public DM0312_MExploradorVenta getVenta(int iId)
        {
            DM0312_MExploradorVenta venta = new DM0312_MExploradorVenta();

            try
            {
                string sQuery = @"
                  SELECT top 1 id, 
                               Cliente, 
                               Movid, 
                               Mov, 
                               Situacion, 
                               Sucursal,
                               Estatus
                  FROM Venta WITH (NOLOCK)
                  WHERE id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            venta = new DM0312_MExploradorVenta();
                            while (dr.Read())
                            {
                                venta.ID = dr["id"] is DBNull ? 0 : dr.GetInt32(0);
                                venta.Cliente = dr["Cliente"] is DBNull ? "SinCliente" : dr.GetString(1);
                                venta.MovId = dr["Movid"] is DBNull ? "SinMovid" : dr.GetString(2);
                                venta.Mov = dr["Mov"] is DBNull ? "SinMov" : dr.GetString(3);
                                venta.Situacion = dr["Situacion"] is DBNull ? "SinSituacion" : dr.GetString(4);
                                venta.Suc = dr["Sucursal"] is DBNull ? 0 : dr.GetInt32(5);
                                venta.Estatus = dr["Estatus"] is DBNull ? "sinEstatus" : dr.GetString(6);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return venta;
        }

        public Venta getVentaById(int IdVenta)
        {
            Venta venta = new Venta();

            string query =
                @"SELECT Id,Mov,MovId,Estatus,Situacion,Cliente
                FROM Venta With(nolock)  
                WHERE id = @IdVenta
                ";

            SqlDataReader dr = null;

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add("@IdVenta", IdVenta);
                    cmd.CommandType = CommandType.Text;
                    using (dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            venta.Id = Convert.ToInt32(dr["Id"].ToString());
                            venta.Mov = dr["Mov"].ToString();
                            venta.MovId = dr["MovId"].ToString();
                            venta.Estatus = dr["Estatus"].ToString();
                            venta.Situacion = dr["Situacion"].ToString();
                            venta.Cliente = dr["Cliente"].ToString();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return venta;
        }

        public async Task<bool> cancelarVentaBtnDetalleCopy(List<DM0312_MExploradorVenta> VentasSeleccionadas,
            int PaginadoActual)
        {
            bool respuesta = true;

            if (!ClaseEstatica.ListaPermisosCreacion.Contains("VTAS." + VentasSeleccionadas[PaginadoActual].Mov))
            {
                // obtener permisos con SP_MaviDM0312PuntoVentaAccesoUsuarios 'VENTP002', true
                MessageBox.Show(
                    "El usuario no tiene acceso a editar el movimiento: " + VentasSeleccionadas[PaginadoActual].Mov,
                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                if ("ACCESO" == "Acceso2")
                {
                    /*using(var SCM = new SolicitudCancelacionMovimiento(VentasSeleccionadas[PaginadoActual])) {
                        SCM.ShowDialog();
                    }*/
                }

                return false;
            }

            //-CandadoEmbarque
            if (VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Mayoreo")
            {
                DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
                string[] sDatosEmbarque = DevolucionMov
                    .validarEstatusEmbarque(VentasSeleccionadas[PaginadoActual].MovId).Split('|');
                if (sDatosEmbarque.Length > 0)
                    if (sDatosEmbarque[0] == "SINAFECTAR" || sDatosEmbarque[0] == "PENDIENTE")
                    {
                        MessageBox.Show(
                            "La factura se encuentra en el embarque ID:" + sDatosEmbarque[1] +
                            ", en estatus sin afectar o pendiente, no se puede realizar la cancelación", "Precaucion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
            }

            string sNumeroVale = CDetalleVenta.obtenerNumeroVale(VentasSeleccionadas[PaginadoActual].ID);

            if (VentasSeleccionadas[PaginadoActual].Almacen != "V00096")
                if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "")
                    if (CDetalleVenta.validarRecogerSucursal(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                        if ((VentasSeleccionadas[PaginadoActual].Situacion == "Liberado" &&
                             VentasSeleccionadas[PaginadoActual].Mov == "Pedido") ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                            if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                                VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 41 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 90)
                            {
                                frmSolicitudContraseña frmSolicitudContraseña = new frmSolicitudContraseña();
                                frmSolicitudContraseña.ShowDialog();
                                if (!frmSolicitudContraseña.bEsCorrecto)
                                {
                                    MessageBox.Show(
                                        "No se puede afectar el movimiento debido a que no se cumplio la validacion",
                                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return false;
                                }

                                CDetalleVenta.cancelarReservacion(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                            }

            //-AppDima
            string sReferencia = CDetalleVenta.EsAPPDIMA(VentasSeleccionadas[PaginadoActual].ID);
            if (sReferencia == "Credilana APPDIMA" || sReferencia == "Venta APPFINALES")
                if (VentasSeleccionadas[PaginadoActual].Mov == "Credilana")
                {
                    MessageBox.Show("No puede cancelar movimientos cuando provenga de APPDIMA", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            //-Datalogic
            if (ClaseEstatica.iRecarga == 1)
                if (CDetalleVenta.valdiarRecarga(VentasSeleccionadas[PaginadoActual].ID) == 1)
                {
                    MessageBox.Show("No Se Puede Cancelar El Moviemiento Debido A Que Ya Se Realizo La Recarga",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            //checar si el usuario puede cancelar otros movs o solo los suyos
            bool PuedeCancelar = true;
            if (!CUsuario.CancelarOtrosMovs)
                //DataTable TablaDatosTableroSeleccionadosPublica = (DataTable)TablaDatosGlobal.TablaDatosTableroSeleccionadosPublica;
                if (CUsuario.Usuario != VentasSeleccionadas[PaginadoActual].Usuario)
                    PuedeCancelar = false;

            if (!PuedeCancelar)
            {
                MessageBox.Show("No puede cancelar movimientos que no sean creados por otro usuario", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if ((VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                     VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU") &&
                    VentasSeleccionadas[PaginadoActual].Sucursal != ClaseEstatica.Usuario.sucursal)
                {
                    MessageBox.Show(
                        "No se puede cancelar movimientos generados en otra sucursal " +
                        VentasSeleccionadas[PaginadoActual].Sucursal, "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else
                {
                    CDetalleVenta.PaginadoActual = PaginadoActual;
                    int MovimientoSePuedeCancelar =
                        CDetalleVenta.ValidacionCancelacion(VentasSeleccionadas[PaginadoActual].Sucursal,
                            VentasSeleccionadas);
                    string Message = "¿Esta seguro que desea cancelar el movimiento?";
                    if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar ||
                        MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoGeneraMovContrario)
                    {
                        if (MovimientoSePuedeCancelar ==
                            (int)Enums.MovCancelacionBanderas.MovimientoGeneraMovContrario)
                            Message = "Nota: Esta cancelación va a generar un movimiento contrario. " +
                                      Environment.NewLine + Environment.NewLine + Message;

                        respuesta = false;
                        DialogResult result = MessageBox.Show(Message, "Cancelacion", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            respuesta = true;
                            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                (VentasSeleccionadas[PaginadoActual].Estatus == "Pendiente" ||
                                 VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE") &&
                                (VentasSeleccionadas[PaginadoActual].Suc == 90 ||
                                 VentasSeleccionadas[PaginadoActual].Suc == 41))
                            {
                                CancelarEcommerce cancelarE = new CancelarEcommerce();
                                cancelarE.idventa = VentasSeleccionadas[PaginadoActual].ID;
                                cancelarE.ShowDialog();
                            }
                        }

                        if (respuesta)
                        {
                            //-FlujoMonedero

                            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                controladorV.checarPedidoContado(int.Parse(VentasSeleccionadas[PaginadoActual]
                                    .EnviarA)))
                                if (controladorV.checarAnticipos(VentasSeleccionadas[PaginadoActual].ID))
                                {
                                    DialogResult res = MessageBox.Show(
                                        "El pedido cuenta con anticipos hechos. Se encuentra el cliente presente con usted?",
                                        "Cancelacion", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (res == DialogResult.Yes)
                                    {
                                        DM0312_LoginCancelacion LoginCancelacion = new DM0312_LoginCancelacion();

                                        if (LoginCancelacion.ShowDialog() == DialogResult.OK)
                                            try
                                            {
                                                string response =
                                                    controladorV.devolucionAnticipos(VentasSeleccionadas[PaginadoActual]
                                                        .ID);
                                                MessageBox.Show(response, "Cancelacion", MessageBoxButtons.OK,
                                                    MessageBoxIcon.Information);
                                            }
                                            catch
                                            {
                                                MessageBox.Show("No se pudieron devolver los anticipos", "Cancelacion",
                                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }
                                        else
                                            return false;
                                    }
                                    else
                                    {
                                        MessageBox.Show(
                                            "Es necesario que el cliente se encuentre con usted para poder realizar la cancelacion.",
                                            "Cancelacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        return false;
                                    }
                                }


                            if (!frmLoading.Visible)
                            {
                                //frmLoading.Show(this);
                                /*WIP: Cosas del Detalle de venta ver como replicar.
                                  EnableControls(false, this);
                                  panelmenu.Location = new Point(2, 1);*/
                            }

                            Afectando = true;
                            string tipomsgRef = string.Empty;
                            /* WIP funciones del DetalleVenta
                             * string msgPrecaucion = await Task.Run(() => CancelarMovimiento(ref tipomsgRef));
                             */
                            string msgPrecaucion = await Task.Run(() =>
                                CancelarMovimiento(ref tipomsgRef, VentasSeleccionadas[PaginadoActual]));
                            if (frmLoading.Visible) frmLoading.Hide();
                            /* WIP funciones del DetalleVenta
                             *  EnableControls(true, this);
                             */
                            if (msgPrecaucion != string.Empty)
                            {
                                if (tipomsgRef != string.Empty)
                                {
                                    if (tipomsgRef == "PRECAUCION")
                                    {
                                        msgPrecaucion = msgPrecaucion + Environment.NewLine + "Movimiento: " +
                                                        VentasSeleccionadas[PaginadoActual].Mov + " " +
                                                        VentasSeleccionadas[PaginadoActual].MovId;
                                        MessageBox.Show(msgPrecaucion, "Precaución", MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                                    }
                                    else if (tipomsgRef == "ERROR")
                                    {
                                        MessageBox.Show(msgPrecaucion, "Error", MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                                    }
                                    else
                                    {
                                        MessageBox.Show(msgPrecaucion, "Advertencia", MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(msgPrecaucion, "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                    //-ValeDigital

                                    if (msgPrecaucion == "Registro cancelado satisfactoriamente")
                                        if (VentasSeleccionadas[PaginadoActual].Canal == "VTAVALE")
                                            if (!string.IsNullOrEmpty(sNumeroVale))
                                                CDetalleVenta.cancelarVale(sNumeroVale);
                                }
                            }

                            if (msgPrecaucion == "Registro cancelado satisfactoriamente" || tipomsgRef == "Monedero")
                            {
                                //this.Dispose();
                                /* WIP
                                 *  this.Visible = false;
                                 */
                                DM0312_ExploradorVentas ExploradorVentas =
                                    (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                                ExploradorVentas.TableroMovimientos();
                                if (VentasSeleccionadas.Count > 1)
                                {
                                    string MovOrigen =
                                        CDetalleVenta.ObtenerMovOrigen(VentasSeleccionadas[PaginadoActual].ID);
                                    DM0312_MExploradorVenta modeloOrigen =
                                        VentasSeleccionadas.FirstOrDefault(x => x.Mov + " " + x.MovId == MovOrigen);
                                    if (modeloOrigen != null)
                                        CDetalleVenta.CargaMovimientoCreado(modeloOrigen.ID, modeloOrigen.ID,
                                            VentasSeleccionadas, true);

                                    CDetalleVenta.CargaMovimientoCreado(VentasSeleccionadas[PaginadoActual].ID,
                                        VentasSeleccionadas[PaginadoActual].ID, VentasSeleccionadas);
                                    VentasSeleccionadas.RemoveAt(PaginadoActual);
                                    if (PaginadoActual > 0)
                                    {
                                        PaginadoActual = PaginadoActual - 1;
                                        CDetalleVenta.PaginadoActual = PaginadoActual;
                                    }

                                    CDetalleVenta.MovimientoGenerado = true;
                                }
                                else
                                {
                                    CDetalleVenta.MovimientoGenerado = false;
                                    //this.Dispose();
                                }

                                /* WIP
                                 *  ExploradorVentas.CargarNuevasAfectaciones(this, VentasSeleccionadas);
                                 *  if(VentasSeleccionadas.Count > 1 && VentasSeleccionadas.Count < PaginadoActual) {
                                 *      Btn_detallePosterior_Click(null, null);
                                 *  }
                                 *
                                 *  if(controladorV.ValidarDie() != "NO") {
                                 *      if(CDetalleVenta.validaCancelaDIE(VentasSeleccionadas[PaginadoActual].ID) == "SI") {
                                 *          LayoutCancelaDIE();
                                 *      }
                                 *  }
                                 */

                                //-430
                                if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76)
                                    if (CDetalleVenta.validarDimaNuevo(VentasSeleccionadas[PaginadoActual].ID))
                                        foreach (DM0312_MExploradorVenta item in VentasSeleccionadas)
                                        {
                                            item.Estatus = CDetalleVenta.obtenerEstatusVenta(item.ID);
                                            if ((item.Mov == "Analisis Credito" || item.Mov == "Solicitud Credito") &&
                                                item.Estatus == "CANCELADO")
                                            {
                                                List<string> datos =
                                                    CDetalleVenta.FechaActualizacion(item, "PENDIENTE");
                                                if (datos.Count > 0)
                                                {
                                                    CDetalleVenta.GuardaNuevoRegistro(datos, item.Estatus);
                                                }
                                                else
                                                {
                                                    List<string> lsDatos =
                                                        CDetalleVenta.ObtenerComentarios(
                                                            VentasSeleccionadas[PaginadoActual].MovId,
                                                            VentasSeleccionadas[PaginadoActual].Mov);
                                                    CDetalleVenta.actualiarHistorialDima(item, lsDatos[0], "CANCELADO");
                                                }
                                            }
                                        }
                            }

                            Afectando = false;
                        }
                    }
                    else if (MovimientoSePuedeCancelar ==
                             (int)Enums.MovCancelacionBanderas.MovimientoFacturaDeOtraSucursal)
                    {
                        MessageBox.Show("No se puede cancelar movimientos generados en otra sucursal", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoYaCancelado)
                    {
                        MessageBox.Show("Este movimiento ya ha sido cancelado", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoConNota)
                    {
                        MessageBox.Show("Cancelar nota", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoPendiente)
                    {
                        MessageBox.Show("Cancelar venta pendiente", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
            }

            //CDetalleVenta.EstatusMonedero(VentasSeleccionadas[PaginadoActual].ID, "EstatusCancelado");

            return respuesta;
        }

        internal List<int> getCatalogoCapturaTelefono()
        {
            std = enumTablaSTD.TablaSTD.CATPVTELEFONO;

            SqlDataReader dr;
            List<int> resultado = new List<int>();

            using (SqlCommand cmd = new SqlCommand(std.getQuery(), ClaseEstatica.ConexionEstatica))
            {
                try
                {
                    cmd.ExecuteNonQuery();
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                        while (dr.Read())
                            resultado.Add(dr.GetInt32(0));
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return resultado;
        }

        /// <summary>
        ///     Cancelacion de movimiento
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 31/07/2017
        public string CancelarMovimiento(ref string tipomsgRef, DM0312_MExploradorVenta Venta)
        {
            string msgRespuesta = string.Empty;

            int EnviarA = 0;
            string IDECommerce = "0";

            try
            {
                if (Venta.EnviarA != null && Venta.EnviarA != string.Empty) EnviarA = int.Parse(Venta.EnviarA);

                if (Venta.IDEcommerce != null && Venta.IDEcommerce != string.Empty) IDECommerce = Venta.IDEcommerce;

                msgRespuesta = CDetalleVenta.CancelarMovimiento(Venta.ID.ToString(), Venta.Mov, Venta.MovId,
                    ClaseEstatica.Usuario.Usser, Venta.Sucursal, EnviarA, IDECommerce, ref tipomsgRef);

                if (Venta.Mov == "Credilana" && Venta.Estatus == "CONCLUIDO")
                    CDetalleVenta.CancelarMovPadreCredilana(Venta.ID.ToString(), Venta.Mov, Venta.MovId,
                        ClaseEstatica.Usuario.Usser, Venta.Sucursal, EnviarA, IDECommerce, ref tipomsgRef);

                if (msgRespuesta == string.Empty) msgRespuesta = "Registro cancelado satisfactoriamente";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return msgRespuesta;
        }

        #region 1590-1591

        private string getObservacion(int idSucursal)
        {
            string nombre = "";
            string query = @"SELECT TOP 1
                            CONCAT(S.Sucursal, ', ', Nombre) as 'NombreSucursalDestino'
                            FROM Sucursal S WITH (NOLOCK)
                            WHERE Sucursal = @idSucursal";
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddWithValue("@idSucursal", idSucursal);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.HasRows)
                            while (sqlDataReader.Read())
                                nombre = "RECOGE EN SUCURSAL NUM. " + sqlDataReader["NombreSucursalDestino"];
                    }
                }
            }
            catch (Exception ex)
            {
                //en caso de tronar lo primero es mandar a llamar el manejador de errores de el 	punto de venta y registrar el error en Base de Datos	DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //Se arroja el mensaje a el usuario de la Exepcion extraordinaria
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return nombre;
        }

        public void actualizaMovimientoPedido(int idVenta, string mov)
        {
            int idSucursalDestino = 0, idOrigen = 0;
            string filtro = "", from = "", query = "", observaciones = "";
            if (mov == "Pedido")
            {
                idOrigen = getIdOrigen(idVenta);
                idSucursalDestino = getSucursalDestino(idOrigen);
                observaciones = getObservacion(idSucursalDestino);
                //alias = "f";
                filtro = " WHERE p.id = ";
                from = @" FROM Venta sc WITH(NOLOCK)
                    LEFT JOIN Venta ac WITH(NOLOCK)
                    ON ac.Origen = sc.Mov AND ac.OrigenID = sc.MovID
                    LEFT JOIN Venta p WITH(ROWLOCK)
                    ON p.Origen = ac.Mov AND p.OrigenID = ac.MovID";
            }

            query = @"UPDATE sc.Observaciones = @sucursalDestino,
                    ac.Observaciones = @sucursalDestino,
                    p.Observaciones = @sucursalDestino" +
                    from + filtro + "@idVenta";

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddWithValue("@IdVenta", idVenta);
                    sqlCommand.Parameters.AddWithValue("@sucursalDestino", observaciones);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                //en caso de tronar lo primero es mandar a llamar el manejador de errores de el 	punto de venta y registrar el error en Base de Datos	DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        private int getIdOrigen(int idVenta)
        {
            int idOrigen = 0;
            string query = @"SELECT SC.id
                    FROM Venta SC WITH (NOLOCK)
                    LEFT JOIN Venta AC WITH (NOLOCK)
                      ON AC.Origen = SC.Mov
                      AND AC.OrigenID = SC.MovID
                    LEFT JOIN Venta P WITH (NOLOCK)
                      ON P.Origen = AC.Mov
                      AND P.OrigenID = AC.MovID
                    WHERE p.id = @idVenta";
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddWithValue("@IdVenta", idVenta);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.HasRows)
                            while (sqlDataReader.Read())
                                idOrigen = Convert.ToInt32(sqlDataReader["observaciones"]);
                    }
                }
            }
            catch (Exception ex)
            {
                //en caso de tronar lo primero es mandar a llamar el manejador de errores de el 	punto de venta y registrar el error en Base de Datos
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //Se arroja el mensaje a el usuario de la Exepcion extraordinaria
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return idOrigen;
        }

        private int getSucursalDestino(int idVenta)
        {
            int idSucursal = 0;
            string query = @"SELECT TOP 1 sucursalDestino
                    FROM VTASDCreditoLiberador CL WITH (NOLOCK)
                    WHERE idVenta = @idVenta
                    AND SucursalDestino != 0
                    OR SucursalDestino IS NOT NULL";
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.Parameters.AddWithValue("@IdVenta", idVenta);
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.HasRows)
                            while (sqlDataReader.Read())
                                idSucursal = Convert.ToInt32(sqlDataReader["observaciones"]);
                    }
                }
            }
            catch (Exception ex)
            {
                //en caso de tronar lo primero es mandar a llamar el manejador de errores de el 	punto de venta y registrar el error en Base de Datos
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //Se arroja el mensaje a el usuario de la Exepcion extraordinaria
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return idSucursal;
        }

        #endregion
    }
}