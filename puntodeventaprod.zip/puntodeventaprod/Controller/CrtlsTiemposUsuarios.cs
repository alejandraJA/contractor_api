﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class CrtlsTiemposUsuarios
    {
        /// <summary>
        ///     Metodo que permite llenar dataGrid Historial Solicitudes (Usuario Tiempos)
        /// </summary>
        /// <param name="id">int</param>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 31/07/2017
        public DataTable LlenaDatGridUsuarioTiempo(int id)
        {
            DataTable dataTable = new DataTable();
            string query =
                "SELECT VerMovTiempo.FechaComenzo,isnull(VerMovTiempo.FechaTermino,GETDATE()) as FechaTermino,VerMovTiempo.Estatus, VerMovTiempo.Situacion," +
                "Tiempos = dbo.Fn_DM0312TiemposUsuarios(VerMovTiempo.FechaComenzo, isnull(VerMovTiempo.FechaTermino, GETDATE()))," +
                "VerMovTiempo.Usuario, u.Nombre " +
                "FROM VerMovTiempo VerMovTiempo WITH(NOLOCK) LEFT join Usuario u WITH(NOLOCK) ON VerMovTiempo.Usuario = u.Usuario " +
                "WHERE VerMovTiempo.Modulo ='VTAS' AND VerMovTiempo.id =@id";
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@id", id);
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlsTiemposUsuarios", ex);
                MessageBox.Show(ex.Message);
            }

            return dataTable;
        }

        /// <summary>
        ///     Metodo que permite obtner el calculo del tiempo trasncurrido entre un determinado rango de fechas
        /// </summary>
        /// <param name="usuario">string</param>
        /// ///
        /// <param name="idVenta">string</param>
        /// <returns>string</returns>
        /// Developer: Victor Avila
        /// Date: 02/08/2017
        public string CalculaTiemposTotalesUsuarios(string idVenta)
        {
            string tempTotal = string.Empty;
            SqlDataReader rd = null;
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312CalculaTiemposTotalesUsuarios",
                    ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParametre = new SqlParameter("@Idventa", SqlDbType.VarChar);
                sqlParametre.Value = idVenta;
                sqlCommand.Parameters.Add(sqlParametre);
                rd = sqlCommand.ExecuteReader();
                if (rd.HasRows)
                    while (rd.Read())
                        tempTotal = rd.GetString(0);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "CrtlsTiemposUsuarios", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (rd != null) rd.Close();
            }

            return tempTotal;
        }

        /// <summary>
        ///     llena una lista para mostrar los registros
        /// </summary>
        /// <param name="usuario">string</param>
        /// ///
        /// <param name="idVenta">string</param>
        /// <returns>List</returns>
        /// Developer: Rodolfo Sanchez
        /// Date: 15/01/2018
        public List<DM0312_MUsuariosTmp> TiemposCorrectos(int id, string mov = "", string movid = "")
        {
            List<DM0312_MUsuariosTmp> List = new List<DM0312_MUsuariosTmp>();
            DataTable temp = LlenaDatGridUsuarioTiempo(id);
            try
            {
                if (temp.Rows.Count <= 0)
                    MessageBox.Show("Sin Registros");
                else
                    foreach (DataRow i in temp.Rows)
                    {
                        DM0312_MUsuariosTmp model = new DM0312_MUsuariosTmp();
                        model.FechaComienzo = Convert.ToDateTime(i["FechaComenzo"].ToString());
                        model.Estatus = i["Estatus"].ToString();
                        model.Situacion = i["Situacion"].ToString();
                        model.Tiempos = i["Tiempos"].ToString();
                        model.Usuario = i["Usuario"].ToString();
                        model.Nombre = i["Nombre"].ToString();
                        model.FechaTermino = Convert.ToDateTime(i["FechaTermino"].ToString());

                        model.Mov = mov;
                        model.MovId = movid;

                        model.Tiempos = CampoCalculado(model.FechaComienzo, model.FechaTermino);

                        List.Add(model);
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TiemposCorrectos", "CrtlsTiemposUsuarios", ex);
                MessageBox.Show(ex.Message);
            }

            return List;
        }

        /// <summary>
        ///     Tiempos correctos para usuarios dependiendo de la fecha inicio y fecha fin
        /// </summary>
        /// <param name="FchComienzo">DateTime</param>
        /// <param name="FchFin">DateTime</param>
        /// <returns>string</returns>
        /// Developer: Rodolfo Sanchez
        /// Date: 15/01/2018
        private string CampoCalculado(DateTime FchComienzo, DateTime FchFin)
        {
            string cadena = string.Empty;
            int anios = 0, Meses = 0, Dias = 0, Horas = 0, Minutos = 0, Segundos = 0;
            string Day = DateAndTime.DateDiff(DateInterval.Day, FchComienzo, FchFin).ToString();
            int anio = FchFin.Year;
            try
            {
                if ((anio / 4 == 0) & ((anio / 100 != 0) | (anio / 400 == 0)))
                    anios = Convert.ToInt32(Day) / 366;
                else
                    anios = Convert.ToInt32(Day) / 365;

                string meses = DateAndTime.DateDiff(DateInterval.Month, FchComienzo, FchFin).ToString();

                string horas = DateAndTime.DateDiff(DateInterval.Hour, FchComienzo, FchFin).ToString();

                //string Minute = DateAndTime.DateDiff(DateInterval.Minute, FchComienzo, FchFin).ToString();

                //string Second = DateAndTime.DateDiff(DateInterval.Second, FchComienzo, FchFin).ToString();


                int RoundMeses = Convert.ToInt32(meses) - 12 * anios;

                Meses = RoundMeses;
                Dias = FchFin.Day - FchComienzo.Day;
                Horas = Convert.ToInt32(horas);
                Minutos = FchFin.Minute - FchComienzo.Minute;
                Segundos = FchFin.Second - FchComienzo.Second;

                if (anios != 0)
                    cadena = anios + " Años ";

                if (Meses != 0)
                    cadena = cadena + Meses + " Meses ";

                if (Dias != 0)
                    cadena = cadena + Dias + " Dias ";

                if (Minutos != 0)
                    cadena = cadena + Minutos + " Minutos ";

                if (Segundos != 0)
                    cadena = cadena + Segundos + " Segundos ";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CampoCalculado", "CrtlsTiemposUsuarios", ex);
                MessageBox.Show(ex.Message);
            }

            return cadena;
        }
    }
}