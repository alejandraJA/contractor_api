﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;


//GESSY 1286
namespace PuntoVenta.Controller
{
    public class SancionController
    {
        public List<string> fetchMotivosSancion(string Valor)
        {
            string query = @"Select nombre
            from tablastd WITH (NOLOCK)
            WHERE TablaSt = 'MOTIVOSANCIONREACTIVACION'
            and Valor is null
                or Valor = @Valor";

            List<string> Motivos = new List<string>();

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@Valor", Valor);
                //sqlCommand.CommandType = CommandType.Text;

                using (SqlDataReader reader = sqlCommand.ExecuteReader())
                {
                    if (reader.HasRows)
                        while (reader.Read())
                            Motivos.Add(reader[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
            }

            return Motivos;
        }

        public bool guardarSancionPendiente(Dictionary<string, string> Parametros)
        {
            //truena en param sucursal
            bool respuesta = false;
            try
            {
                string query = @"INSERT INTO VTASCSancion 
                (Fecha, Sucursal, Vendedor, Monto, MovID, Cliente, UsuarioCredito, Observacion, Aplica, Estatus)
                VALUES 
                (GETDATE(), @Sucursal, @vendedor, @monto, @movID, @cliente, @usuarioCredito, @observacion, @aplica, 'PENDIENTE')";

                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    foreach (KeyValuePair<string, string> parametro in Parametros)
                        cmd.Parameters.AddWithValue(parametro.Key, parametro.Value);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            finally
            {
                respuesta = true;
            }

            return respuesta;
        }

        public string getSanctionAmount()
        {
            string Amount = "";

            string query = @"select valor
            from VTASCParametroDeSancion With(nolock)
            where Parametro = 'Sanc_Uni$'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();

                if (dr.Read()) Amount = dr[0].ToString();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return Amount;
        }

        public int obtenerSancionesDiarias()
        {
            int iSanciones = 0;

            string query = @"select valor
            from VTASCParametroDeSancion With(nolock)
            where Parametro = 'Num_Sanc_Max'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();

                if (dr.Read()) iSanciones = int.Parse(dr[0].ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return iSanciones;
        }

        public int sancionesPorAgente(string sAgente)
        {
            int iSanciones = 0;

            string query = @"select count(vendedor) as Sancion from VTASCSancion with(nolock) where Vendedor = '" +
                           sAgente + "' and cast(fecha as date) = cast(GETDATE() as DATE)";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);

                SqlDataReader dr = command.ExecuteReader();

                if (dr.Read()) iSanciones = int.Parse(dr[0].ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return iSanciones;
        }

        public string obtenerAgenteQueSanciona(int iIdVenta)
        {
            string sAgente = string.Empty;

            string query = @"SELECT
                              Agente
                            FROM MovBitacora WITH (NOLOCK)
                            WHERE id = @Id
                            AND Clave IN ('VTA10000', 'VTA00012', 'VTA00001', 'VTA00050')";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                command.Parameters.AddWithValue("@Id", iIdVenta);
                SqlDataReader dr = command.ExecuteReader();

                if (dr.Read()) sAgente = dr[0].ToString();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return sAgente;
        }
    }
}