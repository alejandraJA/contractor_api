﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using fnPassword;
using PuntoVenta.Model;

//Autor:Rodolfo Sanchez
//Modulo: Punto de venta
//Metodo: Obtiene Factor
//Fecha:25/10/2017
namespace PuntoVenta.Controller
{
    public class DM0312_C_UsuarioDescuentoIncremento
    {
        public string EncriptMD5(string pwd)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text
            md5.ComputeHash(Encoding.ASCII.GetBytes(pwd));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
                //change it into 2 hexadecimal digits
                //for each byte
                strBuilder.Append(result[i].ToString("x2"));

            return strBuilder.ToString();
        }

        public bool ValidaInsertaVenta(string articulo, int id, int renglon)
        {
            int res = 0;

            SqlDataReader dr = null;

            string query =
                string.Format(
                    "select count(*) from VentaD WITH(NOLOCK) where id={0} and Articulo='{1}' and renglon = {2}", id,
                    articulo, renglon);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());

                return Convert.ToBoolean(res);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }
            finally
            {
                dr.Close();
            }

            return false;
        }

        public bool ValidaRenglonID(int id, int renglonID, int renglon, string articulo = "")
        {
            int res = 0;

            SqlDataReader dr = null;

            string query = string.Empty;

            if (articulo != string.Empty)
                query = string.Format(
                    "select count(*) from VentaD WITH(NOLOCK) where id={0} and RenglonID={1} and Renglon={2} and articulo='{3}'",
                    id, renglonID, renglon, articulo);
            else
                query = string.Format(
                    "select count(*) from VentaD WITH(NOLOCK) where id={0} and RenglonID={1} and Renglon={2}", id,
                    renglonID, renglon);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());

                return Convert.ToBoolean(res);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }
            finally
            {
                dr.Close();
            }

            return false;
        }


        //Autor:Rodolfo Sanchez
        //Modulo: Punto de venta
        //Fecha:24/11/2017
        //Descr:Busca Centro de costos segun Almacen
        public string CentroCostos(int sucursal)
        {
            SqlDataReader dr = null;
            string rest = string.Empty;

            string query = string.Format("select CentroCostos from sucursal WITH(NOLOCK)  where sucursal={0}",
                sucursal);
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = ClaseEstatica.ConexionEstatica;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.CommandTimeout = 100;

                    dr = cmd.ExecuteReader();
                }

                if (dr.HasRows)
                    while (dr.Read())
                        rest = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
                MessageBox.Show(ex.Message);
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return rest;
        }

        public bool UpdateSeries(int idventa, string art, int RenglonID)
        {
            int rest = 0;
            string query = string.Format("UPDATE SerieLoteMov SET RenglonID={0} WHERE ID={1} AND Articulo='{2}'",
                RenglonID, idventa, art);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                rest = cmd.ExecuteNonQuery();

                if (rest > 0 || rest == -1)
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return true;
        }

        #region UsuarioDescuento

        public object VentaValidate(int idVenta)
        {
            object res = new object();
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format(
                        "select estatus,Origen,OrigenID,Mov,FormaPagoTipo from venta WITH(NOLOCK) WHERE ID={0}",
                        idVenta);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return null;

                while (dr.Read())
                {
                    var obj = new
                    {
                        estatus = dr[0].ToString(),
                        origen = dr[1].ToString(),
                        origenID = dr[2].ToString(),
                        mov = dr[3].ToString(),
                        PagoTipo = dr[4].ToString()
                    };

                    res = obj;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en VentaValidate de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public List<object> UsuarioList(bool active)
        {
            List<object> res = new List<object>();
            SqlDataReader dr = null;
            try
            {
                string query = string.Empty;
                if (active)
                    //nuevo propietario
                    query = "SELECT Usuario.Usuario,Usuario.Nombre,Usuario.GrupoTrabajo,Usuario.Contrasena FROM" +
                            " Usuario WITH(NOLOCK) where estatus='alta' order by usuario";
                else
                    //autorizo
                    query = "SELECT Usuario.Usuario,Usuario.Nombre,Usuario.GrupoTrabajo,Usuario.Contrasena FROM" +
                            " Usuario WITH(NOLOCK) where Tipo_Descuento = 'Especifico' ORDER BY Usuario";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return null;

                while (dr.Read())
                {
                    var obj = new
                    {
                        usuario = dr[0].ToString(),
                        nombre = dr[1].ToString(),
                        grupoTrabajo = dr[2].ToString(),
                        pwd = dr[3].ToString()
                    };

                    res.Add(obj);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en VentaValidate de UsuarioList " + active);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    "DM0312_C_UsuarioDescuentoIncremento " + active, ex);
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public int UsrAutPrecio(string user)
        {
            int res = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format(
                        "SELECT COUNT(Usuario)FROM Usuario WITH(NOLOCK) WHERE Tipo_Descuento='Especifico' AND Usuario='{0}'",
                        user);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return 0;

                while (dr.Read())
                {
                    int i = 0;
                    i = Convert.ToInt32(dr[0].ToString());
                    res = i;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en UsrAutPrecio de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public bool exec_spPropreAutorizarDescuento(string user, string contrasena, int idVenta,
            DM0312_MVentaDetalle item, double Importe)
        {
            //string password = EncriptMD5(contrasena);
            string password = Intelisis.getHash(contrasena, "P");

            string res = string.Empty;

            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spPropreAutorizarDescuento";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = user;
                cmd.Parameters.Add("@Contrasena", SqlDbType.VarChar).Value = password;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = "VTAS";
                cmd.Parameters.Add("@Renglon", SqlDbType.Float).Value = item.Renglon;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Importe", SqlDbType.Float).Value = Importe;
                cmd.Parameters.Add("@Porcentaje", SqlDbType.Float).Value = (object)item.PropreListaID ?? DBNull.Value;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res != "El precio de venta ha sido actualizado")
                {
                    MessageBox.Show(res, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    MessageBox.Show(res, "OK", MessageBoxButtons.OK);
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en exec_spPropreAutorizarDescuento de DM0312_C_UsuarioDescuentoIncremento  **" +
                                ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return true;
        }

        public void InsertVentaD_E(string articulo, int ID)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("delete from VentaD where articulo= '" + articulo + "' and id=" + ID + "");


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_E", "DM0312_C_UsuarioDescuentoIncremento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public void insertarVentaDFlujoPromo(DM0312_MVentaDetalle item, int IdVenta, int canal, string almacen,
            string agente, int op, int iIdPromocion = 0, string Padre = null)
        {
            DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();

            int defaultInt = 0;
            int sucursal = controlador.GetSucursal(almacen);
            string renglonTipo = item.Tipo.Substring(0, 1);
            double factor = GetFactor(item.Unidad);
            string contUso = CentroCostos(sucursal);
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText =
                    @"INSERT INTO VentaD (ID, Renglon, RenglonSub, RenglonID, RenglonTipo, EnviarA, Almacen, Articulo, Cantidad, Precio, PrecioSugerido, Impuesto1, Impuesto2, Impuesto3, Costo, Paquete,  
            ContUso, Factor, Unidad, FechaRequerida, Agente, Sucursal, SucursalOrigen, UEN, PropreListaID, DescuentoTipo, DescripcionExtra)  
              VALUES(@ID, @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @EnviarA, @Almacen, @Articulo, @Cantidad, @Precio, @PrecioSugerido, @Impuesto1, 0.0, 0.0, @Costo, @Paquete, @ContUso, @Factor, @Unidad, GETDATE(), @Agente, @Sucursal, @SucursalOrigen, @UEN, @PropreListaID, NULL, @DescripcionExtra) ";
                cmd.CommandTimeout = 200;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.AddWithValue("@Renglon", item.Renglon);
                cmd.Parameters.AddWithValue("@RenglonSub", defaultInt);
                cmd.Parameters.AddWithValue("@RenglonID", item.RenglonID);
                cmd.Parameters.Add("@RenglonTipo", SqlDbType.Char).Value = renglonTipo;
                cmd.Parameters.Add("@EnviarA", SqlDbType.Int).Value = canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = almacen;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Cantidad", SqlDbType.Float).Value = item.Cantidad;
                cmd.Parameters.Add("@Precio", SqlDbType.Float).Value = item.Precio;
                cmd.Parameters.Add("@PrecioSugerido", SqlDbType.Float).Value = item.Precio;
                cmd.Parameters.Add("@Impuesto1", SqlDbType.Float).Value = item.impuesto;
                cmd.Parameters.Add("@Costo", SqlDbType.Float).Value = item.Costo;
                cmd.Parameters.AddWithValue("@Paquete", item.Paquete ?? Convert.DBNull);
                cmd.Parameters.Add("@ContUso", SqlDbType.VarChar).Value = contUso;
                cmd.Parameters.Add("@Factor", SqlDbType.Float).Value = factor;
                cmd.Parameters.Add("@Unidad", SqlDbType.VarChar).Value = item.Unidad;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = agente;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                cmd.Parameters.Add("@SucursalOrigen", SqlDbType.Int).Value = ClaseEstatica.Usuario.sucursal;
                cmd.Parameters.Add("@UEN", SqlDbType.Int).Value = ClaseEstatica.Usuario.Uen;
                cmd.Parameters.Add("@PropreListaID", SqlDbType.Int).Value = (object)item.PropreListaID ?? DBNull.Value;
                cmd.Parameters.Add("@OP", SqlDbType.Int).Value = op;
                cmd.Parameters.Add("@IdPromocion", SqlDbType.Int).Value = iIdPromocion;
                cmd.Parameters.Add("@Padre", SqlDbType.VarChar).Value = (object)Padre ?? DBNull.Value;
                if (item.Observaciones == null)
                    item.Observaciones = "";

                cmd.Parameters.Add("@DescripcionExtra", SqlDbType.VarChar).Value = item.Observaciones;

                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en InsertVentaD_ de DM0312_C_UsuarioDescuentoIncremento " + ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }
        }

        public bool InsertVentaD_(DM0312_MVentaDetalle item, int IdVenta, int canal, string almacen, string agente,
            int op, int iIdPromocion = 0, string Padre = null, int iTipoPromocion = 0)
        {
            if (item.Articulo == null)
                return true;

            string contUso = string.Empty;

            DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
            int sucursal = controlador.GetSucursal(almacen);

            double factor = GetFactor(item.Unidad);

            string renglonTipo = item.Tipo.Substring(0, 1);

            int defaultInt = 0;

            string res = string.Empty;

            contUso = CentroCostos(sucursal);

            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0312OperacionesInsDelVentaD";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.AddWithValue("@Renglon", item.Renglon);
                cmd.Parameters.AddWithValue("@RenglonSub", defaultInt);
                cmd.Parameters.AddWithValue("@RenglonID", item.RenglonID);
                cmd.Parameters.Add("@RenglonTipo", SqlDbType.Char).Value = renglonTipo;
                cmd.Parameters.Add("@EnviarA", SqlDbType.Int).Value = canal;
                cmd.Parameters.Add("@Almacen", SqlDbType.VarChar).Value = almacen;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Cantidad", SqlDbType.Float).Value = item.Cantidad;
                cmd.Parameters.Add("@Precio", SqlDbType.Float).Value = item.Precio;
                cmd.Parameters.Add("@PrecioSugerido", SqlDbType.Float).Value = item.Precio;
                cmd.Parameters.Add("@Impuesto1", SqlDbType.Float).Value = item.impuesto;
                cmd.Parameters.Add("@Costo", SqlDbType.Float).Value = item.Costo;
                cmd.Parameters.AddWithValue("@Paquete", item.Paquete ?? Convert.DBNull);
                cmd.Parameters.Add("@ContUso", SqlDbType.VarChar).Value = contUso;
                cmd.Parameters.Add("@Factor", SqlDbType.Float).Value = factor;
                cmd.Parameters.Add("@Unidad", SqlDbType.VarChar).Value = item.Unidad;
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = agente;
                cmd.Parameters.Add("@Sucursal", SqlDbType.Int).Value = sucursal;
                cmd.Parameters.Add("@SucursalOrigen", SqlDbType.Int).Value = ClaseEstatica.Usuario.sucursal;
                cmd.Parameters.Add("@UEN", SqlDbType.Int).Value = ClaseEstatica.Usuario.Uen;
                cmd.Parameters.Add("@PropreListaID", SqlDbType.Int).Value = (object)item.PropreListaID ?? DBNull.Value;
                cmd.Parameters.Add("@OP", SqlDbType.Int).Value = op;
                cmd.Parameters.Add("@IdPromocion", SqlDbType.Int).Value = iIdPromocion;
                cmd.Parameters.Add("@Padre", SqlDbType.VarChar).Value = (object)Padre ?? DBNull.Value;
                cmd.Parameters.Add("@TipoPromocion", SqlDbType.VarChar).Value = (object)iTipoPromocion ?? 0;
                /////////Se agrega PrecioAnterior y UsuarioDescuento//////////
                //cmd.Parameters.Add("@PrecioAnterior", SqlDbType.Float).Value = item.PrecioAnterior;
                //cmd.Parameters.Add("@UsuarioDescuento", SqlDbType.VarChar).Value = item.UsuarioDescuento;
                //////////////////////////////////////////////////////////////

                //if (item.TipoUsrDes_Incr != null)
                //{
                //    cmd.Parameters.Add("@UsuarioDescuento", SqlDbType.VarChar).Value = item.TipoUsrDes_Incr;
                //    //cmd.Parameters.Add("@PrecioAnterior", SqlDbType.Float).Value = item.pr
                //}
                //else
                //{
                //    cmd.Parameters.Add("@UsuarioDescuento", SqlDbType.VarChar).Value = DBNull.Value;
                //}
                if (item.Observaciones == null)
                    item.Observaciones = "";

                cmd.Parameters.Add("@DescripcionExtra", SqlDbType.VarChar).Value = item.Observaciones;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res != "OK")
                {
                    MessageBox.Show(res, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                dr.Close();
            }

            return true;
        }

        public double GetFactor(string unidad)
        {
            double res = 0;
            SqlDataReader dr = null;

            string query = string.Format("SELECT Factor FROM Unidad WITH(NOLOCK) WHERE UNIDAD='{0}'", unidad);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                dr.Close();
            }

            return res;
        }

        public bool exec_SP_MAVIRM0850InsertaAutPrecioXUsr(int IdVenta, string UsrAutorizo, string UsrNvo,
            DM0312_MVentaDetalle item)
        {
            string res = string.Empty;
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "dbo.SP_MAVIRM0850InsertaAutPrecioXUsr";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = IdVenta;
                cmd.Parameters.Add("@Renglon", SqlDbType.Int).Value = item.Renglon;
                cmd.Parameters.Add("@Autoriza", SqlDbType.VarChar).Value = UsrAutorizo;
                cmd.Parameters.Add("@UsrNuevo", SqlDbType.VarChar).Value = UsrNvo;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res != "1")
                {
                    MessageBox.Show(res, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error en exec_SP_MAVIRM0850InsertaAutPrecioXUsr de DM0312_C_UsuarioDescuentoIncremento Error:**" +
                    ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return true;
        }

        #endregion


        #region UsuarioIncremento

        public int UsrAutIncremento()
        {
            int res = 0;
            SqlDataReader dr = null;
            try
            {
                string query =
                    string.Format(
                        "SELECT COUNT(1) FROM TablaStD WITH(NOLOCK) WHERE TablaST='GRUPO TRABAJO USR INCREMENTO' AND Nombre='{0}' AND VALOR='{1}'",
                        ClaseEstatica.Usuario.Acceso, ClaseEstatica.Usuario.Grupo);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return 0;

                while (dr.Read())
                {
                    int i = 0;
                    i = Convert.ToInt32(dr[0].ToString());
                    res = i;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en UsrAutIncremento de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        public bool exec_spPropreIncremento(int idVenta, DM0312_MVentaDetalle item, double Importe, string usuario)
        {
            string res = string.Empty;

            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spPropreIncremento";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuario;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@Modulo", SqlDbType.VarChar).Value = "VTAS";
                cmd.Parameters.Add("@Renglon", SqlDbType.Float).Value = item.Renglon;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;
                cmd.Parameters.Add("@Importe", SqlDbType.Float).Value = Importe;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read()) res = dr[0].ToString();

                if (res != "El precio de venta ha sido actualizado")
                {
                    MessageBox.Show(res, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    MessageBox.Show(res, "OK", MessageBoxButtons.OK);
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en exec_spPropreIncremento de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return true;
        }

        public bool exec_SP_DM0313AutorizaIncremento(int idVenta, DM0312_MVentaDetalle item, string mov)
        {
            string res = string.Empty;

            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "SP_DM0313AutorizaIncremento";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 200;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = ClaseEstatica.Usuario.usuario;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = idVenta;
                cmd.Parameters.Add("@mov", SqlDbType.VarChar).Value = mov;
                cmd.Parameters.Add("@Articulo", SqlDbType.VarChar).Value = item.Articulo;

                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en exec_spPropreIncremento de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
                return false;
            }

            finally
            {
                dr.Close();
            }

            return true;
        }

        public bool GetUserValidate(string user, string pwd)
        {
            string res = string.Empty;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format("SELECT Contrasena FROM Usuario WITH(NOLOCK) WHERE Usuario='{0}'", user);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return false;

                while (dr.Read())
                {
                    string pwd_ = string.Empty;
                    pwd_ = dr[0].ToString();
                    res = pwd_;
                }

                //string password = EncriptMD5(pwd);
                string password = Intelisis.getHash(pwd, "P");

                if (password == res)
                {
                    dr.Close();

                    string pwdUsuario = UsrValidaIncremento(user);

                    if (password == pwdUsuario)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en GetUserValidate de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return false;
        }

        public string UsrValidaIncremento(string usuario)
        {
            string res = string.Empty;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format(
                    " SELECT U.Contrasena FROM Usuario U WITH(NOLOCK)  INNER JOIN TablaStD D WITH(NOLOCK) ON U.ACCESO=D.NOMBRE" +
                    "  WHERE D.TablaSt ='USUARIO VALIDA INCREMENTO' AND U.Usuario='{0}'", usuario);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 200;

                dr = cmd.ExecuteReader();

                if (!dr.HasRows)
                    return string.Empty;

                while (dr.Read())
                {
                    string pwd_ = string.Empty;

                    pwd_ = dr[0].ToString();

                    res = pwd_;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en UsrValidaIncremento de DM0312_C_UsuarioDescuentoIncremento");
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
            }

            finally
            {
                dr.Close();
            }

            return res;
        }

        #endregion


        #region Actualizaciones

        public bool ActualizaDescuentoMavi(int idventa, int renglon, int renglonAnterior)
        {
            string query = string.Format("UPDATE dbo.AutorizacionesUsuarioDescuentoMavi WITH(ROWLOCK)"
                                         + "SET VtaRenglon={0} WHERE VtaID = {1} AND VtaRenglon = {2}", renglon,
                idventa, renglonAnterior);

            int rest = 0;


            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = query;
                cmd.CommandTimeout = 100;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;

                rest = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return Convert.ToBoolean(rest);
        }

        public void InsertVentaD_I(int renglon, int rengloid, int ID)
        {
            SqlDataReader dr = null;
            string query = string.Empty;
            query = string.Format("delete from VentaD where  renglonid='" + rengloid + "' and renglon= '" + renglon +
                                  "' and id=" + ID + "");


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertVentaD_I", "DM0312_C_UsuarioDescuentoIncremento", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }
        }

        public bool ActualizaVentaD(int idventa, int renglon, int renglonId, string articulo, double precio,
            string descripcion, int cantidad)
        {
            string query = string.Format(
                "UPDATE VentaD WITH(ROWLOCK) SET Renglon={0} , RenglonID={2},Precio={4},PrecioSugerido={4},DescripcionExtra='" +
                descripcion + "', cantidad= '" + cantidad + "'   WHERE ID = {1} and Articulo='{3}' AND Renglon = {0}",
                renglon, idventa, renglonId, articulo, precio);

            int rest = 0;


            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = query;
                cmd.CommandTimeout = 100;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;

                rest = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UsuarioDescuentoIncremento",
                    ex);
                MessageBox.Show("Error " + ex.Message);
            }

            return Convert.ToBoolean(rest);
        }

        #endregion
    }
}