﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class clsPosicionDelMovimiento
    {
        private DataTable dt;

        /// <summary>
        ///     Metodo encargado de obtener la informacion de los movimientos de la venta
        /// </summary>
        /// <param name="iIdVenta">id de venta</param>
        /// <param name="iOpcion">opcione de consulta 1:Origen, 2:Destino</param>
        /// <returns>Retorna una lista con todos los moviemitos del origen</returns>
        public List<clsModeloPosicionDelMovimiento> obtenerMovimientos(int iIdVenta, int iOpcion)
        {
            List<clsModeloPosicionDelMovimiento>
                listaPosicionDelMovimineto = new List<clsModeloPosicionDelMovimiento>();
            dt = new DataTable();
            try
            {
                string sRama = string.Empty;
                switch (iOpcion)
                {
                    case 1:
                        sRama = "ORIGENVTAS" + iIdVenta;
                        break;
                    case 2:
                        sRama = "DESTINOVTAS" + iIdVenta;
                        break;
                }

                string sQuery = @"select MovPos.Modulo,
                                  MovPos.Estacion,
                                  MovPos.Tipo,
                                  MovPos.Sucursal,
                                  MovPos.Empresa,
                                  MovPos.OModulo,
                                  MovPos.OID,
                                  MovPos.OMov,
                                  MovPos.OMovID,
                                  MovPos.OEstatus,
                                  MovPos.DModulo,
                                  MovPos.DID,
                                  MovPos.DMov,
                                  MovPos.DMovID,
                                  MovPos.DEstatus,
                                  MovPos.Cancelado,
                                  MovPos.Clave,
                                  MovPos.Rama,
                                  MovPos.EsAcumulativa,
                                  MovPos.Movimiento from MovPos with(nolock) where Rama = @Rama
									and Estacion = @Estacion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Rama", sRama)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Estacion", ClaseEstatica.WorkStation)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPosicionDelMovimineto.Add(new clsModeloPosicionDelMovimiento
                        {
                            sModulo = row["Modulo"].ToString(),
                            iEstacion = int.Parse(row["Estacion"].ToString()),
                            sTipo = row["Tipo"].ToString(),
                            iSucursal = int.Parse(row["Sucursal"].ToString()),
                            sEmpresa = row["Empresa"].ToString(),
                            sOModulo = row["OModulo"].ToString(),
                            iOiD = int.Parse(row["OID"].ToString()),
                            sOMov = row["OMov"].ToString(),
                            sOMovID = row["OMovID"].ToString(),
                            sOEstatus = row["OEstatus"].ToString(),
                            sDModulo = row["DModulo"].ToString(),
                            iDID = int.Parse(row["DID"].ToString()),
                            sDMov = row["DMov"].ToString(),
                            sDMovID = row["DMovID"].ToString(),
                            sDEstatus = row["DEstatus"].ToString(),
                            bCancelado = bool.Parse(row["Cancelado"].ToString()),
                            sClave = row["Clave"].ToString(),
                            sRama = row["Rama"].ToString(),
                            bEsAcumulativa = bool.Parse(row["EsAcumulativa"].ToString()),
                            sMovimiento = row["Movimiento"].ToString(),
                            sListaClave = row["Clave"].ToString()
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaPosicionDelMovimineto;
        }

        /// <summary>
        ///     Metodo encargado de obtener el siguiente movimiento
        /// </summary>
        /// <param name="sClave">clave del siguiente movimiento</param>
        /// <returns>lista de los siguientes movimientos</returns>
        public List<clsModeloPosicionDelMovimiento> siguienteMovimiento(string sClave)
        {
            List<clsModeloPosicionDelMovimiento>
                listaPosicionDelMovimineto = new List<clsModeloPosicionDelMovimiento>();
            dt = new DataTable();
            try
            {
                string sQuery = @"select MovPos.Modulo,
                                  MovPos.Estacion,
                                  MovPos.Tipo,
                                  MovPos.Sucursal,
                                  MovPos.Empresa,
                                  MovPos.OModulo,
                                  MovPos.OID,
                                  MovPos.OMov,
                                  MovPos.OMovID,
                                  MovPos.OEstatus,
                                  MovPos.DModulo,
                                  MovPos.DID,
                                  MovPos.DMov,
                                  MovPos.DMovID,
                                  MovPos.DEstatus,
                                  MovPos.Cancelado,
                                  MovPos.Clave,
                                  MovPos.Rama,
                                  MovPos.EsAcumulativa,
                                  MovPos.Movimiento from MovPos with(nolock) where Rama = @Rama
								  and Estacion = @Estacion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Rama", sClave)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Estacion", ClaseEstatica.WorkStation)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        listaPosicionDelMovimineto.Add(new clsModeloPosicionDelMovimiento
                        {
                            sModulo = row["Modulo"].ToString(),
                            iEstacion = int.Parse(row["Estacion"].ToString()),
                            sTipo = row["Tipo"].ToString(),
                            iSucursal = int.Parse(row["Sucursal"].ToString()),
                            sEmpresa = row["Empresa"].ToString(),
                            sOModulo = row["OModulo"].ToString(),
                            iOiD = int.Parse(row["OID"].ToString()),
                            sOMov = row["OMov"].ToString(),
                            sOMovID = row["OMovID"].ToString(),
                            sOEstatus = row["OEstatus"].ToString(),
                            sDModulo = row["DModulo"].ToString(),
                            iDID = int.Parse(row["DID"].ToString()),
                            sDMov = row["DMov"].ToString(),
                            sDMovID = row["DMovID"].ToString(),
                            sDEstatus = row["DEstatus"].ToString(),
                            bCancelado = bool.Parse(row["Cancelado"].ToString()),
                            sClave = row["Clave"].ToString(),
                            sRama = row["Rama"].ToString(),
                            bEsAcumulativa = bool.Parse(row["EsAcumulativa"].ToString()),
                            sMovimiento = row["Movimiento"].ToString(),
                            sListaClave = row["Clave"].ToString()
                        });
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listaPosicionDelMovimineto;
        }

        public void generarMovimientos(int iIdVenta)
        {
            try
            {
                string sQuery = "sPMovPos";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Estacion", ClaseEstatica.WorkStation)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@MovModulo", "VTAS")
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@MovModuloID ", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }
    }
}