﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public static class ValeDigitalController
    {
        public static int getEstatusVale(string valeDigital)
        {
            int respuesta = 5;
            //Posibles Respuesta del sp
            //0 - Vale Correcto
            //1 - Vale No existe
            //2 - Vale expirado
            //3 - Vale Cancelado
            //4 - Vale ya usado
            //5 - Error metodo/SP

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "validar" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = valeDigital }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                respuesta = int.Parse(dr[0].ToString());
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return respuesta;
        }

        public static MValeDigital getDatosValeSp(string vale)
        {
            MValeDigital datosVale = new MValeDigital();

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "getDatosVale" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = vale }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                datosVale.id_vale = int.Parse(dr["idPedidoValeDigital"].ToString());
                                datosVale.cliente = dr["Cliente"].ToString();
                                datosVale.vale = dr["Vale"].ToString();
                                datosVale.tipo = int.Parse(dr["TipoPedido"].ToString());
                                datosVale.total = double.Parse(dr["Total"].ToString());
                                datosVale.correo = dr["Correo"].ToString();
                                datosVale.telefono = dr["Telefono"].ToString();
                                datosVale.canal = int.Parse(dr["Canal"].ToString());
                                datosVale.condicion = dr["Condicion"].ToString();
                                datosVale.beneficiarioFinal = dr["ClienteBF"].ToString();
                            }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return datosVale;
        }

        public static MValeDigital getDatosValeDQ(string vale)
        {
            MValeDigital datosVale = new MValeDigital();

            string query = @"SELECT TOP 1
            vd.idPedidoValeDigital,
            vd.Cliente,
            vd.Vale,
            vd.TipoPedido,
            vd.Total,
            vd.Correo,
            vd.Telefono,
            vd.Canal,
            vd.Condicion,
            vd.ClienteBF,
            isnull(vd.PuntosRedimidos , 0.0) as PuntosRedimidos
                FROM VTASDPedidoValeDigital vd WITH (NOLOCK)
            LEFT JOIN ERPMAVI.IntelisisTMP.dbo.DM0244_FOLIOS_VALES fv WITH (NOLOCK)
            ON fv.CODIGOBARRAS = vd.Vale
            WHERE vd.Vale = @Vale";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = vale }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                datosVale.id_vale = int.Parse(dr["idPedidoValeDigital"].ToString());
                                datosVale.cliente = dr["Cliente"].ToString();
                                datosVale.vale = dr["Vale"].ToString();
                                datosVale.tipo = int.Parse(dr["TipoPedido"].ToString());
                                datosVale.total = double.Parse(dr["Total"].ToString());
                                datosVale.correo = dr["Correo"].ToString();
                                datosVale.telefono = dr["Telefono"].ToString();
                                datosVale.canal = int.Parse(dr["Canal"].ToString());
                                datosVale.condicion = dr["Condicion"].ToString();
                                datosVale.beneficiarioFinal = dr["ClienteBF"].ToString();
                                datosVale.PuntosRedimidos = double.Parse(dr["PuntosRedimidos"].ToString());
                            }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return datosVale;
        }

        public static List<string> getProductosVale(int id)
        {
            List<string> productos = new List<string>();

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "getProductosVale" },
                        new SqlParameter("@id", SqlDbType.VarChar) { Value = id }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                string sku = dr["sku"].ToString();
                                productos.Add(sku);
                            }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return productos;
        }

        public static string getNipCliente(string cliente)
        {
            string NIP = "";

            try
            {
                string query = string.Format("Select NIP_VENTA From DM0244_CLAVES WITH(NOLOCK) Where Cuenta = '{0}'",
                    cliente);
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                return dr[0].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return NIP;
        }

        public static bool checarSiValeDigital(string valeDigital)
        {
            //Respuesta
            //0 - Vale Correcto
            //1 - Vale No existe

            try
            {
                using (SqlCommand cmd = new SqlCommand("SpCREDIValeDigital", ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] parametros =
                    {
                        new SqlParameter("@Op", SqlDbType.VarChar) { Value = "checarTipoVale" },
                        new SqlParameter("@Vale", SqlDbType.VarChar) { Value = valeDigital }
                    };
                    cmd.Parameters.AddRange(parametros.ToArray());

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                int res = int.Parse(dr[0].ToString());
                                if (res == 1) return true;
                            }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return false;
        }
    }
}