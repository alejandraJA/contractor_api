﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta.Controller
{
    internal class CSituaciones
    {
        /// <summary>
        ///     Obtiene las situaciones que el usuario puede modificar en la venta seleccionada
        /// </summary>
        /// <returns>List<MSituaciones></returns>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        public static List<MSituaciones> ObtenerSituaciones()
        {
            List<MSituaciones> Situaciones = new List<MSituaciones>();

            SqlCommand command = new SqlCommand("SP_DM0312Situaciones", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@Usuario", AccesosDeUsuario.CUsuario.Usuario);
            command.Parameters.AddWithValue("@IDVenta", Dm0312DetalleSituaciones.IdVenta);
            command.Parameters.AddWithValue("@Estatus", Dm0312DetalleSituaciones.Estatus);
            command.Parameters.AddWithValue("@Mov", Dm0312DetalleSituaciones.Mov);
            command.Parameters.AddWithValue("@ObtenerSituaciones", true);
            command.CommandType = CommandType.StoredProcedure;
            SqlParameter returnParameter = command.Parameters.Add("@ReturnVal", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;

            try
            {
                SqlDataReader dr = command.ExecuteReader();
                int result = 1;
                if (returnParameter.Value != null) result = (int)returnParameter.Value;

                if (result == 1)
                {
                    if (dr.HasRows)
                        while (dr.Read())
                        {
                            MSituaciones NuevaSituacion = new MSituaciones
                            {
                                ID = (int)dr["ID"],
                                Situacion = (string)dr["Situacion"]
                            };
                            Situaciones.Add(NuevaSituacion);
                        }
                }
                else
                {
                    Situaciones.Clear();
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerSituaciones", "CSituaciones.cs", ex);
                MessageBox.Show(ex.Message + " function: ObtenerSituaciones, class: CSituaciones");
            }

            return Situaciones;
        }

        /// <summary>
        ///     Cambia la situacion del movimiento
        /// </summary>
        /// <param name="NuevaSituacion">string</param>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        //public void CambiarSituacion(string NuevaSituacion)
        //-TipoDima ↓ 2019-05-25
        public void CambiarSituacion(string NuevaSituacion, string mov, int canal)
        {
            CDetalleVenta Detalle = new CDetalleVenta();
            DateTime FechaHoy = Detalle.ObtenerFechaSQL();
            SqlCommand command = new SqlCommand("spCambiarSituacion", ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@ID", Dm0312DetalleSituaciones.IdVenta);
            command.Parameters.AddWithValue("@Modulo", "VTAS");
            command.Parameters.AddWithValue("@Situacion", NuevaSituacion);
            command.Parameters.AddWithValue("@SituacionFecha", FechaHoy);
            command.Parameters.AddWithValue("@SituacionUsuario", AccesosDeUsuario.CUsuario.Usuario);
            command.Parameters.AddWithValue("@Usuario", AccesosDeUsuario.CUsuario.Usuario);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                command.ExecuteNonQuery();

                //-TipoDima ↓ 2019-05-25
                if (mov == "Analisis Credito" && (canal == 76 || canal == 3) && NuevaSituacion == "Condicionado")
                {
                    string g = getValr(Dm0312DetalleSituaciones.IdVenta);

                    if (g != "NO") setCrmCantidadValr(Dm0312DetalleSituaciones.IdVenta, g);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CambiarSituacion", "CSituaciones.cs", ex);
                MessageBox.Show(ex.Message + " function: CambiarSituacion, class: CSituaciones.cs");
            }
        }

        public string ListaSituacionesProspecto(string situacion)
        {
            SqlDataReader reader = null;
            string str = "";
            try
            {
                reader = new SqlCommand(
                        string.Format(
                            "select nombre from tablastd  with (nolock) where tablast='situaciones bf' and nombre= '" +
                            situacion + "'"), ClaseEstatica.ConexionEstatica)
                    { CommandType = CommandType.Text }.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read()) str = reader[0].ToString();
                    return str;
                }

                return "NO";
            }
            catch (Exception exception)
            {
                DM0312_ErrorLog.RegistraError("ListaSituacionesProspecto", "CSituaciones", exception);
                MessageBox.Show(exception.Message);
            }
            finally
            {
                if (reader != null) reader.Close();
            }

            return str;
        }

        public string ClienteVenta(int id)
        {
            SqlDataReader dr = null;
            string tipo = "";
            try
            {
                string query = string.Empty;
                query = "SELECT top 1 cliente FROM venta with(nolock) WHERE id ='" + id + "'";

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        tipo = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AlmacenActivoFijo", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return tipo;
        }

        /// <summary>
        ///     Valida si la situacion puede continuar en canal 76
        /// </summary>
        /// <param name="ID">string</param>
        /// <param name="EnviarA">string</param>
        /// <param name="Situacion">string</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 17/11/17
        public static bool Validacion76(string ID, string EnviarA, string Situacion)
        {
            SqlCommand command = new SqlCommand("SELECT dbo.fn_MaviDM0244ValidaSituacion(@ID, @EnviarA, @Situacion)",
                ClaseEstatica.ConexionEstatica);
            command.Parameters.AddWithValue("@ID", ID);
            command.Parameters.AddWithValue("@EnviarA", EnviarA);
            command.Parameters.AddWithValue("@Situacion", Situacion);
            command.CommandType = CommandType.Text;
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr[0].ToString() != "S")
                            if (dr[0].ToString() != "no se ha cambiado de prospecto a Cliente final")
                            {
                                MessageBox.Show(dr[0].ToString());
                                return false;
                            }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Validacion76", "CSituaciones.cs", ex);
                MessageBox.Show(ex.Message + " function: Validacion76, class: CSituaciones.cs");
            }

            return true;
        }

        #region //-Dineralia

        /// <summary>
        ///     Metodo encargado de validar si se encuentra el registro de la validacion del analisis de dineralia
        /// </summary>
        /// <param name="iIdVenta">id de la venta (analisis credito)</param>
        /// <param name="sCliente">cliente al cual se le hizo la venta de dineralia</param>
        /// <returns>retorna true si la validacion se encuentra</returns>
        public bool validacionDineralia(int iIdVenta, string sCliente)
        {
            bool bValidacionDineralia = false;
            try
            {
                string sQuery = "SELECT TOP 1 cliente " +
                                "FROM VTASHSolicitudesDineralia WITH(NOLOCK) " +
                                "WHERE IdVenta = @IdVenta " +
                                "AND Cliente = @Cliente " +
                                "AND ImagenFrontalAceptada = CONVERT(bit, 1) " +
                                "AND IneFrontalAceptada = CONVERT(bit, 1) " +
                                "AND IneReversoAceptada = CONVERT(bit, 1) " +
                                "AND ClienteExpressAceptado = CONVERT(bit, 1) " +
                                "AND BuroCreditoAceptado = CONVERT(bit, 1) " +
                                "AND ListaNominalAceptada = CONVERT(bit, 1) " +
                                "AND RespuestaBancoAceptada = CONVERT(bit, 1); ";

                SqlParameter[] pars =
                {
                    new SqlParameter("@IdVenta", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bValidacionDineralia = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bValidacionDineralia;
        }

        #endregion

        #region -TipoDima 2019-05-25

        //-TipoDima ↓ 2019-05-25
        public string getValr(int idVenta)
        {
            SqlDataReader reader = null;
            string str = "NO";
            try
            {
                reader = new SqlCommand(
                        string.Format(
                            "select top 1 articulo from ventad with(nolock) where id={0} and articulo like 'VALR%'",
                            idVenta), ClaseEstatica.ConexionEstatica)
                    { CommandType = CommandType.Text }.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read()) str = reader[0].ToString();
                    return str;
                }
                //return str;
            }
            catch (Exception exception)
            {
                DM0312_ErrorLog.RegistraError("getValr", "CSituaciones", exception);
                MessageBox.Show(exception.Message);
            }
            finally
            {
                if (reader != null) reader.Close();
            }

            return str;
        }


        //-TipoDima ↓ 2019-05-25
        public void setCrmCantidadValr(int idVenta, string articulo)
        {
            try
            {
                using (SqlCommand sqlCommand =
                       new SqlCommand("SpCREDIActualizarCreditoDima", ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@IdVenta", idVenta);
                    sqlCommand.Parameters.AddWithValue("@Articulo", articulo);
                    sqlCommand.ExecuteNonQuery();
                }
            }
            catch (Exception exception)
            {
                DM0312_ErrorLog.RegistraError("getValr", "CSituaciones", exception);
                MessageBox.Show(exception.Message);
            }
        }

        #endregion

        #region Mops

        /// <summary>
        ///     Metodo encargado de validar si la situacion aplicara para validar los dines
        /// </summary>
        /// <param name="sSituacion">Situacion a evaluar</param>
        /// <returns>retorna true si la situacion se encuentra registrada</returns>
        public bool validarSituacion(string sSituacion)
        {
            bool bAcceso = false;
            try
            {
                string sQuery =
                    "SELECT IdLimitePrestamosSituaciones FROM CREDIDLimitePrestamosSituaciones WITH(NOLOCK) WHERE Situacion = @Situacion";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Situacion", sSituacion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        public bool validarUsuario()
        {
            bool bAcceso = false;
            try
            {
                string sQuery =
                    "SELECT IdLimitePrestamosUsuarios FROM CREDIDLimitePrestamosUsuarios WITH(NOLOCK) WHERE TipoDeFacultad = 'EXCEDENTE' AND Perfil = @Acceso";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        public void insertarUsuarioFacultado(DM0312_MExploradorVenta mVenta, int iPlazo, string sEvento,
            string sUltimoEvento)
        {
            try
            {
                string sQuery =
                    "INSERT INTO CREDICAutorizacionMovDines (SucursalOrigen,Analisis,FechaMovto,ImporteMovto,Plazo,Analista," +
                    "FechaAnalista,CalificacionAnalista,UsuarioFacultado," +
                    "CalificacionFacultado,Observacion,FechaAutorizacion) VALUES " +
                    "(@Sucursal, @MovId, GETDATE(), @ImporteMov, @Plazo, @Analista, @FechaAnalisis,@CalificacionAnalista, @UsuarioFacultado, @Calificacion, @Observacion, GETDATE())";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", mVenta.Suc)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter(@"MovId", mVenta.MovId)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@ImporteMov", mVenta.ImporteTotal)
                    {
                        SqlDbType = SqlDbType.Money
                    },
                    new SqlParameter("@Plazo", iPlazo)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Analista", mVenta.Usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@FechaAnalisis", mVenta.FechaAlta)
                    {
                        SqlDbType = SqlDbType.DateTime
                    },
                    new SqlParameter("@CalificacionAnalista", sEvento.Split('|')[0])
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@UsuarioFacultado", ClaseEstatica.Usuario.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Calificacion", sUltimoEvento)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Observacion", sEvento.Split('|')[1])
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de obtener el tipo de politica del cliente
        /// </summary>
        /// <param name="sCliente">Cliente del cual se obtendra el tipo de politica</param>
        /// <returns>retorna una cadena con el tipo de politica</returns>
        public string obtenerTipoPolitica(string sCliente)
        {
            string sTipoPlitica = string.Empty;
            DataTable dt = new DataTable();
            try
            {
                string sQuery = "SELECT CREDITO FROM Cte WITH(NOLOCK) WHERE Cliente = @Cliente";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Cliente", sCliente)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sTipoPlitica = item["CREDITO"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sTipoPlitica;
        }

        public double obtenerMontoPolitica(string sTipoCredito, int iPlazo, int iCanalVenta)
        {
            double dMonto = 0;
            DataTable dt = new DataTable();
            try
            {
                string sQuery =
                    "SELECT TotalPrestamo FROM CREDIDLimitePrestamosPolitica WITH(NOLOCK) WHERE TipoDePolitica = @TipoPolitica AND PlazoEje = @Plazo AND CanalDeVenta = @Canal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@TipoPolitica", sTipoCredito)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Plazo", iPlazo)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Canal", iCanalVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMonto = double.Parse(item["TotalPrestamo"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dMonto;
        }

        /// <summary>
        ///     Metodo encargado de obtener el importe de la venta
        /// </summary>
        /// <param name="iId">Id de venta</param>
        /// <returns>retorna la suma del importe mas impuestos de la tabla venta</returns>
        public double obtenerImporteVenta(int iId)
        {
            double dMonto = 0;
            DataTable dt = new DataTable();
            try
            {
                string sQuery = "SELECT importe + impuestos AS ImporteVenta from VENTA WITH(NOLOCK) where id = @id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        dMonto = double.Parse(item["ImporteVenta"].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return dMonto;
        }

        /// <summary>
        ///     Metodo encargado de validar si el articulo es de la familia crediliana credilana
        /// </summary>
        /// <param name="iId">id de la venta a validar</param>
        /// <returns>retorna true si la venta contiene un articulo de la venta CREDILANA</returns>
        public bool validarArticulo(int iId)
        {
            bool bArticuloCorrecto = false;
            try
            {
                string sQuery = @"SELECT
                                  vd.id
                                FROM ventad vd WITH(NOLOCK)
                                INNER JOIN Art ar WITH(NOLOCK)
                                  ON vd.Articulo = ar.Articulo
                                WHERE vd.ID = @Id
                                AND ar.Linea = 'CREDILANA'";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bArticuloCorrecto = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bArticuloCorrecto;
        }

        #endregion
    }
}