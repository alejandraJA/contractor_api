﻿//-PrimeraFaseDeAutomatizacion //-ReservaOnline

using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class clsSolicitudCodigo
    {
        public bool validarClave(string sClave)
        {
            string query = string.Empty;
            bool bExiste = false;
            query = string.Format(
                "SELECT 1 AS Resultado FROM TrWDM0285_CteRecoge WITH(NOLOCK) WHERE ClaveVenta = '{0}'", sClave);
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        if (int.Parse(dr["Resultado"].ToString()) == 1)
                            bExiste = true;
                        else
                            bExiste = false;
                else
                    bExiste = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "clsSolicitudCodigo", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return bExiste;
        }

        public string obtenerClave(string sClave)
        {
            string query = string.Empty;
            string sClaveRetorno = string.Empty;
            query = string.Format("SELECT ClaveVenta FROM TrWDM0285_CteRecoge WITH(NOLOCK) WHERE ClaveVenta = '{0}'",
                sClave);
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        sClaveRetorno = dr["ClaveVenta"].ToString();
                else
                    sClaveRetorno = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "clsSolicitudCodigo", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return sClaveRetorno;
        }

        public string validarEstatusClave(string sClave)
        {
            string query = string.Empty;
            string sEstatusClave = string.Empty;
            query = string.Format(
                "Select Estatus from TrWDM0285_CteRecoge r WITH(NOLOCK) inner JOIN Venta v WITH(NOLOCK) ON(r.idecommerce = v.idecommerce) where r.ClaveVenta = '{0}' " +
                "AND Mov = 'PEDIDO'", sClave);
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        sEstatusClave = dr["Estatus"].ToString();
                else
                    sEstatusClave = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "clsSolicitudCodigo", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null) dr.Close();
            }

            return sEstatusClave;
        }
    }
}