﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    internal class CDetalleEnganche
    {
        /// <summary>
        ///     Obtiene los anticipos pendientes
        /// </summary>
        /// <returns>List<MDetalleEnganchePendientes></returns>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        public List<MDetalleEnganchePendientes> ObtenerPendientes(string Mov, string MovID, ref string Cuenta,
            ref double AnticiposPendientes)
        {
            List<MDetalleEnganchePendientes> Pendientes = new List<MDetalleEnganchePendientes>();

            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_MaviDM0312PuntoVentaDetalles", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                sqlCommand.Parameters.AddWithValue("@ObtenerPendientes", true);
                sqlCommand.Parameters.AddWithValue("@Mov", Mov);
                sqlCommand.Parameters.AddWithValue("@MovID", MovID);
                AnticiposPendientes = 0;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MDetalleEnganchePendientes NuevoPendiente = new MDetalleEnganchePendientes
                        {
                            Referencia = dr["Referencia"].ToString(),
                            Saldo = Convert.ToDouble(dr["Saldo"]).ToString("C"),
                            Fecha = Convert.ToDateTime(dr["Fecha"]).ToString("dd-MM-yyyy")
                        };
                        Pendientes.Add(NuevoPendiente);
                        Cuenta = dr["Cuenta"].ToString();
                        AnticiposPendientes = AnticiposPendientes + Convert.ToDouble(dr["Saldo"]);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerPendientes", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " Error funcion ObtenerPendientes");
            }

            return Pendientes;
        }

        /// <summary>
        ///     Obtiene los anticipos pendientes
        /// </summary>
        /// <returns>List<MDetalleEngancheRealizados></returns>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        public List<MDetalleEngancheRealizados> ObtenerRealizados(string Mov, string MovID,
            ref double TotalAnticiposRealizados)
        {
            List<MDetalleEngancheRealizados> Realizados = new List<MDetalleEngancheRealizados>();

            try
            {
                SqlCommand sqlCommand =
                    new SqlCommand("SP_MaviDM0312PuntoVentaDetalles", ClaseEstatica.ConexionEstatica)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                sqlCommand.Parameters.AddWithValue("@ObtenerRealizados", true);
                sqlCommand.Parameters.AddWithValue("@Mov", Mov);
                sqlCommand.Parameters.AddWithValue("@MovID", MovID);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                TotalAnticiposRealizados = 0;
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        MDetalleEngancheRealizados NuevoRealizado = new MDetalleEngancheRealizados
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            Referencia = dr["Referencia"].ToString()
                        };
                        if (dr["Abono"] != null && dr["Abono"].ToString() != string.Empty)
                        {
                            NuevoRealizado.Abono = Convert.ToDouble(dr["Abono"]).ToString("C");
                            TotalAnticiposRealizados = TotalAnticiposRealizados + Convert.ToDouble(dr["Abono"]);
                        }
                        else
                        {
                            NuevoRealizado.Abono = "$ 0.00";
                        }

                        NuevoRealizado.Movimiento = dr["Mov"] + " " + dr["MovID"];
                        NuevoRealizado.Fecha = Convert.ToDateTime(dr["Fecha"]).ToString("dd-MM-yyyy");
                        Realizados.Add(NuevoRealizado);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerRealizados", "CDetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " Error funcion ObtenerRealizados");
            }

            return Realizados;
        }
    }
}