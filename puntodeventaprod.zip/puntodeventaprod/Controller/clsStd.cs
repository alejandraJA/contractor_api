﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class clsStd
    {
        private DataTable dt;

        #region //-1037-A

        public bool validarAccesoResumenFactura()
        {
            bool bTieneAcceso = false;
            try
            {
                string sQuery =
                    "SELECT nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'PERFILRESUMENFACTURAMAYOREO' AND Nombre = @Acceso";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bTieneAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bTieneAcceso;
        }

        #endregion

        #region //-343E

        /// <summary>
        ///     Metodo encargado de validar que usuario puede ver el boton de scoring
        /// </summary>
        /// <returns>retorna true si el usuario puede ver el boton scoring</returns>
        /// //-343E
        public bool accesoScoring()
        {
            bool bAcceso = false;
            try
            {
                string sQuery =
                    "SELECT Nombre FROM TablaStd WITH(NOLOCK) where TablaSt = 'USUARIOS SCORING' AND Nombre = @Usuario";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Usuario", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bAcceso;
        }

        #endregion

        #region //-1200

        /// <summary>
        ///     Metodo encargado de activar el menu orden de compra
        /// </summary>
        /// <returns>retorna true el la sucursal del usuario se encuentra en la tabla ORDERDECOMPRA</returns>
        public bool validarAccesoOrdenCompra()
        {
            bool bTieneAcceso = false;
            try
            {
                string sQuery =
                    "SELECT nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'ORDENDECOMPRA' AND Nombre = @Sucursal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.sucursal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bTieneAcceso = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bTieneAcceso;
        }

        #endregion

        public bool apagarPromociones()
        {
            bool bEncendido = false;
            try
            {
                string sQuery =
                    "select valor from TablaStD where TablaSt = 'CONTROL MODULO PROMOCIONES PUNTO DE VENTA' AND Valor = 1";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEncendido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bEncendido;
        }

        public bool validarCheckIva()
        {
            bool bEditarCheck = false;
            try
            {
                string sQuery =
                    "SELECT nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'P VENTA BANDERA DESGLOSAR IVA' AND Nombre = @Acceso";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bEditarCheck = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bEditarCheck;
        }

        #region //-917

        /// <summary>
        ///     Metodo encargado de consultar la tabla std SUCURSALESMX
        /// </summary>
        /// <param name="sTipoCredito">Tipo de credito del cliente</param>
        /// <param name="iOpcion">Opcion de la consulta</param>
        /// <returns>retorna true o false saludos</returns>
        /// //-731
        public bool validarSucursalMx(string sTipoCredito, int iOpcion)
        {
            bool bDatosValidos = false;
            string sQuery = string.Empty;
            dt = new DataTable();
            try
            {
                //sucursal que existe y tipo de credito diferente
                if (iOpcion == 1)
                    sQuery =
                        "SELECT 1 FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Nombre = @Sucursal AND Valor != @Valor";
                if (iOpcion == 2)
                    sQuery =
                        "SELECT nombre FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Nombre != @Sucursal AND Valor = @Valor";
                if (iOpcion == 3)
                    sQuery =
                        "SELECT nombre FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Nombre = @Sucursal AND Valor = @Valor";
                if (iOpcion == 4)
                    sQuery =
                        "SELECT nombre FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Nombre != @Sucursal AND Valor != @Valor";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.Sucursal)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Valor", sTipoCredito)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (iOpcion == 1 || iOpcion == 3 || iOpcion == 4) bDatosValidos = dr.HasRows;
                        if (iOpcion == 2) dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        if (int.Parse(item["nombre"].ToString()) == ClaseEstatica.Usuario.Sucursal)
                            return true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bDatosValidos;
        }

        public bool validarMx(string sTipoCredito)
        {
            bool bDatosValidos = false;
            string sQuery = string.Empty;
            try
            {
                sQuery =
                    "SELECT TOP 1 valor FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Valor = @Valor";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Valor", sTipoCredito)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bDatosValidos = dr.HasRows;
                    }
                }
            }

            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bDatosValidos;
        }

        public bool validarSucursalVentaEnLinea()
        {
            bool bDatosValidos = false;
            string sQuery = string.Empty;
            dt = new DataTable();
            try
            {
                sQuery =
                    "SELECT TOP 1 nombre FROM Tablastd WITH(NOLOCK) WHERE Tablast = 'SUCURSALESMX' AND Nombre = @Sucursal";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Sucursal", ClaseEstatica.Usuario.Sucursal)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bDatosValidos = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bDatosValidos;
        }

        public int obtenerSucursal(string sCliente)
        {
            int iSucursal = 0;

            SqlCommand command = new SqlCommand(
                "select top 1 sucursalorigen from venta where cliente = @Cliente order by id asc",
                ClaseEstatica.ConexionEstatica);

            command.Parameters.Add(new SqlParameter("@Cliente", sCliente));
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read()) iSucursal = int.Parse(dr[0].ToString());

            return iSucursal;
        }

        public bool realizarValidacion()
        {
            bool bDatosValidos = false;
            string sQuery = string.Empty;
            dt = new DataTable();
            try
            {
                sQuery = "SELECT COUNT(*) AS Existencias FROM TablaStd WITH(NOLOCK) WHERE TablaSt = 'SUCURSALESMX'";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow row in dt.Rows)
                        if (int.Parse(row["Existencias"].ToString()) > 0)
                            bDatosValidos = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bDatosValidos;
        }

        #endregion

        #region //-PedidoSinDetalle

        /// <summary>
        ///     metodo encargado de insertar el id de la venta
        /// </summary>
        /// <param name="iId">id Venta</param>
        public void insertarIdVenta(int iId, int iOpcion)
        {
            try
            {
                string sQuery = string.Empty;
                if (iOpcion == 1)
                    sQuery = "INSERT INTO VTASDVentasPorAfectar (IdVenta, Usuario) VALUES ( @Id, @Usuario )";
                if (iOpcion == 2) sQuery = "DELETE FROM VTASDVentasPorAfectar WHERE IdVEnta =  @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Usuario", ClaseEstatica.Usuario.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     metodo encargado de obtener la diferencia de minutos del id afectado
        /// </summary>
        /// <param name="idventa"></param>
        public int DiferenciaMinutos(int idventa)
        {
            int diferencia = 0;
            try
            {
                string sQuery =
                    "select DATEDIFF(N,FechaRegistro,GETDATE()) as 'Diferencia' from VTASDVentasPorAfectar with(nolock) where IdVenta = @Id";
                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", idventa)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                diferencia = int.Parse(dr["Diferencia"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return diferencia;
        }

        /// <summary>
        ///     metodo encargado de validar si el id de la venta se encuentra afectandose
        /// </summary>
        /// <param name="iId">id venta</param>
        /// <returns>retorna true si se encuentra afectandose</returns>
        public bool validarIdVenta(int iId)
        {
            bool bIdValido = false;
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT IdVenta FROM VTASDVentasPorAfectar WITH(NOLOCK) WHERE idVenta = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bIdValido = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bIdValido;
        }

        /// <summary>
        ///     Metodo encargado de obtener el estatus acutal del id de venta ya que puede tener desfase
        /// </summary>
        /// <param name="iId">Id de la tabla venta</param>
        /// <returns>Retorna un string con el estatus actual del movimiento</returns>
        public string obtenerEstatuMovimiento(int iId)
        {
            string sEstatus = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = "SELECT Estatus FROM VENTA WITH(NOLOCK) WHERE id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0) sEstatus = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sEstatus;
        }

        #endregion

        #region //-CerradoIntelisis

        /// <summary>
        ///     Metodo encargado de generar un md5 con el usuario y la fecha del dia
        /// </summary>
        /// <param name="str">usuario y fecha</param>
        /// <returns>retorna una cadena con el md5</returns>
        public string GetMD5(string str)
        {
            MD5 md5 = MD5.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] stream = null;
            StringBuilder sb = new StringBuilder();
            stream = md5.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }

        /// <summary>
        ///     actualiza el campo
        /// </summary>
        /// <param name="sMd5"></param>
        /// <param name="sUsuario"></param>
        public void actualizarMd5(string sMd5, string sUsuario)
        {
            try
            {
                string sQuery = @"UPDATE a 
                                SET a.Token = @Md5
                                FROM(SELECT Token,
                                ROW_NUMBER() OVER(ORDER BY ID DESC) AS IDRow
                                FROM Acceso
                                WHERE Usuario = @Usuario
                                AND FechaSalida IS NULL) a
                                where idrow = 1";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Md5", sMd5)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Usuario", sUsuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion


        #region //-1450

        /// <summary>
        ///     Metodo encargado de activar el boton de embarcar
        /// </summary>
        /// <returns>retorna true si el acceso del usuario puede embarcar</returns>
        public bool usuarioTieneAccesoAbtnEmbarcar()
        {
            bool bBotonVisible = false;
            try
            {
                string sQuery =
                    "SELECT nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'FUNC EMBARCAR Y DESEMBARCAR' AND Nombre = @Acceso";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bBotonVisible = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bBotonVisible;
        }

        /// <summary>
        ///     Metodo encargado de validar si el usuario
        /// </summary>
        /// <returns>retorna true si el acceso del usuario puede hacer cambio de almacen de lo contrario false</returns>
        public bool validarCambioAlmacen()
        {
            bool bCambioAlmacen = false;
            try
            {
                string sQuery =
                    "SELECT nombre FROM tablastd WITH(NOLOCK) WHERE tablast = 'PERMISO DEVOLUCION PUNTO DE VENTA MAGENTO' AND Nombre = @Acceso";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Acceso", ClaseEstatica.Usuario.Acceso)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        bCambioAlmacen = dr.HasRows;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bCambioAlmacen;
        }

        /// <summary>
        ///     Este methodo valida el acceso cambaceo
        /// </summary>
        /// <returns> bool </returns>
        public bool validarAccesoCambaceo()
        {
            try
            {
                bool esCambaceo = false;
                string query =
                    "SELECT * FROM Tablastd with (NOLOCK) WHERE Tablast = 'ACCESO CAMBACEO' AND Nombre = @Acceso;";

                using (SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    command.CommandType = CommandType.Text;
                    command.Parameters.AddWithValue("@Acceso", ClaseEstatica.Usuario.Acceso);
                    SqlDataReader response = command.ExecuteReader();
                    esCambaceo = response.HasRows;
                }

                return esCambaceo;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        #endregion
    }
}