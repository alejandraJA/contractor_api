﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_ConfiguracionColumnas
    {
        /// <summary>
        ///     Obtiene los accesos disponibles para la configuracion de columnas
        /// </summary>
        public DataTable ObtieneAcceso()
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@opc  ", SqlDbType.Int).Value = 10;
                command.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Forma", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneAcceso", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene los campos que se van a mostrar de cada acceso
        /// </summary>
        public DataTable ObtieneConfiguracionComponentesUsuario(string forma, string campo)
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@opc  ", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Forma", SqlDbType.VarChar).Value = forma;
                command.Parameters.Add("@Campo", SqlDbType.VarChar).Value = campo;
                command.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneConfiguracionComponentesUsuario",
                    "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene las formas que se van a mostrar de cada acceso
        /// </summary>
        public DataTable ObtieneForma()
        {
            DataTable dataSet = new DataTable();
            SqlCommand command = null;
            try
            {
                command = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@opc  ", SqlDbType.Int).Value = 2;
                command.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Forma", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneForma", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }

            return dataSet;
        }

        /// <summary>
        ///     Obtiene los un nuevo acceso y permite clonar los componentes de otro ya existente
        /// </summary>
        public List<DM0312_MConfiguracionColumnas> ObtieneNuevoAcceso()
        {
            DataTable dataSet = new DataTable();
            List<DM0312_MConfiguracionColumnas> listModel = new List<DM0312_MConfiguracionColumnas>();
            SqlCommand command = null;
            SqlDataReader dr = null;
            try
            {
                command = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@opc  ", SqlDbType.Int).Value = 7;
                command.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Forma", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                command.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                command.CommandType = CommandType.StoredProcedure;
                dr = command.ExecuteReader();
                while (dr.Read())
                {
                    DM0312_MConfiguracionColumnas model_ = new DM0312_MConfiguracionColumnas();
                    model_.Acceso = dr["Acceso"].ToString();
                    listModel.Add(model_);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneNuevoAcceso", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return listModel;
        }

        /// <summary>
        ///     Obtiene los permisos de cada acceso nuevo
        /// </summary>
        public List<DM0312_MConfiguracionColumnas> ObtienePermisos(string Acceso, string Forma)
        {
            List<DM0312_MConfiguracionColumnas> Lista = new List<DM0312_MConfiguracionColumnas>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 3;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = Acceso;
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = Forma;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                dr = cmd.ExecuteReader();

                DM0312_MConfiguracionColumnas EmptyModel = new DM0312_MConfiguracionColumnas();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MConfiguracionColumnas model_ = new DM0312_MConfiguracionColumnas();

                        model_.Campo = dr["Campo"].ToString();
                        model_.DescripcionCampo = dr["DescripcionCampo"].ToString();
                        //     model_.Estatus = Convert.ToBoolean(dr["Estatus"]);
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtienePermisos", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }


        public List<DM0312_MConfiguracionColumnas> ObtieneTodosPermisos(string Acceso)
        {
            List<DM0312_MConfiguracionColumnas> Lista = new List<DM0312_MConfiguracionColumnas>();
            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 8;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = Acceso;
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                dr = cmd.ExecuteReader();

                DM0312_MConfiguracionColumnas EmptyModel = new DM0312_MConfiguracionColumnas();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        DM0312_MConfiguracionColumnas model_ = new DM0312_MConfiguracionColumnas();
                        model_.Forma = dr["FormaUsuario"].ToString();
                        model_.Campo = dr["DescripcionCampo"].ToString();
                        model_.Estatus = bool.Parse(dr["Estatus"].ToString());
                        Lista.Add(model_);
                    }
                else
                    Lista.Add(EmptyModel);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtieneTodosPermisos", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return Lista;
        }

        public bool Existe(string Acceso, string Forma, string Campo)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 6;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = Acceso;
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = Forma;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();

                while (dr.Read()) existe = true; //bool.Parse(dr["Estatus"].ToString()); ;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Existe", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }

        public int Actualiza(string Acceso, string Forma, string Campo, bool Estatus)
        {
            int existe = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 4;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = Acceso;
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = Forma;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = Estatus;
                existe = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Actualiza", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }

            return existe;
        }

        public bool Inserta(string Acceso, string Forma, string Campo, bool Estatus)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 5;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = Acceso;
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = Forma;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = Estatus;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        existe = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Inserta", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }

        public bool ExisteCampo(string Forma, string Campo)
        {
            SqlDataReader dr = null;
            bool existe = false;
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DM0312ConfiguracionColumnas", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@opc  ", SqlDbType.Int).Value = 9;
                cmd.Parameters.Add("@Acceso", SqlDbType.VarChar).Value = "";
                cmd.Parameters.Add("@Forma", SqlDbType.VarChar).Value = Forma;
                cmd.Parameters.Add("@Campo", SqlDbType.VarChar).Value = Campo;
                cmd.Parameters.Add("@Estatus", SqlDbType.Bit).Value = 0;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        existe = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ExisteCampo", "DM0312_C_ConfiguracionColumnas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return existe;
        }
    }
}