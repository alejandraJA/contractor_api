﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public partial class DM0312_CPuntoDeVenta
    {
        public int validarPagoDie(int iId)
        {
            int iPagoDie = 0;
            SqlDataReader dr = null;
            string query =
                string.Format("select convert(int, pagodie) AS pagodie from venta  WITH (NOLOCK) where id = {0}", iId);

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        iPagoDie = int.Parse(dr[0].ToString());
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarPagoDie", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return iPagoDie;
        }

        #region Formas de pago, anticipos y afectar by Dan

        /// <summary>
        ///     Combobox con formas de pago
        /// </summary>
        /// <returns>ComboBox</returns>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        //public ComboBox ObtenerFormasDePago(List<string> FormasPagoAgregadas)
        //{

        //    ComboBox cb_FormasPago = new ComboBox();
        //    string query = string.Format("SELECT FormaPago FROM FormaPago WITH(NOLOCK) WHERE PV = 1");
        //    string FirstPago = "";
        //    try
        //    {
        //        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
        //        sqlCommand.CommandType = CommandType.Text;
        //        SqlDataReader dr = sqlCommand.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                cb_FormasPago.Items.Add(dr["FormaPago"].ToString());
        //                if (FirstPago == string.Empty && !FormasPagoAgregadas.Contains(dr["FormaPago"].ToString()))
        //                {
        //                    FirstPago = dr["FormaPago"].ToString();
        //                }
        //            }
        //        }
        //        dr.Close();
        //        if (!FormasPagoAgregadas.Contains("EFECTIVO"))
        //        {
        //            cb_FormasPago.Text = "EFECTIVO";
        //        }
        //        else
        //        {
        //            cb_FormasPago.Text = FirstPago;
        //        }
        //        FormasPagoAgregadas.Add(cb_FormasPago.Text);
        //    }
        //    catch (Exception ex)
        //    {
        //        DM0312_ErrorLog.RegistraError("ObtenerFormasDePago", "DM0312_CPuntoDeVenta", ex);
        //        MessageBox.Show(ex.Message + " function: ObtenerFormasDePago, class: DM0312_CPuntoDeVenta.AfectarYAnticipos.cs");
        //    }

        //    return cb_FormasPago;
        //}
        public ComboBox ObtenerFormasDePago(List<string> FormasPagoAgregadas, string condicion)
        {
            ComboBox cb_FormasPago = new ComboBox();
            string query = string.Empty;
            if (condicion == "1")
            {
                if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                    query = "SELECT FormaPago FROM FormaPago WITH(NOLOCK) WHERE VentaLinea='SI' ORDER BY FormaPago ";
                else
                    query = "SELECT FormaPago FROM FormaPago WITH(NOLOCK) WHERE PV = 1";
            }
            else
            {
                if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                    query = "SELECT FormaPago FROM FormaPago WITH(NOLOCK) WHERE VentaLinea='SI' ORDER BY FormaPago ";
                else
                    query = string.Format(
                        "SELECT f.FormaPago FROM VTASDRelacionCondicionYTipoPago v  WITH(NOLOCK) LEFT JOIN Condicion c ON(v.IDCondicion=c.IDCondicion) LEFT JOIN FormaPago f ON(V.IDFormaPago=F.IDFormaPago)  WHERE c.condicion = '" +
                        condicion + "'");
            }

            string FirstPago = "";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        cb_FormasPago.Items.Add(dr["FormaPago"].ToString());
                        if (FirstPago == string.Empty && !FormasPagoAgregadas.Contains(dr["FormaPago"].ToString()))
                            FirstPago = dr["FormaPago"].ToString();
                    }

                dr.Close();
                if (!FormasPagoAgregadas.Contains("EFECTIVO"))
                    cb_FormasPago.Text = "EFECTIVO";
                else
                    cb_FormasPago.Text = FirstPago;
                FormasPagoAgregadas.Add(cb_FormasPago.Text);
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerFormasDePago", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message +
                                " function: ObtenerFormasDePago, class: DM0312_CPuntoDeVenta.AfectarYAnticipos.cs");
            }

            return cb_FormasPago;
        }

        public int ContadorFormasPago(string condicion)
        {
            int valor = 0;
            SqlDataReader dr = null;
            try
            {
                string query = string.Format(
                    "SELECT count(f.FormaPago ) FROM VTASDRelacionCondicionYTipoPago v  WITH(NOLOCK) LEFT JOIN Condicion c ON(v.IDCondicion=c.IDCondicion) LEFT JOIN FormaPago f ON(V.IDFormaPago=F.IDFormaPago)  WHERE c.condicion = '" +
                    condicion + "'");
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valor = int.Parse(dr[0].ToString());
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ContadorFormasPago", "CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }

            dr.Close();
            return valor;
        }

        /// <summary>
        ///     Obtiene las fechas para detalle
        /// </summary>
        /// <param name="IDventa">int</param>
        /// <returns>string[]</returns>
        /// Developer: Dan Palacios
        /// Date: 02/11/17
        public string[] ObtenerFechasParaDetalle(int IDventa)
        {
            string[] Detalles = { "", "" };

            string query = "SELECT FechaEmision, Vencimiento FROM Venta WITH(NOLOCK) WHERE ID = @IDventa";
            try
            {
                int FechaEmision = 0;
                int Vencimiento = 1;

                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@IDventa", IDventa);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Detalles[FechaEmision] = dr["FechaEmision"].ToString();
                        Detalles[Vencimiento] = dr["Vencimiento"].ToString();
                    }

                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerFechasParaDetalle", "DM0312_CPuntoDeVenta.AfectarYAnticipos.cs",
                    ex);
                MessageBox.Show(ex.Message +
                                " function: ObtenerFechasParaDetalle, class: DM0312_CPuntoDeVenta.AfectarYAnticipos.cs");
            }


            return Detalles;
        }

        /// <summary>
        ///     Obtiene cajero
        /// </summary>
        /// <returns>string</returns>
        /// Developer: Dan Palacios
        /// Date: 02/11/17
        public string ObtenerCajero()
        {
            string Cajero = "";

            string query = "SELECT DefCajero FROM Usuario U  WITH (NOLOCK) WHERE U.Usuario = @Usuario";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Usuario", ClaseEstatica.Usuario.usuario);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        Cajero = dr["DefCajero"].ToString();
                dr.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerCajero", "DM0312_CPuntoDeVenta.AfectarYAnticipos.cs", ex);
                MessageBox.Show(ex.Message +
                                " function: ObtenerCajero, class: DM0312_CPuntoDeVenta.AfectarYAnticipos.cs");
            }

            return Cajero;
        }

        #endregion
    }
}