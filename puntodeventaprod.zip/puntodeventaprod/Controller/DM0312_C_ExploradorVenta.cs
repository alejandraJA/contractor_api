﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class DM0312_C_ExploradorVenta
    {
        private EventoController EventoController = new EventoController();

        /// <summary>
        ///     Obtiene el tipo de credito dependiendo de el IdMov
        /// </summary>
        /// <param name="MovID">string</param>
        /// <returns>string</returns>
        /// Developer: Carlos Rizo
        /// Date: 11/09/18
        public string TipoCredito(string MovID)
        {
            string tipoCredito = "";

            SqlCommand command = new SqlCommand("SELECT TipoCredito FROM cte c with(nolock) " +
                                                "where c.cliente = @MovID",
                ClaseEstatica.ConexionEstatica);

            command.Parameters.Add(new SqlParameter("@MovId", MovID));
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read()) tipoCredito = dr[0].ToString();

            return tipoCredito;
        }


        /// <summary>
        ///     Optiene los movimientos posibles a consultar dependiendo el usuario
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 16/09/17
        public List<string> ComboMovimiento(string usuario)
        {
            List<string> movimiento = new List<string>();

            SqlCommand command = new SqlCommand("SP_MaviDM0312PuntoVentaExploradorCampoMovimiento",
                ClaseEstatica.ConexionEstatica);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                SqlParameter sqlParameter = new SqlParameter("@USUARIO", SqlDbType.VarChar);
                sqlParameter.Value = usuario;
                command.Parameters.Add(sqlParameter);
                SqlDataReader slqDataReader = command.ExecuteReader();
                if (slqDataReader.HasRows)
                    while (slqDataReader.Read())
                        movimiento.Add(slqDataReader.GetString(0));
                slqDataReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return movimiento;
        }


        public DataTable FillDataSelecAgente()
        {
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            string query =
                "SELECT Agente, Nombre FROM Agente with (nolock) WHERE(Tipo = 'VENDEDOR' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND " +
                "Estatus = 'ALTA') OR(Tipo = 'GERENTE' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA') OR(Tipo = 'SUBGERENTE' AND " +
                "Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA') OR(Tipo = 'SUPERVISOR' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA') " +
                "OR (Tipo in( 'GERENTE','SUBGERENTE') AND Categoria = 'REACTIVACION VENTAS' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA')";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return dataTable;
        }

        public List<string> ListaReanalis()
        {
            List<string> listareanalisis = new List<string>();
            SqlDataReader drla = null;
            string query =
                "select Nombre+' '+Valor as Nombre from TablaStD a with (nolock) where TablaSt = 'EVENTOS REANALISIS'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                drla = sqlCommand.ExecuteReader();

                if (drla.HasRows)
                    while (drla.Read())
                        listareanalisis.Add(drla[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //TODO WIP(Agregar la barra de Estatus de ser posible esto solo a las vistas)
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            finally
            {
                if (drla != null)
                    drla.Close();
            }

            return listareanalisis;
        }

        public List<DM0312_MConsultarEvento> ListaReanalis2()
        {
            List<DM0312_MConsultarEvento> listareanalisis = new List<DM0312_MConsultarEvento>();

            string query =
                @"select Nombre, Valor as Nombre 
                    from TablaStD a with (nolock) 
                  where TablaSt = 'EVENTOS REANALISIS'";

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;

                    using (SqlDataReader dr = sqlCommand.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                DM0312_MConsultarEvento mEvento = new DM0312_MConsultarEvento();

                                mEvento.Evento = dr[0] + " " + dr[1];
                                mEvento.Clave = dr[1].ToString();

                                listareanalisis.Add(mEvento);
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }

            return listareanalisis;
        }


        public List<string> ListaRespuesta()
        {
            List<string> listarespuesta = new List<string>();
            SqlDataReader drle = null;
            string query = "select Nombre from TablaStD a with (nolock) where TablaSt = 'TIPOS RESPUESTA REANALISIS'";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                drle = sqlCommand.ExecuteReader();

                if (drle.HasRows)
                    while (drle.Read())
                        listarespuesta.Add(drle[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ListaNominas", "DM0312_CExploradorVentas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (drle != null)
                    drle.Close();
            }

            return listarespuesta;
        }

        public void MovimientoReanalis(int id, string usuario, string evento, string agente, string tiporespuesta,
            string observacion)
        {
            try
            {
                SqlCommand command = new SqlCommand("SpIRM1154_RegisReanalisis", ClaseEstatica.ConexionEstatica);
                command.Parameters.Add("@ID  ", SqlDbType.Int).Value = id;
                command.Parameters.Add("@Usuario  ", SqlDbType.VarChar).Value = usuario;
                command.Parameters.Add("@Evento  ", SqlDbType.VarChar).Value = evento;
                command.Parameters.Add("@Agente  ", SqlDbType.VarChar).Value = agente;
                command.Parameters.Add("@TipoRespuesta  ", SqlDbType.VarChar).Value = tiporespuesta;
                command.Parameters.Add("@Observacion  ", SqlDbType.VarChar).Value = observacion;
                command.CommandType = CommandType.StoredProcedure;
                command.ExecuteNonQuery();

                MessageBox.Show("Datos ingresados correctamente", "Exito");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
        }

        public List<string> ListaAgente()
        {
            List<string> listagente = new List<string>();
            SqlDataReader drla = null;
            string query =
                "SELECT Agente FROM Agente with (nolock) WHERE(Tipo = 'VENDEDOR' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' " +
                "AND Estatus = 'ALTA') OR(Tipo = 'GERENTE' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA') OR(Tipo = 'SUBGERENTE' " +
                "AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA') OR(Tipo = 'SUPERVISOR' AND Categoria = 'VENTAS PISO' AND LEFT(Agente, 1) = 'E' AND Estatus = 'ALTA')";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                drla = sqlCommand.ExecuteReader();

                if (drla.HasRows)
                    while (drla.Read())
                        listagente.Add(drla[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ListaAgente", "DM0312_CExploradorVentas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (drla != null)
                    drla.Close();
            }

            return listagente;
        }

        public List<string> LlenaCamposExtras(string mov, int id, string estatus, string usuario)
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;
            try
            {
                SqlCommand cmd = new SqlCommand("spMostrarCamposExtra ", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@VentaMov  ", SqlDbType.VarChar).Value = mov;
                cmd.Parameters.Add("@VentaID  ", SqlDbType.VarChar).Value = id;
                cmd.Parameters.Add("@VentaEst  ", SqlDbType.VarChar).Value = estatus;
                cmd.Parameters.Add("@Us  ", SqlDbType.VarChar).Value = usuario;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        Lista.Add(dr[0].ToString());
                        Lista.Add(dr[1].ToString());
                        Lista.Add(dr[2].ToString());
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaCamposExtras", "DM0312_CExploradorVentas", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }

        public string referenciaV(int id)
        {
            string referencia = "";
            string query = "select referencia from venta  with (nolock) where id = '" + id + "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr[0].ToString() == "")
                        {
                        }
                        else
                        {
                            referencia = dr.GetString(0);
                        }
                else
                    referencia = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("idCanal", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return referencia;
        }

        /// <summary>
        ///     Manda llamar los movimientos dependiendo los filtros que el usuario agregue al explorador
        /// </summary>
        /// <param name="array">string</param>
        /// <param name="tablero">string</param>
        /// <param name="usuario">string</param>
        /// <param name="usuarioCompleto">string</param>
        /// <param name="sucursal">string</param>
        /// <param name="ctoken">string</param>
        /// Developer:Erika Perez
        /// Date: 16/09/17
        public async Task<List<DM0312_MExploradorVenta>> MovimientosExploradorVenta(string[] array,
            DM0312_ExploradorVentas tablero, string usuario, string usuarioCompleto, string sucursal,
            CancellationToken ctoken, string tipoCred)
        {
            List<DM0312_MExploradorVenta> listModel = new List<DM0312_MExploradorVenta>();
            try
            {
                string cadenaChk = string.Empty;
                string movimiento = array[0];
                string situacion = array[1];
                string estatus = array[2];
                string fechaD = array[3];
                string fechaA = array[4];
                string buscar = array[5];
                string buscarEn = array[6];
                string impreso = array[7];
                bool devolver = Convert.ToBoolean(array[8].ToLowerInvariant());

                if (string.IsNullOrEmpty(fechaD))
                    fechaD = "";
                else
                    fechaD = string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(fechaD));
                if (string.IsNullOrEmpty(fechaA))
                    fechaA = "";
                else
                    fechaA = string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(fechaA));
                if (string.IsNullOrEmpty(movimiento)) movimiento = "";
                if (string.IsNullOrEmpty(situacion)) situacion = "";
                if (string.IsNullOrEmpty(estatus)) estatus = "";
                if (string.IsNullOrEmpty(buscarEn)) buscarEn = "";
                if (string.IsNullOrEmpty(buscar)) buscar = "";

                if (tablero.chk_ContaN != "" || tablero.chk_ContaC != "" || tablero.chk_CrediN != "" ||
                    tablero.chk_CrediC != "" || tablero.chk_CrediC_May != "" || tablero.chk_CrediN_May != "" ||
                    tablero.chk_MA_ != "" || tablero.chk_MAVI_ != "" || tablero.chk_VIU_ != "")
                    cadenaChk = tablero.chk_ContaN + "," + tablero.chk_ContaC + "," + tablero.chk_CrediN + "," +
                                tablero.chk_CrediC + "," + tablero.chk_CrediC_May + "," + tablero.chk_CrediN_May + "," +
                                tablero.chk_MA_ + "," + tablero.chk_MAVI_ + "," + tablero.chk_VIU_;

                cadenaChk = cadenaChk.Replace(",,,", ",");
                cadenaChk = cadenaChk.Replace(",,", ",");
                cadenaChk = cadenaChk.Replace(",", ",");
                cadenaChk = cadenaChk.TrimEnd(',');
                cadenaChk = cadenaChk.TrimStart(',');

                //using (SqlConnection conn = ClaseEstatica.ConexionEstatica)
                //{
                SqlCommand command = new SqlCommand("SP_MaviDM0312PuntoVentaExploradorMovimientos",
                    ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 600;

                //Condicion que verifica si su estatus es sinAfectar para no tomar en cuenta un tipo de venta ya que este estatus no obtiene venta 
                if (estatus == "SinAfectar")
                {
                    if (movimiento == "Sol Dev Unicaja")
                        cadenaChk = "Credito Casa";
                    else
                        cadenaChk = "";
                }

                command.Parameters.Add("@Tipo", SqlDbType.VarChar).Value = cadenaChk;
                command.Parameters.Add("@Sucursal", SqlDbType.VarChar).Value = sucursal;
                command.Parameters.Add("@MovF", SqlDbType.VarChar).Value = movimiento;
                command.Parameters.Add("@SituacionF", SqlDbType.VarChar).Value = situacion;
                command.Parameters.Add("@EstatusF", SqlDbType.VarChar).Value = estatus;
                command.Parameters.Add("@FechaI", SqlDbType.VarChar).Value = fechaD;
                command.Parameters.Add("@FechaF", SqlDbType.VarChar).Value = fechaA;
                command.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuarioCompleto;
                command.Parameters.Add("@BusquedaF", SqlDbType.VarChar).Value = buscar;
                command.Parameters.Add("@BusquedaEn", SqlDbType.VarChar).Value = buscarEn;
                command.Parameters.Add("@Impreso", SqlDbType.VarChar).Value = impreso;
                command.Parameters.Add("@Devolucion", SqlDbType.Bit).Value = devolver;
                command.Parameters.Add("@TipoCredito", SqlDbType.VarChar).Value = tipoCred;
                //if (command.Connection.State == ConnectionState.Open)
                //{
                //    command.Connection.Close();
                //}
                //await command.Connection.OpenAsync();
                if (ctoken.IsCancellationRequested) return listModel;
                using (CancellationTokenRegistration ctr = ctoken.Register(() => command.Cancel()))
                {
                    using (SqlDataReader dr = await command.ExecuteReaderAsync())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                            {
                                DM0312_MExploradorVenta model = new DM0312_MExploradorVenta();
                                model.Movimiento = dr["Mov"] + " " + dr["MovId"];
                                model.Suc = Convert.ToInt32(dr["SucursalOrigen"].ToString());
                                model.Cliente = dr["Cliente"].ToString();
                                model.Nombre = dr["Nombre"].ToString();
                                model.Situacion = dr["Situacion"].ToString();
                                model.Condicion = dr["Condicion"].ToString();
                                model.ImporteTotal = dr["ImporteTotal"].ToString();
                                model.TipoCliente = dr["MaviTipoVenta"].ToString();
                                model.Canal = dr["CanalVenta"].ToString();
                                model.Monedero = dr["Monedero"].ToString();
                                model.Estatus = dr["Estatus"].ToString();
                                model.Reactivacion = dr["Reactivacion"].ToString();
                                model.Grupo = dr["Grupo"].ToString();
                                model.Relacionado = dr["Relacionado"].ToString();
                                model.ReferenciaAnterior = dr["ReferenciaAnterior"].ToString();
                                model.FechaAlta = Convert.ToDateTime(dr["FechaAlta"].ToString());
                                model.Calificaciones = dr["Calificacion"].ToString();
                                model.Poblacion = dr["Poblacion"].ToString();
                                model.Seguimiento = dr["Seguimiento"].ToString();
                                model.Agente = dr["Agente"].ToString();
                                model.FechaUltimaMod = Convert.ToDateTime(dr["FUM"].ToString());
                                model.Almacen = dr["Almacen"].ToString();
                                model.Impreso = dr["Impreso"].ToString();
                                model.Bandera = dr["Bandera"].ToString();
                                model.Mov = dr["mov"].ToString();
                                model.MovId = dr["MovID"].ToString();
                                model.ID = Convert.ToInt32(dr["Id"].ToString());
                                model.Usuario = dr["Usuario"].ToString();
                                model.IDEcommerce = dr["IDEcommerce"].ToString();
                                model.AnticiposFacturados = dr["AnticiposFacturados"].ToString();
                                model.GrupoTrabajo = dr["GrupoTrabajo"].ToString();
                                model.TipoCredito = dr["TipoCredito"].ToString();
                                model.Concepto = dr["Concepto"].ToString();
                                model.EnviarA = dr["EnviarA"].ToString();
                                model.MaviTipoVenta = dr["MaviTipoVenta"].ToString();
                                model.MovTipo = dr["MovTipo"].ToString();
                                model.ff = dr["ff"].ToString();
                                model.Importe = Convert.ToDouble(dr["ImporteTotal"].ToString());
                                model.VtaCambaceo = dr["VTACambaceo"].ToString();
                                model.EstatusEnvio = dr["EstatusEnvio"].ToString();
                                model.tiempoTotalTranscurrido = dr["tiempoTotalTranscurrido"].ToString();
                                model.FechaEnvio = Convert.ToDateTime(dr["fechaEnvio"].ToString());
                                model.Supervision = dr["supervision"].ToString();
                                if (dr["SucursalDestino"] != null && dr["SucursalDestino"].ToString() != string.Empty)
                                    model.SucursalDestino = Convert.ToInt32(dr["SucursalDestino"].ToString());
                                if (dr["Sucursal"] != null && dr["Sucursal"].ToString() != string.Empty)
                                    model.Sucursal = Convert.ToInt32(dr["Sucursal"].ToString());
                                if (dr["Nomina"] != null && dr["Nomina"].ToString() != string.Empty)
                                    model.Nomina = dr["Nomina"].ToString();
                                model.TipoEntrega = dr["TipoEntrega"].ToString();
                                ////Pasar el campo ClienteFinal al ExploradorVenta
                                model.ClienteFinal = dr["ClienteFinal"].ToString();
                                listModel.Add(model);
                            }
                    }
                }

                //Valida si el usuario tiene movimientos
                if (listModel.Count > 0) ValidaConsultaOtrosMovs(listModel);
            }
            catch (Exception ex)
            {
                if (ctoken.IsCancellationRequested) return listModel;
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError("MovimientosExploradorVenta", "DM0312_C_ExploradorVenta", ex);
            }

            return listModel;
        }

        /// <summary>
        ///     Muestra la caja en la que se encuentra el usuario
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 16/09/17
        public string ValidaCajaUsuario(string usuario)
        {
            string usser = string.Empty;
            string query = "SELECT ISNULL(DefCtaDinero,'') FROM Usuario WITH(NOLOCK) WHERE Usuario = '" + usuario +
                           "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) usser = dr.GetString(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return usser;
        }


        public int Web1(int id, int opc)
        {
            int R = 0;
            string query = string.Empty;
            if (opc == 1)
                query = "select COUNT(V.Mov) from Venta V With(Nolock) where v.id = " + id +
                        "  and V.Mov='Analisis Credito' and V.Estatus='PENDIENTE'  and V.Situacion='Rechazado' and Referencia in('DINU Preautorizado WEB','DIMA Preautorizado WEB','ArtCred Preautorizado Web') ";
            if (opc == 2)
                query =
                    "select COUNT(V.Mov) from Venta V With(Nolock) Join MovSituacion M With(Nolock) ON V.Mov=M.Mov and V.Estatus=M.Estatus  and V.Situacion=M.Situacion and M.PermiteAfectacion=1  where v.id = " +
                    id + "  and V.Mov='Analisis Credito' and V.Estatus='PENDIENTE' and V.Almacen <> 'V00039' ";
            if (opc == 3)
                query =
                    "select COUNT(V.Mov) from Venta V With(Nolock) Join MovSituacion M With(Nolock) ON V.Mov=M.Mov and V.Estatus=M.Estatus  and V.Situacion=M.Situacion and M.PermiteAfectacion=1  where v.id = " +
                    id + "  and V.Mov='Analisis Credito' and V.Estatus='PENDIENTE'  and V.Almacen = 'V00039' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) R = Convert.ToInt32(dr[0]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return R;
        }


        /// <summary>
        ///     Busca la cuenta de agente que tiene el usuario
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 16/09/17
        public string AgenteUsuario(string usuario)
        {
            string agente = string.Empty;
            string query = "SELECT Propiedad FROM Prop WITH(NOLOCK) WHERE RAMA='USR' AND TIPO='GIRO' AND Cuenta='" +
                           usuario + "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) agente = dr.GetString(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return agente;
        }

        /// <summary>
        ///     Valida si puede o no ver la matriz de autorizacion
        /// </summary>
        /// <param name="Cliente">string</param>
        /// ///
        /// <param name="opc">string</param>
        /// Developer:Erika Perez
        /// Date: 16/09/17
        public string FmatrizAutorizacion(string Cliente, string opc)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT * FROM dbo.FN_DM0296NombreUsuario ('{0}',{1})", Cliente, opc);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FmatrizAutorizacion", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }


        /// <summary>
        ///     Optiene para los usuarios de credito el porcentaje de supervicion
        /// </summary>
        /// <param name="Cliente">string</param>
        /// Developer:Erika Perez
        /// Date: 20/09/17
        public string FporcentajeSup(string Cliente)
        {
            SqlDataReader dr = null;
            string puede = string.Empty;
            try
            {
                string query;
                query = string.Format(" SELECT dbo.Fn_MaviServicasaServicredPorcentajeSupervisionCtosCte ('{0}',{1})",
                    Cliente, 0);

                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();

                DM0312_MVentanaEntrada EmptyModel = new DM0312_MVentanaEntrada();
                if (dr.HasRows)
                    while (dr.Read())
                        puede = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FporcentajeSup", "DM0312_CExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return puede;
        }

        /// <summary>
        ///     Manda llamar los posibles tipos de credito que tiene la empresa y que sean del cliente expres
        /// </summary>
        /// Developer:Erika Perez
        /// Date: 20/09/17
        public List<string> LlenaTipoCredito()
        {
            List<string> Lista = new List<string>();
            SqlDataReader dr = null;

            string todos = "Todos";

            try
            {
                string query = string.Empty;
                query = "select TextoAmostrar from DM0299Tipodecliente";
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.Text;
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Lista.Add(todos);

                    while (dr.Read()) Lista.Add(dr[0].ToString());
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaTipoCredito", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return Lista;
        }


        public string CambioDeSituacion(string idVenta)
        {
            string valida = string.Empty;
            SqlDataReader dr = null;

            string query = string.Format("select situacion  from venta with (nolock)  where id='{0}'", idVenta);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) valida = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }

            return valida;
        }

        /// <summary>
        ///     Metodo que permite llenar el comboBox Situacion
        /// </summary>
        /// <param name="tablero"></param>
        /// <returns></returns>
        /// Developer: Victor Avila
        /// Date:13/07/2017
        public List<string> ComboSituacion(DM0312_ExploradorVentas tablero)
        {
            //Conecta = conexion.SqlConection();
            string query = "";
            object comboMov = tablero.cbx_movimiento.SelectedItem;
            query = "SELECT DISTINCT Ms.Situacion FROM MovSituacion Ms WITH(NOLOCK) WHERE Ms.Modulo='VTAS' AND Mov ='" +
                    Convert.ToString(comboMov) + "'";
            List<string> situacion = new List<string>();
            SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
            command.CommandType = CommandType.Text;
            try
            {
                SqlDataReader dr = command.ExecuteReader();
                while (dr.Read()) situacion.Add(dr.GetString(0));
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return situacion;
        }

        /// <summary>
        ///     Valida si el usuario tiene permiso de consultar todas las sucursales o no
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 20/10/17
        public bool PermisoSucursal(string usuario)
        {
            SqlDataReader dr = null;

            bool situacion = new bool();
            string query = "";
            query = "SELECT ConsultarOtrasSucursales FROM Usuario WITH(NOLOCK) WHERE Usuario ='" + usuario + "'";

            try
            {
                SqlCommand command = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                command.CommandType = CommandType.Text;
                dr = command.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        situacion = Convert.ToBoolean(dr["ConsultarOtrasSucursales"]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return situacion;
        }

        /// <summary>
        ///     Metodo que permite llenar el dataGrid Eventos Historial Solicitudes
        ///     <param name="movimiento"></param>
        ///     <param name="tipoMovimiento"></param>
        ///     <returns>DataSet</returns>
        ///     Developer: Victor Avila
        ///     Date:04/08/2017
        ///     <summary>
        public DataTable FillDataGridEventos(int id, string mov)
        {
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            string query = @"SELECT mb.Fecha, 
            mb.Clave as Calificacion, 
            mb.Clave,
            cg.Descripcion, 
            mb.Evento as Observaciones, 
            mb.Usuario,mb.id,mb.rid     
                FROM MovBitacora mb WITH (NOLOCK)
            LEFT JOIN MAVIClaveSeguimiento cg WITH (NOLOCK) ON cg.Clave = mb.Clave
            WHERE mb.id = @Id
            order by mb.fecha desc";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.Parameters.AddWithValue("@Id", id);
                sqlCommand.Parameters.AddWithValue("@Mov", mov);
                sqlCommand.CommandType = CommandType.Text;
                sqlDataAdapter.SelectCommand = sqlCommand;
                sqlDataAdapter.Fill(dataTable);

                foreach (DataRow item in dataTable.Rows)
                    item["Calificacion"] = item["Calificacion"] + "  " + item["Descripcion"];
                dataTable.Columns.Remove("Descripcion");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return dataTable;
        }

        /// <summary>
        ///     Valida el acceso del usuario
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 20/10/17
        public string AccesoUsuario(string usuario)
        {
            string usser = string.Empty;
            string query =
                "select A.USUARIO from UsuarioAcceso  a with (nolock) inner join usuario u with (nolock) on a.usuario=u.usuario where (a.movsedicion like '%vtas.pedido%' OR a.movsedicion like '%vtas.solicitud devolucion%' OR a.movsedicion like '%vtas.Solicitud Credito%' OR  a.movsedicion like '%vtas.sol dev unicaja%') and u.estatus='alta' and a.Usuario = '" +
                usuario + "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        usser = dr.GetString(0);
                else
                    usser = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AccesoUsuario", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return usser;
        }


        public int idCanal(string clave)
        {
            int canal = 0;
            string query = "select id from VentasCanalMAVI  with (nolock) where clave = '" + clave + "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        canal = dr.GetInt32(0);
                else
                    canal = 0;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("idCanal", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return canal;
        }


        /// <summary>
        ///     Optiene la fecha del servidor
        /// </summary>
        /// Developer:Erika Perez
        /// Date: 16/10/17
        public DateTime FechaActualServidor()
        {
            DateTime fecha = new DateTime();
            string query = "select GETDATE()";
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    SqlDataReader dr = sqlCommand.ExecuteReader();
                    while (dr.Read()) fecha = Convert.ToDateTime(dr[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return fecha;
        }


        public DM0312_MVentaDetalle ConsultaDetalle(string MovID, string Mov = "", string ID = "")
        {
            DM0312_MVentaDetalle VentaDetalle = new DM0312_MVentaDetalle();
            SqlCommand comm = new SqlCommand("SP_MaviDM0312PuntoVentaDetalleTablero", ClaseEstatica.ConexionEstatica);
            comm.CommandType = CommandType.StoredProcedure;
            if (ID == string.Empty)
            {
                comm.Parameters.AddWithValue("@MovID", MovID);
                if (Mov != string.Empty) comm.Parameters.AddWithValue("@Mov", Mov);
            }
            else
            {
                //comm.Parameters.AddWithValue("@MovID", DBNull.Value);
                comm.Parameters.AddWithValue("@ID", ID);
            }

            try
            {
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        VentaDetalle.Condicion = dr["Condicion"].ToString();
                        VentaDetalle.CanalClave = dr["CanalClave"].ToString();
                        VentaDetalle.CanalNombre = dr["CanalNombre"].ToString();
                        VentaDetalle.Embarque = dr["Embarque"].ToString();
                        VentaDetalle.EmbarqueFecha = dr["EmbarqueFecha"].ToString();
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //TODO WIP(Agregar la barra de Estatus de ser posible esto solo a las vistas)
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return VentaDetalle;
        }


        /***********************************************************************************************************************/


        public int origenID(string mov, string movid)
        {
            int origenid = 0;
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;

            query =
                "select v2.id from venta v WITH (NOLOCK) inner join venta v2 WITH (NOLOCK) on v2.mov=v.origen and v2.movid=v.origenid where v.mov='" +
                mov + "' and v.movid='" + movid + "'";


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        origenid = Convert.ToInt32(dr[0].ToString());
                else
                    origenid = 0;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("origenID", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return origenid;
        }

        //1286
        public List<string> listaMovimientosConEventosX(string filtrosMID, string filtrosClave)
        {
            List<string> lista = new List<string>();

            string query =
                "select  moviD from Venta with (NOLOCK)where id in ( SELECT MB.id as ID FROM MovBitacora mb WITH (NOLOCK) LEFT JOIN MAVIClaveSeguimiento cg WITH (NOLOCK) ON cg.Clave = mb.Clave WHERE mb.id in (Select id from Venta where movid in (" +
                filtrosMID + ") and mov = 'Analisis Credito') and mb.Clave in ( " + filtrosClave + " ) ) ";

            SqlDataReader dr;
            try
            {
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        lista.Add((string)dr["movID"]);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return lista;
        }

        public List<AnalistaCreditoModel> listaAnalistas()
        {
            List<AnalistaCreditoModel> analistaList = new List<AnalistaCreditoModel>();

            string query = @"
            SELECT u.Usuario, u.Usuario + ' ' + u.Nombre AS Nombre, u.Usuario + ' ' + u.Nombre AS Analista
            FROM usuario u WITH (NOLOCK)
            JOIN TablaStD std WITH (NOLOCK)
              ON u.Acceso = std.Nombre
            WHERE u.Estatus = 'Alta'
              AND std.TablaSt = 'USUARIOSSEGCREDITO'            
            ";

            SqlDataReader dataRead;
            try
            {
                SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                dataRead = cmd.ExecuteReader();
                if (dataRead.HasRows) analistaList = listOFAnalist(dataRead);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            analistaList.Insert(0, new AnalistaCreditoModel
            {
                analista = "",
                nombre = "",
                usuario = ""
            });

            return analistaList;
        }

        private List<AnalistaCreditoModel> listOFAnalist(SqlDataReader dataRead)
        {
            List<AnalistaCreditoModel> sellerList = new List<AnalistaCreditoModel>();
            while (dataRead.Read()) sellerList.Add(setAnalistaValues(dataRead));
            return sellerList;
        }

        private AnalistaCreditoModel setAnalistaValues(SqlDataReader reader)
        {
            AnalistaCreditoModel analista = new AnalistaCreditoModel();

            analista.usuario = reader.GetString(0) is DBNull ? "error" : reader.GetString(0);
            analista.analista = reader.GetString(1) is DBNull ? "error" : reader.GetString(1);

            return analista;
        }


        //1286
        public bool asignarAnalistaASnalisis(string Analista, string movIDAnalisis)
        {
            bool respuesta = false;
            try
            {
                // FIX Demo Insert
                string query = @"INSERT INTO VTASCSancion 
                (fecha, sucursal, vendedor, monto, movID, cliente, usuarioCredito, observaciones, aplica, estatus)
                VALUES 
                (GETDATE(), @sucursal, @vendedor, @monto, @movID, @cliente, @usuarioCredito, @observaciones, @aplica, 'PENDIENTE')";

                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Analista", Analista);
                    cmd.Parameters.AddWithValue("@movIDAnalisis", movIDAnalisis);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
            }
            finally
            {
                respuesta = true;
            }

            return respuesta;
        }

        public string getnominaUsuario(string Usuario)
        {
            string nomina = "";

            try
            {
                string query = @"
                SELECT p.Propiedad FROM prop p WITH(NOLOCK)
                INNER JOIN Usuario u WITH(NOLOCK) ON p.cuenta = u.Usuario
                where p.Tipo = 'Giro'
                AND u.Usuario = @Usuario";

                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Usuario", Usuario);
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read()) nomina = dr[0].ToString();
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, e);
            }

            return nomina;
        }

        #region Datalogic

        /// <summary>
        ///     Metodo encargado de validar si la venta que se esta seleccionando es una recarga
        /// </summary>
        /// <param name="iId">Id de la venta</param>
        /// <returns></returns>
        public string validarRecarga(int iId)
        {
            string sUnidad = string.Empty;
            SqlDataReader dr = null;
            string query;

            query = string.Format("SELECT UNIDAD FROM VENTAD WHERE id = {0}", iId);
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        sUnidad = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return sUnidad;
        }

        #endregion

        //1861
        /// <summary>
        ///     Metodo encargado de validar si hay un bloqueo por carga de precios
        /// </summary>
        /// <param name="Perfil">Perfil del usuario</param>
        /// <param name="Sucursal">Sucursal</param>
        /// <returns>retorna un bool con el identificador 0: NO BLOQUEADO, 1: BLOQUEADO</returns>
        /// Developer: Julio Barrios
        /// Date: 08/04/2022
        public bool ObtenerBloqueoCargaPrecios(string Perfil, int Sucursal)
        {
            bool EsBloqueo = false;
            string sQuery = string.Empty;
            DataTable dt = new DataTable();
            try
            {
                sQuery = @"select dbo.FnVTASObtenerBloqueoSucursal(@Perfil, @Sucursal) AS Bloqueado";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddWithValue("@Perfil", Perfil);
                    cmd.Parameters.AddWithValue("@Sucursal", Sucursal);
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        if (int.Parse(item["Bloqueado"].ToString()) > 0)
                            EsBloqueo = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return EsBloqueo;
        }

        public double maxImporteARecuperar(int IdVenta)
        {
            double result = 0.0;

            string query = @"
            SELECT PrecioTotal
              FROM venta WITH(NOLOCK)
             WHERE id = @id ";

            using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
            {
                cmd.Parameters.Add("@id", IdVenta);

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                        while (dr.Read())
                            result = Convert.ToDouble(dr["PrecioTotal"].ToString());
                }
            }

            return result;
        }

        //1861
        /// <summary>
        ///     Metodo encargado de obtener el mensaje a mostrar en caso de un bloqueo por carga de precios
        /// </summary>
        /// <returns>retorna un string con el mensaje de bloqueo</returns>
        /// Developer: Julio Barrios
        /// Date: 08/04/2022
        public string ObtenerMensajeBloqueoCargaPrecios()
        {
            string sQuery = string.Empty;
            string sMensaje = string.Empty;

            try
            {
                sQuery =
                    "SELECT TOP 1 Nombre FROM TablaStD WITH(NOLOCK) WHERE TablaSt ='mensajedesbloqueapuntodeventa'";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                sMensaje = dr[0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sMensaje;
        }

        public void depurarNotificaciones()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SpCREDIDepurarNotificaciones", ClaseEstatica.ConexionEstatica);
                cmd.CommandType = CommandType.StoredProcedure;
                int i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        //// 1861
        /// <summary>
        ///     Desactiva la bandera del bloqueo carga de precios
        /// </summary>
        /// <param name="Sucursal">int</param>
        /// Developer: Julio Barrios
        /// Date: 08/04/2022
        public void ActualizarBloqueoCargaPrecios(int nSucursal, string sUsuarioDesbloquea)
        {
            SqlDataReader dr = null;
            string sQuery = string.Empty;
            ;

            sQuery =
                "UPDATE VTASCPCPBloqueoSucursal WITH(ROWLOCK) set Bloqueada = 0, UsuarioDesbloquea = @Usuario, FechaDesbloqueo = GETDATE() WHERE Sucursal = @Sucursal";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlParameter[] pars = new SqlParameter[2]
                {
                    new SqlParameter("@Sucursal", nSucursal)
                    {
                        SqlDbType = SqlDbType.Int
                    },
                    new SqlParameter("@Usuario", sUsuarioDesbloquea)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };
                sqlCommand.Parameters.AddRange(pars);
                dr = sqlCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }
        }

        //// 1861
        /// <summary>
        ///     Validar si el usuario logueado tiene permisos para desbloquear punto de venta
        /// </summary>
        /// <param name="Usuario">int</param>
        /// Developer: Julio Barrios
        /// Date: 08/04/2022
        public bool ValidarPerfilDesbloqueoCargaPrecios(string Usuario)
        {
            string sQuery = string.Empty;
            bool EsValido = false;

            try
            {
                sQuery = @"SELECT 
                            Nombre 
                         FROM TablaStD WITH(NOLOCK) 
                         WHERE 
                            TablaSt ='perfildesbloqueapuntodeventa' 
                            and Nombre = (SELECT TOP 1 Usuario.Acceso FROM Usuario WITH(NOLOCK) WHERE Usuario.Usuario = @Usuario)";
                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.Add(new SqlParameter("@Usuario", Usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    });

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                            while (dr.Read())
                                EsValido = true;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return EsValido;
        }

        #region Metodos Dan

        /// <summary>
        ///     Llena valores del datatable publico
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 11//07/2017
        public void LLenadoListaArticulosSeleccionados(List<DM0312_MExploradorVenta> VentasSeleccionadas = null)
        {
            try
            {
                DM0312_DetalleVenta.ListaDetalles = new List<MDetalleVenta>();
                if (!CDetalleVenta.MovimientoGenerado)
                {
                    foreach (DM0312_MExploradorVenta MExplorador in DM0312_ExploradorVentas.ListaExplorador)
                    {
                        ConsultaDetalle(DM0312_DetalleVenta.ListaDetalles, MExplorador.MovId, MExplorador.Mov,
                            MExplorador.ID);

                        if (validarRecarga(MExplorador.ID) == "RECARGA")
                            ClaseEstatica.iRecarga = 1;
                        else
                            ClaseEstatica.iRecarga = 0;
                    }
                }
                else
                {
                    if (VentasSeleccionadas != null)
                        foreach (DM0312_MExploradorVenta MExplorador in VentasSeleccionadas)
                            ConsultaDetalle(DM0312_DetalleVenta.ListaDetalles, MExplorador.MovId, MExplorador.Mov,
                                MExplorador.ID);
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                //sbp_EstatusPrograma.Text = @"Error: " + e.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }
        }

        /// <summary>
        ///     Agrega el detalle del movimiento seleccionado
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 10/07/2017
        public void FillDetalleMovimiento(
            TextBox txt_DetalleAlmacen, TextBox txt_Condicion, List<TableroDetalleVenta> Detalles,
            TextBox txt_DetalleReferencia, ComboBox cbx_estatus,
            Label lbl_Embarque, TextBox txt_DetalleEmbarqueMov, DataGridView dgv_TablaDetalle,
            ComboBox cbx_movimiento, TextBox txt_DetalleConcepto, Label lbl_Concepto,
            TextBox txt_detalleFechaEmbarque, Label lbl_Referencia)
        {
            txt_DetalleAlmacen.Text = DM0312_ExploradorVentas.ModelSeleccionado.Almacen;
            txt_Condicion.Text = DM0312_ExploradorVentas.ModelSeleccionado.Condicion;

            DataTable tempdt = new DataTable();

            Detalles = new List<TableroDetalleVenta>();

            txt_detalleFechaEmbarque.Visible = false;
            txt_detalleFechaEmbarque.Text = string.Empty;

            tempdt = ObtenerDetalleTablero(DM0312_ExploradorVentas.ModelSeleccionado.ID.ToString());
            if (tempdt.Columns["Articulo"] != null)
                foreach (DataRow temprow in tempdt.Rows)
                {
                    TableroDetalleVenta NuevoDetalle = new TableroDetalleVenta();
                    NuevoDetalle.Articulo = temprow["Articulo"].ToString();
                    if (temprow["Cantidad"] != null && temprow["Cantidad"].ToString() != string.Empty)
                        NuevoDetalle.Cantidad = Convert.ToDouble(temprow["Cantidad"]).ToString("0");
                    else
                        NuevoDetalle.Cantidad = "0";

                    if (temprow["Precio"] != null && temprow["Precio"].ToString() != string.Empty)
                        NuevoDetalle.Precio = Convert.ToDouble(temprow["Precio"]).ToString("C");
                    else
                        NuevoDetalle.Precio = "0";
                    double Importe = 0.00;
                    if (temprow["Precio"] != null && temprow["Precio"].ToString() != string.Empty &&
                        temprow["Cantidad"] != null && temprow["Cantidad"].ToString() != string.Empty)
                        Importe = Convert.ToDouble(temprow["Precio"]) * Convert.ToDouble(NuevoDetalle.Cantidad);
                    else
                        Importe = 0.00;

                    NuevoDetalle.Importe = Importe.ToString("C");
                    if (temprow["RenglonTipo"] != null && temprow["RenglonTipo"].ToString() == "J")
                        NuevoDetalle.EsPaquete = true;
                    else if (temprow["RenglonTipo"] != null && temprow["RenglonTipo"].ToString() == "C")
                        NuevoDetalle.EsComponentePaquete = true;
                    Detalles.Add(NuevoDetalle);

                    string cadenaReferencia = temprow["Referencia"].ToString();
                    txt_DetalleReferencia.Text = cadenaReferencia;


                    //Validacion embarque
                    if (DM0312_ExploradorVentas.ModelSeleccionado.Mov != "Factura" &&
                        DM0312_ExploradorVentas.ModelSeleccionado.Mov != "Factura VIU" &&
                        DM0312_ExploradorVentas.ModelSeleccionado.Mov != "Factura Mayoreo")
                    {
                        lbl_Embarque.Visible = false;
                        txt_DetalleEmbarqueMov.Visible = false;
                        txt_detalleFechaEmbarque.Visible = false;
                    }
                    else if (cbx_estatus.Text != "Concluido" && temprow["Almacen"].ToString() != "V00096")
                    {
                        lbl_Embarque.Visible = false;
                        txt_DetalleEmbarqueMov.Visible = false;
                        txt_detalleFechaEmbarque.Visible = false;
                    }
                    else
                    {
                        string cadenaEmbarque = temprow["Embarque"].ToString();
                        if (cadenaEmbarque != string.Empty)
                        {
                            txt_DetalleEmbarqueMov.Text = cadenaEmbarque;
                            txt_DetalleEmbarqueMov.Visible = true;
                            lbl_Embarque.Visible = true;
                        }
                        else
                        {
                            txt_DetalleEmbarqueMov.Visible = false;
                            lbl_Embarque.Visible = false;
                        }

                        string cadenaEmbarqueFecha = temprow["EmbarqueFecha"].ToString();
                        if (cadenaEmbarqueFecha != string.Empty)
                        {
                            txt_detalleFechaEmbarque.Text =
                                Convert.ToDateTime(cadenaEmbarqueFecha).ToString("dd/MM/yyyy");
                            txt_detalleFechaEmbarque.Visible = true;
                        }
                        else
                        {
                            txt_detalleFechaEmbarque.Visible = false;
                            lbl_Embarque.Visible = false;
                        }
                    }
                }

            dgv_TablaDetalle.DataSource = Detalles;

            for (int i = 0; i < Detalles.Count; i++)
                if (Detalles[i].EsComponentePaquete)
                {
                    if (dgv_TablaDetalle.CurrentCell.ColumnIndex == i)
                        dgv_TablaDetalle.Rows[i].DefaultCellStyle.SelectionForeColor = Color.LightGray;
                    dgv_TablaDetalle.Rows[i].DefaultCellStyle.ForeColor = Color.DimGray;
                }

            //Validacion Concepto y referencia
            if (cbx_movimiento.Text != "Solicitud Devolucion" && cbx_movimiento.Text != "Devolucion Venta")
            {
                txt_DetalleConcepto.Visible = false;
                lbl_Concepto.Visible = false;
                lbl_Referencia.Visible = false;
                txt_DetalleReferencia.Visible = false;
            }
            else
            {
                lbl_Concepto.Visible = true;
                txt_DetalleConcepto.Visible = true;
                txt_DetalleConcepto.Text = DM0312_ExploradorVentas.ModelSeleccionado.Concepto;
                lbl_Referencia.Visible = true;
                txt_DetalleReferencia.Visible = true;
            }
        }

        /// </summary>
        /// <param name="Movs">DataSet</param>
        /// <returns>DataSet</returns>
        /// Developer: Dan Palacios
        /// Date: 25/07/2017
        public List<DM0312_MExploradorVenta> ValidaConsultaOtrosMovs(List<DM0312_MExploradorVenta> Movs)
        {
            ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
            if (!CUsuario.ConsultarOtrosMovs)
                if (Movs != null && Movs.Count > 0)
                    for (int i = Movs.Count - 1; i >= 0; i--)
                        //Si no tiene permiso para consultar otros grupos se checa el grupo
                        if (!CUsuario.ConsultarOtrosMovsGrupo)
                        {
                            if (Movs[i].GrupoTrabajo != CUsuario.GrupoUsuario)
                                Movs.RemoveAt(i);
                            else if (Movs[i].Usuario != CUsuario.Usuario) Movs.RemoveAt(i);
                        }
                        else if (Movs[i].Usuario != CUsuario.Usuario)
                        {
                            Movs.RemoveAt(i);
                        }

            return Movs;
        }

        /// <summary>
        ///     Obtiene los detalles del tablero
        /// </summary>
        /// <param name="ID">string</param>
        /// <returns>DataTable</returns>
        /// Developer: Dan Palacios
        /// Date: 15/08/17
        public DataTable ObtenerDetalleTablero(string ID = "")
        {
            DataTable dt = new DataTable();
            SqlCommand comm = new SqlCommand("SP_MaviDM0312PuntoVentaDetalleTablero", ClaseEstatica.ConexionEstatica);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@ID", ID);
            SqlDataAdapter sda = new SqlDataAdapter(comm);
            try
            {
                sda.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_ExploradorVenta", ex);
            }

            return dt;
        }

        /// <summary>
        ///     Saca la informacion de un datatable y la inserta en un datatable publico para manejar en diferentes formularios
        /// </summary>
        /// <param name="TablaDatosACopiar">DataTable</param>
        /// <param name="TablaDatosALlenar">DataTable</param>
        /// <param name="NuevaTabla">bool</param>
        /// <param name="MovID">string</param>
        /// Developer: Dan Palacios
        /// Date: 13/07/17
        public void LlenadoTablaDatosPublica(List<DM0312_MExploradorVenta> TablaDatosACopiar,
            DataTable TablaDatosALlenar, bool NuevaTabla = false)
        {
            DM0312_MExploradorVenta DM0312_MExploradorVentaTemp = new DM0312_MExploradorVenta();
            if (NuevaTabla)
                foreach (PropertyInfo property in DM0312_MExploradorVentaTemp.GetType().GetProperties())
                    TablaDatosALlenar.Columns.Add(property.Name);

            foreach (DM0312_MExploradorVenta row in TablaDatosACopiar)
            {
                DataRow dRow = TablaDatosALlenar.NewRow();

                object[] values = new object[row.GetType().GetProperties().Length];
                for (int i = 0; i < row.GetType().GetProperties().Length; i++)
                    dRow[row.GetType().GetProperties()[i].Name] = row.GetType().GetProperties()[i].GetValue(row, null);

                TablaDatosALlenar.Rows.Add(dRow);
            }
        }

        /// <summary>
        ///     Llena detalle de mov seleccionado
        /// </summary>
        /// <param name="ListaDetalleVentas">List<MDetalleVenta></param>
        /// <param name="MovID">string</param>
        /// <param name="Mov">string</param>
        /// <param name="ID">int</param>
        /// <returns>List<MDetalleVenta></returns>
        /// Developer: Dan Palacios
        /// DatE: 04/09/17
        public List<MDetalleVenta> ConsultaDetalle(List<MDetalleVenta> ListaDetalleVentas, string MovID,
            string Mov = "", int ID = 0)
        {
            SqlCommand comm = new SqlCommand("SP_MaviDM0312PuntoVentaPosicionMovimientoDetalle",
                ClaseEstatica.ConexionEstatica);
            comm.CommandType = CommandType.StoredProcedure;
            if (ID == 0)
            {
                comm.Parameters.AddWithValue("@MovID", MovID);
                if (Mov != string.Empty) comm.Parameters.AddWithValue("@Mov", Mov);
            }
            else
            {
                comm.Parameters.AddWithValue("@MovID", DBNull.Value);
                comm.Parameters.AddWithValue("@ID", ID);
            }

            int RenglonDeArticulo = 0;
            try
            {
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        if (dr["Articulo"] != null && dr["Articulo"].ToString() != string.Empty)
                        {
                            MDetalleVenta NuevoDetalle = new MDetalleVenta
                            {
                                ID = ID != 0 ? ID : 0,
                                Articulo = dr["Articulo"].ToString(),
                                Cantidad = dr["Cantidad"].ToString(),
                                Precio = dr["Precio"] != null && dr["Precio"].ToString() != ""
                                    ? Convert.ToDouble(dr["Precio"]).ToString("0.00")
                                    : "0.00",
                                Importe = dr["Importe"] != null && dr["Importe"].ToString() != ""
                                    ? Convert.ToDouble(dr["Importe"]).ToString("0.00")
                                    : "0.00",
                                Impuestos = dr["Impuestos"] != null && dr["Impuestos"].ToString() != ""
                                    ? Convert.ToDouble(dr["Impuestos"]).ToString("0.00")
                                    : "0.00",
                                ImporteTotal = dr["ImporteTotal"] != null && dr["ImporteTotal"].ToString() != ""
                                    ? Convert.ToDouble(dr["ImporteTotal"]).ToString("0.00")
                                    : "0.00",
                                Serie = dr["SerieLote"].ToString(),
                                Referencia = dr["Referencia"].ToString(),
                                Descripcion = dr["Descripcion1"].ToString(),
                                CanalClave = dr["CanalClave"].ToString(),
                                CanalNombre = dr["CanalNombre"].ToString(),
                                Email = dr["Email"].ToString(),
                                Unidad = dr["Unidad"].ToString(),
                                Condicion = dr["Condicion"].ToString(),
                                Concepto = dr["Concepto"].ToString(),
                                FormaPagoTipo = dr["FormaPagoTipo"].ToString(),
                                EsPaquete = dr["RenglonTipo"] != null && dr["RenglonTipo"].ToString() != string.Empty &&
                                            dr["RenglonTipo"].ToString() == "J"
                                    ? "True"
                                    : "False",
                                PedimentoTipo = dr["PedimentoTipo"].ToString(),
                                Color = dr["Color"].ToString(),
                                Modelo = dr["Modelo"].ToString(),
                                Aduana = dr["Aduana"].ToString(),
                                Fecha = dr["Fecha"].ToString(),
                                Cuadro = dr["Cuadro"].ToString(),
                                Embarque = dr["Embarque"].ToString(),
                                EmbarqueFecha = dr["EmbarqueFecha"].ToString(),
                                MovID = dr["MovID"].ToString(),
                                Tipo = dr["Tipo"].ToString(),
                                RenglonDeArticulo = RenglonDeArticulo,
                                EsComponentePaquete = dr["RenglonTipo"] != null && dr["RenglonTipo"].ToString() == "C"
                                    ? "True"
                                    : "False",
                                RenglonID = dr["RenglonID"] != null && dr["RenglonID"].ToString() != string.Empty &&
                                            dr["RenglonID"].ToString() != "C"
                                    ? Convert.ToInt32(dr["RenglonID"])
                                    : 0,
                                Costo = dr["Costo"] != null && dr["Costo"].ToString() != ""
                                    ? Convert.ToDouble(dr["Costo"]).ToString("0.00")
                                    : "0.00",
                                Observaciones = dr["DescripcionExtra"].ToString(),
                                CantidadPendiente =
                                    dr["CantidadPendiente"] != null &&
                                    dr["CantidadPendiente"].ToString() != string.Empty
                                        ? Convert.ToInt32(dr["CantidadPendiente"].ToString())
                                        : 0,
                                CantidadAAfectar = dr["CantidadA"] != null && dr["CantidadA"].ToString() != string.Empty
                                    ? Convert.ToInt32(dr["CantidadA"].ToString())
                                    : 0,
                                dPuntosMonedero = double.Parse(dr["Puntos"].ToString()),
                                sPuntosMonedero = dr["Puntos"].ToString(),
                                bCheckMondero = bool.Parse(dr["TransferenciaStp"].ToString()),
                                sCuentaClabe = dr["clabeCuenta"].ToString(),
                                sBanco = dr["banco"].ToString()
                            };
                            ListaDetalleVentas.Add(NuevoDetalle);
                            RenglonDeArticulo = RenglonDeArticulo + 1;
                        }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //TODO WIP(Agregar la barra de Estatus de ser posible esto solo a las vistas)
                //sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return ListaDetalleVentas;
        }

        #endregion


        #region -Venta Cruzada

        public int ventaCruzadaSuc(string mov, string movid)
        {
            int origenid = 0;
            SqlDataReader dr = null;
            int sucursal = 0;
            sucursal = ClaseEstatica.Usuario.sucursal;
            string query;

            query = "select sucursal from venta v WITH (NOLOCK)  where v.mov='" + mov + "' and v.movid='" + movid + "'";


            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.CommandTimeout = 9999999;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        origenid = Convert.ToInt32(dr[0].ToString());
                else
                    origenid = 0;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ventaCruzadaSuc", "DM0312_CDetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return origenid;
        }


        /// <summary>
        ///     Valida el acceso del usuario
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 20/10/17
        public string ValidaEventoVCruzada(string clave)
        {
            string usser = string.Empty;
            string query =
                "select a.continuaproceso from CREDICEventosVentaCruzada  a with (nolock)  where a.idmaviclaveseguimiento = '" +
                clave + "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        usser = dr.GetString(0);
                else
                    usser = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AccesoUsuario", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return usser;
        }


        /// <summary>
        ///     Valida agente de venta cruzada
        /// </summary>
        /// <param name="usuario">string</param>
        /// Developer:Erika Perez
        /// Date: 19/12/17
        public string ValidaAgenteVCruzada(int id)
        {
            string usser = string.Empty;
            string query = "select ISNULL(v.AgenteVtaCruzada,'') from venta v with (nolock)  where v.id = '" + id +
                           "' ";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        usser = dr.GetString(0);
                else
                    usser = "NO";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAgenteVCruzada", "DM0312_C_ExploradorVenta", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return usser;
        }


        /// <summary>
        ///     procedimiento de venta cruzada para mandar la notificacion dependiendo el evento si es aceptado o rechazado
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 15/12/18
        public int RespVentaCruzada(string agente, int id)
        {
            SqlDataReader dr = null;
            int RespVenta = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SpCREDIEnvRespVentaCruzada", ClaseEstatica.ConexionEstaticaAndroidS);
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = agente;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        RespVenta = int.Parse(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("RespVentaCruzada", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return RespVenta;
        }


        /// <summary>
        ///     procedimiento de venta cruzada para mandar la notificacion dependiendo el evento si es aceptado o rechazado
        /// </summary>
        /// <param name="Cliente">string</param>
        /// <param name="Canal">int</param>
        /// Developer: Erika Perez
        /// Date: 15/12/18
        public int RespVentaCruzadaAsig(string agente, string cliente)
        {
            SqlDataReader dr = null;
            int RespVenta = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("SpCREDIAsignAutomatica", ClaseEstatica.ConexionEstatica);
                cmd.Parameters.Add("@Agente", SqlDbType.VarChar).Value = agente;
                cmd.Parameters.Add("@Cliente", SqlDbType.VarChar).Value = cliente;
                cmd.CommandType = CommandType.StoredProcedure;
                dr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("RespVentaCruzadaAsig", "DM0312_CVentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return RespVenta;
        }

        #endregion

        #region Verificación del RFC

        /// <summary>
        ///     Esta función trae todas las coincidencias que haya en el RFC de Prospectos en Clientes
        /// </summary>
        /// <param name="UsuarioPostulante"></param>
        /// <returns> List </returns>
        public async Task<List<CoincidenciasRFCModelo>> postulanteACreditoVerificacionRFC(string UsuarioPostulante)
        {
            try
            {
                using (SqlCommand comando =
                       new SqlCommand("SpCREDIObtenerCoincidenciaRFC", ClaseEstatica.ConexionEstatica))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.AddWithValue("@Cliente", UsuarioPostulante);

                    SqlDataReader response = await comando.ExecuteReaderAsync();
                    if (!response.HasRows) return new List<CoincidenciasRFCModelo>();
                    List<CoincidenciasRFCModelo> listaExplorador = new List<CoincidenciasRFCModelo>();
                    while (response.Read())
                        listaExplorador.Add(new CoincidenciasRFCModelo
                        {
                            _canal = response["Canal"].ToString(),
                            _cliente = response["Cliente"].ToString(),
                            _fechaNacimiento = response["FechaNacimiento"].ToString().Substring(0, 10),
                            _nombre = response["Nombre"].ToString(),
                            _poblacion = response["Poblacion"].ToString(),
                            _rfc = response["RFC"].ToString(),
                            _telefono = response["Telefonos"].ToString()
                        });

                    listaExplorador = listaExplorador.GroupBy(x => x._cliente).Select(x => Concatenar(x.ToList()))
                        .Where(x => x != null).ToList();

                    return listaExplorador;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                return new List<CoincidenciasRFCModelo>();
                ;
            }
        }

        public CoincidenciasRFCModelo Concatenar(List<CoincidenciasRFCModelo> lista)
        {
            try
            {
                string canal = string.Join(",", lista.GroupBy(x => x._canal).Select(x => x.FirstOrDefault()._canal));
                CoincidenciasRFCModelo modelo = lista.FirstOrDefault();
                modelo._canal = canal;
                return modelo;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                return null;
            }
        }

        #endregion
    }
}