﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.Controller
{
    public class ControlAgregarEvento
    {
        private DataTable dt = new DataTable();

        /// <summary>
        ///     Metodo que nos permite insertar el registro en  la DB tabla MovBitacora
        /// </summary>
        /// <param name="agente"></param>
        /// Developer: Victor Avila
        /// Date: 28/08/2017
        /// <returns>bool</returns>
        public bool InsertaEvento(string agente, string clave, string modulo, int id, string fecha, string evento,
            int sucursal, string usuario, string tipo, string estuatus, string situacion, int citaCliente, int citaaval,
            DateTime citaFecha, string citaHora, string TipoEvento, string mov, string cliente)
        {
            bool temp = false;
            try
            {
                int validaInsert = 0;
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312InsertaEventos", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Agente", agente);
                sqlCommand.Parameters.AddWithValue("@Clave", clave);
                sqlCommand.Parameters.AddWithValue("@Modulo", modulo);
                sqlCommand.Parameters.AddWithValue("@Id", id);
                sqlCommand.Parameters.AddWithValue("@Fecha", fecha);
                sqlCommand.Parameters.AddWithValue("@Evento", evento);
                sqlCommand.Parameters.AddWithValue("@Sucursal", sucursal);
                sqlCommand.Parameters.AddWithValue("@Usuario", usuario);
                sqlCommand.Parameters.AddWithValue("@Tipo", tipo);
                sqlCommand.Parameters.AddWithValue("@Estatus", estuatus);
                sqlCommand.Parameters.AddWithValue("@Situacion", situacion);
                sqlCommand.Parameters.AddWithValue("@CitaCliente", citaCliente);
                sqlCommand.Parameters.AddWithValue("@CitaAval", citaaval);
                sqlCommand.Parameters.AddWithValue("@CitaFecha", citaFecha);
                sqlCommand.Parameters.AddWithValue("@CitaHora", citaHora);
                sqlCommand.Parameters.AddWithValue("@TipoEvento", TipoEvento);
                validaInsert = sqlCommand.ExecuteNonQuery();

                if (validaInsert > 0 || validaInsert == -1)
                {
                    temp = true;

                    //-RQ Forma de Pago Negativa Buro
                    if (mov == "Analisis Credito" && (clave == "MEN06872" || clave == "MEN06940"))
                    {
                        int check = 0;
                        if (clave == "MEN06872") check = 1;
                        else if (clave == "MEN06940") check = 0;

                        updateCheckNegativaBC(cliente, check);
                    }
                }
                else
                {
                    temp = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return temp;
        }

        /// <summary>
        ///     Metodo que permite ingresar registro en la DB tabla CtaBitacora
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public bool InsertaNota(string modulo, string cuenta, string evento, string usuario)
        {
            bool temp = false;
            try
            {
                int validaInsert = 0;
                SqlCommand sqlCommand = new SqlCommand("SP_DM0312InsertaNotas", ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Modulo", modulo);
                sqlCommand.Parameters.AddWithValue("@Cuenta", cuenta);
                sqlCommand.Parameters.AddWithValue("@Evento", evento);
                sqlCommand.Parameters.AddWithValue("@Usuario", usuario);
                validaInsert = sqlCommand.ExecuteNonQuery();

                if (validaInsert > 0 || validaInsert == -1)
                    temp = true;
                else
                    temp = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return temp;
        }

        /// <summary>
        ///     Metodo para mandar llamar los agentes dependiendo la sucursal en la que se este
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public List<ModelAgregaEvento> fillAgent(string usuario)
        {
            List<ModelAgregaEvento> list = new List<ModelAgregaEvento>();
            string query =
                "SELECT p.Cuenta, p.Propiedad,  u.Nombre  FROM  prop  p WITH(NOLOCK) INNER JOIN Usuario u WITH(NOLOCK) ON p.cuenta = u.Usuario AND p.Tipo = 'Giro' AND u.Usuario =  '" +
                usuario + "'";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    ModelAgregaEvento addEvent = new ModelAgregaEvento();
                    addEvent.ClaveAgente = dr["Cuenta"].ToString();
                    addEvent.Clave = dr["Propiedad"].ToString();
                    addEvent.NombreAgente = dr["Nombre"].ToString();
                    list.Add(addEvent);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return list;
        }

        public string nombreAgente(string nomina)
        {
            string nombre = "  ";
            string query = @"select top 1 nombre
            from PA_USUARIOS_ANDROID
            where NOMINA = @nomina";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    cmd.Parameters.AddWithValue("@nomina", nomina);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read()) nombre = dr[0].ToString();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, e);
            }

            return nombre;
        }

        /// <summary>
        ///     Metodo para obtener la situacion dependiendo la clave de evento seleccionada
        /// </summary>
        /// Developer: Victor Avila
        /// Date: 09/09/2017
        /// <returns></returns>
        public string Situacion(string clave)
        {
            string situacionE = "";
            string query = "select situacion from MAVIClaveSeguimiento with (nolock) where Clave= '" + clave + "'";
            SqlDataReader dr = null;
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                dr = sqlCommand.ExecuteReader();
                while (dr.Read()) situacionE = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
            }

            return situacionE;
        }

        /// <summary>
        ///     Metodo que permite llenar forma Clave Seguimiento
        /// </summary>
        /// <returns>DataTable</returns>
        /// Developer: Victor Avila
        /// Date: 03/08/2017
        public List<DM0312_MClaveSeguimiento> LlenaComboClaveEvento()
        {
            List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
            SqlDataAdapter adapter = new SqlDataAdapter();
            try
            {
                string query =
                    "SELECT MAVIClaveSeguimiento.Clave, MAVIClaveSeguimiento.Modulo, MAVIClaveSeguimiento.Descripcion, MAVIClaveSeguimiento.Grupo, " +
                    "MAVIClaveSeguimiento.Situacion FROM MAVIClaveSeguimiento WITH(NOLOCK) " +
                    "JOIN Modulo WITH(NOLOCK) ON MAVIClaveSeguimiento.Modulo = Modulo.Modulo " +
                    "WHERE MAVIClaveSeguimiento.Clave <> 'VTA99999' AND Clave IN (Select Clave From dbo.Fn_MaviDM0114VisualCalif('" +
                    ClaseEstatica.Usuario.Usser + "'))";
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    DM0312_MClaveSeguimiento model_ = new DM0312_MClaveSeguimiento();
                    model_.Clave = sqlDataReader["Clave"].ToString();
                    model_.Modulo = sqlDataReader["Modulo"].ToString();
                    model_.Descripcion = sqlDataReader["Descripcion"].ToString();
                    model_.Grupo = sqlDataReader["Grupo"].ToString();
                    model_.Situacion = sqlDataReader["Situacion"].ToString();
                    listModel.Add(model_);
                }

                sqlDataReader.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return listModel;
        }


        //-RQ Forma de Pago Negativa Buro
        public void updateCheckNegativaBC(string cliente, int check)
        {
            DateTime fecha = DateTime.Now;
            string query =
                string.Format(
                    "update cte with(rowlock) set NegativaBC = {0}, Usuario='{1}', UltimoCambio='{2}'  where Cliente='{3}'",
                    check, ClaseEstatica.Usuario.Usser, fecha.ToString("yyyy-MM-dd HH:mm:ss"), cliente);

            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica))
                {
                    sqlCommand.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #region //-ListaNegra

        /// <summary>
        ///     Metodo encargado de ejecutar el sp SP_DM0257GuardaListaNegra
        /// </summary>
        /// <param name="sClave"></param>
        /// <param name="sEvento"></param>
        /// <param name="iSucursal"></param>
        public void ejecutarListaNegra(string sClave, string sEvento, int iSucursal, int iId)
        {
            try
            {
                string sQuery = "EXEC SP_DM0257GuardaListaNegra @Clave, @Evento, @Sucursal, @IdVenta";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Clave", sClave)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Evento", sEvento)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Sucursal", iSucursal)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@IdVenta", iId)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void listaNegraHistorico(ListaNegraHistorico listaNegra)
        {
            string sQuery = "EXEC SpCREDIGuardaListaNegra @IdVenta, @Usuario, @Calificacion, @Observaciones, @Origen";
            try
            {
                SqlParameter[] pars =
                {
                    new SqlParameter("@IdVenta", listaNegra.idVenta)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Usuario", listaNegra.usuario)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Calificacion", listaNegra.calificacion)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Observaciones", listaNegra.observaciones)
                    {
                        SqlDbType = SqlDbType.VarChar
                    },
                    new SqlParameter("@Origen", listaNegra.origen)
                    {
                        SqlDbType = SqlDbType.VarChar
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception("CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        #endregion

        #region //-1927

        public string obtenerBeneficiarioFinal(int iIdVenta)
        {
            string sBeneficiario = string.Empty;
            dt = new DataTable();

            try
            {
                string sQuery = @"SELECT ISNULL(CteFinal,'') AS CteFinal FROM Venta WITH(NOLOCK) WHERE id = @Id";

                SqlParameter[] pars =
                {
                    new SqlParameter("@Id", iIdVenta)
                    {
                        SqlDbType = SqlDbType.Int
                    }
                };

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.Parameters.AddRange(pars);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }

                if (dt.Rows.Count > 0)
                    foreach (DataRow item in dt.Rows)
                        sBeneficiario = item["CteFinal"].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return sBeneficiario;
        }


        public bool ValidarAltaCteFValida(string sCteF)
        {
            bool bResultado = true;
            dt = new DataTable();
            try
            {
                string sQuery = "SP_SID_ProcesoscteFinal";

                using (SqlCommand cmd = new SqlCommand(sQuery, ClaseEstatica.ConexionEstatica))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@opcion", SqlDbType.VarChar).Value = "expvalidar";
                    cmd.Parameters.Add("@Solicitud", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@buscar", SqlDbType.VarChar).Value = " AND r.cte_final = '" + sCteF + "'";
                    cmd.Parameters.Add("@valor1", SqlDbType.VarChar).Value = "";

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                            if (dr["Registro"] + "" == "ALTA" && dr["Valido"] + "" == "True")
                            {
                                bResultado = false;
                                break;
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }


            return bResultado;
        }

        #endregion
    }
}