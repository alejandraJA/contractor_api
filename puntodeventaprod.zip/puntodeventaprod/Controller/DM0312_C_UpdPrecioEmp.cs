﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;

namespace PuntoVenta.Controller
{
    public class DM0312_C_UpdPrecioEmp
    {
        private void EjecutaSpActualizaPrecios(int canal, string condicion, int suc, string Art, int idventa,
            bool redime)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spMAVIDM0148ActualizarPreciosEmpleados";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 100;

                cmd.Parameters.AddWithValue("@Canal", canal);
                cmd.Parameters.AddWithValue("@Condicion", condicion);
                cmd.Parameters.AddWithValue("@Art", Art);
                cmd.Parameters.AddWithValue("@Suc", suc);
                cmd.Parameters.AddWithValue("@ID", idventa);
                cmd.Parameters.AddWithValue("@AplicaPuntos", redime);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UpdPrecioEmp", ex);
                MessageBox.Show(ex.Message + "EN DM0312_C_UpdPrecioEmp");
            }
        }

        private int Countproprelistadfinal(int canal, string condicion, int suc, string Art)
        {
            SqlDataReader dr = null;

            int res = 0;

            string query = string.Format(
                " Select count(p1.Precio) from proprelistadfinal p1 WITH(NOLOCK) join Condicion c WITH(NOLOCK) on c.PropreGrupo=p1.Condicion"
                + " join Sucursal s WITH(NOLOCK) on S.Sucursal = p1.Sucursal where p1.Canal={0} and p1.Articulo='{1}' and c.Condicion='{2}' and p1.Sucursal={3}"
                , canal, Art, condicion, suc);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UpdPrecioEmp", ex);
                MessageBox.Show(ex.Message + "EN Countproprelistadfinal");
            }

            return res;
        }

        private int CountproprelistadfinalInst(int canal, string condicion, string Art)
        {
            SqlDataReader dr = null;

            int res = 0;

            string query = string.Format(
                " Select count(p1.Precio) from proprelistadfinal p1 WITH(NOLOCK) join Condicion c WITH(NOLOCK) on c.PropreGrupo=p1.Condicion "
                + " join Sucursal s WITH(NOLOCK) on S.Sucursal = p1.Sucursal AND Tipo='{0}' where  p1.Canal={1} and p1.Articulo='{2}' and c.Condicion='{3}'"
                + " and p1.Sucursal in (Select MIN(Sucursal) From Sucursal WITH(NOLOCK) where Tipo='{0}')"
                , "INSTITUCIONES", canal, Art, condicion);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                cmd.CommandTimeout = 100;

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = Convert.ToInt32(dr[0].ToString());
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UpdPrecioEmp", ex);
                MessageBox.Show(ex.Message + "EN Countproprelistadfinal");
            }

            return res;
        }

        private string spPropreActualizarPrecios(int idventa)
        {
            string res = string.Empty;

            SqlDataReader dr = null;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ClaseEstatica.ConexionEstatica;
                cmd.CommandText = "spPropreActualizarPrecios";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 100;

                cmd.Parameters.AddWithValue("@ID", idventa);
                cmd.Parameters.AddWithValue("@Estatus", DBNull.Value);

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    while (dr.Read())
                        res = dr[0].ToString();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_C_UpdPrecioEmp", ex);
                MessageBox.Show(ex.Message + "EN DM0312_C_UpdPrecioEmp");
            }

            finally
            {
                if (dr != null)
                    dr.Close();
            }

            return res;
        }

        public string ActualizaPrecios(int canal, string condicion, int suc, string Art, int idventa, bool redime,
            string Mov)
        {
            if (Mov != "Solicitud Credito") return "No se puede realizar la actualización";

            EjecutaSpActualizaPrecios(canal, condicion, suc, Art, idventa, redime);

            int count = Countproprelistadfinal(canal, condicion, suc, Art);

            if (count == 0)
            {
                int countInst = CountproprelistadfinalInst(canal, condicion, Art);

                if (countInst == 0) return "No existe Precio definido";
            }

            string actualizar = spPropreActualizarPrecios(idventa);

            if (actualizar == "Ocurrio un error en el Proceso") return actualizar;

            return "OK";
        }
    }
}