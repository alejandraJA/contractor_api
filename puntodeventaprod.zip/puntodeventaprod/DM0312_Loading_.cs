﻿using System;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Properties;

namespace PuntoVenta
{
    public partial class DM0312_Loading_ : Form
    {
        public bool LoaderCentrado = true;

        public DM0312_Loading_()
        {
            InitializeComponent();
        }

        private void DM0312_Loading__Load(object sender, EventArgs e)
        {
            BackColor = Color.White;
            TransparencyKey = Color.White;
            Imagen();
        }

        private void Imagen()
        {
            //-CambioImagenesResources
            imgPictureBox.Visible = true;

            string path_ = AppDomain.CurrentDomain.BaseDirectory;
            Bitmap image = Resources.Loading;
            imgPictureBox.Image = image;
            imgPictureBox.BackColor = Color.White;
            imgPictureBox.BringToFront();
        }

        private void DM0312_Loading__FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        /// <summary>
        ///     center the form to the owner form
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/10/17
        private void DM0312_Loading__Activated(object sender, EventArgs e)
        {
            if (LoaderCentrado) MoveLoader();
        }

        /// <summary>
        ///     Move loader
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        public void MoveLoader()
        {
            if (Owner != null)
            {
                int boundWidth = Owner.Width;
                int boundHeight = Owner.Height;
                int x = boundWidth - Width;
                int y = boundHeight - Height;
                Location = new Point(Owner.Location.X + x / 2, Owner.Location.Y + y / 2);
            }
        }
    }
}