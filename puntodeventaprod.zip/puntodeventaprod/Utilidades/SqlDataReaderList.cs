﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PuntoVenta.Utilidades
{
    public static class SqlDataReaderList
    {
        public static IEnumerable<T> ToList<T>(this IDataReader reader, Func<IDataReader, T> projection)
        {
            while (reader.Read())
                yield return projection(reader);
        }

        public static T FirstOrDefault<T>(this IDataReader reader, Func<IDataReader, T> projection)
        {
            return ToList(reader, projection).FirstOrDefault();
        }
    }

    public static class ValadorFormulario
    {
        private static readonly List<Control> controles = new List<Control>();

        public static bool VerificarInput(this Control input, ErrorProvider error, Func<string, bool> predicado)
        {
            try
            {
                bool resultado = predicado(input.Text);
                error.SetError(input, resultado ? "Verificar Información" : string.Empty);
                return resultado;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool OcultarPanel(this Control panel, Func<bool> predicado)
        {
            try
            {
                panel.Enabled = predicado();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return false;
            }
        }

        public static void SafeChange(this Control inputs, string change)
        {
            try
            {
                inputs.BeginInvoke((MethodInvoker)delegate { inputs.Text = change; });
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
            }
        }

        public static bool SafeChange(this Control input, Func<Control, bool> predicado)
        {
            try
            {
                bool resp = false;
                input.BeginInvoke((MethodInvoker)delegate { resp = predicado(input); });
                return resp;
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return false;
            }
        }

        public static async Task<bool> AsyncSafeChange(this Control input, Func<Control, bool> predicado)
        {
            try
            {
                await Task.Yield();
                bool resp = false;
                input.BeginInvoke((MethodInvoker)delegate { resp = predicado(input); });
                return resp;
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return false;
            }
        }

        public static void InahabilitarInputs(this Control form, bool show)
        {
            try
            {
                List<Control> lista = form.Controls.Cast<Control>().ToList();
                foreach (Control c in form.Controls)
                    if (c is Label label)
                    {
                    }
                    else if (c is Panel panel)
                    {
                        panel.InahabilitarInputs(show);
                    }
                    else if (show)
                    {
                        if (c.Enabled && !controles.Any(x => x.Name.ToUpper() == c.Name.ToUpper()))
                        {
                            c.Enabled = false;
                            controles.Add(c);
                        }
                    }
                    else
                    {
                        if (controles.Contains(c))
                        {
                            c.Enabled = true;
                            controles.Remove(c);
                        }
                    }
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                controles.Clear();
            }
        }

        public static void ReadParametros<T, K>(this T origen, K destino) where K : class
        {
            try
            {
                Type tipOrigen = origen.GetType();
                List<FieldInfo> camposOrigen = tipOrigen.GetFields().ToList();
                Type tipDestino = destino.GetType();
                List<FieldInfo> camposDestino = tipDestino.GetFields().ToList();
                Parallel.For(0, camposOrigen.Count, i =>
                {
                    try
                    {
                        int index = camposDestino.FindIndex(x => x.Name.ToUpper() == camposOrigen[i].Name.ToUpper());
                        camposDestino[index].SetValue(destino, camposOrigen[i].GetValue(origen));
                    }
                    catch (Exception ex)
                    {
                        Debug.Fail(ex.Message);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
            }
        }

        public static bool VerifyTask(this Form form, params Task<bool>[] tareas)
        {
            try
            {
                return !tareas.Any(x => x.Result == false);
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return false;
            }
        }
    }

    public static class Utilidades
    {
        public static string ToPhone(this string cadena)
        {
            try
            {
                if (string.IsNullOrEmpty(cadena)) return string.Empty;
                Regex regex = new Regex(@"^[0-9]+");
                List<char> numeros = cadena.ToArray().Where(x => regex.IsMatch(x.ToString())).ToList();
                return string.Join("", numeros);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                return "";
            }
        }

        public static bool IsPhone(this string cadena)
        {
            try
            {
                using (SqlCommand command =
                       new SqlCommand(@"SP_MaviDM0312ValidacionTelefono", ClaseEstatica.ConexionEstatica))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Telefono", cadena);
                    SqlDataReader reader = command.ExecuteReader();
                    if (!reader.HasRows) return false;
                    while (reader.Read()) return reader[0].ToString().Equals("0");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                return false;
            }
        }

        public static bool ObtenerInformacionArticulo(this List<string> articulos)
        {
            //SP_MaviDM0312PuntoVentaInformacionArticulos
            bool tieneMoto = false;
            try
            {
                foreach (string id in articulos) tieneMoto = ValidarFamiliaArticulo(id);
            }
            catch (Exception ex)
            {
                return false;
            }

            return tieneMoto;
        }

        public static bool ValidarFamiliaArticulo(this string id)
        {
            bool tieneMoto = false;
            using (SqlCommand commando =
                   new SqlCommand(
                       @"select Familia, * from Art WITH(NOLOCK) where Familia like '%MOTOCICLETAS%' AND Articulo = @id",
                       ClaseEstatica.ConexionEstatica))
            {
                commando.Parameters.AddWithValue("@id", id);
                commando.CommandType = CommandType.Text;
                SqlDataReader dt = commando.ExecuteReader();
                tieneMoto = dt.HasRows;
            }

            return tieneMoto;
        }

        public static string GetDMZ(this string dmz)
        {
            try
            {
                if (string.IsNullOrEmpty(dmz)) throw new Exception();
                return ConfigurationManager.AppSettings["DMZ"];
            }
            catch (Exception ex)
            {
                return "http://factura.creditazzo.mx:7212/";
            }
        }

        public static string ToClienteF(this int ventaid)
        {
            try
            {
                string clienteF = string.Empty;
                using (SqlCommand commando = new SqlCommand(@"SELECT CteFinal FROM Venta WITH(NOLOCK) WHERE Id = @Id",
                           ClaseEstatica.ConexionEstatica))
                {
                    commando.Parameters.AddWithValue("@Id", ventaid);
                    commando.CommandType = CommandType.Text;
                    SqlDataReader dt = commando.ExecuteReader();
                    if (!dt.HasRows) return null;
                    while (dt.Read()) clienteF = dt["CteFinal"].ToString();
                    return clienteF;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static void SendSMSCanal80(string telefono, string ClienteID, int VentaId, int idSMS = 52)
        {
            try
            {
                if (string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(ClienteID))
                    throw new Exception("El telefono o Cliente ID no es Correcto");
                if (!telefono.IsPhone()) throw new Exception($"El Numero {telefono} no es valido");
                string sQuery =
                    @"INSERT INTO TcAAEA00030_EnvioMensajes(IdMensaje,idRegistro, Cliente,FechaEnvio,EstatusEnvio,Tipo,IntentoRespuesta,IntentoEnvio,Telefono, ClienteF) VALUES(@Sms, @id,@Cliente, GETDATE(), 1, 0, 0, 0, @Telefono, @ClienteF)";
                using (SqlCommand commando = new SqlCommand(sQuery, ClaseEstatica.ConexionEstaticaAndroidS))
                {
                    commando.CommandType = CommandType.Text;
                    commando.Parameters.AddWithValue("@Cliente", ClienteID);
                    commando.Parameters.AddWithValue("@Telefono", telefono);
                    commando.Parameters.AddWithValue("@Sms", idSMS);
                    commando.Parameters.AddWithValue("@id", VentaId);
                    commando.Parameters.AddWithValue("@ClienteF", VentaId.ToClienteF());
                    int isAdd = commando.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Erro al enviar SMS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}