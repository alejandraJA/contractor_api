﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PuntoVenta.Utilities
{
    public static class Utilities
    {
        public static string ToPhone(this string cadena)
        {
            try
            {
                if (string.IsNullOrEmpty(cadena)) return string.Empty;
                Regex regex = new Regex(@"^[0-9]+");
                var numeros = cadena.ToArray().Where(x => regex.IsMatch(x.ToString())).ToList();
                return string.Join("", numeros);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                return "";
            }
        }
        public static bool IsPhone(this string cadena)
        {
            try
            {
                if (string.IsNullOrEmpty(cadena)) return false;
                Regex regex = new Regex(@"^[0-9]{7,10}");
                return regex.IsMatch(cadena);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                return false;
            }
        }
    }
}
