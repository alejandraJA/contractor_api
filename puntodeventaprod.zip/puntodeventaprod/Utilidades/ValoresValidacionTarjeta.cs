﻿namespace PuntoVenta.Utilidades
{
    internal class ValoresValidacionTarjeta
    {
        public ValoresValidacionTarjeta()
        {
            Null = -1;
            No = 0;
            NoTiene = 1;
            SiTiene = 2;
            EnviadoValidar = 3;
            ValidacionPositiva = 4;
            ValidacionNegativa = 5;
            ErrorConexion = 6;
        }

        public int Null { get; }
        public int No { get; }
        public int NoTiene { get; }
        public int SiTiene { get; }
        public int EnviadoValidar { get; }
        public int ValidacionPositiva { get; }
        public int ValidacionNegativa { get; }
        public int ErrorConexion { get; }
    }
}