﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using PuntoVenta.Model;

//Autor:Rodolfo Sanchez
namespace PuntoVenta
{
    public static class ClaseEstatica
    {
        //clase estatica que se pueden usar en toda la aplicacion

        /*Objetos estaticos para DM0312_RegistroDeHuellaCliente*/
        public static DateTime FechaInicio;

        public static DateTime FechaFin;

        public static bool DM0312_RegistroDeHuellaFechas = false;

        //*Fotos
        public static List<DM0312_MAnexoCta> ListaAnexoCta;

        public static List<DM0312_MAnexoCta> ListaAnexoCtaHistorica;

        //*Huellas
        public static List<DM0312_MRegistroCte> ListaCte;

        public static string FormActivo;
        /*******************************************************/

        /*Usuario para toda la aplicacion*/
        public static Usuario Usuario;

        /*Estacion para toda la aplicacion*/
        public static int WorkStation = 0;

        /*Conexion*/
        public static SqlConnection ConexionEstatica;

        /*ConexionAndroidServicio*/
        public static SqlConnection ConexionEstaticaAndroidS;

        /*ConexionAndroid*/
        public static SqlConnection ConexionEstaticaAndroid;

        /*ConexionAndroidSid*/
        public static SqlConnection ConexionEstaticaAndroidSid; //-ReporteDima

        public static SqlConnection ConexionHistoricoAdminDoc;

        /*Series Articulos*/
        public static List<MSerieArticulos> SeriesArticulos;

        /* Ruta que permite ejecutar los PlugIns */
        public static string plugInPath = string.Empty;

        /*Permisos para afectar movimiento y crear*/
        public static List<string> ListaPermisosCreacion;

        /*SPID*/
        public static string SPID;

        /*Agente*/
        public static string AgenteU;

        /*Costo*/ //parametro "Cual"
        public static string TipoCosteo;


        /*Lista Clientes Report ClienteExpress*/
        public static List<string> ListClientes = new List<string>();

        public static Dictionary<string, string> sancion = new Dictionary<string, string>();

        //-CerradoIntelisis
        /*ID de sesion de intelisis*/
        public static string loginID { get; set; }

        //-DataLogic
        /// <summary>
        ///     Variable requerida para el modulo de pago de servicios
        /// </summary>
        public static int iSucural { get; set; }

        /// <summary>
        ///     Variable encargada de saber si la venta es de una recarga
        /// </summary>
        public static int iRecarga { get; set; }
    }
}