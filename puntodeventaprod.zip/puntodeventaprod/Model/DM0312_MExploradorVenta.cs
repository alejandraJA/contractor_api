﻿using System;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MExploradorVenta
    {
        public string ClienteFinal { get; set; }

        [DisplayName("Estatus envio")] public string EstatusEnvio { get; set; }

        [DisplayName("TiempoT Transcurrido")] public string tiempoTotalTranscurrido { get; set; }

        [DisplayName("Fecha de Envio")] public DateTime FechaEnvio { get; set; }

        [DisplayName("%Supervision")] public string Supervision { get; set; }

        [DisplayName("VTA cambaceo")] public string VtaCambaceo { get; set; }


        public string Movimiento { get; set; }

        public int Suc { get; set; }

        public string Cliente { get; set; }

        public string RFC { get; set; }

        public string FechaNacimiento { get; set; }

        public string Telefonos { get; set; }

        public string Nombre { get; set; }

        public string Situacion { get; set; }

        public string Condicion { get; set; }

        [DisplayName("Importe total")] public string ImporteTotal { get; set; }

        [DisplayName("Tipo cliente")] public string TipoCliente { get; set; }

        public string Canal { get; set; }

        public string Monedero { get; set; }

        public string Estatus { get; set; }

        public string Reactivacion { get; set; }

        public string Grupo { get; set; }

        public string Relacionado { get; set; }

        [DisplayName("Referencia anterior")] public string ReferenciaAnterior { get; set; }

        [DisplayName("Fecha alta")] public DateTime FechaAlta { get; set; }

        public string Calificaciones { get; set; }

        public string Poblacion { get; set; }

        public string Seguimiento { get; set; }

        public string Agente { get; set; }

        [DisplayName("Fecha ult mod")] public DateTime FechaUltimaMod { get; set; }

        public string Almacen { get; set; }

        public string Impreso { get; set; }

        [DisplayName("Tipo credito")] public string TipoCredito { get; set; }

        [Browsable(false)] public string Bandera { get; set; }

        [Browsable(false)] public string Mov { get; set; }

        [Browsable(false)] public string MovId { get; set; }

        [Browsable(false)] public int ID { get; set; }

        [Browsable(false)] public string Usuario { get; set; }


        public string IDEcommerce { get; set; }

        [Browsable(false)] public string AnticiposFacturados { get; set; }

        [Browsable(false)] public string GrupoTrabajo { get; set; }

        [Browsable(false)] public string Concepto { get; set; }

        [Browsable(false)] public string EnviarA { get; set; }

        [Browsable(false)] public string MaviTipoVenta { get; set; }

        [Browsable(false)] public string MovTipo { get; set; }

        [Browsable(false)] public string ff { get; set; }

        [Browsable(false)] public double Importe { get; set; }

        [Browsable(false)] public int? SucursalDestino { get; set; }

        [Browsable(false)] public int? Sucursal { get; set; }

        [Browsable(false)] public string Nomina { get; set; }

        [DisplayName("Tipo Entrega")] public string TipoEntrega { get; set; }

        [DisplayName("ReactivacionLiberacion")]
        public string ReactivacionLiberacion { get; set; }

        [DisplayName("ReactivacionComplemento")]
        public string ReactivacionComplemento { get; set; }

        [DisplayName("SeguimientoReactivacion")]
        public string SeguimientoReactivacion { get; set; }

        [DisplayName("Reanalisis")] public string Reanalisis { get; set; }
    }
}