﻿namespace PuntoVenta.Model
{
    public class MClaveEvento
    {
        public string MEN00144 { get; set; }
        public string MEN00119 { get; set; }
        public string MEN00120 { get; set; }
        public string MEN00121 { get; set; }
        public string MEN00125 { get; set; }
        public string MEN00133 { get; set; }
        public string MEN00134 { get; set; }
    }
}