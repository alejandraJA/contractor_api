﻿using System;

namespace PuntoVenta.Model
{
    public class mopsModel
    {
        public int iId { get; set; }
        public string sCliente { get; set; }
        public string sMov { get; set; }
        public string sMovId { get; set; }
        public DateTime dtFechaEmision { get; set; }
        public DateTime dtVencimineto { get; set; }
        public int iCanalVenta { get; set; }
        public int iNumeroDocumentos { get; set; }
        public int iUen { get; set; }
        public double dSaldo { get; set; }
        public DateTime dtUltimaConclusion { get; set; }
        public DateTime dtFechaPrimerPago { get; set; }
    }
}