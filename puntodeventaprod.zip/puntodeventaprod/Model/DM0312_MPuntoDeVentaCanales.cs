﻿namespace PuntoVenta.Model
{
    public class DM0312_MPuntoDeVentaCanales
    {
        public int Canal { get; set; }
        public string Clave { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
    }
}