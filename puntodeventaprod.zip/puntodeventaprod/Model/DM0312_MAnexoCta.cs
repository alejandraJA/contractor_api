﻿using System;

namespace PuntoVenta.Model
{
    public class DM0312_MAnexoCta
    {
        public int IDR { get; set; }

        public string Cuenta { get; set; }

        public string Direccion { get; set; }

        public DateTime FechaAlta { get; set; }

        public byte[] Imagen { get; set; }
    }
}