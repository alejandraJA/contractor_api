﻿namespace PuntoVenta.Model
{
    public class MovPropiedadesData
    {
        public string almacen;
        public float anticipos;
        public string articulo;
        public float cantidad;
        public string cliente;
        public string concepto;
        public string descripcion1;
        public float descuento;
        public string estatus;
        public string fechaEmision;
        public float importe;
        public float importeTotal;
        public float impuestos;
        public string moneda;

        public string mov;
        public string movId;
        public string nombre;
        public string observaciones;
        public float precio;
        public float precioImporte;
        public string proyecto;
        public string referencia;
        public string subCuenta;
        public float subTotal;
        public float sumaAnticipos;


        public string Mov
        {
            get => mov;
            set => mov = value;
        }

        public string MovId
        {
            get => movId;
            set => movId = value;
        }

        public string Estatus
        {
            get => estatus;
            set => estatus = value;
        }

        public string Proyecto
        {
            get => proyecto;
            set => proyecto = value;
        }

        public string FechaEmision
        {
            get => fechaEmision;
            set => fechaEmision = value;
        }

        public string Moneda
        {
            get => moneda;
            set => moneda = value;
        }

        public string Nombre
        {
            get => nombre;
            set => nombre = value;
        }

        public string Cliente
        {
            get => cliente;
            set => cliente = value;
        }

        public string Referencia
        {
            get => referencia;
            set => referencia = value;
        }

        public string Concepto
        {
            get => concepto;
            set => concepto = value;
        }

        public string Observaciones
        {
            get => observaciones;
            set => observaciones = value;
        }

        public string Articulo
        {
            get => articulo;
            set => articulo = value;
        }

        public string SubCuenta
        {
            get => subCuenta;
            set => subCuenta = value;
        }

        public string Descripcion1
        {
            get => descripcion1;
            set => descripcion1 = value;
        }

        public string Almacen
        {
            get => almacen;
            set => almacen = value;
        }

        public float Cantidad
        {
            get => cantidad;
            set => cantidad = value;
        }

        public float Precio
        {
            get => precio;
            set => precio = value;
        }

        public float Descuento
        {
            get => descuento;
            set => descuento = value;
        }

        public float PrecioImporte
        {
            get => precioImporte;
            set => precioImporte = value;
        }

        public float Anticipos
        {
            get => anticipos;
            set => anticipos = value;
        }

        public float Importe
        {
            get => importe;
            set => importe = value;
        }

        public float SumaAnticipos
        {
            get => sumaAnticipos;
            set => sumaAnticipos = value;
        }

        public float SubTotal
        {
            get => subTotal;
            set => subTotal = value;
        }

        public float Impuestos
        {
            get => impuestos;
            set => impuestos = value;
        }

        public float ImporteTotal
        {
            get => importeTotal;
            set => importeTotal = value;
        }
    }
}