﻿namespace PuntoVenta.Model
{
    public class ConfiguracionesUsuario
    {
        public string Usuario { get; set; }
        public string GrupoUsuario { get; set; }
        public bool Afectar { get; set; }

        public bool Cancelar { get; set; }

        //        public bool Desafectar { get; set; }
        public bool Autorizar { get; set; }

        public bool AutorizarVenta { get; set; }

        //public bool AutorizarCxp { get; set; }
        //public bool AutorizarGasto { get; set; }
        //public bool AutorizarDinero { get; set; }
        //public bool AutorizarPV { get; set; }
        //public bool AutorizarCompra { get; set; }
        public bool AutorizarSeriesLotes { get; set; }
        public bool AfectarOtrosMovs { get; set; }
        public bool CancelarOtrosMovs { get; set; }
        public bool ConsultarOtrosMovs { get; set; }
        public bool ConsultarOtrosMovsGrupo { get; set; }
        public bool ConsultarOtrasEmpresas { get; set; }

        public bool ConsultarOtrasSucursales { get; set; }

        //public bool AccesarOtrasSucursalesEnLinea { get; set; }
        public bool ModificarOtrosMovs { get; set; }

        //public bool ModificarVencimientos { get; set; }
        //public bool ModificarEntregas { get; set; }
        //public bool ModificarFechaRequerida { get; set; }
        //public bool ModificarEnvios { get; set; }
        public bool ModificarReferencias { get; set; }
        public bool ModificarSituacion { get; set; }
        public bool ModificarAgente { get; set; }
        public bool ModificarUsuario { get; set; }

        public bool ModificarListaPrecios { get; set; }

        //public bool ModificarZonaImpuesto { get; set; }
        //public bool ModificarSucursalDestino { get; set; }
        //public bool ModificarProyUENActCC { get; set; }
        public bool AgregarCteExpress { get; set; }
        public bool AgregarArtExpress { get; set; }
        public bool Costos { get; set; }

        public bool BloquearCostos { get; set; }

        //public bool VerInfoDeudores { get; set; }
        //public bool VerComisionesPendientes { get; set; }
        //public bool BloquearEncabezadoVenta { get; set; }
        //public bool BloquearCxcCtaDinero { get; set; }
        //public bool BloquearCxpCtaDinero { get; set; }
        //public bool BloquearDineroCtaDinero { get; set; }
        public bool EnviarExcel { get; set; }
        public bool ImprimirMovs { get; set; }

        public bool PreliminarMovs { get; set; }
        //public bool Reservar { get; set; }
        //public bool DesReservar { get; set; }
        //public bool Asignar { get; set; }
        //public bool DesAsignar { get; set; }
        //public bool ModificarAlmacenPedidos { get; set; }
        //public bool ModificarConceptos { get; set; }
        //public bool ModificarReferenciasSiempre { get; set; }
        //public bool ModificarAgenteCxcPendiente { get; set; }
        //public bool ModificarMovsNominaVigentes { get; set; }
        //public bool BloquearPrecios { get; set; }
        //public bool BloquearDescGlobal { get; set; }
        //public bool BloquearDescLinea { get; set; }
        //public bool BloquearCondiciones { get; set; }
        //public bool BloquearAlmacen { get; set; }
        //public bool BloquearMoneda { get; set; }
        //public bool BloquearAgente { get; set; }
        //public bool BloquearFechaEmision { get; set; }
        //public bool BloquearProyecto { get; set; }
        //public bool BloquearFormaPago { get; set; }
    }
}