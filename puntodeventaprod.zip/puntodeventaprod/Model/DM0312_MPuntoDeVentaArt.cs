﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MPuntoDeVentaArt
    {
        public string Codigo { get; set; }
        public string Disponible { get; set; }
        public string Nombre { get; set; }
        public string Linea { get; set; }
        public string Estatus { get; set; }
        public string Impuesto { get; set; }
        public string Tipo { get; set; }
        public string unidad { get; set; }

        [Browsable(false)] public string Grupo { get; set; }

        //-ReservaOnline
        public int ReservaOnline { get; set; }
    }
}