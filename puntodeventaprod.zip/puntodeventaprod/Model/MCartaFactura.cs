﻿namespace PuntoVenta.Model
{
    public class MCartaFactura
    {
        public string FechaEmision { get; set; }
        public string Cliente { get; set; }
        public string Domicilio { get; set; }
        public string Factura { get; set; }
        public string FechaImpresion { get; set; }
        public string Articulo { get; set; }
        public string Motor { get; set; }
        public string Cuadro { get; set; }
        public string Pedimento { get; set; }
        public string Modelo { get; set; }
        public string Color { get; set; }
        public string Aduana { get; set; }
        public string FechaAduana { get; set; }
        public string Importe { get; set; }
        public string Sucursal { get; set; }
        public string TipoVenta { get; set; }
        public string DomicilioSucursal { get; set; }
        public bool logoM { get; set; }
        public bool logoV { get; set; }
        public string ciudad { get; set; }
    }
}