﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PuntoVenta.Model
{
    public class Abono
    {
///////////////////////CALCULOS PARA BONIFICACIÓN/////////////////////////////////
        public int idVenta { get; set; }
        public string IdCliente { get; set; }
        public int IDSucursal { get; set; }
        public int CanalVenta { get; set; }
        public string Condicion { get; set; }
        public int Uen { get; set; }
        public string Movimiento { get; set; }
        public double ImportePagoNormal { get; set; }
        public int DiasVencimiento { get; set; }
        public int DANumeroDocumentos { get; set; }
        public int IDCanalVenta { get; set; }
        public string DAPeriodo { get; set; }
        public string TipoCliente { get; set; }
        public List<AbonoDetalle> Articulos { get; set; }
        public double Bonifica { get; set; }

        public DateTime PrimerAbono(DateTime FechaActual)
        {
            TimeSpan dias = new TimeSpan(DiasVencimiento, 0, 0, 0, 0);
            FechaActual = FechaActual.Add(dias);
            return FechaActual;
        }

        public double ImporteParcialidadPagoNormal()
        {
            return Math.Round(ImportePagoNormal / DANumeroDocumentos, 2, MidpointRounding.ToEven);
        }

        public double ImportePagoInmediato()
        {
            return Math.Round(Articulos.Sum(a => a.Cantidad * a.PagoInmediatoCalculado()), 2, MidpointRounding.ToEven);
        }

        public double ImporteParcialidadPagoInmediato()
        {
            return Math.Round(ImportePagoInmediato() / DANumeroDocumentos, 2, MidpointRounding.ToEven);
        }

        public double AhorroPagoInmediato()
        {
            return Math.Round(ImportePagoNormal - ImportePagoInmediato(), 2, MidpointRounding.ToEven);
        }

        public string Plazo()
        {
            return DANumeroDocumentos + (DAPeriodo.ToUpper().Contains("MENSUAL") ? " Meses" : DAPeriodo);
        }

        public double PorcentajeBonificacion()
        {
            return Math.Round(
                (ImportePagoNormal - Articulos.Sum(a => a.Cantidad * a.PagoInmediatoCalculado())) / ImportePagoNormal *
                100, 0, MidpointRounding.ToEven);
        }

///////////////////////CALCULOS PARA BONIFICACIÓN/////////////////////////////////
        public double Bonificacion()
        {
            return Math.Round(Bonifica, 2, MidpointRounding.ToEven);
        }

        public double AhorraPInmediato()
        {
            return Math.Floor(ImportePagoNormal * (Bonifica / 100));
        }

        public double TotalPagoInmediato()
        {
            return Math.Round(ImportePagoNormal - AhorraPInmediato(), 2, MidpointRounding.ToEven);
        }

        public double TotalParcialInmediato()
        {
            return Math.Round(TotalPagoInmediato() / DANumeroDocumentos, 2, MidpointRounding.ToEven);
        }
        //public double Bonificacion { get; set; }
    }
}