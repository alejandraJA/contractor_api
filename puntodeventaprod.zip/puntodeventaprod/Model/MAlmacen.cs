﻿namespace PuntoVenta.Model
{
    internal class MAlmacen
    {
        public string Clave { get; set; }
        public string Nombre { get; set; }
        public int Sucursal { get; set; }
    }
}