﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class ArticulosDetalleVenta
    {
        public string Articulo { get; set; }
        public string Cantidad { get; set; }

        [DisplayName("Precio unitario")] public string Precio { get; set; }

        public string Importe { get; set; }
        public string Costo { get; set; }
        public string Serie { get; set; }

        [Browsable(false)] public string Embarque { get; set; }

        [Browsable(false)] public string EmbarqueFecha { get; set; }

        public string Observaciones { get; set; }

        [DisplayName("Cantidad pendiente")] public int CantidadPendiente { get; set; }

        [DisplayName("Cantidad a afectar")] public int CantidadAAfectar { get; set; }

        [Browsable(false)] public bool EsPaquete { get; set; }

        [Browsable(false)] public bool EsComponentePaquete { get; set; }

        [Browsable(false)] public int RenglonDeArticulo { get; set; }

        [Browsable(false)] public int RenglonID { get; set; }

        [Browsable(false)] public string Tipo { get; set; }

        [DisplayName("Monedero")] public string sPuntosMonedero { get; set; }

        [Browsable(false)] public double dPuntosMonedero { get; set; }
    }
}