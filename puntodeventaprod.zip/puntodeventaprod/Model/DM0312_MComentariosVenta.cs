﻿namespace PuntoVenta.Model
{
    public class DM0312_MComentariosVenta
    {
        public int Id { get; set; }
        public string Campo { get; set; }
        public string Modulo { get; set; }
        public string Comentario { get; set; }
    }
}