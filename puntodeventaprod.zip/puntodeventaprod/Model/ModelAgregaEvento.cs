﻿using System;

namespace PuntoVenta.Model
{
    public class ModelAgregaEvento
    {
        public string agente;
        public int citaaval;
        public int citaCliente;
        public DateTime citaFecha;
        public string citaHora;
        public string clave;
        public string claveAgente;
        public string cliente;
        public string comentario;
        public string descripcion;
        public string estuatus;
        public string evento;
        public string fecha;

        public int idVenta;
        public string modulo;
        public string mov;
        public string nombreAgente;
        public string situacion;
        public int sucursal;
        public string tipo;
        public string TipoEvento;
        public string usuario;

        public string Clave
        {
            get => clave;
            set => clave = value;
        }

        public string Comentario
        {
            get => comentario;
            set => comentario = value;
        }

        public string Descripcion
        {
            get => descripcion;
            set => descripcion = value;
        }

        public string ClaveAgente
        {
            get => claveAgente;
            set => claveAgente = value;
        }

        public string NombreAgente
        {
            get => nombreAgente;
            set => nombreAgente = value;
        }

        public string Fecha
        {
            get => fecha;
            set => fecha = value;
        }
    }
}