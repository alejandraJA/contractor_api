﻿namespace PuntoVenta.Model
{
    public class DM0312_MCamposExtra
    {
        public string Estado { get; set; }
        public string Delegacion { get; set; }
        public string Colonia { get; set; }
        public int CodigoPostal { get; set; }
    }

    public class DM0312_MCamposExtraRecibe
    {
        public DM0312_MCamposExtraRecibe()
        {
            Estatus = false;
            EstatusConsulta = false;
            ClientePresente = true;
        }

        public string TipoCalle { get; set; }
        public string NomCalle { get; set; }
        public string NumExterior { get; set; }
        public string NumInterior { get; set; }
        public string Cruce { get; set; }
        public string CodigoPostal { get; set; }
        public string Telefono { get; set; }
        public string NumIdenti { get; set; }
        public string Conyuge { get; set; }
        public string Fecha { get; set; }
        public string Relacionado { get; set; }
        public string NumIdent { get; set; }
        public bool Estatus { get; set; }
        public bool EstatusConsulta { get; set; }
        public string Colonia { get; set; }
        public string Mov { get; set; }
        public int IdVenta { get; set; }
        public string Cliente { get; set; }
        public bool ClientePresente { get; set; }
    }
}