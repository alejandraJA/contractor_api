﻿namespace PuntoVenta.Model
{
    public class AccesoColumnas
    {
        public string NombreColumna { get; set; }
        public int ID { get; set; }
        public bool Estatus { get; set; }
        public int Orden { get; set; }
        public bool UpdateConfig { get; set; }
    }
}