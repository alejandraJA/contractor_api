﻿namespace PuntoVenta.Model
{
    public class DM0312_MPuntoDeVentaAgente
    {
        public string Agente { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public string Categoria { get; set; }
        public string Sucursal { get; set; }
    }
}