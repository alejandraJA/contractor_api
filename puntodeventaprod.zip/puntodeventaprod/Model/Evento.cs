﻿using System;

namespace PuntoVenta.Model
{
    public class Evento
    {
        public int idVenta { get; set; }
        public string movVenta { get; set; }
        public string movIdVenta { get; set; }
        public string cliente { get; set; }
        public string clienteNombre { get; set; }

        public DateTime Fecha { get; set; }
        public string Clave { get; set; }
        public string ClavePorDefecto { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }

        public string agente { get; set; }
        public string clave { get; set; }
        public string modulo { get; set; }
        public int id { get; set; }
        public string fecha { get; set; }
        public string evento { get; set; }
        public int sucursal { get; set; }
        public string usuario { get; set; }
        public string tipo { get; set; }
        public string estuatus { get; set; }
        public string situacion { get; set; }
        public int citaCliente { get; set; }
        public int citaaval { get; set; }
        public DateTime citaFecha { get; set; }
        public string citaHora { get; set; }
        public string TipoEvento { get; set; }
        public string mov { get; set; }
    }
}