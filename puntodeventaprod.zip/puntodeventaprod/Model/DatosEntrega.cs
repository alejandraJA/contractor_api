﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    internal class DatosEntrega
    {
        [Browsable(false)] public int ID { get; set; }

        [Browsable(false)] public string IDCliente { get; set; }

        [Browsable(false)] public bool Seleccion { get; set; }

        [DisplayName("Direccion")] public string Direccion { get; set; }

        [DisplayName("Colonia")] public string Colonia { get; set; }

        [Browsable(false)] public string Poblacion { get; set; }

        [DisplayName("Codigo Postal")] public string CP { get; set; }

        [Browsable(false)] public string Estado { get; set; }

        [Browsable(false)] public string EntreCalles { get; set; }

        [Browsable(false)] public string TelefonoParticular { get; set; }

        [Browsable(false)] public string TelefonoMovil { get; set; }

        [Browsable(false)] public string Referencia { get; set; }

        [Browsable(false)] public string NumExt { get; set; }

        [Browsable(false)] public string NumInt { get; set; }
    }
}