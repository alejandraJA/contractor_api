﻿namespace PuntoVenta.Model
{
    public class DM0312_MCteContacto
    {
        public string sCteFinal; //Modelo para contactos

        public string Cuenta { get; set; }

        public string NombreCliente { get; set; }

        public string Conyuge { get; set; }

        public string Contacto { get; set; }

        public string Telefonos { get; set; }

        public string Direccion { get; set; }

        public string Colonia { get; set; }

        public string Poblacion { get; set; }

        public string Empresa { get; set; }

        public string Funciones { get; set; }

        //Agentes
        public string Nomina { get; set; }

        public string AgenteName { get; set; }

        public string cteFinal
        {
            get => sCteFinal;
            set => sCteFinal = value;
        }
    }
}