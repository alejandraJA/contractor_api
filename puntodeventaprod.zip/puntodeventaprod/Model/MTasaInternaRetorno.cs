﻿namespace PuntoVenta.Model
{
    public class MTasaInternaRetorno
    {
        public string Cat { get; set; }
        public string Tasa { get; set; }
        public string Contado { get; set; }
        public string Credito { get; set; }
        public string PagoCiclo { get; set; }
    }
}