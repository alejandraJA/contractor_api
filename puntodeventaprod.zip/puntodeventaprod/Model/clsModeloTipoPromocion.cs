﻿namespace PuntoVenta.Model
{
    public class clsModeloTipoPromocion
    {
        public string sArticulo { get; set; }
        public int iTipoPromocion { get; set; }
        public int iCantidadPadres { get; set; }
    }
}