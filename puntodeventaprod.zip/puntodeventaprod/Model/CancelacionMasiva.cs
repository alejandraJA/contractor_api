﻿using System;

namespace PuntoVenta.Model
{
    public class CancelacionMasiva
    {
        public string Cliente { get; set; }

        public string Condicion { get; set; }

        public string Mov { get; set; }

        public string MovId { get; set; }

        public string Movimiento { get; set; }

        public string Estatus { get; set; }

        public double CostoTotal { get; set; }

        public DateTime Fecha { get; set; }

        public string Agente { get; set; }

        public string Almacen { get; set; }

        public string Evento { get; set; }
    }
}