﻿namespace PuntoVenta.Model
{
    public class MRM0847MaviCredRelPedXClienteMayRepImp
    {
        public int ID { get; set; }
        public string SucursalVenta { get; set; }
        public string Nombre { get; set; }
        public string Mov { get; set; }
        public string MovID { get; set; }
        public string FechaEmision { get; set; }
        public string FechaRegistro { get; set; }
        public string EnviarA { get; set; }
        public string Cliente { get; set; }
        public string NombreCliente { get; set; }
        public string DireccionCte { get; set; }
        public string EstadoCliente { get; set; }
        public string ColoniaCte { get; set; }
        public string PoblacionCte { get; set; }
        public string CodigoPostalCte { get; set; }
        public string Referencia { get; set; }
        public string OrdenCompra { get; set; }
        public string Observaciones { get; set; }
        public string Condicion { get; set; }
        public string Cadena { get; set; }
        public int NumeroDocumentos { get; set; }
        public string Agente { get; set; }
        public string Situacion { get; set; }
        public string MaviTipoVenta { get; set; }
        public string Vencimiento { get; set; }
        public string Familia { get; set; }
        public string Linea { get; set; }
        public double Preciototal { get; set; }
        public string Solicito { get; set; }
        public string Comenta { get; set; }
        public string FechaNacimiento { get; set; }
        public string Telefono { get; set; }
        public string NombreDeArticulos { get; set; }
        public string NombreAgente { get; set; }
        public string Articulo { get; set; }
        public string ImporteArt { get; set; }
        public string Precio { get; set; }
        public int Cantidad { get; set; }
        public string Usuario { get; set; }
        public string UsuarioNombre { get; set; }
        public string NombreAval { get; set; }
        public string ColoniaAval { get; set; }
        public string CodigoPostalAval { get; set; }
        public string DireccionAval { get; set; }
        public string TelefonosAval { get; set; }
        public string PoblacionAval { get; set; }
        public string EstadoAval { get; set; }
        public string Leyenda { get; set; }
        public string Factor { get; set; }
    }
}