﻿namespace PuntoVenta.Model
{
    public class DM0312_M_ArticulosAdjudicados
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Linea { get; set; }
        public string Estatus { get; set; }
        public string Disponible { get; set; }
        public string Impuesto { get; set; }
        public string Tipo { get; set; }
        public string unidad { get; set; }
    }
}