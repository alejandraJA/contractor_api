﻿namespace PuntoVenta.Model
{
    public class clsModeloOrdenCompra
    {
        public int iIdVenta { get; set; }
        public string sCliente { get; set; }
        public string sMov { get; set; }
        public string sMovId { get; set; }
    }
}