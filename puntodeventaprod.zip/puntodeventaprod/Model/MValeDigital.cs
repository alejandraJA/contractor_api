﻿namespace PuntoVenta.Model
{
    public class MValeDigital
    {
        public int id_vale { get; set; }
        public string cliente { get; set; }
        public string vale { get; set; }
        public int tipo { get; set; }
        public double total { get; set; }
        public string telefono { get; set; }
        public string correo { get; set; }
        public int canal { get; set; }
        public string condicion { get; set; }
        public string beneficiarioFinal { get; set; }
        public double PuntosRedimidos { get; set; }
    }
}