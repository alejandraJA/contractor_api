﻿namespace PuntoVenta.Model
{
    public class clsModeloPosicionDelMovimiento
    {
        public string sModulo { get; set; }
        public int iEstacion { get; set; }
        public string sTipo { get; set; }
        public int iSucursal { get; set; }
        public string sEmpresa { get; set; }
        public string sOModulo { get; set; }
        public int iOiD { get; set; }
        public string sOMov { get; set; }
        public string sOMovID { get; set; }
        public string sOEstatus { get; set; }
        public string sDModulo { get; set; }
        public int iDID { get; set; }
        public string sDMov { get; set; }
        public string sDMovID { get; set; }
        public string sDEstatus { get; set; }
        public bool bCancelado { get; set; }
        public string sClave { get; set; }
        public string sRama { get; set; }
        public bool bEsAcumulativa { get; set; }
        public string sMovimiento { get; set; }
        public string sListaClave { get; set; }
    }
}