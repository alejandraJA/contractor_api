﻿namespace PuntoVenta.Model
{
    public class MReportesServicio
    {
        public int ID { get; set; }
        public string MovID { get; set; }

        public string Movimiento { get; set; }

        //-ReporteDescuento
        public string Origen { get; set; }
    }
}