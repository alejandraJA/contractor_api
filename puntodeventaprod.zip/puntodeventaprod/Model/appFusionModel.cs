﻿using System.ComponentModel;
using System.Drawing;

namespace PuntoVenta.Model
{
    public class appFusionModel
    {
        public int idImagen { get; set; }

        [DisplayName("Imagen")] public string sNombreImagen { get; set; }

        public Image imgImagen { get; set; }

        [DisplayName("Estatus")] public Image imgEstatus { get; set; }

        public bool bEstatusValidacion { get; set; }
        public string sIdImagen { get; set; }
    }
}