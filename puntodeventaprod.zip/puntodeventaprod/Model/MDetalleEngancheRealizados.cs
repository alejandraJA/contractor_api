﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    internal class MDetalleEngancheRealizados
    {
        [Browsable(false)] public int ID { get; set; }

        public string Movimiento { get; set; }
        public string Referencia { get; set; }
        public string Abono { get; set; }
        public string Fecha { get; set; }
    }
}