﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MSolicitudValera
    {
        public string Articulo { get; set; }

        public string Cantidad { get; set; }

        [DisplayName("Precio Unitario")] public double PrecioUnitario { get; set; }

        [DisplayName("Importe")] public double Importe { get; set; }

        //[Browsable(false)]
        public string Descripcion { get; set; }

        //[Browsable(false)]
        public string Unidad { get; set; }

        public string Observaciones { get; set; }

        public string impuesto { get; set; }
    }
}