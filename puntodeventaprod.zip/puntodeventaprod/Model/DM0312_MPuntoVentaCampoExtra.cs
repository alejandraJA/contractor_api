﻿namespace PuntoVenta.Model
{
    public class DM0312_MPuntoVentaCampoExtra
    {
        public string Valor { get; set; }
        public string CampoExtra { get; set; }
    }
}