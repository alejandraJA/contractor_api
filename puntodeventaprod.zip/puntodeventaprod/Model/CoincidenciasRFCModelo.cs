﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class CoincidenciasRFCModelo
    {
        [DisplayName("Cliente")] public string _cliente { get; set; }

        [DisplayName("Nombre")] public string _nombre { get; set; }

        [DisplayName("Fecha Nacimiento")] public string _fechaNacimiento { get; set; }

        [DisplayName("RFC")] public string _rfc { get; set; }

        [DisplayName("Telefono")] public string _telefono { get; set; }

        [DisplayName("Poblacion")] public string _poblacion { get; set; }

        [DisplayName("Canal")] public string _canal { get; set; }
    }
}