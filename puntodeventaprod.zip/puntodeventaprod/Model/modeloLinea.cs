﻿namespace PuntoVenta.Model
{
    public class modeloLinea
    {
        public string sFamilia { get; set; }
        public string sLinea { get; set; }
    }
}