﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class MSerieArticulos
    {
        public bool Editar { get; set; }
        public string Serie { get; set; }
        public string Cuadro { get; set; }
        public string Pedimento { get; set; }
        public string Modelo { get; set; }
        public string Color { get; set; }
        public string Aduana { get; set; }

        [DisplayName("Fecha de Aduana")] public string FechaAduana { get; set; }

        public string Propiedades { get; set; }
    }
}