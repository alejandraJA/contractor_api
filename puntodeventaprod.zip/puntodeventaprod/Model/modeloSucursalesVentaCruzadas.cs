﻿//-BloqueoVentaCruzadaSuc501

namespace PuntoVenta.Model
{
    public class modeloSucursalesVentaCruzadas
    {
        /// <summary>
        ///     Variable donde se guardara la sucursal configurada
        /// </summary>
        public int iSucursal { get; set; }

        /// <summary>
        ///     Dias configurdados a la sucursals
        /// </summary>
        public int iDias { get; set; }
    }
}