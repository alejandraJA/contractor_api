﻿namespace PuntoVenta.Model
{
    public class DM0312_MPromociones
    {
        public int Uen { get; set; }
        public byte[] Imagen { get; set; }
        public int IdImagen { get; set; }
    }
}