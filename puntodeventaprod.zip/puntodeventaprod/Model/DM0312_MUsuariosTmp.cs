﻿using System;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MUsuariosTmp
    {
        [Browsable(false)] public string Mov { get; set; }

        [Browsable(false)] public string MovId { get; set; }

        [DisplayName("Fecha Comenzo")] public DateTime FechaComienzo { get; set; }

        [Browsable(false)] public DateTime FechaTermino { get; set; }

        public string Estatus { get; set; }

        public string Situacion { get; set; }

        public string Tiempos { get; set; }

        public string Usuario { get; set; }

        public string Nombre { get; set; }
    }
}