﻿using System;

namespace PuntoVenta.Model
{
    public class AbonoDetalle
    {
        public string Articulo { get; set; }
        public int Cantidad { get; set; }
        public double PagoNormal { get; set; }
        public double PagoNormalSELP { get; set; }
        public double PagoInmediadoSELP { get; set; }

        public double PagoInmediatoCalculado()
        {
            double Descuento = PagoInmediadoSELP / PagoNormalSELP;
            return Math.Round((Descuento > 0 && Descuento <= 1 ? Descuento : 1) * PagoNormal, 2,
                MidpointRounding.ToEven);
        }
    }
}