﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    internal class MInfoSerieArticulos
    {
        public string Movimiento { get; set; }

        [DisplayName("Fecha emisión")] public string FechaEmision { get; set; }

        public string Referencia { get; set; }
        public string Concepto { get; set; }

        [Browsable(false)] public string Proyecto { get; set; }

        public string Observaciones { get; set; }
    }
}