﻿namespace PuntoVenta.Model
{
    public class clsModeloPromocionDetalle
    {
        public int iIdConfiguracionPromocion { get; set; }
        public int iIdPromocion { get; set; }
        public string sFamiliaP { get; set; }
        public string sLineaP { get; set; }
        public string sArticuloP { get; set; }
        public string sDescripcionP { get; set; }
        public string sExcepcionP { get; set; }
        public bool bRedimeMonP { get; set; }
        public bool bGeneraMonP { get; set; }
        public int iPzaMin { get; set; }
        public double dMontoMin { get; set; }
        public string sFamiliaH { get; set; }
        public string sLineaH { get; set; }
        public string sArticuloH { get; set; }
        public string sDescripcionH { get; set; }
        public double dPorcDesc { get; set; }
        public string sExcepcionH { get; set; }
        public bool bRedimeMonH { get; set; }
        public int iPzaMax { get; set; }
        public string NombreCampana { get; set; }
    }
}