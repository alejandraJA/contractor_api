﻿using System;

namespace PuntoVenta.Model
{
    public class SolicitudCancelaciones
    {
        public int Id { get; set; }

        public string Cliente { get; set; }

        public string Condicion { get; set; }

        public string Mov { get; set; }

        public string MovID { get; set; }


        public string Movimiento { get; set; }

        public string Estatus { get; set; }

        public double Importe { get; set; }

        public DateTime Fecha { get; set; }

        public string Agente { get; set; }

        public string Almacen { get; set; }

        public string Motivo { get; set; }

        public int EnviarA { get; set; }

        public int Rid { get; set; }

        public string Clave { get; set; }

        public string Visible { get; set; }
    }
}