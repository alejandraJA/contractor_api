﻿namespace PuntoVenta.Model
{
    public class MArtVPendientes
    {
        public string Movimiento { get; set; }
        public string Almacén { get; set; }
        public string Cliente { get; set; }
        public string Nombre { get; set; }
        public string FechaEmision { get; set; }
        public string FechaRequerida { get; set; }
        public string Reservado { get; set; }
        public string Ordenado { get; set; }
        public string Pendiente { get; set; }
        public string ImportePendiente { get; set; }
    }
}