﻿namespace PuntoVenta
{
    public class ModelColumnas
    {
        public int id { get; set; }
        public string data { get; set; }
    }
}