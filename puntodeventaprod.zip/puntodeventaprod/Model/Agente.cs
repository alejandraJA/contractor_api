﻿namespace PuntoVenta.Model
{
    public class Agente
    {
        public string clave;
        public string claveAgente;
        public string nombreAgente;

        public string Clave
        {
            get => clave;
            set => clave = value;
        }

        public string ClaveAgente
        {
            get => claveAgente;
            set => claveAgente = value;
        }

        public string NombreAgente
        {
            get => nombreAgente;
            set => nombreAgente = value;
        }
    }
}