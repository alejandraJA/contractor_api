﻿namespace PuntoVenta.Model
{
    //Autor: Rodolfo Sanchez
    //Modulo: Investigacion Telefonica
    //Fecha: 30/08/2017
    public class DM0312_MRefPersonal
    {
        public int IDContacto { get; set; }

        public int IDMovimiento { get; set; }

        public string Movimiento { get; set; }

        public string Consecutivo { get; set; }

        public string Nombre { get; set; }

        public string TiempoCono { get; set; }

        public string Parentesco { get; set; }

        public string ViveEn { get; set; }

        public string ViveDesde { get; set; }

        public string ViveDe { get; set; }

        public string Nomina { get; set; }

        public string ViveMas { get; set; }

        public string Quienes { get; set; }

        public string ClienteDedica { get; set; }

        public string ConyugeDedica { get; set; }

        public string ProblemasPago { get; set; }

        public string CualesPro { get; set; }

        public string Fecha { get; set; }

        public string Hora { get; set; }

        public string Cuenta { get; set; }
    }
}