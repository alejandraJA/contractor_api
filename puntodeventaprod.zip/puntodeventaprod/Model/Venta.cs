﻿namespace PuntoVenta.Model
{
    public class Venta
    {
        public int Id { get; set; }

        public string Mov { get; set; }

        public string MovId { get; set; }

        public string Estatus { get; set; }

        public string Situacion { get; set; }

        public string Cliente { get; set; }
    }
}