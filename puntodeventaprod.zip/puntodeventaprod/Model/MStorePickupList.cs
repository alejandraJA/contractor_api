﻿//-PrimeraFaseDeAutomatizacion

using System;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    internal class MStorePickupList
    {
        [DisplayName("IDEcommerce")] public string idEcommerce { get; set; }

        [DisplayName("Fecha")] public DateTime fecha { get; set; }

        [DisplayName("SKUs")] public string sku { get; set; }

        [DisplayName("Articulos")] public string nom_articulos { get; set; }

        [DisplayName("Cantidad")] public int qty { get; set; }

        [DisplayName("Importe")] public double importe { get; set; }

        [DisplayName("Nombre Cliente")] public string nombre { get; set; }

        [DisplayName("Telefono")] public string telefono { get; set; }

        [DisplayName("Correo")] public string correo { get; set; }
    }
}