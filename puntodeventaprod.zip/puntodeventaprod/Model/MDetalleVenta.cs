﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class MDetalleVenta
    {
        public int ID { get; set; }
        public string Articulo { get; set; }
        public string Cantidad { get; set; }
        public string Precio { get; set; }
        public string Importe { get; set; }
        public string Costo { get; set; }
        public string Impuestos { get; set; }
        public string ImporteTotal { get; set; }
        public string MovID { get; set; }
        public string Serie { get; set; }
        public string Referencia { get; set; }
        public string Descripcion { get; set; }
        public string CanalClave { get; set; }
        public string CanalNombre { get; set; }
        public string Email { get; set; }
        public string Unidad { get; set; }
        public string Condicion { get; set; }
        public string Concepto { get; set; }
        public string FormaPagoTipo { get; set; }
        public string PedimentoTipo { get; set; }
        public string Observaciones { get; set; }
        public string Tipo { get; set; }
        public string Color { get; set; }
        public string Modelo { get; set; }
        public string Aduana { get; set; }
        public string Fecha { get; set; }
        public string Cuadro { get; set; }

        [Browsable(false)] public string Embarque { get; set; }

        [Browsable(false)] public string EmbarqueFecha { get; set; }

        public string EsPaquete { get; set; }
        public string EsComponentePaquete { get; set; }
        public int RenglonID { get; set; }
        public int RenglonDeArticulo { get; set; }
        public int CantidadPendiente { get; set; }
        public int CantidadAAfectar { get; set; }

        public string sPuntosMonedero { get; set; }
        public double dPuntosMonedero { get; set; }
        public bool bCheckMondero { get; set; }
        public string sCuentaClabe { get; set; }
        public string sBanco { get; set; }
    }
}