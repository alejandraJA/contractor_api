﻿namespace PuntoVenta.Model
{
    public class DM0312_MPuntoDeVentaAlmacen
    {
        public string Almacen { get; set; }
        public string Nombre { get; set; }
        public string Grupo { get; set; }
        public int Sucursal { get; set; }
    }
}