﻿namespace PuntoVenta.Model
{
    public static class enumTablaSTD
    {
        public enum TablaSTD
        {
            CATPVTELEFONO,
            CtesGenericos
        }

        public static string getQuery(this TablaSTD me)
        {
            switch (me)
            {
                case TablaSTD.CATPVTELEFONO:
                    return @" SELECT VM.id
                                FROM TablaStD ts WITH (NOLOCK)
                                JOIN VentasCanalMAVI VM WITH (NOLOCK)
                                  ON VM.Categoria = ts.nombre
                               WHERE TablaSt = 'CATPVTELEFONO' ";

                case TablaSTD.CtesGenericos:
                    return @" SELECT cuenta
                                FROM listaD with(nolock)
                               WHERE Lista = 'Ctes Genericos' ";

                default:
                    return "NO VALUE GIVEN";
            }
        }
    }
}