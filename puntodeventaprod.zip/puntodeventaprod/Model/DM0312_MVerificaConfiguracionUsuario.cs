﻿namespace PuntoVenta.Model
{
    internal class DM0312_MVerificaConfiguracionUsuario
    {
        public string Acceso { get; set; }
        public string Forma { get; set; }
        public string Campo { get; set; }
        public bool Estatus { get; set; }
    }
}