﻿namespace PuntoVenta.Model
{
    public class Cliente
    {
        public string CodigoCliente { get; set; }
        public string Nombre { get; set; }
        public string eMail { get; set; }
    }
}