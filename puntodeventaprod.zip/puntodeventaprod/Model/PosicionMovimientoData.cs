﻿namespace PuntoVenta.Model
{
    public class PosicionMovimientoData
    {
        public string Mov { get; set; }
        public string MovId { get; set; }
        public string Estatus { get; set; }
    }
}