﻿using System;
using System.Drawing;

namespace PuntoVenta.Model
{
    public class DM0312_MAdminDoc
    {
        public Guid ID { get; set; }

        public int TIPO_DOC { get; set; }

        public string CLAVE { get; set; }

        public byte[] DOCUMENTO { get; set; }

        public int IDAPLICACION { get; set; }

        public int? ID_EXTERNO { get; set; }

        public string FORMATO { get; set; }

        public int ID_FOTO { get; set; }

        public string DIR { get; set; }

        public Image Imagen { get; set; }

        public DateTime Fecha { get; set; }
    }
}