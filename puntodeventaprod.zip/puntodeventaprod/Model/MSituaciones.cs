﻿namespace PuntoVenta.Model
{
    public class MSituaciones
    {
        public int ID { get; set; }
        public string Situacion { get; set; }
        public string Flujo { get; set; }
    }
}