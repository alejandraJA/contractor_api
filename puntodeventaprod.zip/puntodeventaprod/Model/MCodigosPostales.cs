﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class MCodigosPostales
    {
        [Browsable(false)] public int? ID { get; set; }

        public string Estado { get; set; }

        [Browsable(false)] public string ColoniaYCodigo { get; set; }

        public string Delegacion { get; set; }
        public string Colonia { get; set; }

        [DisplayName("Codigo postal")] public string CP { get; set; }

        [Browsable(false)] public string Ruta { get; set; }
    }
}