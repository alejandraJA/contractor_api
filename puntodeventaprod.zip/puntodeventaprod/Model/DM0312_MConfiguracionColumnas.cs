﻿namespace PuntoVenta.Model
{
    public class DM0312_MConfiguracionColumnas
    {
        public string Acceso { get; set; }
        public string Forma { get; set; }
        public string Campo { get; set; }
        public string DescripcionCampo { get; set; }
        public bool Estatus { get; set; }
    }
}