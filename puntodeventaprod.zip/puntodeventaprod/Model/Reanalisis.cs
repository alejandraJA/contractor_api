﻿namespace PuntoVenta.Model
{
    public class Reanalisis
    {
        public int idVenta { get; set; }
        public string agente { get; set; }
        public string[] listaAgentes { get; set; }

        public string Evento { get; set; }
        public string TipoRespuesta { get; set; }
        public string Observacion { get; set; }
    }
}