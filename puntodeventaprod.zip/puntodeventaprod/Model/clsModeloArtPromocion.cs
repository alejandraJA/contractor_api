﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class clsModeloArtPromocion
    {
        public int iIdPromocion { get; set; }

        [DisplayName("Articulo")] public string sArticulo { get; set; }

        [DisplayName("Desc. Articulo")] public string sDescripcion { get; set; }

        [DisplayName("Descuento")] public string dPorDec { get; set; }

        [DisplayName("Cantidad A Llevar")] public int iPiezasMaximas { get; set; }

        [DisplayName("Precio Final")] public double dPrecioFinal { get; set; } //calculado

        [DisplayName("Disponible")] public int iDisponible { get; set; }

        [DisplayName("Cantidad")] public int iCantidad { get; set; }

        [DisplayName("Campaña")] public string sNombreCampaña { get; set; }

        public double dPrecio { get; set; }
        public double dPrecio2 { get; set; }
        public string sFamilia { get; set; }
        public string sLinea { get; set; }
        public double dPrecioHijo { get; set; }
        public bool bTipoPromo { get; set; }
        public double dMontoTotal { get; set; }
        public int iMontoIncremental { get; set; }
        public int iTipoPromocion { get; set; }
    }
}