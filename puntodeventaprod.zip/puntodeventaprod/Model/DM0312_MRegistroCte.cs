﻿using System;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MRegistroCte
    {
        public int ID { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Registro { get; set; }
        public DateTime Fecha { get; set; }
        public int Sucursal { get; set; }

        [Browsable(false)] public string Huella { get; set; }

        [Browsable(false)] public bool Valido { get; set; }

        public string Motivo { get; set; }
        public string UsuarioValido { get; set; }
        public DateTime? FechaValido { get; set; }
        public string Recomendado { get; set; }

        [Browsable(false)] public int IdMov { get; set; }

        [Browsable(false)] public string Pregunta1 { get; set; }

        [Browsable(false)] public string Respuesta1 { get; set; }

        [Browsable(false)] public string Pregunta2 { get; set; }

        [Browsable(false)] public string Respuesta2 { get; set; }

        [Browsable(false)] public string Pregunta3 { get; set; }

        [Browsable(false)] public string Respuesta3 { get; set; }

        [Browsable(false)] public string Pregunta4 { get; set; }

        [Browsable(false)] public string Respuesta4 { get; set; }

        [Browsable(false)] public string Pregunta5 { get; set; }

        [Browsable(false)] public string Respuesta5 { get; set; }
    }
}