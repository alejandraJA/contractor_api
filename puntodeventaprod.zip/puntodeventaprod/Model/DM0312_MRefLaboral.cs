﻿namespace PuntoVenta.Model
{
    //Autor: Rodolfo Sanchez
    //Modulo: Investigacion Telefonica
    //Fecha: 30/08/2017
    public class DM0312_MRefLaboral
    {
        public int IDContacto { get; set; }

        public int IDMovimiento { get; set; }

        public string Movimiento { get; set; }

        public string Consecutivo { get; set; }

        public string PuestoLaboral { get; set; }

        public string Departamento { get; set; }

        public string Antiguedad { get; set; }

        public string Domicilio { get; set; }

        public string IngresoMens { get; set; }

        public string Comprobable { get; set; }

        public string Observaciones { get; set; }

        public string DomicilioPer { get; set; }

        public string PlanEmpresa { get; set; }

        public string FormaRecom { get; set; }

        public string NombreInfo { get; set; }

        public string PuestoInfo { get; set; }

        public string Comentarios { get; set; }

        public string Nomina { get; set; }

        public string Fecha { get; set; }

        public string Hora { get; set; }

        public string Cuenta { get; set; }
    }
}