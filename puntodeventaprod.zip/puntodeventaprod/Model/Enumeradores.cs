﻿namespace PuntoVenta.Model
{
    namespace Enumeradores
    {
        public class Enums
        {
            public enum Contactos
            {
                No = 1,
                Si = 2
            }

            public enum DetallesVenta
            {
                Enganche = 0,
                RedMonedero = 1,
                AfectaComisionMavi = 2,
                FacDesgloseIva = 3,
                AgenteServicio = 4,
                Causa = 5,
                ServicioTipo = 6,
                Observaciones = 7,
                Comentarios = 8,
                FormaEnvio = 9,
                NoCtapago = 10,
                Origen = 11,
                OrigenID = 12,
                ReferenciaOrdenCompra = 13,
                Vencimiento = 14,
                OrigenTipo = 15,
                OrigenTipoMov = 16,
                Impuestos = 17,
                Importe = 18,
                UEN = 19,
                DescGlobal = 20,
                SobrePrecio = 21,
                Retencion = 22,
                AnticiposFacturados = 23
            }

            public enum Embarques
            {
                ID = 0,
                Mov = 1,
                MovID = 2,
                Estatus = 3
            }

            public enum Estadocivil
            {
                Divorciado = 0,
                Union_Libre = 1,
                Divorciada = 2,
                Viuda = 3,
                Viudo = 4,
                Casado = 5,
                Casada = 6,
                Soltero = 7,
                Soltera = 8
            }

            public enum EventoNotacita
            {
                Evento = 1,
                Nota = 2,
                Cita = 3
            }

            public enum gvDetallesArticulos
            {
                Articulo = 0,
                Cantidad = 1,
                Precio = 2,
                Importe = 3,
                Costo = 4,
                Series = 5,
                Observaciones = 6,
                CantidadPendiente = 7,
                CantidadAAfectar = 8
            }

            public enum MExploradorPropiedades
            {
                CadenaImporte = 11
            }

            public enum MovCancelacionBanderas
            {
                MovimientoNoSePuedeCancelar = 0,
                MovimientoSiSePuedeCancelar = 1,
                MovimientoFacturaDeOtraSucursal = 2,
                MovimientoYaCancelado = 3,
                MovimientoConNota = 4,
                MovimientoPendiente = 5,
                MovimientoGeneraMovContrario = 6
            }

            public enum Opciones
            {
                Si = 0,
                No = 1
            }

            public enum OpcionesReporteServicios
            {
                AsignaReporte = 1,
                DesasignaReporte = 3
            }

            public enum ParametrosAnticipos
            {
                Mov = 0,
                Usuario = 1,
                Referencia = 2,
                Cliente = 3,
                EnviarA = 4,
                CtaDinero = 5,
                Importe = 6,
                Impuestos = 7,
                MetodoPago1 = 8,
                MetodoPago2 = 9,
                MetodoPago3 = 10,
                MetodoPago4 = 11,
                MetodoPago5 = 12,
                Referencia1 = 13,
                Referencia2 = 14,
                Referencia3 = 15,
                Referencia4 = 16,
                Referencia5 = 17,
                Impuesto1 = 18,
                Impuesto2 = 19,
                Impuesto3 = 20,
                Impuesto4 = 21,
                Impuesto5 = 22,
                Agente = 23,
                Sucursal = 24,
                SucursalOrigen = 25,
                Cajero = 26,
                UEN = 27,
                Estacion = 28
            }

            public enum ParametrosDatosEntrega
            {
                IDCliente = 0,
                Direccion = 1,
                Colonia = 2,
                Poblacion = 3,
                CodigoPostal = 4,
                Estado = 5,
                EntreCalles = 6,
                TelefonoParticular = 7,
                TelefonoMovil = 8,
                Referencia = 9,
                NumExt = 10,
                NumInt = 11
            }

            public enum ParametrosDetallesVenta
            {
                Mov = 0,
                MovID = 1,
                Modulo = 2,
                IDVenta = 3,
                Cliente = 4,
                Estatus = 5,
                EnviarA = 6,
                FechaEmision = 7,
                Sucursal = 8,
                Condicion = 9,
                Categoria = 10,
                ArticuloSeleccionado = 11,
                Almacen = 12,
                UEN = 13,
                OrigenID = 14,
                ReferenciaOrdenCompra = 15,
                Origen = 16,
                ImporteEnAfectar = 17,
                MovTipo = 18,
                FechaVencimiento = 19,
                OrigenTipo = 20,
                SumaImpuesto = 21,
                SumaImporte = 22,
                OrigenTipoMov = 23,
                IDEcommerce = 24,
                Canal = 25,
                Referencia = 26,
                BeneficiarioFinal = 27
            }

            public enum Parentesco
            {
                Padre = 0,
                Madre = 1,
                Hijo = 2,
                Hija = 3,
                Abuelo = 4,
                Abuela = 5,
                Hermano = 6,
                Hermana = 7,
                Tia = 8,
                Tio = 9,
                Sobrino = 10,
                Sorbina = 11,
                Otro = 12,
                Conyuge = 13,
                Nuera = 14,
                Nuero = 15,
                Amistad = 16
            }

            public enum SalidaDiversa
            {
                Condicion = 0
            }

            public enum SerieLoteColumnas
            {
                SerieLote = 0,
                Propiedades = 1
            }

            public enum TipoCalles
            {
                Autopista = 0,
                Autovía = 1,
                Avenida = 2,
                Bulevar = 3,
                Calle = 4,
                Calle_peatonal = 5,
                Callejón = 6,
                Camino = 7,
                Cañada_real = 8,
                Carretera = 9,
                Carretera_circunvalación = 10,
                Carril = 11,
                Ciclovía = 12,
                Corredera = 13,
                Costanilla = 14,
                Parque = 15,
                Pasadizo_elevado = 16,
                Pasaje = 17,
                Paseo_marítimo = 18,
                Plaza = 19,
                Pretil = 20,
                Puente = 21,
                Ronda = 22,
                Sendero = 23,
                Travesía = 24,
                Túnel = 25,
                Vía_pecuaria = 26,
                Vía_rápida = 27,
                Vía_verde = 28,
                Urbanización = 30,
                Andador = 31,
                Boulevard = 32,
                Calzada = 33,
                Privada = 34,
                FERROCARRIL = 35
            }

            public enum TipoTelefono
            {
                MOVIL = 0,
                PARTICULAR = 1,
                FIJO = 2
            }

            public enum Tipovivienda
            {
                Rentada = 0,
                Propia = 1,
                Familiar = 2
            }

            public enum ViveDe
            {
                PROPIETARIO = 1,
                COPROPIETARIO = 2,
                INTESTADO = 3,
                NO_PAGA = 4,
                RENTA = 5,
                HUÉSPED = 6
            }
        }
    }
}