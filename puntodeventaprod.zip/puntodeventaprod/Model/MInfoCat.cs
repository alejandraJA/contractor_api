﻿namespace PuntoVenta.Model
{
    public class MInfoCat
    {
        public string Comisiones { get; set; }
        public string CalculoIntereses { get; set; }
        public string Bonificacion { get; set; }
    }
}