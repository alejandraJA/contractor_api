﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    internal class ArticuloAlmacenes
    {
        [Browsable(false)] public string GrupoAlmacen { get; set; }

        public string Almacen { get; set; }
        public double Disponible { get; set; }
        public double Transito { get; set; }
        public double Total { get; set; }
        public double Minimo { get; set; }
        public double Maximo { get; set; }
    }
}