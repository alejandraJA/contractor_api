﻿namespace PuntoVenta.Model
{
    public class clsModeloPromocion
    {
        public int iIdPromocion { get; set; }
        public string sNombre { get; set; }
        public string sFechaInicio { get; set; }
        public string sFechaFin { get; set; }
        public string sEstatus { get; set; }
        public int iUen { get; set; }
        public int ArticulosPermitidos { get; set; }
    }
}