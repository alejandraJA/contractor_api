﻿namespace PuntoVenta.Model
{
    public class MBeneficiarioFinal
    {
        //Agente
        public string sAgente;
        public string sAtencionEnTienda;
        public bool sCanjeoValeConNIP;
        public string sCuenta;
        public string sDomicilioActual;
        public string sDondeConoceDistribuidor;
        public string sDondeHaraPagos;
        public string sFechaRegistro;
        public int sIdCteCto;
        public int sIdVenta;
        public string sMov;
        public string sMovID;
        public string sNombre;
        public string sNombreAgente;
        public string sObservaciones;
        public string sParaQuienFueLaCompra;
        public string sParentesco;
        public string sProductoOPrestamo;
        public string sProductoOPrestamoMovID;
        public string sQuienTecleoNIPEnTienda;

        public int idCteCto
        {
            get => sIdCteCto;
            set => sIdCteCto = value;
        }

        public int idVenta
        {
            get => sIdVenta;
            set => sIdVenta = value;
        }

        public string mov
        {
            get => sMov;
            set => sMov = value;
        }

        public string movID
        {
            get => sMovID;
            set => sMovID = value;
        }

        public string nombre
        {
            get => sNombre;
            set => sNombre = value;
        }

        public string productoOPrestamo
        {
            get => sProductoOPrestamo;
            set => sProductoOPrestamo = value;
        }

        public string productoOPrestamoMovID
        {
            get => sProductoOPrestamoMovID;
            set => sProductoOPrestamoMovID = value;
        }

        public string parentesco
        {
            get => sParentesco;
            set => sParentesco = value;
        }

        public string dondeConoceDistribuidor
        {
            get => sDondeConoceDistribuidor;
            set => sDondeConoceDistribuidor = value;
        }

        public bool canjeoValeConNIP
        {
            get => sCanjeoValeConNIP;
            set => sCanjeoValeConNIP = value;
        }

        public string quienTecleoNIPEnTienda
        {
            get => sQuienTecleoNIPEnTienda;
            set => sQuienTecleoNIPEnTienda = value;
        }

        public string paraQuienFueLaCompra
        {
            get => sParaQuienFueLaCompra;
            set => sParaQuienFueLaCompra = value;
        }

        public string dondeHaraPagos
        {
            get => sDondeHaraPagos;
            set => sDondeHaraPagos = value;
        }

        public string atencionEnTienda
        {
            get => sAtencionEnTienda;
            set => sAtencionEnTienda = value;
        }

        public string domicilioActual
        {
            get => sDomicilioActual;
            set => sDomicilioActual = value;
        }

        public string observaciones
        {
            get => sObservaciones;
            set => sObservaciones = value;
        }

        public string agente
        {
            get => sAgente;
            set => sAgente = value;
        }

        public string nombreAgente
        {
            get => sNombreAgente;
            set => sNombreAgente = value;
        }

        public string fechaRegistro
        {
            get => sFechaRegistro;
            set => sFechaRegistro = value;
        }

        public string cuenta
        {
            get => sCuenta;
            set => sCuenta = value;
        }
    }
}