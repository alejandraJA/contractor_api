﻿namespace PuntoVenta.Model
{
    public class MArticulosEditar
    {
        public string Codigo { get; set; }
        public int Cantidad { get; set; }
        public string sUsuarioDescuento { get; set; }
        public float fPrecioAnterior { get; set; }
        public float fPrecio { get; set; }
        public int iRenglon { get; set; }
    }
}