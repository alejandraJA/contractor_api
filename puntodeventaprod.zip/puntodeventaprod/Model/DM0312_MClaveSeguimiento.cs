﻿namespace PuntoVenta.Model
{
    public class DM0312_MClaveSeguimiento
    {
        public string Clave { get; set; }
        public string Modulo { get; set; }
        public string Descripcion { get; set; }
        public string Grupo { get; set; }
        public string Situacion { get; set; }
    }
}