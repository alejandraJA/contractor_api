﻿using System;

namespace PuntoVenta.Model
{
    public class Opciones
    {
        public int Id { get; set; }
        public string Valor { get; set; }
    }

    public class ReferenciaCliente
    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public string Telefonos { get; set; }
        public string Atencion { get; set; }
        public string Direccion { get; set; }
        public string Delegacion { get; set; }
        public string Colonia { get; set; }
        public string Estado { get; set; }
        public string Pais { get; set; }
        public string CodigoPostal { get; set; }
        public string Poblacion { get; set; }
        public string TipoCalle { get; set; }
        public string NumExterior { get; set; }
        public string NumInterior { get; set; }
    }

    public class EmpresaCliente
    {
        public int ID { get; set; }
        public string Empresa { get; set; }
        public string Funciones { get; set; }
        public int AniosAntiguedad { get; set; }
        public int MesAntiguedad { get; set; }
        public string JefeInmediato { get; set; }
        public string PuestoJefeInmediato { get; set; }
        public string Ingresos { get; set; }
        public string Departamento { get; set; }
        public string TipoEmpleo { get; set; }
        public string TipoCalle { get; set; }
    }

    public class CTETelLLamada
    {
        public int IDCTETelLLamada { get; set; }
        public int? Tipo { get; set; }
        public string Cliente { get; set; }
    }
}