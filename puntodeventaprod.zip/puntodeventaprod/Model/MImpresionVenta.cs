﻿namespace PuntoVenta.Model
{
    public class MImpresionVenta
    {
        public string Articulo { get; set; }
        public string Opcion { get; set; }
        public string Descripcion { get; set; }
        public string Almacen { get; set; }
        public string Cantidad { get; set; }
        public string Precio { get; set; }
        public string Desc { get; set; }
        public string Importe { get; set; }
    }
}