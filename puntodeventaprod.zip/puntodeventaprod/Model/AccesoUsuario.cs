﻿namespace PuntoVenta.Model
{
    internal class AccesoUsuario
    {
        public string nombreForma { get; set; }
        public string campo { get; set; }
    }
}