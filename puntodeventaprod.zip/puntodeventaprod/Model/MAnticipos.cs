﻿namespace PuntoVenta.Model
{
    public class MAnticipos
    {
        public string FormaPago { get; set; }
        public string Referencia { get; set; }
        public string Importe { get; set; }
    }
}