﻿namespace PuntoVenta.Model
{
    public class DM0312_MPuntoDeVentaCliente
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string eMail { get; set; }
    }
}