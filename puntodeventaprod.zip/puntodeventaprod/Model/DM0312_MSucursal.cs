﻿namespace PuntoVenta.Model
{
    public class DM0312_MSucursal
    {
        public int Sucursal { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string DireccionNumero { get; set; }
        public string DireccionNumeroInt { get; set; }
        public string Delegacion { get; set; }
        public string Colonia { get; set; }
        public string Poblacion { get; set; }
        public string Estado { get; set; }
        public string CodigoPostal { get; set; }
        public string Pais { get; set; }
        public string Grupo { get; set; }
    }
}