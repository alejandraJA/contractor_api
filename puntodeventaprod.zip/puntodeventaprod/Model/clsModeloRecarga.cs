﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    //-Datalogic
    public class clsModeloRecarga
    {
        [DisplayName("Codigo")] public string sCodigo { get; set; }

        [DisplayName("Codigo Intelisis")] public string sCodigoIntelisis { get; set; }

        [DisplayName("Nombre")] public string sNombre { get; set; }

        [DisplayName("Tipo")] public string sTIpo { get; set; }

        [DisplayName("Proveedor")] public string sProv { get; set; }

        [DisplayName("Monto")] public int sMonto { get; set; }

        [DisplayName("Acreedor")] public string sAcreedor { get; set; }
    }
}