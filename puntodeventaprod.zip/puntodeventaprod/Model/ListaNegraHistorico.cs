﻿namespace PuntoVenta.Model
{
    public class ListaNegraHistorico
    {
        public int idVenta { get; set; }
        public string usuario { get; set; }
        public string calificacion { get; set; }
        public string observaciones { get; set; }
        public string origen { get; set; }
    }
}