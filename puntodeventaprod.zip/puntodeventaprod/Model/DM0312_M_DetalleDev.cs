﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_M_DetalleDev
    {
        public string Articulo { get; set; }

        public string Cantidad { get; set; }

        [DisplayName("Precio Unitario")] public string PrecioUnitario { get; set; }

        [DisplayName("Importe")] public string Importe { get; set; }

        public string Serie { get; set; }

        [DisplayName("Cant. Devolver")] public int CantidadDevolver { get; set; }

        //[Browsable(false)]
        public string Descripcion { get; set; }

        //[Browsable(false)]  
        public string Unidad { get; set; }

        [Browsable(false)] public string Tipo { get; set; }

        [Browsable(false)] public int renglon { get; set; }

        [Browsable(false)] public int bandera { get; set; }

        //-CorreccionPropiedadesDevolucion
        [Browsable(false)] public string Cuadro { get; set; }
    }
}