﻿using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class TableroDetalleVenta
    {
        public string Articulo { get; set; }
        public string Cantidad { get; set; }

        [DisplayName("Precio unitario")] public string Precio { get; set; }

        public string Importe { get; set; }

        [Browsable(false)] public bool EsPaquete { get; set; }

        [Browsable(false)] public bool EsComponentePaquete { get; set; }
    }
}