﻿namespace PuntoVenta.Model
{
    public class MLimiteCredito
    {
        public int idLimiteCredito { get; set; }
        public string Mov { get; set; }
        public string TipoDima { get; set; }
        public int PorLimFactDima { get; set; }
        public float LimiteCredito { get; set; }
        public string Clasificacion { get; set; }
    }
}