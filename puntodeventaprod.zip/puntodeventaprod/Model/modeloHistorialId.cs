﻿//-ReporteDima

namespace PuntoVenta.Model
{
    public class modeloHistorialId
    {
        public string sMov { get; set; }
        public string sMovId { get; set; }
        public string sEstatus { get; set; }
    }
}