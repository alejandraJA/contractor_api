﻿using System;

namespace PuntoVenta.Model
{
    public class DM0312_MCte
    {
        public string Cliente { get; set; }

        public string Nombre { get; set; }

        public string Direccion { get; set; }

        public DateTime? FechaNac { get; set; }

        public string Colonia { get; set; }
    }
}