﻿using System.Collections.Generic;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MVentaDetalle
    {
        public string Articulo { get; set; }

        [Browsable(false)] public string Descripcion { get; set; }

        [Browsable(false)] public int RenglonID { get; set; }

        [Browsable(false)] public int Renglon { get; set; }

        [Browsable(false)] public double impuesto { get; set; }

        [Browsable(false)] public double impuesto2 { get; set; }

        [Browsable(false)] public double impuesto3 { get; set; }

        [Browsable(false)] public string Unidad { get; set; }

        public int Cantidad { get; set; }

        [Browsable(false)] public double Precio { get; set; }

        [DisplayName("Precio")] public string PrecioS { get; set; }

        [Browsable(false)] public double Total { get; set; }

        [DisplayName("Total")] public string TotalS { get; set; }

        [Browsable(false)] public double Costo { get; set; }

        [DisplayName("Costo")] public string Costo_ { get; set; }

        [Browsable(false)] public string Articulo_Ligado { get; set; }

        [Browsable(false)] public double SubTotal { get; set; }

        public int Disponible { get; set; }

        public string Serie { get; set; }

        [Browsable(false)] public int CantDevolver { get; set; }

        public string Observaciones { get; set; }

        [Browsable(false)] public string Condicion { get; set; }

        [Browsable(false)] public string CanalClave { get; set; }

        [Browsable(false)] public string CanalNombre { get; set; }

        [Browsable(false)] public string Embarque { get; set; }

        [Browsable(false)] public string EmbarqueFecha { get; set; }

        [Browsable(false)] public string Linea { get; set; }

        [Browsable(false)] public string Tipo { get; set; }


        [Browsable(false)] public int? PropreListaID { get; set; }


        public string Juego { get; set; }

        [Browsable(false)] public string Paquete { get; set; }


        [Browsable(false)] public string Almacen { get; set; }

        [Browsable(false)] public int RenglonAnterior { get; set; }

        [Browsable(false)] public string TipoUsrDes_Incr { get; set; }

        //-Datalogic
        [DisplayName("Proveedor")] public string proveedor { get; set; }

        //-ModuloPromociones
        //Variable para saber si el articulo es de promocion
        [Browsable(false)] public bool bArtPromocion { get; set; } = false;

        //Variable para saber el id de la configuración de la promoción.
        [Browsable(false)] public int idPromocion { get; set; } = 0;

        [Browsable(false)] public int iIdTipoPromocion { get; set; }

        public List<clsModeloTipoPromocion> listaPadres { get; set; }

        [Browsable(false)] public double dMontoMonedero { get; set; }

        [DisplayName("Monedero")] public string sMontoMonedero { get; set; }

        //1832
        [Browsable(false)] public bool? ArticuloPequeno { get; set; } = null;

        [Browsable(false)] public int CantidadEscaneado { get; set; } = 0;

        public string Propiedades { get; set; }
        public bool? Tienepromo { get; set; } = null;

        // Se agrega precioanterior y usuariodescuento //
        //public double PrecioAnterior { get; set; }
        //public string UsuarioDescuento { get; set; }
        /////////////////////////////////////////////////
    }
}