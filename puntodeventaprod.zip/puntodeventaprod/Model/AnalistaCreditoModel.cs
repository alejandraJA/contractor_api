﻿namespace PuntoVenta.Model
{
    public class AnalistaCreditoModel
    {
        public string analista;
        public string nombre;
        public string usuario;
    }
}