﻿using System;
using System.ComponentModel;

namespace PuntoVenta.Model
{
    public class DM0312_MHistorialSolicitudes
    {
        public string agente;
        public string calificacion;
        public string canalVenta;
        public string condicion;
        public string cuenta;
        public string estatus;
        public DateTime fechaAlta;
        public string fechaUltimaMod;

        public int id;
        public string idMovimiento;
        public string importeTotal;
        public string mov;
        public string movimiento;
        public string nombreCliente;
        public string situacion;
        public string suc;
        public double totalizador;
        public string usuario;

        [Browsable(false)]
        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Movimiento
        {
            get => movimiento;
            set => movimiento = value;
        }

        [Browsable(false)]
        public string IdMovimiento
        {
            get => idMovimiento;
            set => idMovimiento = value;
        }

        [DisplayName("Canal Venta")]
        public string CanalVenta
        {
            get => canalVenta;
            set => canalVenta = value;
        }

        public string Suc
        {
            get => suc;
            set => suc = value;
        }

        public string Cuenta
        {
            get => cuenta;
            set => cuenta = value;
        }

        public string Situacion
        {
            get => situacion;
            set => situacion = value;
        }

        public string Agente
        {
            get => agente;
            set => agente = value;
        }

        [DisplayName("Nombre cliente")]
        public string NombreCliente
        {
            get => nombreCliente;
            set => nombreCliente = value;
        }

        public string Estatus
        {
            get => estatus;
            set => estatus = value;
        }

        [DisplayName("Fecha alta")]
        public DateTime FechaAlta
        {
            get => fechaAlta;
            set => fechaAlta = value;
        }

        [DisplayName("Importe Total")]
        public string ImporteTotal
        {
            get => importeTotal;
            set => importeTotal = value;
        }

        [Browsable(false)]
        public double Totalizador
        {
            get => totalizador;
            set => totalizador = value;
        }


        public string Calificacion
        {
            get => calificacion;
            set => calificacion = value;
        }

        [DisplayName("Fecha ultima modificacion")]
        public string FechaUltimaMod
        {
            get => fechaUltimaMod;
            set => fechaUltimaMod = value;
        }

        public string Condicion
        {
            get => condicion;
            set => condicion = value;
        }

        public string Usuario
        {
            get => usuario;
            set => usuario = value;
        }

        [Browsable(false)]
        public string Mov
        {
            get => mov;
            set => mov = value;
        }
    }
}