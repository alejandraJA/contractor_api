﻿namespace PuntoVenta.Model
{
    public class Usuario
    {
        public string color;
        public string grupo;
        public string grupoEmpresa;
        public int sucursal;
        public string usuario;
        public string nombre { get; set; }
        public int Uen { get; set; }
        public string Acceso { get; set; }

        public string Nombre
        {
            get => nombre;
            set => nombre = value;
        }

        public string Usser
        {
            get => usuario;
            set => usuario = value;
        }

        public int Sucursal
        {
            get => sucursal;
            set => sucursal = value;
        }

        public string GrupoEmpresa
        {
            get => grupoEmpresa;
            set => grupoEmpresa = value;
        }

        public string Grupo
        {
            get => grupo;
            set => grupo = value;
        }

        //-Datalogic
        public string sRefCtaDinero { get; set; }
        public string sRefCtaCajero { get; set; }
    }
}