﻿namespace PuntoVenta.Model
{
    internal class MDetalleEnganchePendientes
    {
        public string Referencia { get; set; }
        public string Saldo { get; set; }
        public string Fecha { get; set; }
    }
}