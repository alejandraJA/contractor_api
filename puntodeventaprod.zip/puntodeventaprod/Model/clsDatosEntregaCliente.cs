﻿namespace PuntoVenta.Model
{
    public class clsDatosEntregaCliente
    {
        public string sDireccion { get; set; }
        public string sNumeroExt { get; set; }
        public string sNumeroInt { get; set; }
        public string sColonia { get; set; }
        public string sCodigoPostal { get; set; }
        public string sPoblacion { get; set; }
        public string sEstado { get; set; }
        public string sEntreCalles { get; set; }
        public string sNombreC { get; set; }
        public string sCorreo { get; set; }
    }
}