﻿namespace PuntoVenta.Model
{
    public class MaviRM0855AHojaVerde
    {
        public string FechaHoy { get; set; }

        public double Importe { get; set; }

        public string C_clienteCod { get; set; }

        /*Datos Generales*/
        public string C_clienteNom { get; set; }

        public string C_edad { get; set; }

        public string C_FechaNacimiento { get; set; }

        public string C_Domicilio { get; set; }

        public string C_Antiguedad { get; set; }

        public string C_Cruces { get; set; }

        public string C_Colonia { get; set; }

        public string C_cp { get; set; }

        public string C_Telefono1 { get; set; }

        public string C_Telefono2 { get; set; }

        public string C_Municipio { get; set; }

        public string C_DomAnterior { get; set; }

        public string C_Colonia2 { get; set; }

        public string C_cp2 { get; set; }

        public string C_Vivede { get; set; }

        public string C_Recomendado { get; set; }

        public string C_DireccionRecom { get; set; }

        public string C_Parentezco { get; set; }

        public string C_Observaciones { get; set; }

        public string C_EdoCivil { get; set; }

        public string Conyuge { get; set; }

        public string Con_edad { get; set; }

        public string Con_FechaNacimiento { get; set; }

        /*empleo cliente*/
        public string EC_empresa { get; set; }

        public string EC_Funciones { get; set; }

        public string EC_Departamento { get; set; }

        public string EC_JefeIn { get; set; }

        public string EC_PuestoJefe { get; set; }

        public string EC_Antig { get; set; }

        public string EC_Ingresos { get; set; }

        public string EC_PeriodoIng { get; set; }

        public string EC_Domicilio { get; set; }

        public string EC_Colonia { get; set; }

        public string EC_Cruces { get; set; }

        public string EC_Tel { get; set; }

        public string EC_Municipio { get; set; }

        public string EC_TrabjAnterior { get; set; }

        public string EC_Colonia2 { get; set; }

        public string EC_Municipio2 { get; set; }

        /*empleo conyuge*/
        public string ECon_Empresa { get; set; }

        public string ECon_Funciones { get; set; }

        public string ECon_Departamento { get; set; }

        public string ECon_JefeIn { get; set; }

        public string ECon_PuestoJefe { get; set; }

        public string ECon_Antig { get; set; }

        public string ECon_Ingresos { get; set; }

        public string ECon_PeriodoIng { get; set; }

        public string ECon_Domicilio { get; set; }

        public string ECon_Colonia { get; set; }

        public string ECon_Cruces { get; set; }

        public string ECon_Tel { get; set; }

        public string ECon_Municipio { get; set; }

        public string ECon_TrabjAnterior { get; set; }

        public string ECon_Colonia2 { get; set; }

        public string ECon_Municipio2 { get; set; }

        /*Referencias Personales*/
        //1
        public string Ref_Nombre { get; set; }

        public string Ref_Parentezco { get; set; }

        public string Ref_Telefono { get; set; }

        public string Ref_Domi { get; set; }

        public string Ref_Col { get; set; }

        public string Ref_Municipio { get; set; }

        public bool Ref_escliente { get; set; }

        public string Ref_Cuenta { get; set; }

        //2
        public string Ref2_Nombre { get; set; }

        public string Ref2_Parentezco { get; set; }

        public string Ref2_Telefono { get; set; }

        public string Ref2_Domi { get; set; }

        public string Ref2_Col { get; set; }

        public string Ref2_Municipio { get; set; }

        public bool Ref2_escliente { get; set; }

        public string Ref2_Cuenta { get; set; }

        /*Referencias Comerciales*/
        public string ReferenciaComercial_ { get; set; }

        public string ReferenciaComercial_1 { get; set; }

        public string ReferenciaComercial_2 { get; set; }

        /*Referencias Bancarias*/
        public string RefBan_Tarjeta_ { get; set; }

        public string RefBan_EmisorTarjeta_ { get; set; }

        public string RefBan_Tarjeta_1 { get; set; }

        public string RefBan_EmisorTarjeta_1 { get; set; }


        /*Datos Generales Aval*/
        public string A_Parentezco { get; set; }

        public string A_Vivede { get; set; }

        public string A_Nom { get; set; }

        public string A_edad { get; set; }

        public string A_FechaNacimiento { get; set; }

        public string A_Conyuge { get; set; }

        public string ACon_edad { get; set; }

        public string ACon_FechaNacimiento { get; set; }

        public string A_Domicilio { get; set; }

        public string A_Antiguedad { get; set; }

        public string A_Cruces { get; set; }

        public string A_Colonia { get; set; }

        public string A_cp { get; set; }

        public string A_Telefono { get; set; }

        public string A_Municipio { get; set; }

        public string A_DomAnterior { get; set; }

        public string A_Colonia2 { get; set; }

        public string A_Municipio2 { get; set; }

        public string A_EdoCivil { get; set; }


        /*empleo AVAL*/
        public string EA_empresa { get; set; }

        public string EA_Funciones { get; set; }

        public string EA_Departamento { get; set; }

        public string EA_JefeIn { get; set; }

        public string EA_PuestoJefe { get; set; }

        public string EA_Antig { get; set; }

        public string EA_Ingresos { get; set; }

        public string EA_PeriodoIng { get; set; }

        public string EA_Domicilio { get; set; }

        public string EA_Colonia { get; set; }

        public string EA_CP { get; set; }

        public string EA_Cruces { get; set; }

        public string EA_Tel { get; set; }

        public string EA_Municipio { get; set; }

        public string EA_TrabjAnterior { get; set; }

        public string EA_Colonia2 { get; set; }

        public string EA_Municipio2 { get; set; }

        /*empleo conyuge DEL AVAL*/
        public string EACon_Empresa { get; set; }

        public string EACon_Funciones { get; set; }

        public string EACon_Departamento { get; set; }

        public string EACon_JefeIn { get; set; }

        public string EACon_PuestoJefe { get; set; }

        public string EACon_Antig { get; set; }

        public string EACon_Ingresos { get; set; }

        public string EACon_PeriodoIng { get; set; }

        public string EACon_Domicilio { get; set; }

        public string EACon_Colonia { get; set; }

        public string EACon_CP { get; set; }

        public string EACon_Cruces { get; set; }

        public string EACon_Tel { get; set; }

        public string EACon_Municipio { get; set; }

        public string EACon_TrabjAnterior { get; set; }

        public string EACon_Colonia2 { get; set; }

        public string EACon_Municipio2 { get; set; }


        /*Referencias Comerciales AVAL*/
        public string AReferenciaComercial_ { get; set; }

        public string AReferenciaComercial_1 { get; set; }

        public string AReferenciaComercial_2 { get; set; }

        /*Referencias Bancarias AVAL*/
        public string ARefBan_Tarjeta_ { get; set; }

        public string ARefBan_Tarjeta_1 { get; set; }


        public string Observaciones { get; set; }
    }
}