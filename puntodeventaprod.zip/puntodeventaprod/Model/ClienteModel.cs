﻿using System;

namespace PuntoVenta.Model
{
    public class ClienteModel
    {
        public string ActividadEconomicaCNBV;
        public string Agente;
        public string Agente3;
        public string Agente4;

        public string AgenteServicio;

        //public int NumeroHijos
        public string Alergias;

        //DescuentoRecargos bit default 0,
        //RecorrerVencimiento varchar(20) default 'No',
        public string AlmacenDef;

        //VtasConsignacion bit default 0 not null,
        public string AlmacenVtasConsignacion;

        public DateTime Alta;

        //ImporteRentaMavi money, public string ViveEnCalidad;
        public int AntiguedadNegocioMavi;

        //public int FacturarCteEnviarA
        public string Aseguradora;
        public string Banco;
        public bool Bandera1;
        public bool Bandera2;
        private bool BonoBienvenida;
        public bool CalculoMoratorioMAVI;
        public string Canal;
        public string Categoria;
        public bool CFD_Enviar;
        public string ClabeCuenta;
        public string Clase;
        public int ClaveBanco;
        public string ClaveECE;

        public string Cliente;

        //TieneMovimientos bit default 0,
        public string Cobrador;
        public string CodigoPostal;
        public string Colonia;
        public string Condicion;

        public bool constraint;

        //PedirTono bit default 0 not null,
        public string Contacto1;
        public string Contacto2;
        public string Contrasena;
        public string Contrasena2;
        public string Conyuge;
        public string Credito;

        //CreditoConDias bit default 0 not null,
        //public int CreditoDias;
        //CreditoConCondiciones bit default 0 not null,
        public string CreditoCondiciones;
        //wVerDisponible bit default 0,
        //wVerArtListaPreciosEsp bit default 0,
        //ChecarCredito varchar(20) default '(Empresa)',
        //BloquearMorosos varchar(20) default '(Empresa)',
        //ModificarVencimiento varchar(10) default '(Empresa)',
        //CreditoEspecial bit default 0 not null,
        //CreditoConLimite bit default 0 not null,
        //CreditoLimite money, CreditoConLimitePedidos bit default 0,
        //CreditoLimitePedidos money, 

        public string CreditoMoneda;

        //CRMCierreProbabilidad float,
        public DateTime CRMCierreFechaAprox;

        //CRMPresupuestoAsignado money,
        public string CRMCompetencia;

        //ExcentoISAN bit default 0,
        //CRMImporte money, CRMCantidad float,
        public string CRMEtapa;
        public string CRMFuente;
        public string CRMID;
        public string CRMInfluencia;
        public string CtaBanco;
        public string Cuenta;
        public string CuentaRetencion;

        public string CURP;

        //PolizaImporte money, Deducible money,
        public string DeducibleMoneda;
        public string DefMoneda;
        public string DefPosicionRecibo;
        public string DefPosicionSurtido;
        public string Delegacion;
        public bool Desconocido;
        public string Descripcion1;
        public string Descripcion10;
        public string Descripcion11;
        public string Descripcion12;
        public string Descripcion13;
        public string Descripcion14;
        public string Descripcion15;
        public string Descripcion16;
        public string Descripcion17;
        public string Descripcion18;
        public string Descripcion19;
        public string Descripcion2;
        public string Descripcion20;
        public string Descripcion3;
        public string Descripcion4;
        public string Descripcion5;
        public string Descripcion6;
        public string Descripcion7;
        public string Descripcion8;
        public string Descripcion9;
        public string Descuento;
        public string DiaPago1;
        public string DiaPago2;
        public string DiaRevision1;
        public string DiaRevision2;
        public string Direccion;
        public string DireccionNumero;
        public string DireccionNumeroInt;
        public string DireccionRecomiendaMavi;
        public string DirInternet;
        public string EDICalificador;
        public string EDIIdentificador;
        public string eMail;
        public string eMail1;
        public string eMail2;
        public bool Embarazo;
        public string EntreCalles;
        public int EnviarA;
        public bool EnviarCobTelMavi;
        public bool esAutCredEspecial;
        public bool EsCredExpress;

        public bool EsFavorito;

        //Coaseguro float,
        public string Espacio;
        public string Estado;
        public string EstadoCivil;
        public string ExpedienteFamiliar;
        public string Extencion1;
        public string Extencion2;
        public string FacturarCte;
        public string Familia;
        public string Fax;
        public DateTime Fecha1;
        public DateTime Fecha2;
        public DateTime Fecha3;
        public DateTime Fecha4;

        public DateTime Fecha5;

        //CRMObjectId uniqueidentifier, public string Ubicacion;
        //SerieMonederoVIU varchar(20) exec sp_addextendedproperty 'SerieMonederoVIU', 'Monedero virtual para UEN 2',
        //'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN', 'SerieMonederoVIU',
        //CreditoEmpresario bit constraint DF_Cte_CreditoEmpresario default 0 not null
        //exec sp_addextendedproperty 'CreditoEmpresario',
        //'Indica si el cliente cuenta con crédito para CREDILANA EMPRESARIO', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'CreditoEmpresario',
        //LimiteEmpresario money exec sp_addextendedproperty 'LimiteEmpresario',
        //'Indica el limite de crédito para CREDILANA EMPRESARIO', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'LimiteEmpresario',
        //LCAXSIEMP money exec sp_addextendedproperty 'LCAXSIEMP',
        //'Indica el limite de crédito de sistema para CREDILANA EMPRESARIO', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'LCAXSIEMP',
        //Ingresos money exec sp_addextendedproperty 'Ingresos', 'Campo donde se guardara los ingresos del Cliente',
        //'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN', 'Ingresos',
        //Licencia varchar(50) exec sp_addextendedproperty 'Licencia',
        //'Campo donde se guardara la Licencia del negocio del Cliente', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'Licencia',
        //Giro varchar(100) exec sp_addextendedproperty 'Giro', 'Campo donde se guardara el Giro del negocio del Cliente',
        //'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN', 'Giro',
        //UsoCFDI varchar(3) constraint DF_Cte_UsoCFDI default 'G03' not null
        //exec sp_addextendedproperty 'UsoCFDI', 'Columna saber el CFDI para el cliente', 'SCHEMA', 'dbo', 'TABLE', 'Cte',
        //'COLUMN', 'UsoCFDI',
        //NIPVenta varchar(50) exec sp_addextendedproperty 'NIPVenta',
        //'Campo donde se guardara la clave de Venta del Cliete', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN', 'NIPVenta',
        //NIPCobro varchar(50) exec sp_addextendedproperty 'NIPCobro',
        //'Campo donde se guardara guardara la clave de Cobro del Cliete', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'NIPCobro',
        //CreditoDineralia bit constraint DF_Cte_CreditoDineralia default 0 not null
        //exec sp_addextendedproperty 'CreditoDineralia',
        //'Indica si el cliente cuenta con crédito para Credilana Dineralia', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'CreditoDineralia',
        //LimiteDineralia money exec sp_addextendedproperty 'LimiteDineralia',
        //'Indica el limite de crédito para Credilana Dineralia', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'LimiteDineralia',
        //BloqueoDineralia;
        public DateTime FechaBloqDineralia;
        public DateTime FechaMatrimonio;
        public DateTime? FechaNacimiento;
        public DateTime FechaUltimoCobro;
        public DateTime FechaUltimoCobroAux;

        public string FiscalRegimen;

        //FiscalGenerar bit default 1,
        public string FiscalZona;
        public string FolioActivo;

        public DateTime FolioActivoFecha;

        //Flotilla bit default 0,
        public string FordDistribuidor;
        public string FordZona;
        public string FormaEnvio;
        public string GLN;
        public string Grado;
        public string Grupo;
        public string GrupoSanguineo;
        public string GrupoSanguineoRH;
        public string HorarioPago;
        public string HorarioRevision;
        public string IDAVAL;
        public string IdCatalogoTarjetas;
        public string Idioma;
        public int IDMagento;
        public string IEPS;

        public string IFE;

        //PedidoDef bit default 0,
        //eMailAuto bit default 0,
        //public string wMovVentas;
        //Intercompania bit default 0,
        //Publico bit default 0,
        //CRMovVenta varchar(20) default '(Empresa)',
        //Extranjero bit default 0,
        //DocumentacionCompleta bit default 0,
        //OperacionLimite money, public string ImportadorRegimen;
        public string ImportadorRegistro;
        public string IngresoTipo;
        public string InterfacturaRI;
        public bool Irregularidad;
        public string Latitud;
        private float LCAXSI;
        public int Licencias;
        public string LicenciasLlave;
        public string LicenciasTipo;

        public float LimiteCredito;

        //ListaPrecios int default 1,
        public string ListaPreciosEsp;
        public string LocalidadCNBV;

        public string Longitud;

        //MapaLatitud float,
        //MapaLongitud float,
        public int MapaPrecision;

        //TarimasChep bit default 0,
        //MFATipoOperacion varchar(50) default 'otros' not null,
        public string MapaUbicacion;
        public string MaviEstatus;

        public string MaviRecomendadoPor;

        //Conciliar bit default 0 not null,
        public string Mensaje;
        public string MotivoDesbloqDineralia;
        public string MotivoMavi;
        public string MotivoMAVIPublicidad;
        public string MovimientoUltimoCobro;
        public string MovimientoUltimoCobroAux;
        public string Nacionalidad;
        public bool NegativaBC;

        public string NivelAcceso;

        //CalificacionGlobal float,
        public string NivelCobranzaEspecialMAVI;
        public string NivelEspecialContacto;
        public string Nombre;
        public string NombreAsegurado;
        public string NombreComercial;
        public string NombreCorto;
        public string NoriticarATelefonos;
        public string NotificarA;
        public int Numero;
        public string NumeroTarjetaDineralia;
        public string Observaciones;
        public string Origen;
        public string OtrosCargos;
        public bool PacienteExterno;
        public string PaginaWeb;
        public string Pais;
        public string Parentesco;
        public string ParentescoRecomiendaMavi;
        public string Pasaporte;

        public string PersonalApellidoMaterno;

        //FormasPagoRestringidas bit default 0,
        //PreciosInferioresMinimo bit default 0,
        //public string CBDir;
        //PersonalNombres varchar(100) exec sp_addextendedproperty 'PersonalNombres ',
        //'Campo encargado de guardar el nombre del cliente sin apellidos', 'SCHEMA', 'dbo', 'TABLE', 'Cte', 'COLUMN',
        //'PersonalNombres',
        public string PersonalApellidoPaterno;
        public bool PersonalBuscaResp;
        public string PersonalCobrador;
        public string PersonalCodigoPostal;
        public string PersonalColonia;
        public string PersonalCveTipoAsentamiento;
        public string PersonalCveTipoVialidad;
        public string PersonalDelegacion;
        public string PersonalDireccion;
        public string PersonalEntreCalles;
        public string PersonalEstado;
        public string PersonalEstadoCve;
        public string PersonalEstadoNacimiento;
        public string PersonalEstadoNacimientoCve;
        public string PersonalLocalidadCve;
        public string PersonalMunicipioCve;

        public string PersonalNacionalidad;

        //public string text; 
        public string PersonalNacionalidadCve;
        public string PersonalNumExt;
        public string PersonalNumInt;
        public string PersonalPais;
        public string PersonalPlano;
        public string PersonalPoblacion;
        public string PersonalTelefonoMovil;
        public string PersonalTelefonos;
        public string PersonalTelefonosLada;
        public string PersonalTipoAsentamiento;
        public string PersonalTipoVialidad;
        public string PersonalVialidad;
        public string PersonalZona;
        public string PITEX;
        public string Plano;
        public string Poblacion;
        public string PolizaNumero;
        public string PolizaReferencia;

        public string PolizaTipo;

        //Peso float,
        //Estatura float,
        //Comentarios text, public DateTime PolizaFechaEmision;
        public DateTime PolizaVencimiento;

        //SincronizarCRM bit default 0,
        public string PrimaryContactId;

        //Fuma bit default 0,
        public string Profesion;
        public bool ProspectoACteMAVI;
        public string ProveedorClave;
        public string ProveedorInfo;
        public string Proyecto;
        public bool PublicidadMAVI;
        public string Puesto;
        public string Rama;
        public bool ReestructuraDeuda;

        public string ReferenciaBancaria;

        //ContactoTipo varchar(20) default 'Cliente',
        public string ReferenciaIntelisisService;
        public string ReferidoMail;
        public string ReferidoNombre;
        public string ReferidoRFC;
        public string ReferidoTelefono;
        public string RelacionReferencia;
        public string Religion;
        public string Responsable;
        public bool RetiroApoyoCobranza;
        public string RFC;
        public string RPU;
        public string Ruta;
        public int RutaOrden;
        public bool SeEnviaBuroCreditoMavi;
        public string SerieMonedero;
        public string Sexo;
        public string SIC;
        public bool SiPorcFactDIMA;

        public string SIRAC;

        //PedidosParciales bit default 1 not null,
        //Tipo varchar(15) default 'Cliente',
        public string Situacion;
        public DateTime SituacionFecha;
        public string SituacionNota;

        public string SituacionUsuario;

        //IngresoMensualCredWeb money, 
        //esDimaElite bit,
        //LimiteCredDimaElite money,
        public bool SmsEnviados;
        public int SucursalEmpresa;
        public string Tarjeta;
        public string Telefonos;
        public string TelefonosLada;

        public string TemaCRM;

        //SincroID timestamp null,
        //SincroC int default 1,
        public string TipoCalle;

        public int TipoCredito;

        //LineaCredMayoreo money ,
        //LCAXSIMayoreo money ,
        //CPAXAMayoreo money,
        public string TipoCuentaMayoreo;

        public string TipoDIMA;

        //FueraLinea bit default 0,
        public string TipoRegistro;

        //PersonalSMS bit default 0,
        //FechaNacimiento datetime not null
        //constraint CH_Cte_FechaNacimiento
        //check([FechaNacimiento]<>''),
        public string Titulo;

        //Estatus varchar(15) not null,
        public DateTime UltimoCambio;

        //EsProveedor bit default 0,
        //EsPersonal bit default 0,
        //EsAgente bit default 0,
        //EsAlmacen bit default 0,
        //EsEspacio bit default 0,
        //EsCentroCostos bit default 0,
        //EsProyecto bit default 0,
        //EsCentroTrabajo bit default 0,
        //EsEstacionTrabajo bit default 0,
        public string Usuario;

        public bool vic_NoValidarContrato;

        //BonificacionTipo varchar(20) default 'No',
        //Bonificacion float,
        public DateTime VigenciaDesde;
        public DateTime VigenciaHasta;
        public string Zona;
        public string ZonaImpuesto;
    }
}