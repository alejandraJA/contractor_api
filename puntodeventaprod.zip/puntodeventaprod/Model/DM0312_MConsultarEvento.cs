﻿using System;

namespace PuntoVenta.Model
{
    public class DM0312_MConsultarEvento
    {
        public DateTime Fecha { get; set; }
        public string Clave { get; set; }
        public string Evento { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string DisplayName { get; set; }
    }
}