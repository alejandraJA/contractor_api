﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_CartaFac : Form
    {
        private readonly List<MCartaFactura> list = new List<MCartaFactura>();

        public DM0312_CartaFac()
        {
        }

        public DM0312_CartaFac(List<MCartaFactura> misdatos)
        {
            InitializeComponent();
            list = misdatos;
        }

        private void DM0312_CartaFac_Load(object sender, EventArgs e)
        {
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", list));
            reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Funciones reportePosicionMov = new Funciones();
            //    reportePosicionMov.FillMovPosicion(movId);
        }
    }
}