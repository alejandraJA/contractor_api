﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Properties;

namespace PuntoVenta.Reports
{
    //Autor:Rodolfo Sanchez
    //Modulo: Reporte de Cliente Express
    //Fecha:14/09/2017

    public partial class DM0312_RM0855A_ClienteExpress : Form
    {
        private bool CancelClosed;

        private readonly MaviRM0855AHojaVerdeController cnn;

        private readonly List<MaviRM0855AHojaVerde> Lista;

        private MaviRM0855AHojaVerde model;

        public DM0312_RM0855A_ClienteExpress()
        {
            InitializeComponent();
            model = new MaviRM0855AHojaVerde();
            Lista = new List<MaviRM0855AHojaVerde>();
            cnn = new MaviRM0855AHojaVerdeController();
        }

        public string CodCliente { get; set; }

        public int iCanal { get; set; }

        //load asincrono
        private async void DM0312_RM0855A_ClienteExpress_Load(object sender, EventArgs e)
        {
            if (iCanal == 78 || iCanal == 79)
                rv_RM0855A.LocalReport.ReportEmbeddedResource =
                    "PuntoVenta.Reports.DM0312_RM0855A_ClienteExpress_Empresario.rdlc";

            ClaseEstatica.ListClientes.Add(CodCliente);

            PdfImagen();

            CenterTheBox();

            //empieza la tarea y espera a terminar este proceso
            await Task.Run(() => GetObjectReport());

            if (model == null)
            {
                MessageBox.Show("El cliente:" + CodCliente + " no tiene información", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClaseEstatica.ListClientes.Remove(CodCliente);

                Close();

                return;
            }


            rv_RM0855A.RefreshReport();

            rv_RM0855A.SetDisplayMode(DisplayMode.PrintLayout);

            rv_RM0855A.ZoomMode = ZoomMode.Percent;

            rv_RM0855A.ZoomPercent = 150;

            PC_Loading.Visible = false;
            rv_RM0855A.Visible = true;

            CancelClosed = true;
        }

        //Obtiene datos
        private void GetObjectReport()
        {
            string sBaco = cnn.obtenerBanco(CodCliente);

            model = cnn.GetReport(CodCliente, sBaco, iCanal);

            Lista.Add(model);


            string user = ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.Usuario.Nombre;

            ReportParameter[] parameters = new ReportParameter[1];

            parameters[0] = new ReportParameter("Usuario", user);

            rv_RM0855A.LocalReport.DataSources.Clear();

            rv_RM0855A.LocalReport.DataSources.Add(new ReportDataSource("RM0855A_HojaVerde", Lista));
            rv_RM0855A.LocalReport.SetParameters(parameters);
        }

        private void PdfImagen()
        {
            //-CambioImagenesResources
            PC_Loading.Image = Resources.Loading;
        }

        private void CenterTheBox()
        {
            int top = Width / 2;

            int left = Height / 2;

            PC_Loading.PointToScreen(new Point(top, left));
        }

        private void DM0312_RM0855A_ClienteExpress_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!CancelClosed)
            {
                MessageBox.Show("Antes de Cerrar Debe esperar a que cargue", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }

            ClaseEstatica.ListClientes.Remove(CodCliente);
        }
    }
}