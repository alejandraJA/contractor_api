﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_ReportePosicionMov : Form
    {
        private readonly List<PosicionMovimientoData> list = new List<PosicionMovimientoData>();
        private string mov;
        private int movId;

        public DM0312_ReportePosicionMov()
        {
        }

        public DM0312_ReportePosicionMov(List<PosicionMovimientoData> misdatos, int movId, string mov)
        {
            InitializeComponent();
            list = misdatos;
            this.movId = movId;
            this.mov = mov;
        }

        private void ReportePosicionMov_Load(object sender, EventArgs e)
        {
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", list));
            reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Funciones reportePosicionMov = new Funciones();
            //    reportePosicionMov.FillMovPosicion(movId);
        }
    }
}