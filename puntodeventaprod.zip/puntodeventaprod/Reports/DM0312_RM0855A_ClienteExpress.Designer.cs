﻿namespace PuntoVenta.Reports
{
    partial class DM0312_RM0855A_ClienteExpress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.MaviRM0855AHojaVerdeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.PC_Loading = new System.Windows.Forms.PictureBox();
            this.rv_RM0855A = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.MaviRM0855AHojaVerdeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PC_Loading)).BeginInit();
            this.SuspendLayout();
            // 
            // MaviRM0855AHojaVerdeBindingSource
            // 
            this.MaviRM0855AHojaVerdeBindingSource.DataSource = typeof(PuntoVenta.Model.MaviRM0855AHojaVerde);
            // 
            // PC_Loading
            // 
            this.PC_Loading.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PC_Loading.Location = new System.Drawing.Point(165, 124);
            this.PC_Loading.Name = "PC_Loading";
            this.PC_Loading.Size = new System.Drawing.Size(155, 145);
            this.PC_Loading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PC_Loading.TabIndex = 1;
            this.PC_Loading.TabStop = false;
            // 
            // rv_RM0855A
            // 
            this.rv_RM0855A.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "RM0855A_HojaVerde";
            reportDataSource1.Value = this.MaviRM0855AHojaVerdeBindingSource;
            this.rv_RM0855A.LocalReport.DataSources.Add(reportDataSource1);
            this.rv_RM0855A.LocalReport.ReportEmbeddedResource = "PuntoVenta.Reports.DM0312_RM0855A_ClienteExpress.rdlc";
            this.rv_RM0855A.Location = new System.Drawing.Point(0, 0);
            this.rv_RM0855A.Name = "rv_RM0855A";
            this.rv_RM0855A.Size = new System.Drawing.Size(487, 400);
            this.rv_RM0855A.TabIndex = 2;
            this.rv_RM0855A.Visible = false;
            // 
            // DM0312_RM0855A_ClienteExpress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(487, 400);
            this.Controls.Add(this.PC_Loading);
            this.Controls.Add(this.rv_RM0855A);
            this.Name = "DM0312_RM0855A_ClienteExpress";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DM0312_RM0855A_ClienteExpress";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_RM0855A_ClienteExpress_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_RM0855A_ClienteExpress_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MaviRM0855AHojaVerdeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PC_Loading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource MaviRM0855AHojaVerdeBindingSource;
        private System.Windows.Forms.PictureBox PC_Loading;
        private Microsoft.Reporting.WinForms.ReportViewer rv_RM0855A;
    }
}