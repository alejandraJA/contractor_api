﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_MaviCredMayRepImp : Form
    {
        public static List<MRM0847MaviCredRelPedXClienteMayRepImp> MaviClienteMay =
            new List<MRM0847MaviCredRelPedXClienteMayRepImp>();

        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        private readonly List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public DM0312_MaviCredMayRepImp(List<DM0312_MExploradorVenta> DetalleVentasSeleccionadas)
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            VentasSeleccionadas = DetalleVentasSeleccionadas;
            reportViewer1.ShowExportButton = false;
        }

        private void DM0312_MaviCredMayRepImp_Load(object sender, EventArgs e)
        {
            double precio = 0.0;
            double precio2 = 0.0;
            string MovFinal = CDetalleVenta.MovFinalSegunFamilia(VentasSeleccionadas);
            if (MovFinal.Trim() == string.Empty) MovFinal = " ";
            if (MaviClienteMay.Count > 0)
            {
            }

            foreach (MRM0847MaviCredRelPedXClienteMayRepImp mod in MaviClienteMay)
            {
                precio2 = Convert.ToDouble(mod.ImporteArt.Replace("$", ""));
                precio = precio + precio2;
            }

            ReportParameter rMovFinal = new ReportParameter("MovFinal", MovFinal);
            ReportParameter PrecioT = new ReportParameter("PrecioT", precio.ToString());
            List<ReportParameter> rp = new List<ReportParameter>();
            rp.Add(rMovFinal);
            rp.Add(PrecioT);
            reportViewer1.LocalReport.SetParameters(rp);
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("RM0847MaviCredRelPedXClienteMayRepImp",
                MaviClienteMay));
            reportViewer1.RefreshReport();
            reportViewer1.RefreshReport();
        }
    }
}