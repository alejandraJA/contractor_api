﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_ReporteClienteHuellasFotos : Form
    {
        private readonly int iBusqueda;
        public List<DM0312_MAnexoCta> Lista = new List<DM0312_MAnexoCta>();

        public DM0312_ReporteClienteHuellasFotos(int iTipoImagen)
        {
            InitializeComponent();
            iBusqueda = iTipoImagen;
        }

        private void DM0312_ReporteClienteHuellasFotos_Load(object sender, EventArgs e)
        {
            if (iBusqueda == 1 || iBusqueda == 2)
                Lista = ClaseEstatica.ListaAnexoCta.OrderByDescending(x => x.FechaAlta).ToList();
            else
                Lista = ClaseEstatica.ListaAnexoCtaHistorica.OrderByDescending(x => x.FechaAlta).ToList();

            rwFotos.LocalReport.DataSources.Clear();
            rwFotos.LocalReport.EnableExternalImages = true;
            rwFotos.ProcessingMode = ProcessingMode.Local;
            rwFotos.LocalReport.DataSources.Add(new ReportDataSource("dsClienteHuellasFotos", Lista));

            rwFotos.RefreshReport();

            rwFotos.SetDisplayMode(DisplayMode.PrintLayout);
            rwFotos.ZoomMode = ZoomMode.Percent;
            //Seleccionamos el zoom que deseamos utilizar. En este caso un 100%
            rwFotos.ZoomPercent = 100;
        }
    }
}