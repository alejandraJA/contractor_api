﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Windows.Forms;
using Conversiones;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_FacturaMAVIMayoreo12Imp : Form
    {
        //DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public static List<MFacturaMAVIMayoreo12Imp> FacturaMaviMayoreo = new List<MFacturaMAVIMayoreo12Imp>();
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        private readonly Conv Conversiones = new Conv();
        private readonly string Custodia = "";
        public bool Printed;
        private readonly string sDocumento = "";

        public DM0312_FacturaMAVIMayoreo12Imp(bool VistaPrevia = false, string Documentos = "", string Custodias = "")
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            if (VistaPrevia) reportViewer1.ShowPrintButton = false;
            reportViewer1.ShowExportButton = false;
            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            sDocumento = Documentos;
            Custodia = Custodias;
        }


        private void DM0312_FacturaMAVIMayoreo12Imp_Load(object sender, EventArgs e)
        {
            string paisCliente = CDetalleVenta.GetCountry(FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].Codigo);
            string tiempo = CDetalleVenta.ObtenerTiempo(FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].Condicion);
            string AvisoPagina =
                CDetalleVenta.ObtenerAvisoPagina(FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].SucVta.ToString());
            double Total = FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].Importe +
                           FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].Impuestos;
            string ImporteLetraSinRet =
                Conversiones.enletras(
                    (Total - FacturaMaviMayoreo[FacturaMaviMayoreo.Count - 1].Retencion).ToString("0.00"));
            string ImporteLetra = Conversiones.enletras(Total.ToString("0.00"));
            if (AvisoPagina != string.Empty) AvisoPagina = " ";
            List<ReportParameter> rp = new List<ReportParameter>();
            ReportParameter rpaisCliente = new ReportParameter("paisCliente", paisCliente);
            ReportParameter rtiempo = new ReportParameter("tiempo", tiempo);
            ReportParameter rAvisoPagina = new ReportParameter("AvisoPagina", AvisoPagina);
            ReportParameter rNumeroEnLetra = new ReportParameter("PrecioEnLetra", ImporteLetra);
            ReportParameter rNumeroEnLetraSinRetencion =
                new ReportParameter("PrecioSinRetencionEnLetra", ImporteLetraSinRet);

            // GESSY Aqui se Agrega la variable al REP
            ReportParameter rDocumento = new ReportParameter("Documento", sDocumento);
            ReportParameter rCustodia = new ReportParameter("Custodia", Custodia);


            rp.Add(rpaisCliente);
            rp.Add(rtiempo);
            rp.Add(rAvisoPagina);
            rp.Add(rNumeroEnLetra);
            rp.Add(rNumeroEnLetraSinRetencion);
            rp.Add(rDocumento);
            rp.Add(rCustodia);

            PageSettings setup = reportViewer1.GetPageSettings();
            setup.Margins = new Margins(50, 50, 50, 50);
            reportViewer1.SetPageSettings(setup);
            reportViewer1.LocalReport.SetParameters(rp);
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("FacturaMAVIMayoreo12Imp",
                FacturaMaviMayoreo));

            reportViewer1.RefreshReport();
        }

        private void reportViewer1_Print(object sender, ReportPrintEventArgs e)
        {
            Printed = true;
            Close();
        }
    }
}