﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_BSolCreditoInsPisoRep : Form
    {
        public static List<MRM0847BSolCredito> SolCreditoBDetalles = new List<MRM0847BSolCredito>();
        public static MTasaInternaRetorno TasaInterna = new MTasaInternaRetorno();
        public static MInfoCat InfoCat = new MInfoCat();
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public DM0312_BSolCreditoInsPisoRep(List<DM0312_MExploradorVenta> DetalleVentasSeleccionadas)
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            VentasSeleccionadas = DetalleVentasSeleccionadas;
            reportViewer1.ShowExportButton = false;
        }

        private async void DM0312_BSolCreditoInsPisoRep_Load(object sender, EventArgs e)
        {
            if (!frmLoading.Visible) frmLoading.Show(this);
            string MovFinal = await Task.Run(() => CDetalleVenta.MovFinalSegunFamilia(VentasSeleccionadas));
            if (MovFinal.Trim() == string.Empty) MovFinal = " ";

            ReportParameter rMovFinal = new ReportParameter("MovFinal", MovFinal);
            List<ReportParameter> rp = new List<ReportParameter>();

            string CAT = string.Empty;
            string CATPromedio = string.Empty;
            string DAPeriodo = string.Empty;
            if (SolCreditoBDetalles.Count > 0)
            {
                TasaInterna = await Task.Run(() =>
                    CDetalleVenta.ObtenerTasaInterna(
                        Convert.ToInt32(SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].NumeroDocumentos),
                        SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].Articulo));
                CATPromedio = await Task.Run(() => CDetalleVenta.ObtenerCatPromedioSP_RM0847CatVersion2(
                    SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].Mov,
                    SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].MovID,
                    SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].PrecioTotal,
                    Convert.ToInt32(SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].NumeroDocumentos),
                    SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].Condicion));
                DAPeriodo = await Task.Run(() =>
                    CDetalleVenta.ObtenerDAPeriodo(SolCreditoBDetalles[SolCreditoBDetalles.Count - 1].Condicion));
                InfoCat = await Task.Run(() => CDetalleVenta.ObtenerInfoCat());
            }

            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            if (CATPromedio.Trim() == string.Empty) CATPromedio = " ";
            if (DAPeriodo.Trim() == string.Empty) DAPeriodo = " ";
            if (TasaInterna.Cat.Trim() == "") TasaInterna.Cat = " ";
            if (TasaInterna.Contado.Trim() == "") TasaInterna.Contado = " ";
            if (TasaInterna.Credito.Trim() == "") TasaInterna.Credito = " ";
            if (TasaInterna.PagoCiclo.Trim() == "") TasaInterna.PagoCiclo = " ";
            if (TasaInterna.Tasa.Trim() == "") TasaInterna.Tasa = " ";
            if (InfoCat.Comisiones.Trim() == "") InfoCat.Comisiones = " ";
            if (InfoCat.CalculoIntereses.Trim() == "") InfoCat.CalculoIntereses = " ";
            if (InfoCat.Bonificacion.Trim() == "") InfoCat.Bonificacion = " ";
            ReportParameter rDAPeriodo = new ReportParameter("DAPeriodo", DAPeriodo);
            ReportParameter rCATPromedio = new ReportParameter("CATPromedio", CATPromedio);
            ReportParameter rCat = new ReportParameter("TasaInternaCat", TasaInterna.Cat);
            ReportParameter rContado = new ReportParameter("TasaInternaContado", TasaInterna.Contado);
            ReportParameter rCredito = new ReportParameter("TasaInternaCredito", TasaInterna.Credito);
            ReportParameter rPagoCiclo = new ReportParameter("TasaInternaPagoCiclo", TasaInterna.PagoCiclo);
            ReportParameter rTasa = new ReportParameter("TasaInternaTasa", TasaInterna.Tasa);
            ReportParameter rComisiones = new ReportParameter("InfoCatComisiones", InfoCat.Comisiones);
            ReportParameter rCalculoIntereses =
                new ReportParameter("InfoCatCalculoIntereses", InfoCat.CalculoIntereses);
            ReportParameter rBonificacion = new ReportParameter("InfoCatBonificacion", InfoCat.Bonificacion);
            rp.Add(rCATPromedio);
            rp.Add(rDAPeriodo);
            rp.Add(rCat);
            rp.Add(rContado);
            rp.Add(rCredito);
            rp.Add(rPagoCiclo);
            rp.Add(rTasa);
            rp.Add(rComisiones);
            rp.Add(rCalculoIntereses);
            rp.Add(rBonificacion);

            rp.Add(rMovFinal);
            reportViewer1.LocalReport.SetParameters(rp);
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("SolCreditoBInfo", SolCreditoBDetalles));
            if (frmLoading.Visible) frmLoading.Hide();
            reportViewer1.RefreshReport();
        }
    }
}