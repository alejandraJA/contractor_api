﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_MovimientoData : Form
    {
        private readonly List<MovPropiedadesData> listItem = new List<MovPropiedadesData>();

        public DM0312_MovimientoData()
        {
        }

        public DM0312_MovimientoData(List<MovPropiedadesData> list)
        {
            listItem = list;
            InitializeComponent();
        }

        private void MovimientoData_Load(object sender, EventArgs e)
        {
            reportViewer1.ShowExportButton = false;
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("MovData", listItem));
            reportViewer1.RefreshReport();
        }

        private void PosicionMovimientoDataBindingSource_CurrentChanged(object sender, EventArgs e)
        {
        }
    }
}