﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_MaviCredRelPedXClienteRepImp : Form
    {
        public static List<MRM0847MaviCredRelPedXClienteRepImp> detalleVenta =
            new List<MRM0847MaviCredRelPedXClienteRepImp>();

        public static MTasaInternaRetorno TasaInterna = new MTasaInternaRetorno();
        public static MInfoCat InfoCat = new MInfoCat();
        private readonly CDetalleVenta ControladorDetalleVenta = new CDetalleVenta();
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();

        public DM0312_MaviCredRelPedXClienteRepImp()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            reportViewer1.ShowExportButton = false;
        }

        /// <summary>
        ///     Load detalle venta print
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/09/17
        private async void DetalleVentaData_Load(object sender, EventArgs e)
        {
            if (!frmLoading.Visible) frmLoading.Show(this);
            string CAT = string.Empty;
            string CATPromedio = string.Empty;
            string DAPeriodo = string.Empty;
            if (detalleVenta.Count > 0)
            {
                TasaInterna = await Task.Run(() =>
                    ControladorDetalleVenta.ObtenerTasaInterna(detalleVenta[detalleVenta.Count - 1].NumeroDocumentos,
                        detalleVenta[detalleVenta.Count - 1].Articulo));
                CATPromedio = await Task.Run(() => ControladorDetalleVenta.ObtenerCatPromedioSP_RM0847CatVersion2(
                    detalleVenta[detalleVenta.Count - 1].Mov,
                    detalleVenta[detalleVenta.Count - 1].MovId, detalleVenta[detalleVenta.Count - 1].PrecioTotal,
                    detalleVenta[detalleVenta.Count - 1].NumeroDocumentos,
                    detalleVenta[detalleVenta.Count - 1].Condicion));
                DAPeriodo = await Task.Run(() =>
                    ControladorDetalleVenta.ObtenerDAPeriodo(detalleVenta[detalleVenta.Count - 1].Condicion));
                InfoCat = await Task.Run(() => ControladorDetalleVenta.ObtenerInfoCat());
            }

            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            if (CATPromedio.Trim() == string.Empty) CATPromedio = " ";
            if (DAPeriodo.Trim() == string.Empty) DAPeriodo = " ";
            if (TasaInterna.Cat.Trim() == "") TasaInterna.Cat = " ";
            if (TasaInterna.Contado.Trim() == "") TasaInterna.Contado = " ";
            if (TasaInterna.Credito.Trim() == "") TasaInterna.Credito = " ";
            if (TasaInterna.PagoCiclo.Trim() == "") TasaInterna.PagoCiclo = " ";
            if (TasaInterna.Tasa.Trim() == "") TasaInterna.Tasa = " ";
            if (InfoCat.Comisiones.Trim() == "") InfoCat.Comisiones = " ";
            if (InfoCat.CalculoIntereses.Trim() == "") InfoCat.CalculoIntereses = " ";
            if (InfoCat.Bonificacion.Trim() == "") InfoCat.Bonificacion = " ";
            ReportParameter rDAPeriodo = new ReportParameter("DAPeriodo", DAPeriodo);
            ReportParameter rCATPromedio = new ReportParameter("CATPromedio", CATPromedio);
            ReportParameter rCat = new ReportParameter("TasaInternaCat", TasaInterna.Cat);
            ReportParameter rContado = new ReportParameter("TasaInternaContado", TasaInterna.Contado);
            ReportParameter rCredito = new ReportParameter("TasaInternaCredito", TasaInterna.Credito);
            ReportParameter rPagoCiclo = new ReportParameter("TasaInternaPagoCiclo", TasaInterna.PagoCiclo);
            ReportParameter rTasa = new ReportParameter("TasaInternaTasa", TasaInterna.Tasa);
            ReportParameter rComisiones = new ReportParameter("InfoCatComisiones", InfoCat.Comisiones);
            ReportParameter rCalculoIntereses =
                new ReportParameter("InfoCatCalculoIntereses", InfoCat.CalculoIntereses);
            ReportParameter rBonificacion = new ReportParameter("InfoCatBonificacion", InfoCat.Bonificacion);
            List<ReportParameter> rp = new List<ReportParameter>();
            rp.Add(rCATPromedio);
            rp.Add(rDAPeriodo);
            rp.Add(rCat);
            rp.Add(rContado);
            rp.Add(rCredito);
            rp.Add(rPagoCiclo);
            rp.Add(rTasa);
            rp.Add(rComisiones);
            rp.Add(rCalculoIntereses);
            rp.Add(rBonificacion);
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.SetParameters(rp);
            reportViewer1.ProcessingMode = ProcessingMode.Local;
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DetalleVenta", detalleVenta));
            if (frmLoading.Visible) frmLoading.Hide();
            reportViewer1.RefreshReport();
        }
    }
}