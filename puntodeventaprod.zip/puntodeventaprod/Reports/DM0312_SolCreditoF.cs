﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class DM0312_SolCreditoF : Form
    {
        public static List<MRM0847FSolCredito> SolCreditoFDetalles = new List<MRM0847FSolCredito>();
        public static MTasaInternaRetorno TasaInterna = new MTasaInternaRetorno();
        public static MInfoCat InfoCat = new MInfoCat();
        private readonly CDetalleVenta ControladorDetalleVenta = new CDetalleVenta();
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public DM0312_SolCreditoF(List<DM0312_MExploradorVenta> DetalleVentasSeleccionadas)
        {
            InitializeComponent();
            VentasSeleccionadas = DetalleVentasSeleccionadas;
        }


        private async void DM0312SolCreditoF_Load(object sender, EventArgs e)
        {
            //-ReporteDima
            bool bDimaEsFinal = false;
            bool bMostrar = false;
            bool bClientePresente = false;
            string sClientePresente = string.Empty;

            List<modeloHistorialId> listaHistorial = new List<modeloHistorialId>();

            listaHistorial = ControladorDetalleVenta.obtenerHistoriaId(VentasSeleccionadas[0].ID);

            List<modeloHistorialId> vAnalisis = listaHistorial.Where(x => x.sMov == "Analisis Credito").ToList();
            List<modeloHistorialId> vSolicitud = listaHistorial.Where(x => x.sMov == "Solicitud Credito").ToList();

            if (!frmLoading.Visible) frmLoading.Show(this);
            reportViewer1.ShowExportButton = false;
            string MovFinal = await Task.Run(() => ControladorDetalleVenta.MovFinalSegunFamilia(VentasSeleccionadas));
            if (MovFinal.Trim() == string.Empty) MovFinal = " ";

            ReportParameter rMovFinal = new ReportParameter("MovFinal", MovFinal);
            List<ReportParameter> rp = new List<ReportParameter>();

            string sCodigoBarra = string.Empty;
            string CAT = string.Empty;
            string CATPromedio = string.Empty;
            string DAPeriodo = string.Empty;
            string PagoFijo = Convert.ToString(SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].DblPrecioTotal /
                                               Convert.ToInt32(SolCreditoFDetalles[SolCreditoFDetalles.Count - 1]
                                                   .NumeroDocumentos));
            string abonomensual = Convert.ToString(Convert.ToDouble(PagoFijo) * 2);
            if (SolCreditoFDetalles.Count > 0)
            {
                TasaInterna = await Task.Run(() =>
                    ControladorDetalleVenta.ObtenerTasaInterna(
                        Convert.ToInt32(SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].NumeroDocumentos),
                        SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].Articulo));
                CATPromedio = await Task.Run(() => ControladorDetalleVenta.ObtenerCatPromedioSP_RM0847CatVersion2(
                    SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].Mov,
                    SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].MovID,
                    SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].DblPrecioTotal,
                    Convert.ToInt32(SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].NumeroDocumentos),
                    SolCreditoFDetalles[SolCreditoFDetalles.Count - 1].Condicion));
                DAPeriodo = await Task.Run(() =>
                    ControladorDetalleVenta.ObtenerDAPeriodo(SolCreditoFDetalles[SolCreditoFDetalles.Count - 1]
                        .Condicion));
                InfoCat = await Task.Run(() => ControladorDetalleVenta.ObtenerInfoCat());
                if (vAnalisis.Count > 0)
                    sCodigoBarra = await Task.Run(() =>
                        ControladorDetalleVenta.obtenerCodigoBarra(vAnalisis[0].sMov, vAnalisis[0].sMovId));
                else
                    sCodigoBarra = "SIN VALE";
            }

            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            if (CATPromedio.Trim() == string.Empty) CATPromedio = " ";
            if (DAPeriodo.Trim() == string.Empty) DAPeriodo = " ";
            if (TasaInterna.Cat.Trim() == "") TasaInterna.Cat = " ";
            if (TasaInterna.Contado.Trim() == "") TasaInterna.Contado = " ";
            if (TasaInterna.Credito.Trim() == "") TasaInterna.Credito = " ";
            if (TasaInterna.PagoCiclo.Trim() == "") TasaInterna.PagoCiclo = " ";
            if (TasaInterna.Tasa.Trim() == "") TasaInterna.Tasa = " ";
            if (InfoCat.Comisiones.Trim() == "") InfoCat.Comisiones = " ";
            if (InfoCat.CalculoIntereses.Trim() == "") InfoCat.CalculoIntereses = " ";
            if (InfoCat.Bonificacion.Trim() == "") InfoCat.Bonificacion = " ";
            ReportParameter rDAPeriodo = new ReportParameter("DAPeriodo", DAPeriodo);
            ReportParameter rCATPromedio = new ReportParameter("CATPromedio", CATPromedio);
            ReportParameter rCat = new ReportParameter("TasaInternaCat", TasaInterna.Cat);
            ReportParameter rContado = new ReportParameter("TasaInternaContado", TasaInterna.Contado);
            ReportParameter rCredito = new ReportParameter("TasaInternaCredito", TasaInterna.Credito);
            ReportParameter rPagoCiclo = new ReportParameter("TasaInternaPagoCiclo", TasaInterna.PagoCiclo);
            ReportParameter rTasa = new ReportParameter("TasaInternaTasa", TasaInterna.Tasa);
            ReportParameter rComisiones = new ReportParameter("InfoCatComisiones", InfoCat.Comisiones);
            ReportParameter rCalculoIntereses =
                new ReportParameter("InfoCatCalculoIntereses", InfoCat.CalculoIntereses);
            ReportParameter rBonificacion = new ReportParameter("InfoCatBonificacion", InfoCat.Bonificacion);
            //ReportParameter rPagoFijo = new ReportParameter("PagoFijo", PagoFijo);
            ReportParameter rabonomensual = new ReportParameter("abonomensual", abonomensual);

            //-ReporteDima ->
            bDimaEsFinal = ControladorDetalleVenta.validarClienteDimaFinal(VentasSeleccionadas[0].ID);

            ReportParameter ocultarTxt37 = new ReportParameter();
            ReportParameter ocultarTxt38 = new ReportParameter();
            ReportParameter ocultarTxt85 = new ReportParameter();
            ReportParameter ocultarTxt86 = new ReportParameter();
            ReportParameter ocultarTxt74 = new ReportParameter();
            ReportParameter ocultarTxt79 = new ReportParameter();
            ReportParameter ocultarTxt35 = new ReportParameter();


            ReportParameter rPagoFijo = new ReportParameter();
            int iIdSol = ControladorDetalleVenta.obtenerIdSolicitudCredito(vSolicitud[0].sMov, vSolicitud[0].sMovId);

            sClientePresente = ControladorDetalleVenta.obtenerFinalPresente(iIdSol);

            if (sClientePresente == "SI") bClientePresente = true;

            if (bDimaEsFinal)
            {
                bMostrar = true;
            }
            else
            {
                if (!bClientePresente)
                    bMostrar = true;
                else
                    bMostrar = false;
            }

            if (bMostrar)
            {
                ocultarTxt37 = new ReportParameter("ocultarTxt37", "True");
                ocultarTxt38 = new ReportParameter("ocultarTxt38", "True");
                ocultarTxt85 = new ReportParameter("ocultarTxt85", "True");
                ocultarTxt86 = new ReportParameter("ocultarTxt86", "True");
                ocultarTxt74 = new ReportParameter("ocultarTxt74", "True");
                ocultarTxt79 = new ReportParameter("ocultarTxt79", "True");
                rPagoFijo = new ReportParameter("PagoFijo", PagoFijo);
            }
            else
            {
                SolCreditoFDetalles[0].Condicion = "NO";
                ocultarTxt37 = new ReportParameter("ocultarTxt37", "False");
                ocultarTxt38 = new ReportParameter("ocultarTxt38", "False");
                ocultarTxt85 = new ReportParameter("ocultarTxt85", "False");
                ocultarTxt86 = new ReportParameter("ocultarTxt86", "False");
                ocultarTxt74 = new ReportParameter("ocultarTxt74", "False");
                ocultarTxt79 = new ReportParameter("ocultarTxt79", "False");
                rPagoFijo = new ReportParameter("PagoFijo", " ");
            }

            if (string.IsNullOrEmpty(sCodigoBarra)) sCodigoBarra = "SIN VALE";

            ReportParameter numeroVale = new ReportParameter("numeroVale", sCodigoBarra);
            //-ReporteDima <- 

            rp.Add(rCATPromedio);
            rp.Add(rDAPeriodo);
            rp.Add(rCat);
            rp.Add(rContado);
            rp.Add(rCredito);
            rp.Add(rPagoCiclo);
            rp.Add(rTasa);
            rp.Add(rComisiones);
            rp.Add(rCalculoIntereses);
            rp.Add(rBonificacion);
            rp.Add(rPagoFijo);
            rp.Add(rabonomensual);

            rp.Add(rMovFinal);

            //-ReporteDima
            rp.Add(numeroVale);
            rp.Add(ocultarTxt37);
            rp.Add(ocultarTxt38);
            rp.Add(ocultarTxt85);
            rp.Add(ocultarTxt86);
            rp.Add(ocultarTxt74);
            rp.Add(ocultarTxt79);

            reportViewer1.LocalReport.SetParameters(rp);
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("SolCreditoFInfo", SolCreditoFDetalles));
            if (frmLoading.Visible) frmLoading.Hide();
            reportViewer1.ZoomMode = ZoomMode.PageWidth;
            reportViewer1.RefreshReport();
        }
    }
}