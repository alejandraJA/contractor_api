﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.Reports
{
    public partial class ReporteVenta : Form
    {
        public static DM0312_MExploradorVenta MovAImprimir = new DM0312_MExploradorVenta();
        public static string Referencia;
        public static string Observaciones;
        public static List<MImpresionVenta> ListaImpresionVenta = new List<MImpresionVenta>();
        public static string Unidad;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool Printed = false;

        public ReporteVenta(bool VistaPrevia = false)
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            if (VistaPrevia) reportViewer1.ShowPrintButton = false;
            reportViewer1.ShowExportButton = false;
            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
        }

        private void ReporteVenta_Load(object sender, EventArgs e)
        {
            List<ReportParameter> rp = new List<ReportParameter>();
            ReportParameter rParam = new ReportParameter("rvMov", MovAImprimir.Mov + " " + MovAImprimir.MovId);
            rp.Add(rParam);

            //Se pone la primera letra en mayusculas
            rParam = new ReportParameter("rvEstatus",
                char.ToUpper(MovAImprimir.Estatus[0]) + MovAImprimir.Estatus.Substring(1));
            rp.Add(rParam);
            rParam = new ReportParameter("rvFechaEmision", MovAImprimir.FechaAlta.ToString("dd MMMM yyyy"));
            rp.Add(rParam);
            rParam = new ReportParameter("rcteNombre", MovAImprimir.Nombre + "(" + MovAImprimir.Cliente + ")");
            rp.Add(rParam);
            List<string> InfoCliente = DireccionCliente(MovAImprimir.Cliente);
            rParam = new ReportParameter("rcteDireccion", InfoCliente[0] != "" ? InfoCliente[0] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rcteColonia", InfoCliente[1] != "" ? InfoCliente[1] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rctePoblacion", InfoCliente[2] != "" ? InfoCliente[2] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rcteTelefonos", InfoCliente[3] != "" ? InfoCliente[3] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rcteEstado", InfoCliente[4] != "" ? InfoCliente[4] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rcteCodigoPostal", InfoCliente[5] != "" ? InfoCliente[5] : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rvReferencia", Referencia != "" ? Referencia : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rvConcepto", MovAImprimir.Concepto);
            rp.Add(rParam);
            rParam = new ReportParameter("rvObservaciones", Observaciones != "" ? Observaciones : " ");
            rp.Add(rParam);
            rParam = new ReportParameter("rvAgente", MovAImprimir.Agente + " " + AgenteNombre());
            rp.Add(rParam);

            string descSucursal = " ";
            string datosDescSucursal = " ";
            if (
                (
                    MovAImprimir.EnviarA == "3" || MovAImprimir.EnviarA == "4" || MovAImprimir.EnviarA == "7"
                ) &&
                (
                    MovAImprimir.Sucursal != 96 || MovAImprimir.Sucursal != 39 || MovAImprimir.Sucursal != 29
                    || MovAImprimir.Sucursal != 94
                )
            )
            {
                descSucursal = DescripcionSucursal();
                datosDescSucursal = DatosDescripcionSucursal();
            }

            rParam = new ReportParameter("rvDescripcionSucursal", descSucursal);
            rp.Add(rParam);
            rParam = new ReportParameter("rvDatosDescripcionSucursal", datosDescSucursal);
            rp.Add(rParam);

            int sumaCantidad = ListaImpresionVenta.Sum(x => Convert.ToInt32(x.Cantidad));
            rParam = new ReportParameter("rvsumaCantidad", sumaCantidad.ToString());
            rp.Add(rParam);
            rParam = new ReportParameter("rvUnidad", Unidad);
            rp.Add(rParam);

            double sumaImportes = ListaImpresionVenta.Sum(x => Convert.ToDouble(x.Importe.Replace("$", "")));
            rParam = new ReportParameter("rvsumaImporte", sumaImportes.ToString("C"));
            rp.Add(rParam);

            float dImpuesto = CDetalleVenta.obtenerImpuesto(MovAImprimir.ID) / 100 + 1;
            float im = CDetalleVenta.obtenerImpuestosVenta(MovAImprimir.ID);
            double Impuestos = im;
            rParam = new ReportParameter("rvImpuestos", Impuestos.ToString("C"));
            rp.Add(rParam);

            //double Impuestos = Convert.ToDouble(ListaImpresionVenta[0].sImpuesto.Replace("$", ""));
            //rParam = new ReportParameter("rvImpuestos", "$" + Impuestos.ToString("0.00"));
            //rp.Add(rParam);

            double ImporteTotal = sumaImportes + Impuestos;
            rParam = new ReportParameter("rvImporteTotal", ImporteTotal.ToString("C"));
            rp.Add(rParam);

            rParam = new ReportParameter("DateNow",
                string.Format("{0}, {1} de {2} de {3}", DateTime.Now.ToString("dddd"), DateTime.Now.ToString("dd"),
                    DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy")));
            rp.Add(rParam);

            PageSettings setup = reportViewer1.GetPageSettings();
            setup.Margins = new Margins(50, 50, 50, 50);
            reportViewer1.SetPageSettings(setup);
            reportViewer1.LocalReport.SetParameters(rp);

            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("ListaImpresionVenta", ListaImpresionVenta));

            reportViewer1.RefreshReport();
        }

        private List<string> DireccionCliente(string cliente)
        {
            string CadenaSQL = "SELECT Direccion, Colonia, Poblacion, Telefonos, Estado, CodigoPostal"
                               + " FROM CTE WITH(NOLOCK) WHERE Cliente = @Cliente";
            string[] parametros = { "@Cliente" };
            string[] ValoresParametros = { cliente };
            string[] ListaCliente = { "Direccion", "Colonia", "Poblacion", "Telefonos", "Estado", "CodigoPostal" };
            List<string> InfoCliente =
                CDetalleVenta.EjecutaSQLDataReader(CadenaSQL, parametros, ValoresParametros, ListaCliente);

            return InfoCliente;
        }

        private string AgenteNombre()
        {
            string CadenaSQL = "SELECT Nombre FROM Agente WITH(NOLOCK) WHERE Agente = @Agente";
            string[] parametros = { "@Agente" };
            string[] ValoresParametros = { MovAImprimir.Agente };
            return CDetalleVenta.EjecutaComandosSQL(CadenaSQL, parametros, ValoresParametros, "");
        }

        private string DescripcionSucursal()
        {
            string CadenaSQL = "SELECT Descripcion2 FROM SucursalOtrosDatos WITH(NOLOCK) WHERE Sucursal = @Sucursal";
            string[] parametros = { "@Sucursal" };
            string[] ValoresParametros = { MovAImprimir.Sucursal.ToString() };
            return CDetalleVenta.EjecutaComandosSQL(CadenaSQL, parametros, ValoresParametros, "");
        }

        public string DatosDescripcionSucursal()
        {
            string CadenaSQL = "Select Puntual = case when Art.linea = 'CREDILANA' then " +
                               " X.Precio * Descripcion13 else X.Precio * Descripcion3 end from " +
                               " SucursalOtrosDatos inner join Venta on " +
                               " SucursalOtrosDatos.Sucursal = Venta.SucursalVenta " +
                               " Inner join VentaD on VentaD.id = Venta.id " +
                               " inner join Art on Art.Articulo = VentaD.Articulo " +
                               " inner join(select D.id, Precio= Sum(D.Precio) from " +
                               "(select D.id, Precio= Sum(D.Cantidad) * D.Precio from VentaD D where id=@ID " +
                               " group by D.id,D.Precio)D group by D.id)X on X.id = Venta.id " +
                               " where SucursalOtrosDatos.Sucursal = @Sucursal and Venta.Id = @ID";
            string[] parametros = { "@Sucursal", "@ID" };
            string[] ValoresParametros = { MovAImprimir.Sucursal.ToString(), MovAImprimir.ID.ToString() };
            return CDetalleVenta.EjecutaComandosSQL(CadenaSQL, parametros, ValoresParametros, "");
        }
    }
}