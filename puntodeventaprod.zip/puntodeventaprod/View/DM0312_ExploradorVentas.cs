﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.Properties;
using PuntoVenta.Reports;
using PuntoVenta.Utilidades;
using PuntoVenta.View;
using Workbook = Microsoft.Office.Interop.Excel.Workbook;
using Worksheet = Microsoft.Office.Interop.Excel.Worksheet;
using XlFileFormat = Microsoft.Office.Interop.Excel.XlFileFormat;
#if CUBOS
using PuntoVenta.ShmCubos;
#elif PRODUCCION
using PuntoVenta.ShmProd;
#endif

namespace PuntoVenta
{
    /// <summary>
    ///     Principal class
    /// </summary>
    public partial class DM0312_ExploradorVentas : Form
    {
        public static DM0312_CPuntoDeVenta controladorP = new DM0312_CPuntoDeVenta();
        public static DM0312_CVentanaEntrada controladorVE = new DM0312_CVentanaEntrada();
        public static EventoController EventoC = new EventoController();
        public static DM0312_MExploradorVenta ModelSeleccionado;
        public static DM0312_MConsultarEvento eventoSeleccionado;
        public static List<DM0312_MExploradorVenta> ListaExplorador;
        public static bool validaAcceso;
        public static string CodCliente = string.Empty;
        public static string CodAgente = string.Empty;
        public static string Sucursal = string.Empty;
        public static bool EjecutaEvento = false;
        public static bool AfectarVisible = true;
        public static bool monederoPorRedimir = true;
        public static bool VerActualizacionDeDatos = true;
        public static bool AgregarActualizacionDatosV = true;
        public static bool tiempototal = true;
        public static bool nuevoCd = true;
        public static bool RM0855ClienteExpres = true;
        public static bool consultaBuro = true;
        public static bool Excel = true;
        public static bool Kardexclientefinal = true;
        public static bool CamposExtras = true;
        public static bool CopiarCliente = true;
        public static bool CopiarClienteRelacionado = true;
        public static bool CapturaRelacionado = true;
        public static bool MatrizDeAutorizacion = true;
        public static bool CorreoWeb = true;
        public static bool reanalisisV = true;
        private bool activado;
        private bool activadoMenu;
        private bool AsyncRunning;
        private bool bSeguimientoNotificacion = false;
        public bool cancelaMov;
        public string chk_ContaC;
        public string chk_ContaN;
        public string chk_CrediC;
        public string chk_CrediC_May;
        public string chk_CrediN;
        public string chk_CrediN_May;
        public string chk_MA_;
        public string chk_MAVI_;
        public string chk_VIU_;
        private string codigoclienteFin = "";
        private readonly List<int> columnSizes = new List<int>();
        private DM0312_C_Contactos Contactos = new DM0312_C_Contactos();
        private readonly CDetalleVenta controladorD = new CDetalleVenta();
        public DM0312_CRegistroCte controllercte;
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        public DM0312_MRegistroCte cte;

        private CancellationTokenSource ctoken = new CancellationTokenSource();
        public List<string> datosTipoCredito = new List<string>();
        private string defCuentaUsuario;
        private readonly CDetalleVenta detalle = new CDetalleVenta();
        private readonly List<TableroDetalleVenta> Detalles = new List<TableroDetalleVenta>();
        public bool Devolver;
        public List<DM0312_MAdminDoc> DocumentosAdjuntosList;

        //Bandera para saber si la forma ya paso el evento load y no cargue el evento 'tablero movimiento' varias veces
        private bool FormIsInLoad = true;

        public DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();
        public int IdVenta = 0;
        public Image img;

        public PictureBox imgPictureBox;

        //loading
        public PictureBox imgPictureBox_;

        private bool ImporteFormateado;
        public int index;
        public List<DM0312_MAdminDoc> ListaComprobante;

        public List<string> ListaControles;
        public List<DM0312_MComentariosVenta> ListaExploradorVenta;
        public List<DM0312_MAdminDoc> ListaIdenti;

        // 1286
        public List<string> listaNotificaciones = new List<string>();
        public List<DM0312_MAdminDoc> ListaPedido;
        public List<DM0312_MAdminDoc> ListaTarjetas;
        public List<DM0312_MExploradorVenta> listMovimientos;

        //-CerradoIntelisis
        private readonly DM0312_C_Login loginC = new DM0312_C_Login();
        public string MovId = string.Empty;
        private string nombreSucursal;
        public List<AccesoColumnas> PosicionColumna;
        public string recibeMensaje; // VARIABLE QUE RECIBE EL ACCESO USUARIO "VENTP" DE LA CLASE LOGIN
        public int recibeSucursal;
        public Image returnImage;

        public string[] row1 =
        {
            "Movimiento", "Suc", "Cliente", "Nombre", "Situacion", "Condicion", "ImporteTotal", "TipoCliente", "Canal",
            "Monedero", "Estatus", "Reactivacion", "Grupo", "Relacionado", "ReferenciaAnt", "FechaAlta",
            "Calificaciones", "AgenteTab", "fechaUltimaMod", "Almacen", "Seguimiento", "TipoCredito", "Poblacion"
        };

        //-PedidoSinDetalle
        private readonly clsStd std = new clsStd();
        private string tempSucursal = "";
        private readonly AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
        public string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        public string validaMensaje;

        public DM0312_ExploradorVentas()
        {
            InitializeComponent();
            ModelSeleccionado = new DM0312_MExploradorVenta();
            controllercte = new DM0312_CRegistroCte();
            DocumentosAdjuntosList = new List<DM0312_MAdminDoc>();
            ListaIdenti = new List<DM0312_MAdminDoc>();
            ListaPedido = new List<DM0312_MAdminDoc>();
            ListaComprobante = new List<DM0312_MAdminDoc>();
            ListaTarjetas = new List<DM0312_MAdminDoc>();
            ListaControles = new List<string>();
            frmLoading = new DM0312_Loading_();
            listMovimientos = new List<DM0312_MExploradorVenta>();
            PosicionColumna = new List<AccesoColumnas>();
        }

        private void Tablero_Load(object sender, EventArgs e)
        {
            ValidarBloqueoCargaPrecios();
            LlenarTipoCredito();
            btnKardex.Visible = btn_KardexCliente.Visible;
            listTipoCredito.Visible = false;
            lbl_TipoCredito.Visible = false;

            SPID.Text = "SPID:" + ClaseEstatica.SPID;
            pnlfix_delfix.Location = new Point(-1, 30);
            SPID.Location = new Point(12, 5);
            dgv_TablaDetalle.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            dgv_Eventos.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            gbx_Detalle.DoubleClick += gbx_Detalle_Enter;
            flp_detalle.DoubleClick += gbx_Detalle_Enter;
            foreach (Control ctrl in flp_detalle.Controls) ctrl.DoubleClick += gbx_Detalle_Enter;
            //gbx_Detalle.Click += gbx_Detalle_Enter;
            //flp_detalle.Click += gbx_Detalle_Enter;
            //foreach (Control ctrl in flp_detalle.Controls)
            //{
            //    ctrl.Click += gbx_Detalle_Enter;
            //}
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                dgv_Eventos.Visible = false;
                gbx_Detalle.Visible = false;
                gbx_Eventos.Visible = false;
            }

            txt_Buscar.Focus();
            PdfImagen();
            txt_NombreSucursal.Enabled = false;
            bool permisosuc;

            permisosuc = controllerExplorador.PermisoSucursal(ClaseEstatica.Usuario.Usser);
            if (permisosuc == false) txt_Sucursal.Enabled = false;
            txt_Sucursal.Text = recibeSucursal.ToString();
            gbx_Contactos.Visible = false;
            gbx_DocumentosAdj.Visible = false;
            txt_Buscar.Focus();

            // LLENA COMBOBOX MOVIMIENTO
            cbx_movimiento_FillCombo();
            dgv_TablaMovimientos.Select();

            // SE OBTIENE LOS COMENTARIOS DE LOS COMPONENTES
            ListaExploradorVenta = Funciones.ConsultaComentario("Explorador de Ventas");

            /////////////////////////////////////////////VALIDACION DE ACCESOS POR USUARIO //////////////////////////////////////////////////  
            lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;

            if (ClaseEstatica.Usuario.Acceso == "VENTP_USRB")
            {
                chk_CreditoCasa.Checked = true;
                chk_ContadoNuevo.Checked = true;
                chk_ContadoCasa.Checked = true;
                chk_CreditoNuevo.Checked = true;
                cbx_movimiento.Text = "Pedido";
                cbx_estatus.Text = "Pendiente";
            }

            else
            {
                if (chk_CreditoCasa.Visible)
                {
                    if (usuarioVenta == "COBRA")
                    {
                        chk_CreditoCasa.Checked = true;
                        cbx_movimiento.Text = "Solicitud Devolucion";
                        cbx_estatus.Text = "Pendiente";
                    }
                    else
                    {
                        chk_CreditoCasa.Checked = true;
                        cbx_movimiento.Text = "Solicitud Credito";
                        cbx_estatus.Text = "Pendiente";
                    }
                }
                else if (cbx_CreditoCasaMayoreo.Visible)
                {
                    cbx_movimiento.Text = "Pedido Mayoreo";
                    cbx_CreditoCasaMayoreo.Checked = true;
                    cbx_estatus.Text = "Pendiente";
                }
                else if (chk_MA.Visible)
                {
                    if (usuarioVenta == "CONTM")
                    {
                        chk_MAVI.Checked = true;
                        cbx_movimiento.Text = "Factura";
                        cbx_estatus.Text = "Concluido";
                    }
                    else
                    {
                        chk_MA.Checked = true;
                        cbx_movimiento.Text = "Factura";
                        cbx_estatus.Text = "Concluido";
                    }
                }
            }

            chk_ClienteEnSucursal.Visible = std.validarAccesoCambaceo();
            DateTime thisDay = DateTime.Today;
            cbx_BuscarEn.Text = "MovID";

            cbx_fechaA.Text = controllerExplorador.FechaActualServidor().ToString();
            cbx_fechaD.Text = controllerExplorador.FechaActualServidor().ToString();
            //hace el tablero mas largo para cuando sea usuario de factura se muestre mas grande
            if (lbl_Almacen.Visible && !dgv_Eventos.Visible && !btn_CatalagoCalif.Visible && !imgBoxCta.Visible &&
                !btn_Contactos.Visible
                && !dgv_Contactos.Visible && !btn_Contactos.Visible)
                dgv_TablaMovimientos.Height = 375;
            //gbx_TablaPrincipal.Height = 390;
            //flowLayoutPanel2.Location = new Point(120, 485);
            txt_NombreSucursal.Enabled = false;

            TableroMovimientos();

            //DATAGRID EVENTOS 
            FillDataGridEventos();

            ValidaCaja();

            //Boton huellas y fotos
            gbx_FotoCliente.Visible = false;

            if (txt_Sucursal.Visible == false)
            {
                lbl_Sucursal.Visible = false;
                txt_NombreSucursal.Visible = false;
            }

            dgv_TablaMovimientos.Select();

            MouseWheel += MouseScroll;

            tooltip();

            if (controllerExplorador.AccesoUsuario(ClaseEstatica.Usuario.Usser) != "")
                btn_Nuevo.Visible = true;
            else
                btn_Nuevo.Visible = false;

            if (cbx_Impreso.Visible)
                lbl_Impreso.Visible = true;
            else
                lbl_Impreso.Visible = false;

            FormIsInLoad = false;

            //-343E
            if (std.accesoScoring())
            {
                btnScoring.Visible = true;
                menuScoring.Visible = true;
            }

            //-1200
            if (std.validarAccesoOrdenCompra()) menuOrdenCompra.Visible = true;

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                //Panel_Menu.BackColor = Color.gra;

                pnlfix_delfix.BackColor = Color.AliceBlue;
                Panel_Menu.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;

                //pnlfix_delfix.BackColor = Color.DeepSkyBlue;
                //Panel_Menu.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;

                pnlfix_delfix.BackColor = Color.LightCyan;
                Panel_Menu.BackColor = Color.LightCyan;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;

                pnlfix_delfix.BackColor = Color.WhiteSmoke;
                Panel_Menu.BackColor = Color.WhiteSmoke;
            }

            //1286 LOAD
            if (getTipoUsuario() == "CREDI")
            {
                contextMenuStrip1.Items.AddRange(new ToolStripItem[] { NotificarAnalista, AgregarEventoMI });
                toolTipRecalificar.Items.AddRange(new ToolStripItem[] { menuRecalificar });
            }

            //1286 LOAD
            if (getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR")
            {
                contextMenuStrip1.Items.AddRange(new ToolStripItem[] { AgregarEventoMI });
                toolTipRecalificar.Enabled = false;
            }

            //-1706
            if (ClaseEstatica.Usuario.usuario.Substring(0, 5) == "CREDI") ttCuentaClabe.Visible = true;

            if (new[] { "VENTP", "VENTR" }.Contains(getTipoUsuario())) ttCargaPPC.Visible = true;
        }

        public void tooltip()
        {
            toolTip1 = new ToolTip();
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE COMO UTILIZAR EL EXPLORADOR DE VENTAS");
            toolTip1.SetToolTip(btn_Nuevo,
                "SELECCIONAR PARA HACER UN MOVIMIENTO NUEVO PUEDE SER: VENTA, SOLICITUD DEVOLUCION O ADJUDICACION DEPENDIENDO DE LOS PERMISOS QUE TENGA EL USUARIO (CRTL-N)");
            toolTip1.SetToolTip(btn_Cancelar, "CERRAR EXPLORADOR(ESC)");
            toolTip1.SetToolTip(btn_Refrescar,
                "CARGAR DE NUEVO LOS MOVIMIENTOS CON LOS FILTROS QUE SELECCIONO EL USUARIO (F5)");
            toolTip1.SetToolTip(btn_HistoSolicitudes,
                "HERRAMIENTA EN LA CUAL SE MUESTRA TODO EL HISTORIAL DEL CLIENTE, MUESTRA LAS SOLICITUDES DE CREDITO Y ANALISIS DE CREDITO DESDE LA PRIMERA QUE SE LE REALIZO HASTA LA MAS ACTUAL (F3)");
            toolTip1.SetToolTip(btn_InformacionCliente,
                "DATOS IMPORTANTES DEL CLIENTE ASI COMO SU HISTORIAL EN VENTAS, SUS DOCUMENTOS POR COBRAR, VENTAS PENDIENTES Y HABITOS DE PAGO (CRTL-I)");
            toolTip1.SetToolTip(btn_RegistroHuella,
                "HERRAMIENTA EN LA CUAL SE ENCUENTRA LOS REGISTROS DE HUELLA DEL CLIENTE, SU FOTOGRAFIA ACTUAL Y EL HISTORIAL SU HISTORIAL DE FOTOS (F4)");
            toolTip1.SetToolTip(btn_Selp,
                "HERRAMIENTA PARA OBTENER LOS PRECIOS DE TODOS LOS ARTICULOS QUE TIENE LA TIEDA ASI COMO LAS IMAGENES DE CADA ARTICULO (Crtl-S)");
            toolTip1.SetToolTip(btn_VisorMavi, "HERRAMIENTA QUE MUESTRA TODOS LOS DOCUMENTOS ADJUTOS DEL CLIENTE (F7)");
            //YADI
            toolTip1.SetToolTip(btn_CalidadCap, " (Crtl-L)");
            toolTip1.SetToolTip(btn_ConsultaBuro,
                "HERRAMIENTA PARA CONSULTAR EL HISTORIAL CREDITICIO DE UN CLIENTE EN BURO DE CREDITO (F8)");
            toolTip1.SetToolTip(btn_HistoricoUniCaja,
                "HERRAMIENTA QUE MUESTRA LOS MOVIMIENTOS DE VENTA REALIZADOS EN EL SISTEMA UNICAJA (Crtl-H)");
            toolTip1.SetToolTip(btn_ResumenFac,
                "HERRAMIENTA PARA CONSULTAR EL HISTORIAL DE CREDITO DEL CLIENTE ACTIVO EN LA EMPRESA (F10)");
            //YADI
            toolTip1.SetToolTip(btn_KardexCliente, " (F11)");
            toolTip1.SetToolTip(btn_PreliminarCobro,
                "HERRAMINETA QUE MUESTRA EL ESTADO DE CUENTA DEL CLIENTE Y REALIZACION DE COBROS (F12)");
            if (usuarioVenta == "VENTP" || usuarioVenta == "CREDI")
                toolTip1.SetToolTip(btn_Eventos,
                    "HERRAMIENTA EN LA QUE SE PODRA AGREGAR Y CONSULTAR EVENTOS, NOTAS Y CITAS DEPENDIENDO LOS PERMISOS DEL USUARIO (CRLT-E), AGREGAR EVENTO(F6), CONSULTAR NOTA(F1), CONSULTAR CITA(F2)");
            else
                toolTip1.SetToolTip(btn_Eventos,
                    "HERRAMIENTA EN LA QUE SE PODRA AGREGAR Y CONSULTAR EVENTOS, NOTAS Y CITAS DEPENDIENDO LOS PERMISOS DEL USUARIO (CRLT-E)");
            toolTip1.SetToolTip(btn_UsuariosTiempos,
                "HERRAMIENTA PARA CONSULTAR LOS USUARIOS QUE AFECTARON EL MOVIMIENTO SELECCIONADO (Crlt-U)");
            toolTip1.SetToolTip(btn_PosicionMov,
                "REPORTE QUE MUESTRA LOS MOVIMIENTOS ANTERIORES DEL SELECCIONADO (Crlt-P)");
            toolTip1.SetToolTip(btn_Relaciones, "MUESTRA LAS CUENTAS LIGADAS AL CLIENTE (Crtl-R)");
            toolTip1.SetToolTip(BtnProspectoaCliente, "HERRAMIENTA PARA ASIGNARLE CUENTA A UN PROSPECTO (Crtl-R)");
            toolTip1.SetToolTip(btn_CatalagoCalif,
                "CATALOGO QUE MUESTRA LAS CLAVES CREDITICIAS DE LA COMPAÑIA (Crtl-R)");
            ////YADI
            toolTip1.SetToolTip(btn_AnalistasCredi, " (Crtl-R)");
            toolTip1.SetToolTip(btn_ConfColumnas,
                "HERRAMIENTA DONDE EL USUARIO PODRA CONFIGURAR LAS COLUMNAS DEL EXPLORADOR DE MANERA PERSONALIZADA (F9) ");
            toolTip1.SetToolTip(lbl_Usuario, "Usuario");
            toolTip1.SetToolTip(lbl_CuentaCaja, "Caja");
            toolTip1.SetToolTip(button1, "Cerrar Menu de Inicio");
            toolTip1.SetToolTip(button3, "Cerrar Menu");
            toolTip1.SetToolTip(btnValida, "SELECCIONAR PARA GUARDAR EL REGISTRO DE HUELLA");
            toolTip1.SetToolTip(btn_Contactos,
                "APARTADO DONDE SE PLASMAN LAS REFERENCIAS LABORALES Y PERSONALES DE UN CLIENTE");
            toolTip1.SetToolTip(btn_DocumentosAdjuntos,
                "APARTADO QUE MUESTRA LOS DOCUMENTOS MAS IMPORTANTES DE UN CLIENTE");

            toolTip1.SetToolTip(txt_Buscar, "INSERTAR LA DESCRIPCION DE LO QUE SE QUIERE BUSCAR (NOMBRE,CUENTA,ETC)");
            toolTip1.SetToolTip(cbx_BuscarEn, "LISTA DE CAMPOS DE LOS QUE PUEDES ELEGIR PARA BUSCAR MOVIMIENTOS");
            toolTip1.SetToolTip(cbx_movimiento, "TIPO DE VENTA, DEVOLUCION O ADJUDICACION");
            toolTip1.SetToolTip(cbx_situacion, "ESTADO EN QUE SE ENCUENTRA EL MOVIMIENTO");
            toolTip1.SetToolTip(cbx_estatus,
                "CIRCUNSTANCIA EN LA QUE SE ENCUENTRA EL MOVIMIENTO (SIN AFECTAR, PENDIENTE,CONCLUIDO, CANCELADO)");
            toolTip1.SetToolTip(cbx_fechaD, "RANGO FINAL DE FECHA  DE BUSQUEDA");
            toolTip1.SetToolTip(cbx_fechaA, "RANGO INICIAL DE FECHA  DE BUSQUEDA");
            toolTip1.SetToolTip(txt_Sucursal,
                "SUCURSAL DONDE TE ENCUENTRAS FIRMADO EN INTELISIS SI EL CAMPO SE ENCUENTRA VACIO INDICA QUE SE ESTARA BUSCANDO POR TODAS LAS SURCURSALES QUE TIENE LA EMPRESA");
            toolTip1.SetToolTip(txt_NombreSucursal, "NOMBRE DE LA SUCURSAL");
            toolTip1.SetToolTip(cbx_Impreso,
                "FILTRO QUE PERMITE VISUALIZAR EN EL EXPLORADOR QUE FACTURAS,CREDILANAS O SEGUROS VIDA YA SE IMPRIMIERON");
            toolTip1.SetToolTip(chk_Devolucion,
                "CHECK  QUE PERMITE VISUALIZAR EN EL EXPLORADOR QUE FACTURAS CONTIENEN DEVOLUCION");
            toolTip1.SetToolTip(chk_ContadoNuevo, "MOSTRARA MOVIMIENTOS DE CONTADO PARA CLIENTES NUEVOS");
            toolTip1.SetToolTip(chk_ContadoCasa, "MOSTRARA MOVIMIENTOS DE CONTADO PARA CLIENTES CASA");
            toolTip1.SetToolTip(chk_CreditoNuevo, "MOSTRARA MOVIMIENTOS DE CREDITO PARA CLIENTES NUEVOS");
            toolTip1.SetToolTip(chk_CreditoCasa, "MOSTRARA MOVIMIENTOS DE CREDITO PARA CLIENTES CASA");
            toolTip1.SetToolTip(chk_MA, "MOVIMIENTOS DE UEN 1, MUEBLES AMERICA");
            toolTip1.SetToolTip(chk_MAVI, "MOVIMIENTOS DE UEN 3, DE VENTAS MAYOREO");
            toolTip1.SetToolTip(chk_VIU, "MOVIMIENTOS DE UEN 2 ");
            toolTip1.SetToolTip(cbx_CreditoCasaMayoreo,
                "MOSTRARA MOVIMIENTOS DE CREDITO PARA CLIENTES CASA DE MAYOREO");
            toolTip1.SetToolTip(cbx_creditoNuevoMayoreo,
                "MOSTRARA MOVIMIENTOS DE CREDITO PARA CLIENTES NUEVOS DE MAYOREO");
            toolTip1.SetToolTip(dtp_DeFecha, "RANGO FINAL DE FECHA  DE BUSQUEDA");
            toolTip1.SetToolTip(dtp_Afecha, "RANGO INICIAL DE FECHA  DE BUSQUEDA");
            toolTip1.SetToolTip(listTipoCredito, "LISTADO DE LOS TIPO DE CREDITO");
        }


        /// <summary>
        ///     Fix para el menu que se mueve, tu no remuevas esto ni el label lbl_FixNoRemover plox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 25/10/17
        private void MouseScroll(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
                txt_Buscar.Focus();
            else if (btn_DocumentosAdjuntos.Visible)
                btn_DocumentosAdjuntos.Focus();
            else
                dgv_TablaMovimientos.Focus();
            pnlfix_delfix.Location = new Point(-1, 30);
            SPID.Location = new Point(12, 5);
        }


        /// <summary>
        ///     Entra a los detalles del movimiento
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 11/07/2017
        private void gbx_Detalle_Enter(object sender, EventArgs e)
        {
            try
            {
                if (ListaExplorador.Count > 0)
                {
                    if (!ListasDetallesAbiertas())
                    {
                        if (dgv_TablaDetalle.Rows.Count > 0)
                        {
                            CDetalleVenta.MovimientoGenerado = false;
                            controllerExplorador.LLenadoListaArticulosSeleccionados(listMovimientos);
                            DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
                            detalle.PaginadoActual = 0;
                            dgv_TablaMovimientos.Focus();
                            detalle.Show();
                        }
                        else
                        {
                            dgv_TablaMovimientos.Focus();
                            MessageBox.Show("No se encontraron articulos en el detalle", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        dgv_TablaMovimientos.Focus();
                        MessageBox.Show("Uno o varios movimientos ya estan abiertos", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    dgv_TablaMovimientos.Focus();
                    MessageBox.Show("No hay articulos en este movimiento", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception exception)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, exception);
                //sbp_EstatusPrograma.Text = @"Error: " + exception.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + exception.Message, exception);
            }
        }

        /// <summary>
        ///     Carga los nuevos moviminetos generados por afectacion
        /// </summary>
        /// <param name="detalle">DM0312_DetalleVenta</param>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 09/10/17
        public void CargarNuevasAfectaciones(DM0312_DetalleVenta detalle,
            List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            if (CDetalleVenta.MovimientoGenerado)
            {
                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                controllerExplorador.LLenadoListaArticulosSeleccionados(VentasSeleccionadas);
                detalle.VentasSeleccionadas = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
                detalle.ListaDetallesSeleccionados = new List<MDetalleVenta>(DM0312_DetalleVenta.ListaDetalles);
                detalle = (DM0312_DetalleVenta)UsuarioAcceso.AplicarVistas(detalle);
                detalle.PaginadoActual = CDetalleVenta.PaginadoActual;
                detalle.LoadEvent();
                detalle.Show();
            }
        }

        /// <summary>
        ///     Checa si uno de los movimientos seleccionados ya esta abierto
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 09/10/17
        private bool ListasDetallesAbiertas()
        {
            bool DetalleYaAbierto = false;

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_DetalleVenta")
                {
                    DM0312_DetalleVenta Detalle = (DM0312_DetalleVenta)forma;
                    if (Detalle.VentasSeleccionadas.Count > 0)
                    {
                        bool BreakingValue = false;
                        foreach (DM0312_MExploradorVenta Venta in Detalle.VentasSeleccionadas)
                        {
                            foreach (DM0312_MExploradorVenta item in ListaExplorador)
                                if (Venta.ID == item.ID)
                                {
                                    DetalleYaAbierto = true;
                                    BreakingValue = true;
                                    break;
                                }

                            if (BreakingValue) break;
                        }
                    }
                }

            if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90) DetalleYaAbierto = false;
            return DetalleYaAbierto;
        }

        public void TiempoTotalM()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                TiempoTotal tiempoTotal = new TiempoTotal();
                tiempoTotal.recibeMovimiento = ModelSeleccionado.Mov;
                tiempoTotal.recibeId = Convert.ToInt32(ModelSeleccionado.ID);
                tiempoTotal.recibeCliente = ModelSeleccionado.Cliente;
                tiempoTotal.ShowDialog();
                txt_Buscar.Focus();
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void tiempoTotalCrtlIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TiempoTotalM();
        }

        private void btn_InfCliente_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "InformacionCliente")
                    {
                        forma.Close();
                        break;
                    }

                InformacionCliente infoCliente = new InformacionCliente();
                infoCliente.mensaje = ModelSeleccionado.Cliente;
                infoCliente.Show();
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_Eventos_Click(object sender, EventArgs e)
        {
            // GESSY 1286 
            /*if (dgv_TablaMovimientos.Rows.Count > 0) {
                foreach (Form forma in Application.OpenForms) {
                    if (forma.Name == "DM0312_EventosNotasCitas") {
                        forma.Close();
                        break;
                    }
                }
                //ESTO tiene que ser solo para los credi

                DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                eventNotaCita = (DM0312_EventosNotasCitas)UsuarioAcceso.AplicarVistas(eventNotaCita);
                DM0312_EventosNotasCitas.recibeCliente = ModelSeleccionado.Cliente;
                DM0312_EventosNotasCitas.recibeMov = ModelSeleccionado.Mov;
                DM0312_EventosNotasCitas.recibeMovId = Convert.ToString(ModelSeleccionado.MovId);
                DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(ModelSeleccionado.ID);
                DM0312_EventosNotasCitas.recibeUsuario = lbl_Usuario.Text;
                DM0312_EventosNotasCitas.recibeSituacion = ModelSeleccionado.Situacion;
                DM0312_EventosNotasCitas.recibeEstatus = ModelSeleccionado.Estatus;
                DM0312_EventosNotasCitas.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                DM0312_EventosNotasCitas.iCanalVenta = int.Parse(ModelSeleccionado.EnviarA);
                DM0312_EventosNotasCitas.recibeIdecommerce = ModelSeleccionado.IDEcommerce;
                eventNotaCita.TopMost = true;
                eventNotaCita.ShowDialog();
                if (DM0312_ExploradorVentas.EjecutaEvento) {
                    dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos, new DataGridViewCellEventArgs(0, 0));
                }

                txt_Buscar.Focus();
                eventNotaCita.TopMost = false;
            }
            else {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }*/
            mostrarEventosNotasCitasView();
        }

        private void btn_UsuariosTiempos_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "TiemposUsuarios")
                    {
                        forma.Close();
                        break;
                    }

                TiemposUsuarios tiemposUsuarios = new TiemposUsuarios();
                tiemposUsuarios.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                tiemposUsuarios.recibeMovId = Convert.ToString(ModelSeleccionado.MovId);
                tiemposUsuarios.recibeMov = ModelSeleccionado.Mov;
                tiemposUsuarios.recibeCliente = ClaseEstatica.Usuario.Usser;
                tiemposUsuarios.Show();
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void PosicionMovM()
        {
            int movId = 0;
            string mov = string.Empty;
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    movId = ModelSeleccionado.ID;
                    mov = ModelSeleccionado.Mov;
                    Funciones reportePosicionMov = new Funciones();
                    if (ModelSeleccionado.Estatus != "SINAFECTAR")
                    {
                        if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                            reportePosicionMov.FillReportePosicionMovLinea(movId, mov);
                        else
                            reportePosicionMov.FillReportePosicionMov(movId, mov);
                    }
                    else
                    {
                        MessageBox.Show("Movimiento con origen sin Afectar", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }

                    txt_Buscar.Focus();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("btn_PosMov_Click", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message + " function: btn_PosMov_Click, class: DM0312_ExploradorVentas.cs");
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_PosMov_Click(object sender, EventArgs e)
        {
            PosicionMovM();
        }

        private void btn_HistoSolicitudes_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "HistorialSolicitudes")
                    {
                        forma.Close();
                        break;
                    }

                HistorialSolicitudes historialSol = new HistorialSolicitudes();
                historialSol.recibeMensajeUsuario = ClaseEstatica.Usuario.Usser;
                historialSol.recibeMensajeCliente = ModelSeleccionado.Cliente;
                historialSol.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                historialSol.recibeMovId = ModelSeleccionado.MovId;
                historialSol.recibeCliente = ModelSeleccionado.Cliente;
                historialSol.recibeMov = ModelSeleccionado.Mov;
                historialSol.recibeFecha = cbx_fechaA.Text;
                historialSol.recibeSituacion = ModelSeleccionado.Situacion;
                historialSol.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                historialSol.recibeFechaD = cbx_fechaD.Text;
                historialSol.Show();
            }
            else
            {
                HistorialSolicitudes historialSol = new HistorialSolicitudes();
                historialSol.validaFormEmpty = true;
                historialSol.recibeMensajeUsuario = ClaseEstatica.Usuario.Usser;
                //historialSol.recibeMensajeCliente = ModelSeleccionado.Cliente;
                //historialSol.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                //historialSol.recibeMovId = ModelSeleccionado.MovId;
                //historialSol.recibeCliente = ModelSeleccionado.Cliente;
                //historialSol.recibeMov = ModelSeleccionado.Mov;
                historialSol.recibeFecha = cbx_fechaA.Text;
                //historialSol.recibeSituacion = ModelSeleccionado.Situacion;
                //historialSol.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                historialSol.recibeFechaD = cbx_fechaD.Text;
                historialSol.Show();
            }
        }

        private async void btn_RegistroHuella_Click(object sender, EventArgs e)
        {
            if (funciones.CheckFormsOpen("RegistroDeHuellaCliente"))
                return;

            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                if (ModelSeleccionado.Cliente == " " || ModelSeleccionado.Cliente == null)
                    return;

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                }

                await Task.Run(() => LlenarHuellasyFotos());

                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    DesabilitarControles(true);
                }

                ClaseEstatica.ListaCte.RemoveAll(x => x.Codigo == null);


                if (ClaseEstatica.ListaCte.Count == 0)
                {
                    MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                RegistroDeHuellaCliente huellas = new RegistroDeHuellaCliente();
                huellas.cliente = ModelSeleccionado.Cliente;
                huellas.Usuario = lbl_Usuario.Text;
                huellas.movId = ModelSeleccionado.MovId;
                huellas.mov = ModelSeleccionado.Mov;
                huellas.Show();
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_Relaciones_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "Relaciones")
                    {
                        forma.Close();
                        break;
                    }

                Relaciones RelacionesC = new Relaciones();
                RelacionesC.recibeCliente = ModelSeleccionado.Cliente;
                RelacionesC.Show();
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_CatalagoCalif_Click(object sender, EventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "CatalogoDeCalificaciones")
                {
                    forma.Close();
                    break;
                }

            CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
            catalogoCalificacion.Show();
        }

        private void btn_DocumentosAdjuntos_Click(object sender, EventArgs e)
        {
            if (ListaExplorador.Count == 0)
                return;

            if (gbx_DocumentosAdj.Visible)
            {
                gbx_DocumentosAdj.Visible = false;
            }
            else
            {
                DM0312_CAdminDoc controller = new DM0312_CAdminDoc();
                DocumentosAdjuntosList =
                    controller.DocumentosAdjuntos(ModelSeleccionado.Cliente, ModelSeleccionado.MovId /*CodCliente*/);
                if (DocumentosAdjuntosList.Count > 0)
                {
                    gbx_DocumentosAdj.Visible = true;
                    gbx_DocumentosAdj.Focus();
                    llenarIdentificacion();
                    llenarComprobantes();
                    llenarTarjetas();
                    llenarPagares();
                }
                else
                {
                    gbx_DocumentosAdj.Visible = false;
                    MessageBox.Show(
                        "El Cliente con cuenta: " + ModelSeleccionado.Cliente + "  no tiene documentos adjuntos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void btn_Contactos_Click(object sender, EventArgs e)
        {
            if (gbx_Contactos.Visible)
            {
                gbx_Contactos.Visible = false;
            }
            else
            {
                if (dgv_TablaMovimientos.Rows.Count > 0)
                {
                    InformacionContactosTablero();
                    if (dgv_Contactos.Rows.Count > 0)
                        gbx_Contactos.Visible = true;
                    else
                        MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
                else
                {
                    if (dgv_Contactos.Rows.Count > 0)
                        gbx_Contactos.Visible = true;

                    else
                        MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
            }


            int height = 40;
            foreach (DataGridViewRow item in dgv_Contactos.Rows) height += item.Height;
            dgv_Contactos.Height = height;
            gbx_Contactos.Height = height;

            btn_DocumentosAdjuntos.Focus();
        }

        private void btn_ConfColumn_Click(object sender, EventArgs e)
        {
            ConfiguracionColumnas configColumna = new ConfiguracionColumnas();
            configColumna.ShowDialog();
            ShowColumns();

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                //Panel_Menu.BackColor = Color.gra;

                pnlfix_delfix.BackColor = Color.AliceBlue;
                Panel_Menu.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;

                pnlfix_delfix.BackColor = Color.DeepSkyBlue;
                Panel_Menu.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;

                pnlfix_delfix.BackColor = Color.LightCyan;
                Panel_Menu.BackColor = Color.LightCyan;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_TablaMovimientos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_TablaDetalle.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_Contactos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;

                pnlfix_delfix.BackColor = Color.WhiteSmoke;
                Panel_Menu.BackColor = Color.WhiteSmoke;
            }
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Refrescar_Click(object sender, EventArgs e)
        {
            TableroMovimientos();
            //-ReservaOnline
            showBotonPedidosStorePickup();
            ClaseEstatica.ListaAnexoCta = new List<DM0312_MAnexoCta>();
            ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();
        }

        public async void TableroMovimientos()
        {
            GC.Collect();
            //-CerradoIntelisis
            loginC.checkSession();

            txt_ComentarioAyuda.Text = "";
            if (!AsyncRunning)
            {
                AsyncRunning = true;
                string[] Array = new string[9];

                ListaExplorador = new List<DM0312_MExploradorVenta>();
                ModelSeleccionado = new DM0312_MExploradorVenta();
                validaAcceso = false;
                int sucursal = 0;
                if (txt_Sucursal.Text != string.Empty) int.TryParse(txt_Sucursal.Text, out sucursal);

                Array[0] = cbx_movimiento.Text;
                Array[1] = cbx_situacion.Text;
                Array[2] = cbx_estatus.Text;
                Array[3] = cbx_fechaD.Text;
                Array[4] = cbx_fechaA.Text;
                Array[5] = txt_Buscar.Text;
                Array[6] = cbx_BuscarEn.Text;
                Array[7] = cbx_Impreso.Text;
                Array[8] = Devolver.ToString();

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                }

                try
                {
                    ctoken = new CancellationTokenSource();

                    int cont = 0;
                    string tipocred = "";
                    if (listTipoCredito.Visible)
                        for (int i = 0; i <= listTipoCredito.Items.Count - 1; i++)
                            if (listTipoCredito.GetItemChecked(i))
                            {
                                if (cont == 0)
                                    tipocred = listTipoCredito.Items[i].ToString();
                                else
                                    tipocred = tipocred + "," + listTipoCredito.Items[i];
                                cont++;
                            }

                    if (tipocred == "") tipocred = "Todos";
                    listMovimientos =
                        await Task.Run(
                            () => controllerExplorador.MovimientosExploradorVenta(Array, this, validaMensaje,
                                ClaseEstatica.Usuario.Usser, txt_Sucursal.Text, ctoken.Token, tipocred), ctoken.Token);
                    listMovimientos = (chk_ClienteEnSucursal.Checked
                        ? listMovimientos.Where(filtrar => filtrar.VtaCambaceo == "NO")
                        : listMovimientos).ToList();
                    /*Filtro tipo credito*/
                }
                catch (Exception ex)
                {
                    if (!ctoken.IsCancellationRequested)
                    {
                        DM0312_ErrorLog.RegistraError("TableroMovimientos", "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: TableroMovimientos, class: DM0312_ExploradorVentas.cs");
                    }

                    ImporteFormateado = true;
                }
                finally
                {
                    GetSetColumWidth();
                    dgv_TablaMovimientos.DataSource = null;
                    dgv_TablaMovimientos.DataSource = listMovimientos.ToList();

                    dgv_TablaMovimientos.DataSource = listMovimientos.ToList();

                    dgv_TablaMovimientos.Columns["FechaAlta"].DefaultCellStyle.Format = "dd/MM/yy HH:mm:ss";

                    dgv_TablaMovimientos.Columns["ReactivacionLiberacion"].Visible = false;
                    dgv_TablaMovimientos.Columns["ReactivacionComplemento"].Visible = false;
                    dgv_TablaMovimientos.Columns["Reanalisis"].Visible = false;
                    dgv_TablaMovimientos.Columns["SeguimientoReactivacion"].Visible = false;


                    ImporteFormateado = false;
                }


                if (dgv_TablaMovimientos.Rows.Count == 0)
                {
                    gbx_Detalle.Visible = false;
                    flp_PanelEventos.Visible = false;
                    gbx_FotoCliente.Visible = false;
                }
                else
                {
                    gbx_Detalle.Visible = true;
                    gbx_FotoCliente.Visible = true;
                    flp_PanelEventos.Visible = true;
                }

                if (listMovimientos.Count != 0) validaAcceso = true;
                ////PERMITE CARGAR LA CONFIGURACION DE COLUMNAS EN EL GRIDPRINCIPAL 
                ShowColumns();

                int contCreditoCasa = 0;
                int contCreditoNuevo = 0;
                int contContadoNuevo = 0;
                int contContadoCasa = 0;
                int contCreditoNuevoMay = 0;
                int contCreditoCasaMay = 0;

                double importeCreditoCasa = 0;
                double importeCreditoNuevo = 0;
                double importeContadoNuevo = 0;
                double importeContadoCasa = 0;
                double importeCreditoNuevoMay = 0;
                double importeCreditoCasaMay = 0;

                for (int i = 0; i < dgv_TablaMovimientos.Rows.Count; i++)
                {
                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Contado Nuevo" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo Mayoreo")
                        dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Maroon;

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Contado Casa" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa Mayoreo")
                        dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Navy;

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo")
                    {
                        contCreditoNuevo++;
                        importeCreditoNuevo = importeCreditoNuevo + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Contado Nuevo")
                    {
                        contContadoNuevo++;
                        importeContadoNuevo = importeContadoNuevo + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa")
                    {
                        contCreditoCasa++;
                        importeCreditoCasa = importeCreditoCasa + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa Mayoreo")
                    {
                        contCreditoCasaMay++;
                        importeCreditoCasaMay = importeCreditoCasaMay + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Contado Casa")
                    {
                        contContadoCasa++;
                        importeContadoCasa = importeContadoCasa + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo Mayoreo")
                    {
                        contCreditoNuevoMay++;
                        importeCreditoNuevoMay = importeCreditoNuevoMay + listMovimientos[i].Importe;
                    }
                }

                lbl_CreditoCasaNum.Text = Convert.ToString(contCreditoCasa) + " Credito Casa";
                lbl_CreditoNuevoNum.Text = Convert.ToString(contCreditoNuevo) + " Credito Nuevo";
                lbl_ContadoNuevoNum.Text = Convert.ToString(contContadoNuevo) + " Contado Nuevo";
                lbl_CreditoCasaMayNum.Text = Convert.ToString(contCreditoCasaMay) + " Credito Casa May";
                lbl_ContadoCasaNum.Text = Convert.ToString(contContadoCasa) + " Contado Casa";
                lbl_CreditoNuevoMayNum.Text = Convert.ToString(contCreditoNuevoMay) + " Credito Nuevo May";

                txt_CreditoCasaNum.Text = importeCreditoCasa.ToString("C");
                txt_CreditoNuevoNum.Text = importeCreditoNuevo.ToString("C");
                txt_ContadoNuevoNum.Text = importeContadoNuevo.ToString("C");
                txt_ContadoCasaNum.Text = importeContadoCasa.ToString("C");
                txt_CreditoCasaMayNum.Text = importeCreditoCasaMay.ToString("C");
                txt_CreditoNuevoMayNum.Text = importeCreditoNuevoMay.ToString("C");

                //txt_CreditoNuevoMayNum.Text = Convert.ToDouble(importeCreditoNuevoMay).ToString("C", Thread.CurrentThread.CurrentCulture);
                //txtSubTotal.Text = subtotalParcial.ToString("C");
                //txtImpuestos.Text = subtotalImpuesto.ToString("C");
                //txtTotal.Text = Total.ToString("C");
                ////txt_CreditoCasaNum.Text = "$" + Convert.ToString(importeCreditoCasa.ToString(""));
                //txt_CreditoNuevoNum.Text = "$" + Convert.ToString(importeCreditoNuevo.ToString(""));
                //txt_ContadoNuevoNum.Text = "$" + Convert.ToString(importeContadoNuevo.ToString(""));
                //txt_ContadoCasaNum.Text = "$" + Convert.ToString(importeContadoCasa.ToString(""));
                //txt_CreditoCasaMayNum.Text = "$" + Convert.ToString(importeCreditoCasaMay.ToString());
                //txt_CreditoNuevoMayNum.Text = "$" + Convert.ToString(importeCreditoNuevoMay.ToString(""));

                lbl_CreditoCasaNum.Visible = true;
                txt_CreditoCasaNum.Visible = true;
                lbl_CreditoNuevoNum.Visible = true;
                txt_CreditoNuevoNum.Visible = true;
                lbl_ContadoNuevoNum.Visible = true;
                txt_ContadoNuevoNum.Visible = true;
                lbl_CreditoCasaMayNum.Visible = true;
                txt_CreditoCasaMayNum.Visible = true;
                lbl_ContadoCasaNum.Visible = true;
                txt_ContadoCasaNum.Visible = true;
                lbl_CreditoNuevoMayNum.Visible = true;
                txt_CreditoNuevoMayNum.Visible = true;
                if (contCreditoCasa == 0)
                {
                    lbl_CreditoCasaNum.Visible = false;
                    txt_CreditoCasaNum.Visible = false;
                }

                if (contCreditoNuevo == 0)
                {
                    lbl_CreditoNuevoNum.Visible = false;
                    txt_CreditoNuevoNum.Visible = false;
                }

                if (contContadoNuevo == 0)
                {
                    lbl_ContadoNuevoNum.Visible = false;
                    txt_ContadoNuevoNum.Visible = false;
                }

                if (contCreditoCasaMay == 0)
                {
                    lbl_CreditoCasaMayNum.Visible = false;
                    txt_CreditoCasaMayNum.Visible = false;
                }

                if (contContadoCasa == 0)
                {
                    lbl_ContadoCasaNum.Visible = false;
                    txt_ContadoCasaNum.Visible = false;
                }

                if (contCreditoNuevoMay == 0)
                {
                    lbl_CreditoNuevoMayNum.Visible = false;
                    txt_CreditoNuevoMayNum.Visible = false;
                }

                dgv_TablaMovimientos_SelectionChanged_1(null, null);

                //DesabilitarControles(true);
                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    DesabilitarControles(true);
                }

                //-Dineralia
                if (ModelSeleccionado.Mov == "Analisis Credito")
                {
                    btnDineralia.Enabled = true;
                    if (ClaseEstatica.Usuario.usuario.Substring(0, 5) == "CREDI") ttCuentaClabe.Visible = true;
                }
                else
                {
                    btnDineralia.Enabled = false;
                    if (ClaseEstatica.Usuario.usuario.Substring(0, 5) == "CREDI") ttCuentaClabe.Visible = false;
                }

                dgv_TablaMovimientos.Select();

                if (gbx_Eventos.Visible == false)
                {
                    int height = 80;
                    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                        if (height < 320)
                            height += item.Height;
                    dgv_TablaMovimientos.Height = height;
                    gbx_TableroPr.Height = height + 60;
                    panel_MovsPr.Height = height + 60;
                }
                else
                {
                    int height = 80;
                    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                        if (height < 230)
                            height += item.Height;
                    dgv_TablaMovimientos.Height = height;
                    gbx_TableroPr.Height = height + 60;
                    panel_MovsPr.Height = height + 60;
                }

                dgv_TablaMovimientos.Columns["ReferenciaAnterior"].Width = 180;
                dgv_TablaMovimientos.Columns["FechaAlta"].Width = 130;
                dgv_TablaMovimientos.Columns["EstatusEnvio"].Width = 124;
                dgv_TablaMovimientos.Columns["VtaCambaceo"].Width = 140;
                dgv_TablaMovimientos.Columns["ImporteTotal"].Width = 130;
                dgv_TablaMovimientos.Columns["TipoCliente"].Width = 130;
                dgv_TablaMovimientos.Columns["FechaUltimaMod"].Width = 140;
                dgv_TablaMovimientos.Columns["TipoCredito"].Width = 130;
                dgv_TablaMovimientos.Columns["ImporteTotal"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
                ////Agregar columna ClienteFinal cuando sea usuario "CREDI"
                if (ClaseEstatica.Usuario.Usser.Substring(0, 5) == "CREDI")
                {
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Width = 250;
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Visible = true;
                }
                else ////Caso contrario ocultar la columna ClienteFinal
                {
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Visible = false;
                }

                GetSetColumWidth(true);
                if (dgv_Eventos.Visible)
                    flp_PanelEventos.Visible = true;
                else
                    flp_PanelEventos.Visible = false;
                AsyncRunning = false;
                dgv_Contactos.DataSource = null;
                gbx_Contactos.Visible = false;


                //-Primera Fase de Automatizacion
                //showBotonPedidosStorePickup();
            }
        }

        public async void TableroMovimientos2(string mov, string situacion, string estatus, string movid)
        {
            txt_ComentarioAyuda.Text = "";
            if (!AsyncRunning)
            {
                AsyncRunning = true;
                string[] Array = new string[9];

                ListaExplorador = new List<DM0312_MExploradorVenta>();
                ModelSeleccionado = new DM0312_MExploradorVenta();
                validaAcceso = false;
                int sucursal = 0;
                if (txt_Sucursal.Text != string.Empty) int.TryParse(txt_Sucursal.Text, out sucursal);

                Array[0] = mov;
                Array[1] = situacion;
                Array[2] = estatus;
                Array[3] = cbx_fechaD.Text;
                Array[4] = cbx_fechaA.Text;
                Array[5] = movid;
                Array[6] = cbx_BuscarEn.Text;
                Array[7] = cbx_Impreso.Text;
                Array[8] = Devolver.ToString();

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                }

                try
                {
                    ctoken = new CancellationTokenSource();

                    int cont = 0;
                    string tipocred = "";
                    if (listTipoCredito.Visible)
                        for (int i = 0; i <= listTipoCredito.Items.Count - 1; i++)
                            if (listTipoCredito.GetItemChecked(i))
                            {
                                if (cont == 0)
                                    tipocred = listTipoCredito.Items[i].ToString();
                                else
                                    tipocred = tipocred + "," + listTipoCredito.Items[i];
                                cont++;
                            }

                    if (tipocred == "") tipocred = "Todos";
                    listMovimientos =
                        await Task.Run(
                            () => controllerExplorador.MovimientosExploradorVenta(Array, this, validaMensaje,
                                ClaseEstatica.Usuario.Usser, txt_Sucursal.Text, ctoken.Token, tipocred), ctoken.Token);
                    listMovimientos = (chk_ClienteEnSucursal.Checked
                        ? listMovimientos.Where(filtrar => filtrar.VtaCambaceo == "NO")
                        : listMovimientos).ToList();

                    /*Filtro tipo credito*/
                }
                catch (Exception ex)
                {
                    if (!ctoken.IsCancellationRequested)
                    {
                        DM0312_ErrorLog.RegistraError("TableroMovimientos", "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: TableroMovimientos, class: DM0312_ExploradorVentas.cs");
                    }

                    ImporteFormateado = true;
                }
                finally
                {
                    GetSetColumWidth();
                    dgv_TablaMovimientos.DataSource = null;
                    dgv_TablaMovimientos.DataSource = listMovimientos.ToList();
                    dgv_TablaMovimientos.Columns["FechaAlta"].DefaultCellStyle.Format = "dd/MM/yy HH:mm:ss";
                    ImporteFormateado = false;
                }


                if (dgv_TablaMovimientos.Rows.Count == 0)
                {
                    gbx_Detalle.Visible = false;
                    flp_PanelEventos.Visible = false;
                    gbx_FotoCliente.Visible = false;
                }
                else
                {
                    gbx_Detalle.Visible = true;
                    gbx_FotoCliente.Visible = true;
                    flp_PanelEventos.Visible = true;
                }

                if (listMovimientos.Count != 0) validaAcceso = true;
                ////PERMITE CARGAR LA CONFIGURACION DE COLUMNAS EN EL GRIDPRINCIPAL 
                ShowColumns();

                int contCreditoCasa = 0;
                int contCreditoNuevo = 0;
                int contContadoNuevo = 0;
                int contContadoCasa = 0;
                int contCreditoNuevoMay = 0;
                int contCreditoCasaMay = 0;

                double importeCreditoCasa = 0;
                double importeCreditoNuevo = 0;
                double importeContadoNuevo = 0;
                double importeContadoCasa = 0;
                double importeCreditoNuevoMay = 0;
                double importeCreditoCasaMay = 0;

                for (int i = 0; i < dgv_TablaMovimientos.Rows.Count; i++)
                {
                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Contado Nuevo" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo Mayoreo")
                        dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Maroon;

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Contado Casa" ||
                        Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa Mayoreo")
                        dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Navy;

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo")
                    {
                        contCreditoNuevo++;
                        importeCreditoNuevo = importeCreditoNuevo + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Contado Nuevo")
                    {
                        contContadoNuevo++;
                        importeContadoNuevo = importeContadoNuevo + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa")
                    {
                        contCreditoCasa++;
                        importeCreditoCasa = importeCreditoCasa + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa Mayoreo")
                    {
                        contCreditoCasaMay++;
                        importeCreditoCasaMay = importeCreditoCasaMay + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Contado Casa")
                    {
                        contContadoCasa++;
                        importeContadoCasa = importeContadoCasa + listMovimientos[i].Importe;
                    }

                    if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo Mayoreo")
                    {
                        contCreditoNuevoMay++;
                        importeCreditoNuevoMay = importeCreditoNuevoMay + listMovimientos[i].Importe;
                    }
                }

                lbl_CreditoCasaNum.Text = Convert.ToString(contCreditoCasa) + " Credito Casa";
                lbl_CreditoNuevoNum.Text = Convert.ToString(contCreditoNuevo) + " Credito Nuevo";
                lbl_ContadoNuevoNum.Text = Convert.ToString(contContadoNuevo) + " Contado Nuevo";
                lbl_CreditoCasaMayNum.Text = Convert.ToString(contCreditoCasaMay) + " Credito Casa May";
                lbl_ContadoCasaNum.Text = Convert.ToString(contContadoCasa) + " Contado Casa";
                lbl_CreditoNuevoMayNum.Text = Convert.ToString(contCreditoNuevoMay) + " Credito Nuevo May";

                txt_CreditoCasaNum.Text = importeCreditoCasa.ToString("C");
                txt_CreditoNuevoNum.Text = importeCreditoNuevo.ToString("C");
                txt_ContadoNuevoNum.Text = importeContadoNuevo.ToString("C");
                txt_ContadoCasaNum.Text = importeContadoCasa.ToString("C");
                txt_CreditoCasaMayNum.Text = importeCreditoCasaMay.ToString("C");
                txt_CreditoNuevoMayNum.Text = importeCreditoNuevoMay.ToString("C");

                //txt_CreditoNuevoMayNum.Text = Convert.ToDouble(importeCreditoNuevoMay).ToString("C", Thread.CurrentThread.CurrentCulture);
                //txtSubTotal.Text = subtotalParcial.ToString("C");
                //txtImpuestos.Text = subtotalImpuesto.ToString("C");
                //txtTotal.Text = Total.ToString("C");
                ////txt_CreditoCasaNum.Text = "$" + Convert.ToString(importeCreditoCasa.ToString(""));
                //txt_CreditoNuevoNum.Text = "$" + Convert.ToString(importeCreditoNuevo.ToString(""));
                //txt_ContadoNuevoNum.Text = "$" + Convert.ToString(importeContadoNuevo.ToString(""));
                //txt_ContadoCasaNum.Text = "$" + Convert.ToString(importeContadoCasa.ToString(""));
                //txt_CreditoCasaMayNum.Text = "$" + Convert.ToString(importeCreditoCasaMay.ToString());
                //txt_CreditoNuevoMayNum.Text = "$" + Convert.ToString(importeCreditoNuevoMay.ToString(""));

                lbl_CreditoCasaNum.Visible = true;
                txt_CreditoCasaNum.Visible = true;
                lbl_CreditoNuevoNum.Visible = true;
                txt_CreditoNuevoNum.Visible = true;
                lbl_ContadoNuevoNum.Visible = true;
                txt_ContadoNuevoNum.Visible = true;
                lbl_CreditoCasaMayNum.Visible = true;
                txt_CreditoCasaMayNum.Visible = true;
                lbl_ContadoCasaNum.Visible = true;
                txt_ContadoCasaNum.Visible = true;
                lbl_CreditoNuevoMayNum.Visible = true;
                txt_CreditoNuevoMayNum.Visible = true;
                if (contCreditoCasa == 0)
                {
                    lbl_CreditoCasaNum.Visible = false;
                    txt_CreditoCasaNum.Visible = false;
                }

                if (contCreditoNuevo == 0)
                {
                    lbl_CreditoNuevoNum.Visible = false;
                    txt_CreditoNuevoNum.Visible = false;
                }

                if (contContadoNuevo == 0)
                {
                    lbl_ContadoNuevoNum.Visible = false;
                    txt_ContadoNuevoNum.Visible = false;
                }

                if (contCreditoCasaMay == 0)
                {
                    lbl_CreditoCasaMayNum.Visible = false;
                    txt_CreditoCasaMayNum.Visible = false;
                }

                if (contContadoCasa == 0)
                {
                    lbl_ContadoCasaNum.Visible = false;
                    txt_ContadoCasaNum.Visible = false;
                }

                if (contCreditoNuevoMay == 0)
                {
                    lbl_CreditoNuevoMayNum.Visible = false;
                    txt_CreditoNuevoMayNum.Visible = false;
                }

                dgv_TablaMovimientos_SelectionChanged_1(null, null);

                //DesabilitarControles(true);
                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    DesabilitarControles(true);
                }

                dgv_TablaMovimientos.Select();

                if (gbx_Eventos.Visible == false)
                {
                    int height = 80;
                    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                        if (height < 320)
                            height += item.Height;
                    dgv_TablaMovimientos.Height = height;
                    gbx_TableroPr.Height = height + 60;
                    panel_MovsPr.Height = height + 60;
                }
                else
                {
                    int height = 80;
                    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                        if (height < 230)
                            height += item.Height;
                    dgv_TablaMovimientos.Height = height;
                    gbx_TableroPr.Height = height + 60;
                    panel_MovsPr.Height = height + 60;
                }

                dgv_TablaMovimientos.Columns["ReferenciaAnterior"].Width = 180;
                dgv_TablaMovimientos.Columns["FechaAlta"].Width = 130;
                dgv_TablaMovimientos.Columns["EstatusEnvio"].Width = 124;
                dgv_TablaMovimientos.Columns["VtaCambaceo"].Width = 140;
                dgv_TablaMovimientos.Columns["ImporteTotal"].Width = 130;
                dgv_TablaMovimientos.Columns["TipoCliente"].Width = 130;
                dgv_TablaMovimientos.Columns["FechaUltimaMod"].Width = 140;
                dgv_TablaMovimientos.Columns["TipoCredito"].Width = 130;
                dgv_TablaMovimientos.Columns["TipoEntrega"].Width = 140;
                dgv_TablaMovimientos.Columns["ImporteTotal"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
                ////Agregar columna ClienteFinal cuando sea usuario "CREDI"
                if (ClaseEstatica.Usuario.Usser.Substring(0, 5) == "CREDI")
                {
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Width = 250;
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Visible = true;
                }
                else ////Caso contrario ocultar la columna ClienteFinal
                {
                    dgv_TablaMovimientos.Columns["ClienteFinal"].Visible = false;
                }

                GetSetColumWidth(true);
                if (dgv_Eventos.Visible)
                    flp_PanelEventos.Visible = true;
                else
                    flp_PanelEventos.Visible = false;
                AsyncRunning = false;
                dgv_Contactos.DataSource = null;
                gbx_Contactos.Visible = false;
            }
        }


        private void investigaciónTelefonicaCRTTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int CodContacto = 0;

            string TipoContacto = string.Empty;

            CodContacto = Convert.ToInt32(dgv_Contactos.SelectedCells[0].Value);

            TipoContacto = dgv_Contactos.SelectedCells[1].Value.ToString();

            if (CodContacto > 0)
            {
                InvestigacionTelefonica telefonica = new InvestigacionTelefonica(TipoContacto);

                telefonica.cuenta = ModelSeleccionado.Cliente;
                telefonica.Agente = ClaseEstatica.AgenteU;
                telefonica.IdContacto = CodContacto;
                telefonica.TipoContacto = TipoContacto;
                telefonica.Mov = ModelSeleccionado.Mov;
                telefonica.MovId = ModelSeleccionado.MovId;
                telefonica.IdVenta = ModelSeleccionado.ID;
                telefonica.ShowDialog();
            }
        }


        private void btn_Nuevo_Click(object sender, EventArgs e)
        {
            //ValidarBloqueoCargaPrecios();
            nuevaVenta();
        }


        /// <summary>
        ///     Permite llenar el combobox  Movimiento
        /// </summary>
        public void cbx_movimiento_FillCombo()
        {
            List<string> movimiento = new List<string>();
            movimiento = controllerExplorador.ComboMovimiento(ClaseEstatica.Usuario.Usser);
            foreach (string data in movimiento) cbx_movimiento.Items.Add(data);
        }


        /// <summary>
        ///     Permite llenar DataGrid Eventos
        ///     Developer: Victor Avila
        ///     Date: 2017/06/01
        ///     <retur>void</retur>
        /// </summary>
        private void FillDataGridEventos()
        {
            // GESSY 1286
            if (dgv_TablaMovimientos.Rows.Count > 0 && ModelSeleccionado.Mov != string.Empty &&
                ModelSeleccionado.ID != 0)
                try
                {
                    dgv_Eventos.DataSource = null;
                    dgv_Eventos.DataSource =
                        controllerExplorador.FillDataGridEventos(ModelSeleccionado.ID, ModelSeleccionado.Mov);
                    ;
                    dgv_Eventos.Columns["Clave"].Visible = false;
                    dgv_Eventos.Columns["id"].Visible = false;
                    dgv_Eventos.Columns["rid"].Visible = false;
                    if (usuarioVenta == "CREDI")
                    {
                        dgv_Eventos.Columns["Usuario"].Visible = true;
                    }
                    else
                    {
                        for (int fila = dgv_Eventos.Rows.Count - 1; fila >= 0; fila--)
                            if (new[] { "MEN06207", "MEN06208", "MEN06209", "MEN06210", "MEN06211", "MEN06239" }
                                    .Contains(dgv_Eventos.Rows[fila].Cells["Clave"].Value) && usuarioVenta != "CREDI")
                            {
                                dgv_Eventos.Rows.RemoveAt(fila);
                            }
                            else
                            {
                                if (dgv_Eventos.Rows[fila].Cells["Observaciones"].Value != null)
                                    if (dgv_Eventos.Rows[fila].Cells["Observaciones"].Value.ToString() ==
                                        "Rastreo automático")
                                        if (dgv_Eventos.Rows[fila].Cells["Calificacion"].Value.ToString()
                                                .Contains("MEN07005")
                                            || dgv_Eventos.Rows[fila].Cells["Calificacion"].Value.ToString()
                                                .Contains("MEN07006"))
                                            dgv_Eventos.Rows.RemoveAt(fila);
                            }

                        dgv_Eventos.Columns["Usuario"].Visible = false;
                    }

                    if (dgv_Eventos.Rows.Count == 0)
                        flp_PanelEventos.Visible = false;
                    else
                        flp_PanelEventos.Visible = true;

                    int height = 50;
                    foreach (DataGridViewRow item in dgv_Eventos.Rows)
                        if (height < 260)
                            height += item.Height;
                    dgv_Eventos.Height = height;
                    gbx_Eventos.Height = height + 30;
                    flp_PanelEventos.Height = height + 38;
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message +
                                    "function: FillDataGridEventos, class: DM0312_ExploradorVentas.cs");
                }
        }

        private void InformacionContactosTablero()
        {
            DM0312_C_Contactos ConsultarContactos = new DM0312_C_Contactos();
            try
            {
                DataTable list = new DataTable();
                list = ConsultarContactos.DatosContactos(ModelSeleccionado.Cliente);
                dgv_Contactos.DataSource = null;
                dgv_Contactos.DataSource = list;
                dgv_Contactos.Columns[0].Visible = false;
                Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_ExploradorVentas", ex);
            }
        }

        private void dtp_Afecha_ValueChanged(object sender, EventArgs e)
        {
            cbx_fechaA.Text = dtp_Afecha.Text;
        }

        private void dtp_DeFecha_ValueChanged(object sender, EventArgs e)
        {
            //if (dtp_DeFecha.Value <= dtp_Afecha.Value)
            //{
            cbx_fechaD.Text = dtp_DeFecha.Text;
            //}
            //else
            //    MessageBox.Show("No puedes seleccionar una fecha mayor a la fecha final", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txt_Buscar_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta
                buscar = ListaExploradorVenta.Where(x => x.Campo.Equals("Buscar")).FirstOrDefault();
            txt_ComentarioAyuda.Text = buscar.Comentario;
        }

        private void cbx_En_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta en = ListaExploradorVenta.Where(x => x.Campo.Equals("En")).FirstOrDefault();
            txt_ComentarioAyuda.Text = en.Comentario;
        }

        private void cbx_movimiento_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta mov = ListaExploradorVenta.Where(x => x.Campo.Equals("Movimiento"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = mov.Comentario;
        }

        private void cbx_situacion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta situacion =
                ListaExploradorVenta.Where(x => x.Campo.Equals("Situacion")).FirstOrDefault();
            txt_ComentarioAyuda.Text = situacion.Comentario;
        }

        private void cbx_estatus_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta estatus =
                ListaExploradorVenta.Where(x => x.Campo.Equals("Estatus")).FirstOrDefault();
            txt_ComentarioAyuda.Text = estatus.Comentario;
        }

        private void cbx_fechaD_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fechaD = ListaExploradorVenta.Where(x => x.Campo.Equals("De la Fecha"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = fechaD.Comentario;
        }

        private void cbx_fechaA_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fechaA = ListaExploradorVenta.Where(x => x.Campo.Equals("A la Fecha"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = fechaA.Comentario;
        }

        private void cbx_CreditoCasaMayoreo_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta creditoCasa =
                ListaExploradorVenta.Where(x => x.Campo.Equals("Credito Casa May")).FirstOrDefault();
            txt_ComentarioAyuda.Text = creditoCasa.Comentario;
        }

        private void cbx_creditoNuevoMayoreo_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta creditoNuevo =
                ListaExploradorVenta.Where(x => x.Campo.Equals("Credito")).FirstOrDefault();
            txt_ComentarioAyuda.Text = creditoNuevo.Comentario;
        }

        private void chk_Todos_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta todos = ListaExploradorVenta.Where(x => x.Campo.Equals("todos")).FirstOrDefault();
            txt_ComentarioAyuda.Text = todos.Comentario;
        }

        private void Tablero_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Tablero_Scroll(object sender, ScrollEventArgs e)
        {
            pnlfix_delfix.Location = new Point(-1, 30);
            SPID.Location = new Point(12, 5);
        }

        public void LlenarTipoCredito()
        {
            try
            {
                datosTipoCredito = new List<string>();
                datosTipoCredito = controllerExplorador.LlenaTipoCredito();
                if (datosTipoCredito.Count > 0)
                {
                    listTipoCredito.DataSource = null;
                    listTipoCredito.DataSource = datosTipoCredito.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarTipoCredito", "DM0312_ExploradorVentas", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void chk_CreditoN_CheckedChanged_1(object sender, EventArgs e)
        {
            string validaUsuario = ClaseEstatica.Usuario.Usser.Substring(0, 5);

            if (chk_CreditoNuevo.Checked)
            {
                if (validaUsuario == "CREDI")
                {
                    listTipoCredito.Visible = true;
                    lbl_TipoCredito.Visible = true;
                }

                chk_CreditoNuevo.FlatStyle = FlatStyle.Flat;
                chk_CreditoNuevo.ForeColor = Color.Maroon;

                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta creditoN = ListaExploradorVenta.Where(x => x.Campo.Equals("Credito Nuevo"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = creditoN.Comentario;
                }
            }
            else
            {
                if (chk_CreditoCasa.Checked)
                {
                    if (validaUsuario == "CREDI")
                    {
                        listTipoCredito.Visible = true;
                        lbl_TipoCredito.Visible = true;
                    }
                }
                else
                {
                    listTipoCredito.Visible = false;
                    lbl_TipoCredito.Visible = false;
                    chk_CreditoNuevo.ForeColor = Color.Black;
                }
            }

            noCheckedAndFiltering();
            filterStringsCheckedChanged(sender, e);
            if (!FormIsInLoad) TableroMovimientos();
            dgv_Eventos.DataSource = null;
        }

        private void chk_CreditoC_CheckedChanged_1(object sender, EventArgs e)
        {
            string validaUsuario = ClaseEstatica.Usuario.Usser.Substring(0, 5);

            if (chk_CreditoCasa.Checked)
            {
                if (validaUsuario == "CREDI")
                {
                    listTipoCredito.Visible = true;
                    lbl_TipoCredito.Visible = true;
                }

                chk_CreditoCasa.FlatStyle = FlatStyle.Flat;
                chk_CreditoCasa.ForeColor = Color.Navy;

                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta creditoC = ListaExploradorVenta.Where(x => x.Campo.Equals("Credito Casa"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = creditoC.Comentario;
                }
            }
            else
            {
                if (chk_CreditoNuevo.Checked)
                    if (validaUsuario == "CREDI")
                    {
                        listTipoCredito.Visible = true;
                        lbl_TipoCredito.Visible = true;
                    }
            }

            noCheckedAndFiltering();
            filterStringsCheckedChanged(sender, e);
            if (!FormIsInLoad) TableroMovimientos();
            dgv_Eventos.DataSource = null;
        }

        private void gbx_TablaPrincipal_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.Clear(Color.White);
        }

        private void gbx_Eventos_Paint(object sender, PaintEventArgs e)
        {
        }

        private void gbx_menu_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_Filtros_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_Detalle_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.Clear(Color.White);
        }

        private void nuevoCrtlNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nuevaVenta();
        }

        private void gbx_FotoCliente_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.Clear(Color.White);
        }

        private void cbx_situacion_DropDown_1(object sender, EventArgs e)
        {
            cbx_situacion.Items.Clear();
            cbx_situacion.Refresh();
            List<string> situacion = new List<string>();
            situacion = controllerExplorador.ComboSituacion(this);
            if (situacion.Count > 0)
                foreach (string data in situacion)
                    cbx_situacion.Items.Add(data);
            else
                cbx_situacion.Items.Add("");
        }

        private void gbx_Contactos_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void dgv_TablaMovimientos_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv_TablaMovimientos.CurrentRow != null)
            {
                txt_ComentarioAyuda.Text = ModelSeleccionado.Bandera;
                FillDataGridEventos();

                //-Dineralia
                //ModelSeleccionado = ListaExplorador.FirstOrDefault();
                if (ModelSeleccionado.Mov == "Analisis Credito" && int.Parse(ModelSeleccionado.EnviarA) == 77)
                    btnDineralia.Enabled = true;
                else
                    btnDineralia.Enabled = false;
                gbx_Contactos.Visible = false;
                if (ModelSeleccionado != null)
                {
                    if ((string.IsNullOrEmpty(ModelSeleccionado.MovId) ||
                         !new[] { "76", "80" }.Contains(ModelSeleccionado.EnviarA))
                        && !new[] { "SOLICITUD CREDITO", "ANALISIS CREDITO" }.Contains(ModelSeleccionado.Mov.ToUpper()))
                    {
                        ttCargaPPC.Visible = false;
                    }
                    else
                    {
                        if (new[] { "VENTP", "VENTR" }.Contains(getTipoUsuario())) ttCargaPPC.Visible = true;
                    }
                }
            }
        }

        private void DM0312_ExploradorVentas_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmLoading.Dispose();
            Environment.Exit(Environment.ExitCode);
        }

        public void dgv_TablaMovimientos_SelectionChanged_1(object sender, EventArgs e)
        {
            if (validaAcceso)
            {
                /*Lista estatica de los elementos seleccionados*/
                ListaExplorador = new List<DM0312_MExploradorVenta>();

                for (int i = 0; i < dgv_TablaMovimientos.SelectedRows.Count; i++)
                {
                    DM0312_MExploradorVenta model_ = new DM0312_MExploradorVenta();
                    model_ = (DM0312_MExploradorVenta)dgv_TablaMovimientos.SelectedRows[i].DataBoundItem;
                    ListaExplorador.Add(model_);
                }

                /*modelo estatico sacado de la lista*/
                ModelSeleccionado = ListaExplorador.FirstOrDefault();
                btn_RegistroHuella.Enabled = false;


                txt_DetalleAlmacen.Text = string.Empty;
                txt_Condicion.Text = string.Empty;
                txt_DetalleReferencia.Text = string.Empty;
                txt_DetalleEmbarqueMov.Text = string.Empty;
                txt_DetalleConcepto.Text = string.Empty;
                if (dgv_TablaMovimientos.SelectedRows.Count > 0)
                {
                    controllerExplorador.FillDetalleMovimiento(txt_DetalleAlmacen, txt_Condicion,
                        Detalles, txt_DetalleReferencia, cbx_estatus, lbl_Embarque, txt_DetalleEmbarqueMov,
                        dgv_TablaDetalle, cbx_movimiento, txt_DetalleConcepto, lbl_Concepto, txt_DetalleEmbarqueFecha,
                        lbl_Referencia);
                    FillDataGridEventos();

                    //if (usuarioVenta == "CREDI")
                    //{
                    //    string recuperacion = controllerExplorador.FporcentajeSup(ModelSeleccionado.Cliente);
                    //    txt_ComentarioAyuda.Text = ModelSeleccionado.Bandera + "     Porcentaje de Supervision  " + recuperacion + "%";
                    //}
                    //else
                    //{
                    txt_ComentarioAyuda.Text = ModelSeleccionado.Bandera;
                    //}

                    GetDescripcion();
                }

                gbx_DocumentosAdj.Visible = false;

                if (btn_RegistroHuella.Visible)
                {
                    txtFecha.Text = "";
                    txtIdentificacion.Text = "";
                    txtMotivo.Text = "";
                    chk_Valido.Checked = false;
                    imgBoxCta.Image = null;

                    ClaseEstatica.ListaAnexoCta = new List<DM0312_MAnexoCta>();
                    ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();

                    /*Registro Huellas*/
                    btn_RegistroHuella.Enabled = true;
                    Sucursal = "Todas";
                    LlenarHuellasyFotosPorMov();
                }
                else
                {
                    gbx_FotoCliente.Visible = false;
                }

                PuedeAfectar();

                if (dgv_Eventos.Visible)
                    flp_PanelEventos.Visible = true;
                else
                    flp_PanelEventos.Visible = false;
                if (ModelSeleccionado != null)
                {
                    if ((string.IsNullOrEmpty(ModelSeleccionado.MovId) ||
                         !new[] { "76", "80" }.Contains(ModelSeleccionado.EnviarA))
                        && !new[] { "SOLICITUD CREDITO", "ANALISIS CREDITO" }.Contains(ModelSeleccionado.Mov.ToUpper()))
                    {
                        ttCargaPPC.Visible = false;
                    }
                    else
                    {
                        if (new[] { "VENTP", "VENTR" }.Contains(getTipoUsuario())) ttCargaPPC.Visible = true;
                    }
                }
            }

            //if (gbx_Eventos.Visible == false)
            //{
            //    var height = 80;
            //    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
            //    {
            //        if (height < 320)
            //            height += item.Height;
            //    }
            //    dgv_TablaMovimientos.Height = height;
            //    gbx_TableroPr.Height = height + 60;
            //    panel_MovsPr.Height = height + 60;
            //}
            //else
            //{
            //    var height = 80;
            //    foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
            //    {
            //        if (height < 230)
            //            height += item.Height;
            //    }
            //    dgv_TablaMovimientos.Height = height;
            //    gbx_TableroPr.Height = height + 60;
            //    panel_MovsPr.Height = height + 60;
            //}
        }

        private void chk_ContadoNuevo_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (chk_ContadoNuevo.Checked)
            {
                chk_ContadoNuevo.FlatStyle = FlatStyle.Flat;
                chk_ContadoNuevo.ForeColor = Color.Maroon;
                if (!FormIsInLoad) TableroMovimientos();

                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta contadoN = ListaExploradorVenta.Where(x => x.Campo.Equals("Contado Nuevo"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = contadoN.Comentario;
                }
            }
            else
            {
                chk_ContadoNuevo.ForeColor = Color.Black;
                TableroMovimientos();
                noCheckedAndFiltering();
            }

            dgv_Eventos.DataSource = null;
        }

        private void chk_ContadoCasa_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (chk_ContadoCasa.Checked)
            {
                chk_ContadoCasa.FlatStyle = FlatStyle.Flat;
                chk_ContadoCasa.ForeColor = Color.Navy;
                if (!FormIsInLoad) TableroMovimientos();
                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta contadoC = ListaExploradorVenta.Where(x => x.Campo.Equals("Contado Casa"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = contadoC.Comentario;
                }
            }
            else
            {
                chk_ContadoCasa.ForeColor = Color.Black;
                TableroMovimientos();
                noCheckedAndFiltering();
            }

            dgv_Eventos.DataSource = null;
        }

        private void chk_CreditoCasaMayoreo_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (cbx_CreditoCasaMayoreo.Checked)
            {
                cbx_CreditoCasaMayoreo.FlatStyle = FlatStyle.Flat;
                cbx_CreditoCasaMayoreo.ForeColor = Color.Navy;
                TableroMovimientos();
            }
            else
            {
                cbx_CreditoCasaMayoreo.ForeColor = Color.Black;
                TableroMovimientos();
            }

            dgv_Eventos.DataSource = null;
        }

        private void chk_creditoNuevoMayoreo_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (cbx_creditoNuevoMayoreo.Checked)
            {
                cbx_creditoNuevoMayoreo.FlatStyle = FlatStyle.Flat;
                cbx_creditoNuevoMayoreo.ForeColor = Color.Maroon;
                TableroMovimientos();
            }
            else
            {
                cbx_creditoNuevoMayoreo.ForeColor = Color.Black;
                TableroMovimientos();
            }

            dgv_Eventos.DataSource = null;
        }

        private void cbx_estatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_estatus.Text == "SinAfectar")
                Panel_TiposVenta.Visible = false;
            else
                Panel_TiposVenta.Visible = true;
            if (!FormIsInLoad) TableroMovimientos();
        }

        /// <summary>
        ///     Metodo para mostrar / ocultar columnas de usuario
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 22/07/17
        private void ShowColumns()
        {
            PosicionColumna = ConfigColumnas.AccesoColumnas.OrderBy(x => x.Orden).ToList();
            try
            {
                foreach (AccesoColumnas Columna in PosicionColumna)
                    if (dgv_TablaMovimientos.Columns.Contains(Columna.NombreColumna))
                    {
                        if (Columna.Estatus)
                        {
                            dgv_TablaMovimientos.Columns[Columna.NombreColumna].DisplayIndex = Columna.Orden;
                            dgv_TablaMovimientos.Columns[Columna.NombreColumna].Visible = true;
                        }
                        else
                        {
                            dgv_TablaMovimientos.Columns[Columna.NombreColumna].Visible = false;
                        }
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ShowColumns", "DM0312_CPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void agregarEventoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DM0312_AgregarEvento agregaEvento = new DM0312_AgregarEvento();
            DM0312_AgregarEvento.list.Clear();
            agregaEvento.recibeIdVenta = Convert.ToString(ModelSeleccionado.ID);
            agregaEvento.recibeUsuario = ClaseEstatica.Usuario.Usser;
            agregaEvento.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
            agregaEvento.recibeEstatus = ModelSeleccionado.Estatus;
            agregaEvento.recibeSituacion = ModelSeleccionado.Situacion;
            agregaEvento.recibeCliente = ModelSeleccionado.Cliente;
            agregaEvento.recibeMovId = ModelSeleccionado.MovId;
            agregaEvento.recibeIdecommerce = ModelSeleccionado.IDEcommerce;
            agregaEvento.iCanalVenta = int.Parse(ModelSeleccionado.EnviarA);
            agregaEvento.recibeMov = ModelSeleccionado.Mov;
            agregaEvento.recibeMensaje = 1;
            agregaEvento.Show();
        }

        private void chk_Devolucion_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Devolucion.Checked)
            {
                Devolver = true;
                TableroMovimientos();
            }
            else
            {
                Devolver = false;
                TableroMovimientos();
            }
        }

        private void chk_MA_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (chk_MA.Checked)
            {
                TableroMovimientos();

                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta ma = ListaExploradorVenta.Where(x => x.Campo.Equals("MA"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = ma.Comentario;
                }
            }
            else
            {
                TableroMovimientos();
                noCheckedAndFiltering();
            }

            dgv_Eventos.DataSource = null;
        }

        private void chk_MAVI_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (chk_MAVI.Checked)
            {
                TableroMovimientos();

                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta mavi = ListaExploradorVenta.Where(x => x.Campo.Equals("MAVI"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = mavi.Comentario;
                }
            }
            else
            {
                TableroMovimientos();


                noCheckedAndFiltering();
            }

            dgv_Eventos.DataSource = null;
        }

        private void chk_VIU_CheckedChanged(object sender, EventArgs e)
        {
            filterStringsCheckedChanged(sender, e);
            if (chk_VIU.Checked)
            {
                TableroMovimientos();
                if (txt_ComentarioAyuda.Text == "")
                {
                    DM0312_MComentariosVenta viu = ListaExploradorVenta.Where(x => x.Campo.Equals("VIU"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = viu.Comentario;
                }
            }
            else
            {
                TableroMovimientos();

                noCheckedAndFiltering();
            }

            dgv_Eventos.DataSource = null;
        }

        // 1286 Refactorizar filtros de Busqueda en cheks
        private void filterStringsCheckedChanged(object sender, EventArgs e)
        {
            if (((CheckBox)sender).Name == "chk_CreditoNuevo")
                chk_CrediN = ((CheckBox)sender).Checked ? "Credito Nuevo" : "";

            if (((CheckBox)sender).Name == "chk_CreditoCasa")
                chk_CrediC = ((CheckBox)sender).Checked ? "Credito Casa" : "";

            if (((CheckBox)sender).Name == "chk_ContadoNuevo")
                chk_ContaN = ((CheckBox)sender).Checked ? "Contado Nuevo" : "";

            if (((CheckBox)sender).Name == "chk_ContadoCasa")
                chk_ContaC = ((CheckBox)sender).Checked ? "Contado Casa" : "";

            if (((CheckBox)sender).Name == "cbx_CreditoCasaMayoreo")
                chk_CrediC_May = ((CheckBox)sender).Checked ? "Credito CasaM" : "";

            if (((CheckBox)sender).Name == "cbx_creditoNuevoMayoreo") chk_CrediN_May = "Credito NuevoM";

            if (((CheckBox)sender).Name == "chk_MA") chk_MA_ = ((CheckBox)sender).Checked ? "MA" : "";

            if (((CheckBox)sender).Name == "chk_MAVI") chk_MAVI_ = ((CheckBox)sender).Checked ? "MAVI" : "";

            if (((CheckBox)sender).Name == "chk_VIU") chk_VIU_ = ((CheckBox)sender).Checked ? "VIU" : "";
        }

        private void chks_filterChanges(object sender, EventArgs e)
        {
            if (((CheckBox)sender).Checked)
            {
                //chk_CreditoNuevo
                if (((CheckBox)sender).Name == "chk_CreditoNuevo")
                {
                    if (getTipoUsuario() == "CREDI")
                    {
                        listTipoCredito.Visible = true;
                        lbl_TipoCredito.Visible = true;
                        LlenarTipoCredito();
                    }

                    chk_CreditoNuevo.FlatStyle = FlatStyle.Flat;
                    chk_CreditoNuevo.ForeColor = Color.Maroon;
                    if (!FormIsInLoad) TableroMovimientos();

                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta creditoN = ListaExploradorVenta
                            .Where(x => x.Campo.Equals("Credito Nuevo"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = creditoN.Comentario;
                    }
                }

                //chk_CreditoCasa
                if (((CheckBox)sender).Name == "chk_CreditoCasa")
                {
                    chk_CreditoCasa.FlatStyle = FlatStyle.Flat;
                    chk_CreditoCasa.ForeColor = Color.Navy;
                    if (!FormIsInLoad) TableroMovimientos();

                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta creditoC = ListaExploradorVenta
                            .Where(x => x.Campo.Equals("Credito Casa")).FirstOrDefault();
                        txt_ComentarioAyuda.Text = creditoC.Comentario;
                    }
                }

                //chk_ContadoNuevo
                if (((CheckBox)sender).Name == "chk_ContadoNuevo")
                {
                    chk_ContadoNuevo.FlatStyle = FlatStyle.Flat;
                    chk_ContadoNuevo.ForeColor = Color.Maroon;
                    if (!FormIsInLoad) TableroMovimientos();

                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta contadoN = ListaExploradorVenta
                            .Where(x => x.Campo.Equals("Contado Nuevo"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = contadoN.Comentario;
                    }
                }

                //chk_ContadoCasa
                if (((CheckBox)sender).Name == "chk_ContadoCasa")
                {
                    chk_ContadoCasa.FlatStyle = FlatStyle.Flat;
                    chk_ContadoCasa.ForeColor = Color.Navy;
                    if (!FormIsInLoad) TableroMovimientos();

                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta contadoC = ListaExploradorVenta
                            .Where(x => x.Campo.Equals("Contado Casa")).FirstOrDefault();
                        txt_ComentarioAyuda.Text = contadoC.Comentario;
                    }
                }

                //cbx_CreditoCasaMayoreo
                if (((CheckBox)sender).Name == "cbx_CreditoCasaMayoreo")
                {
                    cbx_CreditoCasaMayoreo.FlatStyle = FlatStyle.Flat;
                    cbx_CreditoCasaMayoreo.ForeColor = Color.Navy;
                    TableroMovimientos();
                }

                //chk_creditoNuevoMayoreo
                if (((CheckBox)sender).Name == "chk_creditoNuevoMayoreo")
                {
                    cbx_creditoNuevoMayoreo.FlatStyle = FlatStyle.Flat;
                    cbx_creditoNuevoMayoreo.ForeColor = Color.Maroon;
                    TableroMovimientos();
                }


                //chk_MA
                if (((CheckBox)sender).Name == "chk_MA")
                {
                    TableroMovimientos();
                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta ma = ListaExploradorVenta.Where(x => x.Campo.Equals("MA"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = ma.Comentario;
                    }
                }

                if (((CheckBox)sender).Name == "FiltroGetse")
                {
                    TableroMovimientos();
                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta ma = ListaExploradorVenta.Where(x => x.Campo.Equals("FiltroGetse"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = ma.Comentario;
                    }
                }

                //chk_MAVI
                if (((CheckBox)sender).Name == "chk_MAVI")
                {
                    TableroMovimientos();
                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta mavi = ListaExploradorVenta.Where(x => x.Campo.Equals("MAVI"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = mavi.Comentario;
                    }
                }

                //chk_VIU
                if (((CheckBox)sender).Name == "chk_VIU")
                {
                    TableroMovimientos();
                    if (txt_ComentarioAyuda.Text == "")
                    {
                        DM0312_MComentariosVenta viu = ListaExploradorVenta.Where(x => x.Campo.Equals("VIU"))
                            .FirstOrDefault();
                        txt_ComentarioAyuda.Text = viu.Comentario;
                    }
                }
            }
            else
            {
                noCheckedAndFiltering();

                if (((CheckBox)sender).Name == "cbx_CreditoCasaMayoreo") cbx_CreditoCasaMayoreo.ForeColor = Color.Black;

                if (((CheckBox)sender).Name == "chk_creditoNuevoMayoreo")
                    cbx_creditoNuevoMayoreo.ForeColor = Color.Black;

                TableroMovimientos();
            }

            dgv_Eventos.DataSource = null;
        }

        private void noCheckedAndFiltering()
        {
            if (chk_ContadoNuevo.Checked)
            {
                DM0312_MComentariosVenta contadoN =
                    ListaExploradorVenta.Where(x => x.Campo.Equals("Contado Nuevo")).FirstOrDefault();
                txt_ComentarioAyuda.Text = contadoN.Comentario;
            }
            else if (chk_ContadoCasa.Checked)
            {
                DM0312_MComentariosVenta contadoC =
                    ListaExploradorVenta.Where(x => x.Campo.Equals("Contado Casa")).FirstOrDefault();
                txt_ComentarioAyuda.Text = contadoC.Comentario;
            }
            else if (chk_CreditoNuevo.Checked)
            {
                DM0312_MComentariosVenta creditoN =
                    ListaExploradorVenta.Where(x => x.Campo.Equals("Credito Nuevo")).FirstOrDefault();
                txt_ComentarioAyuda.Text = creditoN.Comentario;
            }
            else if (chk_CreditoCasa.Checked)
            {
                DM0312_MComentariosVenta creditoC =
                    ListaExploradorVenta.Where(x => x.Campo.Equals("Credito Casa")).FirstOrDefault();
                txt_ComentarioAyuda.Text = creditoC.Comentario;
            }
            else if (chk_MA.Checked)
            {
                DM0312_MComentariosVenta ma = ListaExploradorVenta.Where(x => x.Campo.Equals("MA")).FirstOrDefault();
                txt_ComentarioAyuda.Text = ma.Comentario;
            }
            else if (chk_MAVI.Checked)
            {
                DM0312_MComentariosVenta mavi = ListaExploradorVenta.Where(x => x.Campo.Equals("MAVI"))
                    .FirstOrDefault();
                txt_ComentarioAyuda.Text = mavi.Comentario;
            }
            else if (chk_VIU.Checked)
            {
                DM0312_MComentariosVenta viu = ListaExploradorVenta.Where(x => x.Campo.Equals("VIU")).FirstOrDefault();
                txt_ComentarioAyuda.Text = viu.Comentario;
            }
            else if (chk_VIU.Checked)
            {
                DM0312_MComentariosVenta viu = ListaExploradorVenta.Where(x => x.Campo.Equals("ReactivacionLiberacion"))
                    .FirstOrDefault();
                txt_ComentarioAyuda.Text = viu.Comentario;
            }
        }

        private void txt_Sucursal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void dgv_TablaMovimientos_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            index = 0;
            index = dgv_TablaMovimientos.CurrentRow.Index;
            FillDataGridEventos();
        }

        public string OptieneSucursal()
        {
            string temp = "";
            DM0312_CSucursal sucursal = new DM0312_CSucursal();
            List<DM0312_MSucursal> list = sucursal.ObtenerSucursales();
            if (txt_Sucursal.Text != "" && !Regex.IsMatch(txt_Sucursal.Text, "[^0-9]"))
                temp = list.Where(x => x.Sucursal == Convert.ToInt32(txt_Sucursal.Text)).Select(x => x.Nombre)
                    .SingleOrDefault();
            return temp;
        }

        private void txt_Sucursal_TextChanged(object sender, EventArgs e)
        {
            if (txt_Sucursal.Text != "")
            {
                tempSucursal = txt_Sucursal.Text;
                nombreSucursal = OptieneSucursal();
                txt_NombreSucursal.Text = nombreSucursal;
            }

            if (txt_Sucursal.Text == "") txt_NombreSucursal.Text = "TODAS LAS SUCURSALES";
        }

        private void cbx_fechaD_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (System.Text.RegularExpressions.Regex.IsMatch(cbx_fechaD.Text, "[^0-9-/-]"))
            //{
            //    MessageBox.Show("Solo Numeros, formato DD/MM/YYYY.");
            //    cbx_fechaD.Text = cbx_fechaD.Text.Remove(cbx_fechaD.Text.Length - 1);        
            //} 
        }

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) TableroMovimientos();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '*')
                e.Handled = false;
            else
                e.Handled = true;
        }

        public void llevarSit()
        {
            cbx_situacion.Items.Clear();
            cbx_situacion.Refresh();
            List<string> situacion = new List<string>();
            situacion = controllerExplorador.ComboSituacion(this);
            if (situacion.Count > 0)
                foreach (string data in situacion)
                    cbx_situacion.Items.Add(data);
            else
                cbx_situacion.Items.Add("");
        }

        private void cbx_movimiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClaseEstatica.ListaAnexoCta = new List<DM0312_MAnexoCta>();
            ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();
            if (!FormIsInLoad)
            {
                llevarSit();
                //cbx_situacion.Text = "";
                TableroMovimientos();
            }
        }

        public void LlenarHuellasyFotosPorMov()
        {
            if (ModelSeleccionado == null)
                return;

            bool bandera = false;
            cte = new DM0312_MRegistroCte();
            cte = controllercte.ExecFuncion(ModelSeleccionado.Cliente, ModelSeleccionado.ID);

            if (cte.IdMov != 0)
            {
                txtFecha.Text = cte.Fecha.ToString();
                txtIdentificacion.Text = cte.Registro;
                txtMotivo.Text = cte.Motivo;
                chk_Valido.Checked = cte.Valido;
                txtFecha.Enabled = false;
                txtIdentificacion.Enabled = false;
                txtMotivo.Enabled = false;
                bandera = true;
            }

            DM0312_CAnexoCta controllercta = new DM0312_CAnexoCta();
            DM0312_MAnexoCta CtaModel = new DM0312_MAnexoCta();
            CtaModel = controllercta.GetFotoActual(ModelSeleccionado.Cliente, ModelSeleccionado.MovId);

            if (CtaModel != null && CtaModel.Imagen.Length > 0)
            {
                if (CtaModel.Imagen != null)
                {
                    MemoryStream ms = new MemoryStream(CtaModel.Imagen);
                    returnImage = Image.FromStream(ms);

                    imgBoxCta.Image = returnImage;

                    bandera = true;
                }
                else
                {
                    imgBoxCta.Image = null;
                }
            }
            else
            {
                imgBoxCta.Image = null;
            }

            gbx_FotoCliente.Visible = bandera;
        }

        public void LlenarHuellasyFotos()
        {
            //frmLoading.Show(this);
            /*Registro Huellas*/
            cte = new DM0312_MRegistroCte();
            ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();
            //ClaseEstatica.ListaCte = await Task.Run(()=> controllercte.FiltrarListas(ModelSeleccionado.Cliente, Sucursal));
            ClaseEstatica.ListaCte = controllercte.FiltrarListas(ModelSeleccionado.Cliente, Sucursal);

            /*Fotos*/
            DM0312_CAnexoCta controllercta = new DM0312_CAnexoCta();
            ClaseEstatica.ListaAnexoCta = new List<DM0312_MAnexoCta>();
            //ClaseEstatica.ListaAnexoCta = await Task.Run(() => controllercta.GetFotos(ModelSeleccionado.Cliente));
            if (codigoclienteFin == "") codigoclienteFin = ModelSeleccionado.Cliente;
            ClaseEstatica.ListaAnexoCta = controllercta.GetFotos(codigoclienteFin);

            //-Historico
            ClaseEstatica.ListaAnexoCtaHistorica = new List<DM0312_MAnexoCta>();
            ClaseEstatica.ListaAnexoCtaHistorica = controllercta.obtenerFotosHistorico(ModelSeleccionado.Cliente);
            codigoclienteFin = "";
            //frmLoading.Hide();
        }

        private void imgBoxCta_Click(object sender, EventArgs e)
        {
            if (returnImage == null)
                return;

            DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();
            int Width = 0;
            int Height = 0;
            Width = returnImage.Width;
            Height = returnImage.Height;
            frm.Imagen = returnImage;
            frm.Height = Height;
            frm.Width = Width;
            frm.ShowDialog();
        }

        private void historialDeFotosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DM0312_ReporteClienteHuellasFotos frm = new DM0312_ReporteClienteHuellasFotos(1);
            DM0312_CAnexoCta controllercta = new DM0312_CAnexoCta();
            ClaseEstatica.ListaAnexoCta = controllercta.GetFotos(ModelSeleccionado.Cliente);
            //frm.Lista = ClaseEstatica.ListaAnexoCta;
            if (ClaseEstatica.ListaAnexoCta.Count == 0)
                MessageBox.Show("El cliente " + ModelSeleccionado.Cliente + " no cuenta con historial de fotografias",
                    "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                frm.ShowDialog();
        }

        private void btnValida_Click(object sender, EventArgs e)
        {
            if (ModelSeleccionado.Cliente == null)
            {
                MessageBox.Show("Debe seleccionar un cliente", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();
                List<DM0312_MRegistroCte> ListaGuardar = new List<DM0312_MRegistroCte>();

                cte = controllercte.ExecFuncion(ModelSeleccionado.Cliente, ModelSeleccionado.ID);

                if (cte.ID == 0)
                {
                    MessageBox.Show("No Existe Información Por Validar", "Aviso!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                    return;
                }

                if (cte.Valido != chk_Valido.Checked)
                {
                    cte.Valido = chk_Valido.Checked;
                    cte.UsuarioValido = lbl_Usuario.Text;
                    ListaGuardar.Add(cte);

                    ClaseEstatica.ListaCte =
                        controllercte.ValidaHuellas(ModelSeleccionado.Cliente, "Todas", ListaGuardar);

                    LlenarHuellasyFotos();
                }
                else
                {
                    MessageBox.Show("No Existen Cambios", "Aviso!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void btn_ResumenFac_Click(object sender, EventArgs e)
        {
            resumenFactura();
        }

        private void btn_PreliminarCobro_Click(object sender, EventArgs e)
        {
            //-CerradoIntelisis
            loginC.checkSession();

            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"\PreliminardeCobro\PreliminarCobro.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + "IntelisisTmp" + " " +
                                              ClaseEstatica.WorkStation;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("btn_PreliminarCobro_Click", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: btn_PreliminarCobro_Click, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void btn_HistoricoUniCaja_Click(object sender, EventArgs e)
        {
            //if (dgv_TablaMovimientos.Rows.Count > 0)
            //{
            try
            {
                string cliente = ModelSeleccionado.Cliente;
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"inte601.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = cliente + " " + "N";
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                //         pTicket.WaitForExit();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("btn_HistoricoUniCaja_Click", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: btn_HistoricoUniCaja_Click class: DM0312_ExploradorVentas.cs");
            }
            //}
            //else
            //{
            //    MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        public void ConsultarExcel()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                bool ValidaExcel = false;

                ValidaExcel = Comprobar();

                if (ValidaExcel)
                    ExcelExport();
                else
                    //ExportToExcel();
                    MessageBox.Show("No tienes instalado Excel, la Operación no se puede realizar", "Error!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConsultarExcel();
        }

        private void btn_KardexCliente_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (ModelSeleccionado.Mov == "Solicitud Credito")
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"Coincidencias\CoincidenciasUI.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + ModelSeleccionado.ID + " " +
                                                      ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.WorkStation +
                                                      " " + ClaseEstatica.Usuario.sucursal;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    else
                    {
                        int idOrigen = controllerExplorador.origenID(ModelSeleccionado.Mov, ModelSeleccionado.MovId);
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"Coincidencias\CoincidenciasUI.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + idOrigen + " " +
                                                      ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.WorkStation +
                                                      " " + ClaseEstatica.Usuario.sucursal;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("btn_KardexCliente_Click", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(
                        ex.Message + " function: btn_KardexCliente_Click, class: DM0312_ExploradorVentas.cs");
                    throw;
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ModelSeleccionado.Usuario + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "SA");
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "SC");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "BA");
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "BC");
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "IA");
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "CLIENTE" +
                                    " " + "IC");
        }

        private void btn_VisorMavi_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                VisorSocioEconomico(controllerExplorador.AgenteUsuario(ClaseEstatica.Usuario.Usser) + " " +
                                    ModelSeleccionado.Cliente + " " + "CLIENTE" + " " + "N");
            else
                VisorSocioEconomico(controllerExplorador.AgenteUsuario(ClaseEstatica.Usuario.Usser) + " " + "VACIO" +
                                    " " + "CLIENTE" + " " + "N");
        }

        /// <summary>
        ///     Metodo que estaba repetido solo cambiaban los argumentos
        /// </summary>
        /// <param name="Argumentos">string</param>
        /// Developer: Dan Palacios
        /// Date: 16/01/18
        private void VisorSocioEconomico(string Argumentos)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\ALCHEMY\\AlchemyII.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = Argumentos;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VisorSocioEconomico", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: VisorSocioEconomico, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void btn_ConsultaBuro_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"IntL603.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + ClaseEstatica.Usuario.Usser + " " +
                                                  "N" + " " + ModelSeleccionado.ID;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.Dispose();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("btn_ConsultaBuro_Click", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message +
                                    " function: btn_ConsultaBuro_Click, class: DM0312_ExploradorVentas.cs");
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void DM0312_ExploradorVentas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.F2)
            {
                if (consultaBuro) ConsultarBuro();
            }
            else if (e.Control && e.KeyCode == Keys.F1)
            {
                if (Excel) ConsultarExcel();
            }
            else if (e.Control && e.KeyCode == Keys.F4)
            {
                if (CopiarCliente)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                        Clipboard.SetDataObject(ModelSeleccionado.Cliente);
                    else
                        MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
            }
            else if (e.Control && e.KeyCode == Keys.F5)
            {
                if (CopiarClienteRelacionado)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                        Clipboard.SetDataObject(ModelSeleccionado.Relacionado);
                    else
                        MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
            }
            else if (e.Control && e.KeyCode == Keys.F6)
            {
                if (CapturaRelacionado)
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        if (controllerExplorador.idCanal(ModelSeleccionado.Canal) == 3 ||
                            controllerExplorador.idCanal(ModelSeleccionado.Canal) == 7)
                        {
                            DM0312_CapRelacionado relacionado = new DM0312_CapRelacionado();
                            relacionado.cliente = ModelSeleccionado.Cliente;
                            relacionado.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Solo permitido para canales 3 o 7 ", "Mensaje!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                    }

                if (getTipoUsuario() == "CREDI") NotificarAnalista_Click(null, null);
            }
            else if (e.Control && e.KeyCode == Keys.F7)
            {
                if (dgv_TablaMovimientos.Rows.Count > 0) modificarVenta();
            }
            else if (e.Control && e.KeyCode == Keys.F8)
            {
                if (CamposExtras) CamposExtrasM();
            }
            else if (e.Control && e.KeyCode == Keys.F3)
            {
                if (MatrizDeAutorizacion) MatrizAutorizacionM();
            }
            else if (e.Control && e.KeyCode == Keys.F9)
            {
                web();
            }
            else if (e.Control && e.KeyCode == Keys.F10)
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                //-CambioPluginsJesus 2019-05-28 se cambio ruta de plugin
                //pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\Inte606.exe";
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\SaldosBF\\BeneficiariosFinales.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            else if (e.Control && e.KeyCode == Keys.F11)
            {
                if (btn_SoporAval.Visible) SoportadosAval();
            }
            else if (e.KeyCode == Keys.F4)
            {
                if (btn_RegistroHuella.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        LlenarHuellasyFotos();
                        RegistroDeHuellaCliente frm = new RegistroDeHuellaCliente();
                        frm.cliente = ModelSeleccionado.Cliente;
                        frm.Usuario = lbl_Usuario.Text;
                        frm.movId = ModelSeleccionado.MovId;
                        frm.mov = ModelSeleccionado.Mov;
                        frm.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                    }
                }
            }
            else if (e.KeyCode == Keys.F3)
            {
                if (btn_HistoSolicitudes.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        foreach (Form forma in Application.OpenForms)
                            if (forma.Name == "HistorialSolicitudes")
                            {
                                forma.Close();
                                break;
                            }

                        HistorialSolicitudes historialSol = new HistorialSolicitudes();
                        historialSol.recibeMensajeUsuario = ClaseEstatica.Usuario.Usser;
                        historialSol.recibeMensajeCliente = ModelSeleccionado.Cliente;
                        historialSol.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                        historialSol.recibeMovId = ModelSeleccionado.MovId;
                        historialSol.recibeCliente = ModelSeleccionado.Cliente;
                        historialSol.recibeMov = ModelSeleccionado.Mov;
                        historialSol.recibeFecha = cbx_fechaA.Text;
                        historialSol.recibeSituacion = ModelSeleccionado.Situacion;
                        historialSol.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                        historialSol.recibeFechaD = cbx_fechaD.Text;
                        historialSol.Show();
                    }
                    else
                    {
                        HistorialSolicitudes historialSol = new HistorialSolicitudes();
                        historialSol.validaFormEmpty = true;
                        historialSol.recibeMensajeUsuario = ClaseEstatica.Usuario.Usser;
                        historialSol.recibeMensajeCliente = ModelSeleccionado.Cliente;
                        historialSol.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                        historialSol.recibeMovId = ModelSeleccionado.MovId;
                        historialSol.recibeCliente = ModelSeleccionado.Cliente;
                        historialSol.recibeMov = ModelSeleccionado.Mov;
                        historialSol.recibeFecha = cbx_fechaA.Text;
                        historialSol.recibeSituacion = ModelSeleccionado.Situacion;
                        historialSol.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                        historialSol.recibeFechaD = cbx_fechaD.Text;
                        historialSol.Show();
                    }
                }
            }
            else if (e.KeyCode == Keys.F9)
            {
                if (btn_ConfColumnas.Visible)
                {
                    ConfiguracionColumnas configColumna = new ConfiguracionColumnas();
                    configColumna.ShowDialog();
                    ShowColumns();
                }
            }
            else if (e.KeyCode == Keys.F12)
            {
                if (btn_PreliminarCobro.Visible)
                {
                    //-CerradoIntelisis
                    loginC.checkSession();

                    try
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName =
                            ClaseEstatica.plugInPath + @"\PreliminardeCobro\PreliminarCobro.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments =
                            recibeMensaje + " " + "IntelisisTmp" + " " + ClaseEstatica.WorkStation;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("DM0312_ExploradorVentas_KeyDown F12",
                            "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: DM0312_ExploradorVentas_KeyDown F12, class:DM0312_ExploradorVentas.cs");
                    }
                }
            }
            else if (e.KeyCode == Keys.F7)
            {
                if (btn_VisorMavi.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                        VisorSocioEconomico(controllerExplorador.AgenteUsuario(ClaseEstatica.Usuario.Usser) + " " +
                                            ModelSeleccionado.Cliente + " " + "CLIENTE" + " " + "N");
                    else
                        VisorSocioEconomico(controllerExplorador.AgenteUsuario(ClaseEstatica.Usuario.Usser) + " " +
                                            "VACIO" + " " + "CLIENTE" + " " + "N");
                }
            }
            else if (e.KeyCode == Keys.F11)
            {
                if (btn_KardexCliente.Visible)
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        if (dgv_TablaMovimientos.Rows.Count > 0)
                        {
                            if (ModelSeleccionado.Mov == "Solicitud Credito")
                            {
                                Process pTicket = new Process();
                                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                                pTicket.StartInfo.FileName =
                                    ClaseEstatica.plugInPath + @"Coincidencias\CoincidenciasUI.exe";
                                pTicket.StartInfo.Verb = "runas";
                                pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + ModelSeleccionado.ID +
                                                              " " + ClaseEstatica.Usuario.usuario + " " +
                                                              ClaseEstatica.WorkStation + " " +
                                                              ClaseEstatica.Usuario.sucursal;
                                pTicket.StartInfo.UseShellExecute = false;
                                pTicket.Start();
                                pTicket.Dispose();
                            }
                            else
                            {
                                int idOrigen =
                                    controllerExplorador.origenID(ModelSeleccionado.Mov, ModelSeleccionado.MovId);
                                Process pTicket = new Process();
                                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                                pTicket.StartInfo.FileName =
                                    ClaseEstatica.plugInPath + @"Coincidencias\CoincidenciasUI.exe";
                                pTicket.StartInfo.Verb = "runas";
                                pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + idOrigen + " " +
                                                              ClaseEstatica.Usuario.usuario + " " +
                                                              ClaseEstatica.WorkStation + " " +
                                                              ClaseEstatica.Usuario.sucursal;
                                pTicket.StartInfo.UseShellExecute = false;
                                pTicket.Start();
                                pTicket.Dispose();
                            }
                        }
                        else
                        {
                            MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                        }
                    }
            }
            else if (e.Control && e.KeyCode == Keys.W)
            {
                btnKardex_Click(null, null);
            }
            else if (e.KeyCode == Keys.F10)
            {
                resumenFactura();
            }
            else if (e.Control && e.KeyCode == Keys.U)
            {
                if (btn_UsuariosTiempos.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        TiemposUsuarios tiemposUsuarios = new TiemposUsuarios();
                        tiemposUsuarios.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                        tiemposUsuarios.recibeMovId = ModelSeleccionado.Movimiento;
                        tiemposUsuarios.recibeMov = Convert.ToString(ModelSeleccionado.MovId);
                        tiemposUsuarios.recibeCliente = ClaseEstatica.Usuario.Usser;
                        tiemposUsuarios.Show();
                    }
                    else
                    {
                        MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.E)
            {
                if (btn_Eventos.Visible) mostrarEventosNotasCitasView();
                /*if (getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR") {
                        mostrarEventosNotasCitasView();
                    }
                    if (getTipoUsuario() == "CREDI") {
                        mostrarfrmEventosReactivacion();
                    }*/
            }
            else if (e.Control && e.KeyCode == Keys.I)
            {
                if (btn_InformacionCliente.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        InformacionCliente infoCliente = new InformacionCliente();
                        int index = dgv_TablaMovimientos.CurrentRow.Index;
                        infoCliente.mensaje = ModelSeleccionado.Cliente;
                        infoCliente.Show();
                    }
                    else
                    {
                        MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.P)
            {
                if (btn_PosicionMov.Visible) PosicionMovM();
            }
            else if (e.Control && e.KeyCode == Keys.K)
            {
                if (Kardexclientefinal) KardexClienteFinalC();
            }
            else if (e.Control && e.KeyCode == Keys.R)
            {
                if (btn_Relaciones.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                    {
                        Relaciones RelacionesC = new Relaciones();
                        RelacionesC.recibeCliente = ModelSeleccionado.Cliente;
                        RelacionesC.ShowDialog();
                        txt_Buscar.Focus();
                    }
                    else
                    {
                        MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.B)
            {
                if (btn_AnalistasCredi.Visible)
                    try
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        //-CambioRutaAnalistas //-(2019-09-04)
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"Analistas\\Analistas.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.usuario;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("btn_AnalistasCredi_Click", "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: btn_AnalistasCredi_Click, class: DM0312_ExploradorVentas.cs");
                    }
            }
            else if (e.KeyCode == Keys.F8)
            {
                if (btn_ConsultaBuro.Visible)
                {
                    if (dgv_TablaMovimientos.Rows.Count > 0)
                        try
                        {
                            Process pTicket = new Process();
                            pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                            pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"IntL603.exe";
                            pTicket.StartInfo.Verb = "runas";
                            pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " +
                                                          ClaseEstatica.Usuario.Usser + " N " + ModelSeleccionado.ID;
                            pTicket.StartInfo.UseShellExecute = false;
                            pTicket.Start();
                            pTicket.Dispose();
                        }
                        catch (Exception ex)
                        {
                            DM0312_ErrorLog.RegistraError("DM0312_ExploradorVentas_KeyDown F8",
                                "DM0312_ExploradorVentas.cs", ex);
                            MessageBox.Show(ex.Message +
                                            " function: DM0312_ExploradorVentas_KeyDown F8, class: DM0312_ExploradorVentas.cs");
                        }
                    else
                        MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                }
            }
            else if (e.KeyCode == Keys.F5)
            {
                TableroMovimientos();
                ClaseEstatica.ListaAnexoCta = new List<DM0312_MAnexoCta>();
                ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();
            }
            else if (e.KeyCode == Keys.F1)
            {
                if (dgv_TablaMovimientos.Rows.Count > 0)
                {
                    if (getTipoUsuario() == "CREDI" || getTipoUsuario() == "VENTP")
                    {
                        DM0312_AgregarEvento.list.Clear();
                        DM0312_ConsultarEvento consultaEvento = new DM0312_ConsultarEvento();
                        AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                        consultaEvento = (DM0312_ConsultarEvento)UsuarioAcceso.AplicarVistas(consultaEvento);
                        consultaEvento.recibeMovId = ModelSeleccionado.MovId;
                        consultaEvento.recibeMov = ModelSeleccionado.Mov;
                        consultaEvento.recibeUsuario = ModelSeleccionado.Usuario;
                        consultaEvento.recibeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                        consultaEvento.opcionForma = 3;
                        consultaEvento.ShowDialog();
                        if (EjecutaEvento)
                            dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos, new DataGridViewCellEventArgs(0, 0));
                    }
                }
                else
                {
                    MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else if (e.KeyCode == Keys.F2)
            {
                if (dgv_TablaMovimientos.Rows.Count > 0)
                {
                    if (getTipoUsuario() == "CREDI" || getTipoUsuario() == "VENTP")
                    {
                        DM0312_AgregarEvento.list.Clear();
                        DM0312_ConsultarEvento consultaEvento = new DM0312_ConsultarEvento();
                        AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                        consultaEvento = (DM0312_ConsultarEvento)UsuarioAcceso.AplicarVistas(consultaEvento);
                        consultaEvento.recibeMovId = ModelSeleccionado.MovId;
                        consultaEvento.recibeCliente = ModelSeleccionado.Cliente;
                        consultaEvento.recibeMov = ModelSeleccionado.Mov;
                        consultaEvento.recibeUsuario = ModelSeleccionado.Usuario;
                        consultaEvento.recibeSituacion = ModelSeleccionado.Situacion;
                        consultaEvento.recibeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                        consultaEvento.opcionForma = 2;
                        consultaEvento.recibeEstatus = ModelSeleccionado.Estatus;
                        consultaEvento.CargarLista();
                        consultaEvento.ShowDialog();
                        if (EjecutaEvento)
                            dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos, new DataGridViewCellEventArgs(0, 0));

                        txt_Buscar.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else if (e.KeyCode == Keys.F6)
            {
                ///ROJOS
                if ((getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR") &&
                    ModelSeleccionado.Estatus == "PENDIENTE" && ModelSeleccionado.Mov == "Analisis Credito")
                    mostrarfrmEventosReactivacion();

                //Normal
                else if (getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR") agregarEvento();

                // GESSY 1286 acceso Normal para Credito
                if (getTipoUsuario() == "CREDI")
                    //mostrarEventosNotasCitasView();
                    agregarEvento();
            }
            else if (e.Control && e.KeyCode == Keys.S)
            {
                if (btn_Selp.Visible)
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\SELP\\SELPDesktop.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.Usuario.Acceso +
                                                  " " + ClaseEstatica.Usuario.Uen + " " +
                                                  ClaseEstatica.Usuario.Sucursal;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.Dispose();
                }
            }
            else if (e.Control && e.KeyCode == Keys.O)
            {
                if (btn_CatalagoCalif.Visible)
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "CatalogoDeCalificaciones")
                        {
                            forma.Close();
                            break;
                        }

                    CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
                    catalogoCalificacion.Show();
                }
            }
            else if (e.Control && e.KeyCode == Keys.Q)
            {
                if (BtnProspectoaCliente.Visible) BtnProspectoaCliente_Click(sender, e);
            }
            else if (e.Control && e.KeyCode == Keys.H)
            {
                if (btn_HistoricoUniCaja.Visible)
                    try
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"inte601.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + "N";
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("DM0312_ExploradorVentas_KeyDown F9",
                            "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: DM0312_ExploradorVentas_KeyDown F9, class: DM0312_ExploradorVentas.cs");
                    }
            }
            else if (e.Control && e.KeyCode == Keys.L)
            {
                if (btn_CalidadCap.Visible) CalidadDeCapturaC();
            }
            else if (e.Control && e.KeyCode == Keys.N)
            {
                nuevaVenta();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            else if (e.Control && e.KeyCode == Keys.T)
            {
                if (tiempototal) TiempoTotalM();
            }
            else if (e.Control && e.KeyCode == Keys.D)
            {
                if (monederoPorRedimir) MonederoXredimirConsulta();
            }
            else if (e.Control && e.KeyCode == Keys.M)
            {
                if (VerActualizacionDeDatos) VerActualizacionDatos();
            }
            else if (e.Control && e.KeyCode == Keys.J)
            {
                if (AgregarActualizacionDatosV) AgregarActualizacionDatos();
            }
            else if (e.Control && e.KeyCode == Keys.A)
            {
                if (RM0855ClienteExpres) ClienteExpressRm0855();
            }
            else if (e.Control && e.KeyCode == Keys.G)
            {
                if (btnDineralia.Enabled) btnDineralia_Click(null, null);
            }
            else if (e.Control && e.KeyCode == Keys.F)
            {
                if (AfectarVisible)
                {
                    //-CerradoIntelisis
                    loginC.checkSession();

                    MenuItem_Afectar_Click(null, null);
                }
            }
            else if (e.Control && e.KeyCode == Keys.Y)
            {
                if (btnScoring.Visible) scoring();
            }
        }

        public void agregarEvento()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                string movEvento = ModelSeleccionado.Mov;
                string estatusEvento = ModelSeleccionado.Estatus;

                DM0312_AgregarEvento.list.Clear();
                DM0312_AgregarEvento.recibeTexto = "";
                DM0312_AgregarEvento AgregEvent = new DM0312_AgregarEvento();
                AgregEvent.recibeMensaje = 1;
                AgregEvent.recibeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                AgregEvent.recibeUsuario = ClaseEstatica.Usuario.Usser;
                AgregEvent.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                AgregEvent.recibeEstatus = ModelSeleccionado.Estatus;
                AgregEvent.recibeMov = ModelSeleccionado.Mov;
                AgregEvent.recibeMovId = ModelSeleccionado.MovId;
                AgregEvent.recibeSituacion = ModelSeleccionado.Situacion;
                AgregEvent.recibeCliente = ModelSeleccionado.Cliente;
                AgregEvent.iCanalVenta = int.Parse(ModelSeleccionado.EnviarA);
                AgregEvent.recibeIdecommerce = ModelSeleccionado.IDEcommerce;
                AgregEvent.ShowDialog();
                if (EjecutaEvento)
                {
                    dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos, new DataGridViewCellEventArgs(0, 0));
                    if (dgv_TablaMovimientos.Rows.Count == 1)
                        TableroMovimientos2(movEvento, ModelSeleccionado.Situacion, estatusEvento,
                            ModelSeleccionado.MovId);
                }

                txt_Buscar.Focus();
            }
            else
            {
                MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        //1286
        private void mostrarfrmEventosReactivacion()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                frmEventoReactivacion ER = new frmEventoReactivacion(ModelSeleccionado);
                ER.ShowDialog();
            }
        }


        private void DM0312_ExploradorVentas_Activated(object sender, EventArgs e)
        {
            if (ClaseEstatica.FormActivo == "Registro Huella")
                LlenarHuellasyFotos();
            ClaseEstatica.FormActivo = "";
        }

        private void dgv_TablaMovimientos_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (!ImporteFormateado)
            {
                foreach (DataGridViewRow drow in dgv_TablaMovimientos.Rows)
                    drow.Cells["ImporteTotal"].Value = Convert.ToDouble(drow.Cells["ImporteTotal"].Value).ToString("C");
                ImporteFormateado = true;
            }
        }

        public void ConsultarBuro()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                if (ModelSeleccionado.Mov == "Solicitud Credito")
                    try
                    {
                        //Process pTicket = new Process();
                        //pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath + "SHM\\";
                        //pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "SHM\\" + @"SHM.exe";
                        //pTicket.StartInfo.Verb = "runas";
                        //pTicket.StartInfo.Arguments = "CONSULTAR" + " " +ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " "  + "Solicitud_Credito " + " " + ModelSeleccionado.MovId + " " + 1;
                        //pTicket.StartInfo.UseShellExecute = false;
                        //pTicket.Start();
                        //pTicket.Dispose();
                        if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                        {
                            Process System = new Process();
                            System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                            System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                            System.StartInfo.Verb = "runas";
                            System.StartInfo.Arguments = "CONSULTAR" + " " + ClaseEstatica.Usuario.Usser + " " +
                                                         ModelSeleccionado.Cliente + " " + "Solicitud_Credito " + " " +
                                                         ModelSeleccionado.MovId + " " + 1;
                            //"CAPTURARHOJAVERDE" + " " + txt_Cliente.Text + " " + VentasSeleccionadas[PaginadoActual].MovId + " " + txt_Total.Text.Replace("$", "");
                            System.StartInfo.UseShellExecute = false;
                            System.Start();
                            //-Revision de Procesos 2019-05-28
                            //System.WaitForExit();
                        }
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("consultarBuroToolStripMenuItem_Click",
                            "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: DM0312_ExploradorVentas_KeyDown F8, class: DM0312_ExploradorVentas.cs");
                    }

                if (ModelSeleccionado.Mov == "Analisis Credito")
                    try
                    {
                        //Process pTicket = new Process();
                        //pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath + "SHM\\";
                        //pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "SHM\\" + @"SHM.exe";
                        //pTicket.StartInfo.Verb = "runas";
                        //pTicket.StartInfo.Arguments = "CONSULTAR" + " " + ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente + " " + "Analisis_Credito" + " " + ModelSeleccionado.MovId + " " + 1;
                        //pTicket.StartInfo.UseShellExecute = false;
                        //pTicket.Start();
                        //pTicket.Dispose();
                        if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                        {
                            Process System = new Process();
                            System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                            System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                            System.StartInfo.Verb = "runas";
                            System.StartInfo.Arguments = "CONSULTAR" + " " + ClaseEstatica.Usuario.Usser + " " +
                                                         ModelSeleccionado.Cliente + " " + "Analisis_Credito" + " " +
                                                         ModelSeleccionado.MovId + " " + 1;
                            //"CAPTURARHOJAVERDE" + " " + txt_Cliente.Text + " " + VentasSeleccionadas[PaginadoActual].MovId + " " + txt_Total.Text.Replace("$", "");
                            System.StartInfo.UseShellExecute = false;
                            System.Start();
                            //-Revision de Procesos 2019-05-28
                            //System.WaitForExit();
                        }
                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("consultarBuroToolStripMenuItem_Click",
                            "DM0312_ExploradorVentas.cs", ex);
                        MessageBox.Show(ex.Message +
                                        " function: DM0312_ExploradorVentas_KeyDown F8, class: DM0312_ExploradorVentas.cs");
                    }
            }
        }

        private void cbx_Impreso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) TableroMovimientos();
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
                return;
            }

            if (!char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void copiarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                Clipboard.SetDataObject(ModelSeleccionado.Cliente);
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void copiarClienteRelacionadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                Clipboard.SetDataObject(ModelSeleccionado.Relacionado);
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        ///     Toolstrip cliente express
        /// </summary>
        private void rm0855AClienteExpressCrtlAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClienteExpressRm0855();
        }

        public void AgregarActualizacionDatos()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (ModelSeleccionado.Mov == "Solicitud Credito" || ModelSeleccionado.Mov == "Analisis Credito" ||
                        ModelSeleccionado.Mov == "Pedido")
                    {
                        int numV = controladorD.SucursalRDP(ClaseEstatica.Usuario.sucursal);
                        if (numV == 1)
                        {
                            string ArgumentosPlugin = @"SHM.exe N SHM\ " + "\"" + string.Concat("CAPTURARHOJAVERDE",
                                                          "|", ModelSeleccionado.Cliente, "|", ModelSeleccionado.MovId,
                                                          "|",
                                                          ModelSeleccionado.ImporteTotal.Replace("$", "") + "|" +
                                                          ClaseEstatica.Usuario.Usser) +
                                                      "\"" + " N N";

                            controladorD.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                        }
                        else
                        {
                            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                            {
                                string ArgumentosPlugin = "CAPTURARHOJAVERDE" + " " + ModelSeleccionado.Cliente + " " +
                                                          ModelSeleccionado.MovId + " " +
                                                          ModelSeleccionado.ImporteTotal.Replace("$", "") + " " +
                                                          ClaseEstatica.Usuario.Usser;
                                controladorD.EjecutarPlugins(ArgumentosPlugin, "SHM.exe",
                                    ConfigurationManager.AppSettings["CarpetaSHM"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("agregarActualizacionDeDatosCrtlJToolStripMenuItem_Click",
                        "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message +
                                    " function: agregarActualizacionDeDatosCrtlJToolStripMenuItem_Click, class: DM0312_ExploradorVentas.cs");
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void agregarActualizacionDeDatosCrtlJToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AgregarActualizacionDatos();
        }

        public void VerActualizacionDatos()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                    {
                        Process System = new Process();
                        System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                        System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                        System.StartInfo.Verb = "runas";
                        System.StartInfo.Arguments = "MOSTRARHOJAVERDE" + " " + ModelSeleccionado.Cliente + " " +
                                                     ModelSeleccionado.MovId;
                        //"CAPTURARHOJAVERDE" + " " + txt_Cliente.Text + " " + VentasSeleccionadas[PaginadoActual].MovId + " " + txt_Total.Text.Replace("$", "");
                        System.StartInfo.UseShellExecute = false;
                        System.Start();
                        //-Revision de Procesos 2019-05-28
                        //System.WaitForExit();
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("actualizacionDeDatosCrtlJToolStripMenuItem_Click",
                        "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message +
                                    " function:  actualizacionDeDatosCrtlJToolStripMenuItem_Click, class: DM0312_ExploradorVentas.cs");
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void actualizacionDeDatosCrtlJToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerActualizacionDatos();
        }

        private async void BtnProspectoaCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (ModelSeleccionado == null) return;
                List<CoincidenciasRFCModelo> listaExplorador =
                    await controllerExplorador.postulanteACreditoVerificacionRFC(ModelSeleccionado.Cliente);
                if (listaExplorador.Count < 1)
                {
                    CambiarProspecto();
                    return;
                }

                DialogResult result =
                    MessageBox.Show(
                        "Cliente cuenta con coincidencia con el RFC " + listaExplorador.FirstOrDefault()._rfc, "Alerta",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)
                {
                    DM0312_ExploradorVenta_CoincidenciaRFC coincidenciaRFC =
                        new DM0312_ExploradorVenta_CoincidenciaRFC(listaExplorador);
                    coincidenciaRFC.ShowDialog();
                    bool valido = DialogResult.None == coincidenciaRFC.resultadoForm
                        ? false
                        : DialogResult.OK != coincidenciaRFC.resultadoForm;
                    if (valido) CambiarProspecto();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                Console.WriteLine(ex.ToString());
            }
        }

        public void ValidaCaja()
        {
            defCuentaUsuario = controllerExplorador.ValidaCajaUsuario(ClaseEstatica.Usuario.Usser);
            if (defCuentaUsuario != null)
                lbl_CuentaCaja.Text = defCuentaUsuario;
            else
                lbl_CuentaCaja.Text = "";
        }

        private void catalogoDeCalificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
            catalogoCalificacion.ShowDialog();
            txt_Buscar.Focus();
        }

        private void panelContactos_Paint(object sender, PaintEventArgs e)
        {
        }

        public void KardexClienteFinalC()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                    {
                        Process System = new Process();
                        System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                        System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                        System.StartInfo.Verb = "runas";
                        //-CorreccionKardexClienteFinal
                        //System.StartInfo.Arguments = "CLIENTEFINALKARDEX" + " " + ModelSeleccionado.ID + " " + ModelSeleccionado.Usuario;
                        System.StartInfo.Arguments = "CLIENTEFINALKARDEX" + " " + ModelSeleccionado.ID + " " +
                                                     ClaseEstatica.Usuario.Usser;
                        System.StartInfo.UseShellExecute = false;
                        System.Start();
                        //-Revision de Procesos 2019-05-28
                        //System.WaitForExit();
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("MenuItem_KardexClienteFinal_Click", "DM0312_ExploradorVentas.cs",
                        ex);
                    MessageBox.Show(ex.Message +
                                    " function:  MenuItem_KardexClienteFinal_Click, class: DM0312_ExploradorVentas.cs");
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MenuItem_KardexClienteFinal_Click(object sender, EventArgs e)
        {
            KardexClienteFinalC();
        }

        /// <summary>
        ///     Afecta movimiento seleccionado
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private async void MenuItem_Afectar_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                string estatusAct = detalle.EstatusActual(ModelSeleccionado.ID);

                if (estatusAct != ModelSeleccionado.Estatus)
                {
                    MessageBox.Show(
                        "El movimiento " + ModelSeleccionado.Mov + " " + ModelSeleccionado.MovId +
                        " ya ah sido afectado o esta en seguimiento por otro usuario, favor de refrescar su explorador(F5) para obtener los movimientos a los que le puede dar seguimiento",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }


                CDetalleVenta CDetalleVenta = new CDetalleVenta();
                CDetalleVenta.MovimientoGenerado = false;
                string articuloSeleccionado = string.Empty;
                int EnteroPosicionArticulo = 0;
                if (dgv_TablaDetalle.SelectedRows.Count > 0 &&
                    dgv_TablaDetalle.SelectedRows[dgv_TablaDetalle.SelectedRows.Count - 1].Cells.Count > 0)
                    articuloSeleccionado = dgv_TablaDetalle.SelectedRows[dgv_TablaDetalle.SelectedRows.Count - 1]
                        .Cells[EnteroPosicionArticulo].Value.ToString();
                string UEN = string.Empty;
                string OrigenID = string.Empty;
                string ReferenciaOrdenCompra = string.Empty;
                string Origen = string.Empty;
                string CadenaSumaImporte = string.Empty;
                string Vencimiento = string.Empty;
                string OrigenTipo = string.Empty;
                string Impuestos = string.Empty;
                string Importe = string.Empty;
                string OrigenTipoMov = string.Empty;

                controllerExplorador.LLenadoListaArticulosSeleccionados();

                string[] Parametros =
                {
                    ListaExplorador[ListaExplorador.Count - 1].Mov,
                    ListaExplorador[ListaExplorador.Count - 1].MovId,
                    ListaExplorador[ListaExplorador.Count - 1].MovTipo,
                    ListaExplorador[ListaExplorador.Count - 1].ID.ToString()
                };
                string CategoriaEnviarA = string.Empty;
                List<string> DetallesTablero = CDetalleVenta.ObtenerDetallesVenta(Parametros, ref CategoriaEnviarA);

                if (DetallesTablero.Count > 0)
                {
                    UEN = DetallesTablero[(int)Enums.DetallesVenta.UEN];
                    OrigenID = DetallesTablero[(int)Enums.DetallesVenta.OrigenID];
                    ReferenciaOrdenCompra = DetallesTablero[(int)Enums.DetallesVenta.ReferenciaOrdenCompra];
                    Origen = DetallesTablero[(int)Enums.DetallesVenta.Origen];
                    if (ListaExplorador.Count > 0)
                        CDetalleVenta.PaginadoActual = ListaExplorador.Count - 1;
                    else
                        CDetalleVenta.PaginadoActual = 0;
                    CadenaSumaImporte = CDetalleVenta.CalculaImporte(DetallesTablero).ToString();
                    Vencimiento = DetallesTablero[(int)Enums.DetallesVenta.Vencimiento];
                    OrigenTipo = DetallesTablero[(int)Enums.DetallesVenta.OrigenTipo];
                    Impuestos = DetallesTablero[(int)Enums.DetallesVenta.Impuestos];
                    Importe = DetallesTablero[(int)Enums.DetallesVenta.Importe];
                    OrigenTipoMov = DetallesTablero[(int)Enums.DetallesVenta.OrigenTipoMov];
                }

                string Canal = ListaExplorador[ListaExplorador.Count - 1].EnviarA;
                string[] IDyCategoria = CDetalleVenta.ObtenerCategoriaCanal(Canal);
                int EnteroCategoria = 1;

                Parametros = new[]
                {
                    ListaExplorador[ListaExplorador.Count - 1].Mov,
                    ListaExplorador[ListaExplorador.Count - 1].MovId,
                    "VTAS",
                    ListaExplorador[ListaExplorador.Count - 1].ID.ToString(),
                    ListaExplorador[ListaExplorador.Count - 1].Cliente,
                    ListaExplorador[ListaExplorador.Count - 1].Estatus,
                    ListaExplorador[ListaExplorador.Count - 1].EnviarA,
                    ListaExplorador[ListaExplorador.Count - 1].FechaAlta.ToString(),
                    ListaExplorador[ListaExplorador.Count - 1].Sucursal.ToString(),
                    ListaExplorador[ListaExplorador.Count - 1].Condicion,
                    CategoriaEnviarA,
                    articuloSeleccionado,
                    ListaExplorador[ListaExplorador.Count - 1].Almacen,
                    UEN,
                    OrigenID,
                    ReferenciaOrdenCompra,
                    Origen,
                    CadenaSumaImporte,
                    ListaExplorador[ListaExplorador.Count - 1].MovTipo,
                    Vencimiento,
                    OrigenTipo,
                    Impuestos,
                    Importe,
                    OrigenTipoMov,
                    ListaExplorador[ListaExplorador.Count - 1].IDEcommerce,
                    IDyCategoria[EnteroCategoria],
                    "",
                    string.Empty,
                    string.Empty
                };


                string msgPrecaucion = string.Empty;
                string msgTitulo = "";

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                }

                CDetalleVenta.AfectaDesdeTablero = true;
                if (await Task.Run(() => CDetalleVenta.ValidacionesAfectar(Parametros, ref msgPrecaucion)))
                    if (await Task.Run(() => CDetalleVenta.CondicionAfectar(Parametros, ref msgPrecaucion)))
                        if (await Task.Run(() =>
                                CDetalleVenta.Afectar(Parametros, ref msgPrecaucion, ref msgTitulo, ListaExplorador)))
                        {
                            if (frmLoading.Visible)
                            {
                                frmLoading.Hide();
                                DesabilitarControles(true);
                            }

                            MessageBox.Show("Movimiento afectado satisfactoriamente", "Informacion",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            List<DM0312_MExploradorVenta> NuevosMovs =
                                new List<DM0312_MExploradorVenta>(ListaExplorador);
                            //DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
                            ////TableroMovimientos();
                            //CargarNuevasAfectaciones(detalle, NuevosMovs);
                            if (NuevosMovs.Count > 0)
                            {
                                txt_Buscar.Text = NuevosMovs[NuevosMovs.Count - 1].MovId;
                                cbx_BuscarEn.Text = "MovID";
                                cbx_movimiento.Text = NuevosMovs[NuevosMovs.Count - 1].Mov;
                                cbx_situacion.Text = "";
                                cbx_estatus.Text = NuevosMovs[NuevosMovs.Count - 1].Estatus;
                                cbx_fechaA.Text = CDetalleVenta.ObtenerFechaSQL().ToString();
                                chk_CreditoCasa.Checked = true;
                                chk_CreditoNuevo.Checked = true;
                            }

                            TableroMovimientos();
                            txt_Buscar.Text = "";
                            FormIsInLoad = true;
                            cbx_movimiento.Text = "Solicitud Credito";
                            FormIsInLoad = false;
                        }

                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    DesabilitarControles(true);
                }

                if (msgPrecaucion != string.Empty)
                {
                    string Titulo = "Afectar";
                    if (msgTitulo != string.Empty) Titulo = "Error: " + msgTitulo;
                    MessageBox.Show(msgPrecaucion, Titulo);
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Ordenado de tablero por columna
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 14/10/17
        private void dgv_TablaMovimientos_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count <= 0)
                return;
            ImporteFormateado = true;
            List<object> TempObjects = new List<object>(listMovimientos);
            int HScroll = dgv_TablaMovimientos.HorizontalScrollingOffset;
            if (e.ColumnIndex != (int)Enums.MExploradorPropiedades.CadenaImporte)
                funciones.OrderGridview(dgv_TablaMovimientos, e.ColumnIndex, ref TempObjects,
                    listMovimientos.GetType().GetGenericArguments().Single());
            else
                funciones.OrdenarLista(dgv_TablaMovimientos, e.ColumnIndex, TempObjects, "Importe");

            dgv_TablaMovimientos.Columns["FechaAlta"].DefaultCellStyle.Format = "dd/MM/yy HH:mm:ss";
            dgv_TablaMovimientos.Columns["ImporteTotal"].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;
            listMovimientos = TempObjects.OfType<DM0312_MExploradorVenta>().ToList();

            ImporteFormateado = false;

            dgv_TablaMovimientos.ScrollBars = ScrollBars.None;
            ShowColumns();
            if (listMovimientos.Count != 0) validaAcceso = true;
            dgv_TablaMovimientos.ScrollBars = ScrollBars.Both;

            dgv_TablaMovimientos.HorizontalScrollingOffset = HScroll;

            for (int i = 0; i < dgv_TablaMovimientos.Rows.Count; i++)
            {
                if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo" ||
                    Convert.ToString(listMovimientos[i].Bandera) == "Contado Nuevo" ||
                    Convert.ToString(listMovimientos[i].Bandera) == "Credito Nuevo Mayoreo")
                    dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Maroon;

                if (Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa" ||
                    Convert.ToString(listMovimientos[i].Bandera) == "Contado Casa" ||
                    Convert.ToString(listMovimientos[i].Bandera) == "Credito Casa Mayoreo")
                    dgv_TablaMovimientos.Rows[i].DefaultCellStyle.ForeColor = Color.Navy;
            }
        }

        private void gbx_PanelHuellas_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_TableroPr_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void DM0312_ExploradorVentas_MouseMove(object sender, MouseEventArgs e)
        {
            flp_detalle.BackColor = Color.White;
            dgv_TablaDetalle.BackgroundColor = Color.White;
            gbx_Detalle.BackColor = Color.White;
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void panelContactos_MouseMove(object sender, MouseEventArgs e)
        {
            flp_detalle.BackColor = Color.White;
            gbx_Detalle.BackColor = Color.White;
            dgv_TablaDetalle.BackgroundColor = Color.White;
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void gbx_FotoCliente_MouseHover(object sender, EventArgs e)
        {
            flp_detalle.BackColor = Color.White;
            gbx_Detalle.BackColor = Color.White;
            dgv_TablaDetalle.BackgroundColor = Color.White;
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void dgv_TablaDetalle_MouseMove(object sender, MouseEventArgs e)
        {
            flp_detalle.BackColor = Color.FromArgb(230, 230, 230);
            dgv_TablaDetalle.BackgroundColor = Color.FromArgb(230, 230, 230);
            gbx_Detalle.BackColor = Color.FromArgb(230, 230, 230);
            Rectangle rect = gbx_Detalle.ClientRectangle;
            ControlPaint.DrawBorder3D(gbx_Detalle.CreateGraphics(), rect);
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void gbx_Detalle_MouseHover(object sender, EventArgs e)
        {
            flp_detalle.BackColor = Color.FromArgb(230, 230, 230);
            dgv_TablaDetalle.BackgroundColor = Color.FromArgb(230, 230, 230);
            gbx_Detalle.BackColor = Color.FromArgb(230, 230, 230);
            Rectangle rect = gbx_Detalle.ClientRectangle;
            ControlPaint.DrawBorder3D(gbx_Detalle.CreateGraphics(), rect);
        }

        /// <summary>
        ///     Clear detalle border
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/07/17
        private void flp_detalle_MouseMove(object sender, MouseEventArgs e)
        {
            flp_detalle.BackColor = Color.FromArgb(230, 230, 230);
            dgv_TablaDetalle.BackgroundColor = Color.FromArgb(230, 230, 230);
            gbx_Detalle.BackColor = Color.FromArgb(230, 230, 230);
            Rectangle rect = gbx_Detalle.ClientRectangle;
            ControlPaint.DrawBorder3D(gbx_Detalle.CreateGraphics(), rect);
        }

        private void dgv_Eventos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }
        }

        /// <summary>
        ///     Checa si el movimiento seleccionado podra ser seleccionado y muestra / esconde click derecho afectar
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private void PuedeAfectar()
        {
            bool PuedeAfectar = true;
            if (!AccesosDeUsuario.CUsuario.Afectar) PuedeAfectar = false;
            CDetalleVenta cdVenta = new CDetalleVenta();
            if (ListaExplorador.Count > 0)
                CDetalleVenta.PaginadoActual = ListaExplorador.Count - 1;
            else
                CDetalleVenta.PaginadoActual = 0;

            if (ListaExplorador.Count > 0 && !cdVenta.PuedeAfectar(ModelSeleccionado.Usuario, ModelSeleccionado.Estatus,
                    ModelSeleccionado.Situacion, ModelSeleccionado.Mov)) PuedeAfectar = false;

            List<AccesoUsuario> ListAccesos =
                AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
            if (ListAccesos.Count > 0)
            {
                AccesoUsuario NewAcceso = ListAccesos.SingleOrDefault(x => x.campo == "MenuItem_Afectar");
                if (NewAcceso != null) PuedeAfectar = false;
            }

            if (!PuedeAfectar)
            {
                foreach (ToolStripMenuItem item in dgv_TablaMovimientos.ContextMenuStrip.Items)
                    if (item.Name == "cToolStripMenuItem")
                    {
                        item.Visible = false;
                    }
                    else if (item.Name == "MenuItem_Afectar")
                    {
                        item.Visible = false;
                        break;
                    }
            }
            else
            {
                foreach (ToolStripMenuItem item in dgv_TablaMovimientos.ContextMenuStrip.Items)
                    if (item.Name == "cToolStripMenuItem")
                    {
                        item.Visible = true;
                    }
                    else if (item.Name == "MenuItem_Afectar")
                    {
                        item.Visible = true;
                        break;
                    }
            }
        }

        /// <summary>
        ///     mueve el loader de lugar para volver a centrarlo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        private void DM0312_ExploradorVentas_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        /// <summary>
        ///     Cancelar un task
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            ctoken.Cancel();
            DeshabilitarRefrescar(true);
        }

        private void consultarBuroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConsultarBuro();
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.AliceBlue);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (activado == false)
            {
                int height = 80;
                foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                    if (height < 480)
                        height += item.Height;
                dgv_TablaMovimientos.Height = height;
                gbx_TableroPr.Height = height + 60;
                panel_MovsPr.Height = height + 60;
                groupBox1.Visible = false;
                activado = true;
                button1.Image = Resources.MenuInicioDrow;
                Text = "Explorador de Ventas" + "   " + ClaseEstatica.Usuario.Usser + "   " + cbx_movimiento.Text +
                       "   " + cbx_estatus.Text;
                toolTip1.SetToolTip(button1, "Abrir Menu de Inicio");

                //button1.BackgroundImage = Image.FromFile("Resources/imag2.png"); 
            }
            else
            {
                int height = 80;
                foreach (DataGridViewRow item in dgv_TablaMovimientos.Rows)
                    if (height < 257)
                        height += item.Height;
                dgv_TablaMovimientos.Height = height;
                gbx_TableroPr.Height = height + 60;
                panel_MovsPr.Height = height + 60;
                groupBox1.Visible = true;
                activado = false;
                button1.Image = Resources.MenuInicioUp;
                Text = "Explorador de Ventas";
                toolTip1.SetToolTip(button1, "Cerrar Menu de Inicio");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (activadoMenu == false)
            {
                pnlfix_delfix.Size = new Size(0, 0);
                SPID.Visible = false;
                panelContactos.Location = new Point(10, 2);
                button3.Image = Resources.MenuGiro1;
                gbx_TableroPr.Width = 1247;
                dgv_TablaMovimientos.Width = 1232;
                button3.Location = new Point(3, 257);
                activadoMenu = true;
                toolTip1.SetToolTip(button3, "Abrir Menu");
            }
            else
            {
                pnlfix_delfix.Size = new Size(115, 653);
                SPID.Visible = true;
                panelContactos.Location = new Point(134, 2);
                button3.Image = Resources.MenuGiro2;
                gbx_TableroPr.Width = 1147;
                dgv_TablaMovimientos.Width = 1132;
                activadoMenu = false;
                button3.Location = new Point(116, 257);
                toolTip1.SetToolTip(button3, "Cerra Menu");
            }
        }

        private void dgv_TablaMovimientos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //-CerradoIntelisis
            loginC.checkSession();

            //-PedidosSinDetalle            
            if (std.validarIdVenta(ModelSeleccionado.ID))
            {
                MessageBox.Show("El detalle se encuentra abierto por otro usuario.", "Informacion",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (e.RowIndex >= 0)
            {
                if (ListaExplorador.Count > 0)
                {
                    if (!ListasDetallesAbiertas())
                    {
                        CDetalleVenta.MovimientoGenerado = false;
                        controllerExplorador.LLenadoListaArticulosSeleccionados(listMovimientos);
                        DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
                        detalle.PaginadoActual = 0;
                        dgv_TablaMovimientos.Focus();
                        detalle.Show();
                    }
                    else
                    {
                        dgv_TablaMovimientos.Focus();
                        MessageBox.Show("Uno o varios movimientos ya estan abiertos", "Informacion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    dgv_TablaMovimientos.Focus();
                    MessageBox.Show("No hay articulos en este movimiento", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\SELP\\SELPDesktop.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.Usuario.Acceso + " " +
                                              ClaseEstatica.Usuario.Uen + " " + ClaseEstatica.Usuario.Sucursal;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("consultarBuroToolStripMenuItem_Click", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message +
                                " function: DM0312_ExploradorVentas_KeyDown F8, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void txt_Sucursal_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta suc = ListaExploradorVenta.Where(x => x.Campo.Equals("Sucursal")).FirstOrDefault();
            txt_ComentarioAyuda.Text = suc.Comentario;
        }

        private void cbx_Impreso_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Impreso =
                ListaExploradorVenta.Where(x => x.Campo.Equals("Impreso")).FirstOrDefault();
            txt_ComentarioAyuda.Text = Impreso.Comentario;
        }

        private void chk_Devolucion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Dev = ListaExploradorVenta.Where(x => x.Campo.Equals("Devolucion"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = Dev.Comentario;
        }

        public void CalidadDeCapturaC()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (ModelSeleccionado.Bandera == "Credito Nuevo")
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName =
                            ClaseEstatica.plugInPath + @"EvaluacionCalidad\EvaluacionCalidad.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + ClaseEstatica.Usuario.usuario +
                                                      " " + ModelSeleccionado.Agente;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("El cliente " + ModelSeleccionado.Cliente + " no es Nuevo", "Mensaje!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("CalidadCaptura", "DM0312_ExploradorVentas", ex);
                    MessageBox.Show(ex.Message);
                    throw;
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_CalidadCap_Click(object sender, EventArgs e)
        {
            CalidadDeCapturaC();
        }

        private void GetSetColumWidth(bool Set = false)
        {
            if (Set)
            {
                int i = 0;

                foreach (int dgvcolumn in columnSizes)
                {
                    dgv_TablaMovimientos.Columns[i].Width = dgvcolumn;
                    i++;
                }
            }
            else
            {
                columnSizes.Clear();
                foreach (DataGridViewColumn dgvcolumn in dgv_TablaMovimientos.Columns) columnSizes.Add(dgvcolumn.Width);
            }
        }

        #region TipoCredito

        private void cbx_TipoCredito_SelectedIndexChanged(object sender, EventArgs e)
        {
            TableroMovimientos();
            AsyncRunning = false;
        }

        #endregion

        private void cbx_BuscarEn_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_BuscarEn.Text == "MovID")
                txt_Buscar.MaxLength = 15;
            else if (cbx_BuscarEn.Text == "Cliente")
                txt_Buscar.MaxLength = 9;
            else if (cbx_BuscarEn.Text == "Nombre")
                txt_Buscar.MaxLength = 100;
            else if (cbx_BuscarEn.Text == "Relacionado")
                txt_Buscar.MaxLength = 10;
            else if (cbx_BuscarEn.Text == "Canal de Venta")
                txt_Buscar.MaxLength = 2;
            else if (cbx_BuscarEn.Text == "Grupo")
                txt_Buscar.MaxLength = 50;
            else if (cbx_BuscarEn.Text == "Calificacion") txt_Buscar.MaxLength = 100;
        }

        private void btn_AnalistasCredi_Click(object sender, EventArgs e)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                //-CambioRutaAnalistas //-(2019-09-04)
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"Analistas\\Analistas.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.usuario;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("btn_AnalistasCredi_Click", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: btn_AnalistasCredi_Click, class: DM0312_ExploradorVentas.cs");
            }
        }

        public void MatrizAutorizacionM()
        {
            string DM0296Nombre = "";
            string DM0257Usuario = "";
            string DM0296Nivel = "";
            DM0296Nombre = controllerExplorador.FmatrizAutorizacion(ModelSeleccionado.Cliente, "2");
            DM0257Usuario = controllerExplorador.FmatrizAutorizacion(ClaseEstatica.Usuario.usuario, "1");
            DM0296Nivel = controllerExplorador.FmatrizAutorizacion(ClaseEstatica.Usuario.usuario, "3");

            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"SegundaReferencia\SegundaReferencia.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + DM0296Nombre + " " +
                                              ClaseEstatica.Usuario.Usser + " " + DM0257Usuario + " " + DM0296Nivel;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("matrizDeAutorizacionToolStripMenuItem_Click",
                    "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message +
                                " function: matrizDeAutorizacionToolStripMenuItem_Click, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void matrizDeAutorizacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MatrizAutorizacionM();
        }


        private void GetDescripcion()
        {
            tb_descripcion.Text = string.Empty;

            if (dgv_TablaMovimientos.SelectedRows.Count > 0)
                if (dgv_TablaDetalle.SelectedRows.Count > 0)
                {
                    SqlCommand comm = new SqlCommand("SELECT Descripcion1 FROM ART WITH(NOLOCK) WHERE Articulo = @Art",
                        ClaseEstatica.ConexionEstatica);
                    comm.CommandType = CommandType.Text;
                    comm.Parameters.AddWithValue("@Art",
                        dgv_TablaDetalle.SelectedRows[dgv_TablaDetalle.SelectedRows.Count - 1].Cells[0].Value);

                    try
                    {
                        SqlDataReader dr = comm.ExecuteReader();
                        if (dr.HasRows)
                            while (dr.Read())
                                if (dr["Descripcion1"] != null && dr["Descripcion1"].ToString() != string.Empty)
                                    tb_descripcion.Text = dr["Descripcion1"].ToString();
                        dr.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        DM0312_ErrorLog.RegistraError("dgv_TablaMovimientos_SelectionChanged_1",
                            "DM0312_ExploradorVenta", ex);
                    }
                }
        }


        private void dgv_TablaDetalle_SelectionChanged(object sender, EventArgs e)
        {
            GetDescripcion();
        }

        #region ToolTip

        private void reanalisisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (usuarioVenta != "CREDI")
            {
                MessageBox.Show("Reanalisis sólo está permitido para Usuarios de credito",
                    "No es posible acceder a este modulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (ModelSeleccionado.Mov != "Analisis Credito")
            {
                MessageBox.Show("Reanalisis sólo está permitido en Análisis de crédito",
                    "No es posible acceder a este modulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Reanalisis();
                FillDataGridEventos();
            }
        }

        #endregion

        #region CapturaRelacionado

        private void capturaDeRelacionadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count <= 0)
                return;
            if (controllerExplorador.idCanal(ModelSeleccionado.Canal) == 3 ||
                controllerExplorador.idCanal(ModelSeleccionado.Canal) == 7)
            {
                DM0312_CapRelacionado relacionado = new DM0312_CapRelacionado();
                relacionado.cliente = ModelSeleccionado.Cliente;
                relacionado.ShowDialog();
            }
            else
            {
                MessageBox.Show("Solo permitido para canales 3 o 7 ", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        #endregion

        private void CamposExtrasM()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                if ((ModelSeleccionado.Mov == "Solicitud Credito" || ModelSeleccionado.Mov == "Analisis Credito") &&
                    ModelSeleccionado.Estatus == "PENDIENTE")
                {
                    List<DM0312_MPuntoVentaCampoExtra> list;
                    if (ModelSeleccionado.Mov == "Analisis Credito")
                    {
                        List<string> lista = new List<string>();
                        lista = controllerExplorador.LlenaCamposExtras(ModelSeleccionado.Mov, ModelSeleccionado.ID,
                            ModelSeleccionado.Estatus, usuarioVenta);
                        list = controladorP.ActualizaCamposExtras(Convert.ToInt32(lista[1]));
                    }
                    else
                    {
                        list = controladorP.ActualizaCamposExtras(ModelSeleccionado.ID);
                    }

                    DM0312_MCamposExtraRecibe CamposExtraRecibe = new DM0312_MCamposExtraRecibe
                    {
                        Mov = ModelSeleccionado.Mov,
                        IdVenta = Convert.ToInt32(ModelSeleccionado.ID),
                        Cliente = ModelSeleccionado.Cliente,
                        TipoCalle = list.Where(x => x.CampoExtra == "SC_TIPO_CALLE").Select(x => x.Valor)
                            .FirstOrDefault(),
                        NomCalle = list.Where(x => x.CampoExtra == "SC_CALLE").Select(x => x.Valor).FirstOrDefault(),
                        NumExterior = list.Where(x => x.CampoExtra == "SC_NUM_EXTERIOR").Select(x => x.Valor)
                            .FirstOrDefault(),
                        NumInterior = list.Where(x => x.CampoExtra == "SC_NUM_INTERIOR").Select(x => x.Valor)
                            .FirstOrDefault(),
                        CodigoPostal = list.Where(x => x.CampoExtra == "SC_CP").Select(x => x.Valor).FirstOrDefault(),
                        Colonia = list.Where(x => x.CampoExtra == "SC_COLONIA").Select(x => x.Valor).FirstOrDefault(),
                        Cruce = list.Where(x => x.CampoExtra == "SC_CRUCES").Select(x => x.Valor).FirstOrDefault(),
                        Telefono = list.Where(x => x.CampoExtra == "SC_TELEFONO").Select(x => x.Valor).FirstOrDefault(),
                        NumIdenti = list.Where(x => x.CampoExtra == "SC_TIPO_DOCTO").Select(x => x.Valor)
                            .FirstOrDefault(),
                        Conyuge = list.Where(x => x.CampoExtra == "SC_CONYUGE").Select(x => x.Valor).FirstOrDefault(),
                        Relacionado = list.Where(x => x.CampoExtra == "SC_RECOMENDADO").Select(x => x.Valor)
                            .FirstOrDefault(),
                        Fecha = list.Where(x => x.CampoExtra == "SC_FECHANACIMIENTO").Select(x => x.Valor)
                            .FirstOrDefault(),
                        NumIdent = list.Where(x => x.CampoExtra == "SC_DOCTO").Select(x => x.Valor).FirstOrDefault(),
                        Estatus = true,
                        EstatusConsulta = true
                    };

                    using (DM0312_CamposExtra campoExtra = new DM0312_CamposExtra(CamposExtraRecibe))
                    {
                        DM0312_CamposExtra.validaInsertUsuario = true;
                        campoExtra.psAgente = ModelSeleccionado.Agente;
                        if (CamposExtraRecibe.TipoCalle == null && CamposExtraRecibe.NomCalle == null &&
                            CamposExtraRecibe.NumExterior == null && CamposExtraRecibe.NumInterior == null &&
                            CamposExtraRecibe.CodigoPostal == null && CamposExtraRecibe.Colonia == null &&
                            CamposExtraRecibe.Cruce == null && CamposExtraRecibe.Telefono == null &&
                            CamposExtraRecibe.NumIdenti == null && CamposExtraRecibe.Conyuge == null &&
                            CamposExtraRecibe.Relacionado == null && CamposExtraRecibe.Fecha == null &&
                            CamposExtraRecibe.NumIdent == null)
                            MessageBox.Show("No hay datos de campos extras para consultar", "", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        else
                            campoExtra.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Para consultar los campos extras debe ser movimiento de credito", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void camposExtrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CamposExtrasM();
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            if (usuarioVenta == "VENTP")
            {
                string pdfPath = Path.Combine(Application.StartupPath, "PTOVTA00001 EXPLORADOR VENTA.pdf");

                Process.Start(pdfPath);
            }
            else
            {
                if (usuarioVenta == "CREDI")
                {
                    string pdfPath = Path.Combine(Application.StartupPath, "MANUAL PV.pdf");
                    string pdfPathv = Path.Combine(Application.StartupPath, "PTOVTA00001 EXPLORADOR VENTA.pdf");
                    Process.Start(pdfPathv);
                }
            }
        }

        public void web()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                int canalWeb = 0;
                canalWeb = controllerExplorador.idCanal(ModelSeleccionado.Canal);
                string referencia = controllerExplorador.referenciaV(ModelSeleccionado.ID);
                referencia = referencia.Replace(" ", "");

                if (controllerExplorador.Web1(ModelSeleccionado.ID, 1) > 0)
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pTicket.StartInfo.FileName =
                        ClaseEstatica.plugInPath + "\\SolicitudCreditoWeb\\EmailAutorizado.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + "Rechazado" + " " + canalWeb + " " +
                                                  "'" + referencia + "'" + " " + ModelSeleccionado.ID;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.Dispose();
                }
                else
                {
                    if (controllerExplorador.Web1(ModelSeleccionado.ID, 2) > 0)
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName =
                            ClaseEstatica.plugInPath + "\\SolicitudCreditoWeb\\EmailAutorizado.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ModelSeleccionado.Cliente + " " + "Aceptado" + " " + canalWeb +
                                                      " " + "'" + referencia + "'" + " " + ModelSeleccionado.ID;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    else
                    {
                        if (controllerExplorador.Web1(ModelSeleccionado.ID, 3) > 0)
                            MessageBox.Show("No es posible enviar correo, cliente recibe efectivo en banco", "",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(
                                "No es posible enviar correo, el movimiento tienen que ser analisis credito pendiente",
                                "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void envioCorreoWebCrtlF9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web();
        }

        private void BTN_consultaCf_Click(object sender, EventArgs e)
        {
            Process pTicket = new Process();
            pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
            //-CambioPluginsJesus 2019-05-28 se cambio ruta de plugin
            //pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\Inte606.exe";
            pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\SaldosBF\\BeneficiariosFinales.exe";
            pTicket.StartInfo.Verb = "runas";
            pTicket.StartInfo.UseShellExecute = false;
            pTicket.Start();
            pTicket.Dispose();
        }

        private void DM0312_ExploradorVentas_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
            {
                Panel_Menu.Size = new Size(109, 665);
                pnlfix_delfix.Size = new Size(115, 670);
            }
            else
            {
                Panel_Menu.Size = new Size(109, 635);
                pnlfix_delfix.Size = new Size(115, 640);
                //this.Size = new System.Drawing.Size(1309, 714);
            }
        }

        public void Reanalisis()
        {
            using (DM0312_Reanalisis dm0312Reanalisis = new DM0312_Reanalisis(ModelSeleccionado.ID))
            {
                dm0312Reanalisis.ShowDialog();
            }
        }

        private void btn_SoporAval_Click(object sender, EventArgs e)
        {
            SoportadosAval();
        }


        public void SoportadosAval()
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"SoportadoxAval\SoportexAvales.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("SoportadosAval", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: SoportadosAval, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void editarVentaCrtlF7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modificarVenta();
        }

        public void modificarVenta()
        {
            if ((ClaseEstatica.Usuario.sucursal == 90
                 || ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 98)
                && ModelSeleccionado.Estatus == "SINAFECTAR"
                && (ModelSeleccionado.Mov == "Pedido" || ModelSeleccionado.Mov == "Solicitud Credito" ||
                    ModelSeleccionado.Mov == "Pedido Mayoreo"))
            {
                int canalV = controllerExplorador.idCanal(ModelSeleccionado.Canal);
                PuntoDeVenta puntoDeVenta = new PuntoDeVenta(ModelSeleccionado.Cliente, canalV);
                PuntoDeVenta.Canal = canalV;
                txt_Buscar.Text = ModelSeleccionado.IDEcommerce;

                puntoDeVenta.mensajeBoton = ModelSeleccionado.Mov;
                puntoDeVenta.ValidaEstatus = "SINAFECTAR";
                puntoDeVenta.FlagEventosPuntoVenta = true;
                puntoDeVenta.idVenta = ModelSeleccionado.ID;
                puntoDeVenta.AgenteModificado = ModelSeleccionado.Agente;
                puntoDeVenta.CondicionModificada = ModelSeleccionado.Condicion;
                puntoDeVenta.almacenModificado = ModelSeleccionado.Almacen;
                puntoDeVenta.valorModificado = 1;
                puntoDeVenta.idEcommerceModificado = ModelSeleccionado.IDEcommerce;
                puntoDeVenta.ValorModificadoM = 1;
                if (ClaseEstatica.Usuario.sucursal == 98)
                    puntoDeVenta.mensajeBoton = "Mayoreo";
                else
                    puntoDeVenta.mensajeBoton = "Contado";
                controladorVE.GuardarDomicilioActualCasa(ModelSeleccionado.Cliente);
                Hide();
                puntoDeVenta.ShowDialog();
                if (!puntoDeVenta.CerrarVenta)
                {
                    Show();
                    StartPosition = FormStartPosition.CenterScreen;
                }
                else
                {
                    Close();
                }

                cbx_BuscarEn.Text = "id ecommerce";
                TableroMovimientos();
                validaAcceso = true;
                dgv_TablaMovimientos_SelectionChanged_1(null, null);
                if (!ListasDetallesAbiertas())
                {
                    CDetalleVenta.MovimientoGenerado = false;
                    controllerExplorador.LLenadoListaArticulosSeleccionados(listMovimientos);
                    DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
                    detalle.PaginadoActual = 0;
                    dgv_TablaMovimientos.Focus();
                    detalle.Show();
                    btn_Refrescar_Click(null, null);
                }
                else
                {
                    dgv_TablaMovimientos.Focus();
                    MessageBox.Show("Uno o varios movimientos ya estan abiertos", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }

                validaAcceso = false;
            }
            else
            {
                if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
                    MessageBox.Show("Debe ser un pedido sin afectar para poder ser editado", "Informacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show("No tiene permiso para editar un movimiento", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
            }
        }

        //-Primera Fase de Automatizacion
        private void btn_storepickupOrders_Click(object sender, EventArgs e)
        {
            StorePickupList doro = new StorePickupList();
            doro.ShowDialog();
        }


        //-Primera Fase de Automatizacion
        private void showBotonPedidosStorePickup()
        {
            CStorePickupList storePickup = new CStorePickupList();
            bool storepickupOrderExists = false;
            int storePickupOrderNumber = 0;

            storePickupOrderNumber = storePickup.getNumPedidos();
            storepickupOrderExists = storePickupOrderNumber > 0 ? true : false;

            if (storepickupOrderExists)
            {
                btn_storepickupOrders.Visible = true;
                btn_storepickupOrders.Text = "Entregar:" + Environment.NewLine +
                                             string.Format(storePickupOrderNumber + " pedido(s)");
            }
        }

        //-Primera Fase de Automatizacion
        private void btn_monedero_Click(object sender, EventArgs e)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\MonederoVirtualCM\\MonederoVirtualCM.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Sucursal.ToString();
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("btn_monedero_Click", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message +
                                " function: btn_monedero_Click error al abrir, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void btnKardex_Click(object sender, EventArgs e)
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
                try
                {
                    if (ModelSeleccionado.Mov == "Solicitud Credito")
                    {
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.WorkStation +
                                                      " " + ModelSeleccionado.Cliente + " " + ModelSeleccionado.ID;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                    else
                    {
                        int idOrigen = controllerExplorador.origenID(ModelSeleccionado.Mov, ModelSeleccionado.MovId);
                        Process pTicket = new Process();
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.WorkStation +
                                                      " " + ModelSeleccionado.Cliente + " " + idOrigen;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("btnKardex_Click", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message + " function: btnKardex_Click, class: DM0312_ExploradorVentas.cs");
                    throw;
                }
            else
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //-Dineralia
        /// <summary>
        ///     Evento encargado abrir el modulo de validacion de dineralia
        /// </summary>
        private void btnDineralia_Click(object sender, EventArgs e)
        {
            try
            {
                //-997
                int iRechazo = 0;
                if (ModelSeleccionado.Situacion == "Reanalisis")
                {
                    iRechazo = 2;
                }
                else
                {
                    if (detalle.validarEvento(ModelSeleccionado.ID)) iRechazo = 1;
                }

                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "validacionDineralia\\validacionDineralia.exe";
                //pTicket.StartInfo.FileName = @"\\erpmavi\Versiones\3100Capacitacion\PlugIns\ValidacionDineralia\validacionDineralia.exe";

                //pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\MonederoVirtualCM\\MonederoVirtualCM.exe";
                //pTicket.StartInfo.FileName = @"C:\Users\noreyes\source\repos\validacionDineralia\validacionDineralia\bin\Debug\validacionDineralia.exe"; 
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ModelSeleccionado.ID + " " + ModelSeleccionado.Cliente + " " +
                                              ClaseEstatica.Usuario.usuario + " " + ClaseEstatica.Usuario.sucursal +
                                              " " + ModelSeleccionado.Estatus + " " + ModelSeleccionado.Agente + " " +
                                              iRechazo;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }


        #region

        // 
        private static string getTipoUsuario()
        {
            return ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        }

        #endregion

        private void btn_SolicitudCancelacion_Click(object sender, EventArgs e)
        {
            //1381-A
            //Validar si existen Movimientos de Solicitud Pendientes de atender (mov SOlICITUDES CREDITO estatus PENDIENTES)
            // si no existen mandar Mensaje de error "Sin solicitudes pendientes"
            SolicitudCancelacionesController SolicitudCancelacionesController = new SolicitudCancelacionesController();
            List<SolicitudCancelaciones> SolicitudCancelaciones =
                SolicitudCancelacionesController.getSolicitudesCancelacion();

            if (SolicitudCancelaciones.Count > 0)
                using (HistorialSolicitudCancelacion HSC = new HistorialSolicitudCancelacion(SolicitudCancelaciones))
                {
                    HSC.ShowDialog();
                }
            else
                MessageBox.Show("Sin solicitudes pendientes");
        }

        private void chk_ClienteEnSucursal_CheckStateChanged(object sender, EventArgs e)
        {
            TableroMovimientos();
        }

        private Bitmap EscribirLeyenda(Bitmap b, string sMsg)
        {
            Graphics g = Graphics.FromImage(b);
            int x = sMsg.Length >= 2 ? 21 : 25;
            g.DrawString(sMsg, new Font("Arial", 10, FontStyle.Bold), Brushes.White, new PointF(x, 1));
            return b;
        }

        public Bitmap CambiarTamanoImagen(Image pImagen, int pAncho = 780, int pAlto = 640)
        {
            Bitmap vBitmap = new Bitmap(pAncho, pAlto);
            using (Graphics vGraphics = Graphics.FromImage(vBitmap))
            {
                vGraphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                vGraphics.DrawImage(pImagen, 0, 0, pAncho, pAlto);
            }

            return vBitmap;
        }

        //1861 Valida bloqueo en punto de venta por carga de precios
        private void ValidarBloqueoCargaPrecios()
        {
            bool EsBloqueo =
                controllerExplorador.ObtenerBloqueoCargaPrecios(ClaseEstatica.Usuario.Acceso,
                    ClaseEstatica.Usuario.sucursal);

            while (EsBloqueo)
            {
                DM0312_LoginBloqueoCargaPrecios LoginBloqueo =
                    new DM0312_LoginBloqueoCargaPrecios(controllerExplorador.ObtenerMensajeBloqueoCargaPrecios());

                if (LoginBloqueo.ShowDialog() == DialogResult.OK)
                {
                    controllerExplorador.ActualizarBloqueoCargaPrecios(ClaseEstatica.Usuario.sucursal,
                        LoginBloqueo.sUsuarioAutoriza);
                    EsBloqueo = false;
                }
            }
        }

        private void ttCuentaClabe_Click(object sender, EventArgs e)
        {
            cuentaClabe();
        }

        private void ttCargaPPC_Click(object sender, EventArgs e)
        {
            if (ModelSeleccionado != null)
            {
                if (!string.IsNullOrEmpty(ModelSeleccionado.MovId))
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                    {
                        string ArgumentosPlugin = @"SHM.exe N SHM\ " + "\"" + string.Concat("ACTUALIZARIFEYPPC", "|",
                            ModelSeleccionado.Sucursal, "|", ModelSeleccionado.Mov.Replace(" ", "_"), "|",
                            ModelSeleccionado.MovId, "|",
                            ClaseEstatica.Usuario.usuario) + "\"" + " N N";
                        detalle.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                    }
                }
                else
                {
                    MessageBox.Show("Punto De Venta", "No se encontro movid", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void btnResumenFac_Click(object sender, EventArgs e)
        {
            resumenFacturaNuevo();
        }

        private void dgv_TablaMovimientos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        #region ExportExcel //Rodolfo

        private static void OpenMicrosoftExcel(string Path)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = Path;
            //startInfo.Arguments = culture.ToString();
            Process.Start(startInfo);
        }

        public void ExportToExcel()
        {
            //DataGrid con datos
            if (dgv_TablaMovimientos.RowCount > 0)
            {
                SaveFileDialog fichero = new SaveFileDialog();
                fichero.Filter = "CSV|*.csv";
                if (fichero.ShowDialog() == DialogResult.OK)
                {
                    //Variables para Crear Archivo 
                    string value = "";
                    DataGridViewRow dr = new DataGridViewRow();
                    StreamWriter swOut = new StreamWriter(fichero.FileName);

                    //escribir headers en csv
                    for (int i = 0; i <= dgv_TablaMovimientos.Columns.Count - 1; i++)
                    {
                        bool Visible = dgv_TablaMovimientos.Columns[i].Visible;
                        if (Visible)
                        {
                            if (i > 0) swOut.Write("|");
                            swOut.Write(dgv_TablaMovimientos.Columns[i].HeaderText);
                        }
                    }

                    swOut.WriteLine();

                    //Escribir DataGridView rows en csv
                    for (int j = 0; j <= dgv_TablaMovimientos.Rows.Count - 1; j++)
                    {
                        if (j > 0) swOut.WriteLine();

                        dr = dgv_TablaMovimientos.Rows[j];

                        for (int i = 0; i <= dgv_TablaMovimientos.Columns.Count - 1; i++)
                        {
                            bool Visible = dr.Cells[i].Visible;

                            if (Visible)
                            {
                                if (i > 0) swOut.Write("|");

                                value = dr.Cells[i].Value.ToString();

                                swOut.Write(value);
                            }
                        }
                    }

                    swOut.Close();
                    OpenMicrosoftExcel(fichero.FileName);
                }
            }
        }

        public bool Comprobar()
        {
            try
            {
                Type ExcelType = Type.GetTypeFromProgID("Excel.Application");
                dynamic ExcelInst = Activator.CreateInstance(ExcelType);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        public void ExcelExport()
        {
            DataGridView dt = new DataGridView();

            dt.DataSource = dgv_TablaMovimientos;

            SaveFileDialog fichero = new SaveFileDialog();
            fichero.Filter = "Excel (*.xls)|*.xls";
            if (fichero.ShowDialog() == DialogResult.OK)
            {
                Microsoft.Office.Interop.Excel.Application aplicacion;
                Workbook libros_trabajo;
                Worksheet hoja_trabajo;
                aplicacion = new Microsoft.Office.Interop.Excel.Application();
                libros_trabajo = aplicacion.Workbooks.Add();
                hoja_trabajo =
                    (Worksheet)libros_trabajo.Worksheets.get_Item(1);
                try
                {
                    List<AccesoColumnas> Columns = new List<AccesoColumnas>();
                    Columns = PosicionColumna.Where(x => x.Estatus).OrderBy(x => x.Orden).ToList();

                    DM0312_MExploradorVenta model = new DM0312_MExploradorVenta();
                    ////Recorre HeaderText 
                    int imprimeH = 0; //contador Headers

                    //int ImprimeR = 0;//contador Rows
                    foreach (AccesoColumnas h in Columns)
                    {
                        hoja_trabajo.Cells[1, imprimeH + 1] = h.NombreColumna;


                        int count = listMovimientos.Count();

                        for (int i = 0; i < count; i++)
                        {
                            PropertyInfo reflection;

                            DM0312_MExploradorVenta explo = new DM0312_MExploradorVenta();

                            explo = listMovimientos[i];

                            reflection = explo.GetType().GetProperty(h.NombreColumna);

                            if (reflection != null)
                                hoja_trabajo.Cells[i + 2, imprimeH + 1] = reflection.GetValue(explo, null);
                        }

                        imprimeH++;
                    }


                    libros_trabajo.SaveAs(fichero.FileName, XlFileFormat.xlWorkbookNormal);
                    libros_trabajo.Close(true);
                    aplicacion.Quit();
                    MessageBox.Show("Archivo Exportado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    OpenMicrosoftExcel(fichero.FileName);
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("ExcelExport", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex.Message + " function: ExcelExport, class: DM0312_ExploradorVentas.cs", "Error!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion

        #region DocumentosAdjuntos //Rodolfo

        //19
        public void llenarIdentificacion()
        {
            DM0312_CAdminDoc controller = new DM0312_CAdminDoc();

            DM0312_MAdminDoc model = new DM0312_MAdminDoc();

            model = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 19).OrderByDescending(x => x.Fecha)
                .FirstOrDefault();

            if (model != null)
            {
                string temp_ = string.Empty;

                string temp = Path.GetTempPath();

                temp_ = temp + "\\19.pdf";

                if (File.Exists(temp_))
                {
                    if (!IsFileLocked(temp_)) //esta abierto
                    {
                        File.Delete(temp_);
                    }
                    else
                    {
                        panelIdentifiacion.Visible = false;
                        return;
                    }
                }

                panelIdentifiacion.Visible = true;
                try
                {
                    if (model.FORMATO != "IMG")
                    {
                        FileStream wFile;
                        wFile = new FileStream(temp_, FileMode.Append);
                        wFile.Write(model.DOCUMENTO, 0, model.DOCUMENTO.Length);
                        wFile.Close();

                        pb_Identificacion.Image = img;
                    }
                    else
                    {
                        ListaIdenti = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 19 && x.FORMATO == model.FORMATO)
                            .OrderByDescending(x => x.Fecha).ToList();
                        pb_Identificacion.Image = PictureBox(model.DOCUMENTO);
                    }
                }
                catch (IOException ex)
                {
                    DM0312_ErrorLog.RegistraError("llenarIdentificacion", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex + " function:llenarIdentificacion, class: DM0312_ExploradorVentas.cs");
                }

                lbl_Identificacion.Text = "Identificación";
            }
            else
            {
                panelIdentifiacion.Visible = false;
            }
        }

        //73
        public void llenarComprobantes()
        {
            DM0312_MAdminDoc model = new DM0312_MAdminDoc();

            model = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 73).OrderByDescending(x => x.Fecha)
                .FirstOrDefault();

            if (model != null)
            {
                string temp_ = string.Empty;

                string temp = Path.GetTempPath();

                temp_ = temp + "\\73.pdf";

                if (File.Exists(temp_))
                {
                    if (!IsFileLocked(temp_)) //esta abierto
                    {
                        File.Delete(temp_);
                    }
                    else
                    {
                        panelComprobante.Visible = false;
                        return;
                    }
                }

                panelComprobante.Visible = true;
                try
                {
                    if (model.FORMATO != "IMG")
                    {
                        FileStream wFile;
                        wFile = new FileStream(temp_, FileMode.Append);
                        wFile.Write(model.DOCUMENTO, 0, model.DOCUMENTO.Length);
                        wFile.Close();

                        pb_Comprobante.Image = img;
                    }
                    else
                    {
                        ListaComprobante = DocumentosAdjuntosList
                            .Where(x => x.TIPO_DOC == 73 && x.FORMATO == model.FORMATO).OrderByDescending(x => x.Fecha)
                            .ToList();
                        pb_Comprobante.Image = PictureBox(model.DOCUMENTO);
                    }
                }
                catch (IOException ex)
                {
                    DM0312_ErrorLog.RegistraError("llenarComprobantes", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex + " function: llenarComprobantes, class: DM0312_ExploradorVentas.cs");
                }

                lbl_Comprobante.Text = "Comprobantes";
            }
            else
            {
                panelComprobante.Visible = false;
            }
        }

        //25
        public void llenarTarjetas()
        {
            DM0312_MAdminDoc model = new DM0312_MAdminDoc();

            model = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 25).OrderByDescending(x => x.Fecha)
                .FirstOrDefault();


            if (model != null)
            {
                string temp_ = string.Empty;

                string temp = Path.GetTempPath();

                temp_ = temp + "\\25.pdf";

                if (File.Exists(temp_))
                {
                    if (!IsFileLocked(temp_)) //esta abierto
                    {
                        File.Delete(temp_);
                    }
                    else
                    {
                        panelTarjetasDigitales.Visible = false;
                        return;
                    }
                }

                panelTarjetasDigitales.Visible = true;
                try
                {
                    if (model.FORMATO != "IMG")
                    {
                        FileStream wFile;
                        wFile = new FileStream(temp_, FileMode.Append);
                        wFile.Write(model.DOCUMENTO, 0, model.DOCUMENTO.Length);
                        wFile.Close();

                        pb_TarjetasDig.Image = img;
                    }
                    else
                    {
                        ListaTarjetas = DocumentosAdjuntosList
                            .Where(x => x.TIPO_DOC == 25 && x.FORMATO == model.FORMATO).OrderByDescending(x => x.Fecha)
                            .ToList();
                        pb_TarjetasDig.Image = PictureBox(model.DOCUMENTO);
                    }
                }
                catch (IOException ex)
                {
                    DM0312_ErrorLog.RegistraError("llenarTarjetas", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex + " function: llenarTarjetas, class: DM0312_ExploradorVentas.cs");
                }

                lbl_TarjetasDig.Text = "Tarjetas Digitales";
            }
            else
            {
                panelTarjetasDigitales.Visible = false;
                //lbl_TarjetasDig.Visible = false;
                //pb_TarjetasDig.Visible = false;
            }
        }

        //13
        public void llenarPagares()
        {
            DM0312_MAdminDoc model = new DM0312_MAdminDoc();

            model = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 13).OrderByDescending(x => x.Fecha)
                .FirstOrDefault();


            if (model != null)
            {
                string temp_ = string.Empty;

                string temp = Path.GetTempPath();

                temp_ = temp + "\\13.pdf";

                if (File.Exists(temp_))
                {
                    if (!IsFileLocked(temp_)) //esta abierto
                    {
                        File.Delete(temp_);
                    }
                    else
                    {
                        panelPagares.Visible = false;
                        return;
                    }
                }

                panelPagares.Visible = true;

                try
                {
                    if (model.FORMATO != "IMG")
                    {
                        FileStream wFile;
                        wFile = new FileStream(temp_, FileMode.Append);
                        wFile.Write(model.DOCUMENTO, 0, model.DOCUMENTO.Length);
                        wFile.Close();

                        pb_Pagares.Image = img;
                    }
                    else
                    {
                        ListaPedido = DocumentosAdjuntosList.Where(x => x.TIPO_DOC == 13 && x.FORMATO == model.FORMATO)
                            .OrderByDescending(x => x.Fecha).ToList();
                        pb_Pagares.Image = PictureBox(model.DOCUMENTO);
                    }
                }
                catch (IOException ex)
                {
                    DM0312_ErrorLog.RegistraError("llenarPagares", "DM0312_ExploradorVentas.cs", ex);
                    MessageBox.Show(ex + " function: llenarPagares, class: DM0312_ExploradorVentas.cs");
                }

                lbl__Pagares.Text = "Pedidos";
            }
            else
            {
                panelPagares.Visible = false;
            }
        }

        public Image PictureBox(byte[] imagen)
        {
            Image imagen_ = null;

            MemoryStream ms = new MemoryStream(imagen);
            imagen_ = Image.FromStream(ms);

            return imagen_;
        }

        /*******Eventos Click de los PictureBox*/
        private void pb_Identificacion_Click(object sender, EventArgs e)
        {
            Image img = pb_Identificacion.Image;

            string temp_ = string.Empty;

            string temp = Path.GetTempPath();

            temp_ = temp + "\\19.pdf";

            if (File.Exists(temp_))
            {
                Process.Start(temp_);
            }
            else
            {
                if (ListaIdenti.Count > 1)
                {
                    List<Image> Lista = new List<Image>();

                    foreach (DM0312_MAdminDoc i in ListaIdenti) Lista.Add(PictureBox(i.DOCUMENTO));

                    DM0312_ExploradorVentaDoctsAdj frm = new DM0312_ExploradorVentaDoctsAdj();
                    frm.ListaImagenes = Lista;
                    frm.ShowDialog();
                }
                else
                {
                    DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();
                    Image image;
                    int Width = 0;
                    int Height = 0;
                    Width = img.Width * 2;
                    Height = img.Height * 2;
                    frm.Width = Width;
                    frm.Height = Height;
                    image = scaleImage(img, Width, Height);

                    frm.Imagen = image;
                    frm.ShowDialog();
                }
            }
        }

        private void pb_Comprobante_Click(object sender, EventArgs e)
        {
            Image img = pb_Comprobante.Image;

            string temp_ = string.Empty;

            string temp = Path.GetTempPath();

            temp_ = temp + "\\73.pdf";

            if (File.Exists(temp_))
            {
                Process.Start(temp_);
            }
            else
            {
                if (ListaComprobante.Count > 1)
                {
                    List<Image> Lista = new List<Image>();

                    foreach (DM0312_MAdminDoc i in ListaComprobante) Lista.Add(PictureBox(i.DOCUMENTO));

                    DM0312_ExploradorVentaDoctsAdj frm = new DM0312_ExploradorVentaDoctsAdj();
                    frm.ListaImagenes = Lista;
                    frm.ShowDialog();
                }
                else
                {
                    DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();
                    Image image;
                    int Width = 0;
                    int Height = 0;
                    Width = img.Width * 2;
                    Height = img.Height * 2;
                    frm.Width = Width;
                    frm.Height = Height;
                    image = scaleImage(img, Width, Height);

                    frm.Imagen = image;

                    frm.ShowDialog();
                }
            }
        }

        private void pb_TarjetasDig_Click(object sender, EventArgs e)
        {
            Image img = pb_TarjetasDig.Image;

            string temp_ = string.Empty;

            string temp = Path.GetTempPath();

            temp_ = temp + "\\25.pdf";

            if (File.Exists(temp_))
            {
                Process.Start(temp_);
            }
            else
            {
                if (ListaTarjetas.Count > 1)
                {
                    List<Image> Lista = new List<Image>();

                    foreach (DM0312_MAdminDoc i in ListaTarjetas) Lista.Add(PictureBox(i.DOCUMENTO));

                    DM0312_ExploradorVentaDoctsAdj frm = new DM0312_ExploradorVentaDoctsAdj();
                    frm.ListaImagenes = Lista;
                    frm.ShowDialog();
                }
                else
                {
                    DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();
                    Image image;
                    int Width = 0;
                    int Height = 0;
                    Width = img.Width * 2;
                    Height = img.Height * 2;
                    frm.Width = Width;
                    frm.Height = Height;
                    image = scaleImage(img, Width, Height);

                    frm.Imagen = image;
                    frm.ShowDialog();
                }
            }
        }

        private void pb_Pagares_Click(object sender, EventArgs e)
        {
            Image img = pb_Pagares.Image;

            string temp_ = string.Empty;

            string temp = Path.GetTempPath();

            temp_ = temp + "\\13.pdf";

            //Process.Start(temp_);

            if (File.Exists(temp_))
            {
                Process.Start(temp_);
            }
            else
            {
                if (ListaPedido.Count > 1)
                {
                    List<Image> Lista = new List<Image>();

                    foreach (DM0312_MAdminDoc i in ListaPedido) Lista.Add(PictureBox(i.DOCUMENTO));

                    DM0312_ExploradorVentaDoctsAdj frm = new DM0312_ExploradorVentaDoctsAdj();
                    frm.ListaImagenes = Lista;
                    frm.ShowDialog();
                }
                else
                {
                    DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();
                    Image image;
                    int Width = 0;
                    int Height = 0;
                    Width = img.Width * 2;
                    Height = img.Height * 2;
                    frm.Width = Width;
                    frm.Height = Height;
                    image = scaleImage(img, Width, Height);

                    frm.Imagen = image;
                    frm.ShowDialog();
                }
            }
        }

        public void PdfImagen()
        {
            //-CambioImagenesResources
            img = Resources.pdf;
        }

        public Image scaleImage(Image img, int Width, int Height)
        {
            using (img)
            {
                double xRatio = (double)img.Width / Width;
                double yRatio = (double)img.Height / Height;
                double ratio = Math.Max(xRatio, yRatio);
                int nnx = (int)Math.Floor(img.Width / ratio);
                int nny = (int)Math.Floor(img.Height / ratio);
                Bitmap cpy = new Bitmap(nnx, nny, PixelFormat.Format32bppArgb);
                using (Graphics gr = Graphics.FromImage(cpy))
                {
                    gr.Clear(Color.Transparent);
                    gr.InterpolationMode = InterpolationMode.HighQualityBicubic;

                    gr.DrawImage(img,
                        new Rectangle(0, 0, nnx, nny),
                        new Rectangle(0, 0, img.Width, img.Height),
                        GraphicsUnit.Pixel);
                }

                return cpy;
            }
        }

        protected virtual bool IsFileLocked(string path)
        {
            FileStream stream = null;

            FileInfo file = new FileInfo(path);

            string name = path.Substring(path.Length - 6, 6);

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (Exception)
            {
                MessageBox.Show("Cierre el archivo PDF" + " " + name, "Precaución", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            return false;
        }

        #endregion

        #region MonederoRedimir //Rodolfo

        public void MonederoXredimirConsulta()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                if (ListaExplorador.Count > 1)
                {
                    MessageBox.Show(
                        "Tiene " + dgv_TablaMovimientos.SelectedRows.Count +
                        " Movimientos seleccionados,Seleccione solo 1", "Precaución!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                if (ValidaMonedero())
                {
                    MonederoPorRedimir Redimir = new MonederoPorRedimir();
                    Redimir.idVenta = ModelSeleccionado.ID;
                    Redimir.ShowDialog();
                }
                else
                {
                    MessageBox.Show(
                        "El movimiento: " + ModelSeleccionado.Mov + " " + ModelSeleccionado.MovId + " " +
                        "no cuenta con monedero a redimir", "Error!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void monederoPorRedimirCrtlPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MonederoXredimirConsulta();
        }

        private void dgv_TablaMovimientos_KeyUp(object sender, KeyEventArgs e)
        {
            //Combinacion de teclas Ctrl + D
            if (Convert.ToInt32(e.KeyData) == Convert.ToInt32(Keys.Control) + Convert.ToInt32(Keys.D))
            {
                if (ListaExplorador.Count > 1)
                {
                    MessageBox.Show(
                        "Tiene " + dgv_TablaMovimientos.SelectedRows.Count +
                        " Movimientos seleccionados,Seleccione solo 1", "Precaución!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                if (ValidaMonedero())
                {
                    MonederoPorRedimir Redimir = new MonederoPorRedimir();
                    Redimir.idVenta = ModelSeleccionado.ID;
                    Redimir.ShowDialog();
                }
                else
                {
                    MessageBox.Show("El cliente: " + ModelSeleccionado.Cliente + " " + "no tiene monedero", "Error!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private bool ValidaMonedero()
        {
            string monedero = ModelSeleccionado.Monedero;

            if (monedero == "Si")
                return true;
            return false;
        }

        #endregion

        //Autor: Rodolfo Sanchez
        //Modulo: Cambiar Prospecto A Cliente
        //Fecha:14/09/2017

        #region CambiarProspectoACliente

        public bool validaProspecto()
        {
            if (ListaExplorador.Count == 0)
                return false;

            string cod = ModelSeleccionado.Cliente.Substring(0, 1);

            if (cod == "P" && ModelSeleccionado.Mov == "Analisis Credito")
                return true;
            return false;
        }


        private void DesabilitarControles(bool estado)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in Controls)
                    if (!item.Enabled)
                        ListaControles.Add(item.Name);
                    else
                        item.Enabled = estado;
            }
            else
            {
                foreach (Control item in Controls)
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
            }

            DeshabilitarRefrescar(estado);
        }


        private void DeshabilitarRefrescar(bool estado)
        {
            if (!estado)
            {
                Panel_Menu.Enabled = true;
                pnlfix_delfix.Enabled = true;
                foreach (Control item in btn_Refrescar.Parent.Controls)
                {
                    item.Enabled = false;
                    item.Cursor = Cursors.Default;
                }

                btn_Refrescar.Visible = false;
                btn_stop.Enabled = true;
                btn_stop.Visible = true;
                btn_stop.Cursor = Cursors.Hand;
            }
            else
            {
                btn_Refrescar.Visible = true;
                btn_stop.Visible = false;
                foreach (Control item in btn_Refrescar.Parent.Controls)
                {
                    item.Enabled = true;
                    item.Cursor = Cursors.Hand;
                }
            }
        }

        #endregion

        #region Botones

        /// <summary>
        ///     metodo encargado de llamar el reporte de cliente express
        /// </summary>
        public void ClienteExpressRm0855()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                if (ModelSeleccionado.EnviarA == "77")
                {
                    int iIdSolicitudDineralia = controladorP.obtenerIdDineralia(ModelSeleccionado.Cliente);
                    Process pDineralia = new Process();
                    pDineralia.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pDineralia.StartInfo.FileName = ClaseEstatica.plugInPath + "FormatosReporte\\FormatosReporte.exe";
                    pDineralia.StartInfo.Verb = "runas";
                    pDineralia.StartInfo.Arguments = "RM0855Dineralia" + " " + iIdSolicitudDineralia + " " + "E050715";
                    pDineralia.StartInfo.UseShellExecute = false;
                    pDineralia.Start();
                }
                else
                {
                    if (ClaseEstatica.ListClientes.Contains(ModelSeleccionado.Cliente))
                    {
                        funciones.CheckFormsOpen("DM0312_RM0855A_ClienteExpress");
                        return;
                    }

                    DM0312_RM0855A_ClienteExpress frm = new DM0312_RM0855A_ClienteExpress();
                    frm.CodCliente = ModelSeleccionado.Cliente;
                    frm.iCanal = int.Parse(ModelSeleccionado.EnviarA);
                    frm.Show();
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnScoring_Click(object sender, EventArgs e)
        {
            scoring();
        }

        /// <summary>
        ///     Evento que se ejecuta el dar click en el toopstrip de scoring (ctrl+Y)
        /// </summary>
        private void menuScoring_Click(object sender, EventArgs e)
        {
            if (btnScoring.Visible) scoring();
        }

        //1286
        private void menuAgregarEvento_Click(object sender, EventArgs e)
        {
            // GESSY 1286 acceso Directo para Ventas

            // ROJOS
            if ((getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR") &&
                ModelSeleccionado.Estatus == "PENDIENTE" && ModelSeleccionado.Mov == "Analisis Credito")
                mostrarfrmEventosReactivacion();

            //Normal
            else if (getTipoUsuario() == "VENTP" || getTipoUsuario() == "VENTR") agregarEvento();

            // GESSY 1286 acceso Normal para Credito
            if (getTipoUsuario() == "CREDI")
                //mostrarEventosNotasCitasView();
                agregarEvento();
        }

        /// <summary>
        ///     Metodo del menustrip encargado de abrir el formulario de la orden de compra
        /// </summary>
        private void menuOrdenCompra_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_TablaMovimientos.Rows.Count > 0)
                {
                    clsModeloOrdenCompra mCompra = new clsModeloOrdenCompra
                    {
                        iIdVenta = ModelSeleccionado.ID,
                        sCliente = ModelSeleccionado.Cliente + " " + ModelSeleccionado.Nombre,
                        sMov = ModelSeleccionado.Mov,
                        sMovId = ModelSeleccionado.MovId
                    };

                    using (Form frmOrdenCompra = new frmOrdenCompra(mCompra))
                    {
                        frmOrdenCompra.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("No se encontraron movimientos", "Punto De Venta", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region Metodos

        /// <summary>
        ///     Metodo encargado de abrir una nueva venta
        /// </summary>
        private void nuevaVenta()
        {
            try
            {
                if (btn_Nuevo.Visible)
                {
                    loginC.checkSession();
                    using (DM0312_VentaEntrada frmVentaEntrada = new DM0312_VentaEntrada())
                    {
                        using (DM0312_VentaEntrada venta =
                               (DM0312_VentaEntrada)UsuarioAcceso.AplicarVistas(frmVentaEntrada))
                        {
                            venta.recibeMensaje = recibeMensaje;
                            Visible = false;
                            venta.ShowDialog();
                            Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void resumenFactura()
        {
            if (btn_ResumenFac.Visible)
                try
                {
                    //-1037-A
                    string sPlugin = string.Empty;
                    string sParametros = string.Empty;


                    bool bMayoreo = false;
                    if (ModelSeleccionado.EnviarA != null)
                        if (int.Parse(ModelSeleccionado.EnviarA) == 11)
                            bMayoreo = true;
                    if (std.validarAccesoResumenFactura() && bMayoreo)
                    {
                        sPlugin = ClaseEstatica.plugInPath + @"ResumenDesempeño\ResumenFactura.exe";
                        if (!string.IsNullOrEmpty(ModelSeleccionado.Cliente))
                            sParametros = ClaseEstatica.Usuario.Usser + " " + ModelSeleccionado.Cliente;
                        else
                            sParametros = ClaseEstatica.Usuario.Usser;
                    }
                    else
                    {
                        if (dgv_TablaMovimientos.Rows.Count <= 0) return;
                        sPlugin = ClaseEstatica.plugInPath + @"inte602.exe";
                        sParametros = ModelSeleccionado.Cliente + " " + ClaseEstatica.Usuario.Usser + " N";
                    }

                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    //pTicket.StartInfo.FileName = pdfPath + @"inte602.exe";
                    pTicket.StartInfo.FileName = sPlugin;
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = sParametros;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.Dispose();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
        }

        /// <summary>
        ///     Metodo encargado de ejecutar el exe de Scoring
        /// </summary>
        private void scoring()
        {
            try
            {
                Process[] localByName = Process.GetProcessesByName("Scoring");
                if (localByName.Length == 0)
                {
                    string sParametros = string.Empty;
                    if (!string.IsNullOrEmpty(ModelSeleccionado.Cliente))
                        sParametros = ModelSeleccionado.Cliente + " " + ClaseEstatica.Usuario.usuario;
                    else
                        sParametros = ClaseEstatica.Usuario.usuario;

                    Process pScoring = new Process();
                    pScoring.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pScoring.StartInfo.FileName = ClaseEstatica.plugInPath + "HerramientaScoring\\Scoring.exe";

                    pScoring.StartInfo.Verb = "runas";
                    pScoring.StartInfo.Arguments = sParametros;
                    pScoring.StartInfo.UseShellExecute = false;
                    pScoring.Start();
                    pScoring.Dispose();
                }
                else
                {
                    MessageBox.Show("La herramienta Scoring ya se encuentra abierta.", "Punto De Venta",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void resumenFacturaNuevo()
        {
            try
            {
                string sParametros = string.Empty;
                if (!string.IsNullOrEmpty(ModelSeleccionado.Cliente))
                    sParametros = ClaseEstatica.Usuario.usuario + " " + ModelSeleccionado.Cliente;
                else
                    sParametros = ClaseEstatica.Usuario.usuario;

                Process pScoring = new Process();
                pScoring.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pScoring.StartInfo.FileName = ClaseEstatica.plugInPath + "ResumenDesempeño\\ResumenFactura.exe";

                pScoring.StartInfo.Verb = "runas";
                pScoring.StartInfo.Arguments = sParametros;
                pScoring.StartInfo.UseShellExecute = false;
                pScoring.Start();
                pScoring.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de cambiar el prospecto a cliente
        /// </summary>
        public async void CambiarProspecto()
        {
            DesabilitarControles(false);

            frmLoading.Show(this);

            DM0312_MCte item = new DM0312_MCte();

            double importe = 0;
            string CredEsp = string.Empty;

            if (validaProspecto())
            {
                string CodCliente = string.Empty;
                DM0312_C_Prospecto_A_Cliente controlador = new DM0312_C_Prospecto_A_Cliente();
                controlador.CodCliente = ModelSeleccionado.Cliente;
                string sProspecto = ModelSeleccionado.Cliente;
                string val = await Task.Run(() => controlador.CambiarProspectos());
                frmLoading.Hide();

                CodCliente = val;
                codigoclienteFin = CodCliente;

                if (CodCliente != string.Empty)
                {
                    MessageBox.Show("El cliente se cambio correctamente Cuenta:" + CodCliente, "Exito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (ModelSeleccionado.EnviarA == "76")
                        detalle.insertarSms(CodCliente, int.Parse(ModelSeleccionado.EnviarA), 36);
                    if (new[] { "76", "80" }.Contains(ModelSeleccionado.EnviarA))
                    {
                        frmLineaCredito limite = new frmLineaCredito(CodCliente, int.Parse(ModelSeleccionado.EnviarA));
                        limite.ShowDialog();
                    }
                    else
                    {
                        DM0312_LineaCredito frm = new DM0312_LineaCredito();
                        frm.Cliente = CodCliente;
                        frm.ShowDialog();
                        importe = frm.Importe;
                        CredEsp = frm.CredEspecial;
                        frmLoading.Show(this);
                        string val_ = await Task.Run(() =>
                            controlador.ActualizaLineaCreditoCte(CodCliente, importe, CredEsp));
                        frmLoading.Hide();
                        MessageBox.Show(val_, "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    if (!new[] { "76", "80" }.Contains(ModelSeleccionado.EnviarA))
                    {
                        #region Dispersion Pedorra

                        BuroDigitalClient shm = new BuroDigitalClient();
                        ValoresValidacionTarjeta oValiTarj = new ValoresValidacionTarjeta();
                        int iInstiBanc = 0;
                        string[] sResuSTP = null, arrsCteF = shm.ObtenerXCliente(CodCliente);

                        if (arrsCteF != null)
                        {
                            DC_Tarjeta dcTarjAltaOExist = shm.ObtenerInfoCLABE2(0, CodCliente);

                            if (new[] { 2, 6 }.Any(c => dcTarjAltaOExist.iValiTD == c))
                            {
                                if (arrsCteF[0] == "OTRO BANCO")
                                    iInstiBanc = 40030;
                                else
                                    int.TryParse(dcTarjAltaOExist.sInstiBanc, out iInstiBanc);

                                sResuSTP = Dispersar(true, ModelSeleccionado.ID, CodCliente, iInstiBanc, arrsCteF[2],
                                    arrsCteF[3], arrsCteF[1], "PuntoVentas", dcTarjAltaOExist.sTipo,
                                    dcTarjAltaOExist.iIDCtaCLABE);


                                if (sResuSTP.Length == 2)
                                {
                                    int.TryParse(sResuSTP[0], out int iIDDisp);

                                    if (iIDDisp > 0)
                                        MessageBox.Show(sResuSTP[1], "SHM", MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                                    else
                                        MessageBox.Show(sResuSTP[1], "SHM", MessageBoxButtons.OK,
                                            MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    MessageBox.Show(sResuSTP[1], "SHM", MessageBoxButtons.OK,
                                        MessageBoxIcon.Exclamation);
                                }
                            }
                        }

                        #endregion
                    }

                    //-Dineralia
                    DM0312_C_Prospecto_A_Cliente cnn = new DM0312_C_Prospecto_A_Cliente();
                    bool bDineralia = cnn.validarDineraliaCliente(CodCliente);
                    if (bDineralia) cnn.actualizarLineaCredito(CodCliente);

                    int result = controlador.CteCtoAvales(CodCliente);

                    if (result > 0)
                    {
                        DM0312_CteAval frm_aval = new DM0312_CteAval();
                        frm_aval.codcliente = CodCliente;
                        frm_aval.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No tiene Avales registrados", "Información", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }

                    frmLoading.Show(this);

                    await Task.Run(() => LlenarHuellasyFotos());

                    frmLoading.Hide();
                    DesabilitarControles(true);

                    if (ClaseEstatica.ListaCte.Count > 0 || ClaseEstatica.ListaAnexoCta.Count > 0)
                    {
                        RegistroDeHuellaCliente huellas = new RegistroDeHuellaCliente();
                        huellas.cliente = CodCliente;
                        huellas.Usuario = lbl_Usuario.Text;
                        huellas.movId = ModelSeleccionado.MovId;
                        huellas.mov = ModelSeleccionado.Mov;
                        huellas.ShowDialog();
                        txt_Buscar.Focus();
                        txt_Buscar.Text = CodCliente;
                        chk_CreditoCasa.Checked = true;
                        cbx_BuscarEn.SelectedIndex = 1;
                    }
                    else
                    {
                        MessageBox.Show("No tiene Registro de huellas", "Información", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        txt_Buscar.Focus();
                        txt_Buscar.Text = CodCliente;
                        chk_CreditoCasa.Checked = true;
                        cbx_BuscarEn.SelectedIndex = 1;
                    }

                    frmLoading.Hide();
                    DesabilitarControles(true);

                    AsyncRunning = false;

                    TableroMovimientos();
                }
                else
                {
                    DesabilitarControles(true);
                }
            }
            else
            {
                frmLoading.Hide();
                MessageBox.Show("El prospecto no es valido para cambiarlo a cliente", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                DesabilitarControles(true);
            }
        }


        #region Dispersion

        /// <summary>
        ///     Método para dispersar cuentas CLABE o tarjetas de debito
        /// </summary>
        /// <param name="bEsMenudeo">Indica si el proceso es para menudeo o para cte finales</param>
        /// <param name="iIdSoli">
        ///     ID del análisis en producción y en caso de no contar con el o dispersar para pruebas usar el Id
        ///     de la solicitud
        /// </param>
        /// <param name="sCte">Cuenta del cliente a quien se le realizara la dispersión</param>
        /// <param name="sDescBanco">Banco al que le pertenece el registro bancario</param>
        /// <param name="sNombComp">Nombre completo del cliente</param>
        /// <param name="sRFC">RFC del cliente</param>
        /// <param name="sTarjBanc">Cuenta CLABE o tarjeta de debito a dispersar</param>
        /// <param name="sPrefijo">Prefijo para generar la clave de rastreo para dispersar</param>
        /// <returns>Retorna un arreglo string con el id de la dispersión y el mensaje que retorna el STP</returns>
        public string[] Dispersar(bool bEsMenudeo, int iIdSoli, string sCte, int iIdBanco, string sNombComp,
            string sRFC, string sTarjBanc, string sPrefijo, string sTipoRegiBanc, int iIdCtaBanc)
        {
            int iIdSTPDisp = 0;
            string sMsg = string.Empty;

            ValoresValidacionTarjeta oValiTarj = new ValoresValidacionTarjeta();
            try
            {
                DC_RespuestaStp oResp = DispersarProduccion(iIdSoli, sCte, iIdBanco, sNombComp, sTarjBanc, sRFC,
                    sPrefijo, sTipoRegiBanc);

                if (oResp == null)
                    sMsg = "Fallo respuesta del servicio STP";
                else
                    iIdSTPDisp = oResp.iId;
                using (BuroDigitalClient oBuroDigi = new BuroDigitalClient())
                {
                    if (iIdSTPDisp > 0)
                    {
                        oBuroDigi.ActualizarEstatusTarjeta2(iIdCtaBanc, oValiTarj.EnviadoValidar);
                        sMsg = oResp.sMensaje;

                        // oBuroDigi.ActualizarIdDispersionTarjeta2(iIdCtaBanc, iIdSTPDisp);
                        if (bEsMenudeo)
                            oBuroDigi.ValidarCLABEMenu(sCte);
                    }
                    else
                    {
                        sMsg = "Error de conexión con STP: " + oResp.sMensaje;
                        oBuroDigi.ActualizarEstatusTarjeta2(iIdCtaBanc, oValiTarj.ErrorConexion);
                    }
                }
            }
            catch (Exception ex)
            {
                using (BuroDigitalClient oBuroDigi = new BuroDigitalClient())
                {
                    oBuroDigi.ActualizarEstatusTarjeta2(iIdCtaBanc, oValiTarj.ErrorConexion);
                }

                sMsg = "Error: " + ex.Message;
            }

            return new[] { iIdSTPDisp.ToString(), sMsg };
        }


        public DC_RespuestaStp DispersarProduccion(int iIDAnali, string sCte, int iInstBanc, string sNomb,
            string sNumCLABE, string sRFC, string sPrefijo, string sTipoRegiBanc)
        {
            CDetalleVenta detalleVenta = new CDetalleVenta();
            int iClaveTarjDebi = 0;
            string sClaveRastreo = string.Empty, sClaveMapeada = string.Empty;
            int iReferenciaNum = 0;
            string sConseptoPago = "Validacion", sUsuario = "", sApp = "PuntoVenta";

            using (BuroDigitalClient oBuroDigi = new BuroDigitalClient())
            {
                sClaveRastreo = oBuroDigi.ObtenerClaveRastreoUnica(sPrefijo);
                int.TryParse(oBuroDigi.ObtenerClaveCuentaDebito2(sTipoRegiBanc?.Replace("débito", "debito").ToUpper()),
                    out iClaveTarjDebi);

                if (sTipoRegiBanc.Contains("Tarjeta") && iInstBanc != 40030)
                {
                    sClaveMapeada = oBuroDigi.MapearInstitucionBancariaDebito(iInstBanc.ToString());
                    int.TryParse(sClaveMapeada, out iInstBanc);
                }
            }

            int.TryParse(sClaveRastreo.Substring(3, sClaveRastreo.Length - 3), out iReferenciaNum);

            DispersionClient servDisp = new DispersionClient();
            return servDisp.AplicarValidacionSTP(sCte, iIDAnali, sClaveRastreo, iReferenciaNum,
                ReemplazarCaracteresEspeciales(sNomb), sRFC, sNumCLABE, sConseptoPago, iClaveTarjDebi, iInstBanc,
                sUsuario, sApp);
        }

        public string ReemplazarCaracteresEspeciales(string sCadena)
        {
            return sCadena.ToUpper().Replace("Á", "A").Replace("É", "E").Replace("Í", "I").Replace("Ó", "O")
                .Replace("Ú", "U").Replace("Ñ", "N");
        }

        #endregion

        private void cuentaClabe()
        {
            if (ModelSeleccionado != null)
                if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                {
                    Process System = new Process();
                    System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                    System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                    System.StartInfo.Verb = "runas";
                    System.StartInfo.Arguments = "VALIDACLABEBANCARIA " + " " + ModelSeleccionado.Cliente + " " +
                                                 ModelSeleccionado.ID + " " + ClaseEstatica.Usuario.usuario;
                    System.StartInfo.UseShellExecute = false;
                    System.Start();
                    System.WaitForExit();
                }
        }

        #endregion 1381-A

        #region ToolTip

        #endregion

        #region 1286

        private void menuRecalificar_Click(object sender, EventArgs e)
        {
            if (ModelSeleccionado.Mov != "Analisis Credito" && ModelSeleccionado.Estatus != "Pendiente")
            {
                MessageBox.Show("La opcion recalificar solo esta disponible para Analisis de Credito");
                return;
            }

            bool sancionCerrada = false;

            using (frmSancion sancion = new frmSancion())
            {
                if (dgv_Eventos.SelectedCells.Count > 0)
                {
                    DataGridViewRow selectedEventRow = dgv_Eventos.Rows[dgv_Eventos.SelectedCells[0].RowIndex];
                    DataGridViewRow selectMovimientoRow =
                        dgv_TablaMovimientos.Rows[dgv_TablaMovimientos.SelectedCells[0].RowIndex];

                    string[] cali = Convert.ToString(selectedEventRow.Cells["Calificacion"].Value).Split(' ');
                    string[] movimiento = Convert.ToString(selectMovimientoRow.Cells["Movimiento"].Value).Split(' ');

                    sancion.calificacionEvento = cali[0];

                    sancion.cliente = selectMovimientoRow.Cells["Cliente"].Value.ToString();
                    sancion.idEvento = selectedEventRow.Cells["Id"].Value.ToString();
                    sancion.sucursal = selectMovimientoRow.Cells["Suc"].Value.ToString();
                    sancion.usuarioCredito = ClaseEstatica.Usuario.usuario;
                    sancion.movID = movimiento[movimiento.Length - 1];
                    sancion.vendedor = selectMovimientoRow.Cells["Agente"].Value.ToString();
                    sancion.monto = selectMovimientoRow.Cells["ImporteTotal"].Value.ToString();
                    sancion.observaciones = selectedEventRow.Cells["Observaciones"].Value.ToString();

                    sancion.ShowDialog();
                    sancionCerrada = sancion.cerrado;
                }
            }

            if (sancionCerrada) return;

            using (editarEvento editarEvento = new editarEvento(ModelSeleccionado))
            {
                if (dgv_Eventos.Rows.Count > 0)
                {
                    editarEvento.ShowDialog();
                    FillDataGridEventos();
                }
            }
        }

        private void NotificarAnalista_Click(object sender, EventArgs e)
        {
            EnviarConAnalista EA = new EnviarConAnalista(ModelSeleccionado);
            EA.ShowDialog();
            FillDataGridEventos();
        }


        // 1286
        private void mostrarEventosNotasCitasView()
        {
            if (dgv_TablaMovimientos.Rows.Count > 0)
            {
                DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas(ModelSeleccionado);

                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                eventNotaCita = (DM0312_EventosNotasCitas)UsuarioAcceso.AplicarVistas(eventNotaCita);

                eventNotaCita.ShowDialog();
                if (EjecutaEvento)
                    dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos, new DataGridViewCellEventArgs(0, 0));
                txt_Buscar.Focus();

                if (EjecutaEvento)
                {
                    dgv_TablaMovimientos_CellClick_1(dgv_TablaMovimientos,
                        new DataGridViewCellEventArgs(0, 0));
                    if (dgv_TablaMovimientos.Rows.Count == 1)
                        TableroMovimientos2(ModelSeleccionado.Mov, ModelSeleccionado.Situacion,
                            ModelSeleccionado.Estatus,
                            ModelSeleccionado.MovId);
                }
            }
            else
            {
                MessageBox.Show("No hay registros", "Error!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
        }


        /// <summary>
        ///     Evento encargado de abrir el formulario de posicion de movimientos
        /// </summary>
        private void btnPosicionDelMovimiento_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_TablaMovimientos.Rows.Count > 0)
                    using (frmPosicionDeMovimiento posicionDeMovimiento =
                           new frmPosicionDeMovimiento(ModelSeleccionado.ID, ModelSeleccionado.Movimiento))
                    {
                        posicionDeMovimiento.ShowDialog();
                    }
                else
                    MessageBox.Show("No hay información para mostrar", "Punto De venta", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
    }
}