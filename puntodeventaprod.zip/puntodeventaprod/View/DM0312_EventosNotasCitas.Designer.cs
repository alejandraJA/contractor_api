﻿namespace PuntoVenta
{
    partial class DM0312_EventosNotasCitas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_EventosNotasCitas));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.chk_Eventos = new System.Windows.Forms.CheckBox();
            this.btn_AgregarEvento = new System.Windows.Forms.Button();
            this.btn_Consultar = new System.Windows.Forms.Button();
            this.chk_CitaSupervicion = new System.Windows.Forms.CheckBox();
            this.chk_Nota = new System.Windows.Forms.CheckBox();
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_Mov = new System.Windows.Forms.Label();
            this.lbl_MovID = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.txt_ComentarioAyuda);
            this.groupBox1.Controls.Add(this.chk_Eventos);
            this.groupBox1.Controls.Add(this.btn_AgregarEvento);
            this.groupBox1.Controls.Add(this.btn_Consultar);
            this.groupBox1.Controls.Add(this.chk_CitaSupervicion);
            this.groupBox1.Controls.Add(this.chk_Nota);
            this.groupBox1.Location = new System.Drawing.Point(76, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(547, 289);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.White;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(6, 19);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.ReadOnly = true;
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(525, 34);
            this.txt_ComentarioAyuda.TabIndex = 51;
            // 
            // chk_Eventos
            // 
            this.chk_Eventos.AutoSize = true;
            this.chk_Eventos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chk_Eventos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Eventos.Location = new System.Drawing.Point(57, 82);
            this.chk_Eventos.Name = "chk_Eventos";
            this.chk_Eventos.Size = new System.Drawing.Size(61, 19);
            this.chk_Eventos.TabIndex = 1;
            this.chk_Eventos.Text = "Evento";
            this.chk_Eventos.UseVisualStyleBackColor = true;
            this.chk_Eventos.CheckedChanged += new System.EventHandler(this.chk_Eventos_CheckedChanged);
            this.chk_Eventos.Click += new System.EventHandler(this.chk_Eventos_Click);
            // 
            // btn_AgregarEvento
            // 
            this.btn_AgregarEvento.BackColor = System.Drawing.Color.White;
            this.btn_AgregarEvento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AgregarEvento.FlatAppearance.BorderSize = 0;
            this.btn_AgregarEvento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgregarEvento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AgregarEvento.Image = ((System.Drawing.Image)(resources.GetObject("btn_AgregarEvento.Image")));
            this.btn_AgregarEvento.Location = new System.Drawing.Point(313, 65);
            this.btn_AgregarEvento.Name = "btn_AgregarEvento";
            this.btn_AgregarEvento.Size = new System.Drawing.Size(164, 70);
            this.btn_AgregarEvento.TabIndex = 2;
            this.btn_AgregarEvento.Text = "Agregar ";
            this.btn_AgregarEvento.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_AgregarEvento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_AgregarEvento.UseVisualStyleBackColor = false;
            this.btn_AgregarEvento.Click += new System.EventHandler(this.btn_AgregarEvento_Click);
            // 
            // btn_Consultar
            // 
            this.btn_Consultar.BackColor = System.Drawing.Color.White;
            this.btn_Consultar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Consultar.FlatAppearance.BorderSize = 0;
            this.btn_Consultar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Consultar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Consultar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Consultar.Image")));
            this.btn_Consultar.Location = new System.Drawing.Point(313, 175);
            this.btn_Consultar.Name = "btn_Consultar";
            this.btn_Consultar.Size = new System.Drawing.Size(164, 70);
            this.btn_Consultar.TabIndex = 3;
            this.btn_Consultar.Text = "Consultar ";
            this.btn_Consultar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Consultar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Consultar.UseVisualStyleBackColor = false;
            this.btn_Consultar.Click += new System.EventHandler(this.btn_Consultar_Click);
            // 
            // chk_CitaSupervicion
            // 
            this.chk_CitaSupervicion.AutoSize = true;
            this.chk_CitaSupervicion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chk_CitaSupervicion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_CitaSupervicion.Location = new System.Drawing.Point(57, 215);
            this.chk_CitaSupervicion.Name = "chk_CitaSupervicion";
            this.chk_CitaSupervicion.Size = new System.Drawing.Size(117, 19);
            this.chk_CitaSupervicion.TabIndex = 7;
            this.chk_CitaSupervicion.Text = "Cita Supervision";
            this.chk_CitaSupervicion.UseVisualStyleBackColor = true;
            this.chk_CitaSupervicion.CheckedChanged += new System.EventHandler(this.chkCitaSupervicion_CheckedChanged);
            this.chk_CitaSupervicion.Click += new System.EventHandler(this.chk_CitaSupervicion_Click);
            // 
            // chk_Nota
            // 
            this.chk_Nota.AutoSize = true;
            this.chk_Nota.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chk_Nota.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Nota.Location = new System.Drawing.Point(57, 155);
            this.chk_Nota.Name = "chk_Nota";
            this.chk_Nota.Size = new System.Drawing.Size(51, 19);
            this.chk_Nota.TabIndex = 6;
            this.chk_Nota.Text = "Nota";
            this.chk_Nota.UseVisualStyleBackColor = true;
            this.chk_Nota.CheckedChanged += new System.EventHandler(this.chkNota_CheckedChanged);
            this.chk_Nota.Click += new System.EventHandler(this.chk_Nota_Click);
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(73, 314);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(47, 15);
            this.lbl_Cliente.TabIndex = 1;
            this.lbl_Cliente.Text = "Cliente";
            // 
            // lbl_Mov
            // 
            this.lbl_Mov.AutoSize = true;
            this.lbl_Mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mov.Location = new System.Drawing.Point(375, 314);
            this.lbl_Mov.Name = "lbl_Mov";
            this.lbl_Mov.Size = new System.Drawing.Size(29, 15);
            this.lbl_Mov.TabIndex = 2;
            this.lbl_Mov.Text = "Mov";
            // 
            // lbl_MovID
            // 
            this.lbl_MovID.AutoSize = true;
            this.lbl_MovID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MovID.Location = new System.Drawing.Point(532, 314);
            this.lbl_MovID.Name = "lbl_MovID";
            this.lbl_MovID.Size = new System.Drawing.Size(42, 15);
            this.lbl_MovID.TabIndex = 3;
            this.lbl_MovID.Text = "MovID";
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ayuda.Location = new System.Drawing.Point(1, 92);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(69, 59);
            this.btn_ayuda.TabIndex = 5;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(1, 12);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(69, 74);
            this.btn_Regresar.TabIndex = 4;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Cliente:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(295, 314);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Movimiento:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(480, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "MovID:";
            // 
            // DM0312_EventosNotasCitas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(634, 338);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_ayuda);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.lbl_MovID);
            this.Controls.Add(this.lbl_Mov);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "DM0312_EventosNotasCitas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Eventos Notas y Citas";
            this.Load += new System.EventHandler(this.EventosNotasCitas_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_EventosNotasCitas_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_AgregarEvento;
        private System.Windows.Forms.Button btn_Consultar;
        private System.Windows.Forms.CheckBox chk_CitaSupervicion;
        private System.Windows.Forms.CheckBox chk_Nota;
        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.Label lbl_Mov;
        private System.Windows.Forms.Label lbl_MovID;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.CheckBox chk_Eventos;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}