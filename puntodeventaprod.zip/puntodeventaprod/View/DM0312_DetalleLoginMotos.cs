﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using fnPassword;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleLoginMotos : Form
    {
        public static bool LoginCorrecto;
        public static bool Regresar;

        public DM0312_DetalleLoginMotos()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
        }

        ~DM0312_DetalleLoginMotos()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Boton para checar el login
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        public void GuardarLoginM()
        {
            if (txt_usuario.Text != string.Empty && txt_password.Text != string.Empty)
            {
                SqlCommand sqlCommand = new SqlCommand(
                    "SELECT U.Contrasena FROM Usuario U WITH(NOLOCK) INNER JOIN TablaStD D WITH(NOLOCK) ON U.ACCESO=D.NOMBRE " +
                    "WHERE D.TablaSt ='ACCESO CANCELACION RECIBOS' AND U.Usuario = @Usuario",
                    ClaseEstatica.ConexionEstatica)
                {
                    CommandType = CommandType.Text
                };
                sqlCommand.Parameters.AddWithValue("@Usuario", txt_usuario.Text.ToUpper());
                try
                {
                    SqlDataReader dr = sqlCommand.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                            if (dr["Contrasena"] != null && dr["Contrasena"].ToString() != string.Empty)
                            {
                                if (dr["Contrasena"].ToString() ==
                                    Intelisis.getHash(txt_password.Text.ToUpper(),
                                        "P") /*CDetalleVenta.MD5Hash(txt_password.Text.ToUpper())*/)
                                {
                                    LoginCorrecto = true;
                                    Close();
                                }
                                else
                                {
                                    MessageBox.Show("Usuario y/o contraseña no validos", "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                                }
                            }
                    }
                    else
                    {
                        MessageBox.Show("Usuario y/o contraseña no validos", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError("Aceptar_Click", "DM0312_DetalleLoginMotos.cs", ex);
                    MessageBox.Show(ex.Message + " function: Aceptar_Click, clase: DM0312_DetalleLoginMotos.cs");
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña vacio", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Aceptar_Click(object sender, EventArgs e)
        {
            GuardarLoginM();
        }

        /// <summary>
        ///     Boton regresar cierra login
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///     cierre de login
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">FormClosedEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        private void DM0312_LoginMotos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Regresar = true;
        }

        /// <summary>
        ///     Keypress usuario
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 05/10/17
        private void Txt_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13) txt_password.Focus();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleLoginMotos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.Control && e.KeyCode == Keys.G) GuardarLoginM();
        }

        private void txt_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void DM0312_DetalleLoginMotos_Load(object sender, EventArgs e)
        {
            txt_Comentarios.Text = "INGRESAR USUARIO Y CONTRASEÑA PARA VALIDAR LA SERIE DE MOTOCICLETA";
            toolTip1.SetToolTip(txt_usuario, "INGRESAR LA CUENTA DEL USUARIO QUE VALIDA LA SERIE INGRESADA A LA SERIE");
            toolTip1.SetToolTip(txt_password, "INGRESAR LA CONTRASEÑA LIGADA AL USUARIO");
            toolTip1.SetToolTip(Aceptar, "SELECCIONAR UNA VEZ IGRESADO UN USUARIO Y CONTRASEÑA CORRECTA");
            toolTip1.SetToolTip(btn_Regresar, "CANCELAR LA VALIDACION DE LA MOTOCICLETA");
        }
    }
}