﻿namespace PuntoVenta.View
{
    partial class DM0312_Redime
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_Redime));
            this.FlowPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBoxDimaTipo = new System.Windows.Forms.GroupBox();
            this.rbtn_Virtual = new System.Windows.Forms.RadioButton();
            this.rbtn_Normal = new System.Windows.Forms.RadioButton();
            this.groupBoxGenera = new System.Windows.Forms.GroupBox();
            this.txtGenSaldo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtGenNoMone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxRedime = new System.Windows.Forms.GroupBox();
            this.txtRediImporte = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRediSaldo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRediNoMone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxAutoriza = new System.Windows.Forms.GroupBox();
            this.txtPwd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.FlowPanel.SuspendLayout();
            this.groupBoxDimaTipo.SuspendLayout();
            this.groupBoxGenera.SuspendLayout();
            this.groupBoxRedime.SuspendLayout();
            this.groupBoxAutoriza.SuspendLayout();
            this.SuspendLayout();
            // 
            // FlowPanel
            // 
            this.FlowPanel.AutoSize = true;
            this.FlowPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.FlowPanel.BackColor = System.Drawing.Color.White;
            this.FlowPanel.Controls.Add(this.groupBoxDimaTipo);
            this.FlowPanel.Controls.Add(this.groupBoxGenera);
            this.FlowPanel.Controls.Add(this.groupBoxRedime);
            this.FlowPanel.Controls.Add(this.groupBoxAutoriza);
            this.FlowPanel.Controls.Add(this.btnAceptar);
            this.FlowPanel.Controls.Add(this.btnCancelar);
            this.FlowPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlowPanel.Location = new System.Drawing.Point(0, 0);
            this.FlowPanel.Name = "FlowPanel";
            this.FlowPanel.Size = new System.Drawing.Size(564, 428);
            this.FlowPanel.TabIndex = 0;
            // 
            // groupBoxDimaTipo
            // 
            this.groupBoxDimaTipo.Controls.Add(this.rbtn_Virtual);
            this.groupBoxDimaTipo.Controls.Add(this.rbtn_Normal);
            this.groupBoxDimaTipo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDimaTipo.Location = new System.Drawing.Point(3, 3);
            this.groupBoxDimaTipo.Name = "groupBoxDimaTipo";
            this.groupBoxDimaTipo.Size = new System.Drawing.Size(544, 52);
            this.groupBoxDimaTipo.TabIndex = 5;
            this.groupBoxDimaTipo.TabStop = false;
            this.groupBoxDimaTipo.Text = "Tipo Monedero";
            // 
            // rbtn_Virtual
            // 
            this.rbtn_Virtual.AutoSize = true;
            this.rbtn_Virtual.Location = new System.Drawing.Point(344, 19);
            this.rbtn_Virtual.Name = "rbtn_Virtual";
            this.rbtn_Virtual.Size = new System.Drawing.Size(65, 19);
            this.rbtn_Virtual.TabIndex = 1;
            this.rbtn_Virtual.TabStop = true;
            this.rbtn_Virtual.Text = "Virtual";
            this.rbtn_Virtual.UseVisualStyleBackColor = true;
            this.rbtn_Virtual.CheckedChanged += new System.EventHandler(this.rbtn_Virtual_CheckedChanged);
            // 
            // rbtn_Normal
            // 
            this.rbtn_Normal.AutoSize = true;
            this.rbtn_Normal.Location = new System.Drawing.Point(104, 19);
            this.rbtn_Normal.Name = "rbtn_Normal";
            this.rbtn_Normal.Size = new System.Drawing.Size(66, 19);
            this.rbtn_Normal.TabIndex = 0;
            this.rbtn_Normal.TabStop = true;
            this.rbtn_Normal.Text = "Normal";
            this.rbtn_Normal.UseVisualStyleBackColor = true;
            this.rbtn_Normal.CheckedChanged += new System.EventHandler(this.rbtn_Normal_CheckedChanged);
            // 
            // groupBoxGenera
            // 
            this.groupBoxGenera.Controls.Add(this.txtGenSaldo);
            this.groupBoxGenera.Controls.Add(this.label2);
            this.groupBoxGenera.Controls.Add(this.txtGenNoMone);
            this.groupBoxGenera.Controls.Add(this.label1);
            this.groupBoxGenera.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGenera.Location = new System.Drawing.Point(3, 61);
            this.groupBoxGenera.Name = "groupBoxGenera";
            this.groupBoxGenera.Size = new System.Drawing.Size(544, 71);
            this.groupBoxGenera.TabIndex = 0;
            this.groupBoxGenera.TabStop = false;
            this.groupBoxGenera.Text = "Genera Puntos";
            // 
            // txtGenSaldo
            // 
            this.txtGenSaldo.Enabled = false;
            this.txtGenSaldo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGenSaldo.Location = new System.Drawing.Point(355, 29);
            this.txtGenSaldo.Name = "txtGenSaldo";
            this.txtGenSaldo.Size = new System.Drawing.Size(148, 22);
            this.txtGenSaldo.TabIndex = 4;
            this.txtGenSaldo.Text = "$0.00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(301, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Saldo:";
            // 
            // txtGenNoMone
            // 
            this.txtGenNoMone.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGenNoMone.Location = new System.Drawing.Point(101, 29);
            this.txtGenNoMone.MaxLength = 11;
            this.txtGenNoMone.Name = "txtGenNoMone";
            this.txtGenNoMone.PasswordChar = '*';
            this.txtGenNoMone.Size = new System.Drawing.Size(148, 22);
            this.txtGenNoMone.TabIndex = 3;
            this.txtGenNoMone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGenNoMone_KeyPress);
            this.txtGenNoMone.Leave += new System.EventHandler(this.txtGenNoMone_Leave);
            this.txtGenNoMone.Validating += new System.ComponentModel.CancelEventHandler(this.txtGenNoMone_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "No.  Monedero:";
            // 
            // groupBoxRedime
            // 
            this.groupBoxRedime.Controls.Add(this.txtRediImporte);
            this.groupBoxRedime.Controls.Add(this.label5);
            this.groupBoxRedime.Controls.Add(this.txtRediSaldo);
            this.groupBoxRedime.Controls.Add(this.label3);
            this.groupBoxRedime.Controls.Add(this.txtRediNoMone);
            this.groupBoxRedime.Controls.Add(this.label4);
            this.groupBoxRedime.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxRedime.Location = new System.Drawing.Point(3, 145);
            this.groupBoxRedime.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.groupBoxRedime.Name = "groupBoxRedime";
            this.groupBoxRedime.Size = new System.Drawing.Size(544, 96);
            this.groupBoxRedime.TabIndex = 1;
            this.groupBoxRedime.TabStop = false;
            this.groupBoxRedime.Text = "Redimir Puntos";
            // 
            // txtRediImporte
            // 
            this.txtRediImporte.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRediImporte.Location = new System.Drawing.Point(217, 64);
            this.txtRediImporte.MaxLength = 10;
            this.txtRediImporte.Name = "txtRediImporte";
            this.txtRediImporte.Size = new System.Drawing.Size(148, 22);
            this.txtRediImporte.TabIndex = 7;
            this.txtRediImporte.Text = "$0.00";
            this.txtRediImporte.Click += new System.EventHandler(this.txtRediImporte_Click);
            this.txtRediImporte.Enter += new System.EventHandler(this.txtRediImporte_Enter);
            this.txtRediImporte.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRediImporte_KeyPress);
            this.txtRediImporte.Leave += new System.EventHandler(this.txtRediImporte_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(166, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Importe:";
            // 
            // txtRediSaldo
            // 
            this.txtRediSaldo.Enabled = false;
            this.txtRediSaldo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRediSaldo.Location = new System.Drawing.Point(354, 32);
            this.txtRediSaldo.Name = "txtRediSaldo";
            this.txtRediSaldo.Size = new System.Drawing.Size(148, 22);
            this.txtRediSaldo.TabIndex = 6;
            this.txtRediSaldo.Text = "$0.00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(301, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Saldo:";
            // 
            // txtRediNoMone
            // 
            this.txtRediNoMone.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRediNoMone.Location = new System.Drawing.Point(101, 29);
            this.txtRediNoMone.MaxLength = 11;
            this.txtRediNoMone.Name = "txtRediNoMone";
            this.txtRediNoMone.PasswordChar = '*';
            this.txtRediNoMone.Size = new System.Drawing.Size(148, 22);
            this.txtRediNoMone.TabIndex = 5;
            this.txtRediNoMone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRediNoMone_KeyPress);
            this.txtRediNoMone.Leave += new System.EventHandler(this.txtRediNoMone_Leave);
            this.txtRediNoMone.Validating += new System.ComponentModel.CancelEventHandler(this.txtRediNoMone_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "No.  Monedero:";
            // 
            // groupBoxAutoriza
            // 
            this.groupBoxAutoriza.Controls.Add(this.txtPwd);
            this.groupBoxAutoriza.Controls.Add(this.label6);
            this.groupBoxAutoriza.Controls.Add(this.txtUser);
            this.groupBoxAutoriza.Controls.Add(this.label7);
            this.groupBoxAutoriza.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAutoriza.Location = new System.Drawing.Point(3, 247);
            this.groupBoxAutoriza.Name = "groupBoxAutoriza";
            this.groupBoxAutoriza.Size = new System.Drawing.Size(544, 73);
            this.groupBoxAutoriza.TabIndex = 2;
            this.groupBoxAutoriza.TabStop = false;
            this.groupBoxAutoriza.Text = "Autoriza";
            // 
            // txtPwd
            // 
            this.txtPwd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPwd.Location = new System.Drawing.Point(354, 34);
            this.txtPwd.Name = "txtPwd";
            this.txtPwd.PasswordChar = '*';
            this.txtPwd.Size = new System.Drawing.Size(148, 22);
            this.txtPwd.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Contraseña:";
            // 
            // txtUser
            // 
            this.txtUser.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.Location = new System.Drawing.Point(101, 34);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(138, 22);
            this.txtUser.TabIndex = 8;
            this.txtUser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUser_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 15);
            this.label7.TabIndex = 4;
            this.label7.Text = "Usuario:";
            // 
            // btnAceptar
            // 
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("btnAceptar.Image")));
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAceptar.Location = new System.Drawing.Point(358, 328);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(358, 5, 3, 10);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 76);
            this.btnAceptar.TabIndex = 3;
            this.btnAceptar.Text = "Aceptar (Crtl-G)";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancelar.Location = new System.Drawing.Point(439, 328);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 76);
            this.btnCancelar.TabIndex = 4;
            this.btnCancelar.Text = "Cancelar (Esc)";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // DM0312_Redime
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(564, 428);
            this.ControlBox = false;
            this.Controls.Add(this.FlowPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_Redime";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Redencion o Generacion de puntos";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_Redime_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_Redime_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_Redime_KeyDown);
            this.FlowPanel.ResumeLayout(false);
            this.groupBoxDimaTipo.ResumeLayout(false);
            this.groupBoxDimaTipo.PerformLayout();
            this.groupBoxGenera.ResumeLayout(false);
            this.groupBoxGenera.PerformLayout();
            this.groupBoxRedime.ResumeLayout(false);
            this.groupBoxRedime.PerformLayout();
            this.groupBoxAutoriza.ResumeLayout(false);
            this.groupBoxAutoriza.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel FlowPanel;
        private System.Windows.Forms.GroupBox groupBoxGenera;
        private System.Windows.Forms.TextBox txtGenNoMone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtGenSaldo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxRedime;
        private System.Windows.Forms.TextBox txtRediSaldo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRediNoMone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRediImporte;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBoxAutoriza;
        private System.Windows.Forms.TextBox txtPwd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox groupBoxDimaTipo;
        private System.Windows.Forms.RadioButton rbtn_Virtual;
        private System.Windows.Forms.RadioButton rbtn_Normal;

    }
}