﻿//-PrimeraFaseDeAutomatizacion //-ReservaOnline

using System;
using System.Net.Mail;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class frmSolicitudContraseña : Form
    {
        private readonly clsSolicitudCodigo clsSolicitudCodigo = new clsSolicitudCodigo();

        public frmSolicitudContraseña()
        {
            InitializeComponent();
            maskedTextBox1.PasswordChar = '*';
            maskedTextBox2.PasswordChar = '*';
        }

        public bool bEsCorrecto { get; set; }

        ~frmSolicitudContraseña()
        {
            GC.Collect();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            bEsCorrecto = false;
            string sClaveUno = maskedTextBox1.Text;
            string sClaveDos = maskedTextBox2.Text;

            if (!string.IsNullOrEmpty(maskedTextBox1.Text) || !string.IsNullOrEmpty(maskedTextBox2.Text))
            {
                if (sClaveUno == sClaveDos)
                {
                    string sEstatus = clsSolicitudCodigo.validarEstatusClave(sClaveUno);
                    if (sEstatus != "CONCLUIDO")
                    {
                        string sClave = clsSolicitudCodigo.obtenerClave(sClaveUno);
                        if (sClave == sClaveUno)
                        {
                            MessageBox.Show("Datos Validados Correctamente", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            bEsCorrecto = true;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("La Clave Ingresada No Es Correcta", "Puntos De Venta",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            maskedTextBox1.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("La clave ingresada pertenece a un pedido " + sEstatus + "", "Punto De Venta",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Las Claves Ingresadas No Coinciden", "Puntos De Venta", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    maskedTextBox1.Focus();
                }
            }
            else
            {
                MessageBox.Show("Algun campo esta vacio favor de revisar", "Puntos De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        public bool validarCorreo(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private void maskedTextBox1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) maskedTextBox2.Focus();
        }

        private void maskedTextBox2_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnAceptar_Click(null, null);
        }
    }
}