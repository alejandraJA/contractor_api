﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_DetalleInformacionArticulo : Form
    {
        public static string ArticuloSeleccionado = string.Empty;
        private List<ArticuloAlmacenes> Almacenes;
        private readonly CInfoArticulos CInfoArticulos = new CInfoArticulos();
        public List<ArticulosDetalleVenta> DetallesPaquete = new List<ArticulosDetalleVenta>();
        public bool EsPaquete = false;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();

        public DM0312_DetalleInformacionArticulo()
        {
            InitializeComponent();
            frmLoading.LoaderCentrado = false;
        }

        ~DM0312_DetalleInformacionArticulo()
        {
            GC.Collect();
        }

        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        /// <summary>
        ///     Form load de la forma
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/07/2017
        private void InfoArticulo_Load(object sender, EventArgs e)
        {
            dgv_Almacenes.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 12f, FontStyle.Bold);
            dgv_Almacenes.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            lbl_mavi.Font = new Font(lbl_mavi.Font, FontStyle.Regular);
            lbl_viu.Font = new Font(lbl_viu.Font, FontStyle.Regular);
            lbl_bodega.Font = new Font(lbl_bodega.Font, FontStyle.Regular);
            lbl_todos.Font = new Font(lbl_todos.Font, FontStyle.Bold);
            frmLoading.Width = 150;
            frmLoading.Height = 150;
            frmLoading.StartPosition = FormStartPosition.Manual;
            frmLoading.Location = Location;
            frmLoading.Location =
                new Point(Location.X + dgv_Almacenes.Location.X, Location.Y + dgv_Almacenes.Location.Y);
            frmLoading.Location = new Point(frmLoading.Location.X + 200, frmLoading.Location.Y + 220);
            if (!EsPaquete)
                LLenarAlmacenes(ArticuloSeleccionado);
            else
                LLenarPaquetes(ArticuloSeleccionado);

            txt_Comentarios.Text = "ASISTENTE DONDE SE MUESTRA LOS DATOS MAS IMPORTANTES DEL ARTICULO A VENDER";
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR AL DETALLE DE LA VENTA");
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            toolTip1.SetToolTip(btn_VentaPendiente,
                "SELECCIONAR PARA VER LAS VENTAS PENDIENTES SOBRE EL ARTICULO " + ArticuloSeleccionado);
            toolTip1.SetToolTip(label1, "DESCRIPCION DEL ARTICULO");
            toolTip1.SetToolTip(label3, "EL TIPO EN EL QUE SE AGRUPA EL ARTICULO");
            toolTip1.SetToolTip(label2, "CATEGORIA DEL ARTICULO");
            toolTip1.SetToolTip(label6, "FAMILIA DEL ARTICULO");
            toolTip1.SetToolTip(label10, "LINEA DEL ARTICULO");
            toolTip1.SetToolTip(label4, "UNIDAD DE VENTA DEL ARTICULO");
            toolTip1.SetToolTip(label7, "EL IMPUESTO QUE GENRA EL ARTICULO");

            toolTip1.SetToolTip(label9, "CATEGORIA DE ACTIVO FIJO DEL ARTICULO");
            toolTip1.SetToolTip(label5, "ESTATUS DEL ARTICULO PUEDE SER: BAJA, ALTA Y BLOQUEADO");
            toolTip1.SetToolTip(txt_Descripcion, "DESCRIPCION DEL ARTICULO");
            toolTip1.SetToolTip(txt_Tipo, "EL TIPO EN EL QUE SE AGRUPA EL ARTICULO");
            toolTip1.SetToolTip(txt_Categoria, "CATEGORIA DEL ARTICULO");
            toolTip1.SetToolTip(txt_Familia, "FAMILIA DEL ARTICULO");
            toolTip1.SetToolTip(txt_linea, "LINEA DEL ARTICULO");
            toolTip1.SetToolTip(txt_UnidadVenta, "UNIDAD DE VENTA DEL ARTICULO");
            toolTip1.SetToolTip(txt_IVA, "EL IMPUESTO QUE GENRA EL ARTICULO");
            toolTip1.SetToolTip(txt_CategoriaAF, "CATEGORIA DE ACTIVO FIJO DEL ARTICULO");
            toolTip1.SetToolTip(txt_Estatus, "ESTATUS DEL ARTICULO PUEDE SER: BAJA, ALTA Y BLOQUEADO");

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_Almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        /// <summary>
        ///     Llena la tabla de almacenes
        /// </summary>
        /// <param name="ArticuloSeleccionado">string</param>
        /// <param name="almacen">string</param>
        /// Developer: Dan Palacios
        /// Date: 18/07/2017
        private async void LLenarAlmacenes(string ArticuloSeleccionado, string almacen = "")
        {
            DataTable dtCaracteristicas = new DataTable();

            if (ArticuloSeleccionado != string.Empty)
            {
                CInfoArticulos CInfoArticulos = new CInfoArticulos();
                int enteroPrimeraFila = 0;
                dtCaracteristicas = CInfoArticulos.ConsultaInfoArticulos(ArticuloSeleccionado);
                txt_Descripcion.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Descripcion1"].ToString();
                txt_Tipo.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Tipo"].ToString();
                txt_Categoria.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Categoria"].ToString();
                txt_Familia.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Familia"].ToString();
                txt_linea.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Linea"].ToString();
                txt_CategoriaAF.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["CategoriaActivoFijo"].ToString();
                txt_UnidadVenta.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Unidad"].ToString();
                txt_IVA.Text = Convert.ToDouble(dtCaracteristicas.Rows[enteroPrimeraFila]["Impuesto1"])
                    .ToString("0.00");
                txt_Estatus.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Estatus"].ToString();
                lbl_codigoArticulo.Text = ArticuloSeleccionado;
                if (almacen == string.Empty) almacen = "TODOS";

                if (!frmLoading.Visible) frmLoading.Show(this);

                Almacenes = await Task.Run(() => CInfoArticulos.ObtenerAlmacenes(ArticuloSeleccionado, almacen));
                int EnteroTotalDisponibles = 0;
                int EnteroTotalTransito = 0;
                int EnteroTotal = 0;
                foreach (ArticuloAlmacenes aAlmacenes in Almacenes)
                {
                    EnteroTotalDisponibles = EnteroTotalDisponibles + Convert.ToInt32(aAlmacenes.Disponible);
                    EnteroTotalTransito = EnteroTotalTransito + Convert.ToInt32(aAlmacenes.Transito);
                    EnteroTotal = EnteroTotal + Convert.ToInt32(aAlmacenes.Total);
                }

                if (frmLoading.Visible) frmLoading.Hide();

                dgv_Almacenes.DataSource = null;
                dgv_Almacenes.DataSource = Almacenes;
                foreach (DataGridViewColumn dc in dgv_Almacenes.Columns)
                    dc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
                dgv_Almacenes.Visible = Almacenes.Count == 0 ? false : true;
                lblNoArticulos.Text = Almacenes.Count == 0 ? "No se encontraron articulos en este almacen" : "";

                txt_TotalDisponible.Text = Convert.ToDouble(EnteroTotalDisponibles).ToString("0");
                txt_totalTransito.Text = Convert.ToDouble(EnteroTotalTransito).ToString("0");
                txt_total.Text = Convert.ToDouble(EnteroTotal).ToString("0");
            }
        }

        /// <summary>
        ///     Llena los componentes del paquete y la informacion
        /// </summary>
        /// <param name="ArticuloSeleccionado">string</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private async void LLenarPaquetes(string ArticuloSeleccionado)
        {
            List<ArticulosDetalleVenta> ImportarDetallesPaquete = new List<ArticulosDetalleVenta>(DetallesPaquete);
            var DetallesConDescripcion = ImportarDetallesPaquete.Select(x => new
            {
                x.Articulo,
                Descripcion = CInfoArticulos.ConsultaInfoArticulos(x.Articulo).Rows[0]["Descripcion1"].ToString()
            }).ToList();
            dgv_Almacenes.DataSource = null;
            dgv_Almacenes.DataSource = DetallesConDescripcion;
            dgv_Almacenes.Visible = DetallesConDescripcion.Count == 0 ? false : true;
            lblNoArticulos.Text =
                DetallesConDescripcion.Count == 0 ? "No se encontraron articulos de este paquete" : "";
            dgv_Almacenes.Columns[0].Width = 120;
            dgv_Almacenes.Columns[1].Width = 450;
            groupBox3.Visible = false;

            lbl_total.Visible = false;
            lbl_disponible.Visible = false;
            lbl_transito.Visible = false;
            txt_total.Visible = false;
            txt_TotalDisponible.Visible = false;
            txt_totalTransito.Visible = false;

            if (ArticuloSeleccionado != string.Empty)
            {
                gpx_articulos.Text = "Componentes";
                DataTable dtCaracteristicas = new DataTable();

                int enteroPrimeraFila = 0;

                if (!frmLoading.Visible) frmLoading.Show(this);
                dtCaracteristicas = await Task.Run(() => CInfoArticulos.ConsultaInfoArticulos(ArticuloSeleccionado));
                txt_Descripcion.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Descripcion1"].ToString();
                txt_Tipo.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Tipo"].ToString();
                txt_Categoria.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Categoria"].ToString();
                txt_Familia.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Familia"].ToString();
                txt_linea.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Linea"].ToString();
                txt_CategoriaAF.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["CategoriaActivoFijo"].ToString();
                txt_UnidadVenta.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Unidad"].ToString();
                txt_IVA.Text = Convert.ToDouble(dtCaracteristicas.Rows[enteroPrimeraFila]["Impuesto1"])
                    .ToString("0.00");
                txt_Estatus.Text = dtCaracteristicas.Rows[enteroPrimeraFila]["Estatus"].ToString();
                lbl_codigoArticulo.Text = ArticuloSeleccionado;
                if (frmLoading.Visible) frmLoading.Hide();
            }
        }

        /// <summary>
        ///     Seleccion de almacen
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/07/2017
        protected void SeleccionaAlmacen(object sender, EventArgs e)
        {
            lbl_mavi.Font = new Font(lbl_mavi.Font, FontStyle.Regular);
            lbl_viu.Font = new Font(lbl_viu.Font, FontStyle.Regular);
            lbl_bodega.Font = new Font(lbl_bodega.Font, FontStyle.Regular);
            lbl_todos.Font = new Font(lbl_todos.Font, FontStyle.Regular);
            Label lbl = (Label)sender;
            lbl.Font = new Font(lbl.Font, FontStyle.Bold);
            LLenarAlmacenes(ArticuloSeleccionado, lbl.Text);
        }

        private void GroupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }


        private void GroupBox2_Paint(object sender, PaintEventArgs e)
        {
            if (EsPaquete)
            {
                e.Graphics.Clear(Color.White);
                Font drawFont = new Font("Times New Roman", 9.75f, FontStyle.Bold);
                SolidBrush drawBrush = new SolidBrush(Color.Black);
                // Create point for upper-left corner of drawing.
                PointF drawPoint = new PointF(10f, 0);
                e.Graphics.DrawString("Componentes", drawFont, drawBrush, drawPoint);
            }
            else
            {
                e.Graphics.Clear(Color.White);
            }
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_Almacenes_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (!EsPaquete)
            {
                List<object> TempObjects = new List<object>(Almacenes.ToList());
                funciones.OrderGridview(dgv_Almacenes, e.ColumnIndex, TempObjects,
                    Almacenes.GetType().GetGenericArguments().Single());
            }
            else
            {
                List<ArticulosDetalleVenta> ImportarDetallesPaquete = new List<ArticulosDetalleVenta>(DetallesPaquete);
                var DetallesConDescripcion = ImportarDetallesPaquete.Select(x => new
                {
                    x.Articulo,
                    Descripcion = CInfoArticulos.ConsultaInfoArticulos(x.Articulo).Rows[0]["Descripcion1"].ToString()
                }).ToList();
                List<object> TempObjects = new List<object>(DetallesConDescripcion.ToList());
                funciones.OrderGridview(dgv_Almacenes, e.ColumnIndex, TempObjects,
                    DetallesConDescripcion.GetType().GetGenericArguments().Single());
            }
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleInformacionArticulo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        /// <summary>
        ///     Detecta cuando se mueve la forma para reacomodar el loader
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 28/11/17
        private void DM0312_DetalleInformacionArticulo_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.Location = Location;
            frmLoading.Location =
                new Point(Location.X + dgv_Almacenes.Location.X, Location.Y + dgv_Almacenes.Location.Y);
            frmLoading.Location = new Point(frmLoading.Location.X + 200, frmLoading.Location.Y + 220);
        }


        private void btn_VentaPendiente_Click(object sender, EventArgs e)
        {
            DM0312_DetalleArtVentaPendiente VentasPendientes = new DM0312_DetalleArtVentaPendiente();
            VentasPendientes.ShowDialog();
        }

        private void DM0312_DetalleInformacionArticulo_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dispose();
        }
    }
}