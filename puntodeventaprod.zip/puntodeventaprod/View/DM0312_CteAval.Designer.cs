﻿namespace PuntoVenta.View
{
    partial class DM0312_CteAval
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_CteAval));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelBotones = new System.Windows.Forms.Panel();
            this.BtnAsignarAval = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.dgv_Avales = new System.Windows.Forms.DataGridView();
            this.PanelBotones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Avales)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelBotones
            // 
            this.PanelBotones.Controls.Add(this.BtnAsignarAval);
            this.PanelBotones.Controls.Add(this.btnCancelar);
            this.PanelBotones.Controls.Add(this.BtnAceptar);
            this.PanelBotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PanelBotones.Location = new System.Drawing.Point(0, 291);
            this.PanelBotones.Name = "PanelBotones";
            this.PanelBotones.Size = new System.Drawing.Size(569, 67);
            this.PanelBotones.TabIndex = 2;
            // 
            // BtnAsignarAval
            // 
            this.BtnAsignarAval.BackColor = System.Drawing.SystemColors.Control;
            this.BtnAsignarAval.BackgroundImage = global::PuntoVenta.Properties.Resources.usuario;
            this.BtnAsignarAval.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BtnAsignarAval.FlatAppearance.BorderSize = 0;
            this.BtnAsignarAval.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAsignarAval.Location = new System.Drawing.Point(369, 2);
            this.BtnAsignarAval.Name = "BtnAsignarAval";
            this.BtnAsignarAval.Size = new System.Drawing.Size(62, 62);
            this.BtnAsignarAval.TabIndex = 3;
            this.BtnAsignarAval.UseVisualStyleBackColor = false;
            this.BtnAsignarAval.Click += new System.EventHandler(this.BtnAsignarAval_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancelar.BackgroundImage")));
            this.btnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Location = new System.Drawing.Point(505, 3);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(62, 62);
            this.btnCancelar.TabIndex = 2;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.BackColor = System.Drawing.SystemColors.Control;
            this.BtnAceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnAceptar.BackgroundImage")));
            this.BtnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BtnAceptar.FlatAppearance.BorderSize = 0;
            this.BtnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAceptar.Location = new System.Drawing.Point(437, 3);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(62, 62);
            this.BtnAceptar.TabIndex = 1;
            this.BtnAceptar.UseVisualStyleBackColor = false;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // dgv_Avales
            // 
            this.dgv_Avales.AllowUserToAddRows = false;
            this.dgv_Avales.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Avales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Avales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Avales.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Avales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Avales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Avales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Avales.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Avales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Avales.EnableHeadersVisualStyles = false;
            this.dgv_Avales.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgv_Avales.Location = new System.Drawing.Point(0, 0);
            this.dgv_Avales.Name = "dgv_Avales";
            this.dgv_Avales.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Avales.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Avales.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_Avales.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_Avales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Avales.Size = new System.Drawing.Size(569, 291);
            this.dgv_Avales.TabIndex = 26;
            this.dgv_Avales.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Avales_CellContentClick);
            this.dgv_Avales.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Avales_ColumnHeaderMouseClick);
            // 
            // DM0312_CteAval
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 358);
            this.Controls.Add(this.dgv_Avales);
            this.Controls.Add(this.PanelBotones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DM0312_CteAval";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Avales del Cliente";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_CteAval_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_CteAval_Load);
            this.PanelBotones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Avales)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Panel PanelBotones;
        private System.Windows.Forms.Button btnCancelar;
        public System.Windows.Forms.DataGridView dgv_Avales;
        private System.Windows.Forms.Button BtnAsignarAval;
    }
}