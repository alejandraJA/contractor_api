﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;

// GESSY 1286
namespace PuntoVenta.View
{
    public partial class frmSancion : Form
    {
        public bool aceptado;
        public string aplica;
        public string calificacionEvento = "VTA10000";

        public bool cerrado;
        public string cliente;
        public string idEvento;
        public string monto;
        public string movID;
        public string observaciones;

        private readonly SancionController sancionController = new SancionController();

        public string sucursal;
        public string usuarioCredito;
        public string vendedor;

        public frmSancion()
        {
            InitializeComponent();
        }

        ~frmSancion()
        {
            GC.Collect();
        }

        private void rbSi_CheckedChanged(object sender, EventArgs e)
        {
            cbMotivos.Visible = true;

            if (cbMotivos.Text == "OTROS")
            {
                txtMotivoOtro.Visible = true;
                lblMotivo.Visible = true;
                lbl_contador.Visible = true;
            }
        }

        private void rbNo_CheckedChanged(object sender, EventArgs e)
        {
            cbMotivos.Visible = false;
            txtMotivoOtro.Visible = false;
            lblMotivo.Visible = false;
            txtMotivoOtro.Text = "";

            lbl_contador.Visible = false;
        }

        private void frmSancion_Load(object sender, EventArgs e)
        {
            MotiovosLoad();
        }

        private void MotiovosLoad()
        {
            List<string> listaMotivos = new List<string>();

            try
            {
                switch (calificacionEvento)
                {
                    case "VTA10000":
                        listaMotivos = sancionController.fetchMotivosSancion("LIBERACION");
                        break;
                    case "VTA00012":
                        listaMotivos = sancionController.fetchMotivosSancion("COMPLEMENTO");
                        break;
                    default:
                        listaMotivos.Add("OTROS");
                        break;
                }

                cbMotivos.DataSource = listaMotivos;
                cbMotivos.SelectedIndex = cbMotivos.Items.IndexOf("OTROS");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
            }
        }

        private void cbMotivos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbMotivos.Text != "OTROS")
            {
                txtMotivoOtro.Visible = false;
                lbl_contador.Visible = false;
            }
            else
            {
                txtMotivoOtro.Visible = true;
                lbl_contador.Visible = true;
            }
        }

        private void txtMotivoOtro_KeyDown(object sender, KeyEventArgs e)
        {
            countMotivo();
        }

        private void txtMotivoOtro_KeyUp(object sender, KeyEventArgs e)
        {
            countMotivo();
        }

        private void countMotivo()
        {
            lbl_contador.Text = txtMotivoOtro.Text.Length + "/" + txtMotivoOtro.MaxLength;
        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (cbMotivos.Text == "OTROS" && txtMotivoOtro.Text.Length == 0 && rbSi.Checked)
            {
                MessageBox.Show("Indique el motivo para continuar", "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            ClaseEstatica.sancion = getSancionValues();

            aceptado = true;
            Dispose();
        }

        private Dictionary<string, string> getSancionValues()
        {
            string sVendedor = sancionController.obtenerAgenteQueSanciona(int.Parse(idEvento)).ToUpper();
            Dictionary<string, string> sanction = new Dictionary<string, string>();
            int iSancionesDiarias = sancionController.obtenerSancionesDiarias();
            int iSancionesAgente = sancionController.sancionesPorAgente(sVendedor);

            string sAplicaSancion = string.Empty;
            if (iSancionesAgente >= iSancionesDiarias) sAplicaSancion = "0";

            string sAplica = string.Empty;
            if (!string.IsNullOrEmpty(sAplicaSancion))
            {
                sAplica = sAplicaSancion;
            }
            else
            {
                if (rbSi.Checked)
                    sAplica = "1";
                else
                    sAplica = "0";
            }


            sanction.Add("@Sucursal", sucursal);
            sanction.Add("@Vendedor", sVendedor);
            sanction.Add("@Monto", sancionController.getSanctionAmount());
            sanction.Add("@MovID", movID);
            sanction.Add("@Cliente", cliente);
            sanction.Add("@UsuarioCredito", usuarioCredito);
            sanction.Add("@Observacion",
                string.IsNullOrEmpty(txtMotivoOtro.Text) ? cbMotivos.Text : txtMotivoOtro.Text);
            sanction.Add("@Aplica", sAplica);

            return sanction;
        }

        private void frmSancion_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!aceptado) cerrado = true;
        }

        private void frmSancion_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!aceptado) cerrado = true;
        }
    }
}