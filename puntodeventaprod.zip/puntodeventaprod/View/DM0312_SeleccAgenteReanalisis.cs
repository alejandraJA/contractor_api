﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_SeleccAgenteReanalisis : Form
    {
        private DM0312_Reanalisis _dm0312Reanalisis = new DM0312_Reanalisis();
        public string agente;
        private readonly DM0312_C_ExploradorVenta controlador = new DM0312_C_ExploradorVenta();

        public DM0312_SeleccAgenteReanalisis()
        {
            InitializeComponent();
            FillDataSelecAgente();
            dgv_SelecAgente.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            dgv_SelecAgente.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
        }

        ~DM0312_SeleccAgenteReanalisis()
        {
            GC.Collect();
        }

        private void FillDataSelecAgente()
        {
            try
            {
                DataTable dataTableAgenteReanalisis = new DataTable();
                dataTableAgenteReanalisis = controlador.FillDataSelecAgente();
                dgv_SelecAgente.DataSource = null;
                dgv_SelecAgente.DataSource = dataTableAgenteReanalisis;

                int height = 80;
                foreach (DataGridViewRow item in dgv_SelecAgente.Rows)
                    if (height < 260)
                        height += item.Height;
                dgv_SelecAgente.Height = height;
                dgv_SelecAgente.Width = 460;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("FillDataGridEventos", "DM0312_ExploradorVentas.cs", ex);
                MessageBox.Show(ex.Message + " function: FillDataGridEventos, class: DM0312_ExploradorVentas.cs");
            }
        }

        private void dgv_SelecAgente_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string nombreAgente = dgv_SelecAgente.SelectedRows[0].Cells[0].Value + string.Empty;
            Close();
            DM0312_Reanalisis ViewR = new DM0312_Reanalisis();
            ViewR.agente = nombreAgente;
            agente = nombreAgente;
        }

        private void txt_BuscarAgente_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txt_BuscarAgente.Text))
                    (dgv_SelecAgente.DataSource as DataTable).DefaultView.RowFilter = string.Empty;
                else
                    (dgv_SelecAgente.DataSource as DataTable).DefaultView.RowFilter =
                        string.Format("Nombre LIKE '%{0}%' OR Agente LIKE '%{0}%'", txt_BuscarAgente.Text);
            }

            catch (Exception)
            {
                MessageBox.Show("El valor ingresado no es válido");
            }
        }
    }
}