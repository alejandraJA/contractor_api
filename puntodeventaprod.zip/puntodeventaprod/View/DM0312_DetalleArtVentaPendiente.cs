﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleArtVentaPendiente : Form
    {
        public DM0312_DetalleArtVentaPendiente()
        {
            InitializeComponent();
        }

        ~DM0312_DetalleArtVentaPendiente()
        {
            GC.Collect();
        }

        private void DM0312_DetalleArtVentaPendiente_Load(object sender, EventArgs e)
        {
            GetMovs();
            txt_Comentarios.Text = "FORMA PARA CONSULTAR LAS VENTAS PENDIENTES QUE SE HAN ECHO SOBRE EL ARTICULO";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_ArticulosPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_ArticulosPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_ArticulosPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_ArticulosPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void GetMovs()
        {
            List<MArtVPendientes> ListaPendientes = new List<MArtVPendientes>();
            string comand = "SELECT " +
                            "VentaPendienteD.Mov," +
                            "VentaPendienteD.MovID," +
                            "VentaPendienteD.FechaEmision," +
                            "VentaPendienteD.FechaRequerida," +
                            "VentaPendienteD.Cliente," +
                            "VentaPendienteD.Almacen," +
                            "VentaPendienteD.DescuentoGlobal," +
                            "VentaPendienteD.CantidadReservada," +
                            "VentaPendienteD.CantidadOrdenada," +
                            "VentaPendienteD.CantidadPendiente," +
                            "VentaPendienteD.Precio," +
                            "VentaPendienteD.DescuentoLinea," +
                            "VentaPendienteD.DescuentoTipo," +
                            "VentaPendienteD.Impuesto1," +
                            "VentaPendienteD.Impuesto2," +
                            "VentaPendienteD.Impuesto3," +
                            "VentaPendienteD.DescripcionExtra," +
                            "VentaPendienteD.CteNombre," +
                            "VentaPendienteD.Referencia," +
                            "VentaPendienteD.ReservadaFactor," +
                            "VentaPendienteD.OrdenadaFactor," +
                            "VentaPendienteD.PendienteFactor," +
                            "VentaPendienteD.PrecioTipoCambio," +
                            "Cte.Cliente " +
                            "FROM VentaPendienteD " +
                            " JOIN Art ON VentaPendienteD.Articulo = Art.Articulo " +
                            " JOIN Cte ON VentaPendienteD.Cliente = Cte.Cliente  " +
                            " LEFT OUTER JOIN CteEnviarA ON VentaPendienteD.Cliente = CteEnviarA.Cliente AND VentaPendienteD.EnviarA = CteEnviarA.ID" +
                            " WHERE Art.Articulo = @Articulo";
            SqlCommand sqlCommand = new SqlCommand(comand, ClaseEstatica.ConexionEstatica)
            {
                CommandType = CommandType.Text
            };
            sqlCommand.Parameters.AddWithValue("@Articulo", DM0312_DetalleInformacionArticulo.ArticuloSeleccionado);
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                    {
                        int CantidadReservada =
                            dr["CantidadReservada"] != null && dr["CantidadReservada"].ToString() != string.Empty
                                ? Convert.ToInt32(dr["CantidadReservada"])
                                : 0;
                        int CantidadOrdenada =
                            dr["CantidadOrdenada"] != null && dr["CantidadOrdenada"].ToString() != string.Empty
                                ? Convert.ToInt32(dr["CantidadOrdenada"])
                                : 0;
                        int CantidadPendiente =
                            dr["CantidadPendiente"] != null && dr["CantidadPendiente"].ToString() != string.Empty
                                ? Convert.ToInt32(dr["CantidadPendiente"])
                                : 0;
                        int TotalPendiente = CantidadReservada + CantidadOrdenada + CantidadPendiente;

                        MArtVPendientes VentaPendiente = new MArtVPendientes
                        {
                            Movimiento = dr["Mov"] + " " + dr["MovID"],
                            Almacén = dr["Almacen"].ToString(),
                            Cliente = dr["Cliente"].ToString(),
                            Nombre = dr["CteNombre"].ToString(),
                            FechaEmision = dr["FechaEmision"].ToString(),
                            FechaRequerida = dr["FechaRequerida"].ToString(),
                            Reservado = dr["ReservadaFactor"] != null &&
                                        dr["ReservadaFactor"].ToString() != string.Empty
                                ? dr["ReservadaFactor"].ToString()
                                : "0",
                            Ordenado = dr["OrdenadaFactor"] != null && dr["OrdenadaFactor"].ToString() != string.Empty
                                ? dr["OrdenadaFactor"].ToString()
                                : "0",
                            Pendiente = dr["PendienteFactor"] != null &&
                                        dr["PendienteFactor"].ToString() != string.Empty
                                ? dr["PendienteFactor"].ToString()
                                : "0",
                            ImportePendiente = (Convert.ToDouble(dr["Precio"]) * TotalPendiente).ToString("C")
                        };
                        ListaPendientes.Add(VentaPendiente);
                    }

                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GetMovs", "DM0312_DetalleArtCompraPendiente.cs", ex);
                MessageBox.Show(ex.Message, "Error");
            }

            dgv_ArticulosPendientes.DataSource = null;
            dgv_ArticulosPendientes.DataSource = ListaPendientes;
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DM0312_DetalleArtVentaPendiente_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }
    }
}