﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pruebas.Controller;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta.View
{
    public partial class frmCoincidencias : Form
    {
        private readonly string[] sParamentros;


        public frmCoincidencias(string[] sParamentros)
        {
            InitializeComponent();
            this.sParamentros = sParamentros;
        }

        ~frmCoincidencias()
        {
            GC.Collect();
        }

        private async void frmCoincidencias_Load(object sender, EventArgs e)
        {
            CoincidenciasController cController = new CoincidenciasController();
            await Task.Run(() =>
                cController.BuscarCoincidencias(sParamentros[(int)Enums.ParametrosDetallesVenta.Cliente],
                    int.Parse(sParamentros[(int)Enums.ParametrosDetallesVenta.IDVenta]), ClaseEstatica.Usuario.usuario,
                    true));
            Close();
        }
    }
}