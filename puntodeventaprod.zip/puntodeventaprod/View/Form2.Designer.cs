﻿namespace PuntoVenta.View
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.dgv_TablaMovimientos = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.txt_CreditoNuevoMayNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoNuevoMayNum = new System.Windows.Forms.Label();
            this.txt_CreditoCasaMayNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoCasaMayNum = new System.Windows.Forms.Label();
            this.txt_ContadoCasaNum = new System.Windows.Forms.TextBox();
            this.lbl_ContadoCasaNum = new System.Windows.Forms.Label();
            this.txt_ContadoNuevoNum = new System.Windows.Forms.TextBox();
            this.lbl_ContadoNuevoNum = new System.Windows.Forms.Label();
            this.txt_CreditoNuevoNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoNuevoNum = new System.Windows.Forms.Label();
            this.txt_CreditoCasaNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoCasaNum = new System.Windows.Forms.Label();
            this.panelContactos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaMovimientos)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.Controls.Add(this.dgv_TablaMovimientos);
            this.panelContactos.Controls.Add(this.flowLayoutPanel1);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(223, 1);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(980, 268);
            this.panelContactos.TabIndex = 50;
            // 
            // dgv_TablaMovimientos
            // 
            this.dgv_TablaMovimientos.AllowUserToAddRows = false;
            this.dgv_TablaMovimientos.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_TablaMovimientos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_TablaMovimientos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_TablaMovimientos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_TablaMovimientos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TablaMovimientos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_TablaMovimientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_TablaMovimientos.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_TablaMovimientos.EnableHeadersVisualStyles = false;
            this.dgv_TablaMovimientos.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgv_TablaMovimientos.Location = new System.Drawing.Point(3, 3);
            this.dgv_TablaMovimientos.Name = "dgv_TablaMovimientos";
            this.dgv_TablaMovimientos.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TablaMovimientos.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_TablaMovimientos.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_TablaMovimientos.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_TablaMovimientos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_TablaMovimientos.Size = new System.Drawing.Size(974, 238);
            this.dgv_TablaMovimientos.TabIndex = 25;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lbl_CreditoCasaNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_CreditoCasaNum);
            this.flowLayoutPanel1.Controls.Add(this.lbl_CreditoNuevoNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_CreditoNuevoNum);
            this.flowLayoutPanel1.Controls.Add(this.lbl_ContadoNuevoNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_ContadoNuevoNum);
            this.flowLayoutPanel1.Controls.Add(this.lbl_ContadoCasaNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_ContadoCasaNum);
            this.flowLayoutPanel1.Controls.Add(this.lbl_CreditoCasaMayNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_CreditoCasaMayNum);
            this.flowLayoutPanel1.Controls.Add(this.lbl_CreditoNuevoMayNum);
            this.flowLayoutPanel1.Controls.Add(this.txt_CreditoNuevoMayNum);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 247);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(974, 18);
            this.flowLayoutPanel1.TabIndex = 26;
            // 
            // txt_CreditoNuevoMayNum
            // 
            this.txt_CreditoNuevoMayNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoNuevoMayNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoNuevoMayNum.Enabled = false;
            this.txt_CreditoNuevoMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoNuevoMayNum.Location = new System.Drawing.Point(876, 3);
            this.txt_CreditoNuevoMayNum.Multiline = true;
            this.txt_CreditoNuevoMayNum.Name = "txt_CreditoNuevoMayNum";
            this.txt_CreditoNuevoMayNum.Size = new System.Drawing.Size(40, 12);
            this.txt_CreditoNuevoMayNum.TabIndex = 68;
            // 
            // lbl_CreditoNuevoMayNum
            // 
            this.lbl_CreditoNuevoMayNum.AutoSize = true;
            this.lbl_CreditoNuevoMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoNuevoMayNum.Location = new System.Drawing.Point(756, 3);
            this.lbl_CreditoNuevoMayNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoNuevoMayNum.Name = "lbl_CreditoNuevoMayNum";
            this.lbl_CreditoNuevoMayNum.Size = new System.Drawing.Size(114, 15);
            this.lbl_CreditoNuevoMayNum.TabIndex = 67;
            this.lbl_CreditoNuevoMayNum.Text = "Credito Nuevo May:";
            // 
            // txt_CreditoCasaMayNum
            // 
            this.txt_CreditoCasaMayNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoCasaMayNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoCasaMayNum.Enabled = false;
            this.txt_CreditoCasaMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoCasaMayNum.Location = new System.Drawing.Point(712, 3);
            this.txt_CreditoCasaMayNum.Multiline = true;
            this.txt_CreditoCasaMayNum.Name = "txt_CreditoCasaMayNum";
            this.txt_CreditoCasaMayNum.Size = new System.Drawing.Size(38, 12);
            this.txt_CreditoCasaMayNum.TabIndex = 66;
            // 
            // lbl_CreditoCasaMayNum
            // 
            this.lbl_CreditoCasaMayNum.AutoSize = true;
            this.lbl_CreditoCasaMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoCasaMayNum.Location = new System.Drawing.Point(598, 3);
            this.lbl_CreditoCasaMayNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoCasaMayNum.Name = "lbl_CreditoCasaMayNum";
            this.lbl_CreditoCasaMayNum.Size = new System.Drawing.Size(108, 15);
            this.lbl_CreditoCasaMayNum.TabIndex = 65;
            this.lbl_CreditoCasaMayNum.Text = "Credito Casa May:";
            // 
            // txt_ContadoCasaNum
            // 
            this.txt_ContadoCasaNum.BackColor = System.Drawing.Color.White;
            this.txt_ContadoCasaNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ContadoCasaNum.Enabled = false;
            this.txt_ContadoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContadoCasaNum.Location = new System.Drawing.Point(542, 3);
            this.txt_ContadoCasaNum.Multiline = true;
            this.txt_ContadoCasaNum.Name = "txt_ContadoCasaNum";
            this.txt_ContadoCasaNum.Size = new System.Drawing.Size(50, 12);
            this.txt_ContadoCasaNum.TabIndex = 58;
            // 
            // lbl_ContadoCasaNum
            // 
            this.lbl_ContadoCasaNum.AutoSize = true;
            this.lbl_ContadoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContadoCasaNum.Location = new System.Drawing.Point(451, 3);
            this.lbl_ContadoCasaNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_ContadoCasaNum.Name = "lbl_ContadoCasaNum";
            this.lbl_ContadoCasaNum.Size = new System.Drawing.Size(85, 15);
            this.lbl_ContadoCasaNum.TabIndex = 57;
            this.lbl_ContadoCasaNum.Text = "Contado Casa:";
            // 
            // txt_ContadoNuevoNum
            // 
            this.txt_ContadoNuevoNum.BackColor = System.Drawing.Color.White;
            this.txt_ContadoNuevoNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ContadoNuevoNum.Enabled = false;
            this.txt_ContadoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContadoNuevoNum.Location = new System.Drawing.Point(389, 3);
            this.txt_ContadoNuevoNum.Multiline = true;
            this.txt_ContadoNuevoNum.Name = "txt_ContadoNuevoNum";
            this.txt_ContadoNuevoNum.Size = new System.Drawing.Size(56, 12);
            this.txt_ContadoNuevoNum.TabIndex = 56;
            // 
            // lbl_ContadoNuevoNum
            // 
            this.lbl_ContadoNuevoNum.AutoSize = true;
            this.lbl_ContadoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContadoNuevoNum.Location = new System.Drawing.Point(292, 3);
            this.lbl_ContadoNuevoNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_ContadoNuevoNum.Name = "lbl_ContadoNuevoNum";
            this.lbl_ContadoNuevoNum.Size = new System.Drawing.Size(91, 15);
            this.lbl_ContadoNuevoNum.TabIndex = 55;
            this.lbl_ContadoNuevoNum.Text = "Contado Nuevo:";
            // 
            // txt_CreditoNuevoNum
            // 
            this.txt_CreditoNuevoNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoNuevoNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoNuevoNum.Enabled = false;
            this.txt_CreditoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoNuevoNum.Location = new System.Drawing.Point(240, 3);
            this.txt_CreditoNuevoNum.Multiline = true;
            this.txt_CreditoNuevoNum.Name = "txt_CreditoNuevoNum";
            this.txt_CreditoNuevoNum.Size = new System.Drawing.Size(46, 12);
            this.txt_CreditoNuevoNum.TabIndex = 54;
            // 
            // lbl_CreditoNuevoNum
            // 
            this.lbl_CreditoNuevoNum.AutoSize = true;
            this.lbl_CreditoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoNuevoNum.Location = new System.Drawing.Point(146, 3);
            this.lbl_CreditoNuevoNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoNuevoNum.Name = "lbl_CreditoNuevoNum";
            this.lbl_CreditoNuevoNum.Size = new System.Drawing.Size(88, 15);
            this.lbl_CreditoNuevoNum.TabIndex = 53;
            this.lbl_CreditoNuevoNum.Text = "Credito Nuevo:";
            // 
            // txt_CreditoCasaNum
            // 
            this.txt_CreditoCasaNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoCasaNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoCasaNum.Enabled = false;
            this.txt_CreditoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoCasaNum.Location = new System.Drawing.Point(91, 3);
            this.txt_CreditoCasaNum.Multiline = true;
            this.txt_CreditoCasaNum.Name = "txt_CreditoCasaNum";
            this.txt_CreditoCasaNum.Size = new System.Drawing.Size(49, 12);
            this.txt_CreditoCasaNum.TabIndex = 52;
            // 
            // lbl_CreditoCasaNum
            // 
            this.lbl_CreditoCasaNum.AutoSize = true;
            this.lbl_CreditoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoCasaNum.Location = new System.Drawing.Point(3, 3);
            this.lbl_CreditoCasaNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoCasaNum.Name = "lbl_CreditoCasaNum";
            this.lbl_CreditoCasaNum.Size = new System.Drawing.Size(82, 15);
            this.lbl_CreditoCasaNum.TabIndex = 0;
            this.lbl_CreditoCasaNum.Text = "Credito Casa:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 741);
            this.Controls.Add(this.panelContactos);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panelContactos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaMovimientos)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        public System.Windows.Forms.DataGridView dgv_TablaMovimientos;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lbl_CreditoCasaNum;
        private System.Windows.Forms.TextBox txt_CreditoCasaNum;
        private System.Windows.Forms.Label lbl_CreditoNuevoNum;
        private System.Windows.Forms.TextBox txt_CreditoNuevoNum;
        private System.Windows.Forms.Label lbl_ContadoNuevoNum;
        private System.Windows.Forms.TextBox txt_ContadoNuevoNum;
        private System.Windows.Forms.Label lbl_ContadoCasaNum;
        private System.Windows.Forms.TextBox txt_ContadoCasaNum;
        private System.Windows.Forms.Label lbl_CreditoCasaMayNum;
        private System.Windows.Forms.TextBox txt_CreditoCasaMayNum;
        private System.Windows.Forms.Label lbl_CreditoNuevoMayNum;
        private System.Windows.Forms.TextBox txt_CreditoNuevoMayNum;

    }
}