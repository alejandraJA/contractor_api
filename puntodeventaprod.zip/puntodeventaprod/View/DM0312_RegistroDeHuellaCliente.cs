﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Reports;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class RegistroDeHuellaCliente : Form
    {
        public static List<DM0312_MRegistroCte> ListaGuardar;

        public static DM0312_MRegistroCte ModelSeleccionado;

        private int bandera;

        public bool close;

        private readonly DM0312_CRegistroCte controller;

        public List<dynamic> huellas = new List<dynamic>();

        public RegistroDeHuellaCliente()
        {
            InitializeComponent();
            controller = new DM0312_CRegistroCte();
            //huellas = new List<object>();
        }

        public string cliente { set; get; }

        public string Usuario { get; set; }

        public string mov { get; set; }

        public string movId { get; set; }

        ~RegistroDeHuellaCliente()
        {
            GC.Collect();
        }

        private void RegistroDeHuellaCliente_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(btn_Guardar, "Guardar");
            toolTip1.SetToolTip(btn_refrescar, "Refrescar");
            toolTip1.SetToolTip(btn_Fotos, "Imagenes");
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            toolTip1.SetToolTip(btn_Regresar, "Regresar");

            LlenarComboSucursal();

            LlenarComboFecha();

            ClaseEstatica.FormActivo = "Registro Huella";

            lblMov.Text = lblMov.Text + ":" + mov;
            lblMovID.Text = lblMovID.Text + ":" + movId;

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                gv_Huellas.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                gv_PregYRes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                gv_Huellas.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                gv_PregYRes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                gv_Huellas.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                gv_PregYRes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                gv_Huellas.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                gv_PregYRes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }

        private void RegistroDeHuellaCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!close)
            {
                ChangesInGrid();

                if (ListaGuardar.Count > 0)
                {
                    DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                        MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                        InsertChanges();
                    else
                        close = true;
                }
            }

            if (!close)
            {
                MessageBox.Show("Debe Validar Huellas", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }

            if (close)
                Dispose();
        }


        private void ChangesInGrid()
        {
            ListaGuardar = new List<DM0312_MRegistroCte>();

            if (gv_Huellas.Rows.Count > 0)
            {
                foreach (DataGridViewRow i in gv_Huellas.Rows)
                    if (i.Cells[0].Value != null)
                    {
                        bool check = Convert.ToBoolean(i.Cells[0].Value.ToString());

                        int id = Convert.ToInt32(i.Cells[1].Value.ToString());

                        DM0312_MRegistroCte model = new DM0312_MRegistroCte();

                        model = ClaseEstatica.ListaCte.Where(x => x.ID == id).FirstOrDefault();
                        bool forzarCambio = false;

                        if (i.Cells[0].Tag != null) forzarCambio = (bool)i.Cells[0].Tag;

                        if (model.Valido != Convert.ToBoolean(check) || forzarCambio)
                        {
                            model.Valido = Convert.ToBoolean(check);
                            model.UsuarioValido = Usuario;
                            ListaGuardar.Add(model);
                        }
                    }
            }
            else
            {
                MessageBox.Show("No hay registros", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                close = true;
            }
        }

        private void InsertChanges()
        {
            if (ListaGuardar.Count > 0)
            {
                ClaseEstatica.ListaCte =
                    controller.ValidaHuellas(cliente, cmbSucursal.SelectedItem.ToString(), ListaGuardar);

                ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();

                ObtenerDatos();

                close = true;
            }
            else
            {
                MessageBox.Show("No hay registros afectados", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                close = false;
            }
        }

        private void RegistroDeHuellaCliente_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.KeyCode == Keys.F5) ObtenerDatos();

            if (e.Control && e.KeyCode == Keys.G)
            {
                gv_Huellas.EndEdit();

                DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                    MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    ChangesInGrid();

                    InsertChanges();

                    if (close)
                        Close();
                }
            }
        }

        private void btn_DIMAafil_Click(object sender, EventArgs e)
        {
            if (ModelSeleccionado.Recomendado == "SI")
            {
                Process pTicket = new Process();
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"\PlugDimR\PlugDimR.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ModelSeleccionado.IdMov + " " + ClaseEstatica.Usuario.Usser;
                // pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                //if (true) pTicket.WaitForExit();
                pTicket.Dispose();
            }
            else
            {
                MessageBox.Show("No cuenta con recomendado", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void gv_Huellas_SelectionChanged(object sender, EventArgs e)
        {
            /*Lista estatica de los elementos seleccionados*/
            List<DM0312_MRegistroCte> ListaExplorador = new List<DM0312_MRegistroCte>();

            for (int i = 0; i < gv_Huellas.SelectedRows.Count; i++)
            {
                DM0312_MRegistroCte model_ = new DM0312_MRegistroCte();
                model_ = (DM0312_MRegistroCte)gv_Huellas.SelectedRows[i].DataBoundItem;
                ListaExplorador.Add(model_);
            }

            /*modelo estatico sacado de la lista*/
            ModelSeleccionado = ListaExplorador.FirstOrDefault();
        }

        private void btnHistorico_Click(object sender, EventArgs e)
        {
            DM0312_ReporteClienteHuellasFotos frm = new DM0312_ReporteClienteHuellasFotos(3);
            //frm.Lista = ClaseEstatica.ListaAnexoCta;
            frm.Show();
        }


        #region "Eventos"

        private void gv_Huellas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //ReadOnly(e.ColumnIndex);

                int i = Convert.ToInt32(gv_Huellas.Rows[e.RowIndex].Cells[1].Value.ToString());

                FormatearGrid(i);
            }
        }

        private void gv_Huellas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                ReadOnly(e.ColumnIndex);

                int i = Convert.ToInt32(gv_Huellas.Rows[e.RowIndex].Cells[1].Value.ToString());
                FormatearGrid(i);
            }
        }

        private void cmbFecha_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFecha.SelectedItem.ToString() == "Especifica")
            {
                DM0312_RegistroDeHuellaFechas frm = new DM0312_RegistroDeHuellaFechas();
                frm.ShowDialog();
                ObtenerDatos();
            }
            else
            {
                ObtenerDatos();
            }
        }

        private void cmbSucursal_SelectedIndexChanged(object sender, EventArgs e)
        {
            ObtenerDatos();
            bandera++;
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            gv_Huellas.EndEdit();

            DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                ChangesInGrid();

                InsertChanges();

                if (close)
                    Close();
            }
        }

        private void btn_refrescar_Click(object sender, EventArgs e)
        {
            ObtenerDatos();
        }

        private void btn_Fotos_Click(object sender, EventArgs e)
        {
            DM0312_ReporteClienteHuellasFotos frm = new DM0312_ReporteClienteHuellasFotos(1);
            //frm.Lista = ClaseEstatica.ListaAnexoCta;
            frm.Show();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gv_Huellas_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                MessageBox.Show("No se puede ordenar por este campo", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }


            Funciones funciones = new Funciones();

            List<object> TempObjects = new List<object>(ClaseEstatica.ListaCte);

            funciones.OrderGridview(gv_Huellas, e.ColumnIndex, ref TempObjects,
                ClaseEstatica.ListaCte.GetType().GetGenericArguments().Single());

            ClaseEstatica.ListaCte = TempObjects.OfType<DM0312_MRegistroCte>().ToList();

            gv_PregYRes.DataSource = null;

            AfterToOrder();
        }

        private void AfterToOrder()
        {
            gv_Huellas.Rows[0].Selected = true;

            int i = Convert.ToInt32(gv_Huellas.Rows[0].Cells[1].Value.ToString());

            FormatearGrid(i);

            gv_Huellas.Columns[1].Visible = false;

            gv_Huellas.Columns[0].ReadOnly = false;

            gv_Huellas.Columns[4].HeaderText = "Identificación";

            int row = 0;
            foreach (DM0312_MRegistroCte item in ClaseEstatica.ListaCte)
            {
                gv_Huellas.Rows[row].Cells[0].Value = item.Valido;
                row++;
            }

            gv_Huellas.Refresh();
        }

        #endregion

        #region "Metodos"

        private void ObtenerDatos()
        {
            string sucursal = string.Empty;
            string fecha = string.Empty;

            gv_PregYRes.DataSource = null;

            ClaseEstatica.DM0312_RegistroDeHuellaFechas = false;

            sucursal = cmbSucursal.SelectedItem.ToString();

            ClaseEstatica.ListaCte = new List<DM0312_MRegistroCte>();

            if (bandera > 0)
            {
                fecha = cmbFecha.SelectedItem.ToString();
                bandera++;
                if (fecha != "Todas") ClaseEstatica.DM0312_RegistroDeHuellaFechas = true;
            }

            ClaseEstatica.ListaCte = controller.FiltrarListas(cliente, sucursal);

            ClaseEstatica.ListaCte.RemoveAll(x => x.ID == 0);

            ClaseEstatica.FechaFin = new DateTime();

            ClaseEstatica.FechaInicio = new DateTime();

            if (ClaseEstatica.ListaCte.Count > 0)
            {
                gv_Huellas.Visible = true;
                FormatearGridHuellas();
            }
            else
            {
                MessageBox.Show("El cliente no tiene registro de huella", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                gv_Huellas.DataSource = null;
                gv_Huellas.Visible = false;
                close = true;
                Dispose();
            }
        }

        private void FormatearGridHuellas()
        {
            ClaseEstatica.ListaCte = ClaseEstatica.ListaCte.OrderByDescending(x => x.Fecha).ToList();

            gv_Huellas.DataSource = null;
            gv_Huellas.DataSource = ClaseEstatica.ListaCte;


            gv_Huellas.Columns[1].Visible = false;

            gv_Huellas.Columns[4].HeaderText = "Identificación";


            int row = 0;

            foreach (DM0312_MRegistroCte item in ClaseEstatica.ListaCte)
            {
                gv_Huellas.Rows[row].Cells[0].Value = item.Valido;
                row++;
            }
        }

        private void FormatearGrid(int ID)
        {
            var Preguntas = from p in ClaseEstatica.ListaCte
                where p.ID == ID
                select new
                {
                    p.Pregunta1,
                    p.Respuesta1,
                    p.Pregunta2,
                    p.Respuesta2,
                    p.Pregunta3,
                    p.Respuesta3,
                    p.Pregunta4,
                    p.Respuesta4,
                    p.Pregunta5,
                    p.Respuesta5
                };

            gv_PregYRes.DataSource = null;

            gv_PregYRes.DataSource = Preguntas.ToList();

            gv_PregYRes.ReadOnly = true;
        }

        private void LlenarComboSucursal()
        {
            DM0312_CSucursal controlador = new DM0312_CSucursal();

            List<DM0312_MSucursal> Sucursales = new List<DM0312_MSucursal>();

            Sucursales = controlador.ObtenerSucursales();

            List<string> Lista = new List<string>();

            foreach (DM0312_MSucursal item in Sucursales)
            {
                string s = string.Empty;
                if (item.Sucursal == 0)
                {
                    Lista.Add("Todas");
                    s = item.Sucursal + "-" + item.Nombre;
                    Lista.Add(s);
                }
                else
                {
                    s = item.Sucursal + "-" + item.Nombre;
                    Lista.Add(s);
                }
            }

            cmbSucursal.DataSource = null;
            cmbSucursal.DataSource = Lista.ToList();
        }

        private void LlenarComboFecha()
        {
            List<string> Lista = new List<string>();
            Lista.Add("Todas");
            Lista.Add("Especifica");

            cmbFecha.DataSource = Lista;
        }

        public void ReadOnly(int columnIndex)
        {
            if (columnIndex == 0)
            {
                gv_Huellas.ReadOnly = false;
                gv_Huellas.Columns[columnIndex].ReadOnly = false;

                bool value = Convert.ToBoolean(gv_Huellas.SelectedCells[0].Value.ToString());
                if (gv_Huellas.SelectedCells[0].Tag == null) gv_Huellas.SelectedCells[0].Tag = !value;

                gv_Huellas.BeginEdit(false);

                gv_Huellas.EndEdit();
                gv_Huellas.Refresh();
            }
            else
            {
                gv_Huellas.ReadOnly = true;
                gv_Huellas.Columns[columnIndex].ReadOnly = true;
            }
        }

        #endregion
    }
}