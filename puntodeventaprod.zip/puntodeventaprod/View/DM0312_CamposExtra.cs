﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_CamposExtra : Form
    {
        public static string[] campoExtra =
        {
            "SC_DOCTO", "SC_TIPO_DOCTO", "SC_COLONIA", "SC_TELEFONO", "SC_RECOMENDADO", "SC_CONYUGE",
            "SC_FECHANACIMIENTO",
            "SC_CP", "SC_CRUCES", "SC_NUM_INTERIOR", "SC_NUM_EXTERIOR", "SC_CALLE", "SC_TIPO_CALLE"
        };

        public static string[] valor = new string[13];
        public static bool validaInsertUsuario = false;
        public DM0312_MCamposExtraRecibe camposExtraRecibe = new DM0312_MCamposExtraRecibe();
        private readonly DM0312_CVentanaEntrada controlador = new DM0312_CVentanaEntrada();
        private readonly CDetalleVenta controladorD = new CDetalleVenta();
        public DM0312_CPuntoDeVenta controladorPuntoVenta = new DM0312_CPuntoDeVenta();
        private readonly DM0312_C_CampoExtra controllCampoExtra = new DM0312_C_CampoExtra();
        private readonly Funciones funciones = new Funciones();
        public List<DM0312_MComentariosVenta> ListaCampoExtraComentario;

        public DM0312_CamposExtra()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        public DM0312_CamposExtra(DM0312_MCamposExtraRecibe CamposExtraRecibe)
        {
            InitializeComponent();
            camposExtraRecibe = CamposExtraRecibe;
            StartPosition = FormStartPosition.CenterScreen;
        }

        public DM0312_CamposExtra(
            List<DM0312_MComentariosVenta> ListaCampoExtraComentario,
            string recibeColonia,
            string recibeMov,
            int recibeIdVenta,
            string recibeCliente
        )
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        public string psAgente { get; set; }

        ~DM0312_CamposExtra()
        {
            GC.Collect();
        }

        #region "Methods"

        /// <summary>
        ///     Permite llenar el comboBox Tipo Calle
        /// </summary>
        private void FillTipeClave()
        {
            cbx_TipoCalle.Items.Add("Andador");
            cbx_TipoCalle.Items.Add("Autopista");
            cbx_TipoCalle.Items.Add("Avenida");
            cbx_TipoCalle.Items.Add("Boulevard");
            cbx_TipoCalle.Items.Add("Calle");
            cbx_TipoCalle.Items.Add("Callejón");
            cbx_TipoCalle.Items.Add("Calzada");
            cbx_TipoCalle.Items.Add("Camino");
            cbx_TipoCalle.Items.Add("Carretera");
            cbx_TipoCalle.Items.Add("Cerrada o Privada");
            cbx_TipoCalle.Items.Add("Pasaje");
        }

        #endregion

        private void DM0312_CamposExtra_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (camposExtraRecibe.Estatus)
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_CamposExtra")
                        {
                            forma.Dispose();
                            break;
                        }

                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_AyudaCodigoPostal")
                        {
                            forma.Dispose();
                            break;
                        }

                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "PuntoDeVenta")
                        {
                            forma.Show();
                            break;
                        }
                }
                else
                {
                    if (cbx_TipoCalle.Text == "" || txt_NombreCalle.Text == "" || txt_numExterior.Text == "" ||
                        txt_NumInterior.Text == "" || txt_Telefono.Text == "" || txt_Cruces.Text == "" ||
                        cbx_Colonia.Text == "" || txt_CodigoPostal.Text == "" || txt_TipoIdentificacion.Text == "" ||
                        txt_NombreConyuge.Text == "" || txt_Relacionado.Text == "")
                    {
                        string Faltantes = "";
                        if (cbx_TipoCalle.Text == string.Empty) Faltantes += "Tipo Calle";
                        if (txt_NombreCalle.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Nombre de calle" : "Nombre de calle";
                        if (txt_numExterior.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Numero exterior" : "Numero exterior";
                        if (txt_NumInterior.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Numero interior" : "Numero interior";
                        if (txt_Telefono.Text == string.Empty) Faltantes += Faltantes != "" ? ", teléfono" : "Teléfono";
                        if (txt_Cruces.Text == string.Empty) Faltantes += Faltantes != "" ? ", Cruces" : "Cruces";
                        if (cbx_Colonia.Text == string.Empty) Faltantes += Faltantes != "" ? ", Colonia" : "Colonia";
                        if (txt_CodigoPostal.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Codigo Postal" : "Codigo Postal";
                        if (txt_TipoIdentificacion.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Tipo de identificacion" : "Tipo de identificacion";
                        if (txt_NombreConyuge.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Nombre del Conyuge" : "Nombre del Conyuge";
                        if (txt_Relacionado.Text == string.Empty)
                            Faltantes += Faltantes != "" ? ", Relacionado" : "Relacionado";

                        MessageBox.Show(
                            "Falta agregar " + Faltantes + ", para poder salir debe llenar los campos obligatorios(*)",
                            "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }

            if (e.Control && e.KeyCode == Keys.G)
                if (Aceptar.Visible)
                    if (camposExtraRecibe.EstatusConsulta == false)
                        GuardarCamposEx();
        }

        private void txt_NombreCalle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_numExterior.Select();
        }

        private void txt_Cruces_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cbx_Colonia.Select();
        }

        private void txt_Relacionado_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void txt_numExterior_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_NumInterior.Select();
        }

        private void txt_Telefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_Cruces.Select();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_NumInterior_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_Telefono.Select();
        }

        private void txt_TipoIdentificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) dtp_FechaNacimiento.Select();
        }

        private void cbx_TipoCalle_KeyUp(object sender, KeyEventArgs e)
        {
        }

        #region "Handles"

        private void DM0312_CamposExtra_Load(object sender, EventArgs e)
        {
            label9.Visible = false;
            //cbx_TipoCalle.DropDownStyle = ComboBoxStyle.DropDownList;
            //cbx_Colonia.DropDownStyle = ComboBoxStyle.DropDownList;
            if (camposExtraRecibe.Estatus == false)
            {
                toolTip1.SetToolTip(Aceptar, "SELECCIONAR SI YA TERMINO DE LLENAR TODOS LOS CAMPOS QUE CONTIENEN UN *");
                toolTip1.SetToolTip(btn_Cancelar,
                    "ES OBLIGATORIO LLENAR TODOS LOS CAMPOS QUE CONTIENEN UN * PARA PODER SALIR");
                txt_ComentarioAyuda.Text =
                    "ACTUALIZAR LA INFORMACION DEL CLIENTE, SE DEBEN LLENAR TODOS LOS CAMPOS QUE CONTENGAN UN * PARA PODER CONTINUAR CON LA VENTA";
                btn_Cancelar.Visible = false;
            }
            else
            {
                toolTip1.SetToolTip(Aceptar, "SELECCIONAR PARA GUARADAR LA INFORMACION");
                toolTip1.SetToolTip(btn_Cancelar, "CANCELAR LA CAPTURA DE CAMPOS EXTRAS");
                txt_ComentarioAyuda.Text = "ACTUALIZAR LOS DATOS QUE SE REQUIERAN DEL CLIENTE";
                btn_Cancelar.Visible = true;
            }

            toolTip1.SetToolTip(cbx_TipoCalle, "INGRESAR TIPO DE CALLE DEL CLIENTE");
            toolTip1.SetToolTip(txt_NombreCalle, "INGRESAR NOMBRE DE LA CALLE DEL CLIENTE");
            toolTip1.SetToolTip(txt_numExterior, "INGRESAR NUMERO EXTERIOR DEL CLIENTE");
            toolTip1.SetToolTip(txt_NumInterior, "INGRESAR NUMERO INTERIOR DEL CLIENTE");
            toolTip1.SetToolTip(txt_Telefono, "INGRESAR NUMERO TELEFONICO DEL CLIENTE, SOLO ACEPTA NUMEROS");
            toolTip1.SetToolTip(txt_Cruces, "INGRESAR LAS CALLES EN LA QUE CRUZA");
            toolTip1.SetToolTip(cbx_Colonia, "INGRESAR LA COLONIA DEL CLIENTE");
            toolTip1.SetToolTip(txt_CodigoPostal, "INGRESAR CODIGO POSTAL DEL CLIENTE");
            toolTip1.SetToolTip(txt_TipoIdentificacion, "INGRESAR EL TIPO DE IDENTIFICACION DEL CLIENTE");
            toolTip1.SetToolTip(dtp_FechaNacimiento, "INGRESAR LA FECHA DE NACIMIENTO");
            toolTip1.SetToolTip(txt_NombreConyuge, "INGRESAR EL NOMBRE DEL CONYUGE DEL CLIENTE");
            toolTip1.SetToolTip(txt_Relacionado, "INGRESAR EL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(txt_TipoIdentificacion2, "INGRESAR EL NUMERO DE IDENTIFICACION DEL CLIENTE");


            ListaCampoExtraComentario = Funciones.ConsultaComentario("Campo Extra");
            cbx_TipoCalle.Items.Clear();
            FillTipeClave();
            if (camposExtraRecibe.TipoCalle != null && camposExtraRecibe.NomCalle != null &&
                camposExtraRecibe.NumInterior != null && camposExtraRecibe.Cruce != null &&
                camposExtraRecibe.Colonia != null && camposExtraRecibe.NumExterior != null &&
                camposExtraRecibe.CodigoPostal != null && camposExtraRecibe.Fecha != null)
            {
                if (camposExtraRecibe.TipoCalle == "") cbx_TipoCalle.Items.Clear();

                cbx_TipoCalle.Text = camposExtraRecibe.TipoCalle;
                txt_NombreCalle.Text = camposExtraRecibe.NomCalle;
                txt_numExterior.Text = camposExtraRecibe.NumExterior;
                txt_NumInterior.Text = camposExtraRecibe.NumInterior;
                txt_Cruces.Text = camposExtraRecibe.Cruce;
                txt_CodigoPostal.Text = camposExtraRecibe.CodigoPostal;
                cbx_Colonia.Text = camposExtraRecibe.Colonia;
                txt_Relacionado.Text = camposExtraRecibe.Relacionado;
                txt_Telefono.Text = camposExtraRecibe.Telefono;
                txt_TipoIdentificacion.Text = camposExtraRecibe.NumIdenti;
                txt_NombreConyuge.Text = camposExtraRecibe.Conyuge;
                dtp_FechaNacimiento.Text = camposExtraRecibe.Fecha;
                txt_TipoIdentificacion2.Text = camposExtraRecibe.NumIdent;
            }

            if (camposExtraRecibe.Estatus == false)
            {
                label1.Text = "*Tipo Calle";
                label2.Text = "*Nombre de Calle";
                label3.Text = "*Numero Exterior";
                label4.Text = "Numero Interior";
                label9.Visible = true;
                label5.Text = "*Cruces";
                label6.Text = "*Colonia";
                label7.Text = "*Codigo Postal";
                lbl_Tipo.Text = "*Tipo Identificacion";
                label10.Text = "*Fecha Nacimiento";
                label11.Text = "*Nombre Conyuge";
                label12.Text = "Relacionado a";
            }

            if (camposExtraRecibe.EstatusConsulta)
            {
                Aceptar.Visible = false;
                btn_Cancelar.Location = new Point(3, 3);
                toolTip1.SetToolTip(btn_Cancelar, "SALIR DE LA FORMA DE CONSULTA DE CAMPOS EXTRAS");
                txt_ComentarioAyuda.Text = "CONSULTAR LOS DATOS EXTRAS QUE SE INGRESARON EN LA CAPTURA DE LA VENTA";
                toolTip1.SetToolTip(cbx_TipoCalle, "TIPO DE CALLE DEL CLIENTE");
                toolTip1.SetToolTip(txt_NombreCalle, "NOMBRE DE LA CALLE DEL CLIENTE");
                toolTip1.SetToolTip(txt_numExterior, "NUMERO EXTERIOR DEL CLIENTE");
                toolTip1.SetToolTip(txt_NumInterior, "NUMERO INTERIOR DEL CLIENTE");
                toolTip1.SetToolTip(txt_Telefono, "NUMERO TELEFONICO DEL CLIENTE, SOLO ACEPTA NUMEROS");
                toolTip1.SetToolTip(txt_Cruces, "CALLES EN LA QUE CRUZA");
                toolTip1.SetToolTip(cbx_Colonia, "COLONIA DEL CLIENTE");
                toolTip1.SetToolTip(txt_CodigoPostal, "CODIGO POSTAL DEL CLIENTE");
                toolTip1.SetToolTip(txt_TipoIdentificacion, "TIPO DE IDENTIFICACION DEL CLIENTE");
                toolTip1.SetToolTip(dtp_FechaNacimiento, "FECHA DE NACIMIENTO");
                toolTip1.SetToolTip(txt_NombreConyuge, "NOMBRE DEL CONYUGE DEL CLIENTE");
                toolTip1.SetToolTip(txt_Relacionado, "CLIENTE RELACIONADO");
                toolTip1.SetToolTip(txt_TipoIdentificacion2, "NUMERO DE IDENTIFICACION DEL CLIENTE");
                cbx_TipoCalle.Enabled = false;
                txt_NombreCalle.Enabled = false;
                txt_numExterior.Enabled = false;
                txt_NumInterior.Enabled = false;
                txt_Telefono.Enabled = false;
                txt_Cruces.Enabled = false;
                cbx_Colonia.Enabled = false;
                txt_CodigoPostal.Enabled = false;
                txt_TipoIdentificacion.Enabled = false;
                txt_TipoIdentificacion2.Enabled = false;
                dtp_FechaNacimiento.Enabled = false;
                txt_NombreConyuge.Enabled = false;
                txt_Relacionado.Enabled = false;
                rb_TelefonoMovil.Enabled = false;
                rb_TelefonoParticular.Enabled = false;
            }
        }

        private void cbx_Colonia_Click(object sender, EventArgs e)
        {
            DM0312_AyudaCodigoPostal codigoPostal = new DM0312_AyudaCodigoPostal();
            if (txt_CodigoPostal.Text != "" || txt_CodigoPostal.Text != "")
            {
                codigoPostal.recibeCodigoPostal = Convert.ToInt32(txt_CodigoPostal.Text);
                codigoPostal.ShowDialog();
            }
            else
            {
                codigoPostal.recibeCodigoPostal = 0;
                codigoPostal.ShowDialog();
            }

            codigoPostal.recibeCodigoPostal = 0;
        }

        private void cbx_TipoCalle_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta tCalle = ListaCampoExtraComentario.Where(x => x.Campo.Equals("Tipo Calle"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = tCalle.Comentario;
            cbx_TipoCalle.Items.Clear();
            FillTipeClave();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (camposExtraRecibe.Estatus)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_CamposExtra")
                    {
                        forma.Dispose();
                        break;
                    }

                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_AyudaCodigoPostal")
                    {
                        forma.Dispose();
                        break;
                    }

                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "PuntoDeVenta")
                    {
                        forma.Show();
                        break;
                    }
            }
            else
            {
                if (cbx_TipoCalle.Text == "" || txt_NombreCalle.Text == "" || txt_numExterior.Text == "" ||
                    txt_Telefono.Text == "" || txt_Cruces.Text == "" || cbx_Colonia.Text == "" ||
                    txt_CodigoPostal.Text == "" || txt_TipoIdentificacion.Text == "" ||
                    txt_TipoIdentificacion2.Text == "" || txt_NombreConyuge.Text == "")
                {
                    string Faltantes = "";
                    if (cbx_TipoCalle.Text == string.Empty) Faltantes += "Tipo Calle";
                    if (txt_NombreCalle.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Nombre de calle" : "Nombre de calle";
                    if (txt_numExterior.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Numero exterior" : "Numero exterior";
                    if (txt_Telefono.Text == string.Empty) Faltantes += Faltantes != "" ? ", teléfono" : "Teléfono";
                    if (txt_Cruces.Text == string.Empty) Faltantes += Faltantes != "" ? ", Cruces" : "Cruces";
                    if (cbx_Colonia.Text == string.Empty) Faltantes += Faltantes != "" ? ", Colonia" : "Colonia";
                    if (txt_CodigoPostal.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Codigo Postal" : "Codigo Postal";
                    if (txt_TipoIdentificacion.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Tipo de identificacion" : "Tipo de identificacion";
                    if (txt_TipoIdentificacion2.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Numero de identificacion" : "Numero de identificacion";
                    if (txt_NombreConyuge.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Nombre del Conyuge" : "Nombre del Conyuge";

                    MessageBox.Show(
                        "Falta agregar " + Faltantes + ", para poder salir debe llenar los campos obligatorios(*)", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        public void GuardarCamposEx()
        {
            int validaInsert = 0;
            int count = 0;
            if (validaInsertUsuario)
            {
                foreach (Control item in groupBox1.Controls)
                    if (count < 13)
                    {
                        if (item is ComboBox)
                        {
                            valor[count] = ((ComboBox)item).Text;
                            count++;
                        }

                        if (item is TextBox)
                        {
                            valor[count] = ((TextBox)item).Text;
                            count++;
                        }

                        if (item is DateTimePicker)
                        {
                            valor[count] = ((DateTimePicker)item).Text;
                            count++;
                        }
                    }

                for (int i = 0; i < valor.Length; i++)
                {
                    validaInsert = controllCampoExtra.InsertaCampoExtra("VTAS", camposExtraRecibe.Mov,
                        camposExtraRecibe.IdVenta, campoExtra[i], valor[i]);
                    if (validaInsert == 0)
                    {
                        MessageBox.Show("Error al almacenar los datos", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

                        return;
                    }
                }

                controllCampoExtra.InsertaVentaCampoExtra(1, camposExtraRecibe.Cliente, camposExtraRecibe.IdVenta);
                MessageBox.Show("Se almacenaron los datos correctamente", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Dispose();
            }
            else if (validaInsertUsuario == false && cbx_TipoCalle.Text != "" && txt_NombreCalle.Text != "" &&
                     txt_numExterior.Text != ""
                     && txt_Telefono.Text != "" && txt_Cruces.Text != "" && txt_CodigoPostal.Text != "" &&
                     cbx_Colonia.Text != ""
                     && txt_TipoIdentificacion.Text != "" && dtp_FechaNacimiento.Text != "" &&
                     txt_NombreConyuge.Text != "")
            {
                foreach (Control item in groupBox1.Controls)
                    if (count < 13)
                    {
                        if (item is ComboBox)
                        {
                            valor[count] = ((ComboBox)item).Text;
                            count++;
                        }

                        if (item is TextBox)
                        {
                            valor[count] = ((TextBox)item).Text;
                            count++;
                        }

                        if (item is DateTimePicker)
                        {
                            valor[count] = ((DateTimePicker)item).Text;
                            count++;
                        }
                    }

                for (int i = 0; i < valor.Length; i++)
                {
                    validaInsert = controllCampoExtra.InsertaCampoExtra("VTAS", camposExtraRecibe.Mov,
                        camposExtraRecibe.IdVenta, campoExtra[i], valor[i]);
                    if (validaInsert == 0)
                    {
                        MessageBox.Show("Error al almacenar los datos", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

                        return;
                    }
                }

                controllCampoExtra.InsertaVentaCampoExtra(1, camposExtraRecibe.Cliente, camposExtraRecibe.IdVenta);
                MessageBox.Show("Se almacenaron los datos correctamente", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Dispose();
            }
            else
            {
                if (cbx_TipoCalle.Text == "" || txt_NombreCalle.Text == "" || txt_numExterior.Text == "" ||
                    txt_Telefono.Text == "" || txt_Cruces.Text == "" || cbx_Colonia.Text == "" ||
                    txt_CodigoPostal.Text == "" || txt_TipoIdentificacion.Text == "" ||
                    txt_TipoIdentificacion2.Text == "" || txt_NombreConyuge.Text == "")
                {
                    string Faltantes = "";
                    if (cbx_TipoCalle.Text == string.Empty) Faltantes += "Tipo Calle";
                    if (txt_NombreCalle.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Nombre de calle" : "Nombre de calle";
                    if (txt_numExterior.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Numero exterior" : "Numero exterior";
                    if (txt_Telefono.Text == string.Empty) Faltantes += Faltantes != "" ? ", teléfono" : "Teléfono";
                    if (txt_Cruces.Text == string.Empty) Faltantes += Faltantes != "" ? ", Cruces" : "Cruces";
                    if (cbx_Colonia.Text == string.Empty) Faltantes += Faltantes != "" ? ", Colonia" : "Colonia";
                    if (txt_CodigoPostal.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Codigo Postal" : "Codigo Postal";
                    if (txt_TipoIdentificacion.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Tipo de identificacion" : "Tipo de identificacion";
                    if (txt_TipoIdentificacion2.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Numero de identificacion" : "Numero de identificacion";
                    if (txt_NombreConyuge.Text == string.Empty)
                        Faltantes += Faltantes != "" ? ", Nombre del Conyuge" : "Nombre del Conyuge";
                    MessageBox.Show(
                        "Falta agregar " + Faltantes + " para poder guardar debe llenar los campos obligatorios(*)", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ComponentesFocus();
                }
            }
        }

        public void ComponentesFocus()
        {
            if (cbx_TipoCalle.Text == string.Empty)
            {
                cbx_TipoCalle.Select();
            }
            else
            {
                if (txt_NombreCalle.Text == string.Empty)
                {
                    txt_NombreCalle.Select();
                }
                else
                {
                    if (txt_numExterior.Text == string.Empty)
                    {
                        txt_numExterior.Select();
                    }
                    else
                    {
                        if (txt_NumInterior.Text == string.Empty)
                        {
                            txt_NumInterior.Select();
                        }
                        else
                        {
                            if (txt_Telefono.Text == string.Empty)
                            {
                                txt_Telefono.Select();
                            }
                            else
                            {
                                if (txt_Cruces.Text == string.Empty)
                                {
                                    txt_Cruces.Select();
                                }
                                else
                                {
                                    if (cbx_Colonia.Text == string.Empty)
                                    {
                                        cbx_Colonia.Select();
                                    }
                                    else if (txt_CodigoPostal.Text == string.Empty)
                                    {
                                        txt_CodigoPostal.Select();
                                    }
                                    else
                                    {
                                        if (txt_TipoIdentificacion.Text == string.Empty)
                                        {
                                            txt_TipoIdentificacion.Select();
                                        }
                                        else
                                        {
                                            if (txt_NombreConyuge.Text == string.Empty)
                                            {
                                                txt_NombreConyuge.Select();
                                            }
                                            else
                                            {
                                                if (txt_Relacionado.Text == string.Empty) txt_Relacionado.Select();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void Aceptar_Click(object sender, EventArgs e)
        {
            validacionTelefono();
            GuardarCamposEx();
        }

        public void validacionTelefono()
        {
            string idCliente = camposExtraRecibe.Cliente;
            string idventa = controlador.getIdVenta(idCliente);
            if (string.IsNullOrEmpty(psAgente)) psAgente = string.Empty;
            if (rb_TelefonoMovil.Checked)
            {
                if (!string.IsNullOrEmpty(idventa))
                {
                    if (controlador.LineaCredito(camposExtraRecibe.Cliente))
                    {
                        int numV = controladorD.SucursalRDP(ClaseEstatica.Usuario.sucursal);
                        if (numV == 1)
                        {
                            string ArgumentosPlugin = @"SHM.exe N SHM\ " + "\"" + string.Concat("VALIDACIONTELXSMS",
                                "|", camposExtraRecibe.Cliente, "|", camposExtraRecibe.IdVenta, "|", "CampoExtra", "|",
                                txt_Telefono.Text, "|", ClaseEstatica.Usuario.usuario, "|",
                                ClaseEstatica.Usuario.sucursal) + "\"" + " N N";

                            controladorD.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                        }
                        else
                        {
                            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                            {
                                string ArgumentosPlugin = "VALIDACIONTELXSMS" + " " + camposExtraRecibe.Cliente + " " +
                                                          idventa + " " + "CampoExtra" + " " + txt_Telefono.Text + " " +
                                                          ClaseEstatica.Usuario.usuario + " " +
                                                          ClaseEstatica.Usuario.sucursal;
                                controladorD.EjecutarPlugins(ArgumentosPlugin, "SHM.exe",
                                    ConfigurationManager.AppSettings["CarpetaSHM"]);
                            }
                        }
                        //bTelefonoVailido = controllCampoExtra.verificarTelefonoValido(idCliente);
                    }
                    else
                    {
                        MessageBox.Show("El cliente no cuenta con una linea de credito.", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("El cliente no tiene movimientos", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
        }

        private void cbx_Colonia_Click_1(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta colonia =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Colonia")).FirstOrDefault();
            txt_ComentarioAyuda.Text = colonia.Comentario;
            DM0312_AyudaCodigoPostal codigoPostal = new DM0312_AyudaCodigoPostal();
            codigoPostal.recibeMov = camposExtraRecibe.Mov;
            codigoPostal.recibeIdVenta = camposExtraRecibe.IdVenta;
            codigoPostal.recibeCliente = camposExtraRecibe.Cliente;
            codigoPostal.recibeTipoCalle = cbx_TipoCalle.Text;
            codigoPostal.recibeNomCalle = txt_NombreCalle.Text;
            codigoPostal.recibeNumExterior = txt_numExterior.Text;
            codigoPostal.recibeNumInterior = txt_NumInterior.Text;
            codigoPostal.recibeCruce = txt_Cruces.Text;
            codigoPostal.recibeTelefono = txt_Telefono.Text;
            codigoPostal.recibeNumIdenti = txt_TipoIdentificacion.Text;
            codigoPostal.recibeNombreConyuge = txt_NombreConyuge.Text;
            codigoPostal.recibeRelacionado = txt_Relacionado.Text;
            if (txt_CodigoPostal.Text != "" || txt_CodigoPostal.Text != "")
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_AyudaCodigoPostal")
                    {
                        forma.Dispose();
                        break;
                    }

                if (cbx_Colonia.Text != "" || (cbx_Colonia.Text != null && txt_CodigoPostal.Text == ""))
                    codigoPostal.recibeCodigoPostal = 0;
                else
                    codigoPostal.recibeCodigoPostal = Convert.ToInt32(txt_CodigoPostal.Text);
                codigoPostal.ShowDialog();
                txt_TipoIdentificacion.Focus();
            }
            else
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_CamposExtra")
                    {
                        forma.Visible = false;
                        break;
                    }

                codigoPostal.recibeCodigoPostal = 0;
                codigoPostal.ShowDialog();
                txt_TipoIdentificacion.Focus();
            }
        }

        private void cbx_TipoCalle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_NombreCalle.Select();
        }

        private void txt_Telefono_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txt_Telefono.Text, "[^0-9-/-]"))
            {
                MessageBox.Show("Solo se permiten numeros", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_Telefono.Text = txt_Telefono.Text.Remove(txt_Telefono.Text.Length - 1);
                txt_Telefono.SelectionStart = txt_Telefono.Text.Length;
                txt_Telefono.Focus();
            }
        }

        private void txt_Telefono_Leave(object sender, EventArgs e)
        {
            if (txt_Telefono.Text != "")
            {
                string value = controladorPuntoVenta.TelefonoCorrecto(txt_Telefono.Text);
                if (value != "0")
                {
                    MessageBox.Show(value, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txt_Telefono.Text = txt_Telefono.Text.Remove(txt_Telefono.Text.Length - 1);
                    txt_Telefono.SelectionStart = txt_Telefono.Text.Length;
                    txt_Telefono.Focus();
                }
            }
        }

        private void txt_NombreCalle_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta nCalle = ListaCampoExtraComentario.Where(x => x.Campo.Equals("Nombre de Calle"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = nCalle.Comentario;
        }

        private void txt_numExterior_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta numeroExterior =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Numero Exterior")).FirstOrDefault();
            txt_ComentarioAyuda.Text = numeroExterior.Comentario;
        }

        private void txt_NumInterior_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta numeroInterior =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Numero Interior")).FirstOrDefault();
            txt_ComentarioAyuda.Text = numeroInterior.Comentario;
        }

        private void txt_Telefono_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta telefono =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Telefono")).FirstOrDefault();
            txt_ComentarioAyuda.Text = telefono.Comentario;
        }

        private void txt_Cruces_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta cruces = ListaCampoExtraComentario.Where(x => x.Campo.Equals("Cruces"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = cruces.Comentario;
        }

        private void txt_CodigoPostal_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta cp = ListaCampoExtraComentario.Where(x => x.Campo.Equals("Codigo Postal"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = cp.Comentario;
        }

        private void txt_TipoIdentificacion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta tIndentificacion = ListaCampoExtraComentario
                .Where(x => x.Campo.Equals("Tipo Indentificacion")).FirstOrDefault();
            txt_ComentarioAyuda.Text = tIndentificacion.Comentario;
        }

        private void dtp_FechaNacimiento_MouseUp(object sender, MouseEventArgs e)
        {
            DM0312_MComentariosVenta fechaNacimiento = ListaCampoExtraComentario
                .Where(x => x.Campo.Equals("Fecha Nacimiento")).FirstOrDefault();
            txt_ComentarioAyuda.Text = fechaNacimiento.Comentario;
        }

        private void txt_NombreConyuge_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta nombreConyuge =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Nombre Conyuge")).FirstOrDefault();
            txt_ComentarioAyuda.Text = nombreConyuge.Comentario;
        }

        private void txt_Relacionado_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta relacionado =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Relacionado A")).FirstOrDefault();
            txt_ComentarioAyuda.Text = relacionado.Comentario;
        }

        private void DM0312_CamposExtra_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void txt_CodigoPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            DM0312_MComentariosVenta colonia =
                ListaCampoExtraComentario.Where(x => x.Campo.Equals("Colonia")).FirstOrDefault();
            txt_ComentarioAyuda.Text = colonia.Comentario;
            DM0312_AyudaCodigoPostal codigoPostal = new DM0312_AyudaCodigoPostal();
            codigoPostal.recibeMov = camposExtraRecibe.Mov;
            codigoPostal.recibeIdVenta = camposExtraRecibe.IdVenta;
            codigoPostal.recibeCliente = camposExtraRecibe.Cliente;
            codigoPostal.recibeTipoCalle = cbx_TipoCalle.Text;
            codigoPostal.recibeNomCalle = txt_NombreCalle.Text;
            codigoPostal.recibeNumExterior = txt_numExterior.Text;
            codigoPostal.recibeNumInterior = txt_NumInterior.Text;
            codigoPostal.recibeCruce = txt_Cruces.Text;
            codigoPostal.recibeTelefono = txt_Telefono.Text;
            codigoPostal.recibeNumIdenti = txt_TipoIdentificacion.Text;
            codigoPostal.recibeNombreConyuge = txt_NombreConyuge.Text;
            codigoPostal.recibeRelacionado = txt_Relacionado.Text;
            if (txt_CodigoPostal.Text != "" || txt_CodigoPostal.Text != "")
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_AyudaCodigoPostal")
                    {
                        forma.Dispose();
                        break;
                    }

                if (cbx_Colonia.Text != "" || (cbx_Colonia.Text != null && txt_CodigoPostal.Text == ""))
                    codigoPostal.recibeCodigoPostal = 0;
                else
                    codigoPostal.recibeCodigoPostal = Convert.ToInt32(txt_CodigoPostal.Text);
                codigoPostal.ShowDialog();
            }
            else
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_CamposExtra")
                    {
                        forma.Visible = false;
                        break;
                    }

                codigoPostal.recibeCodigoPostal = 0;
                codigoPostal.ShowDialog();
                txt_TipoIdentificacion.Focus();
            }
        }

        private void txt_NombreConyuge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else if (char.IsSeparator(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_Relacionado.Select();
        }

        private void cbx_Colonia_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_CodigoPostal.Select();
        }

        #endregion
    }
}