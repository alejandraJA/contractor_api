﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_PermisosConfiguracion : Form
    {
        public static List<DM0312_MConfiguracionColumnas> listaModelo = new List<DM0312_MConfiguracionColumnas>();
        public static List<DM0312_MConfiguracionColumnas> listaClonar = new List<DM0312_MConfiguracionColumnas>();
        public static DM0312_C_ConfiguracionColumnas controlador = new DM0312_C_ConfiguracionColumnas();
        private static string Forma, ValidaForma;
        private string Acceso, Campo, Nuevo, Clonar;
        private DataGridViewCheckBoxCell cellSelecion = new DataGridViewCheckBoxCell();
        private string DescripcionCampo;
        private bool Existe, Estatus, NuevoCampo;
        private List<DM0312_MConfiguracionColumnas> FindList = new List<DM0312_MConfiguracionColumnas>();
        private string FormaTemp = string.Empty;
        private readonly Funciones funciones = new Funciones();
        private int indexDgvAcceso;
        private int indexDgvAccesoUsuario;
        private List<DM0312_MConfiguracionColumnas> listNuevoAcceso = new List<DM0312_MConfiguracionColumnas>();
        private readonly List<object> listTemp;
        private bool validaNoAvance;

        public DM0312_PermisosConfiguracion()
        {
            listTemp = new List<object>();
            InitializeComponent();
        }

        ~DM0312_PermisosConfiguracion()
        {
            GC.Collect();
        }


        #region "METHODS"

        public void LlenaAcceso()
        {
            DataTable dataSet = new DataTable();
            dataSet = controlador.ObtieneAcceso();
            dgvAcceso.DataSource = dataSet;
        }

        public void LlenaClonarAcceso()
        {
            DataTable dataSet = new DataTable();
            dataSet = controlador.ObtieneAcceso();
            cmbClonarAcceso.DataSource = dataSet;
            cmbClonarAcceso.DisplayMember = "Acceso";
            cmbClonarAcceso.ValueMember = "Acceso";
        }

        public void LlenaNuevoAcceso()
        {
            listNuevoAcceso = controlador.ObtieneNuevoAcceso();
            cmbNuevoAcceso.DataSource = listNuevoAcceso;

            cmbNuevoAcceso.DisplayMember = "Acceso";
            cmbNuevoAcceso.ValueMember = "Acceso";

            cmbNuevoAcceso.SelectedIndex = -1;
        }

        public void LlenaAccesoUsuario()
        {
            int index = 0;
            dgvAccesoUsuario.DataSource = "";
            listaModelo = new List<DM0312_MConfiguracionColumnas>();
            index = dgvAcceso.CurrentRow.Index;
            Acceso = dgvAcceso.Rows[indexDgvAcceso].Cells["Acceso"].FormattedValue.ToString();

            listaModelo = controlador.ObtienePermisos(Acceso, Forma);

            dgvAccesoUsuario.Visible = true;
            dgvAccesoUsuario.DataSource = listaModelo.ToList();

            dgvAccesoUsuario.Columns["Campo"].Visible = false;
            dgvAccesoUsuario.Columns["Estatus"].Visible = false;
            dgvAccesoUsuario.Columns[2].Width = 150;
            dgvAccesoUsuario.Columns[3].Width = 50;
            dgvAccesoUsuario.Columns[2].ReadOnly = true;
            dgvAccesoUsuario.Columns[3].ReadOnly = false;
            dgvAccesoUsuario.Columns[0].Visible = false;
            dgvAccesoUsuario.Columns[1].Visible = false;
            dgvAccesoUsuario.Columns["DescripcionCampo"].HeaderText = "Descripcion Componente";
        }

        public void LlenaFormas()
        {
            DataTable formas = new DataTable();
            formas = controlador.ObtieneForma();
            cmbFormas.DataSource = formas;

            cmbFormas.DisplayMember = "FormaUsuario";
            cmbFormas.ValueMember = "FormaUsuario";

            cmbFormas.Visible = true;
            lbl_Forma.Visible = true;


            pnl_NuevoAcceso.Visible = false;

            cmbFormas.SelectedIndex = -1;

            //       LlenaAccesoUsuario();
        }

        public void Actualiza()
        {
            int actualiza = 0;
            int contador = 0;
            int contadorTemp = 0;
            foreach (object valor in listTemp)
            {
                contadorTemp++;
                PropertyInfo Reflection_;
                PropertyInfo Reflection_1;
                PropertyInfo Reflection_2;
                PropertyInfo Reflection_3;
                Reflection_ = valor.GetType().GetProperty("Estatus");
                Reflection_1 = valor.GetType().GetProperty("Forma");
                Reflection_2 = valor.GetType().GetProperty("Campo");
                Reflection_3 = valor.GetType().GetProperty("Acceso1");
                bool estatus = (bool)Reflection_.GetValue(valor, null);
                string forma = (string)Reflection_1.GetValue(valor, null);
                string campo = (string)Reflection_2.GetValue(valor, null);
                string acceso = (string)Reflection_3.GetValue(valor, null);

                actualiza = controlador.Actualiza(acceso, forma, campo, estatus);
                if (actualiza == 1) contador++;
            }

            if (contador == contadorTemp)
                MessageBox.Show("Datos actualizados correctamente", "!Aviso¡", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
        }

        public void ValidaRegistro()
        {
            Existe = controlador.Existe(Acceso, Forma, Campo);
        }

        public void ValidaExisteCampo()
        {
            Existe = controlador.ExisteCampo(Forma, Campo);
        }

        public void ObtieneTodosPermisos(string nuevo, string copy)
        {
            listaClonar = new List<DM0312_MConfiguracionColumnas>();
            listaClonar = controlador.ObtieneTodosPermisos(copy);
            foreach (DM0312_MConfiguracionColumnas prop in listaClonar)
            {
                bool Inserta = controlador.Inserta(nuevo, prop.Forma, prop.Campo, prop.Estatus);
            }
        }

        public void Limpear()
        {
            Forma = string.Empty;
            Campo = string.Empty;
            Nuevo = string.Empty;
            Clonar = string.Empty;
            Existe = false;
            Estatus = false;
            txt_Campo.Text = string.Empty;


            NuevoCampo = false;
            menuPermisos.Visible = true;
        }

        #endregion

        #region "HANDLES"

        private void DM0312_PermisosConfiguracionColumnas_Load(object sender, EventArgs e)
        {
            LlenaFormas();
            LlenaClonarAcceso();
            LlenaNuevoAcceso();
        }

        private void dgvAcceso_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvAcceso.Columns["Acceso"].ReadOnly = true;
            if (e.RowIndex == -1)
                return;

            if (dgvAcceso.Visible)
                indexDgvAcceso = dgvAcceso.CurrentRow.Index;
            else

                MessageBox.Show("No ha seleccionado ninguna forma", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
        }

        private void cmbFormas_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_Campo.Text = "";
            FindList.Clear();
            FormaTemp = Convert.ToString(cmbFormas.SelectedValue);
            if (listTemp.Count > 0 && validaNoAvance == false)
            {
                DialogResult dialogResult = MessageBox.Show("¿Desea almacenar los cambios?", "",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (dialogResult == DialogResult.Yes)
                {
                    listTemp.Clear();
                    Forma = Convert.ToString(cmbFormas.SelectedValue);
                    ValidaForma = Forma;
                    LlenaAccesoUsuario();
                }

                if (dialogResult == DialogResult.Cancel)
                {
                    ValidaForma = Forma;
                    validaNoAvance = true;
                    cmbFormas.SelectedValue = Forma;
                    return;
                }

                if (dialogResult == DialogResult.No)
                {
                    listTemp.Clear();
                    Forma = Convert.ToString(cmbFormas.SelectedValue);
                    ValidaForma = Forma;
                    if (Forma != "" && Forma != "System.Data.DataRowView") LlenaAccesoUsuario();
                }
            }
            else
            {
                Forma = FormaTemp;
                if (validaNoAvance)
                {
                    Forma = ValidaForma;
                    cmbFormas.SelectedValue = Forma;
                    validaNoAvance = false;
                    return;
                }

                if (validaNoAvance == false)
                    if (Acceso != "" && Forma != "" && Forma != "System.Data.DataRowView")
                    {
                        LlenaAcceso();
                        LlenaAccesoUsuario();
                    }
            }
        }

        private void toolGuardar_Click(object sender, EventArgs e)
        {
            dgvAccesoUsuario.ClearSelection();
            dgvAccesoUsuario.EndEdit();
            if (listTemp.Count > 0) Actualiza();
            listTemp.Clear();
        }

        private void nuevoAccesoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pnl_NuevoAcceso.Visible)
            {
                pnl_NuevoAcceso.Visible = false;
            }
            else
            {
                pnl_NuevoAcceso.Visible = true;
                lbl_Forma.Visible = false;
                dgvAccesoUsuario.Visible = false;
                cmbFormas.Visible = false;
                cmbFormas.DataSource = null;
                txt_Campo.Visible = false;
                lbl_Campo.Visible = false;
                dgvAcceso.Visible = false;
            }
        }

        private void clonarAccesoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cmbNuevoAcceso.Text != "" && cmbClonarAcceso.Text != "")
            {
                Nuevo = string.Empty;
                Clonar = string.Empty;
                Nuevo = Convert.ToString(cmbNuevoAcceso.SelectedValue);
                Clonar = Convert.ToString(cmbClonarAcceso.SelectedValue);
                if (Nuevo != "" && Clonar != "")
                {
                    ObtieneTodosPermisos(Nuevo, Clonar);
                    LlenaAcceso();
                    MessageBox.Show("Acceso clonado con éxito", "Éxito", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un elemento valido", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    cmbNuevoAcceso.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar un acceso a clonar", "!Aviso¡", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
        }

        private void cmbNuevoAcceso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                string value = cmbNuevoAcceso.Text;
                if (value != "")
                {
                    DM0312_MConfiguracionColumnas index = listNuevoAcceso.Where(x => x.Acceso.Contains(value))
                        .FirstOrDefault();
                    if (index != null)
                        cmbNuevoAcceso.SelectedValue = Convert.ToString(index.Acceso);
                    else
                        MessageBox.Show("No se encontro ningun acceso", "!Aviso¡", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
            }
        }

        private void cmbClonarAcceso_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void nuevoCampoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NuevoCampo = true;
            LlenaFormas();
            dgvAccesoUsuario.Visible = false;
            menuPermisos.Visible = false;
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            if (NuevoCampo && txt_Campo.Text.Trim() != "")
            {
                Existe = false;
                Estatus = false;
                Forma = cmbFormas.Text;
                Campo = txt_Campo.Text;
                ValidaExisteCampo();
                if (Existe == false)
                {
                    if (Acceso == "" || Acceso == null) Acceso = dgvAcceso.Rows[0].Cells["Acceso"].Value.ToString();

                    LlenaAccesoUsuario();
                    Limpear();
                    MessageBox.Show("Registro guardado con éxito", "Éxito", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("El campo ya esta registrado", "Éxito", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    txt_Campo.Text = string.Empty;
                }
            }
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            NuevoCampo = false;
            dgvAccesoUsuario.Visible = false;
            lbl_Campo.Visible = false;
            txt_Campo.Visible = false;
            menuPermisos.Visible = true;
        }

        private void dgvAccesoUsuario_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex <= -1)
                return;

            indexDgvAccesoUsuario = dgvAccesoUsuario.CurrentRow.Index;
            DescripcionCampo = dgvAccesoUsuario.Rows[e.RowIndex].Cells["DescripcionCampo"].FormattedValue.ToString();
            Forma = Convert.ToString(cmbFormas.SelectedValue);

            if (Acceso != "" && Forma != "" && Forma != "System.Data.DataRowView")
            {
                DataTable dataSet = new DataTable();
                dataSet = controlador.ObtieneConfiguracionComponentesUsuario(Forma, DescripcionCampo);
                dgvAcceso.DataSource = null;
                dgvAcceso.DataSource = dataSet;
                dgvAcceso.Columns["DescripcionCampo"].Visible = false;
            }
        }

        private void dgvAcceso_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex <= -1)
                return;

            if (dgvAccesoUsuario.Visible && indexDgvAccesoUsuario >= 0)
            {
                DataGridViewRow row = dgvAcceso.Rows[e.RowIndex];
                if (dgvAcceso.Columns[e.ColumnIndex].Name == "Estatus")
                {
                    cellSelecion = row.Cells["Estatus"] as DataGridViewCheckBoxCell;
                    if (Convert.ToBoolean(cellSelecion.EditedFormattedValue))
                    {
                        var projectList = (from row1 in dgvAcceso.Rows.OfType<DataGridViewRow>()
                            select new
                            {
                                Estatus = true,
                                Forma = Convert.ToString(cmbFormas.SelectedValue),
                                Campo = dgvAccesoUsuario.Rows[indexDgvAccesoUsuario].Cells["DescripcionCampo"].Value
                                    .ToString(),
                                Acceso1 = dgvAcceso.Rows[indexDgvAcceso].Cells["Acceso"].Value.ToString()
                            }).FirstOrDefault();
                        listTemp.Add(projectList);
                    }

                    else
                    {
                        var projectList = (from row1 in dgvAcceso.Rows.OfType<DataGridViewRow>()
                            select new
                            {
                                Estatus = false,
                                Forma = Convert.ToString(cmbFormas.SelectedValue),
                                Campo = dgvAccesoUsuario.Rows[indexDgvAccesoUsuario].Cells["DescripcionCampo"].Value
                                    .ToString(),
                                Acceso1 = dgvAcceso.Rows[indexDgvAcceso].Cells["Acceso"].Value.ToString()
                            }).FirstOrDefault();
                        listTemp.Add(projectList);
                        cellSelecion.Value = false;
                    }
                }
            }
            else
            {
                dgvAcceso.Columns["Estatus"].ReadOnly = true;
            }
        }

        private void txt_Campo_KeyPress(object sender, KeyPressEventArgs e)
        {
            string value = txt_Campo.Text;
            string asterisco = "*";
            if (value.Contains(asterisco)) value = value.Substring(0, value.IndexOf("*"));
            if (e.KeyChar == (int)Keys.Enter)
            {
                FindList = listaModelo.Where(x => x.DescripcionCampo.Contains(value)).ToList();
                dgvAccesoUsuario.DataSource = null;
                dgvAccesoUsuario.DataSource = FindList;
                dgvAccesoUsuario.Columns["DescripcionCampo"].HeaderText = "Descripcion Componente";
                dgvAccesoUsuario.Columns["Acceso"].Visible = false;
                dgvAccesoUsuario.Columns["Forma"].Visible = false;
                dgvAccesoUsuario.Columns["Campo"].Visible = false;
                dgvAccesoUsuario.Columns["Estatus"].Visible = false;
                dgvAccesoUsuario.Columns["Campo"].Visible = false;
                dgvAccesoUsuario.Columns["Estatus"].Visible = false;
            }
        }

        private void regresarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void dgvAccesoUsuario_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (FindList.Count > 0)
            {
                List<object> TempObjects = new List<object>(FindList);
                funciones.OrderGridview(dgvAccesoUsuario, e.ColumnIndex, TempObjects,
                    FindList.GetType().GetGenericArguments().Single());
            }
            else
            {
                List<object> TempObjects = new List<object>(listaModelo);
                funciones.OrderGridview(dgvAccesoUsuario, e.ColumnIndex, TempObjects,
                    listaModelo.GetType().GetGenericArguments().Single());
            }

            dgvAccesoUsuario.Columns["DescripcionCampo"].HeaderText = "Descripcion Componente";
            dgvAccesoUsuario.Columns["Acceso"].Visible = false;
            dgvAccesoUsuario.Columns["Forma"].Visible = false;
            dgvAccesoUsuario.Columns["Campo"].Visible = false;
            dgvAccesoUsuario.Columns["Estatus"].Visible = false;
            dgvAccesoUsuario.Columns["Campo"].Visible = false;
            dgvAccesoUsuario.Columns["Estatus"].Visible = false;
        }

        private void dgvAcceso_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dgvAcceso.Columns["Estatus"].ReadOnly = true;
        }

        #endregion
    }
}