﻿namespace PuntoVenta.View
{
    partial class DM0312_RegistroDeHuellaFechas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_RegistroDeHuellaFechas));
            this.BtnCalendarInicio = new System.Windows.Forms.Button();
            this.BtnCalendarFin = new System.Windows.Forms.Button();
            this.txtFechaInicio = new System.Windows.Forms.TextBox();
            this.txtFechaFin = new System.Windows.Forms.TextBox();
            this.CalendarInicio = new System.Windows.Forms.MonthCalendar();
            this.CalendarFin = new System.Windows.Forms.MonthCalendar();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.errorProvider_ = new System.Windows.Forms.ErrorProvider(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnCalendarInicio
            // 
            this.BtnCalendarInicio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnCalendarInicio.BackgroundImage")));
            this.BtnCalendarInicio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnCalendarInicio.FlatAppearance.BorderSize = 0;
            this.BtnCalendarInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCalendarInicio.ForeColor = System.Drawing.Color.Transparent;
            this.BtnCalendarInicio.Location = new System.Drawing.Point(247, 12);
            this.BtnCalendarInicio.Name = "BtnCalendarInicio";
            this.BtnCalendarInicio.Size = new System.Drawing.Size(47, 41);
            this.BtnCalendarInicio.TabIndex = 1;
            this.BtnCalendarInicio.UseVisualStyleBackColor = true;
            this.BtnCalendarInicio.Click += new System.EventHandler(this.BtnCalendarInicio_Click);
            // 
            // BtnCalendarFin
            // 
            this.BtnCalendarFin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnCalendarFin.BackgroundImage")));
            this.BtnCalendarFin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnCalendarFin.FlatAppearance.BorderSize = 0;
            this.BtnCalendarFin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCalendarFin.ForeColor = System.Drawing.Color.Transparent;
            this.BtnCalendarFin.Location = new System.Drawing.Point(247, 59);
            this.BtnCalendarFin.Name = "BtnCalendarFin";
            this.BtnCalendarFin.Size = new System.Drawing.Size(47, 37);
            this.BtnCalendarFin.TabIndex = 2;
            this.BtnCalendarFin.UseVisualStyleBackColor = true;
            this.BtnCalendarFin.Click += new System.EventHandler(this.BtnCalendarFin_Click);
            // 
            // txtFechaInicio
            // 
            this.txtFechaInicio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaInicio.Location = new System.Drawing.Point(83, 18);
            this.txtFechaInicio.Name = "txtFechaInicio";
            this.txtFechaInicio.Size = new System.Drawing.Size(154, 22);
            this.txtFechaInicio.TabIndex = 3;
            this.txtFechaInicio.Validating += new System.ComponentModel.CancelEventHandler(this.txtFechaInicio_Validating);
            // 
            // txtFechaFin
            // 
            this.txtFechaFin.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaFin.Location = new System.Drawing.Point(83, 65);
            this.txtFechaFin.Name = "txtFechaFin";
            this.txtFechaFin.Size = new System.Drawing.Size(154, 22);
            this.txtFechaFin.TabIndex = 4;
            this.txtFechaFin.Validating += new System.ComponentModel.CancelEventHandler(this.txtFechaFin_Validating);
            // 
            // CalendarInicio
            // 
            this.CalendarInicio.Location = new System.Drawing.Point(33, 14);
            this.CalendarInicio.Name = "CalendarInicio";
            this.CalendarInicio.TabIndex = 5;
            this.CalendarInicio.TodayDate = new System.DateTime(2017, 10, 3, 0, 0, 0, 0);
            this.CalendarInicio.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalendarInicio_DateSelected);
            // 
            // CalendarFin
            // 
            this.CalendarFin.Location = new System.Drawing.Point(33, 21);
            this.CalendarFin.Name = "CalendarFin";
            this.CalendarFin.TabIndex = 6;
            this.CalendarFin.TodayDate = new System.DateTime(2017, 10, 3, 0, 0, 0, 0);
            this.CalendarFin.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalendarFin_DateSelected);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancelar.ForeColor = System.Drawing.Color.Transparent;
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.Location = new System.Drawing.Point(237, 110);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(46, 38);
            this.BtnCancelar.TabIndex = 7;
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAceptar.ForeColor = System.Drawing.Color.Transparent;
            this.BtnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("BtnAceptar.Image")));
            this.BtnAceptar.Location = new System.Drawing.Point(170, 110);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(46, 38);
            this.BtnAceptar.TabIndex = 8;
            this.BtnAceptar.UseVisualStyleBackColor = true;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // errorProvider_
            // 
            this.errorProvider_.ContainerControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Fecha Inicio:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Fecha Fin:";
            // 
            // DM0312_RegistroDeHuellaFechas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(297, 191);
            this.Controls.Add(this.CalendarFin);
            this.Controls.Add(this.CalendarInicio);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnAceptar);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.txtFechaFin);
            this.Controls.Add(this.txtFechaInicio);
            this.Controls.Add(this.BtnCalendarFin);
            this.Controls.Add(this.BtnCalendarInicio);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DM0312_RegistroDeHuellaFechas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fechas";
            this.Load += new System.EventHandler(this.DM1132_RegistroHuella_Fechas_Load);
            this.Click += new System.EventHandler(this.DM0312_RegistroDeHuellaFechas_Click);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCalendarInicio;
        private System.Windows.Forms.Button BtnCalendarFin;
        private System.Windows.Forms.TextBox txtFechaInicio;
        private System.Windows.Forms.TextBox txtFechaFin;
        private System.Windows.Forms.MonthCalendar CalendarInicio;
        private System.Windows.Forms.MonthCalendar CalendarFin;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.ErrorProvider errorProvider_;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;

    }
}