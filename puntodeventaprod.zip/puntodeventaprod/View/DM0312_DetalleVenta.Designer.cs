﻿namespace PuntoVenta
{
    partial class DM0312_DetalleVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_DetalleVenta));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cms_copiar = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UsrIncremento = new System.Windows.Forms.ToolStripMenuItem();
            this.UsrDescuento = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.flpanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.txt_Cliente = new System.Windows.Forms.TextBox();
            this.txt_Cliente1 = new System.Windows.Forms.TextBox();
            this.lbl_TipoVenta = new System.Windows.Forms.Label();
            this.txt_TipoVenta = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl_Agente = new System.Windows.Forms.Label();
            this.txt_Agente = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_Canal = new System.Windows.Forms.TextBox();
            this.lbl_Canal = new System.Windows.Forms.Label();
            this.txt_Canal1 = new System.Windows.Forms.TextBox();
            this.lbl_Condiciones = new System.Windows.Forms.Label();
            this.txt_Condiciones = new System.Windows.Forms.TextBox();
            this.lbl_Almacen = new System.Windows.Forms.Label();
            this.cb_Almacen = new System.Windows.Forms.ComboBox();
            this.pan_correo = new System.Windows.Forms.Panel();
            this.lbl_Correo = new System.Windows.Forms.Label();
            this.txt_Correo = new System.Windows.Forms.TextBox();
            this.pan_refConcepto = new System.Windows.Forms.Panel();
            this.txt_Referencia = new System.Windows.Forms.TextBox();
            this.txt_Concepto = new System.Windows.Forms.TextBox();
            this.lbl_Concepto = new System.Windows.Forms.Label();
            this.lbl_Referencia = new System.Windows.Forms.Label();
            this.lbl_Ecommerce = new System.Windows.Forms.Label();
            this.txt_Commerce = new System.Windows.Forms.TextBox();
            this.pan_formaPago = new System.Windows.Forms.Panel();
            this.txt_FormaCo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_FormaPago = new System.Windows.Forms.Label();
            this.txt_FormaPago = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCuentaClabe = new System.Windows.Forms.Label();
            this.txtCuentaClabe = new System.Windows.Forms.TextBox();
            this.lblBanco = new System.Windows.Forms.Label();
            this.txtBanco = new System.Windows.Forms.TextBox();
            this.txt_CodigoRecomendado = new System.Windows.Forms.TextBox();
            this.lbl_CodigoRecomendado = new System.Windows.Forms.Label();
            this.txt_Enganche = new System.Windows.Forms.ComboBox();
            this.lbl_Enganche = new System.Windows.Forms.Label();
            this.txt_EmbarqueFecha = new System.Windows.Forms.TextBox();
            this.txt_Embarque = new System.Windows.Forms.TextBox();
            this.lbl_Embarque = new System.Windows.Forms.Label();
            this.txt_Monedero = new System.Windows.Forms.TextBox();
            this.lbl_RedMonedero = new System.Windows.Forms.Label();
            this.chk_Mayoreo = new System.Windows.Forms.CheckBox();
            this.chk_Custodia = new System.Windows.Forms.CheckBox();
            this.chk_Iva = new System.Windows.Forms.CheckBox();
            this.chk_Comentario = new System.Windows.Forms.CheckBox();
            this.lbl_AgenteServicio = new System.Windows.Forms.Label();
            this.txt_AgenteServicio = new System.Windows.Forms.TextBox();
            this.lbl_FormaEnvio = new System.Windows.Forms.Label();
            this.txt_FormaEnvio = new System.Windows.Forms.TextBox();
            this.lbl_CtaPago = new System.Windows.Forms.Label();
            this.txt_CtaPago = new System.Windows.Forms.TextBox();
            this.cb_ServicioReporte = new System.Windows.Forms.CheckBox();
            this.lbl_nomina = new System.Windows.Forms.Label();
            this.tb_nomina = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGuardarComentarios = new System.Windows.Forms.Button();
            this.lbl_Observaciones = new System.Windows.Forms.Label();
            this.txt_Observaciones = new System.Windows.Forms.TextBox();
            this.lbl_Comentario = new System.Windows.Forms.Label();
            this.txt_Comentario = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Descripcion = new System.Windows.Forms.Label();
            this.lbl_Unidad = new System.Windows.Forms.Label();
            this.flp_articulos = new System.Windows.Forms.FlowLayoutPanel();
            this.dgv_detalle = new System.Windows.Forms.DataGridView();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.txt_SubTotal = new System.Windows.Forms.TextBox();
            this.lbl_Impuestos = new System.Windows.Forms.Label();
            this.txt_Impuestos = new System.Windows.Forms.TextBox();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.lblMonedero = new System.Windows.Forms.Label();
            this.txtMonedero = new System.Windows.Forms.TextBox();
            this.pan_Vales = new System.Windows.Forms.Panel();
            this.tx_panelvaleInfo = new System.Windows.Forms.TextBox();
            this.txt_vale = new System.Windows.Forms.TextBox();
            this.txt_NIP = new System.Windows.Forms.TextBox();
            this.lbl_ValeVenta = new System.Windows.Forms.Label();
            this.lbl_nip = new System.Windows.Forms.Label();
            this.pnlBtn_DatosEntrega = new System.Windows.Forms.Panel();
            this.chkDomicilioCliente = new System.Windows.Forms.CheckBox();
            this.lbl_comentariosDatosEntrega = new System.Windows.Forms.TextBox();
            this.btn_datosEntrega = new System.Windows.Forms.Button();
            this.gbx_DatosEntrega = new System.Windows.Forms.GroupBox();
            this.gb_CamposEntrega = new System.Windows.Forms.GroupBox();
            this.txt_NumI = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_numE = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_TelefonoLinea = new System.Windows.Forms.TextBox();
            this.txt_Correo_Linea = new System.Windows.Forms.TextBox();
            this.txt_Nombre_Linea = new System.Windows.Forms.TextBox();
            this.txt_IdCommerceL = new System.Windows.Forms.TextBox();
            this.lbl_correoLinea = new System.Windows.Forms.Label();
            this.txt_NombreLinea = new System.Windows.Forms.Label();
            this.lbl_TelefonoLinea = new System.Windows.Forms.Label();
            this.txt_IdEcommerce = new System.Windows.Forms.Label();
            this.cb_colonia = new System.Windows.Forms.ComboBox();
            this.txt_MovilEntrega = new System.Windows.Forms.TextBox();
            this.txt_TelParticularEntrega = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_EntreCallesEntrega = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.lbl_poblacion = new System.Windows.Forms.Label();
            this.lbl_colonia = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_EstadoEntrega = new System.Windows.Forms.TextBox();
            this.txt_PoblacionEntrega = new System.Windows.Forms.TextBox();
            this.txt_CPEntrega = new System.Windows.Forms.TextBox();
            this.txt_ReferenciaEntrega = new System.Windows.Forms.TextBox();
            this.txt_direccionEntrega = new System.Windows.Forms.TextBox();
            this.btn_nuevaEntrega = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.dgv_datosEntrega = new System.Windows.Forms.DataGridView();
            this.btn_Anticipo = new System.Windows.Forms.Button();
            this.gb_anticipos = new System.Windows.Forms.GroupBox();
            this.lbl_cambio = new System.Windows.Forms.Label();
            this.lbl_rec_ceros = new System.Windows.Forms.Label();
            this.Tb_efectivoRecibido = new System.Windows.Forms.TextBox();
            this.lbl_recibido = new System.Windows.Forms.Label();
            this.btn_guardarAnticipos = new System.Windows.Forms.Button();
            this.lbl_importeTotal = new System.Windows.Forms.Label();
            this.flp_FormaPago = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_agregarFormaPago = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.txt_anticipototal = new System.Windows.Forms.TextBox();
            this.lbl_paginaActual = new System.Windows.Forms.Label();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_mov = new System.Windows.Forms.Label();
            this.lbl_movID = new System.Windows.Forms.Label();
            this.lbl_estatus = new System.Windows.Forms.Label();
            this.panelmenu = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Imprimir = new System.Windows.Forms.Button();
            this.btn_Situaciones = new System.Windows.Forms.Button();
            this.btn_Afectar = new System.Windows.Forms.Button();
            this.btn_Eliminar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_InfoArt = new System.Windows.Forms.Button();
            this.btn_Eventos = new System.Windows.Forms.Button();
            this.btn_HojaV = new System.Windows.Forms.Button();
            this.btn_SHM = new System.Windows.Forms.Button();
            this.btnEmbarcar = new System.Windows.Forms.Button();
            this.btn_AdjuntarSHM = new System.Windows.Forms.Button();
            this.btnDocumentos = new System.Windows.Forms.Button();
            this.btn_Ayuda = new System.Windows.Forms.Button();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.flpanel_labels = new System.Windows.Forms.FlowLayoutPanel();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.chx_Die = new System.Windows.Forms.CheckBox();
            this.btn_detallePosterior = new System.Windows.Forms.Button();
            this.btn_detalleAnterior = new System.Windows.Forms.Button();
            this.chkTransferencia = new System.Windows.Forms.CheckBox();
            this.btnCartaFactura = new System.Windows.Forms.Button();
            this.cms_copiar.SuspendLayout();
            this.flpanel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pan_correo.SuspendLayout();
            this.pan_refConcepto.SuspendLayout();
            this.pan_formaPago.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flp_articulos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_detalle)).BeginInit();
            this.pan_Vales.SuspendLayout();
            this.pnlBtn_DatosEntrega.SuspendLayout();
            this.gbx_DatosEntrega.SuspendLayout();
            this.gb_CamposEntrega.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datosEntrega)).BeginInit();
            this.gb_anticipos.SuspendLayout();
            this.panelmenu.SuspendLayout();
            this.flpanel_labels.SuspendLayout();
            this.SuspendLayout();
            // 
            // cms_copiar
            // 
            this.cms_copiar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem,
            this.UsrIncremento,
            this.UsrDescuento});
            this.cms_copiar.Name = "cms_copiar";
            this.cms_copiar.Size = new System.Drawing.Size(179, 70);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.CopiarToolStripMenuItem_Click);
            // 
            // UsrIncremento
            // 
            this.UsrIncremento.Name = "UsrIncremento";
            this.UsrIncremento.Size = new System.Drawing.Size(178, 22);
            this.UsrIncremento.Text = "Usuario Incremento";
            this.UsrIncremento.Click += new System.EventHandler(this.UsrIncremento_Click);
            // 
            // UsrDescuento
            // 
            this.UsrDescuento.Name = "UsrDescuento";
            this.UsrDescuento.Size = new System.Drawing.Size(178, 22);
            this.UsrDescuento.Text = "Usuario Descuento";
            this.UsrDescuento.Click += new System.EventHandler(this.UsrDescuento_Click);
            // 
            // flpanel
            // 
            this.flpanel.AutoScroll = true;
            this.flpanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flpanel.Controls.Add(this.lbl_Cliente);
            this.flpanel.Controls.Add(this.txt_Cliente);
            this.flpanel.Controls.Add(this.txt_Cliente1);
            this.flpanel.Controls.Add(this.lbl_TipoVenta);
            this.flpanel.Controls.Add(this.txt_TipoVenta);
            this.flpanel.Controls.Add(this.panel6);
            this.flpanel.Controls.Add(this.panel4);
            this.flpanel.Controls.Add(this.lbl_Condiciones);
            this.flpanel.Controls.Add(this.txt_Condiciones);
            this.flpanel.Controls.Add(this.lbl_Almacen);
            this.flpanel.Controls.Add(this.cb_Almacen);
            this.flpanel.Controls.Add(this.pan_correo);
            this.flpanel.Controls.Add(this.pan_refConcepto);
            this.flpanel.Controls.Add(this.lbl_Ecommerce);
            this.flpanel.Controls.Add(this.txt_Commerce);
            this.flpanel.Controls.Add(this.pan_formaPago);
            this.flpanel.Controls.Add(this.panel2);
            this.flpanel.Controls.Add(this.chk_Mayoreo);
            this.flpanel.Controls.Add(this.chk_Custodia);
            this.flpanel.Controls.Add(this.chk_Iva);
            this.flpanel.Controls.Add(this.chk_Comentario);
            this.flpanel.Controls.Add(this.lbl_AgenteServicio);
            this.flpanel.Controls.Add(this.txt_AgenteServicio);
            this.flpanel.Controls.Add(this.lbl_FormaEnvio);
            this.flpanel.Controls.Add(this.txt_FormaEnvio);
            this.flpanel.Controls.Add(this.lbl_CtaPago);
            this.flpanel.Controls.Add(this.txt_CtaPago);
            this.flpanel.Controls.Add(this.cb_ServicioReporte);
            this.flpanel.Controls.Add(this.lbl_nomina);
            this.flpanel.Controls.Add(this.tb_nomina);
            this.flpanel.Controls.Add(this.panel1);
            this.flpanel.Controls.Add(this.flowLayoutPanel1);
            this.flpanel.Controls.Add(this.flp_articulos);
            this.flpanel.Controls.Add(this.pan_Vales);
            this.flpanel.Controls.Add(this.pnlBtn_DatosEntrega);
            this.flpanel.Controls.Add(this.gbx_DatosEntrega);
            this.flpanel.Controls.Add(this.btn_Anticipo);
            this.flpanel.Controls.Add(this.gb_anticipos);
            this.flpanel.Location = new System.Drawing.Point(135, 74);
            this.flpanel.Margin = new System.Windows.Forms.Padding(10);
            this.flpanel.Name = "flpanel";
            this.flpanel.Size = new System.Drawing.Size(931, 1315);
            this.flpanel.TabIndex = 84;
            this.toolTip1.SetToolTip(this.flpanel, "DETALLE DE LA VENTA, INFORMACION IMPORTANTE DEL CLIENTE");
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(7, 5);
            this.lbl_Cliente.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Cliente.Size = new System.Drawing.Size(104, 22);
            this.lbl_Cliente.TabIndex = 14;
            this.lbl_Cliente.Text = "Cliente";
            // 
            // txt_Cliente
            // 
            this.txt_Cliente.BackColor = System.Drawing.Color.Snow;
            this.txt_Cliente.Enabled = false;
            this.txt_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cliente.Location = new System.Drawing.Point(125, 5);
            this.txt_Cliente.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Cliente.Name = "txt_Cliente";
            this.txt_Cliente.Size = new System.Drawing.Size(101, 22);
            this.txt_Cliente.TabIndex = 1;
            // 
            // txt_Cliente1
            // 
            this.txt_Cliente1.BackColor = System.Drawing.Color.Snow;
            this.txt_Cliente1.Enabled = false;
            this.txt_Cliente1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cliente1.Location = new System.Drawing.Point(240, 5);
            this.txt_Cliente1.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Cliente1.Name = "txt_Cliente1";
            this.txt_Cliente1.Size = new System.Drawing.Size(310, 22);
            this.txt_Cliente1.TabIndex = 2;
            // 
            // lbl_TipoVenta
            // 
            this.lbl_TipoVenta.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_TipoVenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TipoVenta.Location = new System.Drawing.Point(564, 5);
            this.lbl_TipoVenta.Margin = new System.Windows.Forms.Padding(7, 5, 3, 5);
            this.lbl_TipoVenta.Name = "lbl_TipoVenta";
            this.lbl_TipoVenta.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_TipoVenta.Size = new System.Drawing.Size(70, 22);
            this.lbl_TipoVenta.TabIndex = 68;
            this.lbl_TipoVenta.Text = "TipoVenta";
            // 
            // txt_TipoVenta
            // 
            this.txt_TipoVenta.BackColor = System.Drawing.Color.Snow;
            this.txt_TipoVenta.Enabled = false;
            this.txt_TipoVenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TipoVenta.Location = new System.Drawing.Point(642, 5);
            this.txt_TipoVenta.Margin = new System.Windows.Forms.Padding(5, 5, 3, 5);
            this.txt_TipoVenta.Name = "txt_TipoVenta";
            this.txt_TipoVenta.Size = new System.Drawing.Size(190, 22);
            this.txt_TipoVenta.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lbl_Agente);
            this.panel6.Controls.Add(this.txt_Agente);
            this.panel6.Location = new System.Drawing.Point(3, 35);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(233, 26);
            this.panel6.TabIndex = 89;
            // 
            // lbl_Agente
            // 
            this.lbl_Agente.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Agente.Location = new System.Drawing.Point(3, 3);
            this.lbl_Agente.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Agente.Name = "lbl_Agente";
            this.lbl_Agente.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Agente.Size = new System.Drawing.Size(59, 22);
            this.lbl_Agente.TabIndex = 19;
            this.lbl_Agente.Text = "Agente";
            // 
            // txt_Agente
            // 
            this.txt_Agente.BackColor = System.Drawing.Color.Snow;
            this.txt_Agente.Enabled = false;
            this.txt_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Agente.Location = new System.Drawing.Point(122, 2);
            this.txt_Agente.Margin = new System.Windows.Forms.Padding(5, 5, 3, 5);
            this.txt_Agente.Name = "txt_Agente";
            this.txt_Agente.Size = new System.Drawing.Size(103, 22);
            this.txt_Agente.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txt_Canal);
            this.panel4.Controls.Add(this.lbl_Canal);
            this.panel4.Controls.Add(this.txt_Canal1);
            this.panel4.Location = new System.Drawing.Point(242, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(624, 26);
            this.panel4.TabIndex = 87;
            // 
            // txt_Canal
            // 
            this.txt_Canal.BackColor = System.Drawing.Color.Snow;
            this.txt_Canal.Enabled = false;
            this.txt_Canal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Canal.Location = new System.Drawing.Point(179, 2);
            this.txt_Canal.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Canal.Name = "txt_Canal";
            this.txt_Canal.Size = new System.Drawing.Size(129, 22);
            this.txt_Canal.TabIndex = 5;
            // 
            // lbl_Canal
            // 
            this.lbl_Canal.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Canal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Canal.Location = new System.Drawing.Point(85, 2);
            this.lbl_Canal.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Canal.Name = "lbl_Canal";
            this.lbl_Canal.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Canal.Size = new System.Drawing.Size(80, 22);
            this.lbl_Canal.TabIndex = 12;
            this.lbl_Canal.Text = "Canal";
            // 
            // txt_Canal1
            // 
            this.txt_Canal1.BackColor = System.Drawing.Color.Snow;
            this.txt_Canal1.Enabled = false;
            this.txt_Canal1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Canal1.Location = new System.Drawing.Point(400, 2);
            this.txt_Canal1.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Canal1.Name = "txt_Canal1";
            this.txt_Canal1.Size = new System.Drawing.Size(190, 22);
            this.txt_Canal1.TabIndex = 6;
            // 
            // lbl_Condiciones
            // 
            this.lbl_Condiciones.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Condiciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Condiciones.Location = new System.Drawing.Point(7, 69);
            this.lbl_Condiciones.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Condiciones.Name = "lbl_Condiciones";
            this.lbl_Condiciones.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Condiciones.Size = new System.Drawing.Size(104, 22);
            this.lbl_Condiciones.TabIndex = 9;
            this.lbl_Condiciones.Text = "Condicion";
            // 
            // txt_Condiciones
            // 
            this.txt_Condiciones.BackColor = System.Drawing.Color.Snow;
            this.txt_Condiciones.Enabled = false;
            this.txt_Condiciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Condiciones.Location = new System.Drawing.Point(125, 69);
            this.txt_Condiciones.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Condiciones.Name = "txt_Condiciones";
            this.txt_Condiciones.Size = new System.Drawing.Size(188, 22);
            this.txt_Condiciones.TabIndex = 7;
            // 
            // lbl_Almacen
            // 
            this.lbl_Almacen.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Almacen.Location = new System.Drawing.Point(327, 69);
            this.lbl_Almacen.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Almacen.Name = "lbl_Almacen";
            this.lbl_Almacen.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Almacen.Size = new System.Drawing.Size(84, 22);
            this.lbl_Almacen.TabIndex = 18;
            this.lbl_Almacen.Text = "Almacen";
            // 
            // cb_Almacen
            // 
            this.cb_Almacen.Cursor = System.Windows.Forms.Cursors.Default;
            this.cb_Almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Almacen.FormattingEnabled = true;
            this.cb_Almacen.Location = new System.Drawing.Point(421, 67);
            this.cb_Almacen.MaxLength = 10;
            this.cb_Almacen.Name = "cb_Almacen";
            this.cb_Almacen.Size = new System.Drawing.Size(129, 23);
            this.cb_Almacen.TabIndex = 82;
            this.cb_Almacen.Click += new System.EventHandler(this.Txt_Almacen_Click);
            this.cb_Almacen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cb_Almacen_KeyPress);
            this.cb_Almacen.Leave += new System.EventHandler(this.cb_Almacen_Leave);
            // 
            // pan_correo
            // 
            this.pan_correo.Controls.Add(this.lbl_Correo);
            this.pan_correo.Controls.Add(this.txt_Correo);
            this.pan_correo.Location = new System.Drawing.Point(556, 67);
            this.pan_correo.Name = "pan_correo";
            this.pan_correo.Size = new System.Drawing.Size(310, 26);
            this.pan_correo.TabIndex = 86;
            // 
            // lbl_Correo
            // 
            this.lbl_Correo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Correo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Correo.Location = new System.Drawing.Point(5, 2);
            this.lbl_Correo.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Correo.Name = "lbl_Correo";
            this.lbl_Correo.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Correo.Size = new System.Drawing.Size(68, 22);
            this.lbl_Correo.TabIndex = 62;
            this.lbl_Correo.Text = "Correo";
            // 
            // txt_Correo
            // 
            this.txt_Correo.BackColor = System.Drawing.Color.Snow;
            this.txt_Correo.Enabled = false;
            this.txt_Correo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Correo.Location = new System.Drawing.Point(86, 1);
            this.txt_Correo.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Correo.Name = "txt_Correo";
            this.txt_Correo.Size = new System.Drawing.Size(190, 22);
            this.txt_Correo.TabIndex = 9;
            // 
            // pan_refConcepto
            // 
            this.pan_refConcepto.Controls.Add(this.txt_Referencia);
            this.pan_refConcepto.Controls.Add(this.txt_Concepto);
            this.pan_refConcepto.Controls.Add(this.lbl_Concepto);
            this.pan_refConcepto.Controls.Add(this.lbl_Referencia);
            this.pan_refConcepto.Location = new System.Drawing.Point(3, 99);
            this.pan_refConcepto.Name = "pan_refConcepto";
            this.pan_refConcepto.Size = new System.Drawing.Size(863, 26);
            this.pan_refConcepto.TabIndex = 71;
            // 
            // txt_Referencia
            // 
            this.txt_Referencia.BackColor = System.Drawing.Color.Snow;
            this.txt_Referencia.Enabled = false;
            this.txt_Referencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Referencia.Location = new System.Drawing.Point(120, 1);
            this.txt_Referencia.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Referencia.Name = "txt_Referencia";
            this.txt_Referencia.Size = new System.Drawing.Size(190, 22);
            this.txt_Referencia.TabIndex = 11;
            // 
            // txt_Concepto
            // 
            this.txt_Concepto.BackColor = System.Drawing.Color.Snow;
            this.txt_Concepto.Enabled = false;
            this.txt_Concepto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Concepto.Location = new System.Drawing.Point(418, 1);
            this.txt_Concepto.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Concepto.Name = "txt_Concepto";
            this.txt_Concepto.Size = new System.Drawing.Size(209, 22);
            this.txt_Concepto.TabIndex = 10;
            // 
            // lbl_Concepto
            // 
            this.lbl_Concepto.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Concepto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Concepto.Location = new System.Drawing.Point(324, 4);
            this.lbl_Concepto.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Concepto.Name = "lbl_Concepto";
            this.lbl_Concepto.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Concepto.Size = new System.Drawing.Size(70, 20);
            this.lbl_Concepto.TabIndex = 13;
            this.lbl_Concepto.Text = "Concepto";
            // 
            // lbl_Referencia
            // 
            this.lbl_Referencia.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Referencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Referencia.Location = new System.Drawing.Point(8, 3);
            this.lbl_Referencia.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Referencia.Name = "lbl_Referencia";
            this.lbl_Referencia.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Referencia.Size = new System.Drawing.Size(84, 22);
            this.lbl_Referencia.TabIndex = 15;
            this.lbl_Referencia.Text = "Referencia";
            // 
            // lbl_Ecommerce
            // 
            this.lbl_Ecommerce.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Ecommerce.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ecommerce.Location = new System.Drawing.Point(7, 133);
            this.lbl_Ecommerce.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Ecommerce.Name = "lbl_Ecommerce";
            this.lbl_Ecommerce.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Ecommerce.Size = new System.Drawing.Size(104, 22);
            this.lbl_Ecommerce.TabIndex = 11;
            this.lbl_Ecommerce.Text = "Ped. Ecommerce";
            // 
            // txt_Commerce
            // 
            this.txt_Commerce.BackColor = System.Drawing.Color.Snow;
            this.txt_Commerce.Enabled = false;
            this.txt_Commerce.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Commerce.Location = new System.Drawing.Point(125, 133);
            this.txt_Commerce.Margin = new System.Windows.Forms.Padding(7, 5, 3, 5);
            this.txt_Commerce.Name = "txt_Commerce";
            this.txt_Commerce.Size = new System.Drawing.Size(188, 22);
            this.txt_Commerce.TabIndex = 12;
            // 
            // pan_formaPago
            // 
            this.pan_formaPago.Controls.Add(this.txt_FormaCo);
            this.pan_formaPago.Controls.Add(this.label1);
            this.pan_formaPago.Controls.Add(this.lbl_FormaPago);
            this.pan_formaPago.Controls.Add(this.txt_FormaPago);
            this.pan_formaPago.Location = new System.Drawing.Point(319, 131);
            this.pan_formaPago.Name = "pan_formaPago";
            this.pan_formaPago.Size = new System.Drawing.Size(547, 26);
            this.pan_formaPago.TabIndex = 88;
            // 
            // txt_FormaCo
            // 
            this.txt_FormaCo.BackColor = System.Drawing.Color.White;
            this.txt_FormaCo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaCo.FormattingEnabled = true;
            this.txt_FormaCo.Location = new System.Drawing.Point(327, 1);
            this.txt_FormaCo.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.txt_FormaCo.Name = "txt_FormaCo";
            this.txt_FormaCo.Size = new System.Drawing.Size(186, 21);
            this.txt_FormaCo.TabIndex = 22;
            this.txt_FormaCo.SelectedIndexChanged += new System.EventHandler(this.txt_FormaCo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(245, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(3);
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Forma Cobro";
            // 
            // lbl_FormaPago
            // 
            this.lbl_FormaPago.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_FormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FormaPago.Location = new System.Drawing.Point(8, 2);
            this.lbl_FormaPago.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_FormaPago.Name = "lbl_FormaPago";
            this.lbl_FormaPago.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_FormaPago.Size = new System.Drawing.Size(84, 22);
            this.lbl_FormaPago.TabIndex = 16;
            this.lbl_FormaPago.Text = "Forma Pago";
            // 
            // txt_FormaPago
            // 
            this.txt_FormaPago.BackColor = System.Drawing.Color.Snow;
            this.txt_FormaPago.Enabled = false;
            this.txt_FormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaPago.Location = new System.Drawing.Point(102, 2);
            this.txt_FormaPago.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_FormaPago.Name = "txt_FormaPago";
            this.txt_FormaPago.Size = new System.Drawing.Size(129, 22);
            this.txt_FormaPago.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblCuentaClabe);
            this.panel2.Controls.Add(this.txtCuentaClabe);
            this.panel2.Controls.Add(this.lblBanco);
            this.panel2.Controls.Add(this.txtBanco);
            this.panel2.Controls.Add(this.txt_CodigoRecomendado);
            this.panel2.Controls.Add(this.lbl_CodigoRecomendado);
            this.panel2.Controls.Add(this.txt_Enganche);
            this.panel2.Controls.Add(this.lbl_Enganche);
            this.panel2.Controls.Add(this.txt_EmbarqueFecha);
            this.panel2.Controls.Add(this.txt_Embarque);
            this.panel2.Controls.Add(this.lbl_Embarque);
            this.panel2.Controls.Add(this.txt_Monedero);
            this.panel2.Controls.Add(this.lbl_RedMonedero);
            this.panel2.Location = new System.Drawing.Point(3, 163);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(863, 62);
            this.panel2.TabIndex = 72;
            // 
            // lblCuentaClabe
            // 
            this.lblCuentaClabe.AutoSize = true;
            this.lblCuentaClabe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuentaClabe.Location = new System.Drawing.Point(539, 34);
            this.lblCuentaClabe.Name = "lblCuentaClabe";
            this.lblCuentaClabe.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblCuentaClabe.Size = new System.Drawing.Size(80, 21);
            this.lblCuentaClabe.TabIndex = 92;
            this.lblCuentaClabe.Text = "Cuenta Clabe";
            this.lblCuentaClabe.Visible = false;
            // 
            // txtCuentaClabe
            // 
            this.txtCuentaClabe.BackColor = System.Drawing.Color.White;
            this.txtCuentaClabe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCuentaClabe.Enabled = false;
            this.txtCuentaClabe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaClabe.Location = new System.Drawing.Point(625, 37);
            this.txtCuentaClabe.Margin = new System.Windows.Forms.Padding(3, 2, 0, 3);
            this.txtCuentaClabe.MaxLength = 20;
            this.txtCuentaClabe.Name = "txtCuentaClabe";
            this.txtCuentaClabe.Size = new System.Drawing.Size(204, 22);
            this.txtCuentaClabe.TabIndex = 91;
            this.txtCuentaClabe.Visible = false;
            // 
            // lblBanco
            // 
            this.lblBanco.AutoSize = true;
            this.lblBanco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanco.Location = new System.Drawing.Point(374, 32);
            this.lblBanco.Name = "lblBanco";
            this.lblBanco.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblBanco.Size = new System.Drawing.Size(41, 21);
            this.lblBanco.TabIndex = 90;
            this.lblBanco.Text = "Banco";
            this.lblBanco.Visible = false;
            // 
            // txtBanco
            // 
            this.txtBanco.BackColor = System.Drawing.Color.White;
            this.txtBanco.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBanco.Enabled = false;
            this.txtBanco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBanco.Location = new System.Drawing.Point(421, 33);
            this.txtBanco.Margin = new System.Windows.Forms.Padding(3, 2, 0, 3);
            this.txtBanco.MaxLength = 7;
            this.txtBanco.Name = "txtBanco";
            this.txtBanco.Size = new System.Drawing.Size(110, 22);
            this.txtBanco.TabIndex = 89;
            this.txtBanco.Visible = false;
            // 
            // txt_CodigoRecomendado
            // 
            this.txt_CodigoRecomendado.BackColor = System.Drawing.Color.Snow;
            this.txt_CodigoRecomendado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodigoRecomendado.Location = new System.Drawing.Point(651, 7);
            this.txt_CodigoRecomendado.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_CodigoRecomendado.Name = "txt_CodigoRecomendado";
            this.txt_CodigoRecomendado.ReadOnly = true;
            this.txt_CodigoRecomendado.Size = new System.Drawing.Size(114, 22);
            this.txt_CodigoRecomendado.TabIndex = 36;
            this.txt_CodigoRecomendado.Visible = false;
            // 
            // lbl_CodigoRecomendado
            // 
            this.lbl_CodigoRecomendado.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_CodigoRecomendado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodigoRecomendado.Location = new System.Drawing.Point(510, 7);
            this.lbl_CodigoRecomendado.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_CodigoRecomendado.Name = "lbl_CodigoRecomendado";
            this.lbl_CodigoRecomendado.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_CodigoRecomendado.Size = new System.Drawing.Size(135, 22);
            this.lbl_CodigoRecomendado.TabIndex = 37;
            this.lbl_CodigoRecomendado.Text = "Código Recomendado";
            this.lbl_CodigoRecomendado.Visible = false;
            // 
            // txt_Enganche
            // 
            this.txt_Enganche.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Enganche.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txt_Enganche.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Enganche.FormattingEnabled = true;
            this.txt_Enganche.Location = new System.Drawing.Point(122, 3);
            this.txt_Enganche.Name = "txt_Enganche";
            this.txt_Enganche.Size = new System.Drawing.Size(111, 23);
            this.txt_Enganche.TabIndex = 33;
            this.txt_Enganche.Click += new System.EventHandler(this.Txt_Enganche_Click);
            // 
            // lbl_Enganche
            // 
            this.lbl_Enganche.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Enganche.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Enganche.Location = new System.Drawing.Point(2, 7);
            this.lbl_Enganche.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Enganche.Name = "lbl_Enganche";
            this.lbl_Enganche.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Enganche.Size = new System.Drawing.Size(116, 22);
            this.lbl_Enganche.TabIndex = 10;
            this.lbl_Enganche.Text = "Enganche";
            // 
            // txt_EmbarqueFecha
            // 
            this.txt_EmbarqueFecha.BackColor = System.Drawing.Color.Snow;
            this.txt_EmbarqueFecha.Enabled = false;
            this.txt_EmbarqueFecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmbarqueFecha.Location = new System.Drawing.Point(248, 34);
            this.txt_EmbarqueFecha.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_EmbarqueFecha.Name = "txt_EmbarqueFecha";
            this.txt_EmbarqueFecha.Size = new System.Drawing.Size(121, 22);
            this.txt_EmbarqueFecha.TabIndex = 17;
            // 
            // txt_Embarque
            // 
            this.txt_Embarque.BackColor = System.Drawing.Color.Snow;
            this.txt_Embarque.Enabled = false;
            this.txt_Embarque.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Embarque.Location = new System.Drawing.Point(122, 34);
            this.txt_Embarque.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Embarque.Name = "txt_Embarque";
            this.txt_Embarque.Size = new System.Drawing.Size(114, 22);
            this.txt_Embarque.TabIndex = 16;
            // 
            // lbl_Embarque
            // 
            this.lbl_Embarque.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Embarque.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Embarque.Location = new System.Drawing.Point(4, 35);
            this.lbl_Embarque.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_Embarque.Name = "lbl_Embarque";
            this.lbl_Embarque.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_Embarque.Size = new System.Drawing.Size(70, 22);
            this.lbl_Embarque.TabIndex = 32;
            this.lbl_Embarque.Text = "Embarque";
            // 
            // txt_Monedero
            // 
            this.txt_Monedero.BackColor = System.Drawing.Color.Snow;
            this.txt_Monedero.Enabled = false;
            this.txt_Monedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Monedero.Location = new System.Drawing.Point(396, 4);
            this.txt_Monedero.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.txt_Monedero.Name = "txt_Monedero";
            this.txt_Monedero.Size = new System.Drawing.Size(100, 22);
            this.txt_Monedero.TabIndex = 15;
            // 
            // lbl_RedMonedero
            // 
            this.lbl_RedMonedero.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_RedMonedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RedMonedero.Location = new System.Drawing.Point(258, 7);
            this.lbl_RedMonedero.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lbl_RedMonedero.Name = "lbl_RedMonedero";
            this.lbl_RedMonedero.Padding = new System.Windows.Forms.Padding(3);
            this.lbl_RedMonedero.Size = new System.Drawing.Size(136, 22);
            this.lbl_RedMonedero.TabIndex = 17;
            this.lbl_RedMonedero.Text = "Monedero por redimir";
            // 
            // chk_Mayoreo
            // 
            this.chk_Mayoreo.AutoSize = true;
            this.chk_Mayoreo.Enabled = false;
            this.chk_Mayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Mayoreo.Location = new System.Drawing.Point(10, 238);
            this.chk_Mayoreo.Margin = new System.Windows.Forms.Padding(10);
            this.chk_Mayoreo.Name = "chk_Mayoreo";
            this.chk_Mayoreo.Size = new System.Drawing.Size(101, 19);
            this.chk_Mayoreo.TabIndex = 18;
            this.chk_Mayoreo.Text = "Com Mayoreo";
            this.chk_Mayoreo.UseVisualStyleBackColor = true;
            // 
            // chk_Custodia
            // 
            this.chk_Custodia.AutoSize = true;
            this.chk_Custodia.Enabled = false;
            this.chk_Custodia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Custodia.Location = new System.Drawing.Point(131, 238);
            this.chk_Custodia.Margin = new System.Windows.Forms.Padding(10);
            this.chk_Custodia.Name = "chk_Custodia";
            this.chk_Custodia.Size = new System.Drawing.Size(74, 19);
            this.chk_Custodia.TabIndex = 19;
            this.chk_Custodia.Text = "Custodia";
            this.chk_Custodia.UseVisualStyleBackColor = true;
            // 
            // chk_Iva
            // 
            this.chk_Iva.AutoSize = true;
            this.chk_Iva.Enabled = false;
            this.chk_Iva.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Iva.Location = new System.Drawing.Point(225, 238);
            this.chk_Iva.Margin = new System.Windows.Forms.Padding(10);
            this.chk_Iva.Name = "chk_Iva";
            this.chk_Iva.Size = new System.Drawing.Size(100, 19);
            this.chk_Iva.TabIndex = 20;
            this.chk_Iva.Text = "Desglosar Iva";
            this.chk_Iva.UseVisualStyleBackColor = true;
            // 
            // chk_Comentario
            // 
            this.chk_Comentario.AutoSize = true;
            this.chk_Comentario.Enabled = false;
            this.chk_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Comentario.Location = new System.Drawing.Point(345, 238);
            this.chk_Comentario.Margin = new System.Windows.Forms.Padding(10);
            this.chk_Comentario.Name = "chk_Comentario";
            this.chk_Comentario.Padding = new System.Windows.Forms.Padding(0, 0, 280, 0);
            this.chk_Comentario.Size = new System.Drawing.Size(423, 19);
            this.chk_Comentario.TabIndex = 21;
            this.chk_Comentario.Text = "Imprimir Comentario";
            this.chk_Comentario.UseVisualStyleBackColor = true;
            // 
            // lbl_AgenteServicio
            // 
            this.lbl_AgenteServicio.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_AgenteServicio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AgenteServicio.Location = new System.Drawing.Point(788, 237);
            this.lbl_AgenteServicio.Margin = new System.Windows.Forms.Padding(10, 6, 0, 6);
            this.lbl_AgenteServicio.Name = "lbl_AgenteServicio";
            this.lbl_AgenteServicio.Size = new System.Drawing.Size(113, 20);
            this.lbl_AgenteServicio.TabIndex = 41;
            this.lbl_AgenteServicio.Text = "Agente Telefonico";
            // 
            // txt_AgenteServicio
            // 
            this.txt_AgenteServicio.BackColor = System.Drawing.Color.Snow;
            this.txt_AgenteServicio.Enabled = false;
            this.txt_AgenteServicio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AgenteServicio.Location = new System.Drawing.Point(0, 273);
            this.txt_AgenteServicio.Margin = new System.Windows.Forms.Padding(0, 6, 10, 6);
            this.txt_AgenteServicio.Name = "txt_AgenteServicio";
            this.txt_AgenteServicio.Size = new System.Drawing.Size(124, 22);
            this.txt_AgenteServicio.TabIndex = 22;
            // 
            // lbl_FormaEnvio
            // 
            this.lbl_FormaEnvio.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_FormaEnvio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FormaEnvio.Location = new System.Drawing.Point(144, 274);
            this.lbl_FormaEnvio.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.lbl_FormaEnvio.Name = "lbl_FormaEnvio";
            this.lbl_FormaEnvio.Size = new System.Drawing.Size(90, 20);
            this.lbl_FormaEnvio.TabIndex = 43;
            this.lbl_FormaEnvio.Text = "Forma Envio";
            // 
            // txt_FormaEnvio
            // 
            this.txt_FormaEnvio.BackColor = System.Drawing.Color.Snow;
            this.txt_FormaEnvio.Enabled = false;
            this.txt_FormaEnvio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaEnvio.Location = new System.Drawing.Point(254, 273);
            this.txt_FormaEnvio.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txt_FormaEnvio.Name = "txt_FormaEnvio";
            this.txt_FormaEnvio.Size = new System.Drawing.Size(183, 22);
            this.txt_FormaEnvio.TabIndex = 23;
            // 
            // lbl_CtaPago
            // 
            this.lbl_CtaPago.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_CtaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CtaPago.Location = new System.Drawing.Point(457, 274);
            this.lbl_CtaPago.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.lbl_CtaPago.Name = "lbl_CtaPago";
            this.lbl_CtaPago.Size = new System.Drawing.Size(59, 20);
            this.lbl_CtaPago.TabIndex = 44;
            this.lbl_CtaPago.Text = "Cta Pago";
            // 
            // txt_CtaPago
            // 
            this.txt_CtaPago.BackColor = System.Drawing.Color.Snow;
            this.txt_CtaPago.Enabled = false;
            this.txt_CtaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CtaPago.Location = new System.Drawing.Point(536, 273);
            this.txt_CtaPago.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txt_CtaPago.Name = "txt_CtaPago";
            this.txt_CtaPago.Size = new System.Drawing.Size(145, 22);
            this.txt_CtaPago.TabIndex = 24;
            // 
            // cb_ServicioReporte
            // 
            this.cb_ServicioReporte.AutoSize = true;
            this.cb_ServicioReporte.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ServicioReporte.Location = new System.Drawing.Point(699, 270);
            this.cb_ServicioReporte.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.cb_ServicioReporte.Name = "cb_ServicioReporte";
            this.cb_ServicioReporte.Size = new System.Drawing.Size(156, 19);
            this.cb_ServicioReporte.TabIndex = 110;
            this.cb_ServicioReporte.Text = "Reporte Descuento ZZZ";
            this.cb_ServicioReporte.UseVisualStyleBackColor = true;
            this.cb_ServicioReporte.CheckedChanged += new System.EventHandler(this.Cb_ServicioReporte_CheckedChanged);
            // 
            // lbl_nomina
            // 
            this.lbl_nomina.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_nomina.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nomina.Location = new System.Drawing.Point(10, 308);
            this.lbl_nomina.Margin = new System.Windows.Forms.Padding(10, 6, 0, 6);
            this.lbl_nomina.Name = "lbl_nomina";
            this.lbl_nomina.Size = new System.Drawing.Size(113, 20);
            this.lbl_nomina.TabIndex = 112;
            this.lbl_nomina.Text = "Nomina";
            // 
            // tb_nomina
            // 
            this.tb_nomina.BackColor = System.Drawing.Color.Snow;
            this.tb_nomina.Enabled = false;
            this.tb_nomina.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_nomina.Location = new System.Drawing.Point(123, 307);
            this.tb_nomina.Margin = new System.Windows.Forms.Padding(0, 6, 10, 6);
            this.tb_nomina.Name = "tb_nomina";
            this.tb_nomina.Size = new System.Drawing.Size(124, 22);
            this.tb_nomina.TabIndex = 111;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnGuardarComentarios);
            this.panel1.Controls.Add(this.lbl_Observaciones);
            this.panel1.Controls.Add(this.txt_Observaciones);
            this.panel1.Controls.Add(this.lbl_Comentario);
            this.panel1.Controls.Add(this.txt_Comentario);
            this.panel1.Location = new System.Drawing.Point(3, 338);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(863, 58);
            this.panel1.TabIndex = 109;
            // 
            // btnGuardarComentarios
            // 
            this.btnGuardarComentarios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardarComentarios.FlatAppearance.BorderSize = 0;
            this.btnGuardarComentarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardarComentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarComentarios.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardarComentarios.Image")));
            this.btnGuardarComentarios.Location = new System.Drawing.Point(835, 30);
            this.btnGuardarComentarios.Name = "btnGuardarComentarios";
            this.btnGuardarComentarios.Size = new System.Drawing.Size(22, 20);
            this.btnGuardarComentarios.TabIndex = 46;
            this.btnGuardarComentarios.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.btnGuardarComentarios, "GUARDAR COMENTARIO");
            this.btnGuardarComentarios.UseVisualStyleBackColor = true;
            this.btnGuardarComentarios.Click += new System.EventHandler(this.btnGuardarComentarios_Click);
            // 
            // lbl_Observaciones
            // 
            this.lbl_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Observaciones.Location = new System.Drawing.Point(5, 6);
            this.lbl_Observaciones.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.lbl_Observaciones.Name = "lbl_Observaciones";
            this.lbl_Observaciones.Size = new System.Drawing.Size(90, 20);
            this.lbl_Observaciones.TabIndex = 42;
            this.lbl_Observaciones.Text = "Observaciones";
            // 
            // txt_Observaciones
            // 
            this.txt_Observaciones.BackColor = System.Drawing.Color.Snow;
            this.txt_Observaciones.Enabled = false;
            this.txt_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Observaciones.Location = new System.Drawing.Point(115, 6);
            this.txt_Observaciones.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txt_Observaciones.Multiline = true;
            this.txt_Observaciones.Name = "txt_Observaciones";
            this.txt_Observaciones.Size = new System.Drawing.Size(714, 20);
            this.txt_Observaciones.TabIndex = 25;
            // 
            // lbl_Comentario
            // 
            this.lbl_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comentario.Location = new System.Drawing.Point(5, 30);
            this.lbl_Comentario.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.lbl_Comentario.Name = "lbl_Comentario";
            this.lbl_Comentario.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lbl_Comentario.Size = new System.Drawing.Size(90, 20);
            this.lbl_Comentario.TabIndex = 45;
            this.lbl_Comentario.Text = "Comentarios";
            // 
            // txt_Comentario
            // 
            this.txt_Comentario.BackColor = System.Drawing.Color.Snow;
            this.txt_Comentario.Enabled = false;
            this.txt_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentario.Location = new System.Drawing.Point(115, 30);
            this.txt_Comentario.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txt_Comentario.Name = "txt_Comentario";
            this.txt_Comentario.Size = new System.Drawing.Size(714, 22);
            this.txt_Comentario.TabIndex = 26;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lbl_Descripcion);
            this.flowLayoutPanel1.Controls.Add(this.lbl_Unidad);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 409);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(829, 28);
            this.flowLayoutPanel1.TabIndex = 69;
            // 
            // lbl_Descripcion
            // 
            this.lbl_Descripcion.AutoSize = true;
            this.lbl_Descripcion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Descripcion.Location = new System.Drawing.Point(3, 3);
            this.lbl_Descripcion.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_Descripcion.Name = "lbl_Descripcion";
            this.lbl_Descripcion.Size = new System.Drawing.Size(77, 15);
            this.lbl_Descripcion.TabIndex = 64;
            this.lbl_Descripcion.Text = "Descripcion:";
            // 
            // lbl_Unidad
            // 
            this.lbl_Unidad.AutoSize = true;
            this.lbl_Unidad.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Unidad.Location = new System.Drawing.Point(86, 3);
            this.lbl_Unidad.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_Unidad.Name = "lbl_Unidad";
            this.lbl_Unidad.Size = new System.Drawing.Size(44, 15);
            this.lbl_Unidad.TabIndex = 65;
            this.lbl_Unidad.Text = "Unidad";
            // 
            // flp_articulos
            // 
            this.flp_articulos.AutoSize = true;
            this.flp_articulos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flp_articulos.Controls.Add(this.dgv_detalle);
            this.flp_articulos.Controls.Add(this.lbl_SubTotal);
            this.flp_articulos.Controls.Add(this.txt_SubTotal);
            this.flp_articulos.Controls.Add(this.lbl_Impuestos);
            this.flp_articulos.Controls.Add(this.txt_Impuestos);
            this.flp_articulos.Controls.Add(this.lbl_Total);
            this.flp_articulos.Controls.Add(this.txt_Total);
            this.flp_articulos.Controls.Add(this.lblMonedero);
            this.flp_articulos.Controls.Add(this.txtMonedero);
            this.flp_articulos.Location = new System.Drawing.Point(3, 443);
            this.flp_articulos.MaximumSize = new System.Drawing.Size(660, 0);
            this.flp_articulos.Name = "flp_articulos";
            this.flp_articulos.Size = new System.Drawing.Size(660, 213);
            this.flp_articulos.TabIndex = 5;
            // 
            // dgv_detalle
            // 
            this.dgv_detalle.AllowUserToAddRows = false;
            this.dgv_detalle.AllowUserToDeleteRows = false;
            this.dgv_detalle.AllowUserToResizeColumns = false;
            this.dgv_detalle.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_detalle.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_detalle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_detalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_detalle.BackgroundColor = System.Drawing.Color.White;
            this.dgv_detalle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_detalle.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgv_detalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_detalle.ContextMenuStrip = this.cms_copiar;
            this.dgv_detalle.EnableHeadersVisualStyles = false;
            this.dgv_detalle.Location = new System.Drawing.Point(10, 3);
            this.dgv_detalle.Margin = new System.Windows.Forms.Padding(10, 3, 300, 10);
            this.dgv_detalle.MultiSelect = false;
            this.dgv_detalle.Name = "dgv_detalle";
            this.dgv_detalle.RowHeadersVisible = false;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_detalle.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgv_detalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_detalle.Size = new System.Drawing.Size(645, 145);
            this.dgv_detalle.TabIndex = 36;
            this.dgv_detalle.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgv_detalle_CellBeginEdit);
            this.dgv_detalle.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_detalle_CellDoubleClick);
            this.dgv_detalle.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_detalle_CellEndEdit);
            this.dgv_detalle.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgv_detalle_CellValidating);
            this.dgv_detalle.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Dgv_detalle_ColumnHeaderMouseClick);
            this.dgv_detalle.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgv_detalle_EditingControlShowing);
            this.dgv_detalle.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_detalle_RowEnter);
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(3, 193);
            this.lbl_SubTotal.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(61, 15);
            this.lbl_SubTotal.TabIndex = 58;
            this.lbl_SubTotal.Text = "Sub Total ";
            // 
            // txt_SubTotal
            // 
            this.txt_SubTotal.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_SubTotal.BackColor = System.Drawing.Color.Snow;
            this.txt_SubTotal.Enabled = false;
            this.txt_SubTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SubTotal.Location = new System.Drawing.Point(70, 188);
            this.txt_SubTotal.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.txt_SubTotal.Name = "txt_SubTotal";
            this.txt_SubTotal.Size = new System.Drawing.Size(100, 22);
            this.txt_SubTotal.TabIndex = 37;
            // 
            // lbl_Impuestos
            // 
            this.lbl_Impuestos.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Impuestos.AutoSize = true;
            this.lbl_Impuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Impuestos.Location = new System.Drawing.Point(176, 193);
            this.lbl_Impuestos.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.lbl_Impuestos.Name = "lbl_Impuestos";
            this.lbl_Impuestos.Size = new System.Drawing.Size(65, 15);
            this.lbl_Impuestos.TabIndex = 57;
            this.lbl_Impuestos.Text = "Impuestos ";
            // 
            // txt_Impuestos
            // 
            this.txt_Impuestos.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_Impuestos.BackColor = System.Drawing.Color.Snow;
            this.txt_Impuestos.Enabled = false;
            this.txt_Impuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Impuestos.Location = new System.Drawing.Point(247, 188);
            this.txt_Impuestos.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.txt_Impuestos.Name = "txt_Impuestos";
            this.txt_Impuestos.Size = new System.Drawing.Size(100, 22);
            this.txt_Impuestos.TabIndex = 38;
            // 
            // lbl_Total
            // 
            this.lbl_Total.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(353, 193);
            this.lbl_Total.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(37, 15);
            this.lbl_Total.TabIndex = 56;
            this.lbl_Total.Text = "Total ";
            // 
            // txt_Total
            // 
            this.txt_Total.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_Total.BackColor = System.Drawing.Color.Snow;
            this.txt_Total.Enabled = false;
            this.txt_Total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Total.Location = new System.Drawing.Point(396, 188);
            this.txt_Total.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.Size = new System.Drawing.Size(94, 22);
            this.txt_Total.TabIndex = 39;
            // 
            // lblMonedero
            // 
            this.lblMonedero.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblMonedero.AutoSize = true;
            this.lblMonedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonedero.Location = new System.Drawing.Point(496, 193);
            this.lblMonedero.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.lblMonedero.Name = "lblMonedero";
            this.lblMonedero.Size = new System.Drawing.Size(61, 15);
            this.lblMonedero.TabIndex = 60;
            this.lblMonedero.Text = "Monedero";
            // 
            // txtMonedero
            // 
            this.txtMonedero.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMonedero.BackColor = System.Drawing.Color.Snow;
            this.txtMonedero.Enabled = false;
            this.txtMonedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonedero.Location = new System.Drawing.Point(563, 188);
            this.txtMonedero.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.txtMonedero.Name = "txtMonedero";
            this.txtMonedero.Size = new System.Drawing.Size(94, 22);
            this.txtMonedero.TabIndex = 59;
            // 
            // pan_Vales
            // 
            this.pan_Vales.Controls.Add(this.tx_panelvaleInfo);
            this.pan_Vales.Controls.Add(this.txt_vale);
            this.pan_Vales.Controls.Add(this.txt_NIP);
            this.pan_Vales.Controls.Add(this.lbl_ValeVenta);
            this.pan_Vales.Controls.Add(this.lbl_nip);
            this.pan_Vales.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_Vales.Location = new System.Drawing.Point(669, 443);
            this.pan_Vales.Name = "pan_Vales";
            this.pan_Vales.Size = new System.Drawing.Size(197, 148);
            this.pan_Vales.TabIndex = 85;
            this.pan_Vales.Visible = false;
            // 
            // tx_panelvaleInfo
            // 
            this.tx_panelvaleInfo.BackColor = System.Drawing.Color.White;
            this.tx_panelvaleInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tx_panelvaleInfo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_panelvaleInfo.ForeColor = System.Drawing.Color.Black;
            this.tx_panelvaleInfo.Location = new System.Drawing.Point(7, 10);
            this.tx_panelvaleInfo.Multiline = true;
            this.tx_panelvaleInfo.Name = "tx_panelvaleInfo";
            this.tx_panelvaleInfo.ReadOnly = true;
            this.tx_panelvaleInfo.Size = new System.Drawing.Size(175, 33);
            this.tx_panelvaleInfo.TabIndex = 4;
            this.tx_panelvaleInfo.Text = "Favor de llenar la información de vales";
            // 
            // txt_vale
            // 
            this.txt_vale.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vale.Location = new System.Drawing.Point(10, 118);
            this.txt_vale.MaxLength = 50;
            this.txt_vale.Name = "txt_vale";
            this.txt_vale.Size = new System.Drawing.Size(166, 22);
            this.txt_vale.TabIndex = 3;
            // 
            // txt_NIP
            // 
            this.txt_NIP.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NIP.Location = new System.Drawing.Point(12, 75);
            this.txt_NIP.MaxLength = 50;
            this.txt_NIP.Name = "txt_NIP";
            this.txt_NIP.Size = new System.Drawing.Size(164, 22);
            this.txt_NIP.TabIndex = 2;
            this.txt_NIP.UseSystemPasswordChar = true;
            // 
            // lbl_ValeVenta
            // 
            this.lbl_ValeVenta.AutoSize = true;
            this.lbl_ValeVenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ValeVenta.Location = new System.Drawing.Point(12, 100);
            this.lbl_ValeVenta.Name = "lbl_ValeVenta";
            this.lbl_ValeVenta.Size = new System.Drawing.Size(81, 15);
            this.lbl_ValeVenta.TabIndex = 1;
            this.lbl_ValeVenta.Text = "Vale de venta:";
            // 
            // lbl_nip
            // 
            this.lbl_nip.AutoSize = true;
            this.lbl_nip.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nip.Location = new System.Drawing.Point(12, 57);
            this.lbl_nip.Name = "lbl_nip";
            this.lbl_nip.Size = new System.Drawing.Size(78, 15);
            this.lbl_nip.TabIndex = 0;
            this.lbl_nip.Text = "Nip de venta:";
            // 
            // pnlBtn_DatosEntrega
            // 
            this.pnlBtn_DatosEntrega.Controls.Add(this.chkDomicilioCliente);
            this.pnlBtn_DatosEntrega.Controls.Add(this.lbl_comentariosDatosEntrega);
            this.pnlBtn_DatosEntrega.Controls.Add(this.btn_datosEntrega);
            this.pnlBtn_DatosEntrega.Location = new System.Drawing.Point(3, 689);
            this.pnlBtn_DatosEntrega.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.pnlBtn_DatosEntrega.Name = "pnlBtn_DatosEntrega";
            this.pnlBtn_DatosEntrega.Size = new System.Drawing.Size(852, 55);
            this.pnlBtn_DatosEntrega.TabIndex = 84;
            // 
            // chkDomicilioCliente
            // 
            this.chkDomicilioCliente.AutoSize = true;
            this.chkDomicilioCliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.chkDomicilioCliente.Location = new System.Drawing.Point(179, 21);
            this.chkDomicilioCliente.Name = "chkDomicilioCliente";
            this.chkDomicilioCliente.Size = new System.Drawing.Size(182, 19);
            this.chkDomicilioCliente.TabIndex = 121;
            this.chkDomicilioCliente.Text = "Domicilio Actual Del Cliente";
            this.chkDomicilioCliente.UseVisualStyleBackColor = true;
            this.chkDomicilioCliente.Visible = false;
            this.chkDomicilioCliente.CheckedChanged += new System.EventHandler(this.chkDomicilioCliente_CheckedChanged);
            // 
            // lbl_comentariosDatosEntrega
            // 
            this.lbl_comentariosDatosEntrega.BackColor = System.Drawing.Color.White;
            this.lbl_comentariosDatosEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_comentariosDatosEntrega.Enabled = false;
            this.lbl_comentariosDatosEntrega.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_comentariosDatosEntrega.Location = new System.Drawing.Point(161, 0);
            this.lbl_comentariosDatosEntrega.Multiline = true;
            this.lbl_comentariosDatosEntrega.Name = "lbl_comentariosDatosEntrega";
            this.lbl_comentariosDatosEntrega.Size = new System.Drawing.Size(681, 53);
            this.lbl_comentariosDatosEntrega.TabIndex = 120;
            // 
            // btn_datosEntrega
            // 
            this.btn_datosEntrega.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn_datosEntrega.BackColor = System.Drawing.Color.White;
            this.btn_datosEntrega.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_datosEntrega.FlatAppearance.BorderSize = 0;
            this.btn_datosEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_datosEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_datosEntrega.ForeColor = System.Drawing.Color.Black;
            this.btn_datosEntrega.Image = global::PuntoVenta.Properties.Resources.bloggif_59a1a7a26e5b9;
            this.btn_datosEntrega.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_datosEntrega.Location = new System.Drawing.Point(8, 9);
            this.btn_datosEntrega.Margin = new System.Windows.Forms.Padding(5, 20, 3, 3);
            this.btn_datosEntrega.Name = "btn_datosEntrega";
            this.btn_datosEntrega.Size = new System.Drawing.Size(147, 35);
            this.btn_datosEntrega.TabIndex = 40;
            this.btn_datosEntrega.Text = "Datos de Entrega";
            this.btn_datosEntrega.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_datosEntrega.UseVisualStyleBackColor = false;
            this.btn_datosEntrega.Click += new System.EventHandler(this.Btn_datosEntrega_Click);
            // 
            // gbx_DatosEntrega
            // 
            this.gbx_DatosEntrega.Controls.Add(this.gb_CamposEntrega);
            this.gbx_DatosEntrega.Controls.Add(this.btn_nuevaEntrega);
            this.gbx_DatosEntrega.Controls.Add(this.btn_guardar);
            this.gbx_DatosEntrega.Controls.Add(this.dgv_datosEntrega);
            this.gbx_DatosEntrega.Location = new System.Drawing.Point(3, 750);
            this.gbx_DatosEntrega.Name = "gbx_DatosEntrega";
            this.gbx_DatosEntrega.Size = new System.Drawing.Size(852, 359);
            this.gbx_DatosEntrega.TabIndex = 70;
            this.gbx_DatosEntrega.TabStop = false;
            this.gbx_DatosEntrega.Visible = false;
            // 
            // gb_CamposEntrega
            // 
            this.gb_CamposEntrega.Controls.Add(this.txt_NumI);
            this.gb_CamposEntrega.Controls.Add(this.label3);
            this.gb_CamposEntrega.Controls.Add(this.txt_numE);
            this.gb_CamposEntrega.Controls.Add(this.label2);
            this.gb_CamposEntrega.Controls.Add(this.txt_TelefonoLinea);
            this.gb_CamposEntrega.Controls.Add(this.txt_Correo_Linea);
            this.gb_CamposEntrega.Controls.Add(this.txt_Nombre_Linea);
            this.gb_CamposEntrega.Controls.Add(this.txt_IdCommerceL);
            this.gb_CamposEntrega.Controls.Add(this.lbl_correoLinea);
            this.gb_CamposEntrega.Controls.Add(this.txt_NombreLinea);
            this.gb_CamposEntrega.Controls.Add(this.lbl_TelefonoLinea);
            this.gb_CamposEntrega.Controls.Add(this.txt_IdEcommerce);
            this.gb_CamposEntrega.Controls.Add(this.cb_colonia);
            this.gb_CamposEntrega.Controls.Add(this.txt_MovilEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_TelParticularEntrega);
            this.gb_CamposEntrega.Controls.Add(this.label5);
            this.gb_CamposEntrega.Controls.Add(this.label4);
            this.gb_CamposEntrega.Controls.Add(this.txt_EntreCallesEntrega);
            this.gb_CamposEntrega.Controls.Add(this.label33);
            this.gb_CamposEntrega.Controls.Add(this.lbl_poblacion);
            this.gb_CamposEntrega.Controls.Add(this.lbl_colonia);
            this.gb_CamposEntrega.Controls.Add(this.label27);
            this.gb_CamposEntrega.Controls.Add(this.lbl_direccion);
            this.gb_CamposEntrega.Controls.Add(this.label25);
            this.gb_CamposEntrega.Controls.Add(this.label24);
            this.gb_CamposEntrega.Controls.Add(this.txt_EstadoEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_PoblacionEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_CPEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_ReferenciaEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_direccionEntrega);
            this.gb_CamposEntrega.Location = new System.Drawing.Point(7, 148);
            this.gb_CamposEntrega.Name = "gb_CamposEntrega";
            this.gb_CamposEntrega.Size = new System.Drawing.Size(835, 207);
            this.gb_CamposEntrega.TabIndex = 108;
            this.gb_CamposEntrega.TabStop = false;
            // 
            // txt_NumI
            // 
            this.txt_NumI.BackColor = System.Drawing.Color.White;
            this.txt_NumI.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumI.Location = new System.Drawing.Point(761, 9);
            this.txt_NumI.MaxLength = 5;
            this.txt_NumI.Name = "txt_NumI";
            this.txt_NumI.Size = new System.Drawing.Size(61, 22);
            this.txt_NumI.TabIndex = 145;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(710, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 15);
            this.label3.TabIndex = 144;
            this.label3.Text = "NumInt";
            // 
            // txt_numE
            // 
            this.txt_numE.BackColor = System.Drawing.Color.White;
            this.txt_numE.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numE.Location = new System.Drawing.Point(644, 9);
            this.txt_numE.MaxLength = 5;
            this.txt_numE.Name = "txt_numE";
            this.txt_numE.Size = new System.Drawing.Size(56, 22);
            this.txt_numE.TabIndex = 143;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(581, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 142;
            this.label2.Text = "*NumExt";
            // 
            // txt_TelefonoLinea
            // 
            this.txt_TelefonoLinea.BackColor = System.Drawing.Color.White;
            this.txt_TelefonoLinea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelefonoLinea.Location = new System.Drawing.Point(573, 168);
            this.txt_TelefonoLinea.MaxLength = 10;
            this.txt_TelefonoLinea.Name = "txt_TelefonoLinea";
            this.txt_TelefonoLinea.Size = new System.Drawing.Size(249, 22);
            this.txt_TelefonoLinea.TabIndex = 141;
            // 
            // txt_Correo_Linea
            // 
            this.txt_Correo_Linea.BackColor = System.Drawing.Color.White;
            this.txt_Correo_Linea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Correo_Linea.Location = new System.Drawing.Point(129, 168);
            this.txt_Correo_Linea.MaxLength = 10;
            this.txt_Correo_Linea.Name = "txt_Correo_Linea";
            this.txt_Correo_Linea.Size = new System.Drawing.Size(377, 22);
            this.txt_Correo_Linea.TabIndex = 140;
            // 
            // txt_Nombre_Linea
            // 
            this.txt_Nombre_Linea.BackColor = System.Drawing.Color.White;
            this.txt_Nombre_Linea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre_Linea.Location = new System.Drawing.Point(349, 142);
            this.txt_Nombre_Linea.MaxLength = 10;
            this.txt_Nombre_Linea.Name = "txt_Nombre_Linea";
            this.txt_Nombre_Linea.Size = new System.Drawing.Size(473, 22);
            this.txt_Nombre_Linea.TabIndex = 139;
            // 
            // txt_IdCommerceL
            // 
            this.txt_IdCommerceL.BackColor = System.Drawing.Color.White;
            this.txt_IdCommerceL.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IdCommerceL.Location = new System.Drawing.Point(129, 142);
            this.txt_IdCommerceL.MaxLength = 10;
            this.txt_IdCommerceL.Name = "txt_IdCommerceL";
            this.txt_IdCommerceL.Size = new System.Drawing.Size(145, 22);
            this.txt_IdCommerceL.TabIndex = 138;
            // 
            // lbl_correoLinea
            // 
            this.lbl_correoLinea.AutoSize = true;
            this.lbl_correoLinea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_correoLinea.Location = new System.Drawing.Point(24, 175);
            this.lbl_correoLinea.Name = "lbl_correoLinea";
            this.lbl_correoLinea.Size = new System.Drawing.Size(46, 15);
            this.lbl_correoLinea.TabIndex = 137;
            this.lbl_correoLinea.Text = "Correo";
            // 
            // txt_NombreLinea
            // 
            this.txt_NombreLinea.AutoSize = true;
            this.txt_NombreLinea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NombreLinea.Location = new System.Drawing.Point(293, 145);
            this.txt_NombreLinea.Name = "txt_NombreLinea";
            this.txt_NombreLinea.Size = new System.Drawing.Size(50, 15);
            this.txt_NombreLinea.TabIndex = 136;
            this.txt_NombreLinea.Text = "Nombre";
            // 
            // lbl_TelefonoLinea
            // 
            this.lbl_TelefonoLinea.AutoSize = true;
            this.lbl_TelefonoLinea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TelefonoLinea.Location = new System.Drawing.Point(512, 171);
            this.lbl_TelefonoLinea.Name = "lbl_TelefonoLinea";
            this.lbl_TelefonoLinea.Size = new System.Drawing.Size(53, 15);
            this.lbl_TelefonoLinea.TabIndex = 135;
            this.lbl_TelefonoLinea.Text = "Telefono";
            // 
            // txt_IdEcommerce
            // 
            this.txt_IdEcommerce.AutoSize = true;
            this.txt_IdEcommerce.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IdEcommerce.Location = new System.Drawing.Point(18, 149);
            this.txt_IdEcommerce.Name = "txt_IdEcommerce";
            this.txt_IdEcommerce.Size = new System.Drawing.Size(83, 15);
            this.txt_IdEcommerce.TabIndex = 134;
            this.txt_IdEcommerce.Text = "Id Ecommerce";
            // 
            // cb_colonia
            // 
            this.cb_colonia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cb_colonia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_colonia.FormattingEnabled = true;
            this.cb_colonia.Location = new System.Drawing.Point(129, 37);
            this.cb_colonia.Name = "cb_colonia";
            this.cb_colonia.Size = new System.Drawing.Size(272, 23);
            this.cb_colonia.TabIndex = 110;
            this.cb_colonia.Click += new System.EventHandler(this.Cb_colonia_Click);
            this.cb_colonia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cb_colonia_KeyPress);
            // 
            // txt_MovilEntrega
            // 
            this.txt_MovilEntrega.BackColor = System.Drawing.Color.White;
            this.txt_MovilEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MovilEntrega.Location = new System.Drawing.Point(514, 89);
            this.txt_MovilEntrega.MaxLength = 10;
            this.txt_MovilEntrega.Name = "txt_MovilEntrega";
            this.txt_MovilEntrega.Size = new System.Drawing.Size(308, 22);
            this.txt_MovilEntrega.TabIndex = 116;
            this.txt_MovilEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_MovilEntrega_KeyPress);
            // 
            // txt_TelParticularEntrega
            // 
            this.txt_TelParticularEntrega.BackColor = System.Drawing.Color.White;
            this.txt_TelParticularEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelParticularEntrega.Location = new System.Drawing.Point(129, 89);
            this.txt_TelParticularEntrega.MaxLength = 10;
            this.txt_TelParticularEntrega.Name = "txt_TelParticularEntrega";
            this.txt_TelParticularEntrega.Size = new System.Drawing.Size(272, 22);
            this.txt_TelParticularEntrega.TabIndex = 115;
            this.txt_TelParticularEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_TelParticularEntrega_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(408, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 15);
            this.label5.TabIndex = 125;
            this.label5.Text = "*Telefono Movil";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 15);
            this.label4.TabIndex = 124;
            this.label4.Text = "*Telefono Particular";
            // 
            // txt_EntreCallesEntrega
            // 
            this.txt_EntreCallesEntrega.BackColor = System.Drawing.Color.White;
            this.txt_EntreCallesEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EntreCallesEntrega.Location = new System.Drawing.Point(482, 65);
            this.txt_EntreCallesEntrega.MaxLength = 100;
            this.txt_EntreCallesEntrega.Name = "txt_EntreCallesEntrega";
            this.txt_EntreCallesEntrega.Size = new System.Drawing.Size(340, 22);
            this.txt_EntreCallesEntrega.TabIndex = 114;
            this.txt_EntreCallesEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_EntreCallesEntrega_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(18, 117);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 15);
            this.label33.TabIndex = 123;
            this.label33.Text = "Referencia";
            // 
            // lbl_poblacion
            // 
            this.lbl_poblacion.AutoSize = true;
            this.lbl_poblacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_poblacion.Location = new System.Drawing.Point(563, 40);
            this.lbl_poblacion.Name = "lbl_poblacion";
            this.lbl_poblacion.Size = new System.Drawing.Size(67, 15);
            this.lbl_poblacion.TabIndex = 122;
            this.lbl_poblacion.Text = "*Poblacion";
            // 
            // lbl_colonia
            // 
            this.lbl_colonia.AutoSize = true;
            this.lbl_colonia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_colonia.Location = new System.Drawing.Point(9, 40);
            this.lbl_colonia.Name = "lbl_colonia";
            this.lbl_colonia.Size = new System.Drawing.Size(56, 15);
            this.lbl_colonia.TabIndex = 121;
            this.lbl_colonia.Text = "*Colonia";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Azure;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(408, 40);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 15);
            this.label27.TabIndex = 120;
            this.label27.Text = "*CP";
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(9, 16);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(68, 15);
            this.lbl_direccion.TabIndex = 119;
            this.lbl_direccion.Text = "*Direccion";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Azure;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(16, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(49, 15);
            this.label25.TabIndex = 118;
            this.label25.Text = "*Estado";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(407, 68);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 15);
            this.label24.TabIndex = 117;
            this.label24.Text = "Entre Calles";
            // 
            // txt_EstadoEntrega
            // 
            this.txt_EstadoEntrega.BackColor = System.Drawing.Color.White;
            this.txt_EstadoEntrega.Enabled = false;
            this.txt_EstadoEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EstadoEntrega.Location = new System.Drawing.Point(129, 65);
            this.txt_EstadoEntrega.MaxLength = 30;
            this.txt_EstadoEntrega.Name = "txt_EstadoEntrega";
            this.txt_EstadoEntrega.Size = new System.Drawing.Size(272, 22);
            this.txt_EstadoEntrega.TabIndex = 113;
            // 
            // txt_PoblacionEntrega
            // 
            this.txt_PoblacionEntrega.BackColor = System.Drawing.Color.White;
            this.txt_PoblacionEntrega.Enabled = false;
            this.txt_PoblacionEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PoblacionEntrega.Location = new System.Drawing.Point(636, 37);
            this.txt_PoblacionEntrega.MaxLength = 50;
            this.txt_PoblacionEntrega.Name = "txt_PoblacionEntrega";
            this.txt_PoblacionEntrega.Size = new System.Drawing.Size(186, 22);
            this.txt_PoblacionEntrega.TabIndex = 112;
            // 
            // txt_CPEntrega
            // 
            this.txt_CPEntrega.BackColor = System.Drawing.Color.White;
            this.txt_CPEntrega.Enabled = false;
            this.txt_CPEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CPEntrega.Location = new System.Drawing.Point(445, 37);
            this.txt_CPEntrega.MaxLength = 5;
            this.txt_CPEntrega.Name = "txt_CPEntrega";
            this.txt_CPEntrega.Size = new System.Drawing.Size(112, 22);
            this.txt_CPEntrega.TabIndex = 111;
            this.txt_CPEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CPEntrega_KeyPress);
            // 
            // txt_ReferenciaEntrega
            // 
            this.txt_ReferenciaEntrega.BackColor = System.Drawing.Color.White;
            this.txt_ReferenciaEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ReferenciaEntrega.Location = new System.Drawing.Point(129, 114);
            this.txt_ReferenciaEntrega.MaxLength = 50;
            this.txt_ReferenciaEntrega.Name = "txt_ReferenciaEntrega";
            this.txt_ReferenciaEntrega.Size = new System.Drawing.Size(693, 22);
            this.txt_ReferenciaEntrega.TabIndex = 117;
            this.txt_ReferenciaEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_ReferenciaEntrega_KeyPress);
            // 
            // txt_direccionEntrega
            // 
            this.txt_direccionEntrega.BackColor = System.Drawing.Color.White;
            this.txt_direccionEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccionEntrega.Location = new System.Drawing.Point(129, 9);
            this.txt_direccionEntrega.MaxLength = 100;
            this.txt_direccionEntrega.Name = "txt_direccionEntrega";
            this.txt_direccionEntrega.Size = new System.Drawing.Size(436, 22);
            this.txt_direccionEntrega.TabIndex = 109;
            this.txt_direccionEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_direccionEntrega_KeyPress);
            // 
            // btn_nuevaEntrega
            // 
            this.btn_nuevaEntrega.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_nuevaEntrega.FlatAppearance.BorderSize = 0;
            this.btn_nuevaEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nuevaEntrega.Image = ((System.Drawing.Image)(resources.GetObject("btn_nuevaEntrega.Image")));
            this.btn_nuevaEntrega.Location = new System.Drawing.Point(767, 10);
            this.btn_nuevaEntrega.Name = "btn_nuevaEntrega";
            this.btn_nuevaEntrega.Size = new System.Drawing.Size(81, 56);
            this.btn_nuevaEntrega.TabIndex = 107;
            this.btn_nuevaEntrega.Text = "Nuevo";
            this.btn_nuevaEntrega.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_nuevaEntrega.UseVisualStyleBackColor = true;
            this.btn_nuevaEntrega.Click += new System.EventHandler(this.Btn_nuevo_Click);
            // 
            // btn_guardar
            // 
            this.btn_guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_guardar.FlatAppearance.BorderSize = 0;
            this.btn_guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_guardar.Image = ((System.Drawing.Image)(resources.GetObject("btn_guardar.Image")));
            this.btn_guardar.Location = new System.Drawing.Point(768, 76);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(80, 56);
            this.btn_guardar.TabIndex = 103;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.Btn_guardar_Click);
            // 
            // dgv_datosEntrega
            // 
            this.dgv_datosEntrega.AllowUserToAddRows = false;
            this.dgv_datosEntrega.AllowUserToDeleteRows = false;
            this.dgv_datosEntrega.AllowUserToResizeColumns = false;
            this.dgv_datosEntrega.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_datosEntrega.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_datosEntrega.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_datosEntrega.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_datosEntrega.BackgroundColor = System.Drawing.Color.White;
            this.dgv_datosEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_datosEntrega.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_datosEntrega.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_datosEntrega.EnableHeadersVisualStyles = false;
            this.dgv_datosEntrega.Location = new System.Drawing.Point(10, 15);
            this.dgv_datosEntrega.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.dgv_datosEntrega.MultiSelect = false;
            this.dgv_datosEntrega.Name = "dgv_datosEntrega";
            this.dgv_datosEntrega.ReadOnly = true;
            this.dgv_datosEntrega.RowHeadersVisible = false;
            this.dgv_datosEntrega.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_datosEntrega.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_datosEntrega.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_datosEntrega.Size = new System.Drawing.Size(745, 127);
            this.dgv_datosEntrega.TabIndex = 102;
            this.dgv_datosEntrega.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_datosEntrega_CellClick);
            this.dgv_datosEntrega.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_datosEntrega_CellContentClick);
            this.dgv_datosEntrega.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_datosEntrega_ColumnHeaderMouseClick);
            // 
            // btn_Anticipo
            // 
            this.btn_Anticipo.BackColor = System.Drawing.Color.White;
            this.btn_Anticipo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Anticipo.FlatAppearance.BorderSize = 0;
            this.btn_Anticipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Anticipo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Anticipo.Image = ((System.Drawing.Image)(resources.GetObject("btn_Anticipo.Image")));
            this.btn_Anticipo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Anticipo.Location = new System.Drawing.Point(7, 1115);
            this.btn_Anticipo.Margin = new System.Windows.Forms.Padding(7, 3, 3, 3);
            this.btn_Anticipo.Name = "btn_Anticipo";
            this.btn_Anticipo.Size = new System.Drawing.Size(151, 40);
            this.btn_Anticipo.TabIndex = 107;
            this.btn_Anticipo.Text = "Anticipo";
            this.btn_Anticipo.UseVisualStyleBackColor = false;
            this.btn_Anticipo.Click += new System.EventHandler(this.Btn_Anticipo_Click);
            // 
            // gb_anticipos
            // 
            this.gb_anticipos.BackColor = System.Drawing.Color.White;
            this.gb_anticipos.Controls.Add(this.lbl_cambio);
            this.gb_anticipos.Controls.Add(this.lbl_rec_ceros);
            this.gb_anticipos.Controls.Add(this.Tb_efectivoRecibido);
            this.gb_anticipos.Controls.Add(this.lbl_recibido);
            this.gb_anticipos.Controls.Add(this.btn_guardarAnticipos);
            this.gb_anticipos.Controls.Add(this.lbl_importeTotal);
            this.gb_anticipos.Controls.Add(this.flp_FormaPago);
            this.gb_anticipos.Controls.Add(this.btn_agregarFormaPago);
            this.gb_anticipos.Controls.Add(this.label39);
            this.gb_anticipos.Controls.Add(this.txt_anticipototal);
            this.gb_anticipos.Location = new System.Drawing.Point(3, 1161);
            this.gb_anticipos.Name = "gb_anticipos";
            this.gb_anticipos.Size = new System.Drawing.Size(829, 179);
            this.gb_anticipos.TabIndex = 108;
            this.gb_anticipos.TabStop = false;
            this.gb_anticipos.Visible = false;
            // 
            // lbl_cambio
            // 
            this.lbl_cambio.AutoSize = true;
            this.lbl_cambio.Location = new System.Drawing.Point(418, 111);
            this.lbl_cambio.Name = "lbl_cambio";
            this.lbl_cambio.Size = new System.Drawing.Size(78, 13);
            this.lbl_cambio.TabIndex = 108;
            this.lbl_cambio.Text = "Cambio: $ 0.00";
            // 
            // lbl_rec_ceros
            // 
            this.lbl_rec_ceros.AutoSize = true;
            this.lbl_rec_ceros.Location = new System.Drawing.Point(385, 111);
            this.lbl_rec_ceros.Name = "lbl_rec_ceros";
            this.lbl_rec_ceros.Size = new System.Drawing.Size(22, 13);
            this.lbl_rec_ceros.TabIndex = 107;
            this.lbl_rec_ceros.Text = ".00";
            // 
            // Tb_efectivoRecibido
            // 
            this.Tb_efectivoRecibido.Location = new System.Drawing.Point(303, 108);
            this.Tb_efectivoRecibido.MaxLength = 10;
            this.Tb_efectivoRecibido.Name = "Tb_efectivoRecibido";
            this.Tb_efectivoRecibido.Size = new System.Drawing.Size(76, 20);
            this.Tb_efectivoRecibido.TabIndex = 106;
            this.Tb_efectivoRecibido.Text = "0";
            this.Tb_efectivoRecibido.Enter += new System.EventHandler(this.Tb_efectivoRecibido_Enter);
            this.Tb_efectivoRecibido.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Tb_efectivoRecibido_KeyDown);
            this.Tb_efectivoRecibido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tb_efectivoRecibido_KeyPress);
            this.Tb_efectivoRecibido.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Tb_efectivoRecibido_KeyUp);
            // 
            // lbl_recibido
            // 
            this.lbl_recibido.AutoSize = true;
            this.lbl_recibido.Location = new System.Drawing.Point(243, 111);
            this.lbl_recibido.Name = "lbl_recibido";
            this.lbl_recibido.Size = new System.Drawing.Size(49, 13);
            this.lbl_recibido.TabIndex = 105;
            this.lbl_recibido.Text = "Recibido";
            // 
            // btn_guardarAnticipos
            // 
            this.btn_guardarAnticipos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_guardarAnticipos.FlatAppearance.BorderSize = 0;
            this.btn_guardarAnticipos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_guardarAnticipos.Image = ((System.Drawing.Image)(resources.GetObject("btn_guardarAnticipos.Image")));
            this.btn_guardarAnticipos.Location = new System.Drawing.Point(751, 12);
            this.btn_guardarAnticipos.Name = "btn_guardarAnticipos";
            this.btn_guardarAnticipos.Size = new System.Drawing.Size(66, 56);
            this.btn_guardarAnticipos.TabIndex = 104;
            this.btn_guardarAnticipos.Text = "Guardar";
            this.btn_guardarAnticipos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_guardarAnticipos.UseVisualStyleBackColor = true;
            this.btn_guardarAnticipos.Click += new System.EventHandler(this.Btn_guardarAnticipos_Click);
            // 
            // lbl_importeTotal
            // 
            this.lbl_importeTotal.AutoSize = true;
            this.lbl_importeTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_importeTotal.Location = new System.Drawing.Point(388, 155);
            this.lbl_importeTotal.Name = "lbl_importeTotal";
            this.lbl_importeTotal.Size = new System.Drawing.Size(83, 15);
            this.lbl_importeTotal.TabIndex = 69;
            this.lbl_importeTotal.Text = "Importe total :";
            // 
            // flp_FormaPago
            // 
            this.flp_FormaPago.AutoScroll = true;
            this.flp_FormaPago.Location = new System.Drawing.Point(6, 12);
            this.flp_FormaPago.Name = "flp_FormaPago";
            this.flp_FormaPago.Size = new System.Drawing.Size(723, 82);
            this.flp_FormaPago.TabIndex = 68;
            // 
            // btn_agregarFormaPago
            // 
            this.btn_agregarFormaPago.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_agregarFormaPago.BackColor = System.Drawing.Color.White;
            this.btn_agregarFormaPago.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_agregarFormaPago.FlatAppearance.BorderSize = 0;
            this.btn_agregarFormaPago.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_agregarFormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarFormaPago.ForeColor = System.Drawing.Color.Black;
            this.btn_agregarFormaPago.Image = ((System.Drawing.Image)(resources.GetObject("btn_agregarFormaPago.Image")));
            this.btn_agregarFormaPago.Location = new System.Drawing.Point(6, 100);
            this.btn_agregarFormaPago.Name = "btn_agregarFormaPago";
            this.btn_agregarFormaPago.Size = new System.Drawing.Size(231, 36);
            this.btn_agregarFormaPago.TabIndex = 61;
            this.btn_agregarFormaPago.Text = "Agregar nueva forma de pago";
            this.btn_agregarFormaPago.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_agregarFormaPago.UseVisualStyleBackColor = false;
            this.btn_agregarFormaPago.Click += new System.EventHandler(this.Btn_agregarFormaPago_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(164, 155);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 15);
            this.label39.TabIndex = 57;
            this.label39.Text = "Monto total :";
            // 
            // txt_anticipototal
            // 
            this.txt_anticipototal.BackColor = System.Drawing.Color.White;
            this.txt_anticipototal.Enabled = false;
            this.txt_anticipototal.Location = new System.Drawing.Point(246, 153);
            this.txt_anticipototal.Name = "txt_anticipototal";
            this.txt_anticipototal.Size = new System.Drawing.Size(63, 20);
            this.txt_anticipototal.TabIndex = 58;
            // 
            // lbl_paginaActual
            // 
            this.lbl_paginaActual.AutoSize = true;
            this.lbl_paginaActual.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paginaActual.Location = new System.Drawing.Point(443, 62);
            this.lbl_paginaActual.Name = "lbl_paginaActual";
            this.lbl_paginaActual.Size = new System.Drawing.Size(28, 15);
            this.lbl_paginaActual.TabIndex = 75;
            this.lbl_paginaActual.Text = "de a";
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(87, 0);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(71, 15);
            this.lbl_fecha.TabIndex = 76;
            this.lbl_fecha.Text = "01/01/2001";
            // 
            // lbl_mov
            // 
            this.lbl_mov.AutoSize = true;
            this.lbl_mov.ContextMenuStrip = this.cms_copiar;
            this.lbl_mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mov.Location = new System.Drawing.Point(164, 0);
            this.lbl_mov.Name = "lbl_mov";
            this.lbl_mov.Size = new System.Drawing.Size(97, 15);
            this.lbl_mov.TabIndex = 77;
            this.lbl_mov.Text = "Solicitud credito";
            // 
            // lbl_movID
            // 
            this.lbl_movID.AutoSize = true;
            this.lbl_movID.ContextMenuStrip = this.cms_copiar;
            this.lbl_movID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_movID.Location = new System.Drawing.Point(267, 0);
            this.lbl_movID.Name = "lbl_movID";
            this.lbl_movID.Size = new System.Drawing.Size(60, 15);
            this.lbl_movID.TabIndex = 78;
            this.lbl_movID.Text = "ZAZ6560";
            // 
            // lbl_estatus
            // 
            this.lbl_estatus.AutoSize = true;
            this.lbl_estatus.ContextMenuStrip = this.cms_copiar;
            this.lbl_estatus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_estatus.Location = new System.Drawing.Point(333, 0);
            this.lbl_estatus.Name = "lbl_estatus";
            this.lbl_estatus.Size = new System.Drawing.Size(83, 15);
            this.lbl_estatus.TabIndex = 79;
            this.lbl_estatus.Text = "CONCLUIDO";
            // 
            // panelmenu
            // 
            this.panelmenu.AutoScroll = true;
            this.panelmenu.Controls.Add(this.btn_Regresar);
            this.panelmenu.Controls.Add(this.btn_Imprimir);
            this.panelmenu.Controls.Add(this.btn_Situaciones);
            this.panelmenu.Controls.Add(this.btn_Afectar);
            this.panelmenu.Controls.Add(this.btn_Eliminar);
            this.panelmenu.Controls.Add(this.btn_Cancelar);
            this.panelmenu.Controls.Add(this.btn_InfoArt);
            this.panelmenu.Controls.Add(this.btn_Eventos);
            this.panelmenu.Controls.Add(this.btn_HojaV);
            this.panelmenu.Controls.Add(this.btn_SHM);
            this.panelmenu.Controls.Add(this.btnEmbarcar);
            this.panelmenu.Controls.Add(this.btn_AdjuntarSHM);
            this.panelmenu.Controls.Add(this.btnDocumentos);
            this.panelmenu.Controls.Add(this.btn_Ayuda);
            this.panelmenu.Controls.Add(this.btnCartaFactura);
            this.panelmenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelmenu.Location = new System.Drawing.Point(8, 23);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(114, 574);
            this.panelmenu.TabIndex = 80;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(86, 74);
            this.btn_Regresar.TabIndex = 34;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.Btn_Regresar_Click);
            // 
            // btn_Imprimir
            // 
            this.btn_Imprimir.BackColor = System.Drawing.Color.Transparent;
            this.btn_Imprimir.FlatAppearance.BorderSize = 0;
            this.btn_Imprimir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Imprimir.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Imprimir.Image = ((System.Drawing.Image)(resources.GetObject("btn_Imprimir.Image")));
            this.btn_Imprimir.Location = new System.Drawing.Point(3, 83);
            this.btn_Imprimir.Name = "btn_Imprimir";
            this.btn_Imprimir.Size = new System.Drawing.Size(86, 72);
            this.btn_Imprimir.TabIndex = 27;
            this.btn_Imprimir.Text = "Imprimir (Crtl-I)";
            this.btn_Imprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Imprimir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Imprimir.UseVisualStyleBackColor = false;
            this.btn_Imprimir.Click += new System.EventHandler(this.Btn_Imprimir_Click);
            // 
            // btn_Situaciones
            // 
            this.btn_Situaciones.BackColor = System.Drawing.Color.Transparent;
            this.btn_Situaciones.FlatAppearance.BorderSize = 0;
            this.btn_Situaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Situaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Situaciones.Image = ((System.Drawing.Image)(resources.GetObject("btn_Situaciones.Image")));
            this.btn_Situaciones.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Situaciones.Location = new System.Drawing.Point(3, 161);
            this.btn_Situaciones.Name = "btn_Situaciones";
            this.btn_Situaciones.Size = new System.Drawing.Size(86, 77);
            this.btn_Situaciones.TabIndex = 28;
            this.btn_Situaciones.Text = "Situaciones (Crtl-S)";
            this.btn_Situaciones.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Situaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Situaciones.UseVisualStyleBackColor = false;
            this.btn_Situaciones.Click += new System.EventHandler(this.Btn_Situaciones_Click);
            // 
            // btn_Afectar
            // 
            this.btn_Afectar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Afectar.FlatAppearance.BorderSize = 0;
            this.btn_Afectar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Afectar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Afectar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Afectar.Image")));
            this.btn_Afectar.Location = new System.Drawing.Point(3, 244);
            this.btn_Afectar.Name = "btn_Afectar";
            this.btn_Afectar.Size = new System.Drawing.Size(86, 81);
            this.btn_Afectar.TabIndex = 29;
            this.btn_Afectar.Text = "Afectar (Crtl-F)";
            this.btn_Afectar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Afectar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Afectar.UseVisualStyleBackColor = false;
            this.btn_Afectar.Click += new System.EventHandler(this.Btn_Afectar_Click);
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Eliminar.FlatAppearance.BorderSize = 0;
            this.btn_Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Eliminar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Eliminar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Eliminar.Image")));
            this.btn_Eliminar.Location = new System.Drawing.Point(3, 331);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Size = new System.Drawing.Size(86, 92);
            this.btn_Eliminar.TabIndex = 30;
            this.btn_Eliminar.Text = "Eliminar movimiento (F1)";
            this.btn_Eliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Eliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Eliminar.UseVisualStyleBackColor = false;
            this.btn_Eliminar.Visible = false;
            this.btn_Eliminar.Click += new System.EventHandler(this.Btn_Eliminar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Cancelar.FlatAppearance.BorderSize = 0;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cancelar.Image")));
            this.btn_Cancelar.Location = new System.Drawing.Point(3, 429);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(86, 89);
            this.btn_Cancelar.TabIndex = 31;
            this.btn_Cancelar.Text = "Cancelar movimiento (F2)";
            this.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.Btn_Cancelar_Click);
            // 
            // btn_InfoArt
            // 
            this.btn_InfoArt.BackColor = System.Drawing.Color.Transparent;
            this.btn_InfoArt.FlatAppearance.BorderSize = 0;
            this.btn_InfoArt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InfoArt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InfoArt.Image = ((System.Drawing.Image)(resources.GetObject("btn_InfoArt.Image")));
            this.btn_InfoArt.Location = new System.Drawing.Point(3, 524);
            this.btn_InfoArt.Name = "btn_InfoArt";
            this.btn_InfoArt.Size = new System.Drawing.Size(86, 83);
            this.btn_InfoArt.TabIndex = 32;
            this.btn_InfoArt.Text = "Información del artículo (Crtl-D)";
            this.btn_InfoArt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InfoArt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InfoArt.UseVisualStyleBackColor = false;
            this.btn_InfoArt.Click += new System.EventHandler(this.Btn_InfoArt_Click);
            // 
            // btn_Eventos
            // 
            this.btn_Eventos.BackColor = System.Drawing.Color.Transparent;
            this.btn_Eventos.FlatAppearance.BorderSize = 0;
            this.btn_Eventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Eventos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Eventos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Eventos.Image")));
            this.btn_Eventos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Eventos.Location = new System.Drawing.Point(3, 613);
            this.btn_Eventos.Name = "btn_Eventos";
            this.btn_Eventos.Size = new System.Drawing.Size(86, 86);
            this.btn_Eventos.TabIndex = 33;
            this.btn_Eventos.Text = "Evento, notas y citas (Crtl-E)";
            this.btn_Eventos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Eventos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Eventos.UseVisualStyleBackColor = false;
            this.btn_Eventos.Click += new System.EventHandler(this.Btn_Eventos_Click);
            // 
            // btn_HojaV
            // 
            this.btn_HojaV.BackColor = System.Drawing.Color.Transparent;
            this.btn_HojaV.FlatAppearance.BorderSize = 0;
            this.btn_HojaV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_HojaV.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HojaV.Image = ((System.Drawing.Image)(resources.GetObject("btn_HojaV.Image")));
            this.btn_HojaV.Location = new System.Drawing.Point(3, 705);
            this.btn_HojaV.Name = "btn_HojaV";
            this.btn_HojaV.Size = new System.Drawing.Size(86, 103);
            this.btn_HojaV.TabIndex = 37;
            this.btn_HojaV.Text = "Actualizar Datos (Crtl-A)";
            this.btn_HojaV.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_HojaV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_HojaV.UseVisualStyleBackColor = false;
            this.btn_HojaV.Click += new System.EventHandler(this.Btn_HojaV_Click);
            // 
            // btn_SHM
            // 
            this.btn_SHM.BackColor = System.Drawing.Color.Transparent;
            this.btn_SHM.FlatAppearance.BorderSize = 0;
            this.btn_SHM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SHM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SHM.Image = global::PuntoVenta.Properties.Resources.fingerprint;
            this.btn_SHM.Location = new System.Drawing.Point(3, 814);
            this.btn_SHM.Name = "btn_SHM";
            this.btn_SHM.Size = new System.Drawing.Size(86, 75);
            this.btn_SHM.TabIndex = 38;
            this.btn_SHM.Text = "SHM (Crtl-H)";
            this.btn_SHM.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_SHM.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_SHM.UseVisualStyleBackColor = false;
            this.btn_SHM.Click += new System.EventHandler(this.btn_SHM_Click);
            // 
            // btnEmbarcar
            // 
            this.btnEmbarcar.BackColor = System.Drawing.Color.Transparent;
            this.btnEmbarcar.FlatAppearance.BorderSize = 0;
            this.btnEmbarcar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmbarcar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmbarcar.Image = ((System.Drawing.Image)(resources.GetObject("btnEmbarcar.Image")));
            this.btnEmbarcar.Location = new System.Drawing.Point(3, 895);
            this.btnEmbarcar.Name = "btnEmbarcar";
            this.btnEmbarcar.Size = new System.Drawing.Size(86, 83);
            this.btnEmbarcar.TabIndex = 41;
            this.btnEmbarcar.Text = "Archivo Embarcar-Desembarcar";
            this.btnEmbarcar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEmbarcar.UseVisualStyleBackColor = false;
            this.btnEmbarcar.Visible = false;
            this.btnEmbarcar.Click += new System.EventHandler(this.btnEmbarcar_Click);
            // 
            // btn_AdjuntarSHM
            // 
            this.btn_AdjuntarSHM.BackColor = System.Drawing.Color.Transparent;
            this.btn_AdjuntarSHM.FlatAppearance.BorderSize = 0;
            this.btn_AdjuntarSHM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AdjuntarSHM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AdjuntarSHM.Image = ((System.Drawing.Image)(resources.GetObject("btn_AdjuntarSHM.Image")));
            this.btn_AdjuntarSHM.Location = new System.Drawing.Point(3, 984);
            this.btn_AdjuntarSHM.Name = "btn_AdjuntarSHM";
            this.btn_AdjuntarSHM.Size = new System.Drawing.Size(86, 93);
            this.btn_AdjuntarSHM.TabIndex = 36;
            this.btn_AdjuntarSHM.Text = "SHM adjuntar (Crtl-J)";
            this.btn_AdjuntarSHM.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_AdjuntarSHM.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_AdjuntarSHM.UseVisualStyleBackColor = false;
            this.btn_AdjuntarSHM.Click += new System.EventHandler(this.Btn_AdjuntarSHM_Click);
            // 
            // btnDocumentos
            // 
            this.btnDocumentos.BackColor = System.Drawing.Color.Transparent;
            this.btnDocumentos.FlatAppearance.BorderSize = 0;
            this.btnDocumentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocumentos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocumentos.Image = global::PuntoVenta.Properties.Resources.imagen;
            this.btnDocumentos.Location = new System.Drawing.Point(3, 1083);
            this.btnDocumentos.Name = "btnDocumentos";
            this.btnDocumentos.Size = new System.Drawing.Size(86, 93);
            this.btnDocumentos.TabIndex = 42;
            this.btnDocumentos.Text = "Documentos";
            this.btnDocumentos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDocumentos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDocumentos.UseVisualStyleBackColor = false;
            this.btnDocumentos.Visible = false;
            this.btnDocumentos.Click += new System.EventHandler(this.btnDocumentos_Click);
            // 
            // btn_Ayuda
            // 
            this.btn_Ayuda.BackColor = System.Drawing.Color.Transparent;
            this.btn_Ayuda.FlatAppearance.BorderSize = 0;
            this.btn_Ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_Ayuda.Image")));
            this.btn_Ayuda.Location = new System.Drawing.Point(3, 1182);
            this.btn_Ayuda.Name = "btn_Ayuda";
            this.btn_Ayuda.Size = new System.Drawing.Size(86, 59);
            this.btn_Ayuda.TabIndex = 35;
            this.btn_Ayuda.Text = "Ayuda";
            this.btn_Ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Ayuda.UseVisualStyleBackColor = false;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.ContextMenuStrip = this.cms_copiar;
            this.lbl_ID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(422, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(66, 15);
            this.lbl_ID.TabIndex = 81;
            this.lbl_ID.Text = "ID de venta";
            // 
            // flpanel_labels
            // 
            this.flpanel_labels.Controls.Add(this.lbl_ID);
            this.flpanel_labels.Controls.Add(this.lbl_estatus);
            this.flpanel_labels.Controls.Add(this.lbl_movID);
            this.flpanel_labels.Controls.Add(this.lbl_mov);
            this.flpanel_labels.Controls.Add(this.lbl_fecha);
            this.flpanel_labels.Location = new System.Drawing.Point(510, 48);
            this.flpanel_labels.Name = "flpanel_labels";
            this.flpanel_labels.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flpanel_labels.Size = new System.Drawing.Size(491, 23);
            this.flpanel_labels.TabIndex = 83;
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(126, 0);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(897, 42);
            this.txt_Comentarios.TabIndex = 119;
            this.txt_Comentarios.TextChanged += new System.EventHandler(this.txt_Comentarios_TextChanged);
            // 
            // chx_Die
            // 
            this.chx_Die.AutoSize = true;
            this.chx_Die.Enabled = false;
            this.chx_Die.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chx_Die.Location = new System.Drawing.Point(132, 50);
            this.chx_Die.Margin = new System.Windows.Forms.Padding(7, 5, 3, 3);
            this.chx_Die.Name = "chx_Die";
            this.chx_Die.Size = new System.Drawing.Size(126, 19);
            this.chx_Die.TabIndex = 121;
            this.chx_Die.Text = "Deposito en Banco";
            this.chx_Die.UseVisualStyleBackColor = true;
            this.chx_Die.CheckedChanged += new System.EventHandler(this.chx_Die_CheckedChanged);
            // 
            // btn_detallePosterior
            // 
            this.btn_detallePosterior.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_detallePosterior.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_detallePosterior.FlatAppearance.BorderSize = 0;
            this.btn_detallePosterior.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_detallePosterior.Image = ((System.Drawing.Image)(resources.GetObject("btn_detallePosterior.Image")));
            this.btn_detallePosterior.Location = new System.Drawing.Point(459, 41);
            this.btn_detallePosterior.Name = "btn_detallePosterior";
            this.btn_detallePosterior.Size = new System.Drawing.Size(26, 21);
            this.btn_detallePosterior.TabIndex = 74;
            this.btn_detallePosterior.TabStop = false;
            this.btn_detallePosterior.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_detallePosterior.UseVisualStyleBackColor = false;
            this.btn_detallePosterior.Click += new System.EventHandler(this.Btn_detallePosterior_Click);
            // 
            // btn_detalleAnterior
            // 
            this.btn_detalleAnterior.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_detalleAnterior.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_detalleAnterior.FlatAppearance.BorderSize = 0;
            this.btn_detalleAnterior.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_detalleAnterior.Image = ((System.Drawing.Image)(resources.GetObject("btn_detalleAnterior.Image")));
            this.btn_detalleAnterior.Location = new System.Drawing.Point(425, 41);
            this.btn_detalleAnterior.Name = "btn_detalleAnterior";
            this.btn_detalleAnterior.Size = new System.Drawing.Size(26, 21);
            this.btn_detalleAnterior.TabIndex = 73;
            this.btn_detalleAnterior.TabStop = false;
            this.btn_detalleAnterior.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_detalleAnterior.UseVisualStyleBackColor = false;
            this.btn_detalleAnterior.Click += new System.EventHandler(this.Btn_detalleAnterior_Click);
            // 
            // chkTransferencia
            // 
            this.chkTransferencia.AutoSize = true;
            this.chkTransferencia.Enabled = false;
            this.chkTransferencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.chkTransferencia.Location = new System.Drawing.Point(264, 48);
            this.chkTransferencia.Name = "chkTransferencia";
            this.chkTransferencia.Size = new System.Drawing.Size(156, 19);
            this.chkTransferencia.TabIndex = 122;
            this.chkTransferencia.Text = "Transferencia Bancaria";
            this.chkTransferencia.UseVisualStyleBackColor = true;
            this.chkTransferencia.Visible = false;
            this.chkTransferencia.CheckedChanged += new System.EventHandler(this.chkTransferencia_CheckedChanged);
            // 
            // btnCartaFactura
            // 
            this.btnCartaFactura.BackColor = System.Drawing.Color.Transparent;
            this.btnCartaFactura.FlatAppearance.BorderSize = 0;
            this.btnCartaFactura.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCartaFactura.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCartaFactura.Image = ((System.Drawing.Image)(resources.GetObject("btnCartaFactura.Image")));
            this.btnCartaFactura.Location = new System.Drawing.Point(3, 1247);
            this.btnCartaFactura.Name = "btnCartaFactura";
            this.btnCartaFactura.Size = new System.Drawing.Size(86, 93);
            this.btnCartaFactura.TabIndex = 43;
            this.btnCartaFactura.Text = "Carta Factura";
            this.btnCartaFactura.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCartaFactura.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCartaFactura.UseVisualStyleBackColor = false;
            this.btnCartaFactura.Click += new System.EventHandler(this.btnCartaFactura_Click);
            // 
            // DM0312_DetalleVenta
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1119, 596);
            this.Controls.Add(this.chkTransferencia);
            this.Controls.Add(this.chx_Die);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.flpanel);
            this.Controls.Add(this.flpanel_labels);
            this.Controls.Add(this.panelmenu);
            this.Controls.Add(this.lbl_paginaActual);
            this.Controls.Add(this.btn_detallePosterior);
            this.Controls.Add(this.btn_detalleAnterior);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "DM0312_DetalleVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalle";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_DetalleVenta_FormClosing);
            this.Load += new System.EventHandler(this.Detalle_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Detalle_Scroll);
            this.LocationChanged += new System.EventHandler(this.DM0312_DetalleVenta_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_DetalleVenta_KeyDown);
            this.cms_copiar.ResumeLayout(false);
            this.flpanel.ResumeLayout(false);
            this.flpanel.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pan_correo.ResumeLayout(false);
            this.pan_correo.PerformLayout();
            this.pan_refConcepto.ResumeLayout(false);
            this.pan_refConcepto.PerformLayout();
            this.pan_formaPago.ResumeLayout(false);
            this.pan_formaPago.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flp_articulos.ResumeLayout(false);
            this.flp_articulos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_detalle)).EndInit();
            this.pan_Vales.ResumeLayout(false);
            this.pan_Vales.PerformLayout();
            this.pnlBtn_DatosEntrega.ResumeLayout(false);
            this.pnlBtn_DatosEntrega.PerformLayout();
            this.gbx_DatosEntrega.ResumeLayout(false);
            this.gb_CamposEntrega.ResumeLayout(false);
            this.gb_CamposEntrega.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datosEntrega)).EndInit();
            this.gb_anticipos.ResumeLayout(false);
            this.gb_anticipos.PerformLayout();
            this.panelmenu.ResumeLayout(false);
            this.flpanel_labels.ResumeLayout(false);
            this.flpanel_labels.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Afectar;
        private System.Windows.Forms.Button btn_Situaciones;
        private System.Windows.Forms.Button btn_Imprimir;
        private System.Windows.Forms.Button btn_InfoArt;
        private System.Windows.Forms.Button btn_Eliminar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_Ayuda;
        private System.Windows.Forms.Button btn_Eventos;
        private System.Windows.Forms.Button btn_detalleAnterior;
        private System.Windows.Forms.Button btn_detallePosterior;
        private System.Windows.Forms.Label lbl_paginaActual;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_mov;
        private System.Windows.Forms.Label lbl_movID;
        private System.Windows.Forms.Label lbl_estatus;
        private System.Windows.Forms.FlowLayoutPanel panelmenu;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Button btn_AdjuntarSHM;
        private System.Windows.Forms.Button btn_HojaV;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.FlowLayoutPanel flpanel_labels;
        private System.Windows.Forms.ContextMenuStrip cms_copiar;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.Button btn_SHM;
        private System.Windows.Forms.FlowLayoutPanel flpanel;
        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.TextBox txt_Cliente;
        private System.Windows.Forms.TextBox txt_Cliente1;
        private System.Windows.Forms.Label lbl_TipoVenta;
        private System.Windows.Forms.TextBox txt_TipoVenta;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl_Agente;
        private System.Windows.Forms.TextBox txt_Agente;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txt_Canal;
        private System.Windows.Forms.Label lbl_Canal;
        private System.Windows.Forms.TextBox txt_Canal1;
        private System.Windows.Forms.Label lbl_Condiciones;
        private System.Windows.Forms.TextBox txt_Condiciones;
        private System.Windows.Forms.Label lbl_Almacen;
        private System.Windows.Forms.ComboBox cb_Almacen;
        private System.Windows.Forms.Panel pan_correo;
        private System.Windows.Forms.Label lbl_Correo;
        private System.Windows.Forms.TextBox txt_Correo;
        private System.Windows.Forms.Panel pan_refConcepto;
        private System.Windows.Forms.TextBox txt_Referencia;
        private System.Windows.Forms.TextBox txt_Concepto;
        private System.Windows.Forms.Label lbl_Concepto;
        private System.Windows.Forms.Label lbl_Referencia;
        private System.Windows.Forms.Label lbl_Ecommerce;
        private System.Windows.Forms.TextBox txt_Commerce;
        private System.Windows.Forms.Panel pan_formaPago;
        private System.Windows.Forms.Label lbl_FormaPago;
        private System.Windows.Forms.TextBox txt_FormaPago;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox txt_Enganche;
        private System.Windows.Forms.Label lbl_Enganche;
        private System.Windows.Forms.TextBox txt_EmbarqueFecha;
        private System.Windows.Forms.TextBox txt_Embarque;
        private System.Windows.Forms.Label lbl_Embarque;
        private System.Windows.Forms.TextBox txt_Monedero;
        private System.Windows.Forms.CheckBox chk_Mayoreo;
        private System.Windows.Forms.CheckBox chk_Custodia;
        private System.Windows.Forms.CheckBox chk_Iva;
        private System.Windows.Forms.CheckBox chk_Comentario;
        private System.Windows.Forms.Label lbl_AgenteServicio;
        private System.Windows.Forms.TextBox txt_AgenteServicio;
        private System.Windows.Forms.Label lbl_FormaEnvio;
        private System.Windows.Forms.TextBox txt_FormaEnvio;
        private System.Windows.Forms.Label lbl_CtaPago;
        private System.Windows.Forms.TextBox txt_CtaPago;
        private System.Windows.Forms.CheckBox cb_ServicioReporte;
        private System.Windows.Forms.Label lbl_nomina;
        private System.Windows.Forms.TextBox tb_nomina;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Observaciones;
        private System.Windows.Forms.TextBox txt_Observaciones;
        private System.Windows.Forms.Label lbl_Comentario;
        private System.Windows.Forms.TextBox txt_Comentario;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lbl_Descripcion;
        private System.Windows.Forms.Label lbl_Unidad;
        private System.Windows.Forms.FlowLayoutPanel flp_articulos;
        private System.Windows.Forms.DataGridView dgv_detalle;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.TextBox txt_SubTotal;
        private System.Windows.Forms.Label lbl_Impuestos;
        private System.Windows.Forms.TextBox txt_Impuestos;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.TextBox txt_Total;
        private System.Windows.Forms.Panel pan_Vales;
        private System.Windows.Forms.TextBox tx_panelvaleInfo;
        private System.Windows.Forms.TextBox txt_vale;
        private System.Windows.Forms.TextBox txt_NIP;
        private System.Windows.Forms.Label lbl_ValeVenta;
        private System.Windows.Forms.Label lbl_nip;
        private System.Windows.Forms.Panel pnlBtn_DatosEntrega;
        private System.Windows.Forms.Button btn_datosEntrega;
        private System.Windows.Forms.GroupBox gbx_DatosEntrega;
        private System.Windows.Forms.GroupBox gb_CamposEntrega;
        private System.Windows.Forms.ComboBox cb_colonia;
        private System.Windows.Forms.TextBox txt_MovilEntrega;
        private System.Windows.Forms.TextBox txt_TelParticularEntrega;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_EntreCallesEntrega;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lbl_poblacion;
        private System.Windows.Forms.Label lbl_colonia;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt_EstadoEntrega;
        private System.Windows.Forms.TextBox txt_PoblacionEntrega;
        private System.Windows.Forms.TextBox txt_CPEntrega;
        private System.Windows.Forms.TextBox txt_ReferenciaEntrega;
        private System.Windows.Forms.TextBox txt_direccionEntrega;
        private System.Windows.Forms.Button btn_nuevaEntrega;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.DataGridView dgv_datosEntrega;
        private System.Windows.Forms.Button btn_Anticipo;
        private System.Windows.Forms.GroupBox gb_anticipos;
        private System.Windows.Forms.Label lbl_cambio;
        private System.Windows.Forms.Label lbl_rec_ceros;
        private System.Windows.Forms.TextBox Tb_efectivoRecibido;
        private System.Windows.Forms.Label lbl_recibido;
        private System.Windows.Forms.Button btn_guardarAnticipos;
        private System.Windows.Forms.Label lbl_importeTotal;
        private System.Windows.Forms.FlowLayoutPanel flp_FormaPago;
        private System.Windows.Forms.Button btn_agregarFormaPago;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txt_anticipototal;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.TextBox lbl_comentariosDatosEntrega;
        private System.Windows.Forms.Button btnGuardarComentarios;
        private System.Windows.Forms.TextBox txt_TelefonoLinea;
        private System.Windows.Forms.TextBox txt_Correo_Linea;
        private System.Windows.Forms.TextBox txt_Nombre_Linea;
        private System.Windows.Forms.TextBox txt_IdCommerceL;
        private System.Windows.Forms.Label lbl_correoLinea;
        private System.Windows.Forms.Label txt_NombreLinea;
        private System.Windows.Forms.Label lbl_TelefonoLinea;
        private System.Windows.Forms.Label txt_IdEcommerce;
        private System.Windows.Forms.ToolStripMenuItem UsrIncremento;
        private System.Windows.Forms.ToolStripMenuItem UsrDescuento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox txt_FormaCo;
        private System.Windows.Forms.Label lbl_RedMonedero;
        private System.Windows.Forms.TextBox txt_NumI;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_numE;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chx_Die;
        private System.Windows.Forms.CheckBox chkDomicilioCliente;
        private System.Windows.Forms.TextBox txt_CodigoRecomendado;
        private System.Windows.Forms.Label lbl_CodigoRecomendado;
        private System.Windows.Forms.Button btnEmbarcar;
        private System.Windows.Forms.Button btnDocumentos;
        private System.Windows.Forms.Label lblMonedero;
        private System.Windows.Forms.TextBox txtMonedero;
        private System.Windows.Forms.CheckBox chkTransferencia;
        private System.Windows.Forms.Label lblBanco;
        private System.Windows.Forms.TextBox txtBanco;
        private System.Windows.Forms.Label lblCuentaClabe;
        private System.Windows.Forms.TextBox txtCuentaClabe;
        private System.Windows.Forms.Button btnCartaFactura;
    }
}