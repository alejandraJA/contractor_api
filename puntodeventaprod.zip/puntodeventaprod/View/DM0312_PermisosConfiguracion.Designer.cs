﻿namespace PuntoVenta.View
{
    partial class DM0312_PermisosConfiguracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_PermisosConfiguracion));
            this.dgvAcceso = new System.Windows.Forms.DataGridView();
            this.dgvAccesoUsuario = new System.Windows.Forms.DataGridView();
            this.cmbFormas = new System.Windows.Forms.ComboBox();
            this.menuPermisos = new System.Windows.Forms.MenuStrip();
            this.toolGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoAccesoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regresarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl_NuevoAcceso = new System.Windows.Forms.Panel();
            this.lbl_ClonarAcceso = new System.Windows.Forms.Label();
            this.lbl_Nuevo = new System.Windows.Forms.Label();
            this.cmbClonarAcceso = new System.Windows.Forms.ComboBox();
            this.cmbNuevoAcceso = new System.Windows.Forms.ComboBox();
            this.menuClonar = new System.Windows.Forms.MenuStrip();
            this.clonarAccesoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txt_Campo = new System.Windows.Forms.TextBox();
            this.lbl_Campo = new System.Windows.Forms.Label();
            this.lbl_Forma = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcceso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccesoUsuario)).BeginInit();
            this.menuPermisos.SuspendLayout();
            this.pnl_NuevoAcceso.SuspendLayout();
            this.menuClonar.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvAcceso
            // 
            this.dgvAcceso.AllowUserToAddRows = false;
            this.dgvAcceso.AllowUserToDeleteRows = false;
            this.dgvAcceso.AllowUserToResizeColumns = false;
            this.dgvAcceso.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dgvAcceso.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAcceso.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAcceso.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvAcceso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAcceso.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAcceso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAcceso.EnableHeadersVisualStyles = false;
            this.dgvAcceso.Location = new System.Drawing.Point(323, 135);
            this.dgvAcceso.Name = "dgvAcceso";
            this.dgvAcceso.RowHeadersVisible = false;
            this.dgvAcceso.Size = new System.Drawing.Size(194, 320);
            this.dgvAcceso.TabIndex = 0;
            this.dgvAcceso.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAcceso_CellClick);
            this.dgvAcceso.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAcceso_CellContentClick);
            this.dgvAcceso.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvAcceso_ColumnHeaderMouseClick);
            // 
            // dgvAccesoUsuario
            // 
            this.dgvAccesoUsuario.AllowUserToAddRows = false;
            this.dgvAccesoUsuario.AllowUserToDeleteRows = false;
            this.dgvAccesoUsuario.AllowUserToResizeColumns = false;
            this.dgvAccesoUsuario.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvAccesoUsuario.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvAccesoUsuario.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAccesoUsuario.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvAccesoUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAccesoUsuario.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvAccesoUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAccesoUsuario.EnableHeadersVisualStyles = false;
            this.dgvAccesoUsuario.Location = new System.Drawing.Point(14, 138);
            this.dgvAccesoUsuario.Name = "dgvAccesoUsuario";
            this.dgvAccesoUsuario.RowHeadersVisible = false;
            this.dgvAccesoUsuario.Size = new System.Drawing.Size(236, 320);
            this.dgvAccesoUsuario.TabIndex = 1;
            this.dgvAccesoUsuario.Visible = false;
            this.dgvAccesoUsuario.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAccesoUsuario_CellClick);
            this.dgvAccesoUsuario.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvAccesoUsuario_ColumnHeaderMouseClick);
            // 
            // cmbFormas
            // 
            this.cmbFormas.BackColor = System.Drawing.SystemColors.Window;
            this.cmbFormas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFormas.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFormas.FormattingEnabled = true;
            this.cmbFormas.Location = new System.Drawing.Point(63, 47);
            this.cmbFormas.Name = "cmbFormas";
            this.cmbFormas.Size = new System.Drawing.Size(161, 23);
            this.cmbFormas.TabIndex = 2;
            this.cmbFormas.Visible = false;
            this.cmbFormas.SelectedIndexChanged += new System.EventHandler(this.cmbFormas_SelectedIndexChanged);
            // 
            // menuPermisos
            // 
            this.menuPermisos.BackColor = System.Drawing.SystemColors.Window;
            this.menuPermisos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuPermisos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolGuardar,
            this.nuevoAccesoToolStripMenuItem,
            this.regresarToolStripMenuItem});
            this.menuPermisos.Location = new System.Drawing.Point(0, 0);
            this.menuPermisos.Name = "menuPermisos";
            this.menuPermisos.Size = new System.Drawing.Size(595, 24);
            this.menuPermisos.TabIndex = 3;
            this.menuPermisos.Text = "menuStrip1";
            // 
            // toolGuardar
            // 
            this.toolGuardar.Image = ((System.Drawing.Image)(resources.GetObject("toolGuardar.Image")));
            this.toolGuardar.Name = "toolGuardar";
            this.toolGuardar.Size = new System.Drawing.Size(77, 20);
            this.toolGuardar.Text = "Guardar";
            this.toolGuardar.Click += new System.EventHandler(this.toolGuardar_Click);
            // 
            // nuevoAccesoToolStripMenuItem
            // 
            this.nuevoAccesoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("nuevoAccesoToolStripMenuItem.Image")));
            this.nuevoAccesoToolStripMenuItem.Name = "nuevoAccesoToolStripMenuItem";
            this.nuevoAccesoToolStripMenuItem.Size = new System.Drawing.Size(114, 20);
            this.nuevoAccesoToolStripMenuItem.Text = "Nuevo Acceso";
            this.nuevoAccesoToolStripMenuItem.Click += new System.EventHandler(this.nuevoAccesoToolStripMenuItem_Click);
            // 
            // regresarToolStripMenuItem
            // 
            this.regresarToolStripMenuItem.Name = "regresarToolStripMenuItem";
            this.regresarToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.regresarToolStripMenuItem.Text = "Regresar";
            this.regresarToolStripMenuItem.Click += new System.EventHandler(this.regresarToolStripMenuItem_Click);
            // 
            // pnl_NuevoAcceso
            // 
            this.pnl_NuevoAcceso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_NuevoAcceso.Controls.Add(this.lbl_ClonarAcceso);
            this.pnl_NuevoAcceso.Controls.Add(this.lbl_Nuevo);
            this.pnl_NuevoAcceso.Controls.Add(this.cmbClonarAcceso);
            this.pnl_NuevoAcceso.Controls.Add(this.cmbNuevoAcceso);
            this.pnl_NuevoAcceso.Controls.Add(this.menuClonar);
            this.pnl_NuevoAcceso.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl_NuevoAcceso.Location = new System.Drawing.Point(112, 134);
            this.pnl_NuevoAcceso.Name = "pnl_NuevoAcceso";
            this.pnl_NuevoAcceso.Size = new System.Drawing.Size(383, 130);
            this.pnl_NuevoAcceso.TabIndex = 4;
            this.pnl_NuevoAcceso.Visible = false;
            // 
            // lbl_ClonarAcceso
            // 
            this.lbl_ClonarAcceso.AutoSize = true;
            this.lbl_ClonarAcceso.Location = new System.Drawing.Point(195, 39);
            this.lbl_ClonarAcceso.Name = "lbl_ClonarAcceso";
            this.lbl_ClonarAcceso.Size = new System.Drawing.Size(106, 15);
            this.lbl_ClonarAcceso.TabIndex = 4;
            this.lbl_ClonarAcceso.Text = "Clonar Acceso De:";
            // 
            // lbl_Nuevo
            // 
            this.lbl_Nuevo.AutoSize = true;
            this.lbl_Nuevo.Location = new System.Drawing.Point(9, 39);
            this.lbl_Nuevo.Name = "lbl_Nuevo";
            this.lbl_Nuevo.Size = new System.Drawing.Size(89, 15);
            this.lbl_Nuevo.TabIndex = 3;
            this.lbl_Nuevo.Text = "Nuevo Acceso:";
            // 
            // cmbClonarAcceso
            // 
            this.cmbClonarAcceso.FormattingEnabled = true;
            this.cmbClonarAcceso.Location = new System.Drawing.Point(198, 70);
            this.cmbClonarAcceso.Name = "cmbClonarAcceso";
            this.cmbClonarAcceso.Size = new System.Drawing.Size(159, 23);
            this.cmbClonarAcceso.TabIndex = 2;
            this.cmbClonarAcceso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbClonarAcceso_KeyPress);
            // 
            // cmbNuevoAcceso
            // 
            this.cmbNuevoAcceso.FormattingEnabled = true;
            this.cmbNuevoAcceso.Location = new System.Drawing.Point(12, 70);
            this.cmbNuevoAcceso.Name = "cmbNuevoAcceso";
            this.cmbNuevoAcceso.Size = new System.Drawing.Size(156, 23);
            this.cmbNuevoAcceso.TabIndex = 1;
            this.cmbNuevoAcceso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbNuevoAcceso_KeyPress);
            // 
            // menuClonar
            // 
            this.menuClonar.BackColor = System.Drawing.SystemColors.Window;
            this.menuClonar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clonarAccesoToolStripMenuItem});
            this.menuClonar.Location = new System.Drawing.Point(0, 0);
            this.menuClonar.Name = "menuClonar";
            this.menuClonar.Size = new System.Drawing.Size(381, 24);
            this.menuClonar.TabIndex = 0;
            this.menuClonar.Text = "menuStrip2";
            // 
            // clonarAccesoToolStripMenuItem
            // 
            this.clonarAccesoToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clonarAccesoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("clonarAccesoToolStripMenuItem.Image")));
            this.clonarAccesoToolStripMenuItem.Name = "clonarAccesoToolStripMenuItem";
            this.clonarAccesoToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.clonarAccesoToolStripMenuItem.Text = "Clonar Acceso";
            this.clonarAccesoToolStripMenuItem.Click += new System.EventHandler(this.clonarAccesoToolStripMenuItem_Click);
            // 
            // txt_Campo
            // 
            this.txt_Campo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Campo.Location = new System.Drawing.Point(134, 101);
            this.txt_Campo.Name = "txt_Campo";
            this.txt_Campo.Size = new System.Drawing.Size(160, 22);
            this.txt_Campo.TabIndex = 5;
            this.txt_Campo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Campo_KeyPress);
            // 
            // lbl_Campo
            // 
            this.lbl_Campo.AutoSize = true;
            this.lbl_Campo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Campo.Location = new System.Drawing.Point(11, 104);
            this.lbl_Campo.Name = "lbl_Campo";
            this.lbl_Campo.Size = new System.Drawing.Size(117, 15);
            this.lbl_Campo.TabIndex = 6;
            this.lbl_Campo.Text = "Buscar Componente";
            // 
            // lbl_Forma
            // 
            this.lbl_Forma.AutoSize = true;
            this.lbl_Forma.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Forma.Location = new System.Drawing.Point(11, 55);
            this.lbl_Forma.Name = "lbl_Forma";
            this.lbl_Forma.Size = new System.Drawing.Size(46, 15);
            this.lbl_Forma.TabIndex = 7;
            this.lbl_Forma.Text = "Forma:";
            this.lbl_Forma.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(311, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Buscar Acceso";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(405, 101);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 22);
            this.textBox1.TabIndex = 8;
            // 
            // DM0312_PermisosConfiguracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(595, 470);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_Forma);
            this.Controls.Add(this.lbl_Campo);
            this.Controls.Add(this.txt_Campo);
            this.Controls.Add(this.pnl_NuevoAcceso);
            this.Controls.Add(this.cmbFormas);
            this.Controls.Add(this.dgvAccesoUsuario);
            this.Controls.Add(this.dgvAcceso);
            this.Controls.Add(this.menuPermisos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuPermisos;
            this.Name = "DM0312_PermisosConfiguracion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuracion de Permisos";
            this.Load += new System.EventHandler(this.DM0312_PermisosConfiguracionColumnas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcceso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccesoUsuario)).EndInit();
            this.menuPermisos.ResumeLayout(false);
            this.menuPermisos.PerformLayout();
            this.pnl_NuevoAcceso.ResumeLayout(false);
            this.pnl_NuevoAcceso.PerformLayout();
            this.menuClonar.ResumeLayout(false);
            this.menuClonar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAcceso;
        private System.Windows.Forms.DataGridView dgvAccesoUsuario;
        private System.Windows.Forms.ComboBox cmbFormas;
        private System.Windows.Forms.MenuStrip menuPermisos;
        private System.Windows.Forms.ToolStripMenuItem toolGuardar;
        private System.Windows.Forms.ToolStripMenuItem nuevoAccesoToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_NuevoAcceso;
        private System.Windows.Forms.Label lbl_ClonarAcceso;
        private System.Windows.Forms.Label lbl_Nuevo;
        private System.Windows.Forms.ComboBox cmbClonarAcceso;
        private System.Windows.Forms.ComboBox cmbNuevoAcceso;
        private System.Windows.Forms.MenuStrip menuClonar;
        private System.Windows.Forms.ToolStripMenuItem clonarAccesoToolStripMenuItem;
        private System.Windows.Forms.TextBox txt_Campo;
        private System.Windows.Forms.Label lbl_Campo;
        private System.Windows.Forms.Label lbl_Forma;
        private System.Windows.Forms.ToolStripMenuItem regresarToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}