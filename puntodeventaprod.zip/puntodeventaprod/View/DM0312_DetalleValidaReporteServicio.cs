﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleValidaReporteServicio : Form
    {
        private readonly CReporteServicios CReporte = new CReporteServicios();
        public int IDReporte;
        public int IDVenta = 0;
        public string origen = "";

        public bool ReporteSeleccionadoValido;

        //-ReporteDescuento
        public int Sucursal = 0;

        /// <summary>
        ///     Constructor de forma
        /// </summary>
        /// Developer: Dan Palaicos
        /// Date: 18/11/17
        public DM0312_DetalleValidaReporteServicio()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
        }

        ~DM0312_DetalleValidaReporteServicio()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_ValidaReporteServicio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                ReporteSeleccionadoValido = false;
                Close();
            }

            if (e.Control && e.KeyCode == Keys.G) GuardarR();
        }

        public void GuardarR()
        {
            if (txt_password.Text.Trim() != string.Empty && txt_usuario.Text.Trim() != string.Empty)
            {
                if (dgv_ReporteServicio.Rows.Count > 0)
                {
                    if (CReporte.ContraseñaValida(txt_usuario.Text.Trim(), txt_password.Text.Trim()))
                    {
                        origen = dgv_ReporteServicio.SelectedRows[dgv_ReporteServicio.SelectedRows.Count - 1]
                            .Cells["Origen"].Value.ToString();
                        ReporteSeleccionadoValido = true;
                        IDReporte = Convert.ToInt32(dgv_ReporteServicio
                            .SelectedRows[dgv_ReporteServicio.SelectedRows.Count - 1].Cells["ID"].Value);
                        if (origen == "Soporte")
                            CReporte.AfectarReporte(IDVenta, IDReporte,
                                (int)Enums.OpcionesReporteServicios.AsignaReporte);
                        else if (origen == "VTASDReporteDescuento")
                            CReporte.AfectarReporteDescuento(IDVenta, IDReporte);
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Contraseña y/o usuario invalidos", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Es necesario tener un reporte para continuar", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Usuario y contraseña son requeridos", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Valida si el usuario y la contraseña es valida para el usuario seleccionado
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/11/17
        private void Aceptar_Click(object sender, EventArgs e)
        {
            GuardarR();
        }

        /// <summary>
        ///     Cancelar el mov
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/11/17
        private void Btn_Cancelar_Click(object sender, EventArgs e)
        {
            ReporteSeleccionadoValido = false;
            Close();
        }

        /// <summary>
        ///     Load de forma
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/11/17
        private void DM0312_DetalleValidaReporteServicio_Load(object sender, EventArgs e)
        {
            List<MReportesServicio> ListaReportes = CReporte.ObtenerReportes(IDVenta, Sucursal);
            dgv_ReporteServicio.DataSource = null;
            dgv_ReporteServicio.DataSource = ListaReportes;

            toolTip1.SetToolTip(Aceptar, "SELECCIONAR PARA GUARDAR LOS CAMBIOS");
            toolTip1.SetToolTip(btn_Cancelar, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            txt_Comentarios.Text = "ASISTENTE PARA ASIGNAR UN SERVIO A LOS ARTICULOS DAÑADOS";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_ReporteServicio.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_ReporteServicio.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_ReporteServicio.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_ReporteServicio.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void txt_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }
    }
}