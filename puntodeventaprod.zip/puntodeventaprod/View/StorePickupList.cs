﻿//-PrimeraFaseDeAutomatizacion

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class StorePickupList : Form
    {
        public StorePickupList()
        {
            InitializeComponent();
            Text = "Pedidos a entregar en sucursal " + ClaseEstatica.Usuario.sucursal;
        }

        ~StorePickupList()
        {
            GC.Collect();
        }

        private void StorePickupList_Load(object sender, EventArgs e)
        {
            List<MStorePickupList> listado = new List<MStorePickupList>();

            CStorePickupList storePickupC = new CStorePickupList();


            listado = storePickupC.getPedidosStorePickup();

            orderGrid.DataSource = null;
            orderGrid.DataSource = listado.ToList();


            if (ClaseEstatica.Usuario.color == "Azul")
                orderGrid.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                orderGrid.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                orderGrid.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") orderGrid.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }
    }
}