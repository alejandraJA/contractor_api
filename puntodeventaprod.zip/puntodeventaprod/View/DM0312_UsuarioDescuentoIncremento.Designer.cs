﻿namespace PuntoVenta.View
{
    partial class DM0312_UsuarioDescuentoIncremento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_UsuarioDescuentoIncremento));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbNuevoPro = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPWD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtImport = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbAutoriza = new System.Windows.Forms.ComboBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.cmbNuevoPro);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.txtPWD);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.txtImport);
            this.flowLayoutPanel1.Controls.Add(this.label4);
            this.flowLayoutPanel1.Controls.Add(this.cmbAutoriza);
            this.flowLayoutPanel1.Controls.Add(this.btnAceptar);
            this.flowLayoutPanel1.Controls.Add(this.BtnCancelar);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(300, 158);
            this.flowLayoutPanel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Nuevo Propietario:";
            // 
            // cmbNuevoPro
            // 
            this.cmbNuevoPro.FormattingEnabled = true;
            this.cmbNuevoPro.Location = new System.Drawing.Point(120, 3);
            this.cmbNuevoPro.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.cmbNuevoPro.Name = "cmbNuevoPro";
            this.cmbNuevoPro.Size = new System.Drawing.Size(172, 21);
            this.cmbNuevoPro.TabIndex = 0;
            this.cmbNuevoPro.DropDown += new System.EventHandler(this.cmbNuevoPro_DropDown);
            this.cmbNuevoPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbNuevoPro_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 34);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 15);
            this.label2.TabIndex = 39;
            this.label2.Text = "Contraseña:";
            // 
            // txtPWD
            // 
            this.txtPWD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPWD.Location = new System.Drawing.Point(120, 30);
            this.txtPWD.Margin = new System.Windows.Forms.Padding(40, 3, 3, 3);
            this.txtPWD.Name = "txtPWD";
            this.txtPWD.PasswordChar = '*';
            this.txtPWD.Size = new System.Drawing.Size(172, 20);
            this.txtPWD.TabIndex = 1;
            this.txtPWD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPWD_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 15);
            this.label3.TabIndex = 42;
            this.label3.Text = "Importe:";
            // 
            // txtImport
            // 
            this.txtImport.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtImport.Location = new System.Drawing.Point(119, 56);
            this.txtImport.Margin = new System.Windows.Forms.Padding(60, 3, 3, 3);
            this.txtImport.MaxLength = 10;
            this.txtImport.Name = "txtImport";
            this.txtImport.Size = new System.Drawing.Size(172, 20);
            this.txtImport.TabIndex = 2;
            this.txtImport.Text = "$0";
            this.txtImport.Click += new System.EventHandler(this.txtImport_Click);
            this.txtImport.Enter += new System.EventHandler(this.txtImport_Enter);
            this.txtImport.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtImport_KeyPress);
            this.txtImport.Leave += new System.EventHandler(this.txtImport_Leave);
            this.txtImport.Validating += new System.ComponentModel.CancelEventHandler(this.txtImport_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 86);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 44;
            this.label4.Text = "Autoriza:";
            // 
            // cmbAutoriza
            // 
            this.cmbAutoriza.FormattingEnabled = true;
            this.cmbAutoriza.Location = new System.Drawing.Point(120, 82);
            this.cmbAutoriza.Margin = new System.Windows.Forms.Padding(55, 3, 3, 3);
            this.cmbAutoriza.Name = "cmbAutoriza";
            this.cmbAutoriza.Size = new System.Drawing.Size(172, 21);
            this.cmbAutoriza.TabIndex = 3;
            this.cmbAutoriza.DropDown += new System.EventHandler(this.cmbAutoriza_DropDown);
            this.cmbAutoriza.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbAutoriza_KeyPress);
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("btnAceptar.Image")));
            this.btnAceptar.Location = new System.Drawing.Point(175, 106);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(175, 0, 0, 0);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(50, 49);
            this.btnAceptar.TabIndex = 4;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnCancelar.FlatAppearance.BorderSize = 0;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.Location = new System.Drawing.Point(230, 106);
            this.BtnCancelar.Margin = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(50, 49);
            this.BtnCancelar.TabIndex = 5;
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // DM0312_UsuarioDescuentoIncremento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(300, 158);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DM0312_UsuarioDescuentoIncremento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DM0312_UsuarioDecrementoIncremento";
            this.Load += new System.EventHandler(this.DM0312_UsuarioDescuentoIncremento_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.ComboBox cmbNuevoPro;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbAutoriza;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPWD;
        private System.Windows.Forms.TextBox txtImport;
    }
}