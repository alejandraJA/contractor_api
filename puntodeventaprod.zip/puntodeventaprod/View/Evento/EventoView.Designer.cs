﻿using System.ComponentModel;

namespace PuntoVenta.View.Evento {
    partial class EventoView {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.sb_footerBar = new System.Windows.Forms.StatusBar();
            this.sbp_EstatusPrograma = new System.Windows.Forms.StatusBarPanel();
            this.flp_MenuLaterl = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Ayuda = new System.Windows.Forms.Button();
            this.txt_Comentario = new System.Windows.Forms.TextBox();
            this.grp_Input = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chk_Aval = new System.Windows.Forms.CheckBox();
            this.chk_Cliente = new System.Windows.Forms.CheckBox();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.cbx_Agente = new System.Windows.Forms.ComboBox();
            this.dtp_Fecha = new System.Windows.Forms.DateTimePicker();
            this.txt_ClaveDescripcion = new System.Windows.Forms.TextBox();
            this.cbx_ClaveEvento = new System.Windows.Forms.ComboBox();
            this.txt_AsuntoObservacion = new System.Windows.Forms.TextBox();
            this.txt_DescripcionAgente = new System.Windows.Forms.TextBox();
            this.lbl_Asunto = new System.Windows.Forms.Label();
            this.lbl_Fecha = new System.Windows.Forms.Label();
            this.lbl_Agente = new System.Windows.Forms.Label();
            this.lbl_Clave = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_Movimiento = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).BeginInit();
            this.flp_MenuLaterl.SuspendLayout();
            this.grp_Input.SuspendLayout();
            this.SuspendLayout();
            // 
            // sb_footerBar
            // 
            this.sb_footerBar.Location = new System.Drawing.Point(0, 374);
            this.sb_footerBar.Name = "sb_footerBar";
            this.sb_footerBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                this.sbp_EstatusPrograma
            });
            this.sb_footerBar.ShowPanels = true;
            this.sb_footerBar.Size = new System.Drawing.Size(755, 21);
            this.sb_footerBar.TabIndex = 116;
            this.sb_footerBar.PanelClick += new System.Windows.Forms.StatusBarPanelClickEventHandler(this.sb_footerBar_PanelClick);
            // 
            // sbp_EstatusPrograma
            // 
            this.sbp_EstatusPrograma.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.sbp_EstatusPrograma.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None;
            this.sbp_EstatusPrograma.MinWidth = 150;
            this.sbp_EstatusPrograma.Name = "sbp_EstatusPrograma";
            this.sbp_EstatusPrograma.Text = "Estatus: OK";
            this.sbp_EstatusPrograma.Width = 738;
            // 
            // flp_MenuLaterl
            // 
            this.flp_MenuLaterl.Controls.Add(this.btn_Guardar);
            this.flp_MenuLaterl.Controls.Add(this.btn_Regresar);
            this.flp_MenuLaterl.Controls.Add(this.btn_Cancelar);
            this.flp_MenuLaterl.Controls.Add(this.btn_Ayuda);
            this.flp_MenuLaterl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flp_MenuLaterl.Location = new System.Drawing.Point(3, 7);
            this.flp_MenuLaterl.Name = "flp_MenuLaterl";
            this.flp_MenuLaterl.Size = new System.Drawing.Size(82, 361);
            this.flp_MenuLaterl.TabIndex = 115;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Image = global::PuntoVenta.Properties.Resources.floppy_icon;
            this.btn_Guardar.Location = new System.Drawing.Point(3, 3);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(73, 74);
            this.btn_Guardar.TabIndex = 9;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = global::PuntoVenta.Properties.Resources.icons8_volver_30;
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 83);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(73, 73);
            this.btn_Regresar.TabIndex = 10;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.Color.White;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Cancelar.FlatAppearance.BorderSize = 0;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Image = global::PuntoVenta.Properties.Resources.icons8_cancelar_blue_30;
            this.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Cancelar.Location = new System.Drawing.Point(3, 162);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(77, 73);
            this.btn_Cancelar.TabIndex = 12;
            this.btn_Cancelar.Text = "Cancelar Venta";
            this.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Visible = false;
            // 
            // btn_Ayuda
            // 
            this.btn_Ayuda.BackColor = System.Drawing.Color.White;
            this.btn_Ayuda.FlatAppearance.BorderSize = 0;
            this.btn_Ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ayuda.Image = global::PuntoVenta.Properties.Resources.icons8_ayuda_30;
            this.btn_Ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Ayuda.Location = new System.Drawing.Point(3, 241);
            this.btn_Ayuda.Name = "btn_Ayuda";
            this.btn_Ayuda.Size = new System.Drawing.Size(73, 65);
            this.btn_Ayuda.TabIndex = 11;
            this.btn_Ayuda.Text = "Ayuda";
            this.btn_Ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Ayuda.UseVisualStyleBackColor = false;
            this.btn_Ayuda.Visible = false;
            // 
            // txt_Comentario
            // 
            this.txt_Comentario.BackColor = System.Drawing.Color.White;
            this.txt_Comentario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentario.Enabled = false;
            this.txt_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentario.Location = new System.Drawing.Point(96, 0);
            this.txt_Comentario.Multiline = true;
            this.txt_Comentario.Name = "txt_Comentario";
            this.txt_Comentario.Size = new System.Drawing.Size(653, 59);
            this.txt_Comentario.TabIndex = 114;
            // 
            // grp_Input
            // 
            this.grp_Input.BackColor = System.Drawing.Color.White;
            this.grp_Input.Controls.Add(this.textBox1);
            this.grp_Input.Controls.Add(this.comboBox3);
            this.grp_Input.Controls.Add(this.textBox3);
            this.grp_Input.Controls.Add(this.label1);
            this.grp_Input.Controls.Add(this.comboBox4);
            this.grp_Input.Controls.Add(this.label4);
            this.grp_Input.Controls.Add(this.chk_Aval);
            this.grp_Input.Controls.Add(this.chk_Cliente);
            this.grp_Input.Controls.Add(this.txt_ComentarioAyuda);
            this.grp_Input.Controls.Add(this.cbx_Agente);
            this.grp_Input.Controls.Add(this.dtp_Fecha);
            this.grp_Input.Controls.Add(this.txt_ClaveDescripcion);
            this.grp_Input.Controls.Add(this.cbx_ClaveEvento);
            this.grp_Input.Controls.Add(this.txt_AsuntoObservacion);
            this.grp_Input.Controls.Add(this.txt_DescripcionAgente);
            this.grp_Input.Controls.Add(this.lbl_Asunto);
            this.grp_Input.Controls.Add(this.lbl_Fecha);
            this.grp_Input.Controls.Add(this.lbl_Agente);
            this.grp_Input.Controls.Add(this.lbl_Clave);
            this.grp_Input.Location = new System.Drawing.Point(96, 55);
            this.grp_Input.Name = "grp_Input";
            this.grp_Input.Size = new System.Drawing.Size(653, 295);
            this.grp_Input.TabIndex = 113;
            this.grp_Input.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(219, 232);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(275, 20);
            this.textBox1.TabIndex = 29;
            this.textBox1.Visible = false;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(91, 259);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 28;
            this.comboBox3.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(219, 260);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(275, 20);
            this.textBox3.TabIndex = 27;
            this.textBox3.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 26;
            this.label1.Text = "Agente ";
            this.label1.Visible = false;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(91, 232);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 25;
            this.comboBox4.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "Agente ";
            this.label4.Visible = false;
            // 
            // chk_Aval
            // 
            this.chk_Aval.AutoSize = true;
            this.chk_Aval.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Aval.Location = new System.Drawing.Point(548, 35);
            this.chk_Aval.Name = "chk_Aval";
            this.chk_Aval.Size = new System.Drawing.Size(58, 23);
            this.chk_Aval.TabIndex = 22;
            this.chk_Aval.Text = "Aval";
            this.chk_Aval.UseVisualStyleBackColor = true;
            this.chk_Aval.Visible = false;
            // 
            // chk_Cliente
            // 
            this.chk_Cliente.AutoSize = true;
            this.chk_Cliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Cliente.Location = new System.Drawing.Point(466, 35);
            this.chk_Cliente.Name = "chk_Cliente";
            this.chk_Cliente.Size = new System.Drawing.Size(76, 23);
            this.chk_Cliente.TabIndex = 21;
            this.chk_Cliente.Text = "Cliente";
            this.chk_Cliente.UseVisualStyleBackColor = true;
            this.chk_Cliente.Visible = false;
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(6, 10);
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(526, 13);
            this.txt_ComentarioAyuda.TabIndex = 18;
            // 
            // cbx_Agente
            // 
            this.cbx_Agente.FormattingEnabled = true;
            this.cbx_Agente.Location = new System.Drawing.Point(91, 206);
            this.cbx_Agente.Name = "cbx_Agente";
            this.cbx_Agente.Size = new System.Drawing.Size(121, 21);
            this.cbx_Agente.TabIndex = 13;
            // 
            // dtp_Fecha
            // 
            this.dtp_Fecha.CustomFormat = "dd/MM/yyyy";
            this.dtp_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Fecha.Location = new System.Drawing.Point(548, 68);
            this.dtp_Fecha.Name = "dtp_Fecha";
            this.dtp_Fecha.Size = new System.Drawing.Size(95, 20);
            this.dtp_Fecha.TabIndex = 6;
            this.dtp_Fecha.Value = new System.DateTime(2017, 10, 9, 10, 17, 32, 0);
            // 
            // txt_ClaveDescripcion
            // 
            this.txt_ClaveDescripcion.Enabled = false;
            this.txt_ClaveDescripcion.Location = new System.Drawing.Point(219, 69);
            this.txt_ClaveDescripcion.Name = "txt_ClaveDescripcion";
            this.txt_ClaveDescripcion.ReadOnly = true;
            this.txt_ClaveDescripcion.Size = new System.Drawing.Size(275, 20);
            this.txt_ClaveDescripcion.TabIndex = 2;
            // 
            // cbx_ClaveEvento
            // 
            this.cbx_ClaveEvento.FormattingEnabled = true;
            this.cbx_ClaveEvento.Location = new System.Drawing.Point(91, 69);
            this.cbx_ClaveEvento.Name = "cbx_ClaveEvento";
            this.cbx_ClaveEvento.Size = new System.Drawing.Size(121, 21);
            this.cbx_ClaveEvento.TabIndex = 0;
            this.cbx_ClaveEvento.DropDown += new System.EventHandler(this.cbx_ClaveEvento_DropDown);
            // 
            // txt_AsuntoObservacion
            // 
            this.txt_AsuntoObservacion.BackColor = System.Drawing.Color.Snow;
            this.txt_AsuntoObservacion.Location = new System.Drawing.Point(91, 104);
            this.txt_AsuntoObservacion.MaxLength = 200;
            this.txt_AsuntoObservacion.Multiline = true;
            this.txt_AsuntoObservacion.Name = "txt_AsuntoObservacion";
            this.txt_AsuntoObservacion.Size = new System.Drawing.Size(552, 96);
            this.txt_AsuntoObservacion.TabIndex = 5;
            // 
            // txt_DescripcionAgente
            // 
            this.txt_DescripcionAgente.Enabled = false;
            this.txt_DescripcionAgente.Location = new System.Drawing.Point(219, 206);
            this.txt_DescripcionAgente.Name = "txt_DescripcionAgente";
            this.txt_DescripcionAgente.ReadOnly = true;
            this.txt_DescripcionAgente.Size = new System.Drawing.Size(275, 20);
            this.txt_DescripcionAgente.TabIndex = 8;
            // 
            // lbl_Asunto
            // 
            this.lbl_Asunto.AutoSize = true;
            this.lbl_Asunto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Asunto.Location = new System.Drawing.Point(28, 106);
            this.lbl_Asunto.Name = "lbl_Asunto";
            this.lbl_Asunto.Size = new System.Drawing.Size(49, 15);
            this.lbl_Asunto.TabIndex = 3;
            this.lbl_Asunto.Text = "Asunto ";
            // 
            // lbl_Fecha
            // 
            this.lbl_Fecha.AutoSize = true;
            this.lbl_Fecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fecha.Location = new System.Drawing.Point(500, 73);
            this.lbl_Fecha.Name = "lbl_Fecha";
            this.lbl_Fecha.Size = new System.Drawing.Size(42, 15);
            this.lbl_Fecha.TabIndex = 2;
            this.lbl_Fecha.Text = "Fecha ";
            // 
            // lbl_Agente
            // 
            this.lbl_Agente.AutoSize = true;
            this.lbl_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Agente.Location = new System.Drawing.Point(28, 208);
            this.lbl_Agente.Name = "lbl_Agente";
            this.lbl_Agente.Size = new System.Drawing.Size(49, 15);
            this.lbl_Agente.TabIndex = 1;
            this.lbl_Agente.Text = "Agente ";
            // 
            // lbl_Clave
            // 
            this.lbl_Clave.AutoSize = true;
            this.lbl_Clave.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Clave.Location = new System.Drawing.Point(37, 71);
            this.lbl_Clave.Name = "lbl_Clave";
            this.lbl_Clave.Size = new System.Drawing.Size(40, 15);
            this.lbl_Clave.TabIndex = 0;
            this.lbl_Clave.Text = "Clave ";
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(96, 353);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(111, 13);
            this.lbl_Cliente.TabIndex = 30;
            this.lbl_Cliente.Text = "Cliente: C00000000";
            // 
            // lbl_Movimiento
            // 
            this.lbl_Movimiento.AutoSize = true;
            this.lbl_Movimiento.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Movimiento.Location = new System.Drawing.Point(468, 353);
            this.lbl_Movimiento.Name = "lbl_Movimiento";
            this.lbl_Movimiento.Size = new System.Drawing.Size(281, 13);
            this.lbl_Movimiento.TabIndex = 117;
            this.lbl_Movimiento.Text = "Movmimiento : Solicitud Credito MovID: ZBB123123";
            // 
            // EventoView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(755, 395);
            this.ControlBox = false;
            this.Controls.Add(this.lbl_Movimiento);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.sb_footerBar);
            this.Controls.Add(this.flp_MenuLaterl);
            this.Controls.Add(this.txt_Comentario);
            this.Controls.Add(this.grp_Input);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Name = "EventoView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Evento View";
            this.Load += new System.EventHandler(this.EventoView_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EventoView_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).EndInit();
            this.flp_MenuLaterl.ResumeLayout(false);
            this.grp_Input.ResumeLayout(false);
            this.grp_Input.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        public System.Windows.Forms.ComboBox cbx_ClaveEvento;

        protected System.Windows.Forms.Label lbl_Cliente;
        protected System.Windows.Forms.Label lbl_Movimiento;

        private System.Windows.Forms.Label label2;

        protected System.Windows.Forms.StatusBarPanel sbp_EstatusPrograma;

        private System.Windows.Forms.ToolTip toolTip1;

        public System.Windows.Forms.TextBox textBox1;

        protected System.Windows.Forms.StatusBar sb_footerBar;
        protected System.Windows.Forms.FlowLayoutPanel flp_MenuLaterl;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Button btn_Cancelar;
        public System.Windows.Forms.Button btn_Ayuda;
        public System.Windows.Forms.Button btn_Regresar;
        protected System.Windows.Forms.TextBox txt_AsuntoObservacion;
        private System.Windows.Forms.GroupBox grp_Input;
        protected System.Windows.Forms.ComboBox comboBox3;
        protected System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox comboBox4;
        public System.Windows.Forms.TextBox txt_ComentarioAyuda;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.CheckBox chk_Aval;
        protected System.Windows.Forms.CheckBox chk_Cliente;
        protected System.Windows.Forms.TextBox txt_Comentario;
        public System.Windows.Forms.ComboBox cbx_Agente;
        protected System.Windows.Forms.DateTimePicker dtp_Fecha;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.ComboBox comboBox6;
        public System.Windows.Forms.TextBox txt_DescripcionAgente;
        public System.Windows.Forms.TextBox txt_ClaveDescripcion;
        private System.Windows.Forms.Label lbl_Clave;
        public System.Windows.Forms.Label lbl_Agente;
        protected System.Windows.Forms.Label lbl_Asunto;
        private System.Windows.Forms.Label lbl_Fecha;

        #endregion

    }
}