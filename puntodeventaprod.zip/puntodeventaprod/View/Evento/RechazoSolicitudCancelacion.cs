﻿using System;
using PuntoVenta.Model;

namespace PuntoVenta.View.Evento
{
    public partial class RechazoSolicitudCancelacion : EventoView
    {
        #region attributes

        private const string claveEvento = "VTA99997";

        #endregion

        public RechazoSolicitudCancelacion(DM0312_MExploradorVenta Venta)
        {
            try
            {
                InitializeComponent();
                VentaM = Venta;
                //initValues();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        ~RechazoSolicitudCancelacion()
        {
            GC.Collect();
        }

        private void RechazoSolicitudCancelacion_Load(object sender, EventArgs e)
        {
            initValues();
            cbx_Agente_Fill();
        }

        private void initValues()
        {
            asuntoObligatorio = true;
            // 
            // cbx_ClaveEvento
            //
            cbx_ClaveEvento.Text = claveEvento ?? "";
            cbx_ClaveEvento.Enabled = false;

            txt_ClaveDescripcion.Text = EventoC.getDescripcionEvento(claveEvento);
        }
    }
}