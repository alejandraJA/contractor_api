﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View.Evento
{
    public partial class EventoView : Form
    {
        protected EventoView( /*DM0312_MExploradorVenta Venta */)
        {
            try
            {
                InitializeComponent();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        ~EventoView()
        {
            GC.Collect();
        }

        private void EventoView_Load(object sender, EventArgs e)
        {
            //initStatusBarPartition();
            cliente = ClienteC.getClienteDB(VentaM.Cliente);
            initFrameValues();
            //cbx_Agente_Fill();
        }

        private void initStatusBarPartition()
        {
            try
            {
                sbp_EstatusPrograma.Text = "OK";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        private void initFrameValues()
        {
            try
            {
                lbl_Cliente.Text = "Cliente: " + VentaM.Cliente + " " + cliente.Nombre;
                lbl_Movimiento.Text = "Movimiento: " + VentaM.Mov + " MovID: " + VentaM.MovId;

                dtp_Fecha.Value = ClaseEstatica.ConexionEstatica != null ? sqlH.getFechaActualServidor() : DateTime.Now;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        private void cbx_ClaveEvento_DropDown(object sender, EventArgs e)
        {
            try
            {
                using (ClaveSeguimiento ClaveSeguimiento = new ClaveSeguimiento())
                {
                    ClaveSeguimiento.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        #region classAttributes

        private static readonly sqlHelper sqlH = new sqlHelper();
        private static readonly EventoController agregarEvento = new EventoController();
        protected static ClienteController ClienteC = new ClienteController();
        protected static EventoController EventoC = new EventoController();
        protected static DM0312_MExploradorVenta VentaM = new DM0312_MExploradorVenta();

        protected static bool asuntoObligatorio = false;
        private bool bGuardadoCorrecto;
        private static Cliente cliente = new Cliente();

        #endregion

        #region Trigger

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                guardarEvento();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
            finally
            {
                if (bGuardadoCorrecto)
                {
                    Dispose();
                    Close();
                }
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            cerrarVentana();
        }

        private void sb_footerBar_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {
            try
            {
                MessageBox.Show(sbp_EstatusPrograma.Text);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        private void ck_Cliente_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void ck_Aval_CheckedChanged(object sender, EventArgs e)
        {
        }

        //ShorCuts
        private void EventoView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) btn_Regresar_Click(btn_Regresar, null);
            if (e.Control && e.KeyCode == Keys.G) btn_Guardar_Click(btn_Guardar, null);
        }

        #endregion

        #region metodos

        private void guardarEvento()
        {
            if (EventoC.InsertaEvento(getModeloEventoNuevo()))
            {
                MessageBox.Show("Evento Guardado Correctamente");
                bGuardadoCorrecto = true;
            }
        }

        private ModelAgregaEvento getModeloEventoNuevo()
        {
            ModelAgregaEvento eventoNuevo = new ModelAgregaEvento();
            try
            {
                eventoNuevo.agente = cbx_Agente.Text;
                eventoNuevo.clave = cbx_ClaveEvento.Text;
                eventoNuevo.modulo = "VTAS";
                eventoNuevo.idVenta = VentaM.ID;

                eventoNuevo.fecha = sqlH.getFechaActualServidor().ToString("yyyy/MM/dd HH:mm");

                eventoNuevo.evento = txt_AsuntoObservacion.Text;
                eventoNuevo.sucursal = ClaseEstatica.iSucural;
                eventoNuevo.usuario = ClaseEstatica.Usuario.usuario;
                eventoNuevo.tipo = "COMENTARIO";
                eventoNuevo.estuatus = VentaM.Estatus;
                eventoNuevo.situacion = VentaM.Situacion;
                eventoNuevo.citaCliente = 0;
                eventoNuevo.citaaval = 0;
                eventoNuevo.citaFecha = dtp_Fecha.Value;
                eventoNuevo.citaHora = " ";
                eventoNuevo.TipoEvento = "EVENTO";
                eventoNuevo.mov = VentaM.Mov;
                eventoNuevo.cliente = VentaM.Cliente;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return eventoNuevo;
        }

        private void cerrarVentana()
        {
            if (txt_AsuntoObservacion.Text.Length > 0)
                if (MessageBox.Show("Se perderán los avances asunto vacío \n" + "           ¿Está seguro de Salir?",
                        "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            Dispose();
            Close();
        }

        public bool HelpFillAgent()
        {
            bool validaUsuario = false;

            try
            {
                List<ModelAgregaEvento> listAgent = agregarEvento.fillAgent(ClaseEstatica.Usuario.Usser);
                if (ClaseEstatica.Usuario.Acceso != "VENTP_LIMA")
                {
                    ModelAgregaEvento valAgente =
                        listAgent.FirstOrDefault(x => x.ClaveAgente.Equals(ClaseEstatica.Usuario.Usser));
                    if (valAgente.Clave != "")
                    {
                        cbx_Agente.Text = valAgente.Clave;
                        txt_DescripcionAgente.Text = valAgente.NombreAgente;
                        validaUsuario = true;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return validaUsuario;
        }

        private void cbx_Clave_Fill()
        {
        }

        public void cbx_Agente_Fill()
        {
            try
            {
                Agente Agent = EventoC.datosAgente(ClaseEstatica.Usuario.Usser);

                cbx_Agente.Text = Agent.Clave;
                txt_DescripcionAgente.Text = Agent.NombreAgente;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        #endregion
    }
}