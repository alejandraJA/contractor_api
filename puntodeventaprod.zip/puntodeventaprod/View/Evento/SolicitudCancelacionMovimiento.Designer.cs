﻿using System.ComponentModel;

namespace PuntoVenta.View.Evento {
    partial class SolicitudCancelacionMovimiento {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).BeginInit();
            this.SuspendLayout();
            //
            // txt_Comentario
            //
            this.txt_Comentario.Text = "Para cancelar movimientos provenientes de sucursales virtuales se debe realizar una solicitud de cancelación, favor de capturar motivo de cancelación y guardar.";
            //
            // lbl_Asunto
            //
            this.lbl_Asunto.Text = "*Motivo";
            //
            // txt_AsuntoObservacion
            //
            this.txt_AsuntoObservacion.MaxLength = 50;
            //
            // cbx_Agente
            //
            this.cbx_Agente.Enabled = false;
            //
            // dtp_Fecha
            //
            this.dtp_Fecha.Enabled = false;
            // 
            // SolicitudCancelacionMovimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 395);
            this.Name = "SolicitudCancelacionMovimiento";
            this.Text = "Solicitud Cancelacion de Movimiento";
            this.Load += new System.EventHandler(this.SolicitudCancelacionMovimiento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

    }
}