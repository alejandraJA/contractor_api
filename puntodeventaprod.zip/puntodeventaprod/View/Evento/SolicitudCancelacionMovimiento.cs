﻿using System;
using PuntoVenta.Model;

namespace PuntoVenta.View.Evento
{
    public partial class SolicitudCancelacionMovimiento : EventoView
    {
        #region attributes

        private const string claveEvento = "VTA99998";

        #endregion

        public SolicitudCancelacionMovimiento(DM0312_MExploradorVenta Venta)
        {
            try
            {
                InitializeComponent();
                VentaM = Venta;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        ~SolicitudCancelacionMovimiento()
        {
            GC.Collect();
        }

        private void SolicitudCancelacionMovimiento_Load(object sender, EventArgs e)
        {
            initValues();
            cbx_Agente_Fill();
        }

        private void initValues()
        {
            asuntoObligatorio = true;

            cbx_ClaveEvento.Text = claveEvento ?? "";
            cbx_ClaveEvento.Enabled = false;
            txt_ClaveDescripcion.Text = EventoC.getDescripcionEvento(claveEvento);
        }
    }
}