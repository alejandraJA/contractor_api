﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class DM0312_RegistroDeHuellaFechas : Form
    {
        public DateTime FechaFin;
        public DateTime FechaIni;

        public DM0312_RegistroDeHuellaFechas()
        {
            InitializeComponent();
        }

        ~DM0312_RegistroDeHuellaFechas()
        {
            GC.Collect();
        }

        private void DM1132_RegistroHuella_Fechas_Load(object sender, EventArgs e)
        {
            CalendarFin.Visible = false;
            CalendarInicio.Visible = false;
        }

        private void txtFechaInicio_Validating(object sender, CancelEventArgs e)
        {
            DateTime dtInicio;

            if (!DateTime.TryParse(txtFechaInicio.Text, out dtInicio))
            {
                errorProvider_.SetError(txtFechaInicio, "**Fecha Inicio invalida");
                ClaseEstatica.FechaInicio = new DateTime();
            }
            else
            {
                errorProvider_.SetError(txtFechaInicio, string.Empty);
                ClaseEstatica.FechaInicio = dtInicio;
            }
        }

        private void txtFechaFin_Validating(object sender, CancelEventArgs e)
        {
            DateTime dtFIN;

            if (!DateTime.TryParse(txtFechaFin.Text, out dtFIN))
            {
                errorProvider_.SetError(txtFechaFin, "**Fecha invalida");
                ClaseEstatica.FechaFin = new DateTime();
            }
            else
            {
                DateTime dt = new DateTime();
                dt = dtFIN.Date.AddHours(23).AddMinutes(59).AddSeconds(59);
                errorProvider_.SetError(txtFechaFin, string.Empty);
                ClaseEstatica.FechaFin = dt;
            }
        }

        #region Eventos

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            if (ValidaLlenadoFechas() & ValidandoerrorProvider())
                Close();
            else
                return;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            ClaseEstatica.FechaFin = new DateTime();
            ClaseEstatica.FechaInicio = new DateTime();

            Dispose();
            Close();
        }

        private void BtnCalendarInicio_Click(object sender, EventArgs e)
        {
            CalendarInicio.Visible = true;
            CalendarFin.Visible = false;
        }

        private void BtnCalendarFin_Click(object sender, EventArgs e)
        {
            CalendarFin.Visible = true;
            CalendarInicio.Visible = false;
        }

        private void CalendarInicio_DateSelected(object sender, DateRangeEventArgs e)
        {
            txtFechaInicio.Select();

            txtFechaInicio.Text = e.Start.ToString();
            ClaseEstatica.FechaInicio = e.Start;
            CalendarInicio.Visible = false;
            CalendarFin.Visible = false;
        }

        private void CalendarFin_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (ClaseEstatica.FechaInicio > e.End)
            {
                errorProvider_.SetError(txtFechaInicio, "La fecha de fin no puede ser menor a la fecha inicio");

                return;
            }

            errorProvider_.SetError(txtFechaInicio, string.Empty);

            txtFechaFin.Select();

            txtFechaFin.Text = e.End.ToString();
            ClaseEstatica.FechaFin = e.End;
            CalendarFin.Visible = false;
            CalendarInicio.Visible = false;
        }

        private void DM0312_RegistroDeHuellaFechas_Click(object sender, EventArgs e)
        {
            CalendarFin.Visible = false;
            CalendarInicio.Visible = false;
        }

        #endregion


        #region Metodos

        private bool ValidaLlenadoFechas()
        {
            bool res = false;
            DateTime dt = new DateTime();

            if ((ClaseEstatica.FechaInicio != dt) & (ClaseEstatica.FechaFin != dt))
            {
                errorProvider_.SetError(BtnAceptar, string.Empty);
                res = true;
            }
            else
            {
                errorProvider_.SetError(BtnAceptar, "Fechas incorrectas");
                return false;
            }


            if (ClaseEstatica.FechaInicio > ClaseEstatica.FechaFin)
            {
                errorProvider_.SetError(txtFechaInicio, "La fecha de fin no puede ser menor a la fecha inicio");

                return false;
            }

            res = true;

            return res;
        }

        private bool ValidandoerrorProvider()
        {
            List<string> Lista = new List<string>();

            foreach (Control item in Controls)
                if (errorProvider_.GetError(item) != string.Empty)
                    Lista.Add(item.Name);

            if (Lista.Count > 0)
                return false;
            return true;
        }

        #endregion
    }
}