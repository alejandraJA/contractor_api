﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class frmPosicionDeMovimiento : Form
    {
        private readonly clsPosicionDelMovimiento cPosicion;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly int iIdVenta;
        private List<clsModeloPosicionDelMovimiento> listaDestino = new List<clsModeloPosicionDelMovimiento>();
        private List<clsModeloPosicionDelMovimiento> listaOrigen = new List<clsModeloPosicionDelMovimiento>();
        private List<clsModeloPosicionDelMovimiento> listaOrigenHijos = new List<clsModeloPosicionDelMovimiento>();

        #region Constructor

        public frmPosicionDeMovimiento(int iId, string sMovimiento)
        {
            InitializeComponent();
            cPosicion = new clsPosicionDelMovimiento();
            iIdVenta = iId;
            lblMovimiento.Text = "VENTAS - " + sMovimiento;
        }

        #endregion

        #region Eventos

        private async void frmPosicionDeMovimiento_Load(object sender, EventArgs e)
        {
            try
            {
                if (!frmLoading.Visible) frmLoading.Show(this);

                await Task.Run(() => cPosicion.generarMovimientos(iIdVenta));
                listaOrigen = await Task.Run(() => cPosicion.obtenerMovimientos(iIdVenta, 1));
                listaDestino = await Task.Run(() => cPosicion.obtenerMovimientos(iIdVenta, 2));
                TreeNode tnOrigen = new TreeNode();
                TreeNode tnDestino = new TreeNode();

                if (listaOrigen.Count > 0)
                    foreach (clsModeloPosicionDelMovimiento item in listaOrigen)
                    {
                        tnOrigen = new TreeNode();
                        tnOrigen.Text = item.sMovimiento;
                        tnOrigen.Tag = item.sClave;
                        tnOrigen.Name = item.sDEstatus;
                        llenarNodos(tnOrigen);
                        tvOrigen.Nodes.Add(tnOrigen);
                    }

                if (listaDestino.Count > 0)
                    foreach (clsModeloPosicionDelMovimiento item in listaDestino)
                    {
                        tnDestino = new TreeNode();
                        tnDestino.Text = item.sMovimiento;
                        tnDestino.Tag = item.sClave;
                        tnDestino.Name = item.sDEstatus;

                        llenarNodos(tnDestino);
                        tvDestino.Nodes.Add(tnDestino);
                    }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                if (frmLoading.Visible) frmLoading.Hide();
            }
        }

        /// <summary>
        ///     Evento que se ejecuta al oprimir una tecla en el formulario
        /// </summary>
        private void frmPosicionDeMovimiento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        /// <summary>
        ///     Evento que se ejecuta al dar click al boton regresar (encardao de cerrar el formulario)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///     Evento que se ejecuta despues de seleccionar un nodo en el treeview destino
        /// </summary>
        private void tvDestino_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            llenarInformacionNodo(e, dgMovimientosDestino);
        }

        /// <summary>
        ///     Evento que se ejecuta despues de seleccionar un nodo en el treeview origen
        /// </summary>
        private void tvOrigen_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            llenarInformacionNodo(e, dgMovimientosOrigen);
        }

        #endregion

        #region Metodos

        /// <summary>
        ///     Metodo encargado de llenar todos los nodos con la informacion del pedido
        /// </summary>
        /// <param name="tn">Nodo principal</param>
        private void llenarNodos(TreeNode tn)
        {
            listaOrigenHijos = cPosicion.siguienteMovimiento(tn.Tag.ToString());
            if (listaOrigenHijos.Count > 0)
                foreach (clsModeloPosicionDelMovimiento item in listaOrigenHijos)
                {
                    TreeNode tnHijo = new TreeNode
                    {
                        Text = item.sMovimiento,
                        Tag = item.sClave,
                        Name = item.sDEstatus
                    };

                    tn.Nodes.Add(tnHijo);

                    llenarNodos(tnHijo);
                }
        }

        /// <summary>
        ///     Metodo encargado de agregar la informacion a los datagridview
        /// </summary>
        /// <param name="e">Evento del beforeselected</param>
        /// <param name="dg">Datagrid donde se colococara la informacion</param>
        private void llenarInformacionNodo(TreeViewCancelEventArgs e, DataGridView dg)
        {
            try
            {
                if (!string.IsNullOrEmpty(e.Node.Tag.ToString()))
                {
                    List<modelo> listaInformacion = new List<modelo>();

                    if (e.Node.Nodes.Count > 0)
                        foreach (TreeNode item in e.Node.Nodes)
                            listaInformacion.Add(new modelo
                            {
                                sMov = item.Text,
                                sEstatus = item.Name
                            });
                    else
                        listaInformacion.Add(new modelo
                        {
                            sMov = e.Node.Text,
                            sEstatus = e.Node.Name
                        });

                    dg.DataSource = null;
                    dg.DataSource = listaInformacion;
                    dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion
    }

    public class modelo
    {
        [DisplayName("Movimiento")] public string sMov { get; set; }

        [DisplayName("Estatus")] public string sEstatus { get; set; }
    }
}