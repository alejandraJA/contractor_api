﻿
namespace PuntoVenta.View
{
    partial class frmSancion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSancion));
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.rbSi = new System.Windows.Forms.RadioButton();
            this.rbNo = new System.Windows.Forms.RadioButton();
            this.cbMotivos = new System.Windows.Forms.ComboBox();
            this.txtMotivoOtro = new System.Windows.Forms.TextBox();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.lbl_contador = new System.Windows.Forms.Label();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar.Location = new System.Drawing.Point(12, 11);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(155, 23);
            this.lbl_Buscar.TabIndex = 1;
            this.lbl_Buscar.Text = "¿Aplica Sanción?";
            // 
            // rbSi
            // 
            this.rbSi.AutoSize = true;
            this.rbSi.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.rbSi.Location = new System.Drawing.Point(184, 12);
            this.rbSi.Name = "rbSi";
            this.rbSi.Size = new System.Drawing.Size(45, 27);
            this.rbSi.TabIndex = 2;
            this.rbSi.TabStop = true;
            this.rbSi.Text = "SI";
            this.rbSi.UseVisualStyleBackColor = true;
            this.rbSi.CheckedChanged += new System.EventHandler(this.rbSi_CheckedChanged);
            // 
            // rbNo
            // 
            this.rbNo.AutoSize = true;
            this.rbNo.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.rbNo.Location = new System.Drawing.Point(235, 12);
            this.rbNo.Name = "rbNo";
            this.rbNo.Size = new System.Drawing.Size(58, 27);
            this.rbNo.TabIndex = 3;
            this.rbNo.TabStop = true;
            this.rbNo.Text = "NO";
            this.rbNo.UseVisualStyleBackColor = true;
            this.rbNo.CheckedChanged += new System.EventHandler(this.rbNo_CheckedChanged);
            // 
            // cbMotivos
            // 
            this.cbMotivos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMotivos.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMotivos.FormattingEnabled = true;
            this.cbMotivos.Location = new System.Drawing.Point(103, 45);
            this.cbMotivos.Name = "cbMotivos";
            this.cbMotivos.Size = new System.Drawing.Size(289, 27);
            this.cbMotivos.TabIndex = 4;
            this.cbMotivos.SelectedIndexChanged += new System.EventHandler(this.cbMotivos_SelectedIndexChanged);
            // 
            // txtMotivoOtro
            // 
            this.txtMotivoOtro.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtMotivoOtro.Location = new System.Drawing.Point(16, 94);
            this.txtMotivoOtro.MaxLength = 100;
            this.txtMotivoOtro.Multiline = true;
            this.txtMotivoOtro.Name = "txtMotivoOtro";
            this.txtMotivoOtro.Size = new System.Drawing.Size(376, 95);
            this.txtMotivoOtro.TabIndex = 5;
            this.txtMotivoOtro.Visible = false;
            this.txtMotivoOtro.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMotivoOtro_KeyDown);
            this.txtMotivoOtro.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMotivoOtro_KeyUp);
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivo.Location = new System.Drawing.Point(12, 49);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(72, 23);
            this.lblMotivo.TabIndex = 11;
            this.lblMotivo.Text = "Motivo";
            // 
            // lbl_contador
            // 
            this.lbl_contador.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lbl_contador.Location = new System.Drawing.Point(16, 192);
            this.lbl_contador.Name = "lbl_contador";
            this.lbl_contador.Size = new System.Drawing.Size(87, 20);
            this.lbl_contador.TabIndex = 12;
            this.lbl_contador.Text = "0/100";
            this.lbl_contador.Visible = false;
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.Location = new System.Drawing.Point(16, 245);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(113, 31);
            this.btn_aceptar.TabIndex = 13;
            this.btn_aceptar.Text = "ACEPTAR";
            this.btn_aceptar.UseVisualStyleBackColor = true;
            this.btn_aceptar.Click += new System.EventHandler(this.btn_aceptar_Click);
            // 
            // frmSancion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(404, 288);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.lbl_contador);
            this.Controls.Add(this.lblMotivo);
            this.Controls.Add(this.txtMotivoOtro);
            this.Controls.Add(this.cbMotivos);
            this.Controls.Add(this.rbNo);
            this.Controls.Add(this.rbSi);
            this.Controls.Add(this.lbl_Buscar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(420, 327);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(420, 327);
            this.Name = "frmSancion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Confirmar";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSancion_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSancion_FormClosed);
            this.Load += new System.EventHandler(this.frmSancion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button btn_aceptar;

        private System.Windows.Forms.Label lbl_contador;

        private System.Windows.Forms.Label label1;

        #endregion

        private System.Windows.Forms.Label lbl_Buscar;
        private System.Windows.Forms.RadioButton rbSi;
        private System.Windows.Forms.RadioButton rbNo;
        private System.Windows.Forms.ComboBox cbMotivos;
        private System.Windows.Forms.TextBox txtMotivoOtro;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Label lblMotivo;
    }
}