﻿namespace PuntoVenta.View
{
    partial class DM0312_DetalleSeriesConsulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_DetalleSeriesConsulta));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.btn_InformacionSerie = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.lbl_descripcion = new System.Windows.Forms.Label();
            this.lbl_articulo = new System.Windows.Forms.Label();
            this.dgv_serieArticulo = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_serieArticulo)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.BackColor = System.Drawing.Color.White;
            this.BtnEliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnEliminar.FlatAppearance.BorderSize = 0;
            this.BtnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEliminar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminar.Image = ((System.Drawing.Image)(resources.GetObject("BtnEliminar.Image")));
            this.BtnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnEliminar.Location = new System.Drawing.Point(12, 90);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(78, 60);
            this.BtnEliminar.TabIndex = 42;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnEliminar.UseVisualStyleBackColor = false;
            // 
            // btn_InformacionSerie
            // 
            this.btn_InformacionSerie.BackColor = System.Drawing.Color.White;
            this.btn_InformacionSerie.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_InformacionSerie.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_InformacionSerie.FlatAppearance.BorderSize = 0;
            this.btn_InformacionSerie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InformacionSerie.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InformacionSerie.Image = ((System.Drawing.Image)(resources.GetObject("btn_InformacionSerie.Image")));
            this.btn_InformacionSerie.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_InformacionSerie.Location = new System.Drawing.Point(5, 167);
            this.btn_InformacionSerie.Name = "btn_InformacionSerie";
            this.btn_InformacionSerie.Size = new System.Drawing.Size(85, 70);
            this.btn_InformacionSerie.TabIndex = 41;
            this.btn_InformacionSerie.Text = "Informacion de la Serie";
            this.btn_InformacionSerie.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InformacionSerie.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InformacionSerie.UseVisualStyleBackColor = false;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(12, 12);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(78, 60);
            this.btn_Regresar.TabIndex = 39;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ayuda.Location = new System.Drawing.Point(5, 254);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(78, 56);
            this.btn_ayuda.TabIndex = 40;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // lbl_descripcion
            // 
            this.lbl_descripcion.AutoSize = true;
            this.lbl_descripcion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_descripcion.Location = new System.Drawing.Point(345, 42);
            this.lbl_descripcion.Name = "lbl_descripcion";
            this.lbl_descripcion.Size = new System.Drawing.Size(73, 15);
            this.lbl_descripcion.TabIndex = 45;
            this.lbl_descripcion.Text = "Descripcion";
            // 
            // lbl_articulo
            // 
            this.lbl_articulo.AutoSize = true;
            this.lbl_articulo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_articulo.Location = new System.Drawing.Point(112, 42);
            this.lbl_articulo.Name = "lbl_articulo";
            this.lbl_articulo.Size = new System.Drawing.Size(53, 15);
            this.lbl_articulo.TabIndex = 44;
            this.lbl_articulo.Text = "Articulo";
            // 
            // dgv_serieArticulo
            // 
            this.dgv_serieArticulo.AllowUserToAddRows = false;
            this.dgv_serieArticulo.AllowUserToDeleteRows = false;
            this.dgv_serieArticulo.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_serieArticulo.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_serieArticulo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_serieArticulo.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_serieArticulo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_serieArticulo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_serieArticulo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_serieArticulo.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_serieArticulo.EnableHeadersVisualStyles = false;
            this.dgv_serieArticulo.Location = new System.Drawing.Point(115, 69);
            this.dgv_serieArticulo.Name = "dgv_serieArticulo";
            this.dgv_serieArticulo.ReadOnly = true;
            this.dgv_serieArticulo.RowHeadersVisible = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_serieArticulo.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_serieArticulo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_serieArticulo.Size = new System.Drawing.Size(994, 241);
            this.dgv_serieArticulo.TabIndex = 43;
            // 
            // DM0312_DetalleSeriesConsulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1130, 348);
            this.Controls.Add(this.lbl_descripcion);
            this.Controls.Add(this.lbl_articulo);
            this.Controls.Add(this.dgv_serieArticulo);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.btn_InformacionSerie);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.btn_ayuda);
            this.Name = "DM0312_DetalleSeriesConsulta";
            this.Text = "Serie del Articulo(consulta)";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_serieArticulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button btn_InformacionSerie;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Label lbl_descripcion;
        private System.Windows.Forms.Label lbl_articulo;
        private System.Windows.Forms.DataGridView dgv_serieArticulo;
    }
}