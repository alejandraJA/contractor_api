﻿using System;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class LoginAutorizacion : Form
    {
        private readonly DM0312_CLoginAutorizacion CLoginAutorizacion = new DM0312_CLoginAutorizacion();

        public LoginAutorizacion()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Login()
        {
            if (CLoginAutorizacion.Login(txtUsuario.Text, txtContrasena.Text))
            {
                if (CLoginAutorizacion.PermisoArticuloPequeno(txtUsuario.Text))
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    txtContrasena.Text = string.Empty;
                    txtUsuario.Text = string.Empty;
                    MessageBox.Show("No tiene permisos para autorizar", "Mensaje", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            else
            {
                txtContrasena.Text = string.Empty;
                MessageBox.Show("Usuario o contraseña incorrecto", "Mensaje", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
    }
}