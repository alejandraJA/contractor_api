﻿namespace PuntoVenta.View
{
    partial class DM0312_Reanalisis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_Reanalisis));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_FechaHora = new System.Windows.Forms.Label();
            this.cbo_TipoReanalisis = new System.Windows.Forms.ComboBox();
            this.cbo_TipoRespuesta = new System.Windows.Forms.ComboBox();
            this.txt_Notas = new System.Windows.Forms.TextBox();
            this.txt_fechahora = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_AgenteReanalisis = new System.Windows.Forms.TextBox();
            this.btn_BuscarAgente = new System.Windows.Forms.Button();
            this.btn_acep_reanalisis = new System.Windows.Forms.Button();
            this.btn_cancel_reanalisis = new System.Windows.Forms.Button();
            this.lbl_ImporteRescatado = new System.Windows.Forms.Label();
            this.txt_ImporteRescatado = new System.Windows.Forms.TextBox();
            this.cb_UsuarioCredito = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Cerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(84, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo reanalisis ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(84, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tipo respuesta";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(133, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Notas";
            // 
            // lbl_FechaHora
            // 
            this.lbl_FechaHora.AutoSize = true;
            this.lbl_FechaHora.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_FechaHora.Location = new System.Drawing.Point(101, 319);
            this.lbl_FechaHora.Name = "lbl_FechaHora";
            this.lbl_FechaHora.Size = new System.Drawing.Size(70, 15);
            this.lbl_FechaHora.TabIndex = 3;
            this.lbl_FechaHora.Text = "Fecha/Hora";
            // 
            // cbo_TipoReanalisis
            // 
            this.cbo_TipoReanalisis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbo_TipoReanalisis.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_TipoReanalisis.FormattingEnabled = true;
            this.cbo_TipoReanalisis.Location = new System.Drawing.Point(177, 48);
            this.cbo_TipoReanalisis.Name = "cbo_TipoReanalisis";
            this.cbo_TipoReanalisis.Size = new System.Drawing.Size(305, 23);
            this.cbo_TipoReanalisis.TabIndex = 4;
            this.cbo_TipoReanalisis.SelectedIndexChanged += new System.EventHandler(this.cbo_tipoReanalisis_SelectedIndexChanged);
            // 
            // cbo_TipoRespuesta
            // 
            this.cbo_TipoRespuesta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbo_TipoRespuesta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_TipoRespuesta.FormattingEnabled = true;
            this.cbo_TipoRespuesta.Location = new System.Drawing.Point(177, 77);
            this.cbo_TipoRespuesta.Name = "cbo_TipoRespuesta";
            this.cbo_TipoRespuesta.Size = new System.Drawing.Size(305, 23);
            this.cbo_TipoRespuesta.TabIndex = 5;
            // 
            // txt_Notas
            // 
            this.txt_Notas.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.txt_Notas.Location = new System.Drawing.Point(177, 188);
            this.txt_Notas.Multiline = true;
            this.txt_Notas.Name = "txt_Notas";
            this.txt_Notas.Size = new System.Drawing.Size(369, 122);
            this.txt_Notas.TabIndex = 6;
            // 
            // txt_fechahora
            // 
            this.txt_fechahora.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fechahora.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_fechahora.Location = new System.Drawing.Point(177, 316);
            this.txt_fechahora.Name = "txt_fechahora";
            this.txt_fechahora.ReadOnly = true;
            this.txt_fechahora.Size = new System.Drawing.Size(152, 22);
            this.txt_fechahora.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(125, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Agente";
            // 
            // txt_AgenteReanalisis
            // 
            this.txt_AgenteReanalisis.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.txt_AgenteReanalisis.Location = new System.Drawing.Point(177, 105);
            this.txt_AgenteReanalisis.Name = "txt_AgenteReanalisis";
            this.txt_AgenteReanalisis.Size = new System.Drawing.Size(120, 22);
            this.txt_AgenteReanalisis.TabIndex = 12;
            // 
            // btn_BuscarAgente
            // 
            this.btn_BuscarAgente.Location = new System.Drawing.Point(303, 104);
            this.btn_BuscarAgente.Name = "btn_BuscarAgente";
            this.btn_BuscarAgente.Size = new System.Drawing.Size(26, 23);
            this.btn_BuscarAgente.TabIndex = 13;
            this.btn_BuscarAgente.Text = "...";
            this.btn_BuscarAgente.UseVisualStyleBackColor = true;
            this.btn_BuscarAgente.Click += new System.EventHandler(this.btn_BuscarAgente_Click);
            // 
            // btn_acep_reanalisis
            // 
            this.btn_acep_reanalisis.FlatAppearance.BorderSize = 0;
            this.btn_acep_reanalisis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_acep_reanalisis.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_acep_reanalisis.Image = ((System.Drawing.Image)(resources.GetObject("btn_acep_reanalisis.Image")));
            this.btn_acep_reanalisis.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_acep_reanalisis.Location = new System.Drawing.Point(5, 71);
            this.btn_acep_reanalisis.Margin = new System.Windows.Forms.Padding(358, 5, 3, 10);
            this.btn_acep_reanalisis.Name = "btn_acep_reanalisis";
            this.btn_acep_reanalisis.Size = new System.Drawing.Size(65, 76);
            this.btn_acep_reanalisis.TabIndex = 14;
            this.btn_acep_reanalisis.Text = "Aceptar (Crtl-G)";
            this.btn_acep_reanalisis.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_acep_reanalisis.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_acep_reanalisis.UseVisualStyleBackColor = true;
            this.btn_acep_reanalisis.Click += new System.EventHandler(this.btn_acep_reanalisis_Click);
            // 
            // btn_cancel_reanalisis
            // 
            this.btn_cancel_reanalisis.FlatAppearance.BorderSize = 0;
            this.btn_cancel_reanalisis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel_reanalisis.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel_reanalisis.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel_reanalisis.Image")));
            this.btn_cancel_reanalisis.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_cancel_reanalisis.Location = new System.Drawing.Point(5, 156);
            this.btn_cancel_reanalisis.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.btn_cancel_reanalisis.Name = "btn_cancel_reanalisis";
            this.btn_cancel_reanalisis.Size = new System.Drawing.Size(63, 76);
            this.btn_cancel_reanalisis.TabIndex = 15;
            this.btn_cancel_reanalisis.Text = "Cancelar (Esc)";
            this.btn_cancel_reanalisis.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_cancel_reanalisis.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_cancel_reanalisis.UseVisualStyleBackColor = true;
            this.btn_cancel_reanalisis.Click += new System.EventHandler(this.btn_cancel_reanalisis_Click);
            // 
            // lbl_ImporteRescatado
            // 
            this.lbl_ImporteRescatado.AutoSize = true;
            this.lbl_ImporteRescatado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ImporteRescatado.Location = new System.Drawing.Point(64, 136);
            this.lbl_ImporteRescatado.Name = "lbl_ImporteRescatado";
            this.lbl_ImporteRescatado.Size = new System.Drawing.Size(107, 15);
            this.lbl_ImporteRescatado.TabIndex = 16;
            this.lbl_ImporteRescatado.Text = "Importe Rescatado";
            // 
            // txt_ImporteRescatado
            // 
            this.txt_ImporteRescatado.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.txt_ImporteRescatado.Location = new System.Drawing.Point(177, 133);
            this.txt_ImporteRescatado.MaxLength = 7;
            this.txt_ImporteRescatado.Name = "txt_ImporteRescatado";
            this.txt_ImporteRescatado.Size = new System.Drawing.Size(120, 22);
            this.txt_ImporteRescatado.TabIndex = 17;
            this.txt_ImporteRescatado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ImporteRescatado_KeyPress);
            // 
            // cb_UsuarioCredito
            // 
            this.cb_UsuarioCredito.FormattingEnabled = true;
            this.cb_UsuarioCredito.Location = new System.Drawing.Point(177, 161);
            this.cb_UsuarioCredito.Name = "cb_UsuarioCredito";
            this.cb_UsuarioCredito.Size = new System.Drawing.Size(311, 21);
            this.cb_UsuarioCredito.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(82, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 15);
            this.label6.TabIndex = 19;
            this.label6.Text = "Se Reanaliza A";
            // 
            // btn_Cerrar
            // 
            this.btn_Cerrar.FlatAppearance.BorderSize = 0;
            this.btn_Cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cerrar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cerrar.Image = global::PuntoVenta.Properties.Resources.icons8_cerrar_ventana_30;
            this.btn_Cerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Cerrar.Location = new System.Drawing.Point(5, 6);
            this.btn_Cerrar.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.btn_Cerrar.Name = "btn_Cerrar";
            this.btn_Cerrar.Size = new System.Drawing.Size(63, 57);
            this.btn_Cerrar.TabIndex = 20;
            this.btn_Cerrar.Text = "Cerrar";
            this.btn_Cerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cerrar.UseVisualStyleBackColor = true;
            this.btn_Cerrar.Click += new System.EventHandler(this.btn_Cerrar_Click);
            // 
            // DM0312_Reanalisis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(566, 350);
            this.Controls.Add(this.btn_Cerrar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_UsuarioCredito);
            this.Controls.Add(this.txt_ImporteRescatado);
            this.Controls.Add(this.lbl_ImporteRescatado);
            this.Controls.Add(this.btn_cancel_reanalisis);
            this.Controls.Add(this.btn_acep_reanalisis);
            this.Controls.Add(this.btn_BuscarAgente);
            this.Controls.Add(this.txt_AgenteReanalisis);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_fechahora);
            this.Controls.Add(this.txt_Notas);
            this.Controls.Add(this.cbo_TipoRespuesta);
            this.Controls.Add(this.cbo_TipoReanalisis);
            this.Controls.Add(this.lbl_FechaHora);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DM0312_Reanalisis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reanalisis";
            this.Load += new System.EventHandler(this.Reanalisis_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btn_Cerrar;

        private System.Windows.Forms.Label lbl_FechaHora;
        private System.Windows.Forms.Label lbl_ImporteRescatado;
        private System.Windows.Forms.TextBox txt_ImporteRescatado;
        private System.Windows.Forms.ComboBox cb_UsuarioCredito;
        private System.Windows.Forms.Label label6;

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbo_TipoReanalisis;
        private System.Windows.Forms.ComboBox cbo_TipoRespuesta;
        private System.Windows.Forms.TextBox txt_Notas;
        private System.Windows.Forms.TextBox txt_fechahora;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_AgenteReanalisis;
        private System.Windows.Forms.Button btn_BuscarAgente;
        private System.Windows.Forms.Button btn_acep_reanalisis;
        private System.Windows.Forms.Button btn_cancel_reanalisis;
    }
}