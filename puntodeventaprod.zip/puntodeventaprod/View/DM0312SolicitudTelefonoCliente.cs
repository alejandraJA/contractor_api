﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.Utilidades;

namespace PuntoVenta.View
{
    public partial class DM0312SolicitudTelefonoCliente : Form
    {
        public DM0312SolicitudTelefonoCliente(string[] parametros)
        {
            InitializeComponent();
            Parametros = parametros;
        }

        private string[] Parametros { get; }

        private void btnEnviarFactura_Click(object sender, EventArgs e)
        {
            DM0312SolicitudTelefonoClienteController.Instance.SetCliente(Parametros[4]);
            DM0312SolicitudTelefonoClienteController.Instance.SetIdVenta(
                int.Parse(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]));
            DM0312SolicitudTelefonoClienteController.Instance.SetTelefono(txtTelefono.Text);
            DM0312SolicitudTelefonoClienteController.Instance.SetTelefonoAgente(txtTelefonoAgente.Text);
            MessageBox.Show(DM0312SolicitudTelefonoClienteController.Instance.EnviarSMS(), "Enviar Factura",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void DM0312SolicitudTelefonoCliente_Load(object sender, EventArgs e)
        {
            txtTelefono.Focus();
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void txtTelefonoAgente_TextChanged(object sender, EventArgs e)
        {
            txtTelefonoAgente.Text = txtTelefonoAgente.Text.ToPhone();
        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {
            txtTelefono.Text = txtTelefono.Text.ToPhone();
        }

        private void txtTelefono_Validating(object sender, CancelEventArgs e)
        {
            bool error = txtTelefono.VerificarInput(epValidacion, c => !c.IsPhone());
            e.Cancel = error;
            MostrarMensaje(ref txtTelefono, error);
        }

        private void txtTelefonoAgente_Validating(object sender, CancelEventArgs e)
        {
            bool error = txtTelefonoAgente.VerificarInput(epValidacion, c => !c.IsPhone());
            e.Cancel = error;
            MostrarMensaje(ref txtTelefonoAgente, error);
        }

        private void MostrarMensaje(ref TextBox control, bool hasError)
        {
            if (string.IsNullOrEmpty(control.Text))
            {
                epValidacion.SetError(control, "Campos obligatorios");
                MessageBox.Show("Campos obligatorios", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (hasError)
            {
                epValidacion.SetError(control, $"Telefono {control.Text} incorrecto");
                MessageBox.Show($"Telefono {control.Text} incorrecto", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
    }
}