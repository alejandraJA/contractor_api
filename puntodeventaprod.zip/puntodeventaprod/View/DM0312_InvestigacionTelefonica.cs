﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta
{
    //Autor:Rodolfo Sanchez
    //Modulo: Investigacion Telefonica Credito
    //Fecha:15/09/2017
    public partial class InvestigacionTelefonica : Form
    {
        public static string Tipo = string.Empty;
        public static string nomina = string.Empty;
        public static Dictionary<int, string> diccionarioParentesco;
        public static Dictionary<int, string> Contactos;
        private readonly DM0312_CContactos controller;
        private string cteFinal;
        private DM0312_MExploradorVenta mov = new DM0312_MExploradorVenta();
        private readonly sqlHelper sqlHelper = new sqlHelper();
        private readonly string tipoContacto;

        public InvestigacionTelefonica(string TipoContacto)
        {
            InitializeComponent();
            tipoContacto = TipoContacto;
            controller = new DM0312_CContactos();
            diccionarioParentesco = new Dictionary<int, string>();
            Contactos = new Dictionary<int, string>();
        }

        public int IdContacto { get; set; }
        public string cuenta { get; set; }
        public string Agente { get; set; }
        public string TipoContacto { get; set; }
        public string MovId { get; set; }
        public string Mov { get; set; }
        public int IdVenta { get; set; }

        ~InvestigacionTelefonica()
        {
            GC.Collect();
        }

        private void InvestigacionTelefonica_Load(object sender, EventArgs e)
        {
            Tipo = string.Empty;
            toolTip1.SetToolTip(btn_Ayuda, "Ayuda");
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            setContacto();
            setAgente(Agente);
            validacionTipoContacto();
        }

        private class cbValueBool
        {
            public string Value { get; set; }
            public bool Index { get; set; }
        }

        #region Triggers

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (Tipo == "p")
                    updateModelPersonal();

                if (Tipo == "l")
                    updateModelLaboral();

                if (Tipo == "bf")
                    updateModelBeneficiarioFinal();

                MessageBox.Show("Cambios guardados correctamente", "Información", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void groupBox3_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox4_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void InvestigacionTelefonica_Scroll(object sender, ScrollEventArgs e)
        {
            groupBox4.Location = new Point(0, 20);
        }

        /* INICIA Eventos Solo letras ************************************************/
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtConyugeDedica_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtClienteDedica_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtPuesto_lab_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtNomInfor_lab_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtPuestoInf_lab_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        private void txtFormaReco_lab_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }

        /* FIN Eventos Solo letras **************************************************/
        private void InvestigacionTelefonica_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();

            if (e.Control && e.KeyCode == Keys.G)
            {
                DialogResult result = MessageBox.Show("¿Desea Guardar Los Cambios Efectuados?", "Confirmación",
                    MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    if (Tipo == "p")
                        updateModelPersonal();

                    if (Tipo == "l")
                        updateModelLaboral();

                    if (Tipo == "bf")
                        updateModelBeneficiarioFinal();

                    MessageBox.Show("Cambios guardados correctamente", "Información", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }

        private void InvestigacionTelefonica_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Desea salir de Investigación Telefonica?", "Confirmación",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        /* INICIO VALIDACION FORMULARIO BENEFICIARIO FINAL */
        private void formularioBeneficiarioFinalLetras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void formularioBeneficiarioFinalMixto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b' &&
                !char.IsNumber(e.KeyChar))
            {
                MessageBox.Show("Solo se permiten letras y números", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }
        /* FIN VALIDACION FORMULARIO BENEFICIARIO FINAL */

        #endregion

        #region Metodos

        private void setContacto()
        {
            DM0312_MCteContacto mClienteContacto = new DM0312_MCteContacto();
            mClienteContacto = controller.GetContactoSeleccionado_(cuenta, IdContacto);

            txtCuenta_con.Text = cuenta;
            txtNombre_con.Text = mClienteContacto.NombreCliente;
            txtCony_con.Text = mClienteContacto.Conyuge;
            txtContac_con.Text = mClienteContacto.Contacto;
            txtTel_con.Text = mClienteContacto.Telefonos;
            txtMuni_con.Text = mClienteContacto.Poblacion;
            txtDirec_con.Text = mClienteContacto.Direccion;
            txtCol_con.Text = mClienteContacto.Colonia;

            cteFinal = mClienteContacto.cteFinal;
        }

        private void setReferenciaLaboral()
        {
            DM0312_MRefLaboral mReferenciaLaboral = new DM0312_MRefLaboral();
            mReferenciaLaboral = controller._SelectRefLaboral(IdContacto);
            nomina = mReferenciaLaboral.Nomina;
            txtPuesto_lab.Text = mReferenciaLaboral.PuestoLaboral;
            txtDepartamento_lab.Text = mReferenciaLaboral.Departamento;
            txtAntiguedad_lab.Text = mReferenciaLaboral.Antiguedad;
            txtDom_lab.Text = mReferenciaLaboral.Domicilio;
            txtIngresos_Lab.Text = mReferenciaLaboral.IngresoMens;
            cmbComprobabes_lab.Text = mReferenciaLaboral.Comprobable;
            txtObservaciones_lab.Text = mReferenciaLaboral.Observaciones;
            txtDomPer_lab.Text = mReferenciaLaboral.DomicilioPer;
            txtPlanesEmpresa_lab.Text = mReferenciaLaboral.PlanEmpresa;
            txtFormaReco_lab.Text = mReferenciaLaboral.FormaRecom;
            txtNomInfor_lab.Text = mReferenciaLaboral.NombreInfo;
            txtPuestoInf_lab.Text = mReferenciaLaboral.PuestoInfo;
            txtComenta_lab.Text = mReferenciaLaboral.Comentarios;
            txtFyH_.Text = mReferenciaLaboral.Fecha + " " + mReferenciaLaboral.Hora;
        }

        private void setReferenciaPersonal()
        {
            DM0312_MRefPersonal mReferenciaPersonal = new DM0312_MRefPersonal();
            mReferenciaPersonal = controller._SelectRefPersonal(IdContacto);
            txtNombre.Text = mReferenciaPersonal.Nombre;
            txttiempoCono.Text = mReferenciaPersonal.TiempoCono;
            int indexSelected = 0;
            if (mReferenciaPersonal.Parentesco != string.Empty && mReferenciaPersonal.Parentesco != null)
                indexSelected = diccionarioParentesco.Where(x => x.Value == mReferenciaPersonal.Parentesco)
                    .Select(x => x.Key).FirstOrDefault();
            cmbParentesco.SelectedIndex = indexSelected;
            cmbProblemasPago.Text = mReferenciaPersonal.ProblemasPago;
            cmbVivede.Text = mReferenciaPersonal.ViveDe;
            txtCualesPro.Text = mReferenciaPersonal.CualesPro;
            txtviveen.Text = mReferenciaPersonal.ViveEn;
            txtQuienes.Text = mReferenciaPersonal.Quienes;
            txtClienteDedica.Text = mReferenciaPersonal.ClienteDedica;
            txtConyugeDedica.Text = mReferenciaPersonal.ConyugeDedica;
            txtFyH_.Text = mReferenciaPersonal.Fecha + " " + mReferenciaPersonal.Hora;
        }

        private void setAgente(string nomina)
        {
            txtNombreAgente.Text = controller.GetAgente(nomina);
            txtAgente.Text = nomina;
        }

        private void setParentesco(ComboBox comboBox)
        {
            diccionarioParentesco = controller.GetParentesco();
            comboBox.DataSource = diccionarioParentesco.ToList();
            comboBox.DisplayMember = "Value";
            comboBox.ValueMember = "Value";
        }

        private void setViveDe()
        {
            cmbVivede.DataSource = Enum.GetValues(typeof(Enums.ViveDe));
            //foreach (var item in Enum.GetValues(typeof(PuntoVenta.Model.Enumeradores.Enums.ViveDe)))
            //{
            //    cmbVivede.Items.Add(item);
            //}
        }

        private void setProblemasPago()
        {
            cmbProblemasPago.DataSource = Enum.GetValues(typeof(Enums.Contactos));
        }

        private void setViveAlguienMas()
        {
            cmbViveAlguien.DataSource = Enum.GetValues(typeof(Enums.Contactos));
        }

        private void setComprobables()
        {
            cmbComprobabes_lab.DataSource = Enum.GetValues(typeof(Enums.Contactos));
        }

        private void updateModelLaboral()
        {
            DM0312_MRefLaboral mReferenciaLaboral = new DM0312_MRefLaboral();
            mReferenciaLaboral.IDContacto = IdContacto;
            mReferenciaLaboral.PuestoLaboral = txtPuesto_lab.Text;
            mReferenciaLaboral.Departamento = txtDepartamento_lab.Text;
            mReferenciaLaboral.Antiguedad = txtAntiguedad_lab.Text;
            mReferenciaLaboral.Domicilio = txtDom_lab.Text;
            mReferenciaLaboral.IngresoMens = txtIngresos_Lab.Text;
            if (cmbComprobabes_lab.SelectedItem != null)
                mReferenciaLaboral.Comprobable = cmbComprobabes_lab.SelectedItem.ToString();
            else
                mReferenciaLaboral.Comprobable = string.Empty;
            //model.Comprobable = cmbComprobabes_lab.SelectedText;
            mReferenciaLaboral.Observaciones = txtObservaciones_lab.Text;
            mReferenciaLaboral.DomicilioPer = txtDomPer_lab.Text;
            mReferenciaLaboral.PlanEmpresa = txtPlanesEmpresa_lab.Text;
            mReferenciaLaboral.FormaRecom = txtFormaReco_lab.Text;
            mReferenciaLaboral.NombreInfo = txtNomInfor_lab.Text;
            mReferenciaLaboral.PuestoInfo = txtPuestoInf_lab.Text;
            mReferenciaLaboral.Comentarios = txtComenta_lab.Text;
            mReferenciaLaboral.Cuenta = cuenta;
            mReferenciaLaboral.IDMovimiento = IdVenta;
            mReferenciaLaboral.Movimiento = Mov;
            mReferenciaLaboral.Consecutivo = MovId;
            mReferenciaLaboral.Cuenta = cuenta;
            mReferenciaLaboral.Nomina = Agente;

            controller._UpdateInsertRefLaboral(mReferenciaLaboral);
            // GetRefLaboral();
        }

        private void updateModelPersonal()
        {
            DM0312_MRefPersonal mReferenciaPersonal = new DM0312_MRefPersonal();
            mReferenciaPersonal.Nombre = txtNombre.Text;
            mReferenciaPersonal.TiempoCono = txttiempoCono.Text;
            if (cmbParentesco.SelectedItem != null)
                mReferenciaPersonal.Parentesco = cmbParentesco.SelectedValue.ToString();
            else
                mReferenciaPersonal.Parentesco = string.Empty;
            if (cmbProblemasPago.SelectedItem != null)
                mReferenciaPersonal.ProblemasPago = cmbProblemasPago.SelectedItem.ToString();
            else
                mReferenciaPersonal.ProblemasPago = string.Empty;
            if (cmbVivede.SelectedItem != null)
                mReferenciaPersonal.ViveDe = cmbVivede.SelectedItem.ToString();
            else
                mReferenciaPersonal.ViveDe = string.Empty;
            mReferenciaPersonal.CualesPro = txtCualesPro.Text;
            mReferenciaPersonal.ViveEn = txtviveen.Text;
            mReferenciaPersonal.Quienes = txtQuienes.Text;
            mReferenciaPersonal.ClienteDedica = txtClienteDedica.Text;
            mReferenciaPersonal.ConyugeDedica = txtConyugeDedica.Text;
            mReferenciaPersonal.IDContacto = IdContacto;
            mReferenciaPersonal.Consecutivo = MovId;
            mReferenciaPersonal.IDMovimiento = IdVenta;
            mReferenciaPersonal.Cuenta = cuenta;
            mReferenciaPersonal.Nomina = Agente;
            mReferenciaPersonal.Movimiento = Mov;

            controller._UpdateInsertRefPersonal(mReferenciaPersonal);
            //GetFerPersonal();
        }

        private void mostrarFormularioDeLaboral()
        {
            panelLaboral.Visible = true;

            setComprobables();
            setReferenciaLaboral();

            Height = 680;
            Tipo = "l";
            txtPuesto_lab.Select();
        }

        private void mostrarFormularioDePersonal()
        {
            panelPersonal.Visible = true;

            setParentesco(cmbParentesco);
            setViveDe();
            setProblemasPago();
            setViveAlguienMas();
            setReferenciaPersonal();

            Height = 560;
            Tipo = "p";
            txtNombre.Select();
        }

        /* 1458 - FORMULARIO BENEFICIARIO FINAL*/
        private void validacionTipoContacto()
        {
            switch (tipoContacto)
            {
                case "LABORAL":
                    mostrarFormularioDeLaboral();
                    break;
                case "PERSONAL":
                    mostrarFormularioDePersonal();
                    break;
                case "BENEFICIARIO FINAL":
                    mostrarFormularioDeBeneficiarioFinal();
                    break;
            }
        }

        private void mostrarFormularioDeBeneficiarioFinal()
        {
            panelBeneficiarioFinal.Visible = true;
            btn_Ayuda.Visible = false;

            setParentesco(cb_parentescoBeneficiarioFinal);
            addOpcionesUsoNIP(cb_canjeoValeConNIP);
            setComboOpcionesPagos(cb_dondeHaraPagos);
            setBeneficiarioFinal();

            Height = 680;
            Tipo = "bf";
        }

        private void setBeneficiarioFinal()
        {
            MBeneficiarioFinal mBeneficiarioFinal = new MBeneficiarioFinal();
            mBeneficiarioFinal = controller._SelectReferenciaBeneficiarioFinal(IdContacto);
            txt_nombreBeneficiarioFinal.Text =
                mBeneficiarioFinal.nombre != null ? mBeneficiarioFinal.nombre : txtContac_con.Text;
            mov = getUltimoMovimiento(cteFinal);
            txt_productoOPrestamo.Text = mBeneficiarioFinal.productoOPrestamo != null
                ? mBeneficiarioFinal.productoOPrestamo
                : mov.Mov;
            int selectedItem =
                mBeneficiarioFinal.parentesco != string.Empty &&
                mBeneficiarioFinal.parentesco != null
                    ? diccionarioParentesco.Where(x => x.Value == mBeneficiarioFinal.parentesco).Select(x => x.Key)
                        .FirstOrDefault()
                    : 0;
            cb_parentescoBeneficiarioFinal.SelectedIndex = selectedItem;
            txt_dondeConoceDistribuidor.Text = mBeneficiarioFinal.dondeConoceDistribuidor;
            txt_quienTecleoNIPEnTienda.Text = mBeneficiarioFinal.quienTecleoNIPEnTienda;
            if (mBeneficiarioFinal.canjeoValeConNIP)
                cb_canjeoValeConNIP.SelectedIndex = 0;
            else
                cb_canjeoValeConNIP.SelectedIndex = 1;
            txt_quienTecleoNIPEnTienda.Text = mBeneficiarioFinal.quienTecleoNIPEnTienda;
            txt_paraQuienFueLaCompra.Text = mBeneficiarioFinal.paraQuienFueLaCompra;
            cb_dondeHaraPagos.SelectedItem = mBeneficiarioFinal.dondeHaraPagos != null
                ? mBeneficiarioFinal.dondeHaraPagos
                : "Distribuidor";
            txt_atencionEnTienda.Text = mBeneficiarioFinal.atencionEnTienda;
            txt_domicilioActual.Text = mBeneficiarioFinal.domicilioActual != null
                ? mBeneficiarioFinal.domicilioActual
                : txtDirec_con.Text;
            txt_observacionesBeneficiarioFinal.Text = mBeneficiarioFinal.observaciones;
            txtFyH_.Text = sqlHelper.getFechaActualServidor().ToString("dd/MM/yyyy hh:mm:ss tt");
        }

        private void updateModelBeneficiarioFinal()
        {
            MBeneficiarioFinal mBeneficiarioFinal = new MBeneficiarioFinal();
            mBeneficiarioFinal.nombre = txt_nombreBeneficiarioFinal.Text;
            mBeneficiarioFinal.productoOPrestamo = txt_productoOPrestamo.Text;
            mBeneficiarioFinal.productoOPrestamoMovID = mov.MovId;
            mBeneficiarioFinal.parentesco = cb_parentescoBeneficiarioFinal.SelectedItem != null
                ? cb_parentescoBeneficiarioFinal.SelectedValue.ToString()
                : string.Empty;
            mBeneficiarioFinal.dondeConoceDistribuidor = txt_dondeConoceDistribuidor.Text;

            cbValueBool nipValue = (cbValueBool)cb_canjeoValeConNIP.SelectedItem;
            mBeneficiarioFinal.canjeoValeConNIP = nipValue.Index;

            mBeneficiarioFinal.quienTecleoNIPEnTienda = txt_quienTecleoNIPEnTienda.Text;
            mBeneficiarioFinal.paraQuienFueLaCompra = txt_paraQuienFueLaCompra.Text;
            mBeneficiarioFinal.dondeHaraPagos = cb_dondeHaraPagos.SelectedItem != null
                ? cb_dondeHaraPagos.SelectedValue.ToString()
                : string.Empty;
            mBeneficiarioFinal.atencionEnTienda = txt_atencionEnTienda.Text;
            mBeneficiarioFinal.domicilioActual = txt_domicilioActual.Text;
            mBeneficiarioFinal.observaciones = txt_observacionesBeneficiarioFinal.Text;
            mBeneficiarioFinal.idCteCto = IdContacto;
            mBeneficiarioFinal.movID = MovId;
            mBeneficiarioFinal.idVenta = IdVenta;
            mBeneficiarioFinal.cuenta = cuenta;
            mBeneficiarioFinal.agente = Agente;
            mBeneficiarioFinal.mov = Mov;

            controller._ExecReferenciaBeneficiarioFinal(mBeneficiarioFinal);
        }

        private void addOpcionesUsoNIP(ComboBox comboBox)
        {
            List<cbValueBool> usoNIP = new List<cbValueBool>();

            usoNIP.Add(new cbValueBool { Index = true, Value = "SI" });
            usoNIP.Add(new cbValueBool { Index = false, Value = "NO" });

            setComboOpcionesUsoNIP(comboBox, usoNIP);
        }

        private void setComboOpcionesUsoNIP(ComboBox comboBox, List<cbValueBool> usoNIP)
        {
            comboBox.DataSource = usoNIP;
            comboBox.DisplayMember = "Value";
            comboBox.ValueMember = "Index";
        }

        private void setComboOpcionesPagos(ComboBox comboBox)
        {
            List<string> opcionesPago = new List<string>();

            opcionesPago.Add("Distribuidor");
            opcionesPago.Add("En Tienda");

            comboBox.DataSource = opcionesPago;
        }

        private DM0312_MExploradorVenta getUltimoMovimiento(string cteFinal)
        {
            return controller.getUltimoMovimiento(cteFinal);
        }
        /* 1458 - FORMULARIO BENEFICIARIO FINAL*/

        #endregion
    }
}