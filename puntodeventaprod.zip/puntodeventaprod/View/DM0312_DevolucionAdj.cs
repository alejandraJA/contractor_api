﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta.View
{
    public partial class DM0312_DevolucionAdj : Form
    {
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public static string Almacen = "";
        public static int Canal, idVenta;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool CerrarVenta;
        public List<DM0312_MComentariosVenta> ComentariosDevolucion;
        private int contadorGuardarD;

        private readonly CSerieArticulos ControladorSerie;
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        public List<string> datosConcepto = new List<string>();
        private readonly DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
        private readonly int EnviarA;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public List<MSerieArticulos> ListInIdDevolucion = new List<MSerieArticulos>();
        public List<MSerieArticulos> ListOldSeries = new List<MSerieArticulos>();
        public string mensajeBoton;
        private List<DM0312_M_DetalleDev> ModeloDetalle = new List<DM0312_M_DetalleDev>();
        private MSerieArticulos modeloSeries = new MSerieArticulos();
        public DM0312_M_DetalleDev modeloVentaDetalle;
        public string Mov, codigo, MovID, idFactura, importe, impuestos;
        public string oldValue = string.Empty;
        private readonly string pedComer = "";
        private bool res;
        public int suc;
        public string TipoMovimiento, FormaPago = "";
        private double total;
        public int uen;
        private readonly AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
        public string ValidaEstatus, Concepto = "", Observacion = "", Comentario = "";
        private string validaMensajeBoton;

        public DM0312_DevolucionAdj()
        {
            InitializeComponent();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);
            ControladorSerie = new CSerieArticulos();
        }

        ~DM0312_DevolucionAdj()
        {
            GC.Collect();
        }

        private void DM0312_DevolucionAdj_Load(object sender, EventArgs e)
        {
            Text = Text = " Solicitud devolucion " + Mov + "     SPID:" + ClaseEstatica.SPID + "        " +
                          controllerExplorador.FechaActualServidor();
            lbl_Estatus.Text = ValidaEstatus;
            lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
            ComentariosDevolucion = Funciones.ConsultaComentario("Devolucion");
            validaMensajeBoton = mensajeBoton;
            modificaFormaBoton(validaMensajeBoton);
            lbl_Estatus.Text = "SIN AFECTAR";
            txt_Comentarios.Text =
                "DATOS DE DEVOLUCIÓN SI SON CORRECTOS PONER LA CANTIDAD DE ARTÍCULOS A DEVOLVER DE LA FACTURA UNA VEZ TERMINADO AFECTAR LA DEVOLUCIÓN";

            toolTip1.SetToolTip(cbx_Cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA DEVOLUCION");
            toolTip1.SetToolTip(txt_ClienteNombre, "NOMBRE DEL CLIENTE");
            toolTip1.SetToolTip(cbx_Agente, "VENDEDOR QUE REALIZO LA FACTURA O MOVIMIENTO QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(cbx_Canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(cbx_Condicion, "PLAZO DE PAGO DE LA FACTURA O MOVIMIENTO A DEVOLVER");
            toolTip1.SetToolTip(cbx_Almacen, "ALMACÉN DONDE SE REALIZÓ LA FACTURA O MOVIMIENTO A DEVOLVER");
            toolTip1.SetToolTip(cbx_Concepto, "MOTIVO POR EL CUAL SE SOLICITA UNA SOLICITUD DEVOLUCION");
            toolTip1.SetToolTip(txt_Referencia,
                "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA SOLICITUD DEVOLUCIÓN");
            toolTip1.SetToolTip(cbx_AgenteServicio,
                "VENDEDOR QUE REALIZO LA FACTURA O MOVIMIENTO QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(txt_Pago, "MONEDERO QUE SE REDIMIÓ PARA LA FACTURA " + Mov + " " + MovID);
            toolTip1.SetToolTip(txt_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(txt_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(cbx_SelecTodo, "SELECCIONAR PARA DEVOLVER TODO LO AFECTADO AL MOVIMIENTO");
            toolTip1.SetToolTip(btn_Regresar, "CANCELAR SOLICITUD DEVOLUCION");
            toolTip1.SetToolTip(btn_Afecta,
                "SI TIENE LOS DATOS CORRECTOS Y YA SELECCIONO ALGÚN ARTICULO A DEVOLVER PRESIONAR BOTÓN PARA SEGUIR PROCESO DE SU SOLICITUD DEVOLUCIÓN");
            toolTip1.SetToolTip(btn_InformacionCliente,
                "INFORMACIÓN IMPORTANTE DEL CLIENTE AL QUE SE LE VA HACER LA DEVOLUCIÓN");
            toolTip1.SetToolTip(btn_ayuda, "AYUDA");

            toolTip1.SetToolTip(lbl_cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA DEVOLUCION");
            toolTip1.SetToolTip(lbl_Agente, "VENDEDOR QUE REALIZO LA FACTURA O MOVIMIENTO QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(lbl_canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(lbl_condicion, "PLAZO DE PAGO DE LA FACTURA O MOVIMIENTO A DEVOLVER");
            toolTip1.SetToolTip(lbl_almacen, "ALMACÉN DONDE SE REALIZÓ LA FACTURA O MOVIMIENTO A DEVOLVER");
            toolTip1.SetToolTip(lbl_Concepto, "MOTIVO POR EL CUAL SE SOLICITA UNA SOLICITUD DEVOLUCION");
            toolTip1.SetToolTip(lbl_Referencia,
                "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA SOLICITUD DEVOLUCIÓN, AUN LADO SE ENCUENTRA LA FECHA DE EMISION EN QUE SE REALIZO EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_AgenteServicio,
                "VENDEDOR QUE REALIZO LA FACTURA O MOVIMIENTO QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(lbl_MonederoRedimido, "MONEDERO QUE SE REDIMIÓ PARA LA FACTURA " + Mov + " " + MovID);
            toolTip1.SetToolTip(lbl_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");

            toolTip1.SetToolTip(lbl_Usuario, "USUARIO");
            toolTip1.SetToolTip(lbl_Estatus, "ESTATUS DE LA SOLICITUD DEVOLUCION");
            toolTip1.SetToolTip(lbl_ID, "ID DE LA SOLICITUD DEVOLUCION");
            toolTip1.SetToolTip(gbx_VentaDetalle,
                "DETALLE DEL MOVIMIENTO INSERTAR LA CANTIDAD A DEVOLVER UNA VEZ TERMINADO AFECTAR LA SOLICITUD Y SEGUIR CON SU PROCESO");
            toolTip1.SetToolTip(dvg_detalleVenta,
                "DETALLE DEL MOVIMIENTO INSERTAR LA CANTIDAD A DEVOLVER UNA VEZ TERMINADO AFECTAR LA SOLICITUD Y SEGUIR CON SU PROCESO");

            toolTip1.SetToolTip(lbl_SubTotal, "SUBTOTAL DE LA FACTURA QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(lbl_Impuestos, "TOTAL DE IMPUESTOS DE LA FACTURA QUE SE QUIERE DEVOLVER");
            toolTip1.SetToolTip(lbl_Total, "SUMA DEL SUBTOTAL Y LOS IMPUESTOS");
            toolTip1.SetToolTip(lbl_ImporteD, "IMPORTE TOTAL DE LO QUE SE QUIERE DEVOLVER");

            toolTip1.SetToolTip(lbl_ImporteD, "FECHA EMISION DEL MOVIMIENTO A DEVOLVER");

            if (ClaseEstatica.Usuario.Uen == 3)
            {
                lbl_Empresa.Text = "MAVI";
                toolTip1.SetToolTip(lbl_Empresa, "MAVI DE OCCIDENTE");
            }
            else
            {
                if (ClaseEstatica.Usuario.Uen == 1)
                {
                    lbl_Empresa.Text = "MA";
                    toolTip1.SetToolTip(lbl_Empresa, "MUEBLES AMERICA");
                }
                else
                {
                    if (ClaseEstatica.Usuario.Uen == 2)
                    {
                        lbl_Empresa.Text = "VIU";
                        toolTip1.SetToolTip(lbl_Empresa, "VIU");
                    }
                    else
                    {
                        lbl_Empresa.Text = "";
                        toolTip1.SetToolTip(lbl_Empresa, "");
                    }
                }
            }

            if (ClaseEstatica.Usuario.color == "Azul")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void dvg_detalleVenta_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value != null)
                oldValue = dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value.ToString();
        }


        private void ResetOldValue(string cambio, int columnindex)
        {
            dvg_detalleVenta.CancelEdit();
            string name = dvg_detalleVenta.Columns[columnindex].Name;
            Type tipo = modeloVentaDetalle.GetType().GetProperty(name).PropertyType;
            modeloVentaDetalle.GetType().GetProperty(name)
                .SetValue(modeloVentaDetalle, Convert.ChangeType(oldValue, tipo));
        }

        private void txt_Referencia_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Referencia =
                ComentariosDevolucion.Where(x => x.Campo.Equals("Referencia")).FirstOrDefault();
            if (Referencia != null) txt_Comentarios.Text = Referencia.Comentario;
        }

        private void DM0312_DevolucionAdj_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (lbl_ID.Text != "")
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        EliminarId();
                        Dispose();
                    }
                }
                else
                {
                    Dispose();
                }
            }

            if (e.Control && e.KeyCode == Keys.I)
                try
                {
                    if (cbx_Cliente.Text == "")
                    {
                        MessageBox.Show("Ingrese un Cliente", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        foreach (Form forma in Application.OpenForms)
                            if (forma.Name == "InformacionCliente")
                            {
                                forma.Close();
                                break;
                            }

                        InformacionCliente infoCliente = new InformacionCliente();
                        infoCliente.mensaje = cbx_Cliente.Text;
                        infoCliente.Show();
                    }
                }
                catch
                {
                    MessageBox.Show("No es una cuenta correcta", "Mensaje!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }

            if (e.Control && e.KeyCode == Keys.F) AfectarDevolucion();
        }

        private void txt_FechaFac_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta FechaFac =
                ComentariosDevolucion.Where(x => x.Campo.Equals("FechaFac")).FirstOrDefault();
            if (FechaFac != null) txt_Comentarios.Text = FechaFac.Comentario;
        }

        #region Metodos

        public void ValidaAlmacen()
        {
            try
            {
                string almacen = cbx_Almacen.Text;
                string Resultado = "";

                Resultado = controlador.ValidarAlmacen(almacen);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (almacen == "")
                        MessageBox.Show("Debe ingresar un Almacen", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    else
                        MessageBox.Show("El Almacen es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    cbx_Almacen.Text = "";
                    cbx_Almacen.Focus();
                }
                else
                {
                    cbx_Almacen.Items.Clear();
                    LlenaAlmacen();
                    ActualizarInfoIdVenta();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAlmacen", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void modificaFormaBoton(string mensajeBotonValida)
        {
            switch (mensajeBotonValida)
            {
                case "Devolucion":

                    //this.Text = " Venta de " + mensajeBotonValida;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    btn_Detalle.Visible = true;
                    cbx_AgenteServicio.Enabled = false;
                    //txt_Pago.Enabled = false;
                    dvg_detalleVenta.ReadOnly = false;
                    gbx_DatosGenerales.Size = new Size(711, 224);
                    cbx_Cliente.Enabled = false;
                    txt_ClienteNombre.Enabled = false;
                    cbx_Agente.Enabled = false;
                    cbx_Canal.Enabled = false;
                    cbx_Condicion.Enabled = false;
                    cbx_Almacen.Enabled = false;
                    btn_Detalle.Enabled = false;
                    lbl_Concepto.Visible = true;
                    cbx_Concepto.Visible = true;
                    lbl_Referencia.Visible = true;
                    txt_Referencia.Visible = true;
                    gbx_VentaDetalle.Visible = true;
                    gbx_VentaDetalle.Size = new Size(925, 225);
                    txt_Referencia.Enabled = false;
                    txt_FechaFac.Enabled = false;
                    InformacionDev();
                    if (!CDetalleVenta.PuedeAfectar(ClaseEstatica.Usuario.usuario, "SINAFECTAR", "", TipoMovimiento))
                    {
                        btn_Afecta.Visible = false;
                    }
                    else
                    {
                        btn_Afecta.Visible = true;
                        btn_Afecta.Focus();
                    }

                    FormaPago = "DEVOLUCION";
                    break;

                default:
                    Console.WriteLine("Error");
                    break;
            }
        }

        public void LlenarConcepto()
        {
            try
            {
                string TipoMovimientoD = "";
                if (Mov == "Factura")
                    TipoMovimientoD = "Devolucion Venta";
                else if (Mov == "Credilana")
                    TipoMovimientoD = "Cancela Credilana";
                else if (Mov == "Factura VIU")
                    TipoMovimientoD = "Devolucion VIU";
                else if (Mov == "Prestamo Personal")
                    TipoMovimientoD = "Cancela Prestamo";
                else if (Mov == "Seguro Auto")
                    TipoMovimientoD = "Cancela Seg Auto";
                else if (Mov == "Seguro Vida")
                    TipoMovimientoD = "Cancela Seg Vida";
                else if (Mov == "Factura Mayoreo") TipoMovimientoD = "Devolucion Mayoreo";

                datosConcepto = new List<string>();
                datosConcepto = controlador.LlenaConcepto(TipoMovimientoD);
                if (datosConcepto.Count > 0)
                {
                    cbx_Concepto.DataSource = null;
                    cbx_Concepto.DataSource = datosConcepto.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarConcepto", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void InformacionDev()
        {
            try
            {
                List<string> Resultado = new List<string>();
                string monedero = "";
                lbl_Estatus.Text = ValidaEstatus;
                Resultado = DevolucionMov.InformacionFacturaDevolucion(Mov, MovID);
                monedero = DevolucionMov.MonederoRedimido(Resultado[7]);
                idFactura = Resultado[7];
                importe = Resultado[8];
                impuestos = Resultado[9];
                uen = Convert.ToInt32(Resultado[10]);


                lbl_AgenteServicio.Visible = false;
                cbx_AgenteServicio.Visible = false;


                if (Mov == "Credilana" || Mov == "Factura" || Mov == "Factura VIU" || Mov == "Prestamo Personal" ||
                    Mov == "Seguro Auto" || Mov == "Seguro Vida")
                {
                    TipoMovimiento = "Solicitud Devolucion";
                }
                else
                {
                    if (Mov == "Factura Mayoreo") TipoMovimiento = "Sol Dev Mayoreo";
                }


                if (ClaseEstatica.Usuario.Uen == 3)
                {
                    cbx_AgenteServicio.Text = Resultado[6];

                    if (cbx_AgenteServicio.Text == "")
                    {
                        lbl_AgenteServicio.Visible = false;
                        cbx_AgenteServicio.Visible = false;
                    }
                    else
                    {
                        lbl_AgenteServicio.Visible = true;
                        cbx_AgenteServicio.Visible = true;
                    }
                }

                //this.Text = " Venta de " + "Devolucion";
                LlenarConcepto();
                cbx_Cliente.Text = Resultado[0];
                txt_ClienteNombre.Text = Resultado[1];
                cbx_Agente.Text = Resultado[2];
                cbx_Canal.Text = Resultado[3];
                cbx_Condicion.Text = "(Fecha)";
                cbx_Almacen.Text = controlador.AlmacenDeSucursal(ClaseEstatica.Usuario.sucursal);
                txt_Referencia.Text = Mov + " " + MovID.ToUpper();
                codigo = cbx_Cliente.Text;
                txt_Pago.Text = monedero;
                txt_FechaFac.Text = Resultado[11];
                //txt_FechaFac.Enabled = false;
                if (Mov == "Factura Mayoreo" || Mov == "Factura" || Mov == "Factura VIU")
                    cbx_Concepto.Text = "CAMBIO DE MCIA";

                if (monedero == "")
                {
                    txt_Pago.Visible = false;
                    lbl_MonederoRedimido.Visible = false;
                    if (ClaseEstatica.Usuario.Uen == 1 || ClaseEstatica.Usuario.Uen == 2)
                        gbx_DatosGenerales.Size = new Size(711, 197);
                }
                else
                {
                    txt_Pago.Text = "$" + Convert.ToDouble(monedero).ToString("0.00");
                }

                if (ClaseEstatica.Usuario.Uen == 3) cbx_Almacen.Enabled = true;
                ObtenIdVenta();
                if (lbl_ID.Text == "")
                {
                    MessageBox.Show("Error al generar id de venta", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    Dispose();
                }

                DetalleDev();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InformacionDev", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void LlenaAlmacen()
        {
            try
            {
                if (Almacen != null)
                {
                    cbx_Almacen.Items.Add(Almacen);
                    cbx_Almacen.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ObtenIdVenta()
        {
            try
            {
                Concepto = cbx_Concepto.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                FormaPago = controlador.OrigenDev(Mov, MovID);
                suc = controlador.GetSucursal(cbx_Almacen.Text);

                idVenta = controlador.IdVentaD("MAVI", TipoMovimiento, ClaseEstatica.Usuario.usuario, codigo,
                    Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, cbx_Condicion.Text, suc,
                    uen, "No Identificado", txt_Observaciones.Text, txt_Comentario.Text, cbx_Concepto.Text, FormaPago,
                    txt_Referencia.Text, "", 1,
                    cbx_AgenteServicio.Text, "", false, false, "", false, "", "", "Casa");
                lbl_ID.Text = Convert.ToString(idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenIdVenta", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void DetalleDev()
        {
            try
            {
                DataTable dataSet = new DataTable();

                dataSet = DevolucionMov.DetalleVenta(Convert.ToInt32(idFactura));
                ModeloDetalle = new List<DM0312_M_DetalleDev>();
                double totalImporte = 0.00;

                foreach (DataRow model in dataSet.Rows)
                {
                    DM0312_M_DetalleDev modelDev = new DM0312_M_DetalleDev();
                    modelDev.Articulo = model["Articulo"].ToString();
                    modelDev.Cantidad = model["Cantidad"].ToString();
                    modelDev.PrecioUnitario = model["PrecioUnitario"].ToString();
                    //modelDev.Importe = model["Importe"].ToString();
                    modelDev.Importe = model["Importe"].ToString();
                    //-CorreccionDevolucionSeries
                    modelDev.Serie = model["Tipo"].ToString().Equals("Serie") ? model["Serie"].ToString() : "";
                    //-CorreccionPropiedadesDevolucion
                    modelDev.Cuadro = model["Propiedades"].ToString();
                    modelDev.CantidadDevolver = Convert.ToInt32(model["CantidadDevolver"].ToString());
                    modelDev.Descripcion = model["Descripcion"].ToString();
                    modelDev.Unidad = model["Unidad"].ToString();
                    modelDev.Tipo = model["Tipo"].ToString();
                    modelDev.bandera = Convert.ToInt32(model["bandera"].ToString());
                    ////Se agrega renglon////
                    modelDev.renglon = Convert.ToInt32(model["Renglon"].ToString());
                    /////////////////////////
                    ModeloDetalle.Add(modelDev);
                    if (Convert.ToInt32(modelDev.CantidadDevolver) > 0)
                        totalImporte = Convert.ToInt32(modelDev.CantidadDevolver) *
                                       (totalImporte + Convert.ToDouble(modelDev.PrecioUnitario.Replace("$", "")));

                    if (modelDev.Serie != "")
                    {
                        modeloSeries = new MSerieArticulos();
                        modeloSeries.Serie = modelDev.Serie;
                        modeloSeries.Editar = true;
                        ListInIdDevolucion.Add(modeloSeries);
                    }
                }


                dvg_detalleVenta.DataSource = null;
                dvg_detalleVenta.DataSource = ModeloDetalle;


                dvg_detalleVenta.Columns["Articulo"].ReadOnly = true;
                dvg_detalleVenta.Columns["Cantidad"].ReadOnly = true;
                dvg_detalleVenta.Columns["PrecioUnitario"].ReadOnly = true;
                // this.dvg_detalleVenta.Columns["Importe"].ReadOnly = true;
                dvg_detalleVenta.Columns["Importe"].ReadOnly = true;
                dvg_detalleVenta.Columns["Serie"].ReadOnly = true;
                dvg_detalleVenta.Columns["Descripcion"].Visible = false;
                dvg_detalleVenta.Columns["Unidad"].Visible = false;


                string Unidad = dvg_detalleVenta.CurrentRow.Cells[7].Value.ToString();
                lblUnidad.Text = "Unidad: " + Unidad;
                string Descripcion = dvg_detalleVenta.CurrentRow.Cells[6].Value.ToString();
                lblDescr.Text = "Descripcion: " + Descripcion;

                txtSubTotal.Text = Convert.ToDouble(importe).ToString("C");
                txtImpuestos.Text = Convert.ToDouble(impuestos).ToString("C");
                total = Convert.ToDouble(importe) + Convert.ToDouble(impuestos);
                txtTotal.Text = total.ToString("C");
                txt_ImporteDev.Text = Convert.ToDouble(totalImporte).ToString("C");
                int height = 40;


                //this.dvg_detalleVenta.Columns["Unidad"]

                foreach (DataGridViewRow item in dvg_detalleVenta.Rows)
                    if (height < 150)
                        height += item.Height;
                dvg_detalleVenta.Height = height;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DetalleDev", "DM0312_Devolucion", ex);
                MessageBox.Show(ex.Message);
            }
        }


        public void GuardarDetalle()
        {
            int renglonID = 0;
            int renglon = 0;
            int renglonSub = 1;
            res = true;

            try
            {
                foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                    if (item.CantidadDevolver.ToString() != "0")
                        if (res)
                        {
                            if (item.Tipo == "Juego")
                            {
                                renglonID = renglonID + 1;
                                renglon = renglon + 2048;
                                res = DevolucionMov.InsertVentaD_Dev(item, idVenta, Convert.ToInt32(idFactura), renglon,
                                    renglonID);
                                List<string> Lista = new List<string>();
                                Lista = DevolucionMov.ArtPaquetes(item.Articulo);
                                foreach (string ListaPaquertes in Lista)
                                {
                                    int canP = controlador.CantidadPaqueteDev(ListaPaquertes,
                                        Convert.ToInt32(idFactura));
                                    res = DevolucionMov.InsertVentaD_DevPaquetes(item, ListaPaquertes, idVenta,
                                        Convert.ToInt32(idFactura), renglon, renglonID, renglonSub, canP);
                                    renglonSub++;
                                }

                                contadorGuardarD++;
                            }
                            else
                            {
                                renglonID = renglonID + 1;
                                renglon = renglon + 2048;
                                res = DevolucionMov.InsertVentaD_Dev(item, idVenta, Convert.ToInt32(idFactura), renglon,
                                    renglonID);
                                contadorGuardarD++;
                            }

                            DevolucionMov.UpdateVentaCteD(Convert.ToInt32(idFactura), item.Articulo,
                                item.CantidadDevolver);
                        }

                DevolucionMov.InsertspVentaCteMonedero_Dev(ClaseEstatica.Usuario.sucursal, idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarDetalle", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void llenarLabels(DM0312_M_DetalleDev model)
        {
            try
            {
                lblUnidad.Text = "Unidad:" + model.Unidad;
                lblDescr.Text = "Descripción:" + model.Descripcion;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llenarLabels", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ActualizarInfoIdVenta()
        {
            try
            {
                bool Actualiza = new bool();
                Concepto = cbx_Concepto.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                FormaPago = controlador.OrigenDev(Mov, MovID);
                suc = controlador.GetSucursal(cbx_Almacen.Text);
                Actualiza = controlador.ActualizaIdVentaD("MAVI", TipoMovimiento, ClaseEstatica.Usuario.usuario, codigo,
                    Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, cbx_Condicion.Text, suc,
                    uen, "No Identificado", txt_Observaciones.Text, txt_Comentario.Text, cbx_Concepto.Text, FormaPago,
                    txt_Referencia.Text, "", 2, idVenta, ValidaEstatus, cbx_AgenteServicio.Text, "", false, false,
                    false, "", "", "", "Casa");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizarInfoIdVenta", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void EliminarId()
        {
            try
            {
                bool Eliminar = new bool();
                Eliminar = controlador.EliminarIdVenta(3, idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarId", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }


        private async void Afectar()
        {
            string Canal = EnviarA.ToString();
            string[] IDyCategoria = CDetalleVenta.ObtenerCategoriaCanal(Canal);
            int EnteroCategoria = 1;

            int EnteroEmision = 0;
            int EnteroVencimiento = 1;
            string[] FechaEmisionyVencimiento = controlador.ObtenerFechasParaDetalle(idVenta);

            string[] Parametros =
            {
                TipoMovimiento,
                "", //movID
                "VTAS",
                lbl_ID.Text,
                cbx_Cliente.Text,
                "SINAFECTAR",
                EnviarA.ToString(),
                FechaEmisionyVencimiento[EnteroEmision], //fecha alta
                ClaseEstatica.Usuario.sucursal.ToString(),
                cbx_Condicion.Text,
                IDyCategoria[EnteroCategoria], //categoriaenviarA
                "", //articulo seleccionado
                cbx_Almacen.Text,
                ClaseEstatica.Usuario.Uen.ToString(),
                "", //origenID
                "", //referencia orden compra
                "", //origen
                total.ToString("0.00"),
                "", //mov tipo
                FechaEmisionyVencimiento[EnteroVencimiento], //vencimiento
                "", //origen tipo
                Convert.ToDouble(impuestos).ToString("0.00"), //impuestos
                Convert.ToDouble(importe).ToString("0.00"), //importe
                "", //origen tipo mov
                pedComer, //idecommerce
                IDyCategoria[EnteroCategoria],
                string.Empty,
                string.Empty
            };

            string msgPrecaucion = string.Empty;
            string msgTitulo = "";

            if (!frmLoading.Visible)
            {
                frmLoading.Show(this);
                CDetalleVenta.DesabilitarControles(false, this);
            }

            List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
            CDetalleVenta.CargaMovimientoCreado(Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), VentasSeleccionadas);

            if (await Task.Run(() => CDetalleVenta.ValidacionesAfectar(Parametros, ref msgPrecaucion)))
                if (await Task.Run(() => CDetalleVenta.CondicionAfectar(Parametros, ref msgPrecaucion)))
                    if (await Task.Run(() => CDetalleVenta.Afectar(Parametros, ref msgPrecaucion, ref msgTitulo)))
                    {
                        if (frmLoading.Visible)
                        {
                            frmLoading.Hide();
                            CDetalleVenta.DesabilitarControles(true, this);
                        }

                        MessageBox.Show("Movimiento afectado satisfactoriamente", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        CDetalleVenta.CargaMovimientoCreado(
                            Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                            Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                            VentasSeleccionadas, true);
                        AbrirDetalle(VentasSeleccionadas);
                    }

            if (frmLoading.Visible)
            {
                frmLoading.Hide();
                CDetalleVenta.DesabilitarControles(true, this);
            }

            if (msgPrecaucion != string.Empty)
            {
                string Titulo = "Afectar";
                if (msgTitulo != string.Empty) Titulo = "Error: " + msgTitulo;
                MessageBox.Show(msgPrecaucion, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Abre el detalle del mov afectado / creado
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void AbrirDetalle(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_ExploradorVentas.ListaExplorador = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
            controllerExplorador.LLenadoListaArticulosSeleccionados(VentasSeleccionadas);
            DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
            detalle = (DM0312_DetalleVenta)UsuarioAcceso.AplicarVistas(detalle);
            string[] ParametrosAnticipos = { "" };
            CerrarVenta = true;
            Close();
            detalle.Show();
            detalle.TopMost = true;
            detalle.Focus();
        }

        #endregion

        #region Eventos

        private void cbx_Almacen_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(4);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Almacen.Items.Clear();
            LlenaAlmacen();
            ActualizarInfoIdVenta();

            cbx_Almacen.Focus();
            SendKeys.Send("{tab}");
            //ComponentesFocus();
        }

        private void cbx_Almacen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ValidaAlmacen();
        }

        private void cbx_Almacen_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && cbx_Cliente.Focused == false) ValidaAlmacen();
        }

        private void btn_InformacionCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbx_Cliente.Text == "")
                {
                    MessageBox.Show("Ingrese un Cliente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "InformacionCliente")
                        {
                            forma.Close();
                            break;
                        }

                    InformacionCliente infoCliente = new InformacionCliente();
                    infoCliente.mensaje = cbx_Cliente.Text;
                    infoCliente.Show();
                }
            }
            catch
            {
                MessageBox.Show("No es una cuenta correcta", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }


        private void cbx_Concepto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void txt_Observaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text))
                    ActualizarInfoIdVenta();
        }

        private void txt_Comentario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text))
                    ActualizarInfoIdVenta();
        }

        private void txt_Observaciones_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void txt_Comentario_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
            {
                if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    EliminarId();
                    Dispose();
                }
            }
            else
            {
                Dispose();
            }
        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {
        }

        private void DM0312_DevolucionAdj_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!CerrarVenta)
                if (lbl_ID.Text != "")
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        EliminarId();
                        ClaseEstatica.FormActivo = string.Empty;
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(lbl_ID.Text);
        }

        private void cbx_SelecTodo_CheckedChanged(object sender, EventArgs e)
        {
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                if (item.bandera != 1)
                    EliminarSeries();


            if (cbx_SelecTodo.Checked && cbx_SelecTodo.Focused)
            {
                ModeloDetalle = ModeloDetalle.Select(x =>
                {
                    x.CantidadDevolver = Convert.ToInt32(x.Cantidad);
                    return x;
                }).ToList();
                renglonIDV();
            }
            else
            {
                if (cbx_SelecTodo.Focused)
                    ModeloDetalle = ModeloDetalle.Select(x =>
                    {
                        x.CantidadDevolver = 0;
                        return x;
                    }).ToList();
            }

            dvg_detalleVenta.DataSource = null;
            dvg_detalleVenta.DataSource = ModeloDetalle;
            dvg_detalleVenta.Columns["Articulo"].ReadOnly = true;
            dvg_detalleVenta.Columns["Cantidad"].ReadOnly = true;
            dvg_detalleVenta.Columns["PrecioUnitario"].ReadOnly = true;
            dvg_detalleVenta.Columns["Importe"].ReadOnly = true;
            dvg_detalleVenta.Columns["Serie"].ReadOnly = true;
            dvg_detalleVenta.Columns["Descripcion"].Visible = false;
            dvg_detalleVenta.Columns["Unidad"].Visible = false;
        }

        private void dvg_detalleVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            string Unidad = dvg_detalleVenta.CurrentRow.Cells[7].Value.ToString();

            lblUnidad.Text = "Unidad: " + Unidad;

            string descripcion = dvg_detalleVenta.CurrentRow.Cells[6].Value.ToString();

            lblDescr.Text = "Descripcion: " + descripcion;

            DM0312_M_DetalleDev model = new DM0312_M_DetalleDev();

            model = (DM0312_M_DetalleDev)dvg_detalleVenta.CurrentRow.DataBoundItem;

            if (Convert.ToInt32(model.CantidadDevolver) <= 0)
                return;

            if (e.ColumnIndex == 4)
                if (model.Tipo == "Serie" && model.bandera == 0)
                {
                    DM0312_DevSerieArticulo frm = new DM0312_DevSerieArticulo();

                    frm.IdVentaDev = idVenta;
                    frm.IdVentaFactura = Convert.ToInt32(idFactura);
                    frm.articulo = model.Articulo;
                    frm.descripcion = model.Descripcion;
                    frm.ReferenciaFactura = txt_Referencia.Text;
                    frm.Cantidad = Convert.ToInt32(model.CantidadDevolver);
                    frm.SucursalOrigen = suc;
                    frm.RenglonID = model.renglon;

                    frm.ShowDialog();

                    model.Serie = ControladorSerie.GetSerie(idVenta, model.Articulo);
                }
        }

        public void AfectarF()
        {
            string tipoP = "";
            string SerieP = "";
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
            {
                if ((item.bandera == 1) & (item.Tipo == "Serie") & (item.CantidadDevolver > 0))
                {
                    ListInIdDevolucion = new List<MSerieArticulos>();

                    //-CorreccionDevolucionSeries  
                    if (item.Serie != "")
                    {
                        modeloSeries = new MSerieArticulos();
                        modeloSeries.Serie = item.Serie;
                        modeloSeries.Cuadro = item.Cuadro; //-CorreccionPropiedadesDevolucion
                        modeloSeries.Editar = true;
                        ListInIdDevolucion.Add(modeloSeries);
                    }

                    DevolucionMov.DeleteSeries(idVenta, item.Articulo);
                    List<MSerieArticulos> series = ListInIdDevolucion.Where(x => x.Serie == item.Serie).ToList();
                    //ControladorSerie.ActualizarSerie(idVenta, item.Articulo, ListOldSeries, ListInIdDevolucion, suc, item.renglon);
                    ControladorSerie.ActualizarSerie(idVenta, item.Articulo, ListOldSeries, series, suc, item.renglon);
                }

                if (item.Tipo == "Juego")
                {
                    List<string> Lista = new List<string>();
                    Lista = DevolucionMov.ArtPaquetes(item.Articulo);
                    foreach (string ListaPaquertes in Lista)
                    {
                        tipoP = DevolucionMov.TipoArtPaquetes(ListaPaquertes);

                        if (tipoP == "Serie")
                        {
                            ListInIdDevolucion = new List<MSerieArticulos>();
                            SerieP = DevolucionMov.SerieArtPaquete(idFactura, ListaPaquertes);
                            string propiedad = DevolucionMov.obtenerPropiedad(idFactura, ListaPaquertes);
                            modeloSeries = new MSerieArticulos();
                            modeloSeries.Serie = SerieP;
                            modeloSeries.Editar = true;
                            modeloSeries.Cuadro = propiedad;
                            ListInIdDevolucion.Add(modeloSeries);
                            DevolucionMov.DeleteSeries(idVenta, ListaPaquertes);
                            ControladorSerie.ActualizarSerie(idVenta, ListaPaquertes, ListOldSeries, ListInIdDevolucion,
                                suc, item.renglon);
                        }
                    }

                    contadorGuardarD++;
                }
            }


            if (!ValidacionSeriesAfectar())
            {
                MessageBox.Show("Error el número de series a devolver no coninciden con las insertadas en serielotemov",
                    "Error!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            GuardarDetalle();
            if (res)
            {
                if (contadorGuardarD > 0)
                    Afectar();
                else
                    MessageBox.Show("No hay articulos a devolver", "Mensaje!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
            }
        }

        private void btn_Afecta_Click(object sender, EventArgs e)
        {
            AfectarDevolucion();
        }

        private void AfectarDevolucion()
        {
            //-CandadoEmbarque
            if (Mov == "Factura" || Mov == "Factura VIU" || Mov == "Factura Mayoreo" || Mov == "Sol Dev Mayoreo")
            {
                string[] sDatosEmbarque = DevolucionMov.validarEstatusEmbarque(MovID).Split('|');
                if (sDatosEmbarque.Length > 0)
                    if (sDatosEmbarque[0] == "SINAFECTAR" || sDatosEmbarque[0] == "PENDIENTE")
                    {
                        MessageBox.Show(
                            "La factura se encuentra en el embarque ID:" + sDatosEmbarque[1] +
                            ", en estatus sin afectar o pendiente, no se puede realizar la solicitud devolución",
                            "Precaucion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
            }

            if (!cbx_SelecTodo.Checked)
                if (DevolucionMov.validarSiEsPromocion(MovID))
                    if (DevolucionMov.validarDevolucionVenta(Mov + " " + MovID))
                    {
                        MessageBox.Show(
                            "Ya no se pueden hacer devoluciones parciales, solo totales, favor de realizarlas",
                            "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

            DateTime fechaDev = DevolucionMov.fechaA(Convert.ToInt32(idFactura));
            DateTime fechad = fechaDev.AddDays(2);
            DevolucionMov.borrarVentaCteD(Convert.ToInt32(idFactura), ClaseEstatica.WorkStation);
            DevolucionMov.InsertspVentaCte_Dev(codigo, fechaDev, fechad);
            AfectarF();
        }

        private void dvg_detalleVenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dvg_detalleVenta.CurrentCell.ColumnIndex == 5)
                if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
        }

        private void dvg_detalleVenta_SelectionChanged(object sender, EventArgs e)
        {
            int index = dvg_detalleVenta.CurrentRow.Index;

            if (index == -1)
                return;

            modeloVentaDetalle = new DM0312_M_DetalleDev();

            modeloVentaDetalle = (DM0312_M_DetalleDev)dvg_detalleVenta.CurrentRow.DataBoundItem;

            llenarLabels(modeloVentaDetalle);

            dvg_detalleVenta.EndEdit();
            double totalImporte = 0.00;
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                if (item.CantidadDevolver.ToString() != "0")
                    totalImporte = totalImporte + Convert.ToInt32(item.CantidadDevolver) *
                        Convert.ToDouble(item.PrecioUnitario.Replace("$", ""));
            txt_ImporteDev.Text = Convert.ToDouble(totalImporte).ToString("C");
        }


        private void dvg_detalleVenta_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            string format = string.Empty;
            if (modeloVentaDetalle != null)
            {
                if (modeloVentaDetalle.Articulo == null) return;
            }
            else
            {
                return;
            }

            try
            {
                if (btn_Regresar.Focused == false)
                {
                    if (e.ColumnIndex == 5)
                    {
                        format = e.FormattedValue.ToString();

                        if (format == "")
                        {
                            MessageBox.Show("Debe poner un valor", "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            ResetOldValue(format, e.ColumnIndex);
                            return;
                        }

                        double format_ = Convert.ToDouble(format);

                        if (format_ > Convert.ToDouble(modeloVentaDetalle.Cantidad))
                        {
                            MessageBox.Show(
                                "la cantidad a devolver no debe ser mayor a la cantidad de articulos vendidos",
                                "Advertencia!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ResetOldValue(format, e.ColumnIndex);
                            return;
                        }

                        if (format_ < 0 || (format_ == 0.0 && format != "0"))
                        {
                            MessageBox.Show("Valor incorrecto", "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            ResetOldValue(format, e.ColumnIndex);
                            return;
                        }

                        if (format.Contains(".") | (Convert.ToString(format_) == "0.0"))
                        {
                            MessageBox.Show("Valor incorrecto", "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            ResetOldValue(format, e.ColumnIndex);
                            return;
                        }

                        if (modeloVentaDetalle.bandera == 0)
                            if (Convert.ToInt32(modeloVentaDetalle.CantidadDevolver) != Convert.ToInt32(format_))
                            {
                                controlador.DeleteSeriesLotes(modeloVentaDetalle.Serie, idVenta,
                                    modeloVentaDetalle.Articulo);

                                modeloVentaDetalle.Serie =
                                    ControladorSerie.GetSerie(idVenta, modeloVentaDetalle.Articulo);
                            }
                    }
                }
                else
                {
                    ResetOldValue(format, e.ColumnIndex);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == "La cadena de entrada no tiene el formato correcto.")
                {
                    MessageBox.Show("El valor debe ser Numérico", "Advertencia!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    ResetOldValue(format, e.ColumnIndex);
                    return;
                }

                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        public void renglonIDV()
        {
            double totalImporte = 0.00;
            int renglon = 1;

            //int sum = 0;
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                //if (item.CantidadDevolver != Convert.ToInt32(item.Cantidad))
                //{
                //    cbx_SelecTodo.Checked = false;
                //}
                if (item.CantidadDevolver.ToString() != "0")
                {
                    totalImporte = totalImporte + Convert.ToInt32(item.CantidadDevolver) *
                        Convert.ToDouble(item.PrecioUnitario.Replace("$", ""));
                    //item.renglon = renglon;
                    renglon++;
                }
            //item.renglon = 0;
        }

        private void dvg_detalleVenta_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (btn_Regresar.Focused == false)
            {
                double totalImporte = 0.00;
                renglonIDV();
                //if (validaSelc == 1)
                //{
                //    cbx_SelecTodo.Checked = true;
                //}
                //else
                //{
                //    cbx_SelecTodo.Checked = false;
                //}

                double sumCantidadDev = ModeloDetalle.Sum(x => x.CantidadDevolver);

                double sumCantidad = ModeloDetalle.Sum(x => Convert.ToInt32(x.Cantidad));

                if (sumCantidad == sumCantidadDev)
                    cbx_SelecTodo.Checked = true;
                else
                    cbx_SelecTodo.Checked = false;

                txt_ImporteDev.Text = Convert.ToDouble(totalImporte).ToString("C");


                llenarGridAfterUpdateSeries(e.ColumnIndex, e.RowIndex);
            }
        }

        #endregion

        #region Comentarios

        private void txt_Observaciones_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Observaciones =
                ComentariosDevolucion.Where(x => x.Campo.Equals("Observaciones")).FirstOrDefault();
            if (Observaciones != null) txt_Comentarios.Text = Observaciones.Comentario;
        }

        private void txt_Comentario_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Comentario =
                ComentariosDevolucion.Where(x => x.Campo.Equals("Comentarios")).FirstOrDefault();

            if (Comentario != null) txt_Comentarios.Text = Comentario.Comentario;
        }

        private void cbx_SelecTodo_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta SelTodo =
                ComentariosDevolucion.Where(x => x.Campo.Equals("Devolver")).FirstOrDefault();
            if (SelTodo != null) txt_Comentarios.Text = SelTodo.Comentario;
        }

        private void cbx_Concepto_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Concepto =
                ComentariosDevolucion.Where(x => x.Campo.Equals("Concepto")).FirstOrDefault();
            if (Concepto != null) txt_Comentarios.Text = Concepto.Comentario;
        }

        private void dvg_detalleVenta_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Detalle =
                ComentariosDevolucion.Where(x => x.Campo.Equals("TablaDevolver")).FirstOrDefault();
            if (Detalle != null) txt_Comentarios.Text = Detalle.Comentario;
        }

        #endregion

        #region MetodosSeries //Rodolfo

        private void llenarGridAfterUpdateSeries(int ColumnIndex, int RowIndex)
        {
            dvg_detalleVenta.DataSource = null;
            dvg_detalleVenta.DataSource = ModeloDetalle;
            dvg_detalleVenta.Columns["Articulo"].ReadOnly = true;
            dvg_detalleVenta.Columns["Cantidad"].ReadOnly = true;
            dvg_detalleVenta.Columns["PrecioUnitario"].ReadOnly = true;
            dvg_detalleVenta.Columns["Importe"].ReadOnly = true;
            dvg_detalleVenta.Columns["Serie"].ReadOnly = true;
            dvg_detalleVenta.Columns["Descripcion"].Visible = false;
            dvg_detalleVenta.Columns["Unidad"].Visible = false;

            dvg_detalleVenta.Rows[RowIndex].Selected = true;
            dvg_detalleVenta.CurrentCell = dvg_detalleVenta.Rows[RowIndex].Cells[ColumnIndex];
        }


        private void EliminarSeries()
        {
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                if (item.Tipo == "Serie" && item.bandera != 1)
                {
                    controlador.DeleteSeriesLotes(item.Serie, idVenta, item.Articulo);

                    item.Serie = ControladorSerie.GetSerie(idVenta, item.Articulo);
                }
        }

        private bool ValidacionSeriesAfectar()
        {
            IEnumerable<int> model = ModeloDetalle.Where(x => x.Tipo == "Serie")
                .Select(x => Convert.ToInt32(x.CantidadDevolver));

            string tipoP = "";
            int contSeriesP = 0;
            foreach (DM0312_M_DetalleDev item in ModeloDetalle)
                if (item.Tipo == "Juego")
                {
                    List<string> Lista = new List<string>();
                    Lista = DevolucionMov.ArtPaquetes(item.Articulo);
                    foreach (string ListaPaquertes in Lista)
                    {
                        tipoP = DevolucionMov.TipoArtPaquetes(ListaPaquertes);

                        if (tipoP == "Serie") contSeriesP = contSeriesP + item.CantidadDevolver;
                    }
                }

            //var modelP = ModeloDetalle.Where(x => x.Tipo =="Juego").Select(x => Convert.ToInt32(x.CantidadDevolver));
            int sum = model.Sum() + contSeriesP;

            int res = DevolucionMov.CountSerieLoteMov(idVenta);

            if (sum != res)
                return false;
            return true;
        }

        #endregion
    }
}