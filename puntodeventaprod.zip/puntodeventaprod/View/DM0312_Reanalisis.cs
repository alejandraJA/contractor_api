﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_Reanalisis : Form
    {
        public DM0312_Reanalisis()
        {
            InitializeComponent();
        }

        public DM0312_Reanalisis(int IdVenta)
        {
            InitializeComponent();
            initReanalisisObj(IdVenta);
            SetAgenteDeReanalisis();

            maxImporteARecuperar = controlador.maxImporteARecuperar(IdVenta);
        }

        ~DM0312_Reanalisis()
        {
            GC.Collect();
        }

        private void initReanalisisObj(int IdVenta)
        {
            try
            {
                reanalisis.idVenta = IdVenta;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        private void Reanalisis_Load(object sender, EventArgs e)
        {
            txt_fechahora.Text = controlador.FechaActualServidor().ToString();

            //LlenaComboReanalisis();
            cbo_TipoReanalisisFill();
            LlenaComboRespuesta();
            CargarListaAgente();
            TReanalisisIsCredito();
            cbx_RealizaAFill();
        }

        private void SetAgenteDeReanalisis()
        {
            EventoController EV = new EventoController();
            string usuario = EV.getUltimoUsuarioReactivacion(reanalisis.idVenta);

            try
            {
                txt_AgenteReanalisis.Text = usuario.ToUpper();
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, e);
            }
        }

        public void TReanalisisIsCredito()
        {
            if (cbo_TipoReanalisis.Text == "REANALISIS CREDITO MEN05340")
            {
                label5.Visible = false;
                txt_AgenteReanalisis.Visible = false;
                btn_BuscarAgente.Visible = false;
            }
        }


        public void LlenaComboReanalisis()
        {
            try
            {
                List<string> EventosReanalisis = new List<string>();
                EventosReanalisis = controlador.ListaReanalis();
                if (EventosReanalisis.Count > 0)
                {
                    cbo_TipoReanalisis.DataSource = null;
                    cbo_TipoReanalisis.DataSource = EventosReanalisis.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        private void cbo_TipoReanalisisFill()
        {
            List<cbValue> CBValues = new List<cbValue>();
            List<DM0312_MConsultarEvento> eventoList = controlador.ListaReanalis2();

            eventoList.ForEach(delegate(DM0312_MConsultarEvento evento)
            {
                CBValues.Add(new cbValue { Index = evento.Evento, Value = evento.Clave });
            });

            cbo_TipoReanalisis.DataSource = CBValues;
            cbo_TipoReanalisis.DisplayMember = "Index";
            cbo_TipoReanalisis.ValueMember = "Value";
        }


        private void LlenaComboRespuesta()
        {
            try
            {
                List<string> EventosRespuesta = new List<string>();
                EventosRespuesta = controlador.ListaRespuesta();
                if (EventosRespuesta.Count > 0)
                {
                    cbo_TipoRespuesta.DataSource = null;
                    cbo_TipoRespuesta.DataSource = EventosRespuesta.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        public void CargarListaAgente()
        {
            try
            {
                List<string> EventListaAgente = new List<string>();
                EventListaAgente = controlador.ListaAgente();
                if (EventListaAgente.Count > 0) listaAgentes = EventListaAgente.ToArray();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaListaAgente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void cbo_tipoReanalisis_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbo_TipoReanalisis.Text == "REANALISIS CREDITO MEN05340")
            {
                label5.Visible = false;
                txt_AgenteReanalisis.Visible = false;
                btn_BuscarAgente.Visible = false;
            }
            else
            {
                label5.Visible = true;
                txt_AgenteReanalisis.Visible = true;
                btn_BuscarAgente.Visible = true;
            }
        }

        private void btn_cancel_reanalisis_Click(object sender, EventArgs e)
        {
            Close();
            Dispose();
        }

        private void btn_acep_reanalisis_Click(object sender, EventArgs e)
        {
            //-Reanalisis
            cbValue evento = (cbValue)cbo_TipoReanalisis.SelectedItem;
            string claveEvento = evento.Value;

            if (evento.Index == "REANALISIS CREDITO MEN05340" && string.IsNullOrEmpty(txt_Notas.Text))
            {
                MessageBox.Show("El campo notas está vacío. ", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if ((string.IsNullOrEmpty(txt_AgenteReanalisis.Text) || string.IsNullOrEmpty(txt_Notas.Text)) &&
                txt_AgenteReanalisis.Visible)
            {
                MessageBox.Show("Existen campos vacíos. ", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (!listaAgentes.Contains(txt_AgenteReanalisis.Text) && txt_AgenteReanalisis.Visible)
            {
                MessageBox.Show("Agente no existe en la base de datos. ", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            double importeRescatado = 0.0;
            if (!double.TryParse(txt_ImporteRescatado.Text, out importeRescatado))
            {
                MessageBox.Show("Error en el capo Importe Rescatado", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (importeRescatado > maxImporteARecuperar)
            {
                MessageBox.Show("no se puede ingresar un importe mayor a: " + maxImporteARecuperar, "Advertencia!!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            insertMovimientoReanalisis(claveEvento);
        }

        private void insertMovimientoReanalisis(string claveEvento)
        {
            cbValue analista = (cbValue)cb_UsuarioCredito.SelectedItem;

            controlador.MovimientoReanalis(
                reanalisis.idVenta,
                ClaseEstatica.Usuario.Usser,
                claveEvento,
                txt_AgenteReanalisis.Text,
                cbo_TipoRespuesta.Text,
                txt_ImporteRescatado.Text + "(°3°)" + analista.Index + "(°3°)" + txt_Notas.Text);
            Close();
            Dispose();
        }

        private void btn_BuscarAgente_Click(object sender, EventArgs e)
        {
            DM0312_SeleccAgenteReanalisis seleccAgente = new DM0312_SeleccAgenteReanalisis();
            seleccAgente.ShowDialog();
            agente = seleccAgente.agente;
            txt_AgenteReanalisis.Text = agente;
        }

        private void txt_ImporteRescatado_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.') e.Handled = true;
        }

        private void cbx_RealizaAFill()
        {
            List<cbValue> CBValues = new List<cbValue>();
            List<AnalistaCreditoModel> analistList = controlador.listaAnalistas();

            analistList.ForEach(delegate(AnalistaCreditoModel analista)
            {
                CBValues.Add(new cbValue { Index = analista.usuario, Value = analista.analista });
            });

            cb_UsuarioCredito.DataSource = CBValues;
            cb_UsuarioCredito.DisplayMember = "Value";
            cb_UsuarioCredito.ValueMember = "Index";

            cb_UsuarioCredito.AutoCompleteMode = AutoCompleteMode.Suggest;
            cb_UsuarioCredito.AutoCompleteSource = AutoCompleteSource.ListItems;
        }

        private void btn_Cerrar_Click(object sender, EventArgs e)
        {
            Close();
            Dispose();
        }

        #region atributos

        private readonly DM0312_C_ExploradorVenta controlador = new DM0312_C_ExploradorVenta();

        public int id;
        public string agente;
        public string[] listaAgentes;
        public double maxImporteARecuperar;

        private readonly Reanalisis reanalisis = new Reanalisis();

        private class cbValue
        {
            public string Value { get; set; }
            public string Index { get; set; }
        }

        #endregion
    }
}