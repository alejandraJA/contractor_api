﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleInfoSerieArticulo : Form
    {
        public static string SerieSeleccionada = string.Empty;
        private readonly Funciones funciones = new Funciones();
        private List<MInfoSerieArticulos> InfoSeries = new List<MInfoSerieArticulos>();

        public DM0312_DetalleInfoSerieArticulo()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            FillGridview();
        }

        ~DM0312_DetalleInfoSerieArticulo()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Llenado de datagrid
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 05/09/17
        protected void FillGridview()
        {
            tb_articulo.Text = DM0312_DetalleSerieArticulo.ArticuloSeleccionado;
            tb_numero.Text = SerieSeleccionada;
            tb_descripcion.Text = DM0312_DetalleSerieArticulo.DescripcionArticulo;
            dgv_movs.DataSource = null;
            InfoSeries = CInfoSerieArticulos.ObtenerInfoSeriesArticulos(SerieSeleccionada);
            dgv_movs.DataSource = InfoSeries;
        }

        /// <summary>
        ///     Regresa a forma anterior
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 05/09/17
        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///     Ordenamiento gridv
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_movs_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(InfoSeries.ToList());
            funciones.OrderGridview(dgv_movs, e.ColumnIndex, TempObjects,
                InfoSeries.GetType().GetGenericArguments().Single());
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleInfoSerieArticulo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        private void DM0312_DetalleInfoSerieArticulo_Load(object sender, EventArgs e)
        {
        }

        private void DM0312_DetalleInfoSerieArticulo_Load_1(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(lbl_numero, "NUMERO DE PIEZAS EXISTENTES");
            toolTip1.SetToolTip(tb_numero, "NUMERO DE PIEZAS EXISTENTES");
            toolTip1.SetToolTip(lbl_articulo, "CLAVE DEL ARTICULO QUE FORMA PARTE DEL PAQUETE");
            toolTip1.SetToolTip(tb_articulo, "CLAVE DEL ARTICULO QUE FORMA PARTE DEL PAQUETE");
            toolTip1.SetToolTip(lbl_descripcion, "DESCRIPCION DEL ARTICULO QUE CONFORMA PARTE DEL PAQUETE");
            toolTip1.SetToolTip(tb_descripcion, "DESCRIPCION DEL ARTICULO QUE CONFORMA PARTE DEL PAQUETE");
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR");
            txt_Comentarios.Text = "FORMA DONDE SE CONSULTAN LOS ARTICULOS QUE CONFORMAN EL PAQUETE";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_movs.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_movs.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_movs.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") dgv_movs.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }
    }
}