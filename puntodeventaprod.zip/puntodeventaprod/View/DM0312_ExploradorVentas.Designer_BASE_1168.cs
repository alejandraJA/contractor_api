﻿using System;

namespace PuntoVenta
{
    partial class DM0312_ExploradorVentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_ExploradorVentas));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbl_Sucursal = new System.Windows.Forms.Label();
            this.txt_Sucursal = new System.Windows.Forms.TextBox();
            this.dtp_Afecha = new System.Windows.Forms.DateTimePicker();
            this.dtp_DeFecha = new System.Windows.Forms.DateTimePicker();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.txt_Buscar = new System.Windows.Forms.TextBox();
            this.cbx_estatus = new System.Windows.Forms.ComboBox();
            this.cbx_movimiento = new System.Windows.Forms.ComboBox();
            this.cbx_BuscarEn = new System.Windows.Forms.ComboBox();
            this.cbx_situacion = new System.Windows.Forms.ComboBox();
            this.lbl_FechaA = new System.Windows.Forms.Label();
            this.lbl_FechaD = new System.Windows.Forms.Label();
            this.lbl_Estatus = new System.Windows.Forms.Label();
            this.lblSituacion = new System.Windows.Forms.Label();
            this.lblMovimiento = new System.Windows.Forms.Label();
            this.lblBuscarEn = new System.Windows.Forms.Label();
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.chk_CreditoCasa = new System.Windows.Forms.CheckBox();
            this.chk_CreditoNuevo = new System.Windows.Forms.CheckBox();
            this.chk_ContadoCasa = new System.Windows.Forms.CheckBox();
            this.chk_ContadoNuevo = new System.Windows.Forms.CheckBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem_nuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_TiempoTotal = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_FormatoExploradorPVC = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_MonederoRedimir = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_ActualizacionDatos = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_ClienteExpress = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarBuroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Excel = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_KardexClienteFinal = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Relacionado = new System.Windows.Forms.ToolStripMenuItem();
            this.envioCorreoWebCrtlF9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capturaDeRelacionadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.camposExtrasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matrizDeAutorizacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reanalisisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuScoring = new System.Windows.Forms.ToolStripMenuItem();
            this.menuOrdenCompra = new System.Windows.Forms.ToolStripMenuItem();
            this.ttCuentaClabe = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Afectar = new System.Windows.Forms.ToolStripMenuItem();
            this.editarVentaCrtlF7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTipRecalificar = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.gbx_Detalle = new System.Windows.Forms.GroupBox();
            this.flp_detalle = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Almacen = new System.Windows.Forms.Label();
            this.txt_DetalleAlmacen = new System.Windows.Forms.TextBox();
            this.lbl_Condicion = new System.Windows.Forms.Label();
            this.txt_Condicion = new System.Windows.Forms.TextBox();
            this.lbl_Referencia = new System.Windows.Forms.Label();
            this.txt_DetalleReferencia = new System.Windows.Forms.TextBox();
            this.lbl_Concepto = new System.Windows.Forms.Label();
            this.txt_DetalleConcepto = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Embarque = new System.Windows.Forms.Label();
            this.txt_DetalleEmbarqueMov = new System.Windows.Forms.TextBox();
            this.txt_DetalleEmbarqueFecha = new System.Windows.Forms.TextBox();
            this.lbl_Descripcion = new System.Windows.Forms.Label();
            this.tb_descripcion = new System.Windows.Forms.TextBox();
            this.dgv_TablaDetalle = new System.Windows.Forms.DataGridView();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.gbx_TableroPr = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel_MovsPr = new System.Windows.Forms.FlowLayoutPanel();
            this.dgv_TablaMovimientos = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_CreditoCasaNum = new System.Windows.Forms.Label();
            this.txt_CreditoCasaNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoNuevoNum = new System.Windows.Forms.Label();
            this.txt_CreditoNuevoNum = new System.Windows.Forms.TextBox();
            this.lbl_ContadoNuevoNum = new System.Windows.Forms.Label();
            this.txt_ContadoNuevoNum = new System.Windows.Forms.TextBox();
            this.lbl_ContadoCasaNum = new System.Windows.Forms.Label();
            this.txt_ContadoCasaNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoCasaMayNum = new System.Windows.Forms.Label();
            this.txt_CreditoCasaMayNum = new System.Windows.Forms.TextBox();
            this.lbl_CreditoNuevoMayNum = new System.Windows.Forms.Label();
            this.txt_CreditoNuevoMayNum = new System.Windows.Forms.TextBox();
            this.btn_storepickupOrders = new System.Windows.Forms.Button();
            this.gbx_Contactos = new System.Windows.Forms.GroupBox();
            this.dgv_Contactos = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem_InvestigacionTel = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.lbl_Comentario = new System.Windows.Forms.Label();
            this.contextMenuStrip4 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_CuentaCaja = new System.Windows.Forms.Label();
            this.gbx_FotoCliente = new System.Windows.Forms.GroupBox();
            this.btnValida = new System.Windows.Forms.Button();
            this.chk_Valido = new System.Windows.Forms.CheckBox();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.txtIdentificacion = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.imgBoxCta = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.historialDeFotosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chk_VIU = new System.Windows.Forms.CheckBox();
            this.chk_MA = new System.Windows.Forms.CheckBox();
            this.chk_MAVI = new System.Windows.Forms.CheckBox();
            this.cbx_creditoNuevoMayoreo = new System.Windows.Forms.CheckBox();
            this.cbx_CreditoCasaMayoreo = new System.Windows.Forms.CheckBox();
            this.Panel_Menu = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.btn_Nuevo = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_Refrescar = new System.Windows.Forms.Button();
            this.btn_SolicitudCancelacion = new System.Windows.Forms.Button();
            this.btnDineralia = new System.Windows.Forms.Button();
            this.btn_HistoSolicitudes = new System.Windows.Forms.Button();
            this.btn_RegistroHuella = new System.Windows.Forms.Button();
            this.btn_Selp = new System.Windows.Forms.Button();
            this.btn_VisorMavi = new System.Windows.Forms.Button();
            this.btn_CalidadCap = new System.Windows.Forms.Button();
            this.btn_ConsultaBuro = new System.Windows.Forms.Button();
            this.btn_HistoricoUniCaja = new System.Windows.Forms.Button();
            this.btn_ResumenFac = new System.Windows.Forms.Button();
            this.btn_KardexCliente = new System.Windows.Forms.Button();
            this.btnPosicionDelMovimiento = new System.Windows.Forms.Button();
            this.btn_PreliminarCobro = new System.Windows.Forms.Button();
            this.btn_InformacionCliente = new System.Windows.Forms.Button();
            this.btn_Eventos = new System.Windows.Forms.Button();
            this.btn_UsuariosTiempos = new System.Windows.Forms.Button();
            this.btn_PosicionMov = new System.Windows.Forms.Button();
            this.btn_Relaciones = new System.Windows.Forms.Button();
            this.BtnProspectoaCliente = new System.Windows.Forms.Button();
            this.btn_CatalagoCalif = new System.Windows.Forms.Button();
            this.btn_AnalistasCredi = new System.Windows.Forms.Button();
            this.BTN_consultaCf = new System.Windows.Forms.Button();
            this.btn_SoporAval = new System.Windows.Forms.Button();
            this.btnKardex = new System.Windows.Forms.Button();
            this.btnScoring = new System.Windows.Forms.Button();
            this.Panel_TiposVenta = new System.Windows.Forms.FlowLayoutPanel();
            this.chk_ClienteEnSucursal = new System.Windows.Forms.CheckBox();
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_TipoCredito = new System.Windows.Forms.Label();
            this.cbx_fechaA = new System.Windows.Forms.TextBox();
            this.btn_ConfColumnas = new System.Windows.Forms.Button();
            this.cbx_fechaD = new System.Windows.Forms.TextBox();
            this.listTipoCredito = new System.Windows.Forms.CheckedListBox();
            this.chk_Devolucion = new System.Windows.Forms.CheckBox();
            this.cbx_Impreso = new System.Windows.Forms.ComboBox();
            this.txt_NombreSucursal = new System.Windows.Forms.TextBox();
            this.lbl_Impreso = new System.Windows.Forms.Label();
            this.flp_PanelEventos = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_Eventos = new System.Windows.Forms.GroupBox();
            this.dgv_Eventos = new System.Windows.Forms.DataGridView();
            this.gbx_PanelHuellas = new System.Windows.Forms.GroupBox();
            this.btn_Contactos = new System.Windows.Forms.Button();
            this.btn_DocumentosAdjuntos = new System.Windows.Forms.Button();
            this.gbx_DocumentosAdj = new System.Windows.Forms.FlowLayoutPanel();
            this.panelIdentifiacion = new System.Windows.Forms.Panel();
            this.pb_Identificacion = new System.Windows.Forms.PictureBox();
            this.lbl_Identificacion = new System.Windows.Forms.Label();
            this.panelComprobante = new System.Windows.Forms.Panel();
            this.lbl_Comprobante = new System.Windows.Forms.Label();
            this.pb_Comprobante = new System.Windows.Forms.PictureBox();
            this.panelTarjetasDigitales = new System.Windows.Forms.Panel();
            this.lbl_TarjetasDig = new System.Windows.Forms.Label();
            this.pb_TarjetasDig = new System.Windows.Forms.PictureBox();
            this.panelPagares = new System.Windows.Forms.Panel();
            this.lbl__Pagares = new System.Windows.Forms.Label();
            this.pb_Pagares = new System.Windows.Forms.PictureBox();
            this.pnlfix_delfix = new System.Windows.Forms.Panel();
            this.SPID = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.NotificarAnalista = new System.Windows.Forms.ToolStripMenuItem();
            this.AgregarEventoMI = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRecalificar = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.gbx_Detalle.SuspendLayout();
            this.flp_detalle.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaDetalle)).BeginInit();
            this.gbx_TableroPr.SuspendLayout();
            this.panel_MovsPr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaMovimientos)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            this.gbx_Contactos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Contactos)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip4.SuspendLayout();
            this.gbx_FotoCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgBoxCta)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            this.Panel_Menu.SuspendLayout();
            this.Panel_TiposVenta.SuspendLayout();
            this.panelContactos.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flp_PanelEventos.SuspendLayout();
            this.gbx_Eventos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Eventos)).BeginInit();
            this.gbx_PanelHuellas.SuspendLayout();
            this.gbx_DocumentosAdj.SuspendLayout();
            this.panelIdentifiacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Identificacion)).BeginInit();
            this.panelComprobante.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Comprobante)).BeginInit();
            this.panelTarjetasDigitales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_TarjetasDig)).BeginInit();
            this.panelPagares.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Pagares)).BeginInit();
            this.pnlfix_delfix.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Sucursal
            // 
            this.lbl_Sucursal.AutoSize = true;
            this.lbl_Sucursal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sucursal.Location = new System.Drawing.Point(783, 15);
            this.lbl_Sucursal.Name = "lbl_Sucursal";
            this.lbl_Sucursal.Size = new System.Drawing.Size(64, 15);
            this.lbl_Sucursal.TabIndex = 39;
            this.lbl_Sucursal.Text = "Sucursal*";
            // 
            // txt_Sucursal
            // 
            this.txt_Sucursal.BackColor = System.Drawing.Color.White;
            this.txt_Sucursal.Location = new System.Drawing.Point(786, 33);
            this.txt_Sucursal.MaxLength = 4;
            this.txt_Sucursal.Name = "txt_Sucursal";
            this.txt_Sucursal.Size = new System.Drawing.Size(55, 20);
            this.txt_Sucursal.TabIndex = 38;
            this.txt_Sucursal.Click += new System.EventHandler(this.txt_Sucursal_Click);
            this.txt_Sucursal.TextChanged += new System.EventHandler(this.txt_Sucursal_TextChanged);
            this.txt_Sucursal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Sucursal_KeyPress);
            // 
            // dtp_Afecha
            // 
            this.dtp_Afecha.CalendarMonthBackground = System.Drawing.SystemColors.HighlightText;
            this.dtp_Afecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Afecha.Location = new System.Drawing.Point(679, 33);
            this.dtp_Afecha.Name = "dtp_Afecha";
            this.dtp_Afecha.Size = new System.Drawing.Size(101, 20);
            this.dtp_Afecha.TabIndex = 22;
            this.dtp_Afecha.ValueChanged += new System.EventHandler(this.dtp_Afecha_ValueChanged);
            // 
            // dtp_DeFecha
            // 
            this.dtp_DeFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_DeFecha.Location = new System.Drawing.Point(572, 33);
            this.dtp_DeFecha.Name = "dtp_DeFecha";
            this.dtp_DeFecha.Size = new System.Drawing.Size(101, 20);
            this.dtp_DeFecha.TabIndex = 21;
            this.dtp_DeFecha.ValueChanged += new System.EventHandler(this.dtp_DeFecha_ValueChanged);
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.AliceBlue;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(5, 108);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(973, 22);
            this.txt_ComentarioAyuda.TabIndex = 37;
            // 
            // txt_Buscar
            // 
            this.txt_Buscar.BackColor = System.Drawing.Color.White;
            this.txt_Buscar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Buscar.Location = new System.Drawing.Point(7, 34);
            this.txt_Buscar.MaxLength = 100;
            this.txt_Buscar.Name = "txt_Buscar";
            this.txt_Buscar.Size = new System.Drawing.Size(98, 20);
            this.txt_Buscar.TabIndex = 1;
            this.txt_Buscar.Click += new System.EventHandler(this.txt_Buscar_Click);
            this.txt_Buscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Buscar_KeyPress);
            // 
            // cbx_estatus
            // 
            this.cbx_estatus.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cbx_estatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_estatus.FormattingEnabled = true;
            this.cbx_estatus.Items.AddRange(new object[] {
            "Cancelado",
            "Concluido",
            "Pendiente",
            "SinAfectar",
            "Todo"});
            this.cbx_estatus.Location = new System.Drawing.Point(460, 33);
            this.cbx_estatus.Name = "cbx_estatus";
            this.cbx_estatus.Size = new System.Drawing.Size(106, 21);
            this.cbx_estatus.TabIndex = 5;
            this.cbx_estatus.SelectedIndexChanged += new System.EventHandler(this.cbx_estatus_SelectedIndexChanged);
            this.cbx_estatus.Click += new System.EventHandler(this.cbx_estatus_Click);
            // 
            // cbx_movimiento
            // 
            this.cbx_movimiento.BackColor = System.Drawing.Color.White;
            this.cbx_movimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_movimiento.FormattingEnabled = true;
            this.cbx_movimiento.Location = new System.Drawing.Point(218, 34);
            this.cbx_movimiento.Name = "cbx_movimiento";
            this.cbx_movimiento.Size = new System.Drawing.Size(121, 21);
            this.cbx_movimiento.TabIndex = 3;
            this.cbx_movimiento.SelectedIndexChanged += new System.EventHandler(this.cbx_movimiento_SelectedIndexChanged);
            this.cbx_movimiento.Click += new System.EventHandler(this.cbx_movimiento_Click);
            // 
            // cbx_BuscarEn
            // 
            this.cbx_BuscarEn.BackColor = System.Drawing.Color.White;
            this.cbx_BuscarEn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_BuscarEn.FormattingEnabled = true;
            this.cbx_BuscarEn.Items.AddRange(new object[] {
            "MovID",
            "Cliente",
            "Nombre",
            "Relacionado",
            "Canal de Venta",
            "Grupo",
            "Calificacion",
            "Seguimiento",
            "Reactivacion",
            "Referencia Anterior",
            "id ecommerce"});
            this.cbx_BuscarEn.Location = new System.Drawing.Point(111, 34);
            this.cbx_BuscarEn.Name = "cbx_BuscarEn";
            this.cbx_BuscarEn.Size = new System.Drawing.Size(101, 21);
            this.cbx_BuscarEn.TabIndex = 2;
            this.cbx_BuscarEn.SelectedIndexChanged += new System.EventHandler(this.cbx_BuscarEn_SelectedIndexChanged);
            this.cbx_BuscarEn.Click += new System.EventHandler(this.cbx_En_Click);
            // 
            // cbx_situacion
            // 
            this.cbx_situacion.BackColor = System.Drawing.Color.White;
            this.cbx_situacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_situacion.FormattingEnabled = true;
            this.cbx_situacion.Location = new System.Drawing.Point(345, 33);
            this.cbx_situacion.Name = "cbx_situacion";
            this.cbx_situacion.Size = new System.Drawing.Size(109, 21);
            this.cbx_situacion.TabIndex = 4;
            this.cbx_situacion.DropDown += new System.EventHandler(this.cbx_situacion_DropDown_1);
            this.cbx_situacion.Click += new System.EventHandler(this.cbx_situacion_Click);
            // 
            // lbl_FechaA
            // 
            this.lbl_FechaA.AutoSize = true;
            this.lbl_FechaA.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FechaA.Location = new System.Drawing.Point(680, 15);
            this.lbl_FechaA.Name = "lbl_FechaA";
            this.lbl_FechaA.Size = new System.Drawing.Size(73, 15);
            this.lbl_FechaA.TabIndex = 6;
            this.lbl_FechaA.Text = "A la Fecha *";
            // 
            // lbl_FechaD
            // 
            this.lbl_FechaD.AutoSize = true;
            this.lbl_FechaD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FechaD.Location = new System.Drawing.Point(569, 15);
            this.lbl_FechaD.Name = "lbl_FechaD";
            this.lbl_FechaD.Size = new System.Drawing.Size(73, 15);
            this.lbl_FechaD.TabIndex = 5;
            this.lbl_FechaD.Text = "De la Fecha ";
            // 
            // lbl_Estatus
            // 
            this.lbl_Estatus.AutoSize = true;
            this.lbl_Estatus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estatus.Location = new System.Drawing.Point(457, 15);
            this.lbl_Estatus.Name = "lbl_Estatus";
            this.lbl_Estatus.Size = new System.Drawing.Size(57, 15);
            this.lbl_Estatus.TabIndex = 4;
            this.lbl_Estatus.Text = "Estatus *";
            // 
            // lblSituacion
            // 
            this.lblSituacion.AutoSize = true;
            this.lblSituacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSituacion.Location = new System.Drawing.Point(342, 15);
            this.lblSituacion.Name = "lblSituacion";
            this.lblSituacion.Size = new System.Drawing.Size(62, 15);
            this.lblSituacion.TabIndex = 3;
            this.lblSituacion.Text = "Situacion ";
            // 
            // lblMovimiento
            // 
            this.lblMovimiento.AutoSize = true;
            this.lblMovimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMovimiento.Location = new System.Drawing.Point(215, 17);
            this.lblMovimiento.Name = "lblMovimiento";
            this.lblMovimiento.Size = new System.Drawing.Size(80, 15);
            this.lblMovimiento.TabIndex = 2;
            this.lblMovimiento.Text = "Movimiento *";
            // 
            // lblBuscarEn
            // 
            this.lblBuscarEn.AutoSize = true;
            this.lblBuscarEn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuscarEn.Location = new System.Drawing.Point(108, 16);
            this.lblBuscarEn.Name = "lblBuscarEn";
            this.lblBuscarEn.Size = new System.Drawing.Size(24, 15);
            this.lblBuscarEn.TabIndex = 1;
            this.lblBuscarEn.Text = "En ";
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar.Location = new System.Drawing.Point(7, 16);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(50, 15);
            this.lbl_Buscar.TabIndex = 0;
            this.lbl_Buscar.Text = "Buscar ";
            // 
            // chk_CreditoCasa
            // 
            this.chk_CreditoCasa.AutoSize = true;
            this.chk_CreditoCasa.BackColor = System.Drawing.Color.Transparent;
            this.chk_CreditoCasa.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_CreditoCasa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_CreditoCasa.Location = new System.Drawing.Point(330, 3);
            this.chk_CreditoCasa.Name = "chk_CreditoCasa";
            this.chk_CreditoCasa.Size = new System.Drawing.Size(97, 19);
            this.chk_CreditoCasa.TabIndex = 29;
            this.chk_CreditoCasa.Text = "Credito Casa";
            this.chk_CreditoCasa.UseVisualStyleBackColor = false;
            this.chk_CreditoCasa.CheckedChanged += new System.EventHandler(this.chk_CreditoC_CheckedChanged_1);
            // 
            // chk_CreditoNuevo
            // 
            this.chk_CreditoNuevo.AutoSize = true;
            this.chk_CreditoNuevo.BackColor = System.Drawing.Color.Transparent;
            this.chk_CreditoNuevo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_CreditoNuevo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_CreditoNuevo.Location = new System.Drawing.Point(221, 3);
            this.chk_CreditoNuevo.Name = "chk_CreditoNuevo";
            this.chk_CreditoNuevo.Size = new System.Drawing.Size(103, 19);
            this.chk_CreditoNuevo.TabIndex = 28;
            this.chk_CreditoNuevo.Text = "Credito Nuevo";
            this.chk_CreditoNuevo.UseVisualStyleBackColor = false;
            this.chk_CreditoNuevo.CheckedChanged += new System.EventHandler(this.chk_CreditoN_CheckedChanged_1);
            // 
            // chk_ContadoCasa
            // 
            this.chk_ContadoCasa.AutoSize = true;
            this.chk_ContadoCasa.BackColor = System.Drawing.Color.Transparent;
            this.chk_ContadoCasa.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_ContadoCasa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_ContadoCasa.Location = new System.Drawing.Point(115, 3);
            this.chk_ContadoCasa.Name = "chk_ContadoCasa";
            this.chk_ContadoCasa.Size = new System.Drawing.Size(100, 19);
            this.chk_ContadoCasa.TabIndex = 27;
            this.chk_ContadoCasa.Text = "Contado Casa";
            this.chk_ContadoCasa.UseVisualStyleBackColor = false;
            this.chk_ContadoCasa.CheckedChanged += new System.EventHandler(this.chk_ContadoCasa_CheckedChanged);
            // 
            // chk_ContadoNuevo
            // 
            this.chk_ContadoNuevo.AutoSize = true;
            this.chk_ContadoNuevo.BackColor = System.Drawing.Color.Transparent;
            this.chk_ContadoNuevo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_ContadoNuevo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_ContadoNuevo.Location = new System.Drawing.Point(3, 3);
            this.chk_ContadoNuevo.Name = "chk_ContadoNuevo";
            this.chk_ContadoNuevo.Size = new System.Drawing.Size(106, 19);
            this.chk_ContadoNuevo.TabIndex = 26;
            this.chk_ContadoNuevo.Text = "Contado Nuevo";
            this.chk_ContadoNuevo.UseVisualStyleBackColor = false;
            this.chk_ContadoNuevo.CheckedChanged += new System.EventHandler(this.chk_ContadoNuevo_CheckedChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_nuevo,
            this.MenuItem_TiempoTotal,
            this.MenuItem_FormatoExploradorPVC,
            this.MenuItem_MonederoRedimir,
            this.MenuItem_ActualizacionDatos,
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem,
            this.MenuItem_ClienteExpress,
            this.consultarBuroToolStripMenuItem,
            this.MenuItem_Excel,
            this.MenuItem_KardexClienteFinal,
            this.copiarClienteToolStripMenuItem,
            this.MenuItem_Relacionado,
            this.envioCorreoWebCrtlF9ToolStripMenuItem,
            this.capturaDeRelacionadoToolStripMenuItem,
            this.camposExtrasToolStripMenuItem,
            this.matrizDeAutorizacionToolStripMenuItem,
            this.reanalisisToolStripMenuItem,
            this.menuScoring,
            this.menuOrdenCompra,
            this.ttCuentaClabe,
            this.cToolStripMenuItem,
            this.MenuItem_Afectar,
            this.editarVentaCrtlF7ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(282, 510);
            // 
            // MenuItem_nuevo
            // 
            this.MenuItem_nuevo.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_nuevo.Image")));
            this.MenuItem_nuevo.Name = "MenuItem_nuevo";
            this.MenuItem_nuevo.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_nuevo.Text = "Nuevo (Crtl+N)";
            this.MenuItem_nuevo.Click += new System.EventHandler(this.nuevoCrtlNToolStripMenuItem_Click);
            // 
            // MenuItem_TiempoTotal
            // 
            this.MenuItem_TiempoTotal.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_TiempoTotal.Image")));
            this.MenuItem_TiempoTotal.Name = "MenuItem_TiempoTotal";
            this.MenuItem_TiempoTotal.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_TiempoTotal.Text = "Tiempo Total (Crtl+T)";
            this.MenuItem_TiempoTotal.Click += new System.EventHandler(this.tiempoTotalCrtlIToolStripMenuItem_Click);
            // 
            // MenuItem_FormatoExploradorPVC
            // 
            this.MenuItem_FormatoExploradorPVC.Name = "MenuItem_FormatoExploradorPVC";
            this.MenuItem_FormatoExploradorPVC.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_FormatoExploradorPVC.Text = "Formato Explorador PVC (Crtl+C)";
            this.MenuItem_FormatoExploradorPVC.Click += new System.EventHandler(this.MostrarFormatoExploradorPVC_Click);
            // 
            // MenuItem_MonederoRedimir
            // 
            this.MenuItem_MonederoRedimir.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_MonederoRedimir.Image")));
            this.MenuItem_MonederoRedimir.Name = "MenuItem_MonederoRedimir";
            this.MenuItem_MonederoRedimir.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_MonederoRedimir.Text = "Monedero por Redimir (Crtl+D)";
            this.MenuItem_MonederoRedimir.Click += new System.EventHandler(this.monederoPorRedimirCrtlPToolStripMenuItem_Click);
            // 
            // MenuItem_ActualizacionDatos
            // 
            this.MenuItem_ActualizacionDatos.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_ActualizacionDatos.Image")));
            this.MenuItem_ActualizacionDatos.Name = "MenuItem_ActualizacionDatos";
            this.MenuItem_ActualizacionDatos.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_ActualizacionDatos.Text = "Ver Actualizacion de Datos (Crtl+M)";
            this.MenuItem_ActualizacionDatos.Click += new System.EventHandler(this.actualizacionDeDatosCrtlJToolStripMenuItem_Click);
            // 
            // agregarActualizacionDeDatosCrtlJToolStripMenuItem
            // 
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("agregarActualizacionDeDatosCrtlJToolStripMenuItem.Image")));
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem.Name = "agregarActualizacionDeDatosCrtlJToolStripMenuItem";
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem.Text = "Agregar Actualizacion de Datos (Crtl+J)";
            this.agregarActualizacionDeDatosCrtlJToolStripMenuItem.Click += new System.EventHandler(this.agregarActualizacionDeDatosCrtlJToolStripMenuItem_Click);
            // 
            // MenuItem_ClienteExpress
            // 
            this.MenuItem_ClienteExpress.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_ClienteExpress.Image")));
            this.MenuItem_ClienteExpress.Name = "MenuItem_ClienteExpress";
            this.MenuItem_ClienteExpress.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_ClienteExpress.Text = "RM0855A Cliente express (Crtl+A)";
            this.MenuItem_ClienteExpress.Click += new System.EventHandler(this.rm0855AClienteExpressCrtlAToolStripMenuItem_Click);
            // 
            // consultarBuroToolStripMenuItem
            // 
            this.consultarBuroToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultarBuroToolStripMenuItem.Image")));
            this.consultarBuroToolStripMenuItem.Name = "consultarBuroToolStripMenuItem";
            this.consultarBuroToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.consultarBuroToolStripMenuItem.Text = "Consultar Buro (Crtl+F2)";
            this.consultarBuroToolStripMenuItem.Click += new System.EventHandler(this.consultarBuroToolStripMenuItem_Click);
            // 
            // MenuItem_Excel
            // 
            this.MenuItem_Excel.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_Excel.Image")));
            this.MenuItem_Excel.Name = "MenuItem_Excel";
            this.MenuItem_Excel.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_Excel.Text = "Excel (Crtl-F1)";
            this.MenuItem_Excel.Click += new System.EventHandler(this.excelToolStripMenuItem_Click);
            // 
            // MenuItem_KardexClienteFinal
            // 
            this.MenuItem_KardexClienteFinal.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_KardexClienteFinal.Image")));
            this.MenuItem_KardexClienteFinal.Name = "MenuItem_KardexClienteFinal";
            this.MenuItem_KardexClienteFinal.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_KardexClienteFinal.Text = "Kardex Cliente Final (Crtl+K)";
            this.MenuItem_KardexClienteFinal.Click += new System.EventHandler(this.MenuItem_KardexClienteFinal_Click);
            // 
            // copiarClienteToolStripMenuItem
            // 
            this.copiarClienteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copiarClienteToolStripMenuItem.Image")));
            this.copiarClienteToolStripMenuItem.Name = "copiarClienteToolStripMenuItem";
            this.copiarClienteToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.copiarClienteToolStripMenuItem.Text = "Copiar Cliente (Crtl+F4)";
            this.copiarClienteToolStripMenuItem.Click += new System.EventHandler(this.copiarClienteToolStripMenuItem_Click);
            // 
            // MenuItem_Relacionado
            // 
            this.MenuItem_Relacionado.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_Relacionado.Image")));
            this.MenuItem_Relacionado.Name = "MenuItem_Relacionado";
            this.MenuItem_Relacionado.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_Relacionado.Text = "Copiar Cliente Relacionado (Crtl+F5)";
            this.MenuItem_Relacionado.Click += new System.EventHandler(this.copiarClienteRelacionadoToolStripMenuItem_Click);
            // 
            // envioCorreoWebCrtlF9ToolStripMenuItem
            // 
            this.envioCorreoWebCrtlF9ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("envioCorreoWebCrtlF9ToolStripMenuItem.Image")));
            this.envioCorreoWebCrtlF9ToolStripMenuItem.Name = "envioCorreoWebCrtlF9ToolStripMenuItem";
            this.envioCorreoWebCrtlF9ToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.envioCorreoWebCrtlF9ToolStripMenuItem.Text = "Envio correo web (Crtl+F9)";
            this.envioCorreoWebCrtlF9ToolStripMenuItem.Click += new System.EventHandler(this.envioCorreoWebCrtlF9ToolStripMenuItem_Click);
            // 
            // capturaDeRelacionadoToolStripMenuItem
            // 
            this.capturaDeRelacionadoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("capturaDeRelacionadoToolStripMenuItem.Image")));
            this.capturaDeRelacionadoToolStripMenuItem.Name = "capturaDeRelacionadoToolStripMenuItem";
            this.capturaDeRelacionadoToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.capturaDeRelacionadoToolStripMenuItem.Text = "Captura de Relacionado (Crtl+F6)";
            this.capturaDeRelacionadoToolStripMenuItem.Click += new System.EventHandler(this.capturaDeRelacionadoToolStripMenuItem_Click);
            // 
            // camposExtrasToolStripMenuItem
            // 
            this.camposExtrasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("camposExtrasToolStripMenuItem.Image")));
            this.camposExtrasToolStripMenuItem.Name = "camposExtrasToolStripMenuItem";
            this.camposExtrasToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.camposExtrasToolStripMenuItem.Text = "Campos Extras (Crtl+F8)";
            this.camposExtrasToolStripMenuItem.Click += new System.EventHandler(this.camposExtrasToolStripMenuItem_Click);
            // 
            // matrizDeAutorizacionToolStripMenuItem
            // 
            this.matrizDeAutorizacionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("matrizDeAutorizacionToolStripMenuItem.Image")));
            this.matrizDeAutorizacionToolStripMenuItem.Name = "matrizDeAutorizacionToolStripMenuItem";
            this.matrizDeAutorizacionToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.matrizDeAutorizacionToolStripMenuItem.Text = "Matriz de Autorizacion (Crtl+F3)";
            this.matrizDeAutorizacionToolStripMenuItem.Click += new System.EventHandler(this.matrizDeAutorizacionToolStripMenuItem_Click);
            // 
            // reanalisisToolStripMenuItem
            // 
            this.reanalisisToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("reanalisisToolStripMenuItem.Image")));
            this.reanalisisToolStripMenuItem.Name = "reanalisisToolStripMenuItem";
            this.reanalisisToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.reanalisisToolStripMenuItem.Text = "Reanalisis";
            this.reanalisisToolStripMenuItem.Click += new System.EventHandler(this.reanalisisToolStripMenuItem_Click);
            // 
            // menuScoring
            // 
            this.menuScoring.Image = global::PuntoVenta.Properties.Resources.satisfaction;
            this.menuScoring.Name = "menuScoring";
            this.menuScoring.Size = new System.Drawing.Size(281, 22);
            this.menuScoring.Text = "Scoring (Ctrl + Y)";
            this.menuScoring.Visible = false;
            this.menuScoring.Click += new System.EventHandler(this.menuScoring_Click);
            // 
            // menuOrdenCompra
            // 
            this.menuOrdenCompra.Name = "menuOrdenCompra";
            this.menuOrdenCompra.Size = new System.Drawing.Size(281, 22);
            this.menuOrdenCompra.Text = "Orden Compra";
            this.menuOrdenCompra.Visible = false;
            this.menuOrdenCompra.Click += new System.EventHandler(this.menuOrdenCompra_Click);
            // 
            // ttCuentaClabe
            // 
            this.ttCuentaClabe.Image = global::PuntoVenta.Properties.Resources.credit_card;
            this.ttCuentaClabe.Name = "ttCuentaClabe";
            this.ttCuentaClabe.ShowShortcutKeys = false;
            this.ttCuentaClabe.Size = new System.Drawing.Size(281, 22);
            this.ttCuentaClabe.Text = "Validar Cuenta Clabe (Ctrl + G)";
            this.ttCuentaClabe.Visible = false;
            this.ttCuentaClabe.Click += new System.EventHandler(this.ttCuentaClabe_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.cToolStripMenuItem.Text = "__________________________________";
            // 
            // MenuItem_Afectar
            // 
            this.MenuItem_Afectar.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_Afectar.Image")));
            this.MenuItem_Afectar.Name = "MenuItem_Afectar";
            this.MenuItem_Afectar.Size = new System.Drawing.Size(281, 22);
            this.MenuItem_Afectar.Text = "&Afectar(Crtl+F)";
            this.MenuItem_Afectar.Click += new System.EventHandler(this.MenuItem_Afectar_Click);
            // 
            // editarVentaCrtlF7ToolStripMenuItem
            // 
            this.editarVentaCrtlF7ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editarVentaCrtlF7ToolStripMenuItem.Image")));
            this.editarVentaCrtlF7ToolStripMenuItem.Name = "editarVentaCrtlF7ToolStripMenuItem";
            this.editarVentaCrtlF7ToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.editarVentaCrtlF7ToolStripMenuItem.Text = "Editar Venta (Crtl-F7)";
            this.editarVentaCrtlF7ToolStripMenuItem.Click += new System.EventHandler(this.editarVentaCrtlF7ToolStripMenuItem_Click);
            // 
            // toolTipRecalificar
            // 
            this.toolTipRecalificar.Name = "ctm_MenuEventos";
            this.toolTipRecalificar.Size = new System.Drawing.Size(61, 4);
            // 
            // gbx_Detalle
            // 
            this.gbx_Detalle.BackColor = System.Drawing.Color.White;
            this.gbx_Detalle.Controls.Add(this.flp_detalle);
            this.gbx_Detalle.Cursor = System.Windows.Forms.Cursors.Default;
            this.gbx_Detalle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_Detalle.Location = new System.Drawing.Point(6, 10);
            this.gbx_Detalle.Name = "gbx_Detalle";
            this.gbx_Detalle.Size = new System.Drawing.Size(537, 234);
            this.gbx_Detalle.TabIndex = 14;
            this.gbx_Detalle.TabStop = false;
            this.gbx_Detalle.Text = "Detalle";
            this.toolTip1.SetToolTip(this.gbx_Detalle, "DAR DOBLE CLICK PARA VER EL DETALLE COMPLETO DEL LA VENTA ");
            this.gbx_Detalle.MouseHover += new System.EventHandler(this.gbx_Detalle_MouseHover);
            // 
            // flp_detalle
            // 
            this.flp_detalle.Controls.Add(this.lbl_Almacen);
            this.flp_detalle.Controls.Add(this.txt_DetalleAlmacen);
            this.flp_detalle.Controls.Add(this.lbl_Condicion);
            this.flp_detalle.Controls.Add(this.txt_Condicion);
            this.flp_detalle.Controls.Add(this.lbl_Referencia);
            this.flp_detalle.Controls.Add(this.txt_DetalleReferencia);
            this.flp_detalle.Controls.Add(this.lbl_Concepto);
            this.flp_detalle.Controls.Add(this.txt_DetalleConcepto);
            this.flp_detalle.Controls.Add(this.flowLayoutPanel3);
            this.flp_detalle.Controls.Add(this.lbl_Descripcion);
            this.flp_detalle.Controls.Add(this.tb_descripcion);
            this.flp_detalle.Controls.Add(this.dgv_TablaDetalle);
            this.flp_detalle.Cursor = System.Windows.Forms.Cursors.Default;
            this.flp_detalle.Location = new System.Drawing.Point(6, 25);
            this.flp_detalle.Name = "flp_detalle";
            this.flp_detalle.Size = new System.Drawing.Size(473, 203);
            this.flp_detalle.TabIndex = 52;
            this.toolTip1.SetToolTip(this.flp_detalle, "DAR DOBLE CLICK PARA VER EL DETALLE COMPLETO DEL LA VENTA");
            this.flp_detalle.MouseMove += new System.Windows.Forms.MouseEventHandler(this.flp_detalle_MouseMove);
            // 
            // lbl_Almacen
            // 
            this.lbl_Almacen.AutoSize = true;
            this.lbl_Almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Almacen.Location = new System.Drawing.Point(3, 5);
            this.lbl_Almacen.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbl_Almacen.Name = "lbl_Almacen";
            this.lbl_Almacen.Size = new System.Drawing.Size(55, 15);
            this.lbl_Almacen.TabIndex = 1;
            this.lbl_Almacen.Text = "Almacen";
            // 
            // txt_DetalleAlmacen
            // 
            this.txt_DetalleAlmacen.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_DetalleAlmacen.Enabled = false;
            this.txt_DetalleAlmacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleAlmacen.Location = new System.Drawing.Point(74, 3);
            this.txt_DetalleAlmacen.Margin = new System.Windows.Forms.Padding(13, 3, 3, 3);
            this.txt_DetalleAlmacen.Name = "txt_DetalleAlmacen";
            this.txt_DetalleAlmacen.Size = new System.Drawing.Size(113, 22);
            this.txt_DetalleAlmacen.TabIndex = 32;
            // 
            // lbl_Condicion
            // 
            this.lbl_Condicion.AutoSize = true;
            this.lbl_Condicion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Condicion.Location = new System.Drawing.Point(193, 5);
            this.lbl_Condicion.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbl_Condicion.Name = "lbl_Condicion";
            this.lbl_Condicion.Size = new System.Drawing.Size(62, 15);
            this.lbl_Condicion.TabIndex = 38;
            this.lbl_Condicion.Text = "Condicion";
            // 
            // txt_Condicion
            // 
            this.txt_Condicion.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_Condicion.Enabled = false;
            this.txt_Condicion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Condicion.Location = new System.Drawing.Point(261, 3);
            this.txt_Condicion.Name = "txt_Condicion";
            this.txt_Condicion.Size = new System.Drawing.Size(197, 22);
            this.txt_Condicion.TabIndex = 39;
            // 
            // lbl_Referencia
            // 
            this.lbl_Referencia.AutoSize = true;
            this.lbl_Referencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Referencia.Location = new System.Drawing.Point(3, 28);
            this.lbl_Referencia.Name = "lbl_Referencia";
            this.lbl_Referencia.Size = new System.Drawing.Size(67, 15);
            this.lbl_Referencia.TabIndex = 11;
            this.lbl_Referencia.Text = "Referencia";
            // 
            // txt_DetalleReferencia
            // 
            this.txt_DetalleReferencia.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_DetalleReferencia.Enabled = false;
            this.txt_DetalleReferencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleReferencia.Location = new System.Drawing.Point(76, 31);
            this.txt_DetalleReferencia.Name = "txt_DetalleReferencia";
            this.txt_DetalleReferencia.Size = new System.Drawing.Size(166, 22);
            this.txt_DetalleReferencia.TabIndex = 33;
            // 
            // lbl_Concepto
            // 
            this.lbl_Concepto.AutoSize = true;
            this.lbl_Concepto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Concepto.Location = new System.Drawing.Point(248, 28);
            this.lbl_Concepto.Name = "lbl_Concepto";
            this.lbl_Concepto.Size = new System.Drawing.Size(57, 15);
            this.lbl_Concepto.TabIndex = 12;
            this.lbl_Concepto.Text = "Concepto";
            // 
            // txt_DetalleConcepto
            // 
            this.txt_DetalleConcepto.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_DetalleConcepto.Enabled = false;
            this.txt_DetalleConcepto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleConcepto.Location = new System.Drawing.Point(311, 31);
            this.txt_DetalleConcepto.Name = "txt_DetalleConcepto";
            this.txt_DetalleConcepto.Size = new System.Drawing.Size(147, 22);
            this.txt_DetalleConcepto.TabIndex = 34;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.lbl_Embarque);
            this.flowLayoutPanel3.Controls.Add(this.txt_DetalleEmbarqueMov);
            this.flowLayoutPanel3.Controls.Add(this.txt_DetalleEmbarqueFecha);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 59);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(455, 31);
            this.flowLayoutPanel3.TabIndex = 41;
            this.toolTip1.SetToolTip(this.flowLayoutPanel3, "Detalle de la venta");
            // 
            // lbl_Embarque
            // 
            this.lbl_Embarque.AutoSize = true;
            this.lbl_Embarque.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Embarque.Location = new System.Drawing.Point(3, 0);
            this.lbl_Embarque.Name = "lbl_Embarque";
            this.lbl_Embarque.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.lbl_Embarque.Size = new System.Drawing.Size(61, 19);
            this.lbl_Embarque.TabIndex = 8;
            this.lbl_Embarque.Text = "Embarque";
            // 
            // txt_DetalleEmbarqueMov
            // 
            this.txt_DetalleEmbarqueMov.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_DetalleEmbarqueMov.Enabled = false;
            this.txt_DetalleEmbarqueMov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleEmbarqueMov.Location = new System.Drawing.Point(71, 3);
            this.txt_DetalleEmbarqueMov.Margin = new System.Windows.Forms.Padding(4, 3, 3, 3);
            this.txt_DetalleEmbarqueMov.Name = "txt_DetalleEmbarqueMov";
            this.txt_DetalleEmbarqueMov.Size = new System.Drawing.Size(197, 22);
            this.txt_DetalleEmbarqueMov.TabIndex = 35;
            // 
            // txt_DetalleEmbarqueFecha
            // 
            this.txt_DetalleEmbarqueFecha.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_DetalleEmbarqueFecha.Enabled = false;
            this.txt_DetalleEmbarqueFecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleEmbarqueFecha.Location = new System.Drawing.Point(274, 3);
            this.txt_DetalleEmbarqueFecha.Name = "txt_DetalleEmbarqueFecha";
            this.txt_DetalleEmbarqueFecha.Size = new System.Drawing.Size(148, 22);
            this.txt_DetalleEmbarqueFecha.TabIndex = 40;
            // 
            // lbl_Descripcion
            // 
            this.lbl_Descripcion.AutoSize = true;
            this.lbl_Descripcion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Descripcion.Location = new System.Drawing.Point(3, 98);
            this.lbl_Descripcion.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbl_Descripcion.Name = "lbl_Descripcion";
            this.lbl_Descripcion.Size = new System.Drawing.Size(77, 15);
            this.lbl_Descripcion.TabIndex = 42;
            this.lbl_Descripcion.Text = "Descripcion:";
            // 
            // tb_descripcion
            // 
            this.tb_descripcion.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tb_descripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_descripcion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_descripcion.Location = new System.Drawing.Point(96, 98);
            this.tb_descripcion.Margin = new System.Windows.Forms.Padding(13, 5, 3, 3);
            this.tb_descripcion.Multiline = true;
            this.tb_descripcion.Name = "tb_descripcion";
            this.tb_descripcion.ReadOnly = true;
            this.tb_descripcion.Size = new System.Drawing.Size(366, 20);
            this.tb_descripcion.TabIndex = 43;
            // 
            // dgv_TablaDetalle
            // 
            this.dgv_TablaDetalle.AllowUserToAddRows = false;
            this.dgv_TablaDetalle.AllowUserToDeleteRows = false;
            this.dgv_TablaDetalle.AllowUserToResizeColumns = false;
            this.dgv_TablaDetalle.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_TablaDetalle.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_TablaDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_TablaDetalle.BackgroundColor = System.Drawing.Color.White;
            this.dgv_TablaDetalle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TablaDetalle.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_TablaDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_TablaDetalle.EnableHeadersVisualStyles = false;
            this.dgv_TablaDetalle.Location = new System.Drawing.Point(3, 124);
            this.dgv_TablaDetalle.Name = "dgv_TablaDetalle";
            this.dgv_TablaDetalle.ReadOnly = true;
            this.dgv_TablaDetalle.RowHeadersVisible = false;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_TablaDetalle.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_TablaDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_TablaDetalle.Size = new System.Drawing.Size(455, 71);
            this.dgv_TablaDetalle.TabIndex = 37;
            this.toolTip1.SetToolTip(this.dgv_TablaDetalle, "DAR DOBLE CLICK PARA VER EL DETALLE DE LA VENTA");
            this.dgv_TablaDetalle.SelectionChanged += new System.EventHandler(this.dgv_TablaDetalle_SelectionChanged);
            // 
            // gbx_TableroPr
            // 
            this.gbx_TableroPr.BackColor = System.Drawing.Color.White;
            this.gbx_TableroPr.Controls.Add(this.button1);
            this.gbx_TableroPr.Controls.Add(this.panel_MovsPr);
            this.gbx_TableroPr.Location = new System.Drawing.Point(3, 192);
            this.gbx_TableroPr.Name = "gbx_TableroPr";
            this.gbx_TableroPr.Size = new System.Drawing.Size(1134, 310);
            this.gbx_TableroPr.TabIndex = 54;
            this.gbx_TableroPr.TabStop = false;
            this.toolTip1.SetToolTip(this.gbx_TableroPr, "DAR DOBLE CLICK EN ALGUN REGISTRO PARA VER EL DETALLE DE LA VENTA");
            this.gbx_TableroPr.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_TableroPr_Paint);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(523, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 11);
            this.button1.TabIndex = 53;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel_MovsPr
            // 
            this.panel_MovsPr.AutoSize = true;
            this.panel_MovsPr.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_MovsPr.Controls.Add(this.dgv_TablaMovimientos);
            this.panel_MovsPr.Controls.Add(this.flowLayoutPanel2);
            this.panel_MovsPr.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panel_MovsPr.Location = new System.Drawing.Point(2, 17);
            this.panel_MovsPr.Name = "panel_MovsPr";
            this.panel_MovsPr.Size = new System.Drawing.Size(1146, 287);
            this.panel_MovsPr.TabIndex = 52;
            // 
            // dgv_TablaMovimientos
            // 
            this.dgv_TablaMovimientos.AllowUserToAddRows = false;
            this.dgv_TablaMovimientos.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_TablaMovimientos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_TablaMovimientos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_TablaMovimientos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_TablaMovimientos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_TablaMovimientos.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv_TablaMovimientos.EnableHeadersVisualStyles = false;
            this.dgv_TablaMovimientos.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgv_TablaMovimientos.Location = new System.Drawing.Point(3, 3);
            this.dgv_TablaMovimientos.Name = "dgv_TablaMovimientos";
            this.dgv_TablaMovimientos.ReadOnly = true;
            this.dgv_TablaMovimientos.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_TablaMovimientos.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_TablaMovimientos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_TablaMovimientos.Size = new System.Drawing.Size(1129, 257);
            this.dgv_TablaMovimientos.TabIndex = 25;
            this.toolTip1.SetToolTip(this.dgv_TablaMovimientos, "DAR DOBLE CLICK EN ALGUN REGISTRO PARA VER EL DETALLE DE LA VENTA");
            this.dgv_TablaMovimientos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_TablaMovimientos_CellClick_1);
            this.dgv_TablaMovimientos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_TablaMovimientos_CellDoubleClick);
            this.dgv_TablaMovimientos.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_TablaMovimientos_ColumnHeaderMouseClick);
            this.dgv_TablaMovimientos.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgv_TablaMovimientos_DataBindingComplete);
            this.dgv_TablaMovimientos.SelectionChanged += new System.EventHandler(this.dgv_TablaMovimientos_SelectionChanged_1);
            this.dgv_TablaMovimientos.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgv_TablaMovimientos_KeyUp);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.lbl_CreditoCasaNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_CreditoCasaNum);
            this.flowLayoutPanel2.Controls.Add(this.lbl_CreditoNuevoNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_CreditoNuevoNum);
            this.flowLayoutPanel2.Controls.Add(this.lbl_ContadoNuevoNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_ContadoNuevoNum);
            this.flowLayoutPanel2.Controls.Add(this.lbl_ContadoCasaNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_ContadoCasaNum);
            this.flowLayoutPanel2.Controls.Add(this.lbl_CreditoCasaMayNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_CreditoCasaMayNum);
            this.flowLayoutPanel2.Controls.Add(this.lbl_CreditoNuevoMayNum);
            this.flowLayoutPanel2.Controls.Add(this.txt_CreditoNuevoMayNum);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 266);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(1140, 18);
            this.flowLayoutPanel2.TabIndex = 26;
            // 
            // lbl_CreditoCasaNum
            // 
            this.lbl_CreditoCasaNum.AutoSize = true;
            this.lbl_CreditoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoCasaNum.Location = new System.Drawing.Point(3, 3);
            this.lbl_CreditoCasaNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoCasaNum.Name = "lbl_CreditoCasaNum";
            this.lbl_CreditoCasaNum.Size = new System.Drawing.Size(82, 15);
            this.lbl_CreditoCasaNum.TabIndex = 0;
            this.lbl_CreditoCasaNum.Text = "Credito Casa:";
            // 
            // txt_CreditoCasaNum
            // 
            this.txt_CreditoCasaNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoCasaNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoCasaNum.Enabled = false;
            this.txt_CreditoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoCasaNum.Location = new System.Drawing.Point(91, 3);
            this.txt_CreditoCasaNum.Multiline = true;
            this.txt_CreditoCasaNum.Name = "txt_CreditoCasaNum";
            this.txt_CreditoCasaNum.Size = new System.Drawing.Size(97, 12);
            this.txt_CreditoCasaNum.TabIndex = 52;
            // 
            // lbl_CreditoNuevoNum
            // 
            this.lbl_CreditoNuevoNum.AutoSize = true;
            this.lbl_CreditoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoNuevoNum.Location = new System.Drawing.Point(194, 3);
            this.lbl_CreditoNuevoNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoNuevoNum.Name = "lbl_CreditoNuevoNum";
            this.lbl_CreditoNuevoNum.Size = new System.Drawing.Size(88, 15);
            this.lbl_CreditoNuevoNum.TabIndex = 53;
            this.lbl_CreditoNuevoNum.Text = "Credito Nuevo:";
            // 
            // txt_CreditoNuevoNum
            // 
            this.txt_CreditoNuevoNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoNuevoNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoNuevoNum.Enabled = false;
            this.txt_CreditoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoNuevoNum.Location = new System.Drawing.Point(288, 3);
            this.txt_CreditoNuevoNum.Multiline = true;
            this.txt_CreditoNuevoNum.Name = "txt_CreditoNuevoNum";
            this.txt_CreditoNuevoNum.Size = new System.Drawing.Size(107, 12);
            this.txt_CreditoNuevoNum.TabIndex = 54;
            // 
            // lbl_ContadoNuevoNum
            // 
            this.lbl_ContadoNuevoNum.AutoSize = true;
            this.lbl_ContadoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContadoNuevoNum.Location = new System.Drawing.Point(401, 3);
            this.lbl_ContadoNuevoNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_ContadoNuevoNum.Name = "lbl_ContadoNuevoNum";
            this.lbl_ContadoNuevoNum.Size = new System.Drawing.Size(91, 15);
            this.lbl_ContadoNuevoNum.TabIndex = 55;
            this.lbl_ContadoNuevoNum.Text = "Contado Nuevo:";
            // 
            // txt_ContadoNuevoNum
            // 
            this.txt_ContadoNuevoNum.BackColor = System.Drawing.Color.White;
            this.txt_ContadoNuevoNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ContadoNuevoNum.Enabled = false;
            this.txt_ContadoNuevoNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContadoNuevoNum.Location = new System.Drawing.Point(498, 3);
            this.txt_ContadoNuevoNum.Multiline = true;
            this.txt_ContadoNuevoNum.Name = "txt_ContadoNuevoNum";
            this.txt_ContadoNuevoNum.Size = new System.Drawing.Size(105, 12);
            this.txt_ContadoNuevoNum.TabIndex = 56;
            // 
            // lbl_ContadoCasaNum
            // 
            this.lbl_ContadoCasaNum.AutoSize = true;
            this.lbl_ContadoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContadoCasaNum.Location = new System.Drawing.Point(609, 3);
            this.lbl_ContadoCasaNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_ContadoCasaNum.Name = "lbl_ContadoCasaNum";
            this.lbl_ContadoCasaNum.Size = new System.Drawing.Size(85, 15);
            this.lbl_ContadoCasaNum.TabIndex = 57;
            this.lbl_ContadoCasaNum.Text = "Contado Casa:";
            // 
            // txt_ContadoCasaNum
            // 
            this.txt_ContadoCasaNum.BackColor = System.Drawing.Color.White;
            this.txt_ContadoCasaNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ContadoCasaNum.Enabled = false;
            this.txt_ContadoCasaNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContadoCasaNum.Location = new System.Drawing.Point(700, 3);
            this.txt_ContadoCasaNum.Multiline = true;
            this.txt_ContadoCasaNum.Name = "txt_ContadoCasaNum";
            this.txt_ContadoCasaNum.Size = new System.Drawing.Size(95, 12);
            this.txt_ContadoCasaNum.TabIndex = 58;
            // 
            // lbl_CreditoCasaMayNum
            // 
            this.lbl_CreditoCasaMayNum.AutoSize = true;
            this.lbl_CreditoCasaMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoCasaMayNum.Location = new System.Drawing.Point(801, 3);
            this.lbl_CreditoCasaMayNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoCasaMayNum.Name = "lbl_CreditoCasaMayNum";
            this.lbl_CreditoCasaMayNum.Size = new System.Drawing.Size(108, 15);
            this.lbl_CreditoCasaMayNum.TabIndex = 65;
            this.lbl_CreditoCasaMayNum.Text = "Credito Casa May:";
            // 
            // txt_CreditoCasaMayNum
            // 
            this.txt_CreditoCasaMayNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoCasaMayNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoCasaMayNum.Enabled = false;
            this.txt_CreditoCasaMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoCasaMayNum.Location = new System.Drawing.Point(915, 3);
            this.txt_CreditoCasaMayNum.Multiline = true;
            this.txt_CreditoCasaMayNum.Name = "txt_CreditoCasaMayNum";
            this.txt_CreditoCasaMayNum.Size = new System.Drawing.Size(114, 12);
            this.txt_CreditoCasaMayNum.TabIndex = 66;
            // 
            // lbl_CreditoNuevoMayNum
            // 
            this.lbl_CreditoNuevoMayNum.AutoSize = true;
            this.lbl_CreditoNuevoMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreditoNuevoMayNum.Location = new System.Drawing.Point(3, 21);
            this.lbl_CreditoNuevoMayNum.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_CreditoNuevoMayNum.Name = "lbl_CreditoNuevoMayNum";
            this.lbl_CreditoNuevoMayNum.Size = new System.Drawing.Size(114, 15);
            this.lbl_CreditoNuevoMayNum.TabIndex = 67;
            this.lbl_CreditoNuevoMayNum.Text = "Credito Nuevo May:";
            // 
            // txt_CreditoNuevoMayNum
            // 
            this.txt_CreditoNuevoMayNum.BackColor = System.Drawing.Color.White;
            this.txt_CreditoNuevoMayNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CreditoNuevoMayNum.Enabled = false;
            this.txt_CreditoNuevoMayNum.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CreditoNuevoMayNum.Location = new System.Drawing.Point(123, 21);
            this.txt_CreditoNuevoMayNum.Multiline = true;
            this.txt_CreditoNuevoMayNum.Name = "txt_CreditoNuevoMayNum";
            this.txt_CreditoNuevoMayNum.Size = new System.Drawing.Size(107, 12);
            this.txt_CreditoNuevoMayNum.TabIndex = 68;
            // 
            // btn_storepickupOrders
            // 
            this.btn_storepickupOrders.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btn_storepickupOrders.BackColor = System.Drawing.Color.AliceBlue;
            this.btn_storepickupOrders.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_storepickupOrders.FlatAppearance.BorderSize = 0;
            this.btn_storepickupOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_storepickupOrders.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_storepickupOrders.Image = global::PuntoVenta.Properties.Resources.alert1;
            this.btn_storepickupOrders.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_storepickupOrders.Location = new System.Drawing.Point(995, 130);
            this.btn_storepickupOrders.Name = "btn_storepickupOrders";
            this.btn_storepickupOrders.Size = new System.Drawing.Size(132, 41);
            this.btn_storepickupOrders.TabIndex = 57;
            this.btn_storepickupOrders.Tag = "PEDIDOS A ENTREGAR EN SUCURSAL";
            this.btn_storepickupOrders.Text = "000";
            this.btn_storepickupOrders.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btn_storepickupOrders, "PEDIDOS A ENTREGAR EN SUCURSAL");
            this.btn_storepickupOrders.UseVisualStyleBackColor = false;
            this.btn_storepickupOrders.Visible = false;
            this.btn_storepickupOrders.Click += new System.EventHandler(this.btn_storepickupOrders_Click);
            // 
            // gbx_Contactos
            // 
            this.gbx_Contactos.AutoSize = true;
            this.gbx_Contactos.BackColor = System.Drawing.Color.White;
            this.gbx_Contactos.Controls.Add(this.dgv_Contactos);
            this.gbx_Contactos.Location = new System.Drawing.Point(3, 993);
            this.gbx_Contactos.Name = "gbx_Contactos";
            this.gbx_Contactos.Size = new System.Drawing.Size(1134, 99);
            this.gbx_Contactos.TabIndex = 17;
            this.gbx_Contactos.TabStop = false;
            this.gbx_Contactos.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_Contactos_Paint);
            // 
            // dgv_Contactos
            // 
            this.dgv_Contactos.AllowUserToAddRows = false;
            this.dgv_Contactos.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Contactos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_Contactos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Contactos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgv_Contactos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Contactos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Contactos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_Contactos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Contactos.ContextMenuStrip = this.contextMenuStrip2;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Contactos.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_Contactos.EnableHeadersVisualStyles = false;
            this.dgv_Contactos.Location = new System.Drawing.Point(6, 13);
            this.dgv_Contactos.Name = "dgv_Contactos";
            this.dgv_Contactos.ReadOnly = true;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Contactos.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_Contactos.RowHeadersVisible = false;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_Contactos.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgv_Contactos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Contactos.Size = new System.Drawing.Size(1122, 67);
            this.dgv_Contactos.TabIndex = 0;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_InvestigacionTel});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(204, 26);
            // 
            // MenuItem_InvestigacionTel
            // 
            this.MenuItem_InvestigacionTel.Image = ((System.Drawing.Image)(resources.GetObject("MenuItem_InvestigacionTel.Image")));
            this.MenuItem_InvestigacionTel.Name = "MenuItem_InvestigacionTel";
            this.MenuItem_InvestigacionTel.Size = new System.Drawing.Size(203, 22);
            this.MenuItem_InvestigacionTel.Text = "Investigación Telefonica ";
            this.MenuItem_InvestigacionTel.Click += new System.EventHandler(this.investigaciónTelefonicaCRTTToolStripMenuItem_Click);
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.BackColor = System.Drawing.Color.AliceBlue;
            this.lbl_Usuario.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Usuario.Location = new System.Drawing.Point(1008, 14);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(126, 22);
            this.lbl_Usuario.TabIndex = 0;
            this.lbl_Usuario.Text = "Usuario";
            // 
            // lbl_Comentario
            // 
            this.lbl_Comentario.AutoSize = true;
            this.lbl_Comentario.Location = new System.Drawing.Point(601, 26);
            this.lbl_Comentario.Name = "lbl_Comentario";
            this.lbl_Comentario.Size = new System.Drawing.Size(0, 13);
            this.lbl_Comentario.TabIndex = 36;
            // 
            // contextMenuStrip4
            // 
            this.contextMenuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.contextMenuStrip4.Name = "contextMenuStrip4";
            this.contextMenuStrip4.Size = new System.Drawing.Size(223, 136);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem1.Text = "Visor Socioeconomico Aval";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem2.Text = "Visor Sociecomico Cliente";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem3.Text = "Visor Buro Aval";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem4.Text = "Visor Buro Cliente";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem5.Text = "Visor Indentificación Aval";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItem6.Text = "Visor Indentificación Cliente";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // lbl_CuentaCaja
            // 
            this.lbl_CuentaCaja.BackColor = System.Drawing.Color.AliceBlue;
            this.lbl_CuentaCaja.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CuentaCaja.Location = new System.Drawing.Point(1008, 36);
            this.lbl_CuentaCaja.Name = "lbl_CuentaCaja";
            this.lbl_CuentaCaja.Size = new System.Drawing.Size(120, 22);
            this.lbl_CuentaCaja.TabIndex = 37;
            this.lbl_CuentaCaja.Text = "Cuenta Caja";
            // 
            // gbx_FotoCliente
            // 
            this.gbx_FotoCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbx_FotoCliente.Controls.Add(this.btnValida);
            this.gbx_FotoCliente.Controls.Add(this.chk_Valido);
            this.gbx_FotoCliente.Controls.Add(this.txtMotivo);
            this.gbx_FotoCliente.Controls.Add(this.txtFecha);
            this.gbx_FotoCliente.Controls.Add(this.txtIdentificacion);
            this.gbx_FotoCliente.Controls.Add(this.label19);
            this.gbx_FotoCliente.Controls.Add(this.label18);
            this.gbx_FotoCliente.Controls.Add(this.label17);
            this.gbx_FotoCliente.Controls.Add(this.label1);
            this.gbx_FotoCliente.Controls.Add(this.imgBoxCta);
            this.gbx_FotoCliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_FotoCliente.Location = new System.Drawing.Point(592, 10);
            this.gbx_FotoCliente.Name = "gbx_FotoCliente";
            this.gbx_FotoCliente.Size = new System.Drawing.Size(484, 195);
            this.gbx_FotoCliente.TabIndex = 39;
            this.gbx_FotoCliente.TabStop = false;
            this.gbx_FotoCliente.Text = "Validacion de Huella";
            this.gbx_FotoCliente.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_FotoCliente_Paint);
            this.gbx_FotoCliente.MouseHover += new System.EventHandler(this.gbx_FotoCliente_MouseHover);
            // 
            // btnValida
            // 
            this.btnValida.BackColor = System.Drawing.Color.Transparent;
            this.btnValida.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnValida.BackgroundImage")));
            this.btnValida.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnValida.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnValida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValida.Location = new System.Drawing.Point(424, 76);
            this.btnValida.Name = "btnValida";
            this.btnValida.Size = new System.Drawing.Size(37, 38);
            this.btnValida.TabIndex = 10;
            this.btnValida.UseVisualStyleBackColor = false;
            this.btnValida.Click += new System.EventHandler(this.btnValida_Click);
            // 
            // chk_Valido
            // 
            this.chk_Valido.AutoSize = true;
            this.chk_Valido.Location = new System.Drawing.Point(127, 67);
            this.chk_Valido.Name = "chk_Valido";
            this.chk_Valido.Size = new System.Drawing.Size(15, 14);
            this.chk_Valido.TabIndex = 9;
            this.chk_Valido.UseVisualStyleBackColor = true;
            // 
            // txtMotivo
            // 
            this.txtMotivo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMotivo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMotivo.Location = new System.Drawing.Point(183, 112);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(235, 22);
            this.txtMotivo.TabIndex = 8;
            // 
            // txtFecha
            // 
            this.txtFecha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFecha.Location = new System.Drawing.Point(294, 64);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(124, 22);
            this.txtFecha.TabIndex = 7;
            // 
            // txtIdentificacion
            // 
            this.txtIdentificacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtIdentificacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdentificacion.Location = new System.Drawing.Point(183, 64);
            this.txtIdentificacion.Name = "txtIdentificacion";
            this.txtIdentificacion.Size = new System.Drawing.Size(105, 22);
            this.txtIdentificacion.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(124, 114);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 15);
            this.label19.TabIndex = 5;
            this.label19.Text = "Motivo";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(291, 39);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "Fecha";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(180, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 15);
            this.label17.TabIndex = 3;
            this.label17.Text = "Identificacion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(115, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Es Valido";
            // 
            // imgBoxCta
            // 
            this.imgBoxCta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.imgBoxCta.ContextMenuStrip = this.contextMenuStrip3;
            this.imgBoxCta.Image = ((System.Drawing.Image)(resources.GetObject("imgBoxCta.Image")));
            this.imgBoxCta.Location = new System.Drawing.Point(19, 48);
            this.imgBoxCta.Name = "imgBoxCta";
            this.imgBoxCta.Size = new System.Drawing.Size(87, 65);
            this.imgBoxCta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgBoxCta.TabIndex = 0;
            this.imgBoxCta.TabStop = false;
            this.imgBoxCta.Click += new System.EventHandler(this.imgBoxCta_Click);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.historialDeFotosToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(167, 26);
            // 
            // historialDeFotosToolStripMenuItem
            // 
            this.historialDeFotosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("historialDeFotosToolStripMenuItem.Image")));
            this.historialDeFotosToolStripMenuItem.Name = "historialDeFotosToolStripMenuItem";
            this.historialDeFotosToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.historialDeFotosToolStripMenuItem.Text = "Historial de Fotos";
            this.historialDeFotosToolStripMenuItem.Click += new System.EventHandler(this.historialDeFotosToolStripMenuItem_Click);
            // 
            // chk_VIU
            // 
            this.chk_VIU.AutoSize = true;
            this.chk_VIU.BackColor = System.Drawing.Color.Transparent;
            this.chk_VIU.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_VIU.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_VIU.Location = new System.Drawing.Point(548, 3);
            this.chk_VIU.Name = "chk_VIU";
            this.chk_VIU.Size = new System.Drawing.Size(47, 19);
            this.chk_VIU.TabIndex = 41;
            this.chk_VIU.Text = "VIU";
            this.chk_VIU.UseVisualStyleBackColor = false;
            this.chk_VIU.CheckedChanged += new System.EventHandler(this.chk_VIU_CheckedChanged);
            // 
            // chk_MA
            // 
            this.chk_MA.AutoSize = true;
            this.chk_MA.BackColor = System.Drawing.Color.Transparent;
            this.chk_MA.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_MA.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_MA.Location = new System.Drawing.Point(433, 3);
            this.chk_MA.Name = "chk_MA";
            this.chk_MA.Size = new System.Drawing.Size(46, 19);
            this.chk_MA.TabIndex = 42;
            this.chk_MA.Text = "MA";
            this.chk_MA.UseVisualStyleBackColor = false;
            this.chk_MA.CheckedChanged += new System.EventHandler(this.chk_MA_CheckedChanged);
            // 
            // chk_MAVI
            // 
            this.chk_MAVI.AutoSize = true;
            this.chk_MAVI.BackColor = System.Drawing.Color.Transparent;
            this.chk_MAVI.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_MAVI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_MAVI.Location = new System.Drawing.Point(485, 3);
            this.chk_MAVI.Name = "chk_MAVI";
            this.chk_MAVI.Size = new System.Drawing.Size(57, 19);
            this.chk_MAVI.TabIndex = 43;
            this.chk_MAVI.Text = "MAVI";
            this.chk_MAVI.UseVisualStyleBackColor = false;
            this.chk_MAVI.CheckedChanged += new System.EventHandler(this.chk_MAVI_CheckedChanged);
            // 
            // cbx_creditoNuevoMayoreo
            // 
            this.cbx_creditoNuevoMayoreo.AutoSize = true;
            this.cbx_creditoNuevoMayoreo.BackColor = System.Drawing.Color.Transparent;
            this.cbx_creditoNuevoMayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_creditoNuevoMayoreo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbx_creditoNuevoMayoreo.Location = new System.Drawing.Point(730, 3);
            this.cbx_creditoNuevoMayoreo.Name = "cbx_creditoNuevoMayoreo";
            this.cbx_creditoNuevoMayoreo.Size = new System.Drawing.Size(129, 19);
            this.cbx_creditoNuevoMayoreo.TabIndex = 44;
            this.cbx_creditoNuevoMayoreo.Text = "Credito Nuevo May";
            this.cbx_creditoNuevoMayoreo.UseVisualStyleBackColor = false;
            this.cbx_creditoNuevoMayoreo.CheckedChanged += new System.EventHandler(this.chk_creditoNuevoMayoreo_CheckedChanged);
            this.cbx_creditoNuevoMayoreo.Click += new System.EventHandler(this.cbx_creditoNuevoMayoreo_Click);
            // 
            // cbx_CreditoCasaMayoreo
            // 
            this.cbx_CreditoCasaMayoreo.AutoSize = true;
            this.cbx_CreditoCasaMayoreo.BackColor = System.Drawing.Color.Transparent;
            this.cbx_CreditoCasaMayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_CreditoCasaMayoreo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbx_CreditoCasaMayoreo.Location = new System.Drawing.Point(601, 3);
            this.cbx_CreditoCasaMayoreo.Name = "cbx_CreditoCasaMayoreo";
            this.cbx_CreditoCasaMayoreo.Size = new System.Drawing.Size(123, 19);
            this.cbx_CreditoCasaMayoreo.TabIndex = 45;
            this.cbx_CreditoCasaMayoreo.Text = "Credito Casa May";
            this.cbx_CreditoCasaMayoreo.UseVisualStyleBackColor = false;
            this.cbx_CreditoCasaMayoreo.CheckedChanged += new System.EventHandler(this.chk_CreditoCasaMayoreo_CheckedChanged);
            this.cbx_CreditoCasaMayoreo.Click += new System.EventHandler(this.cbx_CreditoCasaMayoreo_Click);
            // 
            // Panel_Menu
            // 
            this.Panel_Menu.AutoScroll = true;
            this.Panel_Menu.BackColor = System.Drawing.SystemColors.Window;
            this.Panel_Menu.Controls.Add(this.btn_ayuda);
            this.Panel_Menu.Controls.Add(this.btn_Nuevo);
            this.Panel_Menu.Controls.Add(this.btn_Cancelar);
            this.Panel_Menu.Controls.Add(this.btn_stop);
            this.Panel_Menu.Controls.Add(this.btn_Refrescar);
            this.Panel_Menu.Controls.Add(this.btn_SolicitudCancelacion);
            this.Panel_Menu.Controls.Add(this.btnDineralia);
            this.Panel_Menu.Controls.Add(this.btn_HistoSolicitudes);
            this.Panel_Menu.Controls.Add(this.btn_RegistroHuella);
            this.Panel_Menu.Controls.Add(this.btn_Selp);
            this.Panel_Menu.Controls.Add(this.btn_VisorMavi);
            this.Panel_Menu.Controls.Add(this.btn_CalidadCap);
            this.Panel_Menu.Controls.Add(this.btn_ConsultaBuro);
            this.Panel_Menu.Controls.Add(this.btn_HistoricoUniCaja);
            this.Panel_Menu.Controls.Add(this.btn_ResumenFac);
            this.Panel_Menu.Controls.Add(this.btn_KardexCliente);
            this.Panel_Menu.Controls.Add(this.btnPosicionDelMovimiento);
            this.Panel_Menu.Controls.Add(this.btn_PreliminarCobro);
            this.Panel_Menu.Controls.Add(this.btn_InformacionCliente);
            this.Panel_Menu.Controls.Add(this.btn_Eventos);
            this.Panel_Menu.Controls.Add(this.btn_UsuariosTiempos);
            this.Panel_Menu.Controls.Add(this.btn_PosicionMov);
            this.Panel_Menu.Controls.Add(this.btn_Relaciones);
            this.Panel_Menu.Controls.Add(this.BtnProspectoaCliente);
            this.Panel_Menu.Controls.Add(this.btn_CatalagoCalif);
            this.Panel_Menu.Controls.Add(this.btn_AnalistasCredi);
            this.Panel_Menu.Controls.Add(this.BTN_consultaCf);
            this.Panel_Menu.Controls.Add(this.btn_SoporAval);
            this.Panel_Menu.Controls.Add(this.btnKardex);
            this.Panel_Menu.Controls.Add(this.btnScoring);
            this.Panel_Menu.Cursor = System.Windows.Forms.Cursors.Default;
            this.Panel_Menu.Location = new System.Drawing.Point(3, 3);
            this.Panel_Menu.Name = "Panel_Menu";
            this.Panel_Menu.Size = new System.Drawing.Size(109, 635);
            this.Panel_Menu.TabIndex = 46;
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.Transparent;
            this.btn_ayuda.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ayuda.Location = new System.Drawing.Point(3, 3);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(77, 61);
            this.btn_ayuda.TabIndex = 35;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            this.btn_ayuda.Click += new System.EventHandler(this.btn_ayuda_Click);
            // 
            // btn_Nuevo
            // 
            this.btn_Nuevo.BackColor = System.Drawing.Color.Transparent;
            this.btn_Nuevo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Nuevo.FlatAppearance.BorderSize = 0;
            this.btn_Nuevo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Nuevo.Image = ((System.Drawing.Image)(resources.GetObject("btn_Nuevo.Image")));
            this.btn_Nuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Nuevo.Location = new System.Drawing.Point(3, 70);
            this.btn_Nuevo.Name = "btn_Nuevo";
            this.btn_Nuevo.Size = new System.Drawing.Size(77, 72);
            this.btn_Nuevo.TabIndex = 8;
            this.btn_Nuevo.Text = "Nuevo (Crtl+N)";
            this.btn_Nuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Nuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Nuevo.UseVisualStyleBackColor = false;
            this.btn_Nuevo.Click += new System.EventHandler(this.btn_Nuevo_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Cancelar.FlatAppearance.BorderSize = 0;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cancelar.Image")));
            this.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Cancelar.Location = new System.Drawing.Point(3, 148);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(77, 59);
            this.btn_Cancelar.TabIndex = 9;
            this.btn_Cancelar.Text = "Cerrar (Esc)";
            this.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.Transparent;
            this.btn_stop.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_stop.FlatAppearance.BorderSize = 0;
            this.btn_stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_stop.Image = global::PuntoVenta.Properties.Resources.pause_icon;
            this.btn_stop.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_stop.Location = new System.Drawing.Point(3, 213);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(77, 61);
            this.btn_stop.TabIndex = 39;
            this.btn_stop.Text = "Detener";
            this.btn_stop.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_stop.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_stop.UseVisualStyleBackColor = false;
            this.btn_stop.Visible = false;
            this.btn_stop.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Refrescar
            // 
            this.btn_Refrescar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Refrescar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Refrescar.FlatAppearance.BorderSize = 0;
            this.btn_Refrescar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Refrescar.Image = global::PuntoVenta.Properties.Resources.Refrescar;
            this.btn_Refrescar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Refrescar.Location = new System.Drawing.Point(3, 280);
            this.btn_Refrescar.Name = "btn_Refrescar";
            this.btn_Refrescar.Size = new System.Drawing.Size(77, 77);
            this.btn_Refrescar.TabIndex = 10;
            this.btn_Refrescar.Text = "Refrescar (F5)";
            this.btn_Refrescar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Refrescar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Refrescar.UseVisualStyleBackColor = false;
            this.btn_Refrescar.Click += new System.EventHandler(this.btn_Refrescar_Click);
            // 
            // btn_SolicitudCancelacion
            // 
            this.btn_SolicitudCancelacion.BackColor = System.Drawing.Color.Transparent;
            this.btn_SolicitudCancelacion.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_SolicitudCancelacion.FlatAppearance.BorderSize = 0;
            this.btn_SolicitudCancelacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SolicitudCancelacion.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SolicitudCancelacion.Image = global::PuntoVenta.Properties.Resources.icons8_folder_50;
            this.btn_SolicitudCancelacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_SolicitudCancelacion.Location = new System.Drawing.Point(3, 363);
            this.btn_SolicitudCancelacion.Name = "btn_SolicitudCancelacion";
            this.btn_SolicitudCancelacion.Size = new System.Drawing.Size(77, 135);
            this.btn_SolicitudCancelacion.TabIndex = 51;
            this.btn_SolicitudCancelacion.Text = "Solicitudes de Cancelacion (CTRL+L)";
            this.btn_SolicitudCancelacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_SolicitudCancelacion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_SolicitudCancelacion.UseVisualStyleBackColor = false;
            this.btn_SolicitudCancelacion.Visible = false;
            this.btn_SolicitudCancelacion.Click += new System.EventHandler(this.btn_SolicitudCancelacion_Click);
            // 
            // btnDineralia
            // 
            this.btnDineralia.BackColor = System.Drawing.Color.Transparent;
            this.btnDineralia.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDineralia.FlatAppearance.BorderSize = 0;
            this.btnDineralia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDineralia.Image = global::PuntoVenta.Properties.Resources.credit_card;
            this.btnDineralia.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDineralia.Location = new System.Drawing.Point(3, 504);
            this.btnDineralia.Name = "btnDineralia";
            this.btnDineralia.Size = new System.Drawing.Size(77, 77);
            this.btnDineralia.TabIndex = 47;
            this.btnDineralia.Text = "Dineralia (Crtl+G)";
            this.btnDineralia.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDineralia.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDineralia.UseVisualStyleBackColor = false;
            this.btnDineralia.Click += new System.EventHandler(this.btnDineralia_Click);
            // 
            // btn_HistoSolicitudes
            // 
            this.btn_HistoSolicitudes.BackColor = System.Drawing.Color.Transparent;
            this.btn_HistoSolicitudes.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_HistoSolicitudes.FlatAppearance.BorderSize = 0;
            this.btn_HistoSolicitudes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_HistoSolicitudes.Image = ((System.Drawing.Image)(resources.GetObject("btn_HistoSolicitudes.Image")));
            this.btn_HistoSolicitudes.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_HistoSolicitudes.Location = new System.Drawing.Point(3, 587);
            this.btn_HistoSolicitudes.Name = "btn_HistoSolicitudes";
            this.btn_HistoSolicitudes.Size = new System.Drawing.Size(77, 92);
            this.btn_HistoSolicitudes.TabIndex = 21;
            this.btn_HistoSolicitudes.Text = "Historial de Solicitudes (F3) ";
            this.btn_HistoSolicitudes.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_HistoSolicitudes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_HistoSolicitudes.UseVisualStyleBackColor = false;
            this.btn_HistoSolicitudes.Click += new System.EventHandler(this.btn_HistoSolicitudes_Click);
            // 
            // btn_RegistroHuella
            // 
            this.btn_RegistroHuella.BackColor = System.Drawing.Color.Transparent;
            this.btn_RegistroHuella.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_RegistroHuella.FlatAppearance.BorderSize = 0;
            this.btn_RegistroHuella.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_RegistroHuella.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RegistroHuella.Image = ((System.Drawing.Image)(resources.GetObject("btn_RegistroHuella.Image")));
            this.btn_RegistroHuella.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_RegistroHuella.Location = new System.Drawing.Point(3, 685);
            this.btn_RegistroHuella.Name = "btn_RegistroHuella";
            this.btn_RegistroHuella.Size = new System.Drawing.Size(77, 74);
            this.btn_RegistroHuella.TabIndex = 22;
            this.btn_RegistroHuella.Text = "Registro de Huella (F4)";
            this.btn_RegistroHuella.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_RegistroHuella.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_RegistroHuella.UseVisualStyleBackColor = false;
            this.btn_RegistroHuella.Click += new System.EventHandler(this.btn_RegistroHuella_Click);
            // 
            // btn_Selp
            // 
            this.btn_Selp.BackColor = System.Drawing.Color.Transparent;
            this.btn_Selp.FlatAppearance.BorderSize = 0;
            this.btn_Selp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Selp.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Selp.Image = ((System.Drawing.Image)(resources.GetObject("btn_Selp.Image")));
            this.btn_Selp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Selp.Location = new System.Drawing.Point(3, 765);
            this.btn_Selp.Name = "btn_Selp";
            this.btn_Selp.Size = new System.Drawing.Size(77, 83);
            this.btn_Selp.TabIndex = 40;
            this.btn_Selp.Text = "SELP (Crtl+S)";
            this.btn_Selp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Selp.UseVisualStyleBackColor = false;
            this.btn_Selp.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_VisorMavi
            // 
            this.btn_VisorMavi.BackColor = System.Drawing.Color.Transparent;
            this.btn_VisorMavi.ContextMenuStrip = this.contextMenuStrip4;
            this.btn_VisorMavi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_VisorMavi.FlatAppearance.BorderSize = 0;
            this.btn_VisorMavi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_VisorMavi.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_VisorMavi.Image = ((System.Drawing.Image)(resources.GetObject("btn_VisorMavi.Image")));
            this.btn_VisorMavi.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_VisorMavi.Location = new System.Drawing.Point(3, 854);
            this.btn_VisorMavi.Name = "btn_VisorMavi";
            this.btn_VisorMavi.Size = new System.Drawing.Size(77, 84);
            this.btn_VisorMavi.TabIndex = 18;
            this.btn_VisorMavi.Text = "Visor Mavi (F7)";
            this.btn_VisorMavi.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_VisorMavi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_VisorMavi.UseVisualStyleBackColor = false;
            this.btn_VisorMavi.Click += new System.EventHandler(this.btn_VisorMavi_Click);
            // 
            // btn_CalidadCap
            // 
            this.btn_CalidadCap.BackColor = System.Drawing.Color.Transparent;
            this.btn_CalidadCap.FlatAppearance.BorderSize = 0;
            this.btn_CalidadCap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CalidadCap.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CalidadCap.Image = ((System.Drawing.Image)(resources.GetObject("btn_CalidadCap.Image")));
            this.btn_CalidadCap.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CalidadCap.Location = new System.Drawing.Point(3, 944);
            this.btn_CalidadCap.Name = "btn_CalidadCap";
            this.btn_CalidadCap.Size = new System.Drawing.Size(77, 98);
            this.btn_CalidadCap.TabIndex = 41;
            this.btn_CalidadCap.Text = "Calidad de Captura (Crlt+L)";
            this.btn_CalidadCap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CalidadCap.UseVisualStyleBackColor = false;
            this.btn_CalidadCap.Click += new System.EventHandler(this.btn_CalidadCap_Click);
            // 
            // btn_ConsultaBuro
            // 
            this.btn_ConsultaBuro.BackColor = System.Drawing.Color.Transparent;
            this.btn_ConsultaBuro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_ConsultaBuro.FlatAppearance.BorderSize = 0;
            this.btn_ConsultaBuro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ConsultaBuro.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConsultaBuro.Image = ((System.Drawing.Image)(resources.GetObject("btn_ConsultaBuro.Image")));
            this.btn_ConsultaBuro.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ConsultaBuro.Location = new System.Drawing.Point(3, 1048);
            this.btn_ConsultaBuro.Name = "btn_ConsultaBuro";
            this.btn_ConsultaBuro.Size = new System.Drawing.Size(77, 91);
            this.btn_ConsultaBuro.TabIndex = 23;
            this.btn_ConsultaBuro.Text = "Consulta INTL Buro (F8)";
            this.btn_ConsultaBuro.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ConsultaBuro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ConsultaBuro.UseVisualStyleBackColor = false;
            this.btn_ConsultaBuro.Click += new System.EventHandler(this.btn_ConsultaBuro_Click);
            // 
            // btn_HistoricoUniCaja
            // 
            this.btn_HistoricoUniCaja.BackColor = System.Drawing.Color.Transparent;
            this.btn_HistoricoUniCaja.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_HistoricoUniCaja.FlatAppearance.BorderSize = 0;
            this.btn_HistoricoUniCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_HistoricoUniCaja.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HistoricoUniCaja.Image = ((System.Drawing.Image)(resources.GetObject("btn_HistoricoUniCaja.Image")));
            this.btn_HistoricoUniCaja.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_HistoricoUniCaja.Location = new System.Drawing.Point(3, 1145);
            this.btn_HistoricoUniCaja.Name = "btn_HistoricoUniCaja";
            this.btn_HistoricoUniCaja.Size = new System.Drawing.Size(77, 88);
            this.btn_HistoricoUniCaja.TabIndex = 16;
            this.btn_HistoricoUniCaja.Text = "Historico Unicaja (Crtl-H)";
            this.btn_HistoricoUniCaja.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_HistoricoUniCaja.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_HistoricoUniCaja.UseVisualStyleBackColor = false;
            this.btn_HistoricoUniCaja.Click += new System.EventHandler(this.btn_HistoricoUniCaja_Click);
            // 
            // btn_ResumenFac
            // 
            this.btn_ResumenFac.BackColor = System.Drawing.Color.Transparent;
            this.btn_ResumenFac.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_ResumenFac.FlatAppearance.BorderSize = 0;
            this.btn_ResumenFac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ResumenFac.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ResumenFac.Image = ((System.Drawing.Image)(resources.GetObject("btn_ResumenFac.Image")));
            this.btn_ResumenFac.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ResumenFac.Location = new System.Drawing.Point(3, 1239);
            this.btn_ResumenFac.Name = "btn_ResumenFac";
            this.btn_ResumenFac.Size = new System.Drawing.Size(75, 95);
            this.btn_ResumenFac.TabIndex = 20;
            this.btn_ResumenFac.Text = "Resumen Factura (F10)";
            this.btn_ResumenFac.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ResumenFac.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ResumenFac.UseVisualStyleBackColor = false;
            this.btn_ResumenFac.Click += new System.EventHandler(this.btn_ResumenFac_Click);
            // 
            // btn_KardexCliente
            // 
            this.btn_KardexCliente.BackColor = System.Drawing.Color.Transparent;
            this.btn_KardexCliente.FlatAppearance.BorderSize = 0;
            this.btn_KardexCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_KardexCliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_KardexCliente.Image")));
            this.btn_KardexCliente.Location = new System.Drawing.Point(3, 1340);
            this.btn_KardexCliente.Name = "btn_KardexCliente";
            this.btn_KardexCliente.Size = new System.Drawing.Size(75, 75);
            this.btn_KardexCliente.TabIndex = 15;
            this.btn_KardexCliente.Text = "Kardex del Cliente (F11)";
            this.btn_KardexCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_KardexCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_KardexCliente.UseVisualStyleBackColor = false;
            this.btn_KardexCliente.Click += new System.EventHandler(this.btn_KardexCliente_Click);
            // 
            // btnPosicionDelMovimiento
            // 
            this.btnPosicionDelMovimiento.BackColor = System.Drawing.Color.Transparent;
            this.btnPosicionDelMovimiento.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnPosicionDelMovimiento.FlatAppearance.BorderSize = 0;
            this.btnPosicionDelMovimiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPosicionDelMovimiento.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosicionDelMovimiento.Image = global::PuntoVenta.Properties.Resources.hierarchy;
            this.btnPosicionDelMovimiento.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPosicionDelMovimiento.Location = new System.Drawing.Point(3, 1421);
            this.btnPosicionDelMovimiento.Name = "btnPosicionDelMovimiento";
            this.btnPosicionDelMovimiento.Size = new System.Drawing.Size(77, 78);
            this.btnPosicionDelMovimiento.TabIndex = 52;
            this.btnPosicionDelMovimiento.Text = "Posición Del Movimiento";
            this.btnPosicionDelMovimiento.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPosicionDelMovimiento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPosicionDelMovimiento.UseVisualStyleBackColor = false;
            this.btnPosicionDelMovimiento.Click += new System.EventHandler(this.btnPosicionDelMovimiento_Click);
            // 
            // btn_PreliminarCobro
            // 
            this.btn_PreliminarCobro.BackColor = System.Drawing.Color.Transparent;
            this.btn_PreliminarCobro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_PreliminarCobro.FlatAppearance.BorderSize = 0;
            this.btn_PreliminarCobro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_PreliminarCobro.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PreliminarCobro.Image = ((System.Drawing.Image)(resources.GetObject("btn_PreliminarCobro.Image")));
            this.btn_PreliminarCobro.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_PreliminarCobro.Location = new System.Drawing.Point(3, 1505);
            this.btn_PreliminarCobro.Name = "btn_PreliminarCobro";
            this.btn_PreliminarCobro.Size = new System.Drawing.Size(77, 94);
            this.btn_PreliminarCobro.TabIndex = 17;
            this.btn_PreliminarCobro.Text = "Preliminar de Cobro (F12)";
            this.btn_PreliminarCobro.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_PreliminarCobro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_PreliminarCobro.UseVisualStyleBackColor = false;
            this.btn_PreliminarCobro.Click += new System.EventHandler(this.btn_PreliminarCobro_Click);
            // 
            // btn_InformacionCliente
            // 
            this.btn_InformacionCliente.BackColor = System.Drawing.Color.Transparent;
            this.btn_InformacionCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_InformacionCliente.FlatAppearance.BorderSize = 0;
            this.btn_InformacionCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InformacionCliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_InformacionCliente.Image")));
            this.btn_InformacionCliente.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_InformacionCliente.Location = new System.Drawing.Point(3, 1605);
            this.btn_InformacionCliente.Name = "btn_InformacionCliente";
            this.btn_InformacionCliente.Size = new System.Drawing.Size(76, 78);
            this.btn_InformacionCliente.TabIndex = 11;
            this.btn_InformacionCliente.Text = "Informacion del Cliente (Crtl-I)";
            this.btn_InformacionCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InformacionCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InformacionCliente.UseVisualStyleBackColor = false;
            this.btn_InformacionCliente.Click += new System.EventHandler(this.btn_InfCliente_Click);
            // 
            // btn_Eventos
            // 
            this.btn_Eventos.BackColor = System.Drawing.Color.Transparent;
            this.btn_Eventos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Eventos.FlatAppearance.BorderSize = 0;
            this.btn_Eventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Eventos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Eventos.Image")));
            this.btn_Eventos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Eventos.Location = new System.Drawing.Point(3, 1689);
            this.btn_Eventos.Name = "btn_Eventos";
            this.btn_Eventos.Size = new System.Drawing.Size(77, 85);
            this.btn_Eventos.TabIndex = 12;
            this.btn_Eventos.Text = "Eventos, Notas y Citas (Crtl-E)";
            this.btn_Eventos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Eventos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Eventos.UseVisualStyleBackColor = false;
            this.btn_Eventos.Click += new System.EventHandler(this.btn_Eventos_Click);
            // 
            // btn_UsuariosTiempos
            // 
            this.btn_UsuariosTiempos.BackColor = System.Drawing.Color.Transparent;
            this.btn_UsuariosTiempos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_UsuariosTiempos.FlatAppearance.BorderSize = 0;
            this.btn_UsuariosTiempos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UsuariosTiempos.Image = ((System.Drawing.Image)(resources.GetObject("btn_UsuariosTiempos.Image")));
            this.btn_UsuariosTiempos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_UsuariosTiempos.Location = new System.Drawing.Point(3, 1780);
            this.btn_UsuariosTiempos.Name = "btn_UsuariosTiempos";
            this.btn_UsuariosTiempos.Size = new System.Drawing.Size(76, 89);
            this.btn_UsuariosTiempos.TabIndex = 13;
            this.btn_UsuariosTiempos.Text = "Usuarios y Tiempos (Crtl-U)";
            this.btn_UsuariosTiempos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_UsuariosTiempos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_UsuariosTiempos.UseVisualStyleBackColor = false;
            this.btn_UsuariosTiempos.Click += new System.EventHandler(this.btn_UsuariosTiempos_Click);
            // 
            // btn_PosicionMov
            // 
            this.btn_PosicionMov.BackColor = System.Drawing.Color.Transparent;
            this.btn_PosicionMov.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_PosicionMov.FlatAppearance.BorderSize = 0;
            this.btn_PosicionMov.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_PosicionMov.Image = ((System.Drawing.Image)(resources.GetObject("btn_PosicionMov.Image")));
            this.btn_PosicionMov.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_PosicionMov.Location = new System.Drawing.Point(3, 1875);
            this.btn_PosicionMov.Name = "btn_PosicionMov";
            this.btn_PosicionMov.Size = new System.Drawing.Size(77, 85);
            this.btn_PosicionMov.TabIndex = 14;
            this.btn_PosicionMov.Text = "Posicion del Movimiento (Crtl-P)";
            this.btn_PosicionMov.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_PosicionMov.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_PosicionMov.UseVisualStyleBackColor = false;
            this.btn_PosicionMov.Click += new System.EventHandler(this.btn_PosMov_Click);
            // 
            // btn_Relaciones
            // 
            this.btn_Relaciones.BackColor = System.Drawing.Color.Transparent;
            this.btn_Relaciones.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Relaciones.FlatAppearance.BorderSize = 0;
            this.btn_Relaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Relaciones.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Relaciones.Image = ((System.Drawing.Image)(resources.GetObject("btn_Relaciones.Image")));
            this.btn_Relaciones.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Relaciones.Location = new System.Drawing.Point(3, 1966);
            this.btn_Relaciones.Name = "btn_Relaciones";
            this.btn_Relaciones.Size = new System.Drawing.Size(77, 80);
            this.btn_Relaciones.TabIndex = 19;
            this.btn_Relaciones.Text = "Relaciones (Crtl-R)";
            this.btn_Relaciones.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Relaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Relaciones.UseVisualStyleBackColor = false;
            this.btn_Relaciones.Click += new System.EventHandler(this.btn_Relaciones_Click);
            // 
            // BtnProspectoaCliente
            // 
            this.BtnProspectoaCliente.BackColor = System.Drawing.Color.Transparent;
            this.BtnProspectoaCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BtnProspectoaCliente.FlatAppearance.BorderSize = 0;
            this.BtnProspectoaCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnProspectoaCliente.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnProspectoaCliente.Image = ((System.Drawing.Image)(resources.GetObject("BtnProspectoaCliente.Image")));
            this.BtnProspectoaCliente.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnProspectoaCliente.Location = new System.Drawing.Point(3, 2052);
            this.BtnProspectoaCliente.Name = "BtnProspectoaCliente";
            this.BtnProspectoaCliente.Size = new System.Drawing.Size(77, 108);
            this.BtnProspectoaCliente.TabIndex = 26;
            this.BtnProspectoaCliente.Text = "Cambiar Prospecto a Cliente (Crtl-Q)";
            this.BtnProspectoaCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnProspectoaCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnProspectoaCliente.UseVisualStyleBackColor = false;
            this.BtnProspectoaCliente.Click += new System.EventHandler(this.BtnProspectoaCliente_Click);
            // 
            // btn_CatalagoCalif
            // 
            this.btn_CatalagoCalif.BackColor = System.Drawing.Color.Transparent;
            this.btn_CatalagoCalif.FlatAppearance.BorderSize = 0;
            this.btn_CatalagoCalif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CatalagoCalif.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CatalagoCalif.Image = ((System.Drawing.Image)(resources.GetObject("btn_CatalagoCalif.Image")));
            this.btn_CatalagoCalif.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CatalagoCalif.Location = new System.Drawing.Point(3, 2166);
            this.btn_CatalagoCalif.Name = "btn_CatalagoCalif";
            this.btn_CatalagoCalif.Size = new System.Drawing.Size(77, 72);
            this.btn_CatalagoCalif.TabIndex = 38;
            this.btn_CatalagoCalif.Text = "Catalogo de Cal. (Crtl-O)";
            this.btn_CatalagoCalif.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CatalagoCalif.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CatalagoCalif.UseVisualStyleBackColor = false;
            this.btn_CatalagoCalif.Click += new System.EventHandler(this.btn_CatalagoCalif_Click);
            // 
            // btn_AnalistasCredi
            // 
            this.btn_AnalistasCredi.BackColor = System.Drawing.Color.Transparent;
            this.btn_AnalistasCredi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_AnalistasCredi.FlatAppearance.BorderSize = 0;
            this.btn_AnalistasCredi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AnalistasCredi.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AnalistasCredi.Image = ((System.Drawing.Image)(resources.GetObject("btn_AnalistasCredi.Image")));
            this.btn_AnalistasCredi.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_AnalistasCredi.Location = new System.Drawing.Point(3, 2244);
            this.btn_AnalistasCredi.Name = "btn_AnalistasCredi";
            this.btn_AnalistasCredi.Size = new System.Drawing.Size(77, 83);
            this.btn_AnalistasCredi.TabIndex = 42;
            this.btn_AnalistasCredi.Text = "Analistas de Credito (Crtl-B)";
            this.btn_AnalistasCredi.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_AnalistasCredi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_AnalistasCredi.UseVisualStyleBackColor = false;
            this.btn_AnalistasCredi.Click += new System.EventHandler(this.btn_AnalistasCredi_Click);
            // 
            // BTN_consultaCf
            // 
            this.BTN_consultaCf.BackColor = System.Drawing.Color.Transparent;
            this.BTN_consultaCf.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BTN_consultaCf.FlatAppearance.BorderSize = 0;
            this.BTN_consultaCf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_consultaCf.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_consultaCf.Image = ((System.Drawing.Image)(resources.GetObject("BTN_consultaCf.Image")));
            this.BTN_consultaCf.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BTN_consultaCf.Location = new System.Drawing.Point(3, 2333);
            this.BTN_consultaCf.Name = "BTN_consultaCf";
            this.BTN_consultaCf.Size = new System.Drawing.Size(77, 98);
            this.BTN_consultaCf.TabIndex = 43;
            this.BTN_consultaCf.Text = "Consulta cliente final (Ctrl-F10)";
            this.BTN_consultaCf.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BTN_consultaCf.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BTN_consultaCf.UseVisualStyleBackColor = false;
            this.BTN_consultaCf.Click += new System.EventHandler(this.BTN_consultaCf_Click);
            // 
            // btn_SoporAval
            // 
            this.btn_SoporAval.BackColor = System.Drawing.Color.Transparent;
            this.btn_SoporAval.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_SoporAval.FlatAppearance.BorderSize = 0;
            this.btn_SoporAval.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SoporAval.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SoporAval.Image = ((System.Drawing.Image)(resources.GetObject("btn_SoporAval.Image")));
            this.btn_SoporAval.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_SoporAval.Location = new System.Drawing.Point(3, 2437);
            this.btn_SoporAval.Name = "btn_SoporAval";
            this.btn_SoporAval.Size = new System.Drawing.Size(77, 125);
            this.btn_SoporAval.TabIndex = 45;
            this.btn_SoporAval.Text = "Soportados por aval (Ctrl-F11)";
            this.btn_SoporAval.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_SoporAval.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_SoporAval.UseVisualStyleBackColor = false;
            this.btn_SoporAval.Click += new System.EventHandler(this.btn_SoporAval_Click);
            // 
            // btnKardex
            // 
            this.btnKardex.BackColor = System.Drawing.Color.Transparent;
            this.btnKardex.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnKardex.FlatAppearance.BorderSize = 0;
            this.btnKardex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKardex.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKardex.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKardex.Location = new System.Drawing.Point(3, 2568);
            this.btnKardex.Name = "btnKardex";
            this.btnKardex.Size = new System.Drawing.Size(77, 80);
            this.btnKardex.TabIndex = 46;
            this.btnKardex.Text = "Kardex (Ctrl-W)";
            this.btnKardex.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKardex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnKardex.UseVisualStyleBackColor = false;
            this.btnKardex.Click += new System.EventHandler(this.btnKardex_Click);
            // 
            // btnScoring
            // 
            this.btnScoring.BackColor = System.Drawing.Color.Transparent;
            this.btnScoring.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnScoring.FlatAppearance.BorderSize = 0;
            this.btnScoring.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScoring.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScoring.Image = global::PuntoVenta.Properties.Resources.satisfaction;
            this.btnScoring.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnScoring.Location = new System.Drawing.Point(3, 2654);
            this.btnScoring.Name = "btnScoring";
            this.btnScoring.Size = new System.Drawing.Size(77, 80);
            this.btnScoring.TabIndex = 50;
            this.btnScoring.Text = "Scoring (Ctrl + Y)";
            this.btnScoring.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnScoring.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnScoring.UseVisualStyleBackColor = false;
            this.btnScoring.Visible = false;
            this.btnScoring.Click += new System.EventHandler(this.btnScoring_Click);
            // 
            // Panel_TiposVenta
            // 
            this.Panel_TiposVenta.BackColor = System.Drawing.Color.AliceBlue;
            this.Panel_TiposVenta.Controls.Add(this.chk_ContadoNuevo);
            this.Panel_TiposVenta.Controls.Add(this.chk_ContadoCasa);
            this.Panel_TiposVenta.Controls.Add(this.chk_CreditoNuevo);
            this.Panel_TiposVenta.Controls.Add(this.chk_CreditoCasa);
            this.Panel_TiposVenta.Controls.Add(this.chk_MA);
            this.Panel_TiposVenta.Controls.Add(this.chk_MAVI);
            this.Panel_TiposVenta.Controls.Add(this.chk_VIU);
            this.Panel_TiposVenta.Controls.Add(this.cbx_CreditoCasaMayoreo);
            this.Panel_TiposVenta.Controls.Add(this.cbx_creditoNuevoMayoreo);
            this.Panel_TiposVenta.Controls.Add(this.chk_ClienteEnSucursal);
            this.Panel_TiposVenta.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.Panel_TiposVenta.Location = new System.Drawing.Point(226, 75);
            this.Panel_TiposVenta.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.Panel_TiposVenta.Name = "Panel_TiposVenta";
            this.Panel_TiposVenta.Size = new System.Drawing.Size(747, 25);
            this.Panel_TiposVenta.TabIndex = 47;
            // 
            // chk_ClienteEnSucursal
            // 
            this.chk_ClienteEnSucursal.AutoSize = true;
            this.chk_ClienteEnSucursal.BackColor = System.Drawing.Color.Transparent;
            this.chk_ClienteEnSucursal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_ClienteEnSucursal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_ClienteEnSucursal.Location = new System.Drawing.Point(865, 3);
            this.chk_ClienteEnSucursal.Name = "chk_ClienteEnSucursal";
            this.chk_ClienteEnSucursal.Size = new System.Drawing.Size(110, 19);
            this.chk_ClienteEnSucursal.TabIndex = 46;
            this.chk_ClienteEnSucursal.Text = "Cliente En Suc.";
            this.chk_ClienteEnSucursal.UseVisualStyleBackColor = false;
            this.chk_ClienteEnSucursal.Visible = false;
            this.chk_ClienteEnSucursal.CheckStateChanged += new System.EventHandler(this.chk_ClienteEnSucursal_CheckStateChanged);
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.Controls.Add(this.groupBox1);
            this.panelContactos.Controls.Add(this.gbx_TableroPr);
            this.panelContactos.Controls.Add(this.flp_PanelEventos);
            this.panelContactos.Controls.Add(this.gbx_PanelHuellas);
            this.panelContactos.Controls.Add(this.btn_Contactos);
            this.panelContactos.Controls.Add(this.gbx_Contactos);
            this.panelContactos.Controls.Add(this.btn_DocumentosAdjuntos);
            this.panelContactos.Controls.Add(this.gbx_DocumentosAdj);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(134, 24);
            this.panelContactos.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(1140, 1251);
            this.panelContactos.TabIndex = 49;
            this.panelContactos.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelContactos_MouseMove);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.groupBox1.Controls.Add(this.btn_storepickupOrders);
            this.groupBox1.Controls.Add(this.lbl_TipoCredito);
            this.groupBox1.Controls.Add(this.cbx_fechaA);
            this.groupBox1.Controls.Add(this.btn_ConfColumnas);
            this.groupBox1.Controls.Add(this.cbx_fechaD);
            this.groupBox1.Controls.Add(this.lbl_Usuario);
            this.groupBox1.Controls.Add(this.listTipoCredito);
            this.groupBox1.Controls.Add(this.lbl_CuentaCaja);
            this.groupBox1.Controls.Add(this.lbl_Buscar);
            this.groupBox1.Controls.Add(this.lbl_FechaA);
            this.groupBox1.Controls.Add(this.chk_Devolucion);
            this.groupBox1.Controls.Add(this.dtp_Afecha);
            this.groupBox1.Controls.Add(this.cbx_Impreso);
            this.groupBox1.Controls.Add(this.Panel_TiposVenta);
            this.groupBox1.Controls.Add(this.lblBuscarEn);
            this.groupBox1.Controls.Add(this.txt_ComentarioAyuda);
            this.groupBox1.Controls.Add(this.dtp_DeFecha);
            this.groupBox1.Controls.Add(this.lblMovimiento);
            this.groupBox1.Controls.Add(this.cbx_movimiento);
            this.groupBox1.Controls.Add(this.lbl_FechaD);
            this.groupBox1.Controls.Add(this.lbl_Comentario);
            this.groupBox1.Controls.Add(this.txt_Sucursal);
            this.groupBox1.Controls.Add(this.lbl_Sucursal);
            this.groupBox1.Controls.Add(this.lblSituacion);
            this.groupBox1.Controls.Add(this.cbx_estatus);
            this.groupBox1.Controls.Add(this.cbx_BuscarEn);
            this.groupBox1.Controls.Add(this.txt_Buscar);
            this.groupBox1.Controls.Add(this.txt_NombreSucursal);
            this.groupBox1.Controls.Add(this.cbx_situacion);
            this.groupBox1.Controls.Add(this.lbl_Estatus);
            this.groupBox1.Controls.Add(this.lbl_Impreso);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1134, 183);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // lbl_TipoCredito
            // 
            this.lbl_TipoCredito.AutoSize = true;
            this.lbl_TipoCredito.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TipoCredito.Location = new System.Drawing.Point(792, 15);
            this.lbl_TipoCredito.Name = "lbl_TipoCredito";
            this.lbl_TipoCredito.Size = new System.Drawing.Size(75, 15);
            this.lbl_TipoCredito.TabIndex = 57;
            this.lbl_TipoCredito.Text = "Tipo Credito";
            // 
            // cbx_fechaA
            // 
            this.cbx_fechaA.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cbx_fechaA.Location = new System.Drawing.Point(679, 33);
            this.cbx_fechaA.Name = "cbx_fechaA";
            this.cbx_fechaA.ReadOnly = true;
            this.cbx_fechaA.Size = new System.Drawing.Size(68, 20);
            this.cbx_fechaA.TabIndex = 54;
            this.cbx_fechaA.Click += new System.EventHandler(this.cbx_fechaA_Click);
            // 
            // btn_ConfColumnas
            // 
            this.btn_ConfColumnas.BackColor = System.Drawing.Color.AliceBlue;
            this.btn_ConfColumnas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ConfColumnas.FlatAppearance.BorderSize = 0;
            this.btn_ConfColumnas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ConfColumnas.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfColumnas.Image = ((System.Drawing.Image)(resources.GetObject("btn_ConfColumnas.Image")));
            this.btn_ConfColumnas.Location = new System.Drawing.Point(996, 75);
            this.btn_ConfColumnas.Name = "btn_ConfColumnas";
            this.btn_ConfColumnas.Size = new System.Drawing.Size(135, 43);
            this.btn_ConfColumnas.TabIndex = 30;
            this.btn_ConfColumnas.Text = "Configuracion de Columnas (F9)";
            this.btn_ConfColumnas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ConfColumnas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_ConfColumnas.UseVisualStyleBackColor = false;
            this.btn_ConfColumnas.Click += new System.EventHandler(this.btn_ConfColumn_Click);
            // 
            // cbx_fechaD
            // 
            this.cbx_fechaD.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cbx_fechaD.Location = new System.Drawing.Point(572, 33);
            this.cbx_fechaD.Name = "cbx_fechaD";
            this.cbx_fechaD.ReadOnly = true;
            this.cbx_fechaD.Size = new System.Drawing.Size(68, 20);
            this.cbx_fechaD.TabIndex = 53;
            this.cbx_fechaD.Click += new System.EventHandler(this.cbx_fechaD_Click);
            this.cbx_fechaD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_fechaD_KeyPress);
            // 
            // listTipoCredito
            // 
            this.listTipoCredito.FormattingEnabled = true;
            this.listTipoCredito.Location = new System.Drawing.Point(795, 59);
            this.listTipoCredito.Name = "listTipoCredito";
            this.listTipoCredito.Size = new System.Drawing.Size(179, 94);
            this.listTipoCredito.TabIndex = 56;
            // 
            // chk_Devolucion
            // 
            this.chk_Devolucion.AutoSize = true;
            this.chk_Devolucion.BackColor = System.Drawing.Color.Transparent;
            this.chk_Devolucion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Devolucion.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chk_Devolucion.Location = new System.Drawing.Point(109, 77);
            this.chk_Devolucion.Name = "chk_Devolucion";
            this.chk_Devolucion.Size = new System.Drawing.Size(86, 19);
            this.chk_Devolucion.TabIndex = 27;
            this.chk_Devolucion.Text = "Devolucion";
            this.chk_Devolucion.UseVisualStyleBackColor = false;
            this.chk_Devolucion.CheckedChanged += new System.EventHandler(this.chk_Devolucion_CheckedChanged);
            this.chk_Devolucion.Click += new System.EventHandler(this.chk_Devolucion_Click);
            // 
            // cbx_Impreso
            // 
            this.cbx_Impreso.BackColor = System.Drawing.Color.White;
            this.cbx_Impreso.FormattingEnabled = true;
            this.cbx_Impreso.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbx_Impreso.Location = new System.Drawing.Point(5, 79);
            this.cbx_Impreso.Name = "cbx_Impreso";
            this.cbx_Impreso.Size = new System.Drawing.Size(98, 21);
            this.cbx_Impreso.TabIndex = 51;
            this.cbx_Impreso.Click += new System.EventHandler(this.cbx_Impreso_Click);
            this.cbx_Impreso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Impreso_KeyPress);
            // 
            // txt_NombreSucursal
            // 
            this.txt_NombreSucursal.Location = new System.Drawing.Point(847, 33);
            this.txt_NombreSucursal.Name = "txt_NombreSucursal";
            this.txt_NombreSucursal.Size = new System.Drawing.Size(156, 20);
            this.txt_NombreSucursal.TabIndex = 40;
            // 
            // lbl_Impreso
            // 
            this.lbl_Impreso.AutoSize = true;
            this.lbl_Impreso.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Impreso.Location = new System.Drawing.Point(11, 61);
            this.lbl_Impreso.Name = "lbl_Impreso";
            this.lbl_Impreso.Size = new System.Drawing.Size(51, 15);
            this.lbl_Impreso.TabIndex = 50;
            this.lbl_Impreso.Text = "Impreso";
            // 
            // flp_PanelEventos
            // 
            this.flp_PanelEventos.BackColor = System.Drawing.Color.White;
            this.flp_PanelEventos.Controls.Add(this.gbx_Eventos);
            this.flp_PanelEventos.Location = new System.Drawing.Point(3, 508);
            this.flp_PanelEventos.Name = "flp_PanelEventos";
            this.flp_PanelEventos.Size = new System.Drawing.Size(1134, 172);
            this.flp_PanelEventos.TabIndex = 48;
            // 
            // gbx_Eventos
            // 
            this.gbx_Eventos.Controls.Add(this.dgv_Eventos);
            this.gbx_Eventos.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_Eventos.Location = new System.Drawing.Point(3, 3);
            this.gbx_Eventos.Name = "gbx_Eventos";
            this.gbx_Eventos.Size = new System.Drawing.Size(1128, 159);
            this.gbx_Eventos.TabIndex = 13;
            this.gbx_Eventos.TabStop = false;
            this.gbx_Eventos.Text = "Eventos";
            this.gbx_Eventos.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_Eventos_Paint);
            // 
            // dgv_Eventos
            // 
            this.dgv_Eventos.AllowUserToAddRows = false;
            this.dgv_Eventos.AllowUserToResizeRows = false;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Eventos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgv_Eventos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Eventos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Eventos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Eventos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgv_Eventos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Eventos.ContextMenuStrip = this.toolTipRecalificar;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Eventos.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgv_Eventos.EnableHeadersVisualStyles = false;
            this.dgv_Eventos.Location = new System.Drawing.Point(3, 18);
            this.dgv_Eventos.Name = "dgv_Eventos";
            this.dgv_Eventos.ReadOnly = true;
            this.dgv_Eventos.RowHeadersVisible = false;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_Eventos.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgv_Eventos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_Eventos.Size = new System.Drawing.Size(1121, 135);
            this.dgv_Eventos.TabIndex = 31;
            this.dgv_Eventos.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_Eventos_CellFormatting);
            // 
            // gbx_PanelHuellas
            // 
            this.gbx_PanelHuellas.BackColor = System.Drawing.Color.White;
            this.gbx_PanelHuellas.Controls.Add(this.gbx_Detalle);
            this.gbx_PanelHuellas.Controls.Add(this.gbx_FotoCliente);
            this.gbx_PanelHuellas.Location = new System.Drawing.Point(3, 686);
            this.gbx_PanelHuellas.Name = "gbx_PanelHuellas";
            this.gbx_PanelHuellas.Size = new System.Drawing.Size(1134, 253);
            this.gbx_PanelHuellas.TabIndex = 53;
            this.gbx_PanelHuellas.TabStop = false;
            this.gbx_PanelHuellas.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_PanelHuellas_Paint);
            // 
            // btn_Contactos
            // 
            this.btn_Contactos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Contactos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Contactos.FlatAppearance.BorderSize = 0;
            this.btn_Contactos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Contactos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Contactos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Contactos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Contactos.Image")));
            this.btn_Contactos.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_Contactos.Location = new System.Drawing.Point(3, 945);
            this.btn_Contactos.Name = "btn_Contactos";
            this.btn_Contactos.Size = new System.Drawing.Size(111, 42);
            this.btn_Contactos.TabIndex = 40;
            this.btn_Contactos.Text = "Contactos";
            this.btn_Contactos.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_Contactos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Contactos.UseVisualStyleBackColor = false;
            this.btn_Contactos.Click += new System.EventHandler(this.btn_Contactos_Click);
            // 
            // btn_DocumentosAdjuntos
            // 
            this.btn_DocumentosAdjuntos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_DocumentosAdjuntos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_DocumentosAdjuntos.FlatAppearance.BorderSize = 0;
            this.btn_DocumentosAdjuntos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DocumentosAdjuntos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DocumentosAdjuntos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DocumentosAdjuntos.Image = ((System.Drawing.Image)(resources.GetObject("btn_DocumentosAdjuntos.Image")));
            this.btn_DocumentosAdjuntos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DocumentosAdjuntos.Location = new System.Drawing.Point(3, 1098);
            this.btn_DocumentosAdjuntos.Name = "btn_DocumentosAdjuntos";
            this.btn_DocumentosAdjuntos.Size = new System.Drawing.Size(186, 43);
            this.btn_DocumentosAdjuntos.TabIndex = 39;
            this.btn_DocumentosAdjuntos.Text = "Documentos Adjuntos";
            this.btn_DocumentosAdjuntos.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btn_DocumentosAdjuntos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_DocumentosAdjuntos.UseVisualStyleBackColor = false;
            this.btn_DocumentosAdjuntos.Click += new System.EventHandler(this.btn_DocumentosAdjuntos_Click);
            // 
            // gbx_DocumentosAdj
            // 
            this.gbx_DocumentosAdj.BackColor = System.Drawing.Color.White;
            this.gbx_DocumentosAdj.Controls.Add(this.panelIdentifiacion);
            this.gbx_DocumentosAdj.Controls.Add(this.panelComprobante);
            this.gbx_DocumentosAdj.Controls.Add(this.panelTarjetasDigitales);
            this.gbx_DocumentosAdj.Controls.Add(this.panelPagares);
            this.gbx_DocumentosAdj.Cursor = System.Windows.Forms.Cursors.Default;
            this.gbx_DocumentosAdj.Location = new System.Drawing.Point(3, 1147);
            this.gbx_DocumentosAdj.Name = "gbx_DocumentosAdj";
            this.gbx_DocumentosAdj.Size = new System.Drawing.Size(1134, 101);
            this.gbx_DocumentosAdj.TabIndex = 52;
            // 
            // panelIdentifiacion
            // 
            this.panelIdentifiacion.Controls.Add(this.pb_Identificacion);
            this.panelIdentifiacion.Controls.Add(this.lbl_Identificacion);
            this.panelIdentifiacion.Location = new System.Drawing.Point(3, 3);
            this.panelIdentifiacion.Name = "panelIdentifiacion";
            this.panelIdentifiacion.Size = new System.Drawing.Size(183, 112);
            this.panelIdentifiacion.TabIndex = 19;
            // 
            // pb_Identificacion
            // 
            this.pb_Identificacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_Identificacion.Location = new System.Drawing.Point(40, 3);
            this.pb_Identificacion.Name = "pb_Identificacion";
            this.pb_Identificacion.Size = new System.Drawing.Size(100, 73);
            this.pb_Identificacion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Identificacion.TabIndex = 17;
            this.pb_Identificacion.TabStop = false;
            this.pb_Identificacion.Click += new System.EventHandler(this.pb_Identificacion_Click);
            // 
            // lbl_Identificacion
            // 
            this.lbl_Identificacion.AutoSize = true;
            this.lbl_Identificacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Identificacion.Location = new System.Drawing.Point(60, 81);
            this.lbl_Identificacion.Name = "lbl_Identificacion";
            this.lbl_Identificacion.Size = new System.Drawing.Size(57, 15);
            this.lbl_Identificacion.TabIndex = 18;
            this.lbl_Identificacion.Text = "Nombre1";
            this.lbl_Identificacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelComprobante
            // 
            this.panelComprobante.Controls.Add(this.lbl_Comprobante);
            this.panelComprobante.Controls.Add(this.pb_Comprobante);
            this.panelComprobante.Location = new System.Drawing.Point(192, 3);
            this.panelComprobante.Name = "panelComprobante";
            this.panelComprobante.Size = new System.Drawing.Size(183, 112);
            this.panelComprobante.TabIndex = 20;
            // 
            // lbl_Comprobante
            // 
            this.lbl_Comprobante.AutoSize = true;
            this.lbl_Comprobante.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comprobante.Location = new System.Drawing.Point(59, 81);
            this.lbl_Comprobante.Name = "lbl_Comprobante";
            this.lbl_Comprobante.Size = new System.Drawing.Size(60, 15);
            this.lbl_Comprobante.TabIndex = 15;
            this.lbl_Comprobante.Text = "Nombre 2";
            this.lbl_Comprobante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Comprobante
            // 
            this.pb_Comprobante.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_Comprobante.Location = new System.Drawing.Point(42, 3);
            this.pb_Comprobante.Name = "pb_Comprobante";
            this.pb_Comprobante.Size = new System.Drawing.Size(100, 73);
            this.pb_Comprobante.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Comprobante.TabIndex = 9;
            this.pb_Comprobante.TabStop = false;
            this.pb_Comprobante.Click += new System.EventHandler(this.pb_Comprobante_Click);
            // 
            // panelTarjetasDigitales
            // 
            this.panelTarjetasDigitales.Controls.Add(this.lbl_TarjetasDig);
            this.panelTarjetasDigitales.Controls.Add(this.pb_TarjetasDig);
            this.panelTarjetasDigitales.Location = new System.Drawing.Point(381, 3);
            this.panelTarjetasDigitales.Name = "panelTarjetasDigitales";
            this.panelTarjetasDigitales.Size = new System.Drawing.Size(183, 112);
            this.panelTarjetasDigitales.TabIndex = 21;
            // 
            // lbl_TarjetasDig
            // 
            this.lbl_TarjetasDig.AutoSize = true;
            this.lbl_TarjetasDig.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TarjetasDig.Location = new System.Drawing.Point(64, 81);
            this.lbl_TarjetasDig.Name = "lbl_TarjetasDig";
            this.lbl_TarjetasDig.Size = new System.Drawing.Size(60, 15);
            this.lbl_TarjetasDig.TabIndex = 14;
            this.lbl_TarjetasDig.Text = "Nombre 3";
            this.lbl_TarjetasDig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_TarjetasDig
            // 
            this.pb_TarjetasDig.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_TarjetasDig.Location = new System.Drawing.Point(44, 3);
            this.pb_TarjetasDig.Name = "pb_TarjetasDig";
            this.pb_TarjetasDig.Size = new System.Drawing.Size(100, 73);
            this.pb_TarjetasDig.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_TarjetasDig.TabIndex = 10;
            this.pb_TarjetasDig.TabStop = false;
            this.pb_TarjetasDig.Click += new System.EventHandler(this.pb_TarjetasDig_Click);
            // 
            // panelPagares
            // 
            this.panelPagares.Controls.Add(this.lbl__Pagares);
            this.panelPagares.Controls.Add(this.pb_Pagares);
            this.panelPagares.Location = new System.Drawing.Point(570, 3);
            this.panelPagares.Name = "panelPagares";
            this.panelPagares.Size = new System.Drawing.Size(183, 112);
            this.panelPagares.TabIndex = 22;
            // 
            // lbl__Pagares
            // 
            this.lbl__Pagares.AutoSize = true;
            this.lbl__Pagares.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl__Pagares.Location = new System.Drawing.Point(72, 81);
            this.lbl__Pagares.Name = "lbl__Pagares";
            this.lbl__Pagares.Size = new System.Drawing.Size(60, 15);
            this.lbl__Pagares.TabIndex = 13;
            this.lbl__Pagares.Text = "Nombre 4";
            this.lbl__Pagares.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Pagares
            // 
            this.pb_Pagares.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_Pagares.Location = new System.Drawing.Point(50, 3);
            this.pb_Pagares.Name = "pb_Pagares";
            this.pb_Pagares.Size = new System.Drawing.Size(100, 73);
            this.pb_Pagares.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Pagares.TabIndex = 11;
            this.pb_Pagares.TabStop = false;
            this.pb_Pagares.Click += new System.EventHandler(this.pb_Pagares_Click);
            // 
            // pnlfix_delfix
            // 
            this.pnlfix_delfix.BackColor = System.Drawing.Color.White;
            this.pnlfix_delfix.Controls.Add(this.Panel_Menu);
            this.pnlfix_delfix.Location = new System.Drawing.Point(2, 53);
            this.pnlfix_delfix.Name = "pnlfix_delfix";
            this.pnlfix_delfix.Size = new System.Drawing.Size(115, 640);
            this.pnlfix_delfix.TabIndex = 52;
            // 
            // SPID
            // 
            this.SPID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPID.Location = new System.Drawing.Point(12, 24);
            this.SPID.Name = "SPID";
            this.SPID.Size = new System.Drawing.Size(80, 22);
            this.SPID.TabIndex = 38;
            this.SPID.Text = "SPID:";
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(116, 257);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(15, 31);
            this.button3.TabIndex = 54;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // NotificarAnalista
            // 
            this.NotificarAnalista.Image = global::PuntoVenta.Properties.Resources.icons8_campana_16;
            this.NotificarAnalista.Name = "NotificarAnalista";
            this.NotificarAnalista.Size = new System.Drawing.Size(281, 22);
            this.NotificarAnalista.Text = "Notificar Analista (Ctrl + F6)";
            this.NotificarAnalista.Click += new System.EventHandler(this.NotificarAnalista_Click);
            // 
            // AgregarEventoMI
            // 
            this.AgregarEventoMI.Image = global::PuntoVenta.Properties.Resources.Utilities_google_calendar_icon;
            this.AgregarEventoMI.Name = "AgregarEventoMI";
            this.AgregarEventoMI.Size = new System.Drawing.Size(281, 22);
            this.AgregarEventoMI.Text = "AgregarEvento";
            this.AgregarEventoMI.Click += new System.EventHandler(this.menuAgregarEvento_Click);
            // 
            // menuRecalificar
            // 
            this.menuRecalificar.Image = global::PuntoVenta.Properties.Resources.icons8_calendario_más_16;
            this.menuRecalificar.Name = "menuRecalificar";
            this.menuRecalificar.Size = new System.Drawing.Size(166, 22);
            this.menuRecalificar.Text = "ReCalificarEvento";
            this.menuRecalificar.Click += new System.EventHandler(this.menuRecalificar_Click);
            // 
            // DM0312_ExploradorVentas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1395, 675);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.SPID);
            this.Controls.Add(this.pnlfix_delfix);
            this.Controls.Add(this.panelContactos);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_ExploradorVentas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Explorador de Ventas";
            this.Activated += new System.EventHandler(this.DM0312_ExploradorVentas_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_ExploradorVentas_FormClosing);
            this.Load += new System.EventHandler(this.Tablero_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Tablero_Scroll);
            this.LocationChanged += new System.EventHandler(this.DM0312_ExploradorVentas_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_ExploradorVentas_KeyDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DM0312_ExploradorVentas_MouseMove);
            this.Resize += new System.EventHandler(this.DM0312_ExploradorVentas_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.gbx_Detalle.ResumeLayout(false);
            this.flp_detalle.ResumeLayout(false);
            this.flp_detalle.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaDetalle)).EndInit();
            this.gbx_TableroPr.ResumeLayout(false);
            this.gbx_TableroPr.PerformLayout();
            this.panel_MovsPr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TablaMovimientos)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.gbx_Contactos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Contactos)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip4.ResumeLayout(false);
            this.gbx_FotoCliente.ResumeLayout(false);
            this.gbx_FotoCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgBoxCta)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            this.Panel_Menu.ResumeLayout(false);
            this.Panel_TiposVenta.ResumeLayout(false);
            this.Panel_TiposVenta.PerformLayout();
            this.panelContactos.ResumeLayout(false);
            this.panelContactos.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flp_PanelEventos.ResumeLayout(false);
            this.gbx_Eventos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Eventos)).EndInit();
            this.gbx_PanelHuellas.ResumeLayout(false);
            this.gbx_DocumentosAdj.ResumeLayout(false);
            this.panelIdentifiacion.ResumeLayout(false);
            this.panelIdentifiacion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Identificacion)).EndInit();
            this.panelComprobante.ResumeLayout(false);
            this.panelComprobante.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Comprobante)).EndInit();
            this.panelTarjetasDigitales.ResumeLayout(false);
            this.panelTarjetasDigitales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_TarjetasDig)).EndInit();
            this.panelPagares.ResumeLayout(false);
            this.panelPagares.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Pagares)).EndInit();
            this.pnlfix_delfix.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void MostrarFormatoExploradorPVC_Click(object sender, EventArgs e)
        {
            MostrarFormatoExploradorPVC();
        }

        private System.Windows.Forms.CheckBox checkBox1;

        private System.Windows.Forms.ToolStripMenuItem NotificarAnalista;

        private System.Windows.Forms.ToolStripMenuItem AgregarEventoStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;

        #endregion

        private System.Windows.Forms.Button btn_SolicitudCancelacion;
        private System.Windows.Forms.Label lbl_FechaA;
        private System.Windows.Forms.Label lbl_FechaD;
        private System.Windows.Forms.Label lbl_Estatus;
        private System.Windows.Forms.Label lblSituacion;
        private System.Windows.Forms.Label lblMovimiento;
        private System.Windows.Forms.Label lblBuscarEn;
        private System.Windows.Forms.Label lbl_Buscar;
        private System.Windows.Forms.GroupBox gbx_Detalle;
        private System.Windows.Forms.DataGridView dgv_TablaDetalle;
        private System.Windows.Forms.TextBox txt_DetalleAlmacen;
        private System.Windows.Forms.Label lbl_Almacen;
        private System.Windows.Forms.Button btn_DocumentosAdjuntos;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_nuevo;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_TiempoTotal;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_FormatoExploradorPVC;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_MonederoRedimir;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_ActualizacionDatos;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_ClienteExpress;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Excel;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_KardexClienteFinal;
        private System.Windows.Forms.TextBox txt_DetalleReferencia;
        private System.Windows.Forms.TextBox txt_DetalleConcepto;
        private System.Windows.Forms.Label lbl_Concepto;
        private System.Windows.Forms.Label lbl_Referencia;
        private System.Windows.Forms.TextBox txt_DetalleEmbarqueMov;
        private System.Windows.Forms.Label lbl_Embarque;
        private System.Windows.Forms.Button btn_PosicionMov;
        private System.Windows.Forms.Button btn_RegistroHuella;
        private System.Windows.Forms.Button btn_Relaciones;
        private System.Windows.Forms.Button btn_VisorMavi;
        private System.Windows.Forms.Button btn_ResumenFac;
        private System.Windows.Forms.Button btn_HistoricoUniCaja;
        private System.Windows.Forms.Button btn_PreliminarCobro;
        private System.Windows.Forms.Button btn_ConsultaBuro;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox chk_CreditoCasa;
        private System.Windows.Forms.CheckBox chk_CreditoNuevo;
        private System.Windows.Forms.CheckBox chk_ContadoCasa;
        private System.Windows.Forms.CheckBox chk_ContadoNuevo;
        private System.Windows.Forms.DateTimePicker dtp_DeFecha;
        private System.Windows.Forms.DateTimePicker dtp_Afecha;
        private System.Windows.Forms.Button btn_CatalagoCalif;
        private System.Windows.Forms.Button btn_Contactos;
        private System.Windows.Forms.GroupBox gbx_Contactos;
        private System.Windows.Forms.DataGridView dgv_Contactos;
        private System.Windows.Forms.Button btn_ConfColumnas;
        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_InvestigacionTel;
        private System.Windows.Forms.Button btn_ayuda;
        public System.Windows.Forms.ComboBox cbx_estatus;
        public System.Windows.Forms.ComboBox cbx_movimiento;
        public System.Windows.Forms.ComboBox cbx_situacion;
        public System.Windows.Forms.ComboBox cbx_BuscarEn;
        public System.Windows.Forms.TextBox txt_Buscar;
        private System.Windows.Forms.Label lbl_Comentario;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.Button btn_HistoSolicitudes;
        private System.Windows.Forms.Label lbl_CuentaCaja;
        private System.Windows.Forms.Button btn_KardexCliente;
        private System.Windows.Forms.GroupBox gbx_FotoCliente;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Afectar;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem historialDeFotosToolStripMenuItem;
        private System.Windows.Forms.Label lbl_Sucursal;
        public System.Windows.Forms.TextBox txt_Sucursal;
        private System.Windows.Forms.CheckBox chk_VIU;
        private System.Windows.Forms.CheckBox chk_MA;
        private System.Windows.Forms.CheckBox chk_MAVI;
        private System.Windows.Forms.TextBox txt_Condicion;
        private System.Windows.Forms.Label lbl_Condicion;
        private System.Windows.Forms.CheckBox cbx_CreditoCasaMayoreo;
        private System.Windows.Forms.CheckBox cbx_creditoNuevoMayoreo;
        private System.Windows.Forms.FlowLayoutPanel Panel_Menu;
        private System.Windows.Forms.Button btn_Nuevo;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Refrescar;
        private System.Windows.Forms.Button btn_InformacionCliente;
        private System.Windows.Forms.Button btn_Eventos;
        private System.Windows.Forms.Button btn_UsuariosTiempos;
        private System.Windows.Forms.FlowLayoutPanel Panel_TiposVenta;
        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        private System.Windows.Forms.TextBox txt_NombreSucursal;
        public System.Windows.Forms.ComboBox cbx_Impreso;
        private System.Windows.Forms.Label lbl_Impreso;
        private System.Windows.Forms.ContextMenuStrip toolTipRecalificar;
        private System.Windows.Forms.ToolStripMenuItem menuRecalificar;
        private System.Windows.Forms.CheckBox chk_Devolucion;
        private System.Windows.Forms.FlowLayoutPanel gbx_DocumentosAdj;
        private System.Windows.Forms.Label lbl_Comprobante;
        private System.Windows.Forms.Label lbl_TarjetasDig;
        private System.Windows.Forms.Label lbl__Pagares;
        private System.Windows.Forms.PictureBox pb_Pagares;
        private System.Windows.Forms.PictureBox pb_TarjetasDig;
        private System.Windows.Forms.PictureBox pb_Comprobante;
        private System.Windows.Forms.Panel panelIdentifiacion;
        private System.Windows.Forms.PictureBox pb_Identificacion;
        private System.Windows.Forms.Label lbl_Identificacion;
        private System.Windows.Forms.Panel panelComprobante;
        private System.Windows.Forms.Panel panelTarjetasDigitales;
        private System.Windows.Forms.Panel panelPagares;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.Button BtnProspectoaCliente;
        private System.Windows.Forms.ToolStripMenuItem copiarClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Relacionado;
        private System.Windows.Forms.ToolStripMenuItem agregarActualizacionDeDatosCrtlJToolStripMenuItem;
        private System.Windows.Forms.TextBox txt_DetalleEmbarqueFecha;
        private System.Windows.Forms.Button btnValida;
        private System.Windows.Forms.CheckBox chk_Valido;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.TextBox txtIdentificacion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox imgBoxCta;
        private System.Windows.Forms.GroupBox gbx_PanelHuellas;
        private System.Windows.Forms.GroupBox gbx_TableroPr;
        private System.Windows.Forms.FlowLayoutPanel panel_MovsPr;
        public System.Windows.Forms.DataGridView dgv_TablaMovimientos;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label lbl_CreditoCasaNum;
        private System.Windows.Forms.TextBox txt_CreditoCasaNum;
        private System.Windows.Forms.Label lbl_CreditoNuevoNum;
        private System.Windows.Forms.TextBox txt_CreditoNuevoNum;
        private System.Windows.Forms.Label lbl_ContadoNuevoNum;
        private System.Windows.Forms.TextBox txt_ContadoNuevoNum;
        private System.Windows.Forms.Label lbl_ContadoCasaNum;
        private System.Windows.Forms.TextBox txt_ContadoCasaNum;
        private System.Windows.Forms.Label lbl_CreditoCasaMayNum;
        private System.Windows.Forms.TextBox txt_CreditoCasaMayNum;
        private System.Windows.Forms.Label lbl_CreditoNuevoMayNum;
        private System.Windows.Forms.TextBox txt_CreditoNuevoMayNum;
        private System.Windows.Forms.FlowLayoutPanel flp_detalle;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Panel pnlfix_delfix;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Label SPID;
        private System.Windows.Forms.ToolStripMenuItem consultarBuroToolStripMenuItem;
        public System.Windows.Forms.TextBox cbx_fechaD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_Selp;
        private System.Windows.Forms.FlowLayoutPanel flp_PanelEventos;
        private System.Windows.Forms.GroupBox gbx_Eventos;
        public System.Windows.Forms.DataGridView dgv_Eventos;
        private System.Windows.Forms.Button btn_CalidadCap;
        private System.Windows.Forms.Button btn_AnalistasCredi;
        private System.Windows.Forms.ToolStripMenuItem capturaDeRelacionadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matrizDeAutorizacionToolStripMenuItem;
        private System.Windows.Forms.Label lbl_Descripcion;
        private System.Windows.Forms.TextBox tb_descripcion;
        private System.Windows.Forms.ToolStripMenuItem camposExtrasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem envioCorreoWebCrtlF9ToolStripMenuItem;
        private System.Windows.Forms.Button BTN_consultaCf;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox cbx_fechaA;
        private System.Windows.Forms.Label lbl_TipoCredito;
        private System.Windows.Forms.CheckedListBox listTipoCredito;
        private System.Windows.Forms.ToolStripMenuItem menuScoring;
        private System.Windows.Forms.Button btn_SoporAval;
        private System.Windows.Forms.Button btn_storepickupOrders; //-PrimeraFaseDeAutomatizacion
        private System.Windows.Forms.ToolStripMenuItem editarVentaCrtlF7ToolStripMenuItem;
        private System.Windows.Forms.Button btnKardex;
        private System.Windows.Forms.Button btnDineralia;
        private System.Windows.Forms.Button btnScoring;
        private System.Windows.Forms.ToolStripMenuItem reanalisisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuOrdenCompra;
        private System.Windows.Forms.ToolStripMenuItem AgregarEventoMI;
        private System.Windows.Forms.CheckBox chk_ClienteEnSucursal;
        private System.Windows.Forms.Button btnPosicionDelMovimiento;
        private System.Windows.Forms.ToolStripMenuItem ttCuentaClabe;


    }
}

