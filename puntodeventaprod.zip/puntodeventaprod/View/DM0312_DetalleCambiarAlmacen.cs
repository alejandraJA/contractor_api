﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleCambiarAlmacen : Form
    {
        public static int IDVenta;
        public static string AlmacenActual;
        public static int SucursalDestino;
        public static string AlmacenAntes;
        public static string commerce;
        private List<MAlmacen> AlmacenesDisponibles = new List<MAlmacen>();
        private List<MAlmacen> AlmacenesFiltrados;
        private readonly CAlmacenes ControladorAlmacenes = new CAlmacenes();
        private CDetalleVenta ControladorD = new CDetalleVenta();
        private readonly Funciones funciones = new Funciones();
        public int PaginadoActual = 0;

        //Flag que indica que el evento selection change puede ejecutarse
        private bool SeleccionPuedeCambiar;
        public List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public DM0312_DetalleCambiarAlmacen()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
        }

        ~DM0312_DetalleCambiarAlmacen()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Close form
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void Btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///     Load de almacenes
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void DM0312_CambiarAlmacenDetalle_Load(object sender, EventArgs e)
        {
            dgv_almacenes.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 12f, FontStyle.Bold);
            dgv_almacenes.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            AlmacenesDisponibles = ControladorAlmacenes.ObtenerAlmacenes();

            SeleccionPuedeCambiar = false;
            dgv_almacenes.DataSource = null;
            dgv_almacenes.DataSource = AlmacenesDisponibles;
            SeleccionPuedeCambiar = true;

            string NombreAlmacenActual = AlmacenesDisponibles.SingleOrDefault(x => x.Clave == AlmacenActual).Nombre;
            lbl_almacenAnterior.Text = "Almacen anterior: " + AlmacenActual + " - " + NombreAlmacenActual;

            if (dgv_almacenes.SelectedRows.Count > 0)
            {
                AlmacenActual = dgv_almacenes
                    .Rows[dgv_almacenes.SelectedRows[dgv_almacenes.SelectedRows.Count - 1].Index].Cells[0].Value
                    .ToString();
                SucursalDestino = Convert.ToInt32(dgv_almacenes
                    .Rows[dgv_almacenes.SelectedRows[dgv_almacenes.SelectedRows.Count - 1].Index].Cells[2].Value
                    .ToString());
                lbl_NuevoAlmacen.Text = "Nuevo almacen: " + AlmacenActual;
            }

            toolTip1.SetToolTip(lbl_almacenAnterior, "MUESTRA EL ALMACEN QUE SE TENIA ANTERIORMENTE");
            toolTip1.SetToolTip(lbl_NuevoAlmacen, "MUESTRA EL ALMACEN QUE SE DESEA CAMBIAR");
            toolTip1.SetToolTip(lbl_almacen, "CLAVE DE ALMACEN");
            toolTip1.SetToolTip(txt_busqueda,
                "INGRESA LA CLAVE DEL ALMACEN A BUSCAR, DAR ENTER PARA ACTUALIZAR LA BUSQUEDA");
            toolTip1.SetToolTip(btn_CambiarAlmacen, "SELECCIONAR PARA HACER EL CAMBIO DE ALMACEN");
            toolTip1.SetToolTip(btn_Regresar, "CANCELAR EL CAMBIO DE ALMACEN Y REGRESAR A LA FORMA ANTERIOR");
            txt_Comentarios.Text =
                "ASISTENTE DE ALMACENES EN EL CUAL SE PODRA CAMBIAR EL ALMACEN ASIGNADO A LA VENTA, UNA VEZ SELECCIONADO EL NUEVO ALMACEN DAR CLICK AL BOTON CAMBIAR ALMACEN";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_almacenes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        /// <summary>
        ///     Cambia el almacen actual
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void Btn_CambiarAlmacen_Click(object sender, EventArgs e)
        {
            if (AlmacenActual == string.Empty)
            {
                MessageBox.Show("Selecciona un almacen", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            int result = ControladorAlmacenes.ActualizarAlmacen(VentasSeleccionadas[PaginadoActual].Estatus);
            if (result == 0)
                if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90 ||
                    ClaseEstatica.Usuario.sucursal == 504 || ClaseEstatica.Usuario.sucursal == 505)
                    if (AlmacenAntes == "V00041" || AlmacenAntes == "V00090" || AlmacenAntes == "V00504" ||
                        AlmacenAntes == "V00505")
                        if (AlmacenActual != "V00096")
                        {
                            //ControladorD.CambiarSuc(commerce);
                        }

            if (result == 1)
            {
                MessageBox.Show("Tiene articulos reservados y/o ordenados, no se puede cambiar el almacen",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (result == 2)
            {
                MessageBox.Show("Los almacenes deben de ser del mismo tipo", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                VentasSeleccionadas[PaginadoActual].SucursalDestino = SucursalDestino;
                VentasSeleccionadas[PaginadoActual].Almacen = AlmacenActual;
                Close();
            }
        }

        /// <summary>
        ///     Evento cuando se selecciona un almacen nuevo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void Dgv_almacenes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv_almacenes.SelectedRows.Count > 0)
            {
                AlmacenActual = dgv_almacenes
                    .Rows[dgv_almacenes.SelectedRows[dgv_almacenes.SelectedRows.Count - 1].Index].Cells[0].Value
                    .ToString();
                SucursalDestino = Convert.ToInt32(dgv_almacenes
                    .Rows[dgv_almacenes.SelectedRows[dgv_almacenes.SelectedRows.Count - 1].Index].Cells[2].Value
                    .ToString());
                lbl_NuevoAlmacen.Text = "Nuevo almacen: " + AlmacenActual;
            }
            else
            {
                AlmacenActual = "";
                lbl_NuevoAlmacen.Text = "Nuevo almacen: ";
            }
        }

        /// <summary>
        ///     Cambia almacen en selecion changed
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 25/09/17
        private void Dgv_almacenes_SelectionChanged(object sender, EventArgs e)
        {
            if (SeleccionPuedeCambiar) Dgv_almacenes_CellContentClick(null, null);
        }

        /// <summary>
        ///     Busqueda de almacenes
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void Txt_almacenSeleccionado_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txt_busqueda.Text == string.Empty)
                {
                    dgv_almacenes.DataSource = null;
                    dgv_almacenes.DataSource = AlmacenesDisponibles;
                }
                else
                {
                    string AlmacenFiltrado = txt_busqueda.Text;
                    AlmacenesFiltrados = AlmacenesDisponibles.Where(x => x.Nombre.Contains(AlmacenFiltrado.ToUpper())
                                                                         ||
                                                                         x.Clave.Contains(AlmacenFiltrado.ToUpper()))
                        .ToList();
                    dgv_almacenes.DataSource = null;
                    dgv_almacenes.DataSource = AlmacenesFiltrados;
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_almacenes_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (txt_busqueda.Text == string.Empty)
            {
                List<object> TempObjects = new List<object>(AlmacenesDisponibles);
                funciones.OrderGridview(dgv_almacenes, e.ColumnIndex, TempObjects,
                    AlmacenesDisponibles.GetType().GetGenericArguments().Single());
            }
            else
            {
                List<object> TempObjects = new List<object>(AlmacenesFiltrados);
                funciones.OrderGridview(dgv_almacenes, e.ColumnIndex, TempObjects,
                    AlmacenesFiltrados.GetType().GetGenericArguments().Single());
            }
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleCambiarAlmacen_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        /// <summary>
        ///     double click de gridview
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 25/10/17
        private void dgv_almacenes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1) Btn_CambiarAlmacen_Click(null, null);
        }
    }
}