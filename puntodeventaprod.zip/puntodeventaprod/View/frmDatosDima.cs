﻿using System;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class frmDatosDima : Form
    {
        public frmDatosDima(string sNombre, string sDireccion)
        {
            InitializeComponent();
            txtNombre.Text = sNombre;
            txtDireccion.Text = sDireccion;
        }

        ~frmDatosDima()
        {
            GC.Collect();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}