﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class InformacionCliente : Form
    {
        private DateTime FechaADocCobrar;
        private DateTime FechaAHPago;
        private DateTime FechaAVPendientes;
        private DateTime FechaDeDocCobrar;

        private DateTime FechaDeHPago;

        private DateTime FechaDeVPendientes;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private DM0312_C_InformacionClientes infCliente;
        private List<string> ListaControles = new List<string>();
        public string mensaje;
        public string recibeMensaje;
        private bool ShowMessage;
        private string validaMensaje;

        public InformacionCliente()
        {
            InitializeComponent();
            MouseWheel += Wheel;
        }

        ~InformacionCliente()
        {
            GC.Collect();
        }

        private void InformacionCliente_Load(object sender, EventArgs e)
        {
            txt_Comentarios.Text =
                "INFORMACION COMPLETA DEL CLIENTE ASI COMO SUS DOCUMENTOS TANTO PENDIENTES COMO CONCLUIDOS";
            validaMensaje = recibeMensaje;
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            DatosCliente();

            DateTime thisDay = DateTime.Today;
            cbx_FechaCobrarDe.Text = thisDay.AddYears(-1).ToString("d");
            cbx_FechaCobrarA.Text = thisDay.ToString("d");
            txt_VentaPendienteFechaDe.Text = thisDay.AddYears(-1).ToString("d");
            txt_VentaPendienteFechaA.Text = thisDay.ToString("d");
            txt_HabitosPagoFechaDe.Text = thisDay.AddYears(-1).ToString("d");
            txt_HabitosPagoFechaA.Text = thisDay.ToString("d");
            ShowMessage = true;
            gbx_DatosVentasPendientes.Visible = false;
            gbx_DatosHabitosPago.Visible = false;
            gbx_DatosPorCobrar.Visible = false;

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_PorCobrar.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_VentasPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_HabitosPago.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_PorCobrar.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_VentasPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_HabitosPago.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_PorCobrar.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_VentasPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_HabitosPago.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_PorCobrar.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_VentasPendientes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_HabitosPago.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }

        private void DatosCliente()
        {
            infCliente = new DM0312_C_InformacionClientes();
            try
            {
                List<string> cliente = new List<string>();
                string recibemensaje = "";
                recibemensaje = mensaje;

                cliente = infCliente.InfoCliente(recibemensaje);

                lbl_Cliente.Text = cliente[0];
                txt_Nombre.Text = cliente[1];
                txt_rfc.Text = cliente[2];
                txt_Direccion.Text = cliente[3];
                txt_Estado.Text = cliente[4];
                txt_Cp.Text = cliente[5];
                txt_Colonia.Text = cliente[6];
                txt_Municipio.Text = cliente[7];
                txt_EntreCalle.Text = cliente[8];
                txt_Correo.Text = cliente[9];
                txt_TelParticular.Text = cliente[10];
                txt_TelMovil.Text = cliente[11];
                txt_Otros.Text = cliente[12];
                txt_CuentaUnicaja.Text = cliente[13];
                txt_ForamaPago.Text = cliente[14];

                #region //-BeneficiariosFinales

                if (!infCliente.TieneBeneficiario(cliente[0]))
                    btnActualizarBeneficiario.Visible = false;

                if (!infCliente.TieneAval(cliente[0]))
                    btnActualizarAval.Visible = false;

                #endregion
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("DatosCliente", "DM0312_InformacionCliente", e);
                MessageBox.Show(e.Message);
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_Datos_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_DatosCobrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (gbx_DatosPorCobrar.Visible)
                {
                    gbx_DatosPorCobrar.Visible = false;
                    btn_DatosCobrar.Focus();
                }
                else
                {
                    DatosCobrarCliente();
                    btn_VentasPendientes.Focus();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosCobrar", "DM0312_InformacionCliente", ex);
                MessageBox.Show(ex.Message);
            }
        }


        private void btn_VentasPendientes_Click(object sender, EventArgs e)
        {
            if (gbx_DatosVentasPendientes.Visible)
            {
                gbx_DatosVentasPendientes.Visible = false;
                btn_VentasPendientes.Focus();
            }
            else
            {
                ObtenerVentasPendientes();
                btn_HabitosPago.Focus();
            }
        }


        private void btn_HabitosPago_Click(object sender, EventArgs e)
        {
            if (gbx_DatosHabitosPago.Visible)
            {
                gbx_DatosHabitosPago.Visible = false;
                btn_DatosCobrar.Focus();
            }
            else
            {
                gbx_DatosHabitosPago.Visible = true;
                DatosHabitosPago();
                dgv_HabitosPago.Focus();
            }
        }

        private async void btn_ImgenesCliente_Click(object sender, EventArgs e)
        {
            try
            {
                List<DM0312_MAnexoCta> lista = new List<DM0312_MAnexoCta>();

                DM0312_CAnexoCta controller = new DM0312_CAnexoCta();

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                }


                lista = await Task.Run(() =>
                    controller.GetFotos(lbl_Cliente.Text).OrderByDescending(x => x.FechaAlta).ToList());


                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    DesabilitarControles(true);
                }


                if (lista.Count == 0)
                {
                    MessageBox.Show("El cliente:" + lbl_Cliente.Text + " no tiene imagenes", "Aviso!",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                List<Image> ListaImagenes = new List<Image>();

                foreach (DM0312_MAnexoCta i in lista) ListaImagenes.Add(PictureBox(i.Imagen));
                ClaseEstatica.FormActivo = "InformacionCliente";
                DM0312_ExploradorVentaDoctsAdj frm = new DM0312_ExploradorVentaDoctsAdj();
                frm.ListaImagenes = ListaImagenes;
                frm.Text = " " + lbl_Cliente.Text + " " + txt_Nombre.Text;
                frm.ShowDialog();
                ClaseEstatica.FormActivo = string.Empty;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ImagenesCliente", "DM0312_InformacionCliente", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public Image PictureBox(byte[] imagen)
        {
            Image imagen_ = null;

            MemoryStream ms = new MemoryStream(imagen);
            imagen_ = Image.FromStream(ms);

            return imagen_;
        }

        private void InformacionCliente_Scroll(object sender, ScrollEventArgs e)
        {
            Panel_Menu.Location = new Point(1, 11);
            lbl_Cliente.Location = new Point(888, 25);
        }

        public void DatosCobrarCliente()
        {
            try
            {
                DataTable dataSet = new DataTable();
                if (cbx_FechaCobrarDe.Text != string.Empty && cbx_FechaCobrarA.Text != string.Empty)
                {
                    DateTime FechaDe = Convert.ToDateTime(cbx_FechaCobrarDe.Text);
                    DateTime FechaA = Convert.ToDateTime(cbx_FechaCobrarA.Text);
                    if (FechaDe <= FechaA)
                    {
                        FechaDeDocCobrar = Convert.ToDateTime(cbx_FechaCobrarDe.Text);
                        FechaADocCobrar = Convert.ToDateTime(cbx_FechaCobrarA.Text);

                        dataSet = infCliente.DatosXcobrar(lbl_Cliente.Text, FechaDe, FechaA);

                        double total = 0;

                        foreach (DataRow Data in dataSet.Rows)
                            if (Data["Saldo"] != null && Data["Saldo"].ToString() != "")
                            {
                                total = total + Convert.ToDouble(Data["Saldo"]);
                                Data["Saldo"] = "$" + Convert.ToDouble(Data["Saldo"]).ToString("0.00");
                            }
                            else
                            {
                                Data["Saldo"] = "$" + "0.00";
                            }

                        lbl_TotalCobrar.Text =
                            Convert.ToDouble(total).ToString("C", Thread.CurrentThread.CurrentCulture);
                        dgv_PorCobrar.DataSource = null;
                        dgv_PorCobrar.DataSource = dataSet;
                        AjustarTamañodgvGbx(dgv_PorCobrar, gbx_DatosPorCobrar, btn_DatosCobrar);
                    }
                    else
                    {
                        cbx_FechaCobrarDe.Text = FechaDeDocCobrar.ToShortDateString();
                        cbx_FechaCobrarA.Text = FechaADocCobrar.ToShortDateString();
                        MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final", "Informacion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosCobrarCliente", "DM0312_InformacionCliente", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void DatosHabitosPago()
        {
            try
            {
                DataTable dataSet = new DataTable();
                if (txt_HabitosPagoFechaDe.Text != string.Empty && txt_HabitosPagoFechaA.Text != string.Empty)
                {
                    DateTime FechaDe = Convert.ToDateTime(txt_HabitosPagoFechaDe.Text);
                    DateTime FechaA = Convert.ToDateTime(txt_HabitosPagoFechaA.Text);
                    if (FechaDe <= FechaA)
                    {
                        FechaDeVPendientes = Convert.ToDateTime(txt_HabitosPagoFechaDe.Text);
                        FechaAVPendientes = Convert.ToDateTime(txt_HabitosPagoFechaA.Text);
                        dataSet = infCliente.HabitoPago(lbl_Cliente.Text, txt_BuscarHabitos.Text, FechaDe, FechaA);
                        double total = 0;
                        int totalDia = 0;

                        foreach (DataRow Data in dataSet.Rows)
                            if (Data["ImporteTotal"] != null && Data["ImporteTotal"].ToString() != "")
                            {
                                total = total + Convert.ToDouble(Data["ImporteTotal"]);
                                totalDia = totalDia + Convert.ToInt32(Data["DiasRetraso"]);
                                Data["ImporteTotal"] = "$" + Convert.ToDouble(Data["ImporteTotal"]).ToString("0.00");
                            }
                            else
                            {
                                Data["ImporteTotal"] = "$" + "0.00";
                            }

                        lbl_Tot.Text = Convert.ToDouble(total).ToString("C", Thread.CurrentThread.CurrentCulture);
                        lbl_TotalDiasR.Text = totalDia.ToString();

                        dgv_HabitosPago.DataSource = null;
                        dgv_HabitosPago.DataSource = dataSet;
                        dgv_HabitosPago.Columns["ImporteTotal"].HeaderText = "Importe Total";
                        dgv_HabitosPago.Columns["DiasRetraso"].HeaderText = "Dias de Retraso";
                        dgv_HabitosPago.Columns["FechaConclusion"].HeaderText = "Fecha Conclusion";
                        AjustarTamañodgvGbx(dgv_HabitosPago, gbx_DatosHabitosPago, btn_HabitosPago);
                        gbx_DatosHabitosPago.Height = gbx_DatosHabitosPago.Height + 20;
                    }
                    else
                    {
                        txt_HabitosPagoFechaDe.Text = FechaDeVPendientes.ToShortDateString();
                        txt_HabitosPagoFechaA.Text = FechaAVPendientes.ToShortDateString();
                        MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final", "Informacion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosHabitosPago", "DM0312_InformacionCliente", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void Wheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
                label11.Focus();
            else
                btn_HabitosPago.Focus();
            Panel_Menu.Location = new Point(1, 11);
        }

        private void txt_BuscarHabitos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) DatosHabitosPago();
        }

        private void cbx_FechaCobrarA_ValueChanged(object sender, EventArgs e)
        {
            DatosCobrarCliente();
        }

        private void cbx_FechaCobrarA_TabIndexChanged(object sender, EventArgs e)
        {
        }

        /// <summary>
        ///     Codigo que se repetia por todos lados :V
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void AjustarTamañodgvGbx(DataGridView dgv, GroupBox gbox, Button btnToFocus)
        {
            if (dgv.Rows.Count > 0)
            {
                gbox.Visible = true;
                btnToFocus.Focus();
                dgv.Visible = true;
            }
            else
            {
                dgv.Visible = false;
                if (ShowMessage)
                    MessageBox.Show("No hay registros", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            int height = 40;
            foreach (DataGridViewRow item in dgv.Rows)
                if (height < 195)
                    height += item.Height;
            dgv.Height = height;
            gbox.Height = height + 100;
        }

        /// <summary>
        ///     Obtiene las ventas pendientes
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void ObtenerVentasPendientes()
        {
            try
            {
                DataTable list = new DataTable();
                if (cbx_FechaCobrarDe.Text != string.Empty && cbx_FechaCobrarA.Text != string.Empty)
                {
                    DateTime FechaDe = Convert.ToDateTime(txt_VentaPendienteFechaDe.Text);
                    DateTime FechaA = Convert.ToDateTime(txt_VentaPendienteFechaA.Text);
                    if (FechaDe <= FechaA)
                    {
                        FechaDeHPago = Convert.ToDateTime(txt_VentaPendienteFechaDe.Text);
                        FechaAHPago = Convert.ToDateTime(txt_VentaPendienteFechaA.Text);
                        list = infCliente.VentasPendientes(lbl_Cliente.Text, FechaDe, FechaA);
                        double total = 0;

                        foreach (DataRow Data in list.Rows)
                            if (Data["Saldo"] != null && Data["Saldo"].ToString() != "")
                            {
                                total = total + Convert.ToDouble(Data["Saldo"]);
                                Data["Saldo"] = "$" + Convert.ToDouble(Data["Saldo"]).ToString("0.00");
                            }
                            else
                            {
                                Data["Saldo"] = "$" + "0.00";
                            }

                        lbl_Total.Text = Convert.ToDouble(total).ToString("C", Thread.CurrentThread.CurrentCulture);
                        dgv_VentasPendientes.DataSource = list;
                        dgv_VentasPendientes.Columns["FechaEmision"].HeaderText = "Fecha Emision";
                        dgv_VentasPendientes.Columns["FechaRequerida"].HeaderText = "Fecha Requerida";
                        AjustarTamañodgvGbx(dgv_VentasPendientes, gbx_DatosVentasPendientes, btn_HabitosPago);
                    }
                    else
                    {
                        txt_VentaPendienteFechaDe.Text = FechaDeHPago.ToShortDateString();
                        txt_VentaPendienteFechaA.Text = FechaAHPago.ToShortDateString();
                        MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final", "Informacion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VentasPendientes", "DM0312_InformacionCliente", ex);
                MessageBox.Show(ex.Message);
            }
        }


        private void DesabilitarControles(bool estado)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in Controls)
                    if (!item.Enabled)
                        ListaControles.Add(item.Name);
                    else
                        item.Enabled = estado;
            }
            else
            {
                foreach (Control item in Controls)
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
            }
        }

        private void InformacionCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dispose();
        }

        /// <summary>
        ///     Value changed de fecha inicio
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void cbx_FechaCobrarDe_CloseUp(object sender, EventArgs e)
        {
            DatosCobrarCliente();
        }

        /// <summary>
        ///     Value changed de fecha final
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void cbx_FechaCobrarA_CloseUp(object sender, EventArgs e)
        {
            DatosCobrarCliente();
        }

        /// <summary>
        ///     Value changed de fecha inicio
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void txt_VentaPendienteFechaDe_CloseUp(object sender, EventArgs e)
        {
            ObtenerVentasPendientes();
        }

        /// <summary>
        ///     Value changed de fecha final
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void txt_VentaPendienteFechaA_CloseUp(object sender, EventArgs e)
        {
            ObtenerVentasPendientes();
        }

        /// <summary>
        ///     Value changed de fecha inicio
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void txt_HabitosPagoFechaDe_CloseUp(object sender, EventArgs e)
        {
            DatosHabitosPago();
        }

        /// <summary>
        ///     Value changed de fecha final
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void txt_HabitosPagoFechaA_CloseUp(object sender, EventArgs e)
        {
            DatosHabitosPago();
        }

        private void InformacionCliente_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        private void InformacionCliente_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        private void txt_BuscarHabitos_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        #region //-BeneficiariosFinales

        private void btnActualizarCliente_Click(object sender, EventArgs e)
        {
            EjecutarPlugin("CLIENTE");
        }

        private void btnActualizarBeneficiario_Click(object sender, EventArgs e)
        {
            EjecutarPlugin("BENEFICIARIO");
        }

        private void btnActualizarAval_Click(object sender, EventArgs e)
        {
            EjecutarPlugin("AVAL");
        }

        private void EjecutarPlugin(string opcion)
        {
            try
            {
                Process pClientes = new Process();
                pClientes.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pClientes.StartInfo.FileName =
                    ClaseEstatica.plugInPath + @"ActualizacionDatosCliente\ActualizacionDatosCFA.exe";
                pClientes.StartInfo.Verb = "runas";
                pClientes.StartInfo.Arguments =
                    $"{ClaseEstatica.Usuario.Usser} {ClaseEstatica.Usuario.sucursal} {lbl_Cliente.Text} {opcion}";
                pClientes.StartInfo.UseShellExecute = false;
                pClientes.Start();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
    }
}