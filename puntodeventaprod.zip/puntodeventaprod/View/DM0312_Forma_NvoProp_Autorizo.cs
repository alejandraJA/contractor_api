﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_Forma_NvoProp_Autorizo : Form
    {
        public bool cancel_;
        private readonly DM0312_C_UsuarioDescuentoIncremento controller;

        public List<object> List;

        public List<object> ListFil;

        private string metodo;

        public bool Origen;
        public string pwd;

        public string user;

        public DM0312_Forma_NvoProp_Autorizo()
        {
            InitializeComponent();

            controller = new DM0312_C_UsuarioDescuentoIncremento();

            metodo = string.Empty;
        }

        ~DM0312_Forma_NvoProp_Autorizo()
        {
            GC.Collect();
        }

        private void DM0312_Forma_NvoProp_Autorizo_Load(object sender, EventArgs e)
        {
            //Origen = true;
            if (!Origen) dtgv_Usuarios.Width = 465;

            llenarGrid("");

            if (ClaseEstatica.Usuario.color == "Azul")
                dtgv_Usuarios.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dtgv_Usuarios.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dtgv_Usuarios.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dtgv_Usuarios.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }


        #region Metodos

        private void llenarGrid(string name)
        {
            List = new List<object>();

            ListFil = new List<object>();

            List = controller.UsuarioList(Origen);

            if (name == string.Empty)
            {
                dtgv_Usuarios.DataSource = null;
                dtgv_Usuarios.DataSource = List.ToList();
            }
            else
            {
                foreach (object obj in List)
                {
                    string rest = string.Empty;
                    PropertyInfo Reflection_;
                    Reflection_ = obj.GetType().GetProperty("nombre");
                    rest = (string)Reflection_.GetValue(obj, null);

                    if (rest.Contains(name)) ListFil.Add(obj);
                }

                List = new List<object>();
                List = ListFil;

                dtgv_Usuarios.DataSource = null;
                dtgv_Usuarios.DataSource = List.ToList();
            }

            if (dtgv_Usuarios.Rows.Count == 0)
                return;

            if (Origen)
            {
                dtgv_Usuarios.Columns[3].Visible = false;
            }
            else
            {
                dtgv_Usuarios.Columns[2].Visible = false;
                dtgv_Usuarios.Columns[3].Visible = false;
            }

            dtgv_Usuarios.Columns[0].HeaderText = "Usuario";
            dtgv_Usuarios.Columns[1].HeaderText = "Nombre";
            dtgv_Usuarios.Columns[2].HeaderText = "Grupo de Trabajo";
        }

        #endregion

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == (char)Keys.Enter)
                llenarGrid(txtName.Text);
        }

        private void dtgv_Usuarios_DoubleClick(object sender, EventArgs e)
        {
            object obj = dtgv_Usuarios.CurrentRow.DataBoundItem;

            string rest = string.Empty;
            PropertyInfo Reflection_;

            //Usuario
            Reflection_ = obj.GetType().GetProperty("usuario");
            user = (string)Reflection_.GetValue(obj, null);

            //Contrasena
            Reflection_ = obj.GetType().GetProperty("pwd");
            pwd = (string)Reflection_.GetValue(obj, null);

            metodo = "double click";

            Close();
        }

        private void DM0312_Forma_NvoProp_Autorizo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (metodo == string.Empty)
                cancel_ = true;
        }

        private void dtgv_Usuarios_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            OrderGrid(e.ColumnIndex);
        }

        private void OrderGrid(int columnIndex)
        {
            List<object> result = new List<object>();
            Funciones funciones = new Funciones();

            if (dtgv_Usuarios.Rows.Count > 0)
            {
                string strColumnName = dtgv_Usuarios.Columns[columnIndex].Name;
                SortOrder SystemSortOrder = funciones.getSortOrder(dtgv_Usuarios, columnIndex);

                result = OrdenarList(strColumnName, SystemSortOrder, List);

                dtgv_Usuarios.DataSource = null;
                dtgv_Usuarios.DataSource = result;
                dtgv_Usuarios.Columns[columnIndex].HeaderCell.SortGlyphDirection = SystemSortOrder;


                if (dtgv_Usuarios.Rows.Count == 0)
                    return;

                if (Origen)
                {
                    dtgv_Usuarios.Columns[3].Visible = false;
                }
                else
                {
                    dtgv_Usuarios.Columns[2].Visible = false;
                    dtgv_Usuarios.Columns[3].Visible = false;
                }

                dtgv_Usuarios.Columns[0].HeaderText = "Usuario";
                dtgv_Usuarios.Columns[1].HeaderText = "Nombre";
                dtgv_Usuarios.Columns[2].HeaderText = "Grupo de Trabajo";
            }
        }

        public List<object> OrdenarList(string orderName, SortOrder SortOrder, List<object> lista)
        {
            if (SortOrder == SortOrder.Ascending)
                lista = lista.OrderBy(x => x.GetType().GetProperty(orderName).GetValue(x)).ToList();
            else
                lista = lista.OrderByDescending(x => x.GetType().GetProperty(orderName).GetValue(x)).ToList();

            return lista;
        }
    }
}