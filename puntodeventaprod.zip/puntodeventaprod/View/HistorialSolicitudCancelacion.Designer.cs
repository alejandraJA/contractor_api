using System.ComponentModel;

namespace PuntoVenta.View {
    partial class HistorialSolicitudCancelacion {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HistorialSolicitudCancelacion));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_RechazarSolicitud = new System.Windows.Forms.Button();
            this.btn_CancelarMovimiento = new System.Windows.Forms.Button();
            this.btn_CancelarTodo = new System.Windows.Forms.Button();
            this.dgv_ListaMovimientos = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.sb_footerBar = new System.Windows.Forms.StatusBar();
            this.sbp_EstatusPrograma = new System.Windows.Forms.StatusBarPanel();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ListaMovimientos)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel1.Controls.Add(this.btn_RechazarSolicitud);
            this.flowLayoutPanel1.Controls.Add(this.btn_CancelarMovimiento);
            this.flowLayoutPanel1.Controls.Add(this.btn_CancelarTodo);
            this.flowLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(84, 417);
            this.flowLayoutPanel1.TabIndex = 14;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = global::PuntoVenta.Properties.Resources.icons8_volver_30;
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(79, 73);
            this.btn_Regresar.TabIndex = 10;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_RechazarSolicitud
            // 
            this.btn_RechazarSolicitud.BackColor = System.Drawing.Color.White;
            this.btn_RechazarSolicitud.FlatAppearance.BorderSize = 0;
            this.btn_RechazarSolicitud.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_RechazarSolicitud.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RechazarSolicitud.Image = global::PuntoVenta.Properties.Resources.icons8_cancelar_suscripción_30;
            this.btn_RechazarSolicitud.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_RechazarSolicitud.Location = new System.Drawing.Point(3, 82);
            this.btn_RechazarSolicitud.Name = "btn_RechazarSolicitud";
            this.btn_RechazarSolicitud.Size = new System.Drawing.Size(79, 86);
            this.btn_RechazarSolicitud.TabIndex = 11;
            this.btn_RechazarSolicitud.Text = "Rechazar Solicitud (CTRL+R)";
            this.btn_RechazarSolicitud.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_RechazarSolicitud.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_RechazarSolicitud.UseVisualStyleBackColor = false;
            this.btn_RechazarSolicitud.Click += new System.EventHandler(this.btn_RechazarSolicitud_Click);
            // 
            // btn_CancelarMovimiento
            // 
            this.btn_CancelarMovimiento.BackColor = System.Drawing.Color.White;
            this.btn_CancelarMovimiento.FlatAppearance.BorderSize = 0;
            this.btn_CancelarMovimiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CancelarMovimiento.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarMovimiento.Image = global::PuntoVenta.Properties.Resources.icons8_cross_mark_30;
            this.btn_CancelarMovimiento.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CancelarMovimiento.Location = new System.Drawing.Point(3, 174);
            this.btn_CancelarMovimiento.Name = "btn_CancelarMovimiento";
            this.btn_CancelarMovimiento.Size = new System.Drawing.Size(79, 83);
            this.btn_CancelarMovimiento.TabIndex = 12;
            this.btn_CancelarMovimiento.Text = "Cancelar Movimiento (F2)";
            this.btn_CancelarMovimiento.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CancelarMovimiento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CancelarMovimiento.UseVisualStyleBackColor = false;
            this.btn_CancelarMovimiento.Click += new System.EventHandler(this.btn_CancelarMovimiento_Click);
            // 
            // btn_CancelarTodo
            // 
            this.btn_CancelarTodo.BackColor = System.Drawing.Color.White;
            this.btn_CancelarTodo.FlatAppearance.BorderSize = 0;
            this.btn_CancelarTodo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CancelarTodo.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarTodo.Image = global::PuntoVenta.Properties.Resources.icons8_cancelar_30;
            this.btn_CancelarTodo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CancelarTodo.Location = new System.Drawing.Point(3, 263);
            this.btn_CancelarTodo.Name = "btn_CancelarTodo";
            this.btn_CancelarTodo.Size = new System.Drawing.Size(79, 87);
            this.btn_CancelarTodo.TabIndex = 13;
            this.btn_CancelarTodo.Text = "Cancelar Todo (CTRL+F2)";
            this.btn_CancelarTodo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CancelarTodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CancelarTodo.UseVisualStyleBackColor = false;
            this.btn_CancelarTodo.Click += new System.EventHandler(this.btn_CancelarTodo_Click);
            // 
            // dgv_ListaMovimientos
            // 
            this.dgv_ListaMovimientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ListaMovimientos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_ListaMovimientos.Location = new System.Drawing.Point(93, 3);
            this.dgv_ListaMovimientos.Name = "dgv_ListaMovimientos";
            this.dgv_ListaMovimientos.ReadOnly = true;
            this.dgv_ListaMovimientos.Size = new System.Drawing.Size(692, 417);
            this.dgv_ListaMovimientos.TabIndex = 16;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.dgv_ListaMovimientos, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 12);
            this.tableLayoutPanel1.MinimumSize = new System.Drawing.Size(788, 423);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(788, 423);
            this.tableLayoutPanel1.TabIndex = 17;
            // 
            // sb_footerBar
            // 
            this.sb_footerBar.Location = new System.Drawing.Point(0, 441);
            this.sb_footerBar.Name = "sb_footerBar";
            this.sb_footerBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                this.sbp_EstatusPrograma
            });
            this.sb_footerBar.ShowPanels = true;
            this.sb_footerBar.Size = new System.Drawing.Size(800, 14);
            this.sb_footerBar.TabIndex = 18;
            // 
            // sbp_EstatusPrograma
            // 
            this.sbp_EstatusPrograma.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.sbp_EstatusPrograma.Name = "sbp_EstatusPrograma";
            this.sbp_EstatusPrograma.Text = "Estatus: OK";
            this.sbp_EstatusPrograma.Width = 783;
            // 
            // HistorialSolicitudCancelacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(800, 455);
            this.Controls.Add(this.sb_footerBar);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(816, 494);
            this.Name = "HistorialSolicitudCancelacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historial de Solicitud de Cancelación";
            this.Load += new System.EventHandler(this.HistorialSolicitudCancelacion_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HistorialSolicitudCancelacion_KeyDown);
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ListaMovimientos)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sbp_EstatusPrograma)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.StatusBarPanel sbp_EstatusPrograma;
        private System.Windows.Forms.StatusBar sb_footerBar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dgv_ListaMovimientos;
        private System.Windows.Forms.Button btn_RechazarSolicitud;
        private System.Windows.Forms.Button btn_CancelarMovimiento;
        private System.Windows.Forms.Button btn_CancelarTodo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn_Regresar;

        #endregion

    }
}