﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class PuntoDeVenta
    {
        #region Datos entrega, anticipos, afectar by DAN

        //-917
        private readonly clsStd std = new clsStd();

        private bool Afectando;
        private CDetalleVenta.ValAfectar ValidaAfectar;

        //-ErrorIVA
        private readonly DM0312_CPuntoDeVenta controladorV = new DM0312_CPuntoDeVenta();

        /// <summary>
        ///     Abre los datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void DatosEntregaClick(object sender, EventArgs e)
        {
            VentaDimaValidacion();
            if (ListVentaDetalle.Count <= 1)
            {
                MessageBox.Show("Agrega articulos primeramente", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (vale == 1)
            {
                txt_direccionEntrega.Text = string.Empty;
                cb_colonia.Text = string.Empty;
                txt_CPEntrega.Text = string.Empty;
                txt_PoblacionEntrega.Text = string.Empty;
                txt_EstadoEntrega.Text = string.Empty;
                txt_EntreCallesEntrega.Text = string.Empty;
                txt_TelParticularEntrega.Text = string.Empty;
                txt_MovilEntrega.Text = string.Empty;
                txt_ReferenciaEntrega.Text = string.Empty;
                txt_NumE.Text = string.Empty;
                txt_NumI.Text = string.Empty;

                string IDSeleccionado = string.Empty;
                string IDVentaCadena = idVenta.ToString();

                BitacoraEntregas = CDetalleVenta.ObtenerBitacoraEntregas(Codigo, ref IDSeleccionado, IDVentaCadena);
                int? BitacoraSeleccionada = CDetalleVenta.ObtenerBitacoraSeleccionada(IDSeleccionado, BitacoraEntregas);

                if (gbx_DatosEntrega.Visible == false)
                {
                    gbx_DatosEntrega.Visible = true;
                    gbx_DatosEntrega.Size = new Size(966, 151);
                    txt_ComentariosDatosEntrega.Text =
                        "Ingresa la direccion de entrega de la mercancia si ya existe la direccion en el catalogo del cliente seleccionarla al terminar dar clic al apartado de " +
                        btn_Anticipo.Text;
                    //btn_ObligatorioDatos.FlatStyle.;


                    gb_CamposEntrega.Visible = false;
                    if (BitacoraEntregas.Count > 0)
                        if (BitacoraSeleccionada != null)
                        {
                            int bitSel = Convert.ToInt32(BitacoraSeleccionada);
                            txt_direccionEntrega.Text = BitacoraEntregas[bitSel].Direccion;
                            cb_colonia.Text = BitacoraEntregas[bitSel].Colonia;
                            txt_CPEntrega.Text = BitacoraEntregas[bitSel].CP;
                            txt_PoblacionEntrega.Text = BitacoraEntregas[bitSel].Poblacion;
                            txt_EstadoEntrega.Text = BitacoraEntregas[bitSel].Estado;
                            txt_EntreCallesEntrega.Text = BitacoraEntregas[bitSel].EntreCalles;
                            txt_TelParticularEntrega.Text = BitacoraEntregas[bitSel].TelefonoParticular;
                            txt_MovilEntrega.Text = BitacoraEntregas[bitSel].TelefonoMovil;
                            txt_ReferenciaEntrega.Text = BitacoraEntregas[bitSel].Referencia;
                            txt_NumE.Text = BitacoraEntregas[bitSel].NumExt;
                            txt_NumI.Text = BitacoraEntregas[bitSel].NumInt;
                            gb_CamposEntrega.Visible = true;
                        }

                    AutoScrollPosition = new Point(0, 820);
                    gbx_menuPuntoVenta.Location = new Point(0, 4);
                    flp_promociones.Location = new Point(1057, 56);
                    Panel_UsuarioEstatus.Location = new Point(829, 7);
                }
                else
                {
                    gbx_DatosEntrega.Visible = false;

                    lbl_cliente.Focus();
                    gbx_menuPuntoVenta.Location = new Point(0, 4);
                    flp_promociones.Location = new Point(1057, 56);
                    Panel_UsuarioEstatus.Location = new Point(829, 7);
                }

                if (dgv_datosEntrega.Columns.Count == 0)
                {
                    DataGridViewCheckBoxColumn c = new DataGridViewCheckBoxColumn();
                    c.Name = "";
                    dgv_datosEntrega.Columns.Add(c);
                }

                dgv_datosEntrega.DataSource = null;
                dgv_datosEntrega.DataSource = BitacoraEntregas;
                CDetalleVenta.FillDataGridDatosEntrega(BitacoraEntregas, ref dgv_datosEntrega, BitacoraSeleccionada);
                btn_nuevaEntrega.Enabled = true;
            }

            btn_Afectar.Focus();
        }

        /// <summary>
        ///     Abre anticipos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void btn_Anticipo_Click(object sender, EventArgs e)
        {
            string defCuentaUsuario = "";
            defCuentaUsuario = controllerExplorador.ValidaCajaUsuario(ClaseEstatica.Usuario.Usser);
            if (controlador.ValidaEstatusCaja(defCuentaUsuario))
            {
                if (controlador.ClienteConCuenta(Codigo))
                {
                    VentaDimaValidacion();
                    if (vale == 0)
                    {
                        gbx_Anticipo.Visible = false;
                        btn_Anticipo.Focus();
                    }
                    else
                    {
                        if (ListVentaDetalle.Count <= 1)
                        {
                            MessageBox.Show("Agrega articulos primeramente", "Mensaje!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            return;
                        }

                        if (gbx_Anticipo.Visible)
                        {
                            gbx_Anticipo.Visible = false;
                        }
                        else
                        {
                            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                            DM0312_MVentaDetalle modelvacio = new DM0312_MVentaDetalle();
                            ListVentaDetalle.Add(modelvacio);
                            llenarGrid();
                            gbx_Anticipo.Visible = true;
                        }
                    }

                    btn_Afectar.Focus();
                }
                else
                {
                    MessageBox.Show(
                        "No puede hacer anticipos o enganches a prospectos debe asignarle cuenta de cliente",
                        "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show(
                    "No puede hacer anticipos o enganches por que la caja " + defCuentaUsuario +
                    " se encuentra cerrada", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        ///     datos entrega gridview content click
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void dgv_datosEntrega_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgv_datosEntrega.RefreshEdit();
        }

        /// <summary>
        ///     evento de fila seleccionada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        private void dgv_datosEntrega_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            NuevaEntrega = false;
            btn_nuevaEntrega.Enabled = true;
            gb_CamposEntrega.Visible = true;
            ChangeSelectedCheckbox();

            dgv_datosEntrega.RefreshEdit();
            if (dgv_datosEntrega.Rows.Count > 0) dgv_datosEntrega.NotifyCurrentCellDirty(true);

            DataGridViewSelectedRowCollection selectedRows = dgv_datosEntrega.SelectedRows;
            if (selectedRows.Count > 0 && BitacoraEntregas != null &&
                selectedRows[selectedRows.Count - 1].Index < BitacoraEntregas.Count)
            {
                txt_direccionEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Direccion;
                cb_colonia.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Colonia;
                txt_CPEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].CP;
                txt_PoblacionEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Poblacion;
                txt_EstadoEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Estado;
                txt_EntreCallesEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].EntreCalles;
                txt_TelParticularEntrega.Text =
                    BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].TelefonoParticular;
                txt_MovilEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].TelefonoMovil;
                txt_ReferenciaEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Referencia;
                txt_NumE.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].NumExt;
                txt_NumI.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].NumInt;
            }
            else
            {
                txt_direccionEntrega.Text = "";
                cb_colonia.Text = string.Empty;
                txt_CPEntrega.Text = "";
                txt_PoblacionEntrega.Text = "";
                txt_EstadoEntrega.Text = "";
                txt_EntreCallesEntrega.Text = "";
                txt_TelParticularEntrega.Text = "";
                txt_MovilEntrega.Text = "";
                txt_ReferenciaEntrega.Text = "";
                txt_NumE.Text = "";
                txt_NumI.Text = "";
            }

            cb_colonia.Focus();
            gbx_DatosEntrega.Size = new Size(966, 357);
            gb_CamposEntrega.Focus();
        }

        /// <summary>
        ///     Cambio de fila seleccionada
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        protected void ChangeSelectedCheckbox()
        {
            int selectedRowCount = dgv_datosEntrega.Rows.GetRowCount(DataGridViewElementStates.Selected);
            foreach (DataGridViewRow dgrow in dgv_datosEntrega.Rows)
                if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                {
                    DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                    if (selectedRowCount > 0 &&
                        dgrow.Index == dgv_datosEntrega.SelectedRows[selectedRowCount - 1].Index)
                        dcb.Value = true;
                    else
                        dcb.Value = false;
                }
        }

        /// <summary>
        ///     boton para indicar que se hara una nueva entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void btn_nuevaEntrega_Click(object sender, EventArgs e)
        {
            NuevaEntrega = true;
            gb_CamposEntrega.Visible = true;
            txt_direccionEntrega.Focus();
            btn_nuevaEntrega.Enabled = false;

            txt_direccionEntrega.Text = string.Empty;
            cb_colonia.Text = string.Empty;
            txt_CPEntrega.Text = string.Empty;
            txt_PoblacionEntrega.Text = string.Empty;
            txt_EstadoEntrega.Text = string.Empty;
            txt_EntreCallesEntrega.Text = string.Empty;
            txt_TelParticularEntrega.Text = string.Empty;
            txt_MovilEntrega.Text = string.Empty;
            txt_ReferenciaEntrega.Text = string.Empty;
            txt_NumE.Text = string.Empty;
            txt_NumI.Text = string.Empty;

            chkDomicilioCliente.Visible = true;
            txt_ComentariosDatosEntrega.Visible = false;

            foreach (DataGridViewRow dgrow in dgv_datosEntrega.Rows)
                if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                {
                    DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                    dcb.Value = false;
                }

            dgv_datosEntrega.ClearSelection();
            gbx_DatosEntrega.Size = new Size(966, 357);
            gb_CamposEntrega.Focus();
        }

        /// <summary>
        ///     Guarda o crea nueva fila para datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        private void btn_guardar_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dgv_datosEntrega.SelectedRows;

            if (cb_colonia.Text != string.Empty && txt_CPEntrega.Text != string.Empty &&
                txt_PoblacionEntrega.Text != string.Empty && txt_direccionEntrega.Text != string.Empty &&
                txt_TelParticularEntrega.Text != string.Empty && txt_MovilEntrega.Text != string.Empty)
            {
                bool telefonosValidos = true;
                bool MovilEntregaValido = true;
                bool ParticularValido = true;
                if (txt_MovilEntrega.Text != string.Empty && !funciones.ValidaTelefonos(txt_MovilEntrega.Text))
                {
                    telefonosValidos = false;
                    MovilEntregaValido = false;
                }

                if (txt_TelParticularEntrega.Text != string.Empty &&
                    !funciones.ValidaTelefonos(txt_TelParticularEntrega.Text))
                {
                    telefonosValidos = false;
                    ParticularValido = false;
                }

                if (telefonosValidos)
                {
                    //Parametros que se guardaran en los datos de entrega
                    string[] Parametros =
                    {
                        Codigo,
                        txt_direccionEntrega.Text,
                        cb_colonia.Text,
                        txt_PoblacionEntrega.Text,
                        txt_CPEntrega.Text,
                        txt_EstadoEntrega.Text,
                        txt_EntreCallesEntrega.Text,
                        txt_TelParticularEntrega.Text,
                        txt_MovilEntrega.Text,
                        txt_ReferenciaEntrega.Text,
                        txt_NumE.Text,
                        txt_NumI.Text
                    };

                    int? sucursalaGuardar = ClaseEstatica.Usuario.sucursal;
                    CDetalleVenta.GuardarDatosEntrega(selectedRows, BitacoraEntregas, Parametros, idVenta,
                        sucursalaGuardar, NuevaEntrega);

                    BitacoraEntregas.Clear();
                    string IDSeleccionado = string.Empty;
                    BitacoraEntregas =
                        CDetalleVenta.ObtenerBitacoraEntregas(Codigo, ref IDSeleccionado, idVenta.ToString());

                    int? BitacoraSeleccionada =
                        CDetalleVenta.ObtenerBitacoraSeleccionada(IDSeleccionado, BitacoraEntregas);

                    dgv_datosEntrega.DataSource = null;
                    dgv_datosEntrega.DataSource = BitacoraEntregas;
                    CDetalleVenta.FillDataGridDatosEntrega(BitacoraEntregas, ref dgv_datosEntrega,
                        BitacoraSeleccionada);
                    btn_nuevaEntrega.Enabled = true;
                }
                else
                {
                    string PhoneValido = string.Empty;
                    if (!MovilEntregaValido) PhoneValido = "Teléfono movil";
                    if (!ParticularValido)
                    {
                        if (PhoneValido != string.Empty)
                            PhoneValido = PhoneValido + " y teléfono particular";
                        else
                            PhoneValido = "Teléfono particular";
                    }

                    MessageBox.Show(PhoneValido + " con formato incorrecto", "Advertencia!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            else
            {
                string Faltantes = "";
                if (cb_colonia.Text == string.Empty) Faltantes += "Colonia";
                if (txt_NumE.Text == string.Empty) Faltantes += "Numero Exterior";
                if (txt_CPEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", código postal" : "Código postal";
                if (txt_PoblacionEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", población" : "Población";
                if (txt_direccionEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", dirección" : "Dirección";
                if (txt_TelParticularEntrega.Text == string.Empty && txt_TelParticularEntrega.Text != "0000000000")
                    Faltantes += Faltantes != "" ? ", teléfono particular" : "Teléfono particular";
                if (txt_MovilEntrega.Text == string.Empty && txt_MovilEntrega.Text != "0000000000")
                    Faltantes += Faltantes != "" ? ", teléfono movil" : "Teléfono movil";

                MessageBox.Show("Falta agregar " + Faltantes + " para poder guardar la direccion de entrega",
                    "Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ComponentesFocusDatosEntrega();
            }
        }

        public void ComponentesFocusDatosEntrega()
        {
            if (txt_direccionEntrega.Text == string.Empty)
            {
                txt_direccionEntrega.Select();
            }
            else
            {
                if (cb_colonia.Text == string.Empty)
                {
                    cb_colonia.Select();
                }
                else
                {
                    if (txt_CPEntrega.Text == string.Empty)
                    {
                        txt_CPEntrega.Select();
                    }
                    else
                    {
                        if (txt_PoblacionEntrega.Text == string.Empty)
                        {
                            txt_PoblacionEntrega.Select();
                        }
                        else
                        {
                            if (txt_TelParticularEntrega.Text == string.Empty &&
                                txt_TelParticularEntrega.Text != "0000000000")
                            {
                                txt_TelParticularEntrega.Select();
                            }
                            else
                            {
                                if (txt_MovilEntrega.Text == string.Empty && txt_MovilEntrega.Text != "0000000000")
                                    txt_MovilEntrega.Select();
                            }
                        }
                    }
                }
            }
        }

        private void cb_colonia_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cb_colonia_Click(object sender, EventArgs e)
        {
            DM0312_DetalleCodigoPostal.regresar = false;
            DM0312_DetalleCodigoPostal cp = new DM0312_DetalleCodigoPostal();
            cp.ShowDialog();
            if (!DM0312_DetalleCodigoPostal.regresar)
            {
                cb_colonia.Text = cp.CodigoPostalSeleccionado.Colonia;
                txt_CPEntrega.Text = cp.CodigoPostalSeleccionado.CP;
                txt_PoblacionEntrega.Text = cp.CodigoPostalSeleccionado.Delegacion;
                txt_EstadoEntrega.Text = cp.CodigoPostalSeleccionado.Estado;
                txt_EntreCallesEntrega.Select();
            }
        }

        /// <summary>
        ///     keypress direccion entrega textbox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void txt_direccionEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cb_colonia.Select();
        }

        /// <summary>
        ///     keypress textbox calles entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void txt_EntreCallesEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_TelParticularEntrega.Select();
        }

        /// <summary>
        ///     solo números en telefono
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void txt_TelParticularEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_MovilEntrega.Select();
        }

        /// <summary>
        ///     solo números en telefono
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void txt_MovilEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_ReferenciaEntrega.Select();
        }

        /// <summary>
        ///     Validaciones en recibido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developr: Dan Palacios
        /// Date: 26/10/17
        private void RecibidosKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        }

        /// <summary>
        ///     Referencia entrega keypress validaciones
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void txt_ReferenciaEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     Agrega una nueva forma de pago
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void AgregarFormaPago()
        {
            if (controladorD.SMStablaConversionSegurosValor() == "1")
            {
                int valorN = 0;
                string mensaje = "";
                valorN = controlador.ContadorFormasPago(cbx_Condicion.Text);
                if (valorN > 5)
                {
                    valorN = 5;
                    mensaje = "Solo se permiten 5 formas de pago distintas";
                }
                else
                {
                    mensaje = "No se permite agregar un numero mayor de formas de pago de las que tiene la condicion";
                }

                if (FormasPagoAgregadas.Count < valorN)
                {
                    Label lbl_formaPago = new Label
                    {
                        Name = "lbl_formaPago",
                        Text = "Forma pago",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(72, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_formaPago);

                    ComboBox cb_FormaPago = controlador.ObtenerFormasDePago(FormasPagoAgregadas, cbx_Condicion.Text);
                    cb_FormaPago.Tag = FormasPagoTag.ToString();
                    cb_FormaPago.DropDownWidth = 253;
                    cb_FormaPago.Size = new Size(100, 21);
                    cb_FormaPago.Click += FormaPagoClick;
                    cb_FormaPago.SelectedIndexChanged += ComboDropped;
                    cb_FormaPago.DropDownClosed += CambiarFormaPago;
                    cb_FormaPago.DropDownStyle = ComboBoxStyle.DropDownList;
                    LastFormaPagoSelected.Add(FormasPagoTag, cb_FormaPago.Text);

                    flp_FormaPago.Controls.Add(cb_FormaPago);

                    Label lbl_Monto = new Label
                    {
                        Text = "Monto",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(50, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Monto);

                    TextBox tb_Monto = new TextBox
                    {
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(60, 21)
                    };
                    tb_Monto.KeyPress += txt_MovilEntrega_KeyPress;
                    tb_Monto.KeyUp += KeyDownUpMonto;
                    tb_Monto.KeyDown += KeyDownUpMonto;
                    tb_Monto.Enter += FocusEnMonto;
                    tb_Monto.Leave += SalirDeFocusEnMonto;
                    tb_Monto.Text = "0";
                    tb_Monto.Name = "tb_Monto";
                    tb_Monto.MaxLength = 20;
                    flp_FormaPago.Controls.Add(tb_Monto);

                    Label lbl_MontoCeros = new Label
                    {
                        Text = ".00",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(40, 15),
                        Margin = new Padding(3, 9, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_MontoCeros);

                    Label lbl_Referencia = new Label
                    {
                        Text = "Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(70, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Referencia);

                    TextBox tb_Referencia = new TextBox
                    {
                        Name = "tb_Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(150, 21),
                        MaxLength = 100
                    };
                    flp_FormaPago.Controls.Add(tb_Referencia);

                    Button btn_removeFormaPago = new Button
                    {
                        FlatStyle = FlatStyle.Flat
                    };
                    btn_removeFormaPago.FlatAppearance.BorderColor = Color.Black;
                    btn_removeFormaPago.BackColor = Color.LightGray;
                    btn_removeFormaPago.Text = "Remover";
                    btn_removeFormaPago.Tag = FormasPagoTag.ToString();
                    btn_removeFormaPago.Cursor = Cursors.Hand;
                    btn_removeFormaPago.Click += RemoveSelectedFormaPago;
                    flp_FormaPago.Controls.Add(btn_removeFormaPago);

                    FormasPagoTag = FormasPagoTag + 1;
                    flp_FormaPago.VerticalScroll.Value = flp_FormaPago.VerticalScroll.Maximum;
                    flp_FormaPago.PerformLayout();
                    EfectivoSeleccionado();
                    if (cb_FormaPago.Text == "EFECTIVO")
                    {
                        Tb_efectivoRecibido.Text = "0";
                        lbl_cambio.Text = "Cambio: $ 0.00";
                    }
                }
                else
                {
                    MessageBox.Show(mensaje, "Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                if (FormasPagoAgregadas.Count < 5)
                {
                    Label lbl_formaPago = new Label
                    {
                        Name = "lbl_formaPago",
                        Text = "Forma pago",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(72, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_formaPago);

                    ComboBox cb_FormaPago = controlador.ObtenerFormasDePago(FormasPagoAgregadas, "1");
                    cb_FormaPago.Tag = FormasPagoTag.ToString();
                    cb_FormaPago.DropDownWidth = 253;
                    cb_FormaPago.Size = new Size(100, 21);
                    cb_FormaPago.Click += FormaPagoClick;
                    cb_FormaPago.SelectedIndexChanged += ComboDropped;
                    cb_FormaPago.DropDownClosed += CambiarFormaPago;
                    cb_FormaPago.DropDownStyle = ComboBoxStyle.DropDownList;
                    LastFormaPagoSelected.Add(FormasPagoTag, cb_FormaPago.Text);

                    flp_FormaPago.Controls.Add(cb_FormaPago);

                    Label lbl_Monto = new Label
                    {
                        Text = "Monto",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(50, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Monto);

                    TextBox tb_Monto = new TextBox
                    {
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(60, 21)
                    };
                    tb_Monto.KeyPress += txt_MovilEntrega_KeyPress;
                    tb_Monto.KeyUp += KeyDownUpMonto;
                    tb_Monto.KeyDown += KeyDownUpMonto;
                    tb_Monto.Enter += FocusEnMonto;
                    tb_Monto.Leave += SalirDeFocusEnMonto;
                    tb_Monto.Text = "0";
                    tb_Monto.Name = "tb_Monto";
                    tb_Monto.MaxLength = 20;
                    flp_FormaPago.Controls.Add(tb_Monto);

                    Label lbl_MontoCeros = new Label
                    {
                        Text = ".00",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(40, 15),
                        Margin = new Padding(3, 9, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_MontoCeros);

                    Label lbl_Referencia = new Label
                    {
                        Text = "Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(70, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Referencia);

                    TextBox tb_Referencia = new TextBox
                    {
                        Name = "tb_Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(150, 21),
                        MaxLength = 100
                    };
                    flp_FormaPago.Controls.Add(tb_Referencia);

                    Button btn_removeFormaPago = new Button
                    {
                        FlatStyle = FlatStyle.Flat
                    };
                    btn_removeFormaPago.FlatAppearance.BorderColor = Color.Black;
                    btn_removeFormaPago.BackColor = Color.LightGray;
                    btn_removeFormaPago.Text = "Remover";
                    btn_removeFormaPago.Tag = FormasPagoTag.ToString();
                    btn_removeFormaPago.Cursor = Cursors.Hand;
                    btn_removeFormaPago.Click += RemoveSelectedFormaPago;
                    flp_FormaPago.Controls.Add(btn_removeFormaPago);

                    FormasPagoTag = FormasPagoTag + 1;
                    flp_FormaPago.VerticalScroll.Value = flp_FormaPago.VerticalScroll.Maximum;
                    flp_FormaPago.PerformLayout();
                    EfectivoSeleccionado();
                    if (cb_FormaPago.Text == "EFECTIVO")
                    {
                        Tb_efectivoRecibido.Text = "0";
                        lbl_cambio.Text = "Cambio: $ 0.00";
                    }
                }
                else
                {
                    MessageBox.Show("Solo se permiten 5 formas de pago distintas", "Advertencia!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        /// <summary>
        ///     Remueve la linea de forma pago seleccionada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void RemoveSelectedFormaPago(object sender, EventArgs e)
        {
            Button btnsender = (Button)sender;
            if (FormasPagoAgregadas.Count > 1)
            {
                for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
                    if (flp_FormaPago.Controls[i].Tag.ToString() == btnsender.Tag.ToString())
                    {
                        if (flp_FormaPago.Controls[i] is ComboBox)
                        {
                            LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                            FormasPagoAgregadas.Remove(flp_FormaPago.Controls[i].Text);
                            //FormasPagoAgregadas.RemoveAt(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                        }

                        flp_FormaPago.Controls.RemoveAt(i);
                        AnticipoMontoTotal();
                    }

                EfectivoSeleccionado();
            }
            else
            {
                MessageBox.Show("Debe existir al menos una forma de pago", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        ///     Añade una nueva forma de pago
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void btn_agregarFormaPago_Click(object sender, EventArgs e)
        {
            if (!CerosEnFormasDePago())
            {
                if (montoTotal == saldoRestante)
                    MessageBox.Show("El monto total ya es igual al total del movimiento", "Advertencia!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    AgregarFormaPago();
            }
            else
            {
                MessageBox.Show("No pueden quedar formas de pago en 0", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        ///     Keyup para montos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void KeyDownUpMonto(object sender, KeyEventArgs e)
        {
            TextBox tb_monto = (TextBox)sender;
            if (tb_monto.Text.Length > 0 && tb_monto.Text.Substring(0, 1) == "-")
                tb_monto.Text = tb_monto.Text.Substring(1, tb_monto.Text.Length - 1);
            double totalAntes = montoTotal;
            AnticipoMontoTotal();
            double Montototal = montoTotal;
            if (Montototal > saldoRestante)
            {
                Montototal = Montototal - Convert.ToDouble(tb_monto.Text);
                double MontoRestante = saldoRestante - Montototal;
                tb_monto.Text = MontoRestante.ToString();
                tb_monto.SelectionStart = tb_monto.Text.Length + 1;
            }

            if (tb_monto.Text.Length > 1 && tb_monto.Text.Substring(0, 1) == "0")
            {
                tb_monto.Text = tb_monto.Text.Substring(1, tb_monto.Text.Length - 1);
                tb_monto.SelectionStart = tb_monto.Text.Length + 1;
            }

            AnticipoMontoTotal();

            double montoEfectivo = 0;
            if (tb_monto.Text != string.Empty) montoEfectivo = Convert.ToDouble(tb_monto.Text);
            ObtenerCambioMinimo(tb_monto.Tag.ToString(), montoEfectivo);
        }

        /// <summary>
        ///     Focus de monto
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/11/17
        private void FocusEnMonto(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox tbsender = (TextBox)sender;
                if (tbsender.Text == "0") tbsender.Text = "";
            }
        }

        /// <summary>
        ///     Salir de focus de monto
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/11/17
        private void SalirDeFocusEnMonto(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                KeyDownUpMonto(sender, null);
                TextBox tbsender = (TextBox)sender;
                if (tbsender.Text == "") tbsender.Text = "0";
                ObtenerCambioMinimo(tbsender.Tag.ToString(), Convert.ToDouble(tbsender.Text));
            }
        }

        /// <summary>
        ///     Obtiene la minima cantidad que se podra poner en el textbox de recibido
        /// </summary>
        /// <param name="CurrentTag">string</param>
        /// <param name="LimiteRecibido">double</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void ObtenerCambioMinimo(string CurrentTag, double LimiteRecibido)
        {
            RecibidoMinimo = 0;
            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl.Tag.ToString() == CurrentTag && ctrl is ComboBox)
                {
                    ComboBox cboxFormaPago = (ComboBox)ctrl;
                    if (cboxFormaPago.Text == "EFECTIVO")
                    {
                        RecibidoMinimo = LimiteRecibido;
                        BanderaRecibidoMinimo = LimiteRecibido;
                        //Tb_efectivoRecibido.Text = (Tb_efectivoRecibido.Text == "" || Tb_efectivoRecibido.Text == "0" || Convert.ToDouble(Tb_efectivoRecibido.Text) < RecibidoMinimo) ? RecibidoMinimo.ToString() : Tb_efectivoRecibido.Text;
                        lbl_cambio.Text = "Cambio: " +
                                          (Convert.ToDouble(Tb_efectivoRecibido.Text) - BanderaRecibidoMinimo).ToString(
                                              "C");
                    }
                }
        }


        /// <summary>
        ///     monto total de anticipos
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void AnticipoMontoTotal()
        {
            montoTotal = 0;
            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl is TextBox)
                {
                    TextBox txt_monto = (TextBox)ctrl;
                    if (txt_monto.Name == "tb_Monto")
                        if (txt_monto.Text != string.Empty)
                            montoTotal = montoTotal + Convert.ToDouble(txt_monto.Text);
                }

            txt_anticipototal.Text = montoTotal.ToString("C");
        }

        /// <summary>
        ///     Checar si hay ceros en formas de pago
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private bool CerosEnFormasDePago()
        {
            bool MontoConCero = false;

            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl is TextBox)
                {
                    TextBox txt_monto = (TextBox)ctrl;
                    if (txt_monto.Name == "tb_Monto")
                        if (txt_monto.Text != string.Empty && (txt_monto.Text == "0" || txt_monto.Text.Trim() == ""))
                            return true;
                }

            return MontoConCero;
        }

        /// <summary>
        ///     Click en forma de pago para guardar el estatus anterior
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void FormaPagoClick(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] = cbFormaPago.Text;
        }

        /// <summary>
        ///     combo index changed
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/10/17
        private void ComboDropped(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            if (!cbFormaPago.DroppedDown)
                cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
        }

        /// <summary>
        ///     Evento cuando el textbox de recibido pierde focus
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_Leave(object sender, EventArgs e)
        {
            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text;
            if (Convert.ToDouble(Tb_efectivoRecibido.Text) < RecibidoMinimo)
            {
                Tb_efectivoRecibido.Text = "0";
                Tb_efectivoRecibido.SelectionStart = Tb_efectivoRecibido.Text.Length + 1;
            }

            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text != "" ? Tb_efectivoRecibido.Text : "0";
            lbl_cambio.Text = "Cambio: " +
                              (Convert.ToDouble(Tb_efectivoRecibido.Text) - BanderaRecibidoMinimo).ToString("C");
        }

        /// <summary>
        ///     Focus de textbox recbido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_Enter(object sender, EventArgs e)
        {
            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text != "0" ? Tb_efectivoRecibido.Text : "";
        }

        /// <summary>
        ///     key down de textbox de recibido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                double Total = Convert.ToDouble(Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text) -
                               BanderaRecibidoMinimo;
                Total = Total < 0 ? 0 : Total;
                lbl_cambio.Text = "Cambio: " + Total.ToString("C");
            }
            catch
            {
            }
        }

        /// <summary>
        ///     key press de textbox de recibido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                double Total = Convert.ToDouble(Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text) -
                               BanderaRecibidoMinimo;
                Total = Total < 0 ? 0 : Total;
                lbl_cambio.Text = "Cambio: " + Total.ToString("C");
            }
            catch
            {
            }
        }

        /// <summary>
        ///     Checa si el metodo de pago efectivo esta seleccionado en un combobox
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void EfectivoSeleccionado()
        {
            lbl_recibido.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            Tb_efectivoRecibido.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            lbl_rec_ceros.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            lbl_cambio.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
        }


        /// <summary>
        ///     Cambiar la forma de pago en el evento del combobox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void CambiarFormaPago(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            if (cbFormaPago.DroppedDown)
            {
                cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
                return;
            }

            if (FormasPagoAgregadas.Contains(cbFormaPago.Text))
            {
                if (LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] != cbFormaPago.Text)
                {
                    MessageBox.Show("No se pueden duplicar las formas de pago", "Advertencia!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
                }
            }
            else
            {
                FormasPagoAgregadas.Add(cbFormaPago.Text);
                FormasPagoAgregadas.Remove(LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())]);
                LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] = cbFormaPago.Text;
            }

            EfectivoSeleccionado();
            if (cbFormaPago.Text == "EFECTIVO")
                foreach (Control ctrl in flp_FormaPago.Controls)
                    if (ctrl.Tag.ToString() == cbFormaPago.Tag.ToString() && ctrl is TextBox && ctrl.Name == "tb_Monto")
                    {
                        TextBox tb_Monto = (TextBox)ctrl;
                        ObtenerCambioMinimo(cbFormaPago.Tag.ToString(), Convert.ToDouble(tb_Monto.Text));
                        break;
                    }
        }

        /// <summary>
        ///     Text changed del total
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/10/17
        private void txtTotal_TextChanged(object sender, EventArgs e)
        {
            if (txtTotal.Text != string.Empty && txt_anticipototal.Text != string.Empty
                                              && Convert.ToDouble(total) < Convert.ToDouble(montoTotal.ToString()))
            {
                string comboboxSelected = string.Empty;
                for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
                    if (FormasPagoAgregadas.Count > 1)
                    {
                        if (flp_FormaPago.Controls[i] is ComboBox)
                        {
                            ComboBox cb_monto = (ComboBox)flp_FormaPago.Controls[i];
                            comboboxSelected = cb_monto.Text;
                        }

                        if (flp_FormaPago.Controls[i] is Label && flp_FormaPago.Controls[i].Name == "lbl_formaPago")
                        {
                            LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                            FormasPagoAgregadas.Remove(comboboxSelected);
                        }

                        flp_FormaPago.Controls.RemoveAt(i);
                    }
                    else
                    {
                        if (flp_FormaPago.Controls[i] is TextBox)
                        {
                            TextBox txt_monto = (TextBox)flp_FormaPago.Controls[i];
                            if (txt_monto.Name == "tb_Monto") txt_monto.Text = "0";
                        }
                    }

                AnticipoMontoTotal();
            }
        }

        /// <summary>
        ///     Metodo del boton para afectar movimiento
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 04/11/17
        public async Task AfectarF()
        {
            GC.Collect();
            ValidaCamposObligatorios();
            if (obligatorio != true)
            {
                if (!AsignarCodigosRecomendadores()) return;

                //Candado promociones 
                listaPromos.Clear();
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x => x.idPromocion != 0))
                    listaPromos.Add(item);

                foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x => x.idPromocion == 0))
                    if (!string.IsNullOrEmpty(item.Articulo))
                        if (!item.Articulo.Contains("GARA"))
                        {
                            int iCantidad = item.Cantidad;
                        }


                foreach (DM0312_MVentaDetalle item in listaPromos)
                {
                }


                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                DM0312_MVentaDetalle modelvacio = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(modelvacio);
                backgroundWorker1.Dispose();
                aTimer.Enabled = false;
                if (correoCompleto != "") GuardarCorreoC();

                if (txt_TelParticular.Enabled) telefonocorrectoParticular(txt_TelParticular.Text);

                if (txt_movil.Enabled || obligatorioMovil) InsertaTelefono(txt_movil.Text, "MOVIL");

                if (txt_TelParticular.Enabled || obligatorioParticular)
                    InsertaTelefono(txt_TelParticular.Text, "PARTICULAR");

                VentaDimaValidacion();
                if (vale == 1)
                {
                    if (!guardarArticulos()) return;

                    /////////////////////////
                    string tipoS = controladorEntrada.TipoSuc();
                    if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                    {
                        string totalP = txtTotal.Text;
                        totalP = totalP.Replace("$", "");
                        totalP = totalP.Replace(",", "");
                        double TotalNUM = Convert.ToDouble(totalP);
                        double precioM = 0;
                        double precioD = 0;

                        precioM = controladorEntrada.precioMD(1);
                        precioD = controladorEntrada.precioMD(2);

                        if (CDetalleVenta.ConsultarVentaCredilana(Convert.ToString(idVenta)))
                        {
                            if (controladorEntrada.ReglasTelemarketingPrecio(TotalNUM, "Dinero") == "NO")
                            {
                                MessageBox.Show(
                                    "No puede realizar venta de dinero en esta sucursal con un importe mayor a " +
                                    precioD, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                        }
                        else
                        {
                            if (controladorEntrada.ReglasTelemarketingPrecio(TotalNUM, "Mercancia") == "NO")
                            {
                                MessageBox.Show(
                                    "No puede realizar venta de mercancia en esta sucursal con un importe mayor a " +
                                    precioM, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                        }
                    }
                    ////////////////////////

                    if (dvg_detalleVenta.Rows.Count < 2)
                    {
                        MessageBox.Show("No hay articulos añadidos", "Advertencia!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return;
                    }

                    string Canal = EnviarA.ToString();
                    string[] IDyCategoria = CDetalleVenta.ObtenerCategoriaCanal(Canal);
                    int EnteroCategoria = 1;

                    int EnteroEmision = 0;
                    int EnteroVencimiento = 1;
                    string[] FechaEmisionyVencimiento = controlador.ObtenerFechasParaDetalle(idVenta);

                    string[] Parametros =
                    {
                        TipoMovimiento,
                        "", //movID
                        "VTAS",
                        lbl_ID.Text,
                        cbx_Cliente.Text,
                        "SINAFECTAR",
                        EnviarA.ToString(),
                        FechaEmisionyVencimiento[EnteroEmision], //fecha alta
                        ClaseEstatica.Usuario.sucursal.ToString(),
                        cbx_Condicion.Text,
                        IDyCategoria[EnteroCategoria], //categoriaenviarA
                        "", //articulo seleccionado
                        cbx_Almacen.Text,
                        ClaseEstatica.Usuario.Uen.ToString(),
                        "", //origenID
                        "", //referencia orden compra
                        "", //origen
                        total.ToString(),
                        "", //mov tipo
                        FechaEmisionyVencimiento[EnteroVencimiento], //vencimiento
                        "", //origen tipo
                        impuesto.ToString(), //impuestos
                        subtotal.ToString(), //importe
                        "", //origen tipo mov
                        pedComer, //idecommerce
                        IDyCategoria[EnteroCategoria],
                        string.Empty,
                        valeDigitalDatos.beneficiarioFinal
                    };

                    string msgPrecaucion = string.Empty;
                    string msgTitulo = "";

                    if (!frmLoading.Visible)
                    {
                        frmLoading.Show(this);
                        CDetalleVenta.DesabilitarControles(false, this);
                        gbx_menuPuntoVenta.Location = new Point(0, 4);
                        flp_promociones.Location = new Point(1057, 56);
                        Panel_UsuarioEstatus.Location = new Point(829, 7);
                    }

                    List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
                    CDetalleVenta.CargaMovimientoCreado(
                        Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                        Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), VentasSeleccionadas);
                    Afectando = true;

                    CDetalleVenta.PuntosRedimidos =
                        valeDigitalDatos.PuntosRedimidos > 0 ? valeDigitalDatos.PuntosRedimidos : 0.0;

                    ValidaAfectar = CDetalleVenta.ValidacionesAfectar;
                    if (await Task.Run(() => ValidaAfectar(Parametros, ref msgPrecaucion)))
                    {
                        ValidaAfectar = CDetalleVenta.CondicionAfectar;
                        if (await Task.Run(() => ValidaAfectar(Parametros, ref msgPrecaucion)))
                            if (await Task.Run(
                                    () => CDetalleVenta.Afectar(Parametros, ref msgPrecaucion, ref msgTitulo)))
                            {
                                if (frmLoading.Visible)
                                {
                                    frmLoading.Hide();
                                    CDetalleVenta.DesabilitarControles(true, this);
                                    gbx_menuPuntoVenta.Location = new Point(0, 4);
                                    flp_promociones.Location = new Point(1057, 56);
                                    Panel_UsuarioEstatus.Location = new Point(829, 7);
                                }

                                MessageBox.Show("Movimiento afectado satisfactoriamente", "Exito!!",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                Afectando = false;
                                CDetalleVenta.CargaMovimientoCreado(
                                    Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                    Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                    VentasSeleccionadas, true);

                                //-ModuloPromociones
                                if (!string.IsNullOrEmpty(Factura))
                                    if (Refacturacion)
                                    {
                                        //Aplicar nota de cargo y credito
                                        clsControladorPromociones clsControladorPromociones =
                                            new clsControladorPromociones();
                                        List<DM0312_MVentaDetalle> artículos =
                                            clsControladorPromociones.GetArticulos(Factura);

                                        string MovId = clsControladorPromociones.GetMovId(idVenta);
                                        DateTime fecha = clsControladorPromociones.Fecha();

                                        ListVentaDetalle = ListVentaDetalle
                                            .Where(v => !string.IsNullOrEmpty(v.Articulo)).ToList();
                                        int Cargo = 0;
                                        int Credito = 0;

                                        List<DM0312_MVentaDetalle> tmp = artículos
                                            .Where(a => !string.IsNullOrEmpty(a.Articulo_Ligado)).ToList();
                                        List<string> tmp2 = tmp.Count > 0
                                            ? tmp.Select(a => a.Articulo_Ligado).ToList()
                                            : new List<string>();
                                        List<DM0312_MVentaDetalle> padres =
                                            artículos.Where(p => tmp2.Contains(p.Articulo)).ToList();

                                        foreach (DM0312_MVentaDetalle padre in padres)
                                            if (ListVentaDetalle.Exists(vd => vd.Articulo == padre.Articulo))
                                            {
                                            }
                                            else
                                            {
                                                List<DM0312_MVentaDetalle> arts = artículos
                                                    .Where(a => a.Articulo_Ligado == padre.Articulo).ToList();
                                                foreach (DM0312_MVentaDetalle art in arts)
                                                    Cargo += Convert.ToInt32(
                                                        clsControladorPromociones.GetPrecioAnterior(Factura,
                                                            art.Articulo) - art.Precio);
                                                Credito += Convert.ToInt32(padre.Precio);
                                            }

                                        List<DM0312_MVentaDetalle> hijos = ListVentaDetalle.Where(h =>
                                            artículos.Select(a => a.Articulo).Contains(h.Articulo) &&
                                            !string.IsNullOrEmpty(h.Articulo_Ligado)).ToList();

                                        clsControladorPromociones.spNotasPromocion(MovId, idVenta,
                                            ClaseEstatica.Usuario.Sucursal, ClaseEstatica.Usuario.GrupoEmpresa,
                                            ClaseEstatica.Usuario.usuario,
                                            idVenta, MovId, fecha, fecha, Cargo, Credito, "AFECTAR", "");
                                    }

                                AbrirDetalle(VentasSeleccionadas);
                            }
                    }

                    Afectando = false;
                    if (frmLoading.Visible)
                    {
                        frmLoading.Hide();
                        CDetalleVenta.DesabilitarControles(true, this);
                        gbx_menuPuntoVenta.Location = new Point(0, 4);
                        flp_promociones.Location = new Point(1057, 56);
                        Panel_UsuarioEstatus.Location = new Point(829, 7);
                    }

                    if (msgPrecaucion != string.Empty)
                    {
                        string Titulo = "Afectar";
                        if (msgTitulo != string.Empty) Titulo = "Error: " + msgTitulo;

                        //GESSY Mensaje de minimo a de venta
                        MessageBox.Show(msgPrecaucion, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }


        private bool AsignarCodigosRecomendadores()
        {
            /*GESSY 1030/1061 DIMA*/
            if (canalC == 76)
                if (txt_CodigoRecomendadoDima.Visible && txt_CodigoRecomendadoDima.Enabled)
                {
                    if (!string.IsNullOrEmpty(txt_CodigoRecomendadoDima.Text))
                    {
                        if (controlador.validarCodigoRecomendador(txt_CodigoRecomendadoDima.Text, canalC))
                        {
                            string datos =
                                controlador.obtenerDatosDimaRecomendador(txt_CodigoRecomendadoDima.Text, Canal);
                            frmDatosDima dima = new frmDatosDima(datos.Split('|')[0], datos.Split('|')[1]);
                            /*TODO GESSY S*/
                            /*dima.ShowDialog();*/
                            controlador.actualizarCodigoDima(Cliente, txt_CodigoRecomendadoDima.Text, canalC);
                        }
                        else
                        {
                            /*GESSY 1030/1061 DIMA */
                            MessageBox.Show("Código Recomendado Inexistente", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Falta Ingresar Código Recomendador", "Punto De Venta", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                    }
                }

            if (canalC == 7 || canalC == 3)
                if (txt_CodigoRecomendadoDima.Visible && txt_CodigoRecomendadoDima.Enabled)
                {
                    if (!string.IsNullOrEmpty(txt_CodigoRecomendadoDima.Text))
                    {
                        string validaCodigoMenudeo =
                            controlador.validaCodigoMenudeoUEN(txt_CodigoRecomendadoDima.Text, canalC);

                        if (validaCodigoMenudeo != "OK")
                        {
                            MessageBox.Show(validaCodigoMenudeo, "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            return false;
                        }

                        validaCodigoMenudeo =
                            controlador.validaCodigoMenudeo(txt_CodigoRecomendadoDima.Text, cbx_Cliente.Text);

                        if (validaCodigoMenudeo != "OK")
                        {
                            MessageBox.Show(validaCodigoMenudeo, "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            return false;
                        }

                        List<string> DatosCliente =
                            controlador.encontrarCteCodigoMenudeo(txt_CodigoRecomendadoDima.Text, cbx_Cliente.Text);

                        if (DatosCliente.Count > 0)
                        {
                            customMessageCodigoRecomendado(DatosCliente[0] + "\r\n" + DatosCliente[1],
                                "Cliente Recomendador", "check");

                            if (controlador.actualizarCodigoMenudeo(Cliente, txt_CodigoRecomendadoDima.Text, canalC))
                            {
                                if (controlador.actualizarCanjeoCodigoMenudeo(txt_CodigoRecomendadoDima.Text))
                                    MessageBox.Show("Código Recomendado canjeado correctamente");
                            }
                            else
                            {
                                MessageBox.Show("Error al ActualizarAlmacen Código Recomendado Error CLiente");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Código Recomendado Inexistente", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Falta Ingresar Código Recomendador", "Punto De Venta", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                    }
                }

            return true;
        }


        private void sepeararPedido(DM0312_MVentaDetalle mArticulo, clsModeloArtPromocion hijo, int cantidadMaxima,
            int iArticulosAgregados, string sArticuloligado)
        {
            ListVentaDetalle.Remove(mArticulo);

            int dif = cantidadMaxima - iArticulosAgregados;
            int totalagregar = mArticulo.Cantidad - dif;

            mArticulo.Cantidad = dif;
            Dictionary<double, double> item_ = new Dictionary<double, double>();
            double value = Math.Truncate(100 * hijo.dPrecio) / 100;

            mArticulo.Precio = hijo.dPrecio;
            mArticulo.PrecioS = value.ToString("C", Thread.CurrentThread.CurrentCulture);
            mArticulo.Articulo_Ligado = sArticuloligado;

            item_ = actualizaMovPorModel(mArticulo.Cantidad.ToString(), mArticulo);

            mArticulo.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());

            mArticulo.Total = Convert.ToDouble(item_.Values.FirstOrDefault());

            mArticulo.bArtPromocion = true;

            mArticulo.idPromocion = hijo.iIdPromocion;

            mArticulo.TotalS = item_.Values.FirstOrDefault().ToString("C", Thread.CurrentThread.CurrentCulture);
            ListVentaDetalle.Add(mArticulo);

            if (totalagregar != 0) BuscarArticulos(mArticulo.Articulo, false, totalagregar);
            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
        }


        private void btn_Afectar_Click(object sender, EventArgs e)
        {
            ListVentaDetalle.RemoveAll(x => string.IsNullOrEmpty(x.Descripcion));
            //-PedidoSinDetalle
            if (std.obtenerEstatuMovimiento(idVenta) != lbl_Estatus.Text)
                MessageBox.Show("El estatus del moviemiento no corresponde al original.", "Punto De Venta",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (Canal == 3 || canalC == 7)
                if (controladorEntrada.validaVentasFinalesInternet(Codigo) == "NO")
                    if (std.realizarValidacion())
                    {
                        string TipoCredito = controllerExplorador.TipoCredito(Codigo);

                        int iSuc = std.obtenerSucursal(Codigo);

                        if (std.validarMx(TipoCredito))
                            if (iSuc != ClaseEstatica.Usuario.sucursal)
                                if (!std.validarSucursalVentaEnLinea())
                                {
                                    MessageBox.Show(
                                        "No es posible realizar la reactivación de movimientos en las sucursales no correspondientes.",
                                        "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                    }


            int candadoEdadM = 0;
            foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                if (item.Linea == "SEGUROS DE VIDA")
                    candadoEdadM = 1;

            if (Canal == 3 || Canal == 7)
                if (candadoEdadM == 0)
                    if (!CandadoEdadCondicion(Codigo))
                        return;

            if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
                if (TipoMovimiento == "Pedido")
                    if (txb_Ecommerce.Text == "")
                    {
                        MessageBox.Show("Campo Ped.Ecommerce debe ser obligatorio", "Advertencia!",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


            //////////TipoDima///////////////////
            if (Canal == 76 || Canal == 80)
            {
                //if (controlador.validaCasa(Codigo, Canal) == "Nuevo")
                //{
                //    controlador.UpdateTipoDima(Codigo);
                //}

                //-TipoDima ↓ 2019-05-25
                if (controlador.ValorTipoDIMA(Codigo) == "")
                    controlador.UpdateTipoDima(Codigo, Canal == 76 ? "Normal" : "Foraneo");
                if (Canal == 76)
                {
                    string sMotos = controlador.obtenerMontos(cbx_Condicion.Text);

                    if (!string.IsNullOrEmpty(sMotos))
                    {
                        double dMontoMinimo = double.Parse(sMotos.Split('|')[0]);
                        double dMontoMaximo = double.Parse(sMotos.Split('|')[1]);
                        double dTotalVenta = double.Parse(txtTotal.Text.Replace("$", ""));

                        if (!(dTotalVenta >= dMontoMinimo && dTotalVenta <= dMontoMaximo))
                        {
                            MessageBox.Show(
                                "La condición de pago " + cbx_Condicion.Text + " solo permite ventas de $" +
                                dMontoMinimo + " a $" + dMontoMaximo + "\n" +
                                "Favor de seleccionar otra condición de pago.", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
            }

            Parallel.Invoke(async () => await AfectarF());
        }

        #region //-ModuloPromociones

        private void CargarPedidoPromocionVencida()
        {
            clsControladorPromociones clsControladorPromociones = new clsControladorPromociones();
            List<DM0312_MVentaDetalle> artículos = clsControladorPromociones.GetArticulos(Factura);

            //Correo
            /*txt_Correo.Text = "SINCORREO";
            txt_Correo2.Text = "SINCORREO.COM";

            ValidacionInsertarCorreo();
            if (obligatorioCorreo == true && lbl_ID.Text == "")
            {
                componenteValidado = "Correo";
                ValidacionComponentes(componenteValidado);
            }*/

            //productos
            foreach (DM0312_MVentaDetalle item in artículos) BuscarArticulos(item.Articulo, false, item.Cantidad);
            CambiarPrecios(artículos);
            List<DM0312_MVentaDetalle> articulosConPromocion = artículos.Where(a => a.idPromocion > 0).ToList();
            Respetar = articulosConPromocion.Count > 0
                ? articulosConPromocion.Select(a => a.idPromocion).ToList()
                : new List<int>();
            llenarGrid();
        }

        private void CambiarPrecios(List<DM0312_MVentaDetalle> artículos)
        {
            ListVentaDetalle = ListVentaDetalle.Select((d, i) =>
            {
                d.Precio = artículos.Count > i ? artículos[i].Precio : d.Precio;
                d.PrecioS = d.Precio.ToString("C", Thread.CurrentThread.CurrentCulture);

                double iva = d.impuesto / 100 + 1;
                double subtotalParcial = d.Cantidad * (d.Precio / iva);

                double value = Math.Truncate(100 * subtotalParcial) / 100;
                d.SubTotal = Convert.ToDouble(value);

                double Total = Math.Truncate(100 * (d.Cantidad * d.Precio)) / 100;
                d.Total = Total;
                d.TotalS = Total.ToString("C", Thread.CurrentThread.CurrentCulture);

                d.Articulo_Ligado = artículos.Count > i ? artículos[i].Articulo_Ligado : null;
                d.idPromocion = artículos.Count > i ? artículos[i].idPromocion : 0;

                d.bArtPromocion = !string.IsNullOrEmpty(d.Articulo_Ligado) && d.idPromocion > 0;
                return d;
            }).ToList();
        }

        /// <summary>
        ///     Metodo que se encarga de ver si un articulo es valido para una promocion.
        /// </summary>
        /// <param name="sArticulo"></param>
        /// <param name="iCantidad"></param>
        public void ValidaPromocion(string sArticulo, int iCantidad, double iPrecio, int iRenglon,
            List<DM0312_MVentaDetalle> ArticulosIncluidos = null, bool Show = true, bool Forzar = false,
            bool Disminuir = false)
        {
            try
            {
                if (iPrecio >= 99999.99) return;

                if (!std.apagarPromociones()) return;

                //Validamos si la venta aplica para una promocion 
                List<int> listaPromocionesValidas = clsControladorPromociones.validarVentaAplicaPromocion(idVenta);
                if (listaPromocionesValidas.Count <= 0) return;

                //Xml Promociones
                XElement xmlPromociones = new XElement("Promocion",
                    listaPromocionesValidas.Select(i => new XElement("IdPromocion", i)));


                //limpiamos las promociones y cargamos las nuevas
                listaPromos.Clear();
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x => x.idPromocion != 0))
                    listaPromos.Add(item);
                bool bAvanzar = true;

                List<DM0312_MVentaDetalle> listaCopia = ListVentaDetalle.Where(x =>
                    x.listaPadres != null && x.iIdTipoPromocion != 5 && x.iIdTipoPromocion != 2 &&
                    x.iIdTipoPromocion != 4).ToList();
                if (listaCopia.Count > 0)
                {
                    List<clsModeloTipoPromocion> z = listaCopia.FirstOrDefault(x => x.listaPadres != null).listaPadres
                        .Where(a => a.sArticulo == sArticulo).ToList();
                    if (z.Count > 0) bAvanzar = false;
                }

                // Candado para FamiliaMotos
                if (!string.IsNullOrEmpty(sArticulo))
                    if (clsControladorPromociones.ArticuloProhibidaPorFamilia(sArticulo))
                        return;

                frmArticulosPromocion.iCantidadPermitida = 0;

                //se crean los objetos nuevos
                List<clsModeloArtPromocion> listaRegaloMontoGlobal = new List<clsModeloArtPromocion>();
                List<clsModeloArtPromocion> listaRegalo = new List<clsModeloArtPromocion>();

                //Limpiamos objetos que se utilizaron anteriormente
                frmArticulosPromocion.lModeloPromocion.Clear();
                frmArticulosPromocion.ListVentaDetalle.Clear();

                //Se asignan variables al formulario de promociones
                frmArticulosPromocion.Disminuir = Disminuir;

                //se asignan los articulos que tenemos de promocion
                this.ArticulosIncluidos = ListVentaDetalle.Where(x => x.idPromocion > 0).ToList();

                //Xml con los articulos del detalle
                List<string> listaDentalle = new List<string>();
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x => x.idPromocion == 0))
                    if (!string.IsNullOrEmpty(item.Articulo))
                        if (!item.Articulo.Contains("GARA"))
                            listaDentalle.Add(item.Articulo);
                XElement xmlDetalle = new XElement("Articulos",
                    listaDentalle.ToList().Select(i => new XElement("Articulo", i)));

                List<string> listaCinco = new List<string>();
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x =>
                             x.idPromocion == 0 && x.Articulo != null && x.listaPadres == null &&
                             !x.Articulo.Contains("GARA"))) listaCinco.Add(item.Articulo);

                XElement xmlTipoCinco = new XElement("Articulos",
                    listaCinco.ToList().Select(i => new XElement("Articulo", i)));


                //obtengo los padres del tipo 1 y 2
                List<DM0312_MVentaDetalle> d = ListVentaDetalle.Where(x =>
                    x.iIdTipoPromocion == 1 || x.iIdTipoPromocion == 3 || x.iIdTipoPromocion == 5).ToList();
                List<DM0312_MVentaDetalle> e = ListVentaDetalle
                    .Where(x => x.iIdTipoPromocion == 2 || x.iIdTipoPromocion == 4).ToList();

                int suma = e.Sum(x => x.Cantidad);
                List<string> listaPadreTipoUno = new List<string>();
                List<string> listaPadreTipoDos = new List<string>();
                List<string> listaPadreTipoTres = new List<string>();


                foreach (DM0312_MVentaDetalle item in d)
                foreach (clsModeloTipoPromocion padres in item.listaPadres)
                    if (!listaPadreTipoUno.Contains(padres.sArticulo))
                        listaPadreTipoUno.Add(padres.sArticulo);


                foreach (DM0312_MVentaDetalle item in e)
                foreach (clsModeloTipoPromocion padres in item.listaPadres)
                    if (!listaPadreTipoDos.Contains(padres.sArticulo))
                        listaPadreTipoDos.Add(padres.sArticulo);

                double dMontoPadresTipoUno = 0;
                double dMontoPadresTipoDos = 0;


                if (listaPadreTipoUno.Count > 0)
                    foreach (string item in listaPadreTipoUno)
                        dMontoPadresTipoUno = dMontoPadresTipoUno + ListVentaDetalle.Where(x => x.Articulo == item)
                            .Sum(x => x.Precio * x.Cantidad);

                if (listaPadreTipoDos.Count > 0)
                    foreach (string item in listaPadreTipoDos)
                        dMontoPadresTipoDos = dMontoPadresTipoDos + ListVentaDetalle.Where(x => x.Articulo == item)
                            .Sum(x => x.Precio * x.Cantidad);


                //obtenemos el total de la venta de todos articulos que no esten en 
                double dTotalVenta = ListVentaDetalle
                    .Where(x => x.Articulo != null && x.idPromocion == 0 && x.Precio != 99999.99)
                    .Sum(x => x.Precio * x.Cantidad);
                //Obtenemos las promociones que se activan por montos
                //Monto Global Id = 1
                List<int> listaPromocionesPorMonto = new List<int>();
                DM0312_MVentaDetalle c = ListVentaDetalle.FirstOrDefault(x => x.iIdTipoPromocion == 1);
                if (c == null)
                {
                    listaPromocionesPorMonto =
                        clsControladorPromociones.obtenerIdPromocionesFacturaGlobal(dTotalVenta - dMontoPadresTipoDos,
                            1, xmlPromociones.ToString());
                }
                else
                {
                    listaPromocionesPorMonto =
                        clsControladorPromociones.obtenerIdPromocionesFacturaGlobal(dTotalVenta - dMontoPadresTipoDos,
                            1, xmlPromociones.ToString());

                    if (listaPromocionesPorMonto.Count <= 0) ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 1);

                    foreach (int item in listaPromocionesPorMonto)
                    {
                        double dMontoPorPromocion = clsControladorPromociones.obtenerMontoMinimoPromocion(item);
                        if (dMontoPorPromocion > dTotalVenta)
                            ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 1 && x.idPromocion == item);
                    }
                }
                //-----------------------------------------------------------------------------------------------------

                //Monto global y articulo padre id = 2
                List<int> listaPromocionesPorMontoEspecifico = new List<int>();
                if (listaPadreTipoDos.Contains(sArticulo))
                {
                    listaPromocionesPorMontoEspecifico =
                        clsControladorPromociones.obtenerIdPromocionesFacturaGlobal(dTotalVenta, 2,
                            xmlPromociones.ToString());
                    if (listaPromocionesPorMontoEspecifico.Count <= 0)
                        ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 2);
                }
                else
                {
                    listaPromocionesPorMontoEspecifico =
                        clsControladorPromociones.obtenerIdPromocionesFacturaGlobal(dTotalVenta - dMontoPadresTipoUno,
                            2, xmlPromociones.ToString());
                }


                //-----------------------------------------------------------------------------------------------------
                List<int> listaPromoTipoTres = new List<int>();
                DM0312_MVentaDetalle h = ListVentaDetalle.FirstOrDefault(x => x.iIdTipoPromocion == 3);
                if (h == null)
                {
                    //Por articulo padre id = 3
                    List<clsModeloTipoPromocion> listaPromocionesPorArticuloPadreTres =
                        clsControladorPromociones.obtenerIdPromocionesPorArticuloPadreDos(xmlDetalle.ToString(), 3,
                            xmlPromociones.ToString());
                    if (listaPromocionesPorArticuloPadreTres.Count > 0)
                    {
                        XElement xmlPadres = new XElement("Articulos",
                            listaPromocionesPorArticuloPadreTres.Select(i => new XElement("Articulo", i.sArticulo)));

                        double dPrecio = 0;
                        foreach (clsModeloTipoPromocion item in listaPromocionesPorArticuloPadreTres)
                        {
                            DM0312_MVentaDetalle a = ListVentaDetalle.FirstOrDefault(x => x.Articulo == item.sArticulo);
                            dPrecio = dPrecio + a.Precio * a.Cantidad;
                        }

                        foreach (clsModeloTipoPromocion item in listaPromocionesPorArticuloPadreTres)
                            listaPromoTipoTres = clsControladorPromociones.obtenerIdPromocionesMontoIncremental(
                                xmlPadres.ToString(), dPrecio, item.iTipoPromocion, 3, xmlPromociones.ToString());
                    }
                }
                else
                {
                    List<clsModeloTipoPromocion> listaPromocionesPorArticuloPadreTres =
                        clsControladorPromociones.obtenerIdPromocionesPorArticuloPadreDos(xmlDetalle.ToString(), 3,
                            xmlPromociones.ToString());
                    if (listaPromocionesPorArticuloPadreTres.Count <= 0)
                        ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 3);
                }
                //-----------------------------------------------------------------------------------------------------

                //Por articulo padre id = 4
                List<clsModeloTipoPromocion> listaPromocionesPorArticuloPadreDos =
                    clsControladorPromociones.obtenerIdPromocionesPorArticuloPadreDos(xmlDetalle.ToString(), 4,
                        xmlPromociones.ToString());
                List<int> listaPromoTipoCuatro = new List<int>();
                if (listaPromocionesPorArticuloPadreDos.Count > 0)
                {
                    XElement xmlPadres = new XElement("Articulos",
                        listaPromocionesPorArticuloPadreDos.Select(i => new XElement("Articulo", i.sArticulo)));

                    double dPrecio = 0;
                    foreach (clsModeloTipoPromocion item in listaPromocionesPorArticuloPadreDos)
                    {
                        DM0312_MVentaDetalle a = ListVentaDetalle.FirstOrDefault(x => x.Articulo == item.sArticulo);
                        dPrecio = dPrecio + a.Precio * a.Cantidad;
                    }

                    foreach (clsModeloTipoPromocion item in listaPromocionesPorArticuloPadreDos)
                        listaPromoTipoCuatro = clsControladorPromociones.obtenerIdPromocionesMontoIncremental(
                            xmlPadres.ToString(), dPrecio, item.iTipoPromocion, 4, xmlPromociones.ToString());
                }

                if (listaPromocionesPorArticuloPadreDos.Count <= 0)
                    ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 4);

                //Por articulo padre id = 5
                List<clsModeloTipoPromocion> listaArticulosPromo =
                    clsControladorPromociones.obtenerArticulosDePromocionDetalle(xmlTipoCinco.ToString());
                //Se quita debido a que no activa otras promociones ocacionando un error
                //listaArticulosPromo = listaArticulosPromo.Where(x => x.sArticulo == sArticulo).ToList();
                List<clsModeloTipoPromocion> listaPromoTipoCinco = new List<clsModeloTipoPromocion>();
                if (listaArticulosPromo.Count > 0)
                {
                    int iTotalArticulos = 0;
                    foreach (IGrouping<string, clsModeloTipoPromocion> item in listaArticulosPromo
                                 .GroupBy(x => x.sArticulo).ToList())
                        if (!string.IsNullOrEmpty(item.Key))
                            iTotalArticulos += ListVentaDetalle.FirstOrDefault(x => x.Articulo == item.Key).Cantidad;
                    var agrupacion = listaArticulosPromo.GroupBy(x => new { x.iTipoPromocion })
                        .Select(g => new { g.Key.iTipoPromocion, Count = iTotalArticulos }).ToList();
                    foreach (var item in agrupacion)
                        listaPromoTipoCinco.AddRange(
                            clsControladorPromociones.obtenerIdPromocionesPorArticulo(item.Count, item.iTipoPromocion,
                                xmlPromociones.ToString()));
                }
                //-----------------------------------------------------------------------------------------------------

                //llenamos todas las promociones
                foreach (int idPromo in listaPromocionesPorMonto)
                    if (ListVentaDetalle.Where(x => x.iIdTipoPromocion == 1).ToList().Count <= 0)
                        //TIPO 1
                        listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta, iRenglon,
                            cbx_Almacen.Text, this.ArticulosIncluidos));
                foreach (int idPromo in listaPromocionesPorMontoEspecifico)
                {
                    int montonI = clsControladorPromociones.obtenerMontoIncremental(idPromo);
                    int iPzaMaximas = clsControladorPromociones.obtenerMaximoHijos(idPromo);
                    double dMontoPorPromocion = clsControladorPromociones.obtenerMontoMinimoPromocion(idPromo);
                    int iMaxArticulos =
                        calcularPzaMaximasPorMonto(dMontoPorPromocion, dTotalVenta, montonI, iPzaMaximas);
                    if (iMaxArticulos > montonI * iPzaMaximas) iMaxArticulos = montonI * iPzaMaximas;
                    DM0312_MVentaDetalle f = ListVentaDetalle.FirstOrDefault(x => x.iIdTipoPromocion == 2);

                    if (iMaxArticulos > suma)
                    {
                        frmArticulosPromocion.iCantidadPermitidaTipoDos = iMaxArticulos;
                        //TIPO 2
                        listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta, iRenglon,
                            cbx_Almacen.Text, this.ArticulosIncluidos, 0, iMaxArticulos));
                    }
                    else
                    {
                        DM0312_MVentaDetalle articulotipodos =
                            ListVentaDetalle.FirstOrDefault(x => x.Articulo == sArticulo);
                        if (articulotipodos.iIdTipoPromocion == 2)
                        {
                            ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 2);
                            frmArticulosPromocion.iCantidadPermitidaTipoDos = iMaxArticulos;
                            //TIPO 2
                            listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta,
                                iRenglon, cbx_Almacen.Text, this.ArticulosIncluidos, 0, iMaxArticulos));
                        }
                    }
                }

                foreach (int idPromo in listaPromoTipoTres)
                    //TIPO 3
                    listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta, iRenglon,
                        cbx_Almacen.Text, this.ArticulosIncluidos));
                foreach (int idPromo in listaPromoTipoCuatro)
                {
                    int montonI = clsControladorPromociones.obtenerMontoIncremental(idPromo);
                    int iPzaMaximas = clsControladorPromociones.obtenerMaximoHijos(idPromo);
                    double dMontoPorPromocion = clsControladorPromociones.obtenerMontoMinimoPromocion(idPromo);
                    int iMaxArticulos =
                        calcularPzaMaximasPorMonto(dMontoPorPromocion, dTotalVenta, montonI, iPzaMaximas);
                    if (iMaxArticulos > montonI * iPzaMaximas) iMaxArticulos = montonI * iPzaMaximas;
                    DM0312_MVentaDetalle f = ListVentaDetalle.FirstOrDefault(x => x.iIdTipoPromocion == 4);
                    frmArticulosPromocion.iCantidadPermitidaTipoDos = iMaxArticulos;

                    if (iMaxArticulos > suma)
                        //TIPO 4
                        listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta, iRenglon,
                            cbx_Almacen.Text, this.ArticulosIncluidos, 0, iMaxArticulos));
                }

                foreach (int idPromo in listaPromoTipoCinco.Select(x => x.iTipoPromocion).Distinct().ToList())
                {
                    int iPiezasMinimasActivarPromocion =
                        clsControladorPromociones.obtenerPiezasMinimasPromocion(idPromo);
                    int iPzaMaximas = clsControladorPromociones.obtenerMaximoHijos(idPromo);

                    listaArticulosPromo =
                        clsControladorPromociones.obtenerArticulosDePromocionDetalle(xmlTipoCinco.ToString());

                    int iTotalArticulos = 0;
                    foreach (IGrouping<string, clsModeloTipoPromocion> item in listaArticulosPromo
                                 .Where(x => x.iTipoPromocion == idPromo).GroupBy(x => x.sArticulo).ToList())
                        if (!string.IsNullOrEmpty(item.Key))
                            iTotalArticulos += ListVentaDetalle
                                .FirstOrDefault(x => x.Articulo == item.Key && x.idPromocion == 0).Cantidad;

                    var agrupacion = listaArticulosPromo.GroupBy(x => new { x.iTipoPromocion })
                        .Select(g => new { g.Key.iTipoPromocion, Count = iTotalArticulos }).ToList();

                    //Articulo en promociones
                    int iTotalPromos = listaPromos.Where(x => x.idPromocion == idPromo).Sum(x => x.Cantidad);

                    if (agrupacion.Where(x => x.iTipoPromocion == idPromo && x.Count >= iPiezasMinimasActivarPromocion)
                            .ToList().Count > 0)
                    {
                        double a = Math.Floor((double)iTotalArticulos / iPiezasMinimasActivarPromocion) * iPzaMaximas;
                        if (a != iTotalPromos)
                        {
                            frmArticulosPromocion.iCantidadPermitida = (int)a;
                            listaRegalo.AddRange(clsControladorPromociones.obtenerPromociones(idPromo, idVenta,
                                iRenglon, cbx_Almacen.Text, this.ArticulosIncluidos, iPrecio, (int)a));
                        }
                    }
                }

                if (listaRegalo.Count <= 0) return;

                if (Show)
                {
                    frmArticulosPromocion.lsCampanas = new List<string>();
                    frmArticulosPromocion.lsFamilias = new List<string>();
                    frmArticulosPromocion.lsLinea = new List<modeloLinea>();
                    foreach (clsModeloArtPromocion item in listaRegalo)
                    {
                        List<modeloLinea> existeVacio = frmArticulosPromocion.lsLinea
                            .Where(x => x.sLinea == "" && x.sFamilia == "").ToList();
                        if (existeVacio.Count <= 0)
                            frmArticulosPromocion.lsLinea.Add(new modeloLinea
                            {
                                sFamilia = "",
                                sLinea = ""
                            });

                        List<modeloLinea> existe = frmArticulosPromocion.lsLinea
                            .Where(x => x.sLinea == item.sLinea && item.sFamilia == item.sFamilia).ToList();

                        if (existe.Count <= 0)
                            frmArticulosPromocion.lsLinea.Add(new modeloLinea
                            {
                                sFamilia = item.sFamilia,
                                sLinea = item.sLinea
                            });

                        if (!frmArticulosPromocion.lsFamilias.Contains("")) frmArticulosPromocion.lsFamilias.Add("");

                        if (!frmArticulosPromocion.lsFamilias.Contains(item.sFamilia))
                            frmArticulosPromocion.lsFamilias.Add(item.sFamilia);

                        if (!frmArticulosPromocion.lsCampanas.Contains("")) frmArticulosPromocion.lsCampanas.Add("");

                        if (!frmArticulosPromocion.lsCampanas.Contains(item.sNombreCampaña))
                            frmArticulosPromocion.lsCampanas.Add(item.sNombreCampaña);
                    }
                }

                frmArticulosPromocion.lModeloPromocion = listaRegalo;

                List<clsModeloTipoPromocion> lista = new List<clsModeloTipoPromocion>();


                if (listaPromocionesPorMonto.Count > 0 || listaPromocionesPorMontoEspecifico.Count > 0)
                    foreach (DM0312_MVentaDetalle item in ListVentaDetalle.Where(x =>
                                 x.Articulo != null && x.idPromocion <= 0))
                    {
                        clsModeloTipoPromocion a = new clsModeloTipoPromocion
                        {
                            sArticulo = item.Articulo, iTipoPromocion = item.iIdTipoPromocion,
                            iCantidadPadres = item.Cantidad
                        };
                        if (!lista.Contains(a)) lista.Add(a);
                    }

                if (lista.Count <= 0)
                    for (int i = 0; i < listaArticulosPromo.Count; i++)
                        lista.Add(new clsModeloTipoPromocion
                        {
                            sArticulo = listaArticulosPromo[i].sArticulo,
                            iCantidadPadres = listaArticulosPromo[i].iCantidadPadres, iTipoPromocion = 5
                        });

                if (!bAvanzar) return;
                if (Show || Forzar)
                    if (frmArticulosPromocion.lModeloPromocion.Count > 0)
                    {
                        frmArticulosPromocion promocion =
                            new frmArticulosPromocion(lista, iCantidad, this.ArticulosIncluidos);
                        promocion.ShowDialog();
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de calcular cuantas piezas se puede llevar por una compra de monto maximo
        /// </summary>
        /// <param name="dMontoPorCampra">Monto para activar la venta</param>
        /// <param name="dMontoVenta">monto total de la venta</param>
        /// <param name="iCantidadIncremental">cuantas veces se puede repetir la promocion</param>
        /// <param name="iPzaMaximas">piezas maximas de la promocion</param>
        /// <returns></returns>
        private int calcularPzaMaximasPorMonto(double dMontoPorCampra, double dMontoVenta, int iCantidadIncremental,
            int iPzaMaximas)
        {
            int iPiezasMaximasCamp = 0;
            try
            {
                if (dMontoVenta < dMontoPorCampra)
                {
                    iPiezasMaximasCamp = 1 * iCantidadIncremental;
                }
                else
                {
                    double a = dMontoVenta / dMontoPorCampra;
                    iPiezasMaximasCamp = Convert.ToInt32(Math.Floor(a)) * iCantidadIncremental;
                }
            }
            catch (Exception ex)
            {
            }

            return iPiezasMaximasCamp;
        }


        /// <summary>
        ///     Metodo que se encarga de agregar los articlos de promocion a la venta.
        /// </summary>
        public void AgregarArticulosPromo()
        {
            if (!string.IsNullOrEmpty(frmArticulosPromocion.sArticuloP) &&
                frmArticulosPromocion.DialogResult == DialogResult.OK)
                ListVentaDetalle.RemoveAll(x =>
                    x.Articulo_Ligado == frmArticulosPromocion.sArticuloP && !x.Articulo.Contains("GARA"));
            else if (frmArticulosPromocion.Disminuir && frmArticulosPromocion.DialogResult == DialogResult.Cancel)
                ListVentaDetalle.RemoveAll(x =>
                    x.Articulo_Ligado == frmArticulosPromocion.sArticuloP && !x.Articulo.Contains("GARA"));


            List<int> promos = new List<int>();
            foreach (DM0312_MVentaDetalle item in frmArticulosPromocion.ListVentaDetalle)
            {
                if (!promos.Contains(item.idPromocion))
                    ListVentaDetalle.RemoveAll(x => x.idPromocion == item.idPromocion);
                DataTable dt = new DataTable();
                dt = controlador.BuscaArticulos_VentaDetalle(item.Articulo.Trim(), Almacen, 1);
                if (dt.Rows.Count > 0)
                {
                    //llenado del modelo por el articulo nuevo
                    item.Articulo = dt.Rows[0].ItemArray[0].ToString();
                    item.Descripcion = dt.Rows[0].ItemArray[1].ToString();
                    item.Linea = dt.Rows[0].ItemArray[2].ToString();
                    item.Disponible = Convert.ToInt32(dt.Rows[0].ItemArray[4].ToString());
                    item.impuesto = Convert.ToDouble(dt.Rows[0].ItemArray[5].ToString());
                    item.Tipo = dt.Rows[0].ItemArray[6].ToString();
                    item.Unidad = dt.Rows[0].ItemArray[7].ToString();
                    item.PropreListaID = controlador.GetPropreListaID(idVenta, item.Articulo, cbx_RedimirM.Checked);
                }

                /*costo*/
                double costoRegalo =
                    controlador.ExecspVerCosto(ClaseEstatica.Usuario.sucursal, item.Articulo, item.Unidad);

                double porcentajeDesc = clsControladorPromociones.ObtenerDescuento(item.idPromocion, item.Articulo);

                double value_Regalo = Math.Truncate(porcentajeDesc * costoRegalo) / 100;

                double vCosto = costoRegalo - value_Regalo;

                item.Costo = vCosto;

                item.Costo_ = vCosto.ToString("C", Thread.CurrentThread.CurrentCulture);

                /*guarda modelo si es canal 34*/
                //if (canalC == 34)
                //{
                //    CUsuarioDes.InsertVentaD_(item, idVenta, canalC, cbx_Almacen.Text, cbx_Agente.Text, 1);
                //}

                item.Total = item.Precio * item.Cantidad;

                item.TotalS = (item.Precio * item.Cantidad).ToString("C", Thread.CurrentThread.CurrentCulture);

                //listas para calcular renglones 
                if (ListVentaDetalle.Count == 0)
                    item.RenglonID = 1;
                else
                    item.RenglonID = ListVentaDetalle.Count + 1;

                item.Renglon = 2048 * item.RenglonID;

                DM0312_MVentaDetalle art =
                    ListVentaDetalle.FirstOrDefault(a => a.Articulo == item.Articulo && a.bArtPromocion);
                if (art != null) ListVentaDetalle.RemoveAll(a => a.Articulo == art.Articulo && a.bArtPromocion);
                promos.Add(item.idPromocion);
                ListVentaDetalle.Add(item);
            }

            ListVentaDetalle.RemoveAll(x => x.Articulo == null);
            DM0312_MVentaDetalle modelvacio = new DM0312_MVentaDetalle();
            ListVentaDetalle.Add(modelvacio);
            frmArticulosPromocion.sArticuloP = string.Empty;
        }

        public List<string> ArtAplica(string sArticulo, int iCantidad)
        {
            List<string> lsNombres = new List<string>();

            List<int> lsIdPromociones =
                clsControladorPromociones.AplicaCanalSucursal(ClaseEstatica.Usuario.sucursal, canalC);
            DateTime dtFechaActual = clsControladorPromociones.getDate();
            if (lsIdPromociones.Count > 0)
                foreach (int iPromocion in lsIdPromociones)
                {
                    List<clsModeloPromocion> lsModeloPromocion = new List<clsModeloPromocion>();
                    bool bAplicaUen = false;
                    bool bAutorizada = false;
                    bool bFechaI = false;
                    bool bFechaF = false;
                    bool bExepcion = true;
                    lsModeloPromocion = clsControladorPromociones.ObtenerPromocion(iPromocion);

                    if (lsModeloPromocion.Count > 0)
                    {
                        //Validar UEN
                        if (lsModeloPromocion.Exists(x => x.iUen == ClaseEstatica.Usuario.Uen)) bAplicaUen = true;
                        //Validar que la promoción se encuentra autorizada.
                        if (lsModeloPromocion.Exists(x => x.sEstatus == "Autorizada")) bAutorizada = true;

                        if (bAplicaUen && bAutorizada)
                        {
                            //Validar que la promoción se encuentre vigente.
                            string vFechaInicio = lsModeloPromocion.Select(x => x.sFechaInicio).First();
                            string vFechaFin = lsModeloPromocion.Select(x => x.sFechaFin).First();
                            //Conversion de string a fecha.
                            DateTime dtFechaInicio = Convert.ToDateTime(vFechaInicio);
                            DateTime dtFechaFin = Convert.ToDateTime(vFechaFin);
                            //Calculos de fecha.
                            int iComparacionFechaInicio =
                                DateTime.Compare(Convert.ToDateTime(dtFechaInicio.ToString("yyyy/MM/dd")),
                                    Convert.ToDateTime(dtFechaActual.ToString("yyyy/MM/dd")));
                            if (iComparacionFechaInicio < 0 || iComparacionFechaInicio == 0) bFechaI = true;
                            int iComparacionFechaFin =
                                DateTime.Compare(Convert.ToDateTime(dtFechaFin.ToString("yyyy/MM/dd")),
                                    Convert.ToDateTime(dtFechaActual.ToString("yyyy/MM/dd")));
                            if (iComparacionFechaFin > 0 || iComparacionFechaInicio == 0) bFechaF = true;
                            //TODO: Modificar exepciones padre, separar el campo por comas y comparar.
                            if (lsConfiguracion.Exists(x => x.sExcepcionP == sArticulo)) bExepcion = false;
                        }

                        if (bFechaI && bFechaF && bExepcion)
                        {
                            lsConfiguracion = clsControladorPromociones.ObtenerPromocionD(iPromocion);
                            frmArticulosPromocion.lsConfiguracion = lsConfiguracion;

                            if (lsConfiguracion.Count > 0)
                                foreach (clsModeloPromocionDetalle item in lsConfiguracion)
                                {
                                    string vFamilia = clsControladorPromociones.ObtenerFamilia(sArticulo);
                                    string vLinea = clsControladorPromociones.ObtenerLinea(sArticulo);

                                    if (vFamilia == item.sFamiliaP && (vLinea == item.sLineaP || item.sLineaP == "") &&
                                        (sArticulo == item.sArticuloP || item.sArticuloP == "") &&
                                        iCantidad >= item.iPzaMin)
                                    {
                                        //model_.idPromocion = item.iIdPromocion;
                                        string vPromo = clsControladorPromociones.ObtenerNombrePromo(iPromocion);

                                        if (!lsNombres.Exists(x => x == vPromo))
                                            lsNombres.Add(vPromo);
                                    }
                                }
                        }
                    }
                }

            return lsNombres;
        }

        #endregion


        public bool CandadoEdadCondicion(string cliente)
        {
            int anios = 0;
            DM0312_CVentanaEntrada controladorV = new DM0312_CVentanaEntrada();
            anios = controlador.CandadoEdadAños("FACTURA");
            int numDoc = 0;
            numDoc = controlador.numeroDocumentos(cbx_Condicion.Text);

            if (numDoc == 0) return true;

            DateTime nacimiento = controladorV.FechaNacimientoCliente(cliente); //Fecha de nacimiento
            int edad = DateTime.Today.AddMonths(numDoc).AddTicks(-nacimiento.Ticks).Year - 1;

            if (edad > anios && anios != 0)
            {
                MessageBox.Show("Cliente " + cliente + " no califica por edad", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Obtiene los parametros para insertar anticipos
        /// </summary>
        /// <param name="ParametrosAnticipos">ref string[]</param>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 02/11/17
        private bool ObtenerAnticipos(ref string[] ParametrosAnticipos)
        {
            bool TieneAnticipos = false;
            if (montoTotal.ToString() != "0")
            {
                MAnticipos NuevoAnticipo = new MAnticipos();
                foreach (Control ctrl in flp_FormaPago.Controls)
                    if (ctrl is ComboBox)
                    {
                        ComboBox cb_FormaPago = (ComboBox)ctrl;
                        NuevoAnticipo = new MAnticipos();
                        NuevoAnticipo.FormaPago = cb_FormaPago.Text;
                        TieneAnticipos = true;
                    }
                    else if (ctrl is TextBox)
                    {
                        TextBox txt_Anticipo = (TextBox)ctrl;
                        if (txt_Anticipo.Name == "tb_Monto")
                        {
                            if (txt_Anticipo.Text != string.Empty) NuevoAnticipo.Importe = txt_Anticipo.Text;
                        }
                        else if (txt_Anticipo.Name == "tb_Referencia")
                        {
                            if (txt_Anticipo.Text != string.Empty) NuevoAnticipo.Referencia = txt_Anticipo.Text;
                            ListaAnticipos.Add(NuevoAnticipo);
                        }
                    }
            }


            string Referencia1 = "";
            string Referencia2 = "";
            string Referencia3 = "";
            string Referencia4 = "";
            string Referencia5 = "";
            string Monto1 = "";
            string Monto2 = "";
            string Monto3 = "";
            string Monto4 = "";
            string Monto5 = "";
            string FormaPago1 = "";
            string FormaPago2 = "";
            string FormaPago3 = "";
            string FormaPago4 = "";
            string FormaPago5 = "";

            if (ListaAnticipos.Count > 0)
                LLenarListaAnticipos(out Referencia1, out Monto1, out FormaPago1, ListaAnticipos[0]);
            if (ListaAnticipos.Count > 1)
                LLenarListaAnticipos(out Referencia2, out Monto2, out FormaPago2, ListaAnticipos[1]);
            if (ListaAnticipos.Count > 2)
                LLenarListaAnticipos(out Referencia3, out Monto3, out FormaPago3, ListaAnticipos[2]);
            if (ListaAnticipos.Count > 3)
                LLenarListaAnticipos(out Referencia4, out Monto4, out FormaPago4, ListaAnticipos[3]);
            if (ListaAnticipos.Count > 4)
                LLenarListaAnticipos(out Referencia5, out Monto5, out FormaPago5, ListaAnticipos[4]);

            string ctadinero = controllerExplorador.ValidaCajaUsuario(ClaseEstatica.Usuario.usuario);

            string MovAnticipo = "Anticipo Contado";
            if (TipoMovimiento == "Solicitud Credito")
                MovAnticipo = "Enganche";
            else if (TipoMovimiento == "Pedido Mayoreo") MovAnticipo = "Anticipo Mayoreo";

            //-ErrorIVA
            double iva = controladorV.getIVA();
            double totalMonto = montoTotal;
            double MontoSubtotal = totalMonto / (1 + iva);
            double impuestosMonto = MontoSubtotal * iva;

            ParametrosAnticipos = new[]
            {
                MovAnticipo, ClaseEstatica.Usuario.usuario, "", cbx_Cliente.Text, EnviarA.ToString(),
                ctadinero, MontoSubtotal.ToString("0.0000"), impuestosMonto.ToString("0.0000"),
                FormaPago1, FormaPago2, FormaPago3, FormaPago4, FormaPago5,
                Referencia1, Referencia2, Referencia3, Referencia4, Referencia5,
                Monto1, Monto2, Monto3, Monto4, Monto5,
                cbx_Agente.Text, ClaseEstatica.Usuario.sucursal.ToString(), ClaseEstatica.Usuario.sucursal.ToString(),
                controlador.ObtenerCajero(), ClaseEstatica.Usuario.Uen.ToString(), ClaseEstatica.WorkStation.ToString()
            };

            return TieneAnticipos;
        }

        private void LLenarListaAnticipos(out string Referencia, out string Monto, out string FormaPago,
            MAnticipos Anticipo)
        {
            Referencia = Anticipo.Referencia;
            Monto = Anticipo.Importe;
            FormaPago = Anticipo.FormaPago;
        }

        /// <summary>
        ///     Checa si el movimiento puede ser afectado o necesita cambiar de situacion
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 04/11/17
        private bool PuedeAfectar()
        {
            bool PuedeAfectar = false;

            string comando =
                "SELECT PermiteAfectacion FROM MovSituacion WITH(NOLOCK) WHERE Estatus='SINAFECTAR' and Modulo='VTAS' AND Mov = @Mov AND Flujo='Inicial Todas'";
            SqlCommand sqlCommand = new SqlCommand(comando, ClaseEstatica.ConexionEstatica);
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.Parameters.AddWithValue("@Mov", TipoMovimiento);
            string cadenaPuedeAfectar = string.Empty;
            try
            {
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        cadenaPuedeAfectar = dr["PermiteAfectacion"].ToString();
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("PuedeAfectar", "DM0312_PuntoDeVenta.cs", ex);
                MessageBox.Show(ex.Message + " function PuedeAfectar, class: DM0312_PuntoDeVenta.cs");
            }

            if (cadenaPuedeAfectar == "False")
                PuedeAfectar = false;
            else
                PuedeAfectar = true;

            return PuedeAfectar;
        }

        /// <summary>
        ///     Abre la forma de situaciones para cambiar la situacion de la venta
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        private void btn_situaciones_Click(object sender, EventArgs e)
        {
            ValidaCamposObligatorios();
            if (obligatorio != true)
            {
                if (!guardarArticulos())
                    return;
                if (dvg_detalleVenta.Rows.Count < 2)
                {
                    MessageBox.Show("No hay articulos añadidos", "Mensaje!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }

                Dm0312DetalleSituaciones.IdVenta = idVenta;
                Dm0312DetalleSituaciones.Estatus = "SINAFECTAR";
                Dm0312DetalleSituaciones.Mov = TipoMovimiento;
                Dm0312DetalleSituaciones.MovId = "";
                List<MSituaciones> ListaSituaciones = CSituaciones.ObtenerSituaciones();
                Dm0312DetalleSituaciones.Situaciones = ListaSituaciones;

                List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
                CDetalleVenta.CargaMovimientoCreado(idVenta, idVenta, VentasSeleccionadas);

                Dm0312DetalleSituaciones situaciones = new Dm0312DetalleSituaciones(VentasSeleccionadas);
                situaciones.ShowDialog();
                if (situaciones.ValidaSituacion)
                {
                    ListaSituaciones = CSituaciones.ObtenerSituaciones();
                    AbrirDetalle(VentasSeleccionadas);
                }
            }
        }

        /// <summary>
        ///     Abre el detalle del mov afectado / creado
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void AbrirDetalle(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_ExploradorVentas.ListaExplorador = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
            controllerExplorador.LLenadoListaArticulosSeleccionados(VentasSeleccionadas);
            DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
            ClienteC = controlador.ClienteConCuenta(Codigo);
            if (Canal == 3 || Canal == 76)
            {
                detalle.ClienteC = ClienteC;
                detalle.ClienteNuevo = ClienteNuevo;
            }

            detalle.FromPuntoVenta = true;
            detalle = (DM0312_DetalleVenta)UsuarioAcceso.AplicarVistas(detalle);
            string[] ParametrosAnticipos = { "" };
            if (ObtenerAnticipos(ref ParametrosAnticipos))
            {
                detalle.AnticiposEnviados = true;
                detalle.ParametrosAnticipos = ParametrosAnticipos;
            }

            if (Alm.Trim() != almacenOrigen.Trim()) ActualizarAlmacen = true;
            CerrarVenta = true;
            Close();
            detalle.Show();
            detalle.TopMost = true;
            detalle.Focus();
        }

        /// <summary>
        ///     Ordenamiento datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        private void dgv_datosEntrega_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(BitacoraEntregas);
            funciones.OrderGridview(dgv_datosEntrega, e.ColumnIndex, ref TempObjects,
                BitacoraEntregas.GetType().GetGenericArguments().Single());
            BitacoraEntregas = TempObjects.OfType<DatosEntrega>().ToList();
            dgv_datosEntrega_CellClick(null, null);
        }

        /// <summary>
        ///     remover formas de pago
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/10/17
        private void RemoverAnticipos()
        {
            string comboboxSelected = string.Empty;
            for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
                if (FormasPagoAgregadas.Count > 1)
                {
                    if (flp_FormaPago.Controls[i] is ComboBox)
                    {
                        ComboBox cb_monto = (ComboBox)flp_FormaPago.Controls[i];
                        comboboxSelected = cb_monto.Text;
                    }

                    if (flp_FormaPago.Controls[i] is Label && flp_FormaPago.Controls[i].Name == "lbl_formaPago")
                    {
                        LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                        FormasPagoAgregadas.Remove(comboboxSelected);
                    }

                    flp_FormaPago.Controls.RemoveAt(i);
                }
                else
                {
                    if (flp_FormaPago.Controls[i] is TextBox)
                    {
                        TextBox txt_monto = (TextBox)flp_FormaPago.Controls[i];
                        if (txt_monto.Name == "tb_Monto") txt_monto.Text = "0";
                    }
                }

            ListaAnticipos.Clear();
            AnticipoMontoTotal();
            Tb_efectivoRecibido.Text = "0";
        }

        #endregion

        #region Mops

        public bool validarMops(string sClinte, int iCanal, string sCondicion, string sTipoCliente, double dImporte)
        {
            bool bMopsCorrectos = false;

            //-Mops
            List<DateTime> lsitaMops = new List<DateTime>();
            List<mopsModel> lista = new List<mopsModel>();

            lista = controlador.obtenerInformacionMops(sClinte);
            if (lista.Count > 0)
            {
                lsitaMops = new List<DateTime>();

                foreach (mopsModel item in lista)
                {
                    DateTime dtFecha;
                    DateTime dtFechaFin;
                    DateTime dtFechaServidor = controllerExplorador.FechaActualServidor();
                    if (item.dtVencimineto < item.dtFechaPrimerPago)
                        dtFecha = GetLastDayOfMonth(item.dtVencimineto);
                    else
                        dtFecha = GetLastDayOfMonth(item.dtFechaPrimerPago);

                    if (item.dSaldo > 0)
                        dtFechaFin = GetLastDayOfMonth(dtFechaServidor);
                    else
                        dtFechaFin = GetLastDayOfMonth(item.dtUltimaConclusion);

                    double iMesesMops = 0;
                    if (controlador.validaRs(item.iUen, item.iCanalVenta, item.sMov))
                        iMesesMops = controlador.obtenerRs(item.iUen, item.iCanalVenta, item.sMov);
                    else
                        iMesesMops = controlador.obtenerRs(0, 0, item.sMov);

                    if (iMesesMops != 0)
                        while (dtFecha < dtFechaFin)
                        {
                            int dateSpan = GetMonths(dtFecha, dtFechaServidor);

                            if (dateSpan < iMesesMops)
                            {
                                DateTime fechaNueva = new DateTime(dtFecha.Year, dtFecha.Month, 1);
                                if (!lsitaMops.Contains(fechaNueva)) lsitaMops.Add(fechaNueva);
                            }

                            dtFecha = dtFecha.AddMonths(1);
                        }
                }

                double vImporte = lista.Sum(x => x.dSaldo) + dImporte;
                int iDocumentos = controlador.obtenerDocumentos(sCondicion);
                List<double> listaMontoClienteCasa =
                    controlador.obtenerMontosClienteCasa(sTipoCliente, iCanal, iDocumentos, lsitaMops.Count);
                if (listaMontoClienteCasa.Count > 0)
                {
                    List<double> bDato = listaMontoClienteCasa.Where(x => x > vImporte).ToList();
                    if (bDato.Count > 0) bMopsCorrectos = true;
                }

                if (!bMopsCorrectos)
                {
                    string sTipoCredito = controlador.obtenerTipoCredito(sClinte);
                    if (!string.IsNullOrEmpty(sTipoCredito))
                    {
                        List<double> lsitaMontosPoliticas =
                            controlador.obtenerMontosPoliticas(sTipoCliente, canalC, iDocumentos, sTipoCredito);
                        if (lsitaMontosPoliticas.Count > 0)
                        {
                            List<double> bPuedePolitica = lsitaMontosPoliticas.Where(x => x > vImporte).ToList();
                            if (bPuedePolitica.Count > 0) bMopsCorrectos = true;
                        }
                    }
                }
            }

            return bMopsCorrectos;
        }

        public DateTime GetLastDayOfMonth(DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, DateTime.DaysInMonth(dateTime.Year, dateTime.Month));
        }

        public int GetMonths(DateTime startDate, DateTime endDate)
        {
            int months = endDate.Year * 12 + endDate.Month - (startDate.Year * 12 + startDate.Month);

            if (endDate.Day >= startDate.Day) months++;

            return months;
        }

        public static int MonthDiff(DateTime d1, DateTime d2)
        {
            int retVal = 0;

            // Calculate the number of years represented and multiply by 12
            // Substract the month number from the total
            // Substract the difference of the second month and 12 from the total
            retVal = (d1.Year - d2.Year) * 12;
            retVal = retVal - d1.Month;
            retVal = retVal - (12 - d2.Month);

            return retVal;
        }

        public static int GetMonthsBetween(DateTime from, DateTime to)
        {
            if (from > to) return GetMonthsBetween(to, from);

            int monthDiff = Math.Abs(to.Year * 12 + (to.Month - 1) - (from.Year * 12 + (from.Month - 1)));

            if (from.AddMonths(monthDiff) > to || to.Day < from.Day)
                return monthDiff - 1;
            return monthDiff;
        }

        #endregion
    }
}