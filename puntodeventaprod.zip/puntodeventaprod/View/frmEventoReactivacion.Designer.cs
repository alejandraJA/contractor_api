﻿using System.ComponentModel;

namespace PuntoVenta.View {
    partial class frmEventoReactivacion {

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_MovID = new System.Windows.Forms.Label();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_reactivacion = new System.Windows.Forms.Label();
            this.btn_reactivacion = new System.Windows.Forms.Button();
            this.lbl_msgReactivacion = new System.Windows.Forms.Label();
            this.btn_complemento = new System.Windows.Forms.Button();
            this.btn_liberacion = new System.Windows.Forms.Button();
            this.lbl_reanalisis = new System.Windows.Forms.Label();
            this.lbl_fechaSeguimiento = new System.Windows.Forms.Label();
            this.btn_reanalisis = new System.Windows.Forms.Button();
            this.btn_fechaSeguimiento = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_Mov = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(3, 4);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(47, 15);
            this.lbl_Cliente.TabIndex = 1;
            this.lbl_Cliente.Text = "Cliente";
            this.lbl_Cliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_MovID
            // 
            this.lbl_MovID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_MovID.AutoSize = true;
            this.lbl_MovID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MovID.Location = new System.Drawing.Point(578, 24);
            this.lbl_MovID.Name = "lbl_MovID";
            this.lbl_MovID.Size = new System.Drawing.Size(29, 15);
            this.lbl_MovID.TabIndex = 2;
            this.lbl_MovID.Text = "Mov";
            this.lbl_MovID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = global::PuntoVenta.Properties.Resources.icons8_volver_30;
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(63, 74);
            this.btn_Regresar.TabIndex = 4;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.btn_Regresar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 269F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(610, 269);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl_reactivacion);
            this.panel1.Controls.Add(this.btn_reactivacion);
            this.panel1.Controls.Add(this.lbl_msgReactivacion);
            this.panel1.Controls.Add(this.btn_complemento);
            this.panel1.Controls.Add(this.btn_liberacion);
            this.panel1.Controls.Add(this.lbl_reanalisis);
            this.panel1.Controls.Add(this.lbl_fechaSeguimiento);
            this.panel1.Controls.Add(this.btn_reanalisis);
            this.panel1.Controls.Add(this.btn_fechaSeguimiento);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(72, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(535, 263);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lbl_reactivacion
            // 
            this.lbl_reactivacion.BackColor = System.Drawing.Color.Transparent;
            this.lbl_reactivacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_reactivacion.Location = new System.Drawing.Point(72, 3);
            this.lbl_reactivacion.Name = "lbl_reactivacion";
            this.lbl_reactivacion.Size = new System.Drawing.Size(124, 61);
            this.lbl_reactivacion.TabIndex = 20;
            this.lbl_reactivacion.Text = "Reactivación";
            this.lbl_reactivacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_reactivacion
            // 
            this.btn_reactivacion.BackColor = System.Drawing.Color.White;
            this.btn_reactivacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_reactivacion.FlatAppearance.BorderSize = 0;
            this.btn_reactivacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reactivacion.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reactivacion.Image = global::PuntoVenta.Properties.Resources.icons8_calendar_plus_48;
            this.btn_reactivacion.Location = new System.Drawing.Point(3, 3);
            this.btn_reactivacion.Name = "btn_reactivacion";
            this.btn_reactivacion.Size = new System.Drawing.Size(64, 64);
            this.btn_reactivacion.TabIndex = 21;
            this.btn_reactivacion.Text = "\r\n";
            this.btn_reactivacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_reactivacion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_reactivacion.UseVisualStyleBackColor = false;
            this.btn_reactivacion.Click += new System.EventHandler(this.btn_reactivacion_Click);
            // 
            // lbl_msgReactivacion
            // 
            this.lbl_msgReactivacion.BackColor = System.Drawing.Color.Transparent;
            this.lbl_msgReactivacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_msgReactivacion.Location = new System.Drawing.Point(3, 3);
            this.lbl_msgReactivacion.Name = "lbl_msgReactivacion";
            this.lbl_msgReactivacion.Size = new System.Drawing.Size(362, 67);
            this.lbl_msgReactivacion.TabIndex = 1;
            this.lbl_msgReactivacion.Text = "Selecciones el tipo de reactivación que desea realizar";
            this.lbl_msgReactivacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_msgReactivacion.Visible = false;
            // 
            // btn_complemento
            // 
            this.btn_complemento.Location = new System.Drawing.Point(202, 143);
            this.btn_complemento.Name = "btn_complemento";
            this.btn_complemento.Size = new System.Drawing.Size(119, 64);
            this.btn_complemento.TabIndex = 17;
            this.btn_complemento.Text = "COMPLEMENTO";
            this.btn_complemento.UseVisualStyleBackColor = true;
            this.btn_complemento.Visible = false;
            this.btn_complemento.Click += new System.EventHandler(this.btn_complemento_Click);
            // 
            // btn_liberacion
            // 
            this.btn_liberacion.Location = new System.Drawing.Point(202, 73);
            this.btn_liberacion.Name = "btn_liberacion";
            this.btn_liberacion.Size = new System.Drawing.Size(119, 64);
            this.btn_liberacion.TabIndex = 11;
            this.btn_liberacion.Text = "LIBERACIÓN";
            this.btn_liberacion.UseVisualStyleBackColor = true;
            this.btn_liberacion.Visible = false;
            this.btn_liberacion.Click += new System.EventHandler(this.btn_liberacion_Click);
            // 
            // lbl_reanalisis
            // 
            this.lbl_reanalisis.BackColor = System.Drawing.Color.Transparent;
            this.lbl_reanalisis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_reanalisis.Location = new System.Drawing.Point(72, 143);
            this.lbl_reanalisis.Name = "lbl_reanalisis";
            this.lbl_reanalisis.Size = new System.Drawing.Size(124, 64);
            this.lbl_reanalisis.TabIndex = 10;
            this.lbl_reanalisis.Text = "Reanálisis";
            this.lbl_reanalisis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_fechaSeguimiento
            // 
            this.lbl_fechaSeguimiento.BackColor = System.Drawing.Color.Transparent;
            this.lbl_fechaSeguimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fechaSeguimiento.Location = new System.Drawing.Point(72, 73);
            this.lbl_fechaSeguimiento.Name = "lbl_fechaSeguimiento";
            this.lbl_fechaSeguimiento.Size = new System.Drawing.Size(124, 64);
            this.lbl_fechaSeguimiento.TabIndex = 9;
            this.lbl_fechaSeguimiento.Text = "Fecha Seguimiento";
            this.lbl_fechaSeguimiento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_reanalisis
            // 
            this.btn_reanalisis.BackColor = System.Drawing.Color.White;
            this.btn_reanalisis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_reanalisis.FlatAppearance.BorderSize = 0;
            this.btn_reanalisis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reanalisis.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reanalisis.Image = global::PuntoVenta.Properties.Resources.icons8_calendar_plus_48;
            this.btn_reanalisis.Location = new System.Drawing.Point(3, 143);
            this.btn_reanalisis.Name = "btn_reanalisis";
            this.btn_reanalisis.Size = new System.Drawing.Size(64, 64);
            this.btn_reanalisis.TabIndex = 7;
            this.btn_reanalisis.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_reanalisis.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_reanalisis.UseVisualStyleBackColor = false;
            this.btn_reanalisis.Click += new System.EventHandler(this.btn_reanalisis_Click);
            // 
            // btn_fechaSeguimiento
            // 
            this.btn_fechaSeguimiento.BackColor = System.Drawing.Color.White;
            this.btn_fechaSeguimiento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fechaSeguimiento.FlatAppearance.BorderSize = 0;
            this.btn_fechaSeguimiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechaSeguimiento.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fechaSeguimiento.Image = global::PuntoVenta.Properties.Resources.icons8_event_48;
            this.btn_fechaSeguimiento.Location = new System.Drawing.Point(3, 73);
            this.btn_fechaSeguimiento.Name = "btn_fechaSeguimiento";
            this.btn_fechaSeguimiento.Size = new System.Drawing.Size(64, 64);
            this.btn_fechaSeguimiento.TabIndex = 19;
            this.btn_fechaSeguimiento.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_fechaSeguimiento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_fechaSeguimiento.UseVisualStyleBackColor = false;
            this.btn_fechaSeguimiento.Click += new System.EventHandler(this.btn_fechaSeguimiento_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_Mov, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_Cliente, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_MovID, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 287);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(610, 39);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // lbl_Mov
            // 
            this.lbl_Mov.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_Mov.AutoSize = true;
            this.lbl_Mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mov.Location = new System.Drawing.Point(3, 24);
            this.lbl_Mov.Name = "lbl_Mov";
            this.lbl_Mov.Size = new System.Drawing.Size(77, 15);
            this.lbl_Mov.TabIndex = 3;
            this.lbl_Mov.Text = "Movimiento :";
            this.lbl_Mov.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmEventoReactivacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(634, 338);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frmEventoReactivacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reactivación / Seguimiento / Reanálisis";
            this.Load += new System.EventHandler(this.frmEventoReactivacion_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmEventoReactivacion_KeyDown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Label lbl_reactivacion;
        private System.Windows.Forms.Button btn_reanalisis;
        
        private System.Windows.Forms.Label lbl_reanalisis;

        private System.Windows.Forms.Button btn_reactivacion;

        private System.Windows.Forms.Label lbl_msgReactivacion;

        private System.Windows.Forms.Button btn_liberacion;
        private System.Windows.Forms.Button btn_complemento;
        private System.Windows.Forms.Label lbl_fechaSeguimiento;

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;

        private System.Windows.Forms.Panel panel1;
        
        private System.Windows.Forms.Button btn_fechaSeguimiento;

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        
        private System.Windows.Forms.Label lbl_Cliente;
        
        private System.Windows.Forms.Label lbl_Mov;
        
        private System.Windows.Forms.Label lbl_MovID;

        private System.Windows.Forms.Button btn_Regresar;

        #endregion
        
        
    }
}