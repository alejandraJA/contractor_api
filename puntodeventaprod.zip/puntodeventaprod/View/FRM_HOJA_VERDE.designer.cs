﻿namespace PuntoVenta
{
    partial class FRM_HOJA_VERDE
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRM_HOJA_VERDE));
            this.gb_DatosEncabezado = new System.Windows.Forms.GroupBox();
            this.lbl_FechaRes = new System.Windows.Forms.Label();
            this.chk_SoloReferencias = new System.Windows.Forms.CheckBox();
            this.chk_SoloAval = new System.Windows.Forms.CheckBox();
            this.dtp_Fecha = new System.Windows.Forms.DateTimePicker();
            this.txt_NumSolicitud = new System.Windows.Forms.TextBox();
            this.lbl_nSolicitud = new System.Windows.Forms.Label();
            this.txt_NumProspecto = new System.Windows.Forms.TextBox();
            this.lbl_nProspecto = new System.Windows.Forms.Label();
            this.txt_Importe = new System.Windows.Forms.TextBox();
            this.lbl_importe = new System.Windows.Forms.Label();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.gb_DGCte = new System.Windows.Forms.GroupBox();
            this.ddl_CteRecomParentesco = new System.Windows.Forms.ComboBox();
            this.txt_CteObservaciones = new System.Windows.Forms.TextBox();
            this.txt_CteDireccionRecom = new System.Windows.Forms.TextBox();
            this.txt_CteDomAnterior = new System.Windows.Forms.TextBox();
            this.txt_CteRecomendado = new System.Windows.Forms.TextBox();
            this.txt_CteMunicipioAnterior = new System.Windows.Forms.TextBox();
            this.lbl_CteMunicipioAnterior = new System.Windows.Forms.Label();
            this.txt_CteColoniaAnterior = new System.Windows.Forms.TextBox();
            this.txt_CteCpAnterior = new System.Windows.Forms.TextBox();
            this.lbl_CteObservaciones = new System.Windows.Forms.Label();
            this.lbl_CteRecomParentezco = new System.Windows.Forms.Label();
            this.lbl_CteDireccionRecom = new System.Windows.Forms.Label();
            this.lbl_CteRecomendado = new System.Windows.Forms.Label();
            this.lbl_CteCpAnterior = new System.Windows.Forms.Label();
            this.lbl_CteColoniaAnterior = new System.Windows.Forms.Label();
            this.lbl_CteDomAnterior = new System.Windows.Forms.Label();
            this.gb_obligatorioDGCte = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ddl_CteCalidadVive = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_ObligatorioConyugeCte = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_Obligatorio = new System.Windows.Forms.Label();
            this.ddl_CteEdoCivil = new System.Windows.Forms.ComboBox();
            this.dtp_CteConyugeFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.dtp_CteFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.txt_CteMunicipio = new System.Windows.Forms.TextBox();
            this.txt_CteCruces = new System.Windows.Forms.TextBox();
            this.lbl_CteCalidadVive = new System.Windows.Forms.Label();
            this.lbl_CteMunicipio = new System.Windows.Forms.Label();
            this.txt_CteDomicilio = new System.Windows.Forms.TextBox();
            this.txt_CteConyuge = new System.Windows.Forms.TextBox();
            this.txt_CteTelefono = new System.Windows.Forms.TextBox();
            this.txt_CteColonia = new System.Windows.Forms.TextBox();
            this.txt_CteAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_CteCp = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEdad = new System.Windows.Forms.TextBox();
            this.txt_CteEdad = new System.Windows.Forms.TextBox();
            this.txt_CteNombre = new System.Windows.Forms.TextBox();
            this.lbl_CteEdoCivil = new System.Windows.Forms.Label();
            this.lbl_CteTelefono = new System.Windows.Forms.Label();
            this.lbl_CteCp = new System.Windows.Forms.Label();
            this.lbl_CteColonia = new System.Windows.Forms.Label();
            this.lbl_CteCruces = new System.Windows.Forms.Label();
            this.lbl_CteAntiguedad = new System.Windows.Forms.Label();
            this.lbl_CteDomicilio = new System.Windows.Forms.Label();
            this.lbl_CteConyugeFechaNacimiento = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEdad = new System.Windows.Forms.Label();
            this.lbl_CteConyuge = new System.Windows.Forms.Label();
            this.lbl_CteFechaNacimiento = new System.Windows.Forms.Label();
            this.lbl_CteEdad = new System.Windows.Forms.Label();
            this.lbl_CteNombre = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_ObligatorioFechaNacCnyugeCte = new System.Windows.Forms.Label();
            this.lbl_ObligatorioEdadConyugeCte = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_EmpCte1 = new System.Windows.Forms.Label();
            this.gb_DECte = new System.Windows.Forms.GroupBox();
            this.gb_ObligatorioDECte = new System.Windows.Forms.GroupBox();
            this.lbl_EmpCte2 = new System.Windows.Forms.Label();
            this.lbl_EmpCte4 = new System.Windows.Forms.Label();
            this.ddl_CteEmpPeriodoIngresos = new System.Windows.Forms.ComboBox();
            this.txt_CteEmpPuestoJefe = new System.Windows.Forms.TextBox();
            this.txt_CteEmpIngresos = new System.Windows.Forms.TextBox();
            this.txt_CteEmpAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_CteEmpJefe = new System.Windows.Forms.TextBox();
            this.lbl_EmpCte3 = new System.Windows.Forms.Label();
            this.lbl_empCtePuestoJefe = new System.Windows.Forms.Label();
            this.lbl_empCteJefe = new System.Windows.Forms.Label();
            this.lbl_empCteDpto = new System.Windows.Forms.Label();
            this.lbl_empCteFunciones = new System.Windows.Forms.Label();
            this.lbl_empCteEmpresa = new System.Windows.Forms.Label();
            this.txt_CteEmpEmpresa = new System.Windows.Forms.TextBox();
            this.txt_CteEmpDpto = new System.Windows.Forms.TextBox();
            this.txt_CteEmpFunciones = new System.Windows.Forms.TextBox();
            this.lbl_empCtePeriodoIngresos = new System.Windows.Forms.Label();
            this.lbl_empCteIngresos = new System.Windows.Forms.Label();
            this.lbl_empCteAntiguedad = new System.Windows.Forms.Label();
            this.lbl_EmpCte5 = new System.Windows.Forms.Label();
            this.lbl_EmpCte8 = new System.Windows.Forms.Label();
            this.lbl_EmpCte7 = new System.Windows.Forms.Label();
            this.lbl_EmpCte6 = new System.Windows.Forms.Label();
            this.chk_CteNoTrabaja = new System.Windows.Forms.CheckBox();
            this.txt_CteEmpObservaciones = new System.Windows.Forms.TextBox();
            this.txt_CteEmpColonia = new System.Windows.Forms.TextBox();
            this.txt_CteEmpAntMunicipio = new System.Windows.Forms.TextBox();
            this.txt_CteEmpMunicipio = new System.Windows.Forms.TextBox();
            this.txt_CteEmpAntColonia = new System.Windows.Forms.TextBox();
            this.txt_CteEmpTelefono = new System.Windows.Forms.TextBox();
            this.txt_CteEmpAntDomicilio = new System.Windows.Forms.TextBox();
            this.lbl_CteNoTrabaja = new System.Windows.Forms.Label();
            this.txt_CteEmpAntEmpresa = new System.Windows.Forms.TextBox();
            this.txt_CteEmpCruces = new System.Windows.Forms.TextBox();
            this.txt_CteEmpDomicilio = new System.Windows.Forms.TextBox();
            this.txt_CteEmpAntCp = new System.Windows.Forms.TextBox();
            this.txt_CteEmpCp = new System.Windows.Forms.TextBox();
            this.lbl_empCteColonia = new System.Windows.Forms.Label();
            this.lbl_CteEmpAntMunicipio = new System.Windows.Forms.Label();
            this.lbl_empCteMunicipio = new System.Windows.Forms.Label();
            this.lbl_empCteTelefono = new System.Windows.Forms.Label();
            this.lbl_CteEmpAntColonia = new System.Windows.Forms.Label();
            this.lbl_CteEmpAntDomicilio = new System.Windows.Forms.Label();
            this.lbl_CteEmpAntEmpresa = new System.Windows.Forms.Label();
            this.lbl_empCteCruces = new System.Windows.Forms.Label();
            this.lbl_CteEmpAntCp = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_empCteDomicililo = new System.Windows.Forms.Label();
            this.gb_DRPersonales = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdb_CteRef2EsClienteSi = new System.Windows.Forms.RadioButton();
            this.rdb_CteRef2EsClienteNo = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdb_CteRef1EsClienteSi = new System.Windows.Forms.RadioButton();
            this.rdb_CteRef1EsClienteNo = new System.Windows.Forms.RadioButton();
            this.ddl_CteRef2Parentesco = new System.Windows.Forms.ComboBox();
            this.ddl_CteRef1Parentesco = new System.Windows.Forms.ComboBox();
            this.txt_CteRef2NumCuenta = new System.Windows.Forms.TextBox();
            this.txt_CteRef1NumCuenta = new System.Windows.Forms.TextBox();
            this.txt_CteRef2Telefono = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Telefono = new System.Windows.Forms.TextBox();
            this.txt_CteRef2Colonia = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Colonia = new System.Windows.Forms.TextBox();
            this.txt_CteRef2Municipio = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Municipio = new System.Windows.Forms.TextBox();
            this.txt_CteRef2Domicilio = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Domicilio = new System.Windows.Forms.TextBox();
            this.txt_CteRef2Nombre = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Nombre = new System.Windows.Forms.TextBox();
            this.lbl_CteRef2NumCuenta = new System.Windows.Forms.Label();
            this.lbl_CteRef1NumCuenta = new System.Windows.Forms.Label();
            this.txt_CteRef2Cp = new System.Windows.Forms.TextBox();
            this.txt_CteRef1Cp = new System.Windows.Forms.TextBox();
            this.lbl_CteRef2EsCliente = new System.Windows.Forms.Label();
            this.lbl_CteRef1EsCliente = new System.Windows.Forms.Label();
            this.lbl_CteRef2Municipio = new System.Windows.Forms.Label();
            this.lbl_CteRef2Colonia = new System.Windows.Forms.Label();
            this.lbl_CteRef1Municipio = new System.Windows.Forms.Label();
            this.lbl_CteRef2Telefono = new System.Windows.Forms.Label();
            this.lbl_CteRef1Colonia = new System.Windows.Forms.Label();
            this.lbl_CteRef2Domicilio = new System.Windows.Forms.Label();
            this.lbl_CteRef1Telefono = new System.Windows.Forms.Label();
            this.lbl_CteRef2Parentesco = new System.Windows.Forms.Label();
            this.lbl_CteRef1Domicilio = new System.Windows.Forms.Label();
            this.lbl_CteRef2Cp = new System.Windows.Forms.Label();
            this.lbl_CteRef1Parentesco = new System.Windows.Forms.Label();
            this.lbl_CteRef2Nombre = new System.Windows.Forms.Label();
            this.lbl_CteRef1Cp = new System.Windows.Forms.Label();
            this.lbl_CteRef1Nombre = new System.Windows.Forms.Label();
            this.gb_RCCTE = new System.Windows.Forms.GroupBox();
            this.txt_CteRefComer3 = new System.Windows.Forms.TextBox();
            this.txt_CteRefComer2 = new System.Windows.Forms.TextBox();
            this.txt_CteRefComer1 = new System.Windows.Forms.TextBox();
            this.lbl_CteRefComer3 = new System.Windows.Forms.Label();
            this.lbl_CteRefComer2 = new System.Windows.Forms.Label();
            this.lbl_CteRefComer1 = new System.Windows.Forms.Label();
            this.gb_RBCTE = new System.Windows.Forms.GroupBox();
            this.lbl_TCreBancoNum2 = new System.Windows.Forms.Label();
            this.lbl_TComEmisorNum2 = new System.Windows.Forms.Label();
            this.lbl_TComEmisorNum1 = new System.Windows.Forms.Label();
            this.lbl_TCreBancoNum1 = new System.Windows.Forms.Label();
            this.txt_TCreBancoNum2 = new System.Windows.Forms.TextBox();
            this.txt_TComEmisorNum2 = new System.Windows.Forms.TextBox();
            this.txt_TComEmisorNum1 = new System.Windows.Forms.TextBox();
            this.txt_TCreBancoNum1 = new System.Windows.Forms.TextBox();
            this.gb_DEConyugeCte = new System.Windows.Forms.GroupBox();
            this.ddl_CteConyugeEmpPeriodoIngresos = new System.Windows.Forms.ComboBox();
            this.txt_CteConyugeEmpPuestoJefe = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpColonia = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpIngresos = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntMunicipio = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpMunicipio = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntColonia = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpTelefono = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntDomicilio = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntEmpresa = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpCruces = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpDomicilio = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpJefe = new System.Windows.Forms.TextBox();
            this.lbl_CteConyugeEmpPuestoJefe = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpJefe = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpDpto = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpFunciones = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpEmpresa = new System.Windows.Forms.Label();
            this.txt_CteConyugeEmpEmpresa = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpDpto = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpAntCp = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpCp = new System.Windows.Forms.TextBox();
            this.txt_CteConyugeEmpFunciones = new System.Windows.Forms.TextBox();
            this.lbl_CteConyugeEmpColonia = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntMunicipio = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpMunicipio = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpTelefono = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntColonia = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntDomicilio = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntEmpresa = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpCruces = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpPeriodoIngresos = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpIngresos = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntiguedad = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpAntCp = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpCp = new System.Windows.Forms.Label();
            this.lbl_CteConyugeEmpDomicilio = new System.Windows.Forms.Label();
            this.gb_DGAval = new System.Windows.Forms.GroupBox();
            this.gb_ObligatorioDGAval = new System.Windows.Forms.GroupBox();
            this.ddl_AvalParentesco = new System.Windows.Forms.ComboBox();
            this.ddl_AvalEdoCivil = new System.Windows.Forms.ComboBox();
            this.dtp_AvalConyugeFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.ddl_AvalCalidadVive = new System.Windows.Forms.ComboBox();
            this.dtp_AvalFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.txt_AvalMunicipio = new System.Windows.Forms.TextBox();
            this.txt_AvalCruces = new System.Windows.Forms.TextBox();
            this.lbl_AvalMunicipio = new System.Windows.Forms.Label();
            this.txt_AvalDomicilio = new System.Windows.Forms.TextBox();
            this.txt_AvalConyuge = new System.Windows.Forms.TextBox();
            this.txt_AvalTelefono = new System.Windows.Forms.TextBox();
            this.lbl_AvalCalidadVive = new System.Windows.Forms.Label();
            this.txt_AvalColonia = new System.Windows.Forms.TextBox();
            this.txt_AvalAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_AvalCp = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEdad = new System.Windows.Forms.TextBox();
            this.lbl_Aval7 = new System.Windows.Forms.Label();
            this.txt_AvalEdad = new System.Windows.Forms.TextBox();
            this.txt_AvalNombre = new System.Windows.Forms.TextBox();
            this.lbl_AvalEdoCivil = new System.Windows.Forms.Label();
            this.lbl_AvalParentesco = new System.Windows.Forms.Label();
            this.lbl_AvalTelefono = new System.Windows.Forms.Label();
            this.lbl_AvalCp = new System.Windows.Forms.Label();
            this.lbl_AvalColonia = new System.Windows.Forms.Label();
            this.lbl_AvalCruces = new System.Windows.Forms.Label();
            this.lbl_AvalAntiguedad = new System.Windows.Forms.Label();
            this.lbl_AvalDomicilio = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeFechaNacimiento = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEdad = new System.Windows.Forms.Label();
            this.lbl_AvalConyuge = new System.Windows.Forms.Label();
            this.lbl_AvalFechaNacimiento = new System.Windows.Forms.Label();
            this.lbl_AvalEdad = new System.Windows.Forms.Label();
            this.lbl_AvalNombre = new System.Windows.Forms.Label();
            this.lbl_Aval6 = new System.Windows.Forms.Label();
            this.lbl_Aval5 = new System.Windows.Forms.Label();
            this.lbl_Aval4 = new System.Windows.Forms.Label();
            this.lbl_Aval3 = new System.Windows.Forms.Label();
            this.lbl_Aval2 = new System.Windows.Forms.Label();
            this.lbl_Aval10 = new System.Windows.Forms.Label();
            this.lbl_Aval15 = new System.Windows.Forms.Label();
            this.lbl_Aval14 = new System.Windows.Forms.Label();
            this.lbl_Aval13 = new System.Windows.Forms.Label();
            this.lbl_Aval12 = new System.Windows.Forms.Label();
            this.lbl_Aval11 = new System.Windows.Forms.Label();
            this.lbl_Aval9 = new System.Windows.Forms.Label();
            this.lbl_Aval8 = new System.Windows.Forms.Label();
            this.lbl_Aval1 = new System.Windows.Forms.Label();
            this.lbl_AvalObservaciones = new System.Windows.Forms.Label();
            this.chk_SinAval = new System.Windows.Forms.CheckBox();
            this.txt_AvalObservaciones = new System.Windows.Forms.TextBox();
            this.txt_AvalDomAnterior = new System.Windows.Forms.TextBox();
            this.txt_AvalMunicipioAnterior = new System.Windows.Forms.TextBox();
            this.lbl_AvalMunicipioAnterior = new System.Windows.Forms.Label();
            this.txt_AvalColoniaAnterior = new System.Windows.Forms.TextBox();
            this.txt_AvalCpAnterior = new System.Windows.Forms.TextBox();
            this.lbl_AvalCpAnterior = new System.Windows.Forms.Label();
            this.lbl_AvalColoniaAnterior = new System.Windows.Forms.Label();
            this.lbl_AvalDomAnterior = new System.Windows.Forms.Label();
            this.gb_DEAval = new System.Windows.Forms.GroupBox();
            this.gb_ObligatorioDEAval = new System.Windows.Forms.GroupBox();
            this.ddl_AvalEmpPeriodoIngresos = new System.Windows.Forms.ComboBox();
            this.txt_AvalEmpPuestoJefe = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpIngresos = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpJefe = new System.Windows.Forms.TextBox();
            this.lbl_AvalEmpPuestoJefe = new System.Windows.Forms.Label();
            this.lbl_AvalEmpJefe = new System.Windows.Forms.Label();
            this.lbl_AvalEmpDpto = new System.Windows.Forms.Label();
            this.lbl_AvalEmpFunciones = new System.Windows.Forms.Label();
            this.lbl_AvalEmpEmpresa = new System.Windows.Forms.Label();
            this.txt_AvalEmpEmpresa = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpDpto = new System.Windows.Forms.TextBox();
            this.lbl_AvalEmp2 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp5 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp7 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp4 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp1 = new System.Windows.Forms.Label();
            this.txt_AvalEmpFunciones = new System.Windows.Forms.TextBox();
            this.lbl_AvalEmpPeriodoIngresos = new System.Windows.Forms.Label();
            this.lbl_AvalEmpIngresos = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntiguedad = new System.Windows.Forms.Label();
            this.lbl_AvalEmp8 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp6 = new System.Windows.Forms.Label();
            this.lbl_AvalEmp3 = new System.Windows.Forms.Label();
            this.lbl_AvalNoTrabaja = new System.Windows.Forms.Label();
            this.chk_AvalNoTrabaja = new System.Windows.Forms.CheckBox();
            this.txt_AvalEmpObservaciones = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpColonia = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntMunicipio = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpMunicipio = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntColonia = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpTelefono = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntDomicilio = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntEmpresa = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpCruces = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpDomicilio = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpAntCp = new System.Windows.Forms.TextBox();
            this.txt_AvalEmpCp = new System.Windows.Forms.TextBox();
            this.lbl_AvalEmpColonia = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntMunicipio = new System.Windows.Forms.Label();
            this.lbl_AvalEmpMunicipio = new System.Windows.Forms.Label();
            this.lbl_AvalEmpTelefono = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntColonia = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntDomicilio = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntEmpresa = new System.Windows.Forms.Label();
            this.lbl_AvalEmpCruces = new System.Windows.Forms.Label();
            this.lbl_AvalEmpAntCp = new System.Windows.Forms.Label();
            this.lbl_AvalEmpCp = new System.Windows.Forms.Label();
            this.lbl_AvalEmpDomicilio = new System.Windows.Forms.Label();
            this.gb_DEConyugeAval = new System.Windows.Forms.GroupBox();
            this.ddl_AvalConyugeEmpPeriodoIngresos = new System.Windows.Forms.ComboBox();
            this.txt_AvalConyugeEmpPuestoJefe = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpColonia = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpIngresos = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntMunicipio = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpMunicipio = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntColonia = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpTelefono = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntDomicilio = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntEmpresa = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpCruces = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpDomicilio = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntiguedad = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpJefe = new System.Windows.Forms.TextBox();
            this.lbl_AvalConyugeEmpPuestoJefe = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpJefe = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpDpto = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpFunciones = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpEmpresa = new System.Windows.Forms.Label();
            this.txt_AvalConyugeEmpEmpresa = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpDpto = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpAntCp = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpCp = new System.Windows.Forms.TextBox();
            this.txt_AvalConyugeEmpFunciones = new System.Windows.Forms.TextBox();
            this.lbl_AvalConyugeEmpColonia = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntMunicipio = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpMunicipio = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpTelefono = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntColonia = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntDomicilio = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntEmpresa = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpCruces = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpPeriodoIngresos = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpIngresos = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntiguedad = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpAntCp = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpCp = new System.Windows.Forms.Label();
            this.lbl_AvalConyugeEmpDomicilio = new System.Windows.Forms.Label();
            this.gb_RCAval = new System.Windows.Forms.GroupBox();
            this.txt_AvalRefComer3 = new System.Windows.Forms.TextBox();
            this.txt_AvalRefComer2 = new System.Windows.Forms.TextBox();
            this.txt_AvalRefComer1 = new System.Windows.Forms.TextBox();
            this.lbl_AvalRefComer3 = new System.Windows.Forms.Label();
            this.lbl_AvalRefComer2 = new System.Windows.Forms.Label();
            this.lbl_AvalRefComer1 = new System.Windows.Forms.Label();
            this.gb_RBAval = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_TCreBancoNumAval2 = new System.Windows.Forms.TextBox();
            this.txt_TComEmisorNumAval2 = new System.Windows.Forms.TextBox();
            this.txt_TComEmisorNumAval1 = new System.Windows.Forms.TextBox();
            this.txt_TCreBancoNumAval1 = new System.Windows.Forms.TextBox();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.btn_Imprimir = new System.Windows.Forms.Button();
            this.gb_DatosEncabezado.SuspendLayout();
            this.gb_DGCte.SuspendLayout();
            this.gb_obligatorioDGCte.SuspendLayout();
            this.gb_DECte.SuspendLayout();
            this.gb_ObligatorioDECte.SuspendLayout();
            this.gb_DRPersonales.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_RCCTE.SuspendLayout();
            this.gb_RBCTE.SuspendLayout();
            this.gb_DEConyugeCte.SuspendLayout();
            this.gb_DGAval.SuspendLayout();
            this.gb_ObligatorioDGAval.SuspendLayout();
            this.gb_DEAval.SuspendLayout();
            this.gb_ObligatorioDEAval.SuspendLayout();
            this.gb_DEConyugeAval.SuspendLayout();
            this.gb_RCAval.SuspendLayout();
            this.gb_RBAval.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_DatosEncabezado
            // 
            this.gb_DatosEncabezado.Controls.Add(this.lbl_FechaRes);
            this.gb_DatosEncabezado.Controls.Add(this.chk_SoloReferencias);
            this.gb_DatosEncabezado.Controls.Add(this.chk_SoloAval);
            this.gb_DatosEncabezado.Controls.Add(this.dtp_Fecha);
            this.gb_DatosEncabezado.Controls.Add(this.txt_NumSolicitud);
            this.gb_DatosEncabezado.Controls.Add(this.lbl_nSolicitud);
            this.gb_DatosEncabezado.Controls.Add(this.txt_NumProspecto);
            this.gb_DatosEncabezado.Controls.Add(this.lbl_nProspecto);
            this.gb_DatosEncabezado.Controls.Add(this.txt_Importe);
            this.gb_DatosEncabezado.Controls.Add(this.lbl_importe);
            this.gb_DatosEncabezado.Controls.Add(this.lbl_fecha);
            this.gb_DatosEncabezado.Location = new System.Drawing.Point(12, 12);
            this.gb_DatosEncabezado.Name = "gb_DatosEncabezado";
            this.gb_DatosEncabezado.Size = new System.Drawing.Size(989, 117);
            this.gb_DatosEncabezado.TabIndex = 1;
            this.gb_DatosEncabezado.TabStop = false;
            // 
            // lbl_FechaRes
            // 
            this.lbl_FechaRes.AutoSize = true;
            this.lbl_FechaRes.Location = new System.Drawing.Point(65, 16);
            this.lbl_FechaRes.Name = "lbl_FechaRes";
            this.lbl_FechaRes.Size = new System.Drawing.Size(41, 13);
            this.lbl_FechaRes.TabIndex = 15;
            this.lbl_FechaRes.Text = "label13";
            // 
            // chk_SoloReferencias
            // 
            this.chk_SoloReferencias.AutoSize = true;
            this.chk_SoloReferencias.Location = new System.Drawing.Point(690, 87);
            this.chk_SoloReferencias.Name = "chk_SoloReferencias";
            this.chk_SoloReferencias.Size = new System.Drawing.Size(129, 17);
            this.chk_SoloReferencias.TabIndex = 6;
            this.chk_SoloReferencias.Text = "Sólo Datos Refencias";
            this.chk_SoloReferencias.UseVisualStyleBackColor = true;
            this.chk_SoloReferencias.CheckedChanged += new System.EventHandler(this.chk_SoloReferencias_CheckedChanged);
            // 
            // chk_SoloAval
            // 
            this.chk_SoloAval.AutoSize = true;
            this.chk_SoloAval.Location = new System.Drawing.Point(564, 87);
            this.chk_SoloAval.Name = "chk_SoloAval";
            this.chk_SoloAval.Size = new System.Drawing.Size(102, 17);
            this.chk_SoloAval.TabIndex = 5;
            this.chk_SoloAval.Text = "Sólo Datos Aval";
            this.chk_SoloAval.UseVisualStyleBackColor = true;
            this.chk_SoloAval.CheckedChanged += new System.EventHandler(this.chk_SoloAval_CheckedChanged);
            // 
            // dtp_Fecha
            // 
            this.dtp_Fecha.Enabled = false;
            this.dtp_Fecha.Location = new System.Drawing.Point(124, 10);
            this.dtp_Fecha.Name = "dtp_Fecha";
            this.dtp_Fecha.Size = new System.Drawing.Size(217, 20);
            this.dtp_Fecha.TabIndex = 1;
            this.dtp_Fecha.Visible = false;
            // 
            // txt_NumSolicitud
            // 
            this.txt_NumSolicitud.Location = new System.Drawing.Point(375, 87);
            this.txt_NumSolicitud.Name = "txt_NumSolicitud";
            this.txt_NumSolicitud.Size = new System.Drawing.Size(100, 20);
            this.txt_NumSolicitud.TabIndex = 4;
            // 
            // lbl_nSolicitud
            // 
            this.lbl_nSolicitud.AutoSize = true;
            this.lbl_nSolicitud.Location = new System.Drawing.Point(384, 63);
            this.lbl_nSolicitud.Name = "lbl_nSolicitud";
            this.lbl_nSolicitud.Size = new System.Drawing.Size(72, 13);
            this.lbl_nSolicitud.TabIndex = 14;
            this.lbl_nSolicitud.Text = "# de Solicitud";
            // 
            // txt_NumProspecto
            // 
            this.txt_NumProspecto.Location = new System.Drawing.Point(203, 88);
            this.txt_NumProspecto.Name = "txt_NumProspecto";
            this.txt_NumProspecto.Size = new System.Drawing.Size(100, 20);
            this.txt_NumProspecto.TabIndex = 3;
            // 
            // lbl_nProspecto
            // 
            this.lbl_nProspecto.AutoSize = true;
            this.lbl_nProspecto.Location = new System.Drawing.Point(211, 63);
            this.lbl_nProspecto.Name = "lbl_nProspecto";
            this.lbl_nProspecto.Size = new System.Drawing.Size(80, 13);
            this.lbl_nProspecto.TabIndex = 12;
            this.lbl_nProspecto.Text = "# de Prospecto";
            // 
            // txt_Importe
            // 
            this.txt_Importe.Location = new System.Drawing.Point(21, 88);
            this.txt_Importe.Name = "txt_Importe";
            this.txt_Importe.Size = new System.Drawing.Size(100, 20);
            this.txt_Importe.TabIndex = 2;
            this.txt_Importe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Importe_KeyPress);
            // 
            // lbl_importe
            // 
            this.lbl_importe.AutoSize = true;
            this.lbl_importe.Location = new System.Drawing.Point(18, 63);
            this.lbl_importe.Name = "lbl_importe";
            this.lbl_importe.Size = new System.Drawing.Size(120, 13);
            this.lbl_importe.TabIndex = 10;
            this.lbl_importe.Text = "Importe de la Operación";
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Location = new System.Drawing.Point(18, 16);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(40, 13);
            this.lbl_fecha.TabIndex = 8;
            this.lbl_fecha.Text = "Fecha:";
            // 
            // gb_DGCte
            // 
            this.gb_DGCte.Controls.Add(this.ddl_CteRecomParentesco);
            this.gb_DGCte.Controls.Add(this.txt_CteObservaciones);
            this.gb_DGCte.Controls.Add(this.txt_CteDireccionRecom);
            this.gb_DGCte.Controls.Add(this.txt_CteDomAnterior);
            this.gb_DGCte.Controls.Add(this.txt_CteRecomendado);
            this.gb_DGCte.Controls.Add(this.txt_CteMunicipioAnterior);
            this.gb_DGCte.Controls.Add(this.lbl_CteMunicipioAnterior);
            this.gb_DGCte.Controls.Add(this.txt_CteColoniaAnterior);
            this.gb_DGCte.Controls.Add(this.txt_CteCpAnterior);
            this.gb_DGCte.Controls.Add(this.lbl_CteObservaciones);
            this.gb_DGCte.Controls.Add(this.lbl_CteRecomParentezco);
            this.gb_DGCte.Controls.Add(this.lbl_CteDireccionRecom);
            this.gb_DGCte.Controls.Add(this.lbl_CteRecomendado);
            this.gb_DGCte.Controls.Add(this.lbl_CteCpAnterior);
            this.gb_DGCte.Controls.Add(this.lbl_CteColoniaAnterior);
            this.gb_DGCte.Controls.Add(this.lbl_CteDomAnterior);
            this.gb_DGCte.Controls.Add(this.gb_obligatorioDGCte);
            this.gb_DGCte.Location = new System.Drawing.Point(12, 160);
            this.gb_DGCte.Name = "gb_DGCte";
            this.gb_DGCte.Size = new System.Drawing.Size(989, 395);
            this.gb_DGCte.TabIndex = 2;
            this.gb_DGCte.TabStop = false;
            this.gb_DGCte.Text = "DATOS GENERALES DEL CLIENTE";
            // 
            // ddl_CteRecomParentesco
            // 
            this.ddl_CteRecomParentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteRecomParentesco.Location = new System.Drawing.Point(772, 302);
            this.ddl_CteRecomParentesco.Name = "ddl_CteRecomParentesco";
            this.ddl_CteRecomParentesco.Size = new System.Drawing.Size(160, 21);
            this.ddl_CteRecomParentesco.TabIndex = 8;
            // 
            // txt_CteObservaciones
            // 
            this.txt_CteObservaciones.Location = new System.Drawing.Point(143, 329);
            this.txt_CteObservaciones.Multiline = true;
            this.txt_CteObservaciones.Name = "txt_CteObservaciones";
            this.txt_CteObservaciones.Size = new System.Drawing.Size(789, 53);
            this.txt_CteObservaciones.TabIndex = 9;
            this.txt_CteObservaciones.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_CteObservaciones_KeyDown);
            this.txt_CteObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteObservaciones_KeyPress);
            this.txt_CteObservaciones.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txt_CteObservaciones_MouseDown);
            // 
            // txt_CteDireccionRecom
            // 
            this.txt_CteDireccionRecom.Location = new System.Drawing.Point(143, 303);
            this.txt_CteDireccionRecom.Name = "txt_CteDireccionRecom";
            this.txt_CteDireccionRecom.Size = new System.Drawing.Size(546, 20);
            this.txt_CteDireccionRecom.TabIndex = 7;
            // 
            // txt_CteDomAnterior
            // 
            this.txt_CteDomAnterior.Location = new System.Drawing.Point(125, 221);
            this.txt_CteDomAnterior.Name = "txt_CteDomAnterior";
            this.txt_CteDomAnterior.Size = new System.Drawing.Size(451, 20);
            this.txt_CteDomAnterior.TabIndex = 2;
            // 
            // txt_CteRecomendado
            // 
            this.txt_CteRecomendado.Location = new System.Drawing.Point(125, 276);
            this.txt_CteRecomendado.Name = "txt_CteRecomendado";
            this.txt_CteRecomendado.Size = new System.Drawing.Size(808, 20);
            this.txt_CteRecomendado.TabIndex = 6;
            // 
            // txt_CteMunicipioAnterior
            // 
            this.txt_CteMunicipioAnterior.Location = new System.Drawing.Point(125, 247);
            this.txt_CteMunicipioAnterior.Name = "txt_CteMunicipioAnterior";
            this.txt_CteMunicipioAnterior.Size = new System.Drawing.Size(393, 20);
            this.txt_CteMunicipioAnterior.TabIndex = 4;
            // 
            // lbl_CteMunicipioAnterior
            // 
            this.lbl_CteMunicipioAnterior.AutoSize = true;
            this.lbl_CteMunicipioAnterior.Location = new System.Drawing.Point(45, 250);
            this.lbl_CteMunicipioAnterior.Name = "lbl_CteMunicipioAnterior";
            this.lbl_CteMunicipioAnterior.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteMunicipioAnterior.TabIndex = 47;
            this.lbl_CteMunicipioAnterior.Text = "Municipio:";
            // 
            // txt_CteColoniaAnterior
            // 
            this.txt_CteColoniaAnterior.Location = new System.Drawing.Point(633, 221);
            this.txt_CteColoniaAnterior.Name = "txt_CteColoniaAnterior";
            this.txt_CteColoniaAnterior.Size = new System.Drawing.Size(299, 20);
            this.txt_CteColoniaAnterior.TabIndex = 3;
            // 
            // txt_CteCpAnterior
            // 
            this.txt_CteCpAnterior.Location = new System.Drawing.Point(560, 251);
            this.txt_CteCpAnterior.Name = "txt_CteCpAnterior";
            this.txt_CteCpAnterior.Size = new System.Drawing.Size(75, 20);
            this.txt_CteCpAnterior.TabIndex = 5;
            // 
            // lbl_CteObservaciones
            // 
            this.lbl_CteObservaciones.AutoSize = true;
            this.lbl_CteObservaciones.Location = new System.Drawing.Point(45, 334);
            this.lbl_CteObservaciones.Name = "lbl_CteObservaciones";
            this.lbl_CteObservaciones.Size = new System.Drawing.Size(81, 13);
            this.lbl_CteObservaciones.TabIndex = 55;
            this.lbl_CteObservaciones.Text = "Observaciones:";
            // 
            // lbl_CteRecomParentezco
            // 
            this.lbl_CteRecomParentezco.AutoSize = true;
            this.lbl_CteRecomParentezco.Location = new System.Drawing.Point(702, 306);
            this.lbl_CteRecomParentezco.Name = "lbl_CteRecomParentezco";
            this.lbl_CteRecomParentezco.Size = new System.Drawing.Size(64, 13);
            this.lbl_CteRecomParentezco.TabIndex = 54;
            this.lbl_CteRecomParentezco.Text = "Parentesco:";
            // 
            // lbl_CteDireccionRecom
            // 
            this.lbl_CteDireccionRecom.AutoSize = true;
            this.lbl_CteDireccionRecom.Location = new System.Drawing.Point(45, 307);
            this.lbl_CteDireccionRecom.Name = "lbl_CteDireccionRecom";
            this.lbl_CteDireccionRecom.Size = new System.Drawing.Size(92, 13);
            this.lbl_CteDireccionRecom.TabIndex = 53;
            this.lbl_CteDireccionRecom.Text = "Dirección Recom:";
            // 
            // lbl_CteRecomendado
            // 
            this.lbl_CteRecomendado.AutoSize = true;
            this.lbl_CteRecomendado.Location = new System.Drawing.Point(45, 276);
            this.lbl_CteRecomendado.Name = "lbl_CteRecomendado";
            this.lbl_CteRecomendado.Size = new System.Drawing.Size(80, 13);
            this.lbl_CteRecomendado.TabIndex = 52;
            this.lbl_CteRecomendado.Text = "Recomendado:";
            // 
            // lbl_CteCpAnterior
            // 
            this.lbl_CteCpAnterior.AutoSize = true;
            this.lbl_CteCpAnterior.Location = new System.Drawing.Point(524, 254);
            this.lbl_CteCpAnterior.Name = "lbl_CteCpAnterior";
            this.lbl_CteCpAnterior.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteCpAnterior.TabIndex = 50;
            this.lbl_CteCpAnterior.Text = "C.P.:";
            // 
            // lbl_CteColoniaAnterior
            // 
            this.lbl_CteColoniaAnterior.AutoSize = true;
            this.lbl_CteColoniaAnterior.Location = new System.Drawing.Point(582, 224);
            this.lbl_CteColoniaAnterior.Name = "lbl_CteColoniaAnterior";
            this.lbl_CteColoniaAnterior.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteColoniaAnterior.TabIndex = 49;
            this.lbl_CteColoniaAnterior.Text = "Colonia:";
            // 
            // lbl_CteDomAnterior
            // 
            this.lbl_CteDomAnterior.AutoSize = true;
            this.lbl_CteDomAnterior.Location = new System.Drawing.Point(45, 224);
            this.lbl_CteDomAnterior.Name = "lbl_CteDomAnterior";
            this.lbl_CteDomAnterior.Size = new System.Drawing.Size(74, 13);
            this.lbl_CteDomAnterior.TabIndex = 48;
            this.lbl_CteDomAnterior.Text = "Dom. Anterior:";
            // 
            // gb_obligatorioDGCte
            // 
            this.gb_obligatorioDGCte.BackColor = System.Drawing.Color.Transparent;
            this.gb_obligatorioDGCte.Controls.Add(this.label7);
            this.gb_obligatorioDGCte.Controls.Add(this.label10);
            this.gb_obligatorioDGCte.Controls.Add(this.ddl_CteCalidadVive);
            this.gb_obligatorioDGCte.Controls.Add(this.label9);
            this.gb_obligatorioDGCte.Controls.Add(this.label8);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_ObligatorioConyugeCte);
            this.gb_obligatorioDGCte.Controls.Add(this.label6);
            this.gb_obligatorioDGCte.Controls.Add(this.label15);
            this.gb_obligatorioDGCte.Controls.Add(this.label16);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_Obligatorio);
            this.gb_obligatorioDGCte.Controls.Add(this.ddl_CteEdoCivil);
            this.gb_obligatorioDGCte.Controls.Add(this.dtp_CteConyugeFechaNacimiento);
            this.gb_obligatorioDGCte.Controls.Add(this.dtp_CteFechaNacimiento);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteMunicipio);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteCruces);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteCalidadVive);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteMunicipio);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteDomicilio);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteConyuge);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteTelefono);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteColonia);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteAntiguedad);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteCp);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteConyugeEdad);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteEdad);
            this.gb_obligatorioDGCte.Controls.Add(this.txt_CteNombre);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteEdoCivil);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteTelefono);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteCp);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteColonia);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteCruces);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteAntiguedad);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteDomicilio);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteConyugeFechaNacimiento);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteConyugeEdad);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteConyuge);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteFechaNacimiento);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteEdad);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_CteNombre);
            this.gb_obligatorioDGCte.Controls.Add(this.label12);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_ObligatorioFechaNacCnyugeCte);
            this.gb_obligatorioDGCte.Controls.Add(this.lbl_ObligatorioEdadConyugeCte);
            this.gb_obligatorioDGCte.Controls.Add(this.label11);
            this.gb_obligatorioDGCte.Controls.Add(this.label17);
            this.gb_obligatorioDGCte.Location = new System.Drawing.Point(25, 27);
            this.gb_obligatorioDGCte.Name = "gb_obligatorioDGCte";
            this.gb_obligatorioDGCte.Size = new System.Drawing.Size(935, 188);
            this.gb_obligatorioDGCte.TabIndex = 1;
            this.gb_obligatorioDGCte.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(8, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 20);
            this.label7.TabIndex = 57;
            this.label7.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(8, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 20);
            this.label10.TabIndex = 57;
            this.label10.Text = "*";
            // 
            // ddl_CteCalidadVive
            // 
            this.ddl_CteCalidadVive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteCalidadVive.Location = new System.Drawing.Point(125, 162);
            this.ddl_CteCalidadVive.Name = "ddl_CteCalidadVive";
            this.ddl_CteCalidadVive.Size = new System.Drawing.Size(187, 21);
            this.ddl_CteCalidadVive.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(8, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 20);
            this.label9.TabIndex = 57;
            this.label9.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(8, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 20);
            this.label8.TabIndex = 57;
            this.label8.Text = "*";
            // 
            // lbl_ObligatorioConyugeCte
            // 
            this.lbl_ObligatorioConyugeCte.AutoSize = true;
            this.lbl_ObligatorioConyugeCte.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ObligatorioConyugeCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ObligatorioConyugeCte.ForeColor = System.Drawing.Color.Red;
            this.lbl_ObligatorioConyugeCte.Location = new System.Drawing.Point(8, 61);
            this.lbl_ObligatorioConyugeCte.Name = "lbl_ObligatorioConyugeCte";
            this.lbl_ObligatorioConyugeCte.Size = new System.Drawing.Size(15, 20);
            this.lbl_ObligatorioConyugeCte.TabIndex = 57;
            this.lbl_ObligatorioConyugeCte.Text = "*";
            this.lbl_ObligatorioConyugeCte.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(8, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 20);
            this.label6.TabIndex = 57;
            this.label6.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(641, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 20);
            this.label15.TabIndex = 57;
            this.label15.Text = "*";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(641, 111);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 20);
            this.label16.TabIndex = 57;
            this.label16.Text = "*";
            // 
            // lbl_Obligatorio
            // 
            this.lbl_Obligatorio.AutoSize = true;
            this.lbl_Obligatorio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Obligatorio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Obligatorio.ForeColor = System.Drawing.Color.Red;
            this.lbl_Obligatorio.Location = new System.Drawing.Point(8, 10);
            this.lbl_Obligatorio.Name = "lbl_Obligatorio";
            this.lbl_Obligatorio.Size = new System.Drawing.Size(15, 20);
            this.lbl_Obligatorio.TabIndex = 57;
            this.lbl_Obligatorio.Text = "*";
            // 
            // ddl_CteEdoCivil
            // 
            this.ddl_CteEdoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteEdoCivil.Location = new System.Drawing.Point(77, 34);
            this.ddl_CteEdoCivil.Name = "ddl_CteEdoCivil";
            this.ddl_CteEdoCivil.Size = new System.Drawing.Size(121, 21);
            this.ddl_CteEdoCivil.TabIndex = 4;
            this.ddl_CteEdoCivil.SelectedIndexChanged += new System.EventHandler(this.ddl_CteEdoCivil_SelectedIndexChanged);
            // 
            // dtp_CteConyugeFechaNacimiento
            // 
            this.dtp_CteConyugeFechaNacimiento.Enabled = false;
            this.dtp_CteConyugeFechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_CteConyugeFechaNacimiento.Location = new System.Drawing.Point(795, 59);
            this.dtp_CteConyugeFechaNacimiento.Name = "dtp_CteConyugeFechaNacimiento";
            this.dtp_CteConyugeFechaNacimiento.Size = new System.Drawing.Size(113, 20);
            this.dtp_CteConyugeFechaNacimiento.TabIndex = 7;
            // 
            // dtp_CteFechaNacimiento
            // 
            this.dtp_CteFechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_CteFechaNacimiento.Location = new System.Drawing.Point(794, 9);
            this.dtp_CteFechaNacimiento.Name = "dtp_CteFechaNacimiento";
            this.dtp_CteFechaNacimiento.Size = new System.Drawing.Size(113, 20);
            this.dtp_CteFechaNacimiento.TabIndex = 3;
            // 
            // txt_CteMunicipio
            // 
            this.txt_CteMunicipio.Location = new System.Drawing.Point(77, 137);
            this.txt_CteMunicipio.Name = "txt_CteMunicipio";
            this.txt_CteMunicipio.Size = new System.Drawing.Size(375, 20);
            this.txt_CteMunicipio.TabIndex = 12;
            // 
            // txt_CteCruces
            // 
            this.txt_CteCruces.Location = new System.Drawing.Point(77, 111);
            this.txt_CteCruces.Name = "txt_CteCruces";
            this.txt_CteCruces.Size = new System.Drawing.Size(562, 20);
            this.txt_CteCruces.TabIndex = 10;
            // 
            // lbl_CteCalidadVive
            // 
            this.lbl_CteCalidadVive.AutoSize = true;
            this.lbl_CteCalidadVive.Location = new System.Drawing.Point(20, 166);
            this.lbl_CteCalidadVive.Name = "lbl_CteCalidadVive";
            this.lbl_CteCalidadVive.Size = new System.Drawing.Size(99, 13);
            this.lbl_CteCalidadVive.TabIndex = 51;
            this.lbl_CteCalidadVive.Text = "Vive en Calidad de:";
            // 
            // lbl_CteMunicipio
            // 
            this.lbl_CteMunicipio.AutoSize = true;
            this.lbl_CteMunicipio.Location = new System.Drawing.Point(20, 140);
            this.lbl_CteMunicipio.Name = "lbl_CteMunicipio";
            this.lbl_CteMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteMunicipio.TabIndex = 47;
            this.lbl_CteMunicipio.Text = "Municipio:";
            // 
            // txt_CteDomicilio
            // 
            this.txt_CteDomicilio.Location = new System.Drawing.Point(77, 85);
            this.txt_CteDomicilio.Name = "txt_CteDomicilio";
            this.txt_CteDomicilio.Size = new System.Drawing.Size(562, 20);
            this.txt_CteDomicilio.TabIndex = 8;
            // 
            // txt_CteConyuge
            // 
            this.txt_CteConyuge.Enabled = false;
            this.txt_CteConyuge.Location = new System.Drawing.Point(77, 59);
            this.txt_CteConyuge.Name = "txt_CteConyuge";
            this.txt_CteConyuge.Size = new System.Drawing.Size(430, 20);
            this.txt_CteConyuge.TabIndex = 5;
            // 
            // txt_CteTelefono
            // 
            this.txt_CteTelefono.Location = new System.Drawing.Point(678, 137);
            this.txt_CteTelefono.MaxLength = 13;
            this.txt_CteTelefono.Name = "txt_CteTelefono";
            this.txt_CteTelefono.Size = new System.Drawing.Size(230, 20);
            this.txt_CteTelefono.TabIndex = 14;
            this.txt_CteTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteTelefono_KeyPress);
            // 
            // txt_CteColonia
            // 
            this.txt_CteColonia.Location = new System.Drawing.Point(715, 111);
            this.txt_CteColonia.Name = "txt_CteColonia";
            this.txt_CteColonia.Size = new System.Drawing.Size(193, 20);
            this.txt_CteColonia.TabIndex = 11;
            // 
            // txt_CteAntiguedad
            // 
            this.txt_CteAntiguedad.Location = new System.Drawing.Point(715, 85);
            this.txt_CteAntiguedad.Name = "txt_CteAntiguedad";
            this.txt_CteAntiguedad.Size = new System.Drawing.Size(193, 20);
            this.txt_CteAntiguedad.TabIndex = 9;
            // 
            // txt_CteCp
            // 
            this.txt_CteCp.Location = new System.Drawing.Point(494, 137);
            this.txt_CteCp.Name = "txt_CteCp";
            this.txt_CteCp.Size = new System.Drawing.Size(120, 20);
            this.txt_CteCp.TabIndex = 13;
            // 
            // txt_CteConyugeEdad
            // 
            this.txt_CteConyugeEdad.Enabled = false;
            this.txt_CteConyugeEdad.Location = new System.Drawing.Point(556, 59);
            this.txt_CteConyugeEdad.MaxLength = 2;
            this.txt_CteConyugeEdad.Name = "txt_CteConyugeEdad";
            this.txt_CteConyugeEdad.Size = new System.Drawing.Size(121, 20);
            this.txt_CteConyugeEdad.TabIndex = 6;
            this.txt_CteConyugeEdad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteConyugeEdad_KeyPress);
            // 
            // txt_CteEdad
            // 
            this.txt_CteEdad.Location = new System.Drawing.Point(556, 9);
            this.txt_CteEdad.MaxLength = 2;
            this.txt_CteEdad.Name = "txt_CteEdad";
            this.txt_CteEdad.Size = new System.Drawing.Size(121, 20);
            this.txt_CteEdad.TabIndex = 2;
            this.txt_CteEdad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteEdad_KeyPress);
            // 
            // txt_CteNombre
            // 
            this.txt_CteNombre.AcceptsReturn = true;
            this.txt_CteNombre.Location = new System.Drawing.Point(77, 9);
            this.txt_CteNombre.Name = "txt_CteNombre";
            this.txt_CteNombre.Size = new System.Drawing.Size(430, 20);
            this.txt_CteNombre.TabIndex = 1;
            // 
            // lbl_CteEdoCivil
            // 
            this.lbl_CteEdoCivil.AutoSize = true;
            this.lbl_CteEdoCivil.Location = new System.Drawing.Point(20, 37);
            this.lbl_CteEdoCivil.Name = "lbl_CteEdoCivil";
            this.lbl_CteEdoCivil.Size = new System.Drawing.Size(51, 13);
            this.lbl_CteEdoCivil.TabIndex = 56;
            this.lbl_CteEdoCivil.Text = "Edo Civil:";
            // 
            // lbl_CteTelefono
            // 
            this.lbl_CteTelefono.AutoSize = true;
            this.lbl_CteTelefono.Location = new System.Drawing.Point(624, 140);
            this.lbl_CteTelefono.Name = "lbl_CteTelefono";
            this.lbl_CteTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteTelefono.TabIndex = 46;
            this.lbl_CteTelefono.Text = "Teléfono:";
            // 
            // lbl_CteCp
            // 
            this.lbl_CteCp.AutoSize = true;
            this.lbl_CteCp.Location = new System.Drawing.Point(458, 140);
            this.lbl_CteCp.Name = "lbl_CteCp";
            this.lbl_CteCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteCp.TabIndex = 45;
            this.lbl_CteCp.Text = "C.P.:";
            // 
            // lbl_CteColonia
            // 
            this.lbl_CteColonia.AutoSize = true;
            this.lbl_CteColonia.Location = new System.Drawing.Point(659, 114);
            this.lbl_CteColonia.Name = "lbl_CteColonia";
            this.lbl_CteColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteColonia.TabIndex = 44;
            this.lbl_CteColonia.Text = "Colonia:";
            // 
            // lbl_CteCruces
            // 
            this.lbl_CteCruces.AutoSize = true;
            this.lbl_CteCruces.Location = new System.Drawing.Point(20, 114);
            this.lbl_CteCruces.Name = "lbl_CteCruces";
            this.lbl_CteCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_CteCruces.TabIndex = 43;
            this.lbl_CteCruces.Text = "Cruces:";
            // 
            // lbl_CteAntiguedad
            // 
            this.lbl_CteAntiguedad.AutoSize = true;
            this.lbl_CteAntiguedad.Location = new System.Drawing.Point(652, 88);
            this.lbl_CteAntiguedad.Name = "lbl_CteAntiguedad";
            this.lbl_CteAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_CteAntiguedad.TabIndex = 42;
            this.lbl_CteAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_CteDomicilio
            // 
            this.lbl_CteDomicilio.AutoSize = true;
            this.lbl_CteDomicilio.Location = new System.Drawing.Point(20, 88);
            this.lbl_CteDomicilio.Name = "lbl_CteDomicilio";
            this.lbl_CteDomicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteDomicilio.TabIndex = 41;
            this.lbl_CteDomicilio.Text = "Domicilio:";
            // 
            // lbl_CteConyugeFechaNacimiento
            // 
            this.lbl_CteConyugeFechaNacimiento.AutoSize = true;
            this.lbl_CteConyugeFechaNacimiento.Location = new System.Drawing.Point(686, 62);
            this.lbl_CteConyugeFechaNacimiento.Name = "lbl_CteConyugeFechaNacimiento";
            this.lbl_CteConyugeFechaNacimiento.Size = new System.Drawing.Size(111, 13);
            this.lbl_CteConyugeFechaNacimiento.TabIndex = 40;
            this.lbl_CteConyugeFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lbl_CteConyugeEdad
            // 
            this.lbl_CteConyugeEdad.AutoSize = true;
            this.lbl_CteConyugeEdad.Location = new System.Drawing.Point(518, 62);
            this.lbl_CteConyugeEdad.Name = "lbl_CteConyugeEdad";
            this.lbl_CteConyugeEdad.Size = new System.Drawing.Size(35, 13);
            this.lbl_CteConyugeEdad.TabIndex = 39;
            this.lbl_CteConyugeEdad.Text = "Edad:";
            // 
            // lbl_CteConyuge
            // 
            this.lbl_CteConyuge.AutoSize = true;
            this.lbl_CteConyuge.Location = new System.Drawing.Point(20, 62);
            this.lbl_CteConyuge.Name = "lbl_CteConyuge";
            this.lbl_CteConyuge.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteConyuge.TabIndex = 38;
            this.lbl_CteConyuge.Text = "Conyuge:";
            // 
            // lbl_CteFechaNacimiento
            // 
            this.lbl_CteFechaNacimiento.AutoSize = true;
            this.lbl_CteFechaNacimiento.Location = new System.Drawing.Point(686, 12);
            this.lbl_CteFechaNacimiento.Name = "lbl_CteFechaNacimiento";
            this.lbl_CteFechaNacimiento.Size = new System.Drawing.Size(111, 13);
            this.lbl_CteFechaNacimiento.TabIndex = 37;
            this.lbl_CteFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lbl_CteEdad
            // 
            this.lbl_CteEdad.AutoSize = true;
            this.lbl_CteEdad.Location = new System.Drawing.Point(519, 12);
            this.lbl_CteEdad.Name = "lbl_CteEdad";
            this.lbl_CteEdad.Size = new System.Drawing.Size(35, 13);
            this.lbl_CteEdad.TabIndex = 36;
            this.lbl_CteEdad.Text = "Edad:";
            // 
            // lbl_CteNombre
            // 
            this.lbl_CteNombre.AutoSize = true;
            this.lbl_CteNombre.Location = new System.Drawing.Point(20, 12);
            this.lbl_CteNombre.Name = "lbl_CteNombre";
            this.lbl_CteNombre.Size = new System.Drawing.Size(42, 13);
            this.lbl_CteNombre.TabIndex = 35;
            this.lbl_CteNombre.Text = "Cliente:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(675, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 20);
            this.label12.TabIndex = 57;
            this.label12.Text = "*";
            // 
            // lbl_ObligatorioFechaNacCnyugeCte
            // 
            this.lbl_ObligatorioFechaNacCnyugeCte.AutoSize = true;
            this.lbl_ObligatorioFechaNacCnyugeCte.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ObligatorioFechaNacCnyugeCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ObligatorioFechaNacCnyugeCte.ForeColor = System.Drawing.Color.Red;
            this.lbl_ObligatorioFechaNacCnyugeCte.Location = new System.Drawing.Point(674, 60);
            this.lbl_ObligatorioFechaNacCnyugeCte.Name = "lbl_ObligatorioFechaNacCnyugeCte";
            this.lbl_ObligatorioFechaNacCnyugeCte.Size = new System.Drawing.Size(15, 20);
            this.lbl_ObligatorioFechaNacCnyugeCte.TabIndex = 57;
            this.lbl_ObligatorioFechaNacCnyugeCte.Text = "*";
            this.lbl_ObligatorioFechaNacCnyugeCte.Visible = false;
            // 
            // lbl_ObligatorioEdadConyugeCte
            // 
            this.lbl_ObligatorioEdadConyugeCte.AutoSize = true;
            this.lbl_ObligatorioEdadConyugeCte.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ObligatorioEdadConyugeCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ObligatorioEdadConyugeCte.ForeColor = System.Drawing.Color.Red;
            this.lbl_ObligatorioEdadConyugeCte.Location = new System.Drawing.Point(506, 60);
            this.lbl_ObligatorioEdadConyugeCte.Name = "lbl_ObligatorioEdadConyugeCte";
            this.lbl_ObligatorioEdadConyugeCte.Size = new System.Drawing.Size(15, 20);
            this.lbl_ObligatorioEdadConyugeCte.TabIndex = 57;
            this.lbl_ObligatorioEdadConyugeCte.Text = "*";
            this.lbl_ObligatorioEdadConyugeCte.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(506, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 20);
            this.label11.TabIndex = 57;
            this.label11.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(613, 140);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 20);
            this.label17.TabIndex = 57;
            this.label17.Text = "*";
            // 
            // lbl_EmpCte1
            // 
            this.lbl_EmpCte1.AutoSize = true;
            this.lbl_EmpCte1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte1.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte1.Location = new System.Drawing.Point(6, 8);
            this.lbl_EmpCte1.Name = "lbl_EmpCte1";
            this.lbl_EmpCte1.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte1.TabIndex = 57;
            this.lbl_EmpCte1.Text = "*";
            // 
            // gb_DECte
            // 
            this.gb_DECte.Controls.Add(this.gb_ObligatorioDECte);
            this.gb_DECte.Controls.Add(this.chk_CteNoTrabaja);
            this.gb_DECte.Controls.Add(this.txt_CteEmpObservaciones);
            this.gb_DECte.Controls.Add(this.txt_CteEmpColonia);
            this.gb_DECte.Controls.Add(this.txt_CteEmpAntMunicipio);
            this.gb_DECte.Controls.Add(this.txt_CteEmpMunicipio);
            this.gb_DECte.Controls.Add(this.txt_CteEmpAntColonia);
            this.gb_DECte.Controls.Add(this.txt_CteEmpTelefono);
            this.gb_DECte.Controls.Add(this.txt_CteEmpAntDomicilio);
            this.gb_DECte.Controls.Add(this.lbl_CteNoTrabaja);
            this.gb_DECte.Controls.Add(this.txt_CteEmpAntEmpresa);
            this.gb_DECte.Controls.Add(this.txt_CteEmpCruces);
            this.gb_DECte.Controls.Add(this.txt_CteEmpDomicilio);
            this.gb_DECte.Controls.Add(this.txt_CteEmpAntCp);
            this.gb_DECte.Controls.Add(this.txt_CteEmpCp);
            this.gb_DECte.Controls.Add(this.lbl_empCteColonia);
            this.gb_DECte.Controls.Add(this.lbl_CteEmpAntMunicipio);
            this.gb_DECte.Controls.Add(this.lbl_empCteMunicipio);
            this.gb_DECte.Controls.Add(this.lbl_empCteTelefono);
            this.gb_DECte.Controls.Add(this.lbl_CteEmpAntColonia);
            this.gb_DECte.Controls.Add(this.lbl_CteEmpAntDomicilio);
            this.gb_DECte.Controls.Add(this.lbl_CteEmpAntEmpresa);
            this.gb_DECte.Controls.Add(this.lbl_empCteCruces);
            this.gb_DECte.Controls.Add(this.lbl_CteEmpAntCp);
            this.gb_DECte.Controls.Add(this.label3);
            this.gb_DECte.Controls.Add(this.lbl_empCteDomicililo);
            this.gb_DECte.Location = new System.Drawing.Point(12, 568);
            this.gb_DECte.Name = "gb_DECte";
            this.gb_DECte.Size = new System.Drawing.Size(989, 319);
            this.gb_DECte.TabIndex = 4;
            this.gb_DECte.TabStop = false;
            this.gb_DECte.Text = "DATOS DEL EMPLEO DEL CLIENTE";
            // 
            // gb_ObligatorioDECte
            // 
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte2);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte4);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte1);
            this.gb_ObligatorioDECte.Controls.Add(this.ddl_CteEmpPeriodoIngresos);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpPuestoJefe);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpIngresos);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpAntiguedad);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpJefe);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte3);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCtePuestoJefe);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteJefe);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteDpto);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteFunciones);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteEmpresa);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpEmpresa);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpDpto);
            this.gb_ObligatorioDECte.Controls.Add(this.txt_CteEmpFunciones);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCtePeriodoIngresos);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteIngresos);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_empCteAntiguedad);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte5);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte8);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte7);
            this.gb_ObligatorioDECte.Controls.Add(this.lbl_EmpCte6);
            this.gb_ObligatorioDECte.Location = new System.Drawing.Point(24, 36);
            this.gb_ObligatorioDECte.Name = "gb_ObligatorioDECte";
            this.gb_ObligatorioDECte.Size = new System.Drawing.Size(936, 92);
            this.gb_ObligatorioDECte.TabIndex = 2;
            this.gb_ObligatorioDECte.TabStop = false;
            // 
            // lbl_EmpCte2
            // 
            this.lbl_EmpCte2.AutoSize = true;
            this.lbl_EmpCte2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte2.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte2.Location = new System.Drawing.Point(6, 34);
            this.lbl_EmpCte2.Name = "lbl_EmpCte2";
            this.lbl_EmpCte2.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte2.TabIndex = 57;
            this.lbl_EmpCte2.Text = "*";
            // 
            // lbl_EmpCte4
            // 
            this.lbl_EmpCte4.AutoSize = true;
            this.lbl_EmpCte4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte4.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte4.Location = new System.Drawing.Point(445, 8);
            this.lbl_EmpCte4.Name = "lbl_EmpCte4";
            this.lbl_EmpCte4.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte4.TabIndex = 57;
            this.lbl_EmpCte4.Text = "*";
            // 
            // ddl_CteEmpPeriodoIngresos
            // 
            this.ddl_CteEmpPeriodoIngresos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteEmpPeriodoIngresos.Location = new System.Drawing.Point(671, 59);
            this.ddl_CteEmpPeriodoIngresos.Name = "ddl_CteEmpPeriodoIngresos";
            this.ddl_CteEmpPeriodoIngresos.Size = new System.Drawing.Size(240, 21);
            this.ddl_CteEmpPeriodoIngresos.TabIndex = 8;
            // 
            // txt_CteEmpPuestoJefe
            // 
            this.txt_CteEmpPuestoJefe.Location = new System.Drawing.Point(577, 34);
            this.txt_CteEmpPuestoJefe.Name = "txt_CteEmpPuestoJefe";
            this.txt_CteEmpPuestoJefe.Size = new System.Drawing.Size(334, 20);
            this.txt_CteEmpPuestoJefe.TabIndex = 5;
            // 
            // txt_CteEmpIngresos
            // 
            this.txt_CteEmpIngresos.Location = new System.Drawing.Point(417, 58);
            this.txt_CteEmpIngresos.Name = "txt_CteEmpIngresos";
            this.txt_CteEmpIngresos.Size = new System.Drawing.Size(143, 20);
            this.txt_CteEmpIngresos.TabIndex = 7;
            this.txt_CteEmpIngresos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteEmpIngresos_KeyPress);
            // 
            // txt_CteEmpAntiguedad
            // 
            this.txt_CteEmpAntiguedad.Location = new System.Drawing.Point(100, 59);
            this.txt_CteEmpAntiguedad.Name = "txt_CteEmpAntiguedad";
            this.txt_CteEmpAntiguedad.Size = new System.Drawing.Size(246, 20);
            this.txt_CteEmpAntiguedad.TabIndex = 6;
            // 
            // txt_CteEmpJefe
            // 
            this.txt_CteEmpJefe.Location = new System.Drawing.Point(100, 34);
            this.txt_CteEmpJefe.Name = "txt_CteEmpJefe";
            this.txt_CteEmpJefe.Size = new System.Drawing.Size(339, 20);
            this.txt_CteEmpJefe.TabIndex = 4;
            // 
            // lbl_EmpCte3
            // 
            this.lbl_EmpCte3.AutoSize = true;
            this.lbl_EmpCte3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte3.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte3.Location = new System.Drawing.Point(6, 60);
            this.lbl_EmpCte3.Name = "lbl_EmpCte3";
            this.lbl_EmpCte3.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte3.TabIndex = 57;
            this.lbl_EmpCte3.Text = "*";
            // 
            // lbl_empCtePuestoJefe
            // 
            this.lbl_empCtePuestoJefe.AutoSize = true;
            this.lbl_empCtePuestoJefe.Location = new System.Drawing.Point(448, 37);
            this.lbl_empCtePuestoJefe.Name = "lbl_empCtePuestoJefe";
            this.lbl_empCtePuestoJefe.Size = new System.Drawing.Size(132, 13);
            this.lbl_empCtePuestoJefe.TabIndex = 53;
            this.lbl_empCtePuestoJefe.Text = "Puesto del Jefe Inmediato:";
            // 
            // lbl_empCteJefe
            // 
            this.lbl_empCteJefe.AutoSize = true;
            this.lbl_empCteJefe.Location = new System.Drawing.Point(18, 37);
            this.lbl_empCteJefe.Name = "lbl_empCteJefe";
            this.lbl_empCteJefe.Size = new System.Drawing.Size(79, 13);
            this.lbl_empCteJefe.TabIndex = 52;
            this.lbl_empCteJefe.Text = "Jefe Inmediato:";
            // 
            // lbl_empCteDpto
            // 
            this.lbl_empCteDpto.AutoSize = true;
            this.lbl_empCteDpto.Location = new System.Drawing.Point(687, 11);
            this.lbl_empCteDpto.Name = "lbl_empCteDpto";
            this.lbl_empCteDpto.Size = new System.Drawing.Size(77, 13);
            this.lbl_empCteDpto.TabIndex = 51;
            this.lbl_empCteDpto.Text = "Departamento:";
            // 
            // lbl_empCteFunciones
            // 
            this.lbl_empCteFunciones.AutoSize = true;
            this.lbl_empCteFunciones.Location = new System.Drawing.Point(456, 11);
            this.lbl_empCteFunciones.Name = "lbl_empCteFunciones";
            this.lbl_empCteFunciones.Size = new System.Drawing.Size(59, 13);
            this.lbl_empCteFunciones.TabIndex = 50;
            this.lbl_empCteFunciones.Text = "Funciones:";
            // 
            // lbl_empCteEmpresa
            // 
            this.lbl_empCteEmpresa.AutoSize = true;
            this.lbl_empCteEmpresa.Location = new System.Drawing.Point(21, 11);
            this.lbl_empCteEmpresa.Name = "lbl_empCteEmpresa";
            this.lbl_empCteEmpresa.Size = new System.Drawing.Size(51, 13);
            this.lbl_empCteEmpresa.TabIndex = 49;
            this.lbl_empCteEmpresa.Text = "Empresa:";
            // 
            // txt_CteEmpEmpresa
            // 
            this.txt_CteEmpEmpresa.Location = new System.Drawing.Point(100, 4);
            this.txt_CteEmpEmpresa.Name = "txt_CteEmpEmpresa";
            this.txt_CteEmpEmpresa.Size = new System.Drawing.Size(342, 20);
            this.txt_CteEmpEmpresa.TabIndex = 1;
            // 
            // txt_CteEmpDpto
            // 
            this.txt_CteEmpDpto.Location = new System.Drawing.Point(765, 8);
            this.txt_CteEmpDpto.Name = "txt_CteEmpDpto";
            this.txt_CteEmpDpto.Size = new System.Drawing.Size(145, 20);
            this.txt_CteEmpDpto.TabIndex = 3;
            // 
            // txt_CteEmpFunciones
            // 
            this.txt_CteEmpFunciones.Location = new System.Drawing.Point(516, 8);
            this.txt_CteEmpFunciones.Name = "txt_CteEmpFunciones";
            this.txt_CteEmpFunciones.Size = new System.Drawing.Size(158, 20);
            this.txt_CteEmpFunciones.TabIndex = 2;
            // 
            // lbl_empCtePeriodoIngresos
            // 
            this.lbl_empCtePeriodoIngresos.AutoSize = true;
            this.lbl_empCtePeriodoIngresos.Location = new System.Drawing.Point(569, 62);
            this.lbl_empCtePeriodoIngresos.Name = "lbl_empCtePeriodoIngresos";
            this.lbl_empCtePeriodoIngresos.Size = new System.Drawing.Size(104, 13);
            this.lbl_empCtePeriodoIngresos.TabIndex = 38;
            this.lbl_empCtePeriodoIngresos.Text = "Periodo de Ingresos:";
            // 
            // lbl_empCteIngresos
            // 
            this.lbl_empCteIngresos.AutoSize = true;
            this.lbl_empCteIngresos.Location = new System.Drawing.Point(357, 62);
            this.lbl_empCteIngresos.Name = "lbl_empCteIngresos";
            this.lbl_empCteIngresos.Size = new System.Drawing.Size(59, 13);
            this.lbl_empCteIngresos.TabIndex = 37;
            this.lbl_empCteIngresos.Text = "Ingresos $:";
            // 
            // lbl_empCteAntiguedad
            // 
            this.lbl_empCteAntiguedad.AutoSize = true;
            this.lbl_empCteAntiguedad.Location = new System.Drawing.Point(18, 62);
            this.lbl_empCteAntiguedad.Name = "lbl_empCteAntiguedad";
            this.lbl_empCteAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_empCteAntiguedad.TabIndex = 39;
            this.lbl_empCteAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_EmpCte5
            // 
            this.lbl_EmpCte5.AutoSize = true;
            this.lbl_EmpCte5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte5.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte5.Location = new System.Drawing.Point(677, 8);
            this.lbl_EmpCte5.Name = "lbl_EmpCte5";
            this.lbl_EmpCte5.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte5.TabIndex = 57;
            this.lbl_EmpCte5.Text = "*";
            // 
            // lbl_EmpCte8
            // 
            this.lbl_EmpCte8.AutoSize = true;
            this.lbl_EmpCte8.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte8.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte8.Location = new System.Drawing.Point(561, 60);
            this.lbl_EmpCte8.Name = "lbl_EmpCte8";
            this.lbl_EmpCte8.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte8.TabIndex = 57;
            this.lbl_EmpCte8.Text = "*";
            // 
            // lbl_EmpCte7
            // 
            this.lbl_EmpCte7.AutoSize = true;
            this.lbl_EmpCte7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte7.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte7.Location = new System.Drawing.Point(347, 60);
            this.lbl_EmpCte7.Name = "lbl_EmpCte7";
            this.lbl_EmpCte7.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte7.TabIndex = 57;
            this.lbl_EmpCte7.Text = "*";
            // 
            // lbl_EmpCte6
            // 
            this.lbl_EmpCte6.AutoSize = true;
            this.lbl_EmpCte6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_EmpCte6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmpCte6.ForeColor = System.Drawing.Color.Red;
            this.lbl_EmpCte6.Location = new System.Drawing.Point(439, 35);
            this.lbl_EmpCte6.Name = "lbl_EmpCte6";
            this.lbl_EmpCte6.Size = new System.Drawing.Size(15, 20);
            this.lbl_EmpCte6.TabIndex = 57;
            this.lbl_EmpCte6.Text = "*";
            // 
            // chk_CteNoTrabaja
            // 
            this.chk_CteNoTrabaja.AutoSize = true;
            this.chk_CteNoTrabaja.Location = new System.Drawing.Point(441, 0);
            this.chk_CteNoTrabaja.Name = "chk_CteNoTrabaja";
            this.chk_CteNoTrabaja.Size = new System.Drawing.Size(150, 17);
            this.chk_CteNoTrabaja.TabIndex = 1;
            this.chk_CteNoTrabaja.Text = "Cliente se dedica al Hogar";
            this.chk_CteNoTrabaja.UseVisualStyleBackColor = true;
            this.chk_CteNoTrabaja.CheckedChanged += new System.EventHandler(this.chk_CteNoTrabaja_CheckedChanged);
            // 
            // txt_CteEmpObservaciones
            // 
            this.txt_CteEmpObservaciones.Location = new System.Drawing.Point(143, 259);
            this.txt_CteEmpObservaciones.Multiline = true;
            this.txt_CteEmpObservaciones.Name = "txt_CteEmpObservaciones";
            this.txt_CteEmpObservaciones.Size = new System.Drawing.Size(789, 48);
            this.txt_CteEmpObservaciones.TabIndex = 20;
            this.txt_CteEmpObservaciones.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_CteEmpObservaciones_KeyDown);
            this.txt_CteEmpObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteEmpObservaciones_KeyPress);
            this.txt_CteEmpObservaciones.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txt_CteEmpObservaciones_MouseDown);
            // 
            // txt_CteEmpColonia
            // 
            this.txt_CteEmpColonia.Location = new System.Drawing.Point(700, 128);
            this.txt_CteEmpColonia.Name = "txt_CteEmpColonia";
            this.txt_CteEmpColonia.Size = new System.Drawing.Size(234, 20);
            this.txt_CteEmpColonia.TabIndex = 10;
            // 
            // txt_CteEmpAntMunicipio
            // 
            this.txt_CteEmpAntMunicipio.Location = new System.Drawing.Point(465, 232);
            this.txt_CteEmpAntMunicipio.Name = "txt_CteEmpAntMunicipio";
            this.txt_CteEmpAntMunicipio.Size = new System.Drawing.Size(318, 20);
            this.txt_CteEmpAntMunicipio.TabIndex = 18;
            // 
            // txt_CteEmpMunicipio
            // 
            this.txt_CteEmpMunicipio.Location = new System.Drawing.Point(124, 154);
            this.txt_CteEmpMunicipio.Name = "txt_CteEmpMunicipio";
            this.txt_CteEmpMunicipio.Size = new System.Drawing.Size(361, 20);
            this.txt_CteEmpMunicipio.TabIndex = 11;
            // 
            // txt_CteEmpAntColonia
            // 
            this.txt_CteEmpAntColonia.Location = new System.Drawing.Point(93, 231);
            this.txt_CteEmpAntColonia.Name = "txt_CteEmpAntColonia";
            this.txt_CteEmpAntColonia.Size = new System.Drawing.Size(306, 20);
            this.txt_CteEmpAntColonia.TabIndex = 17;
            // 
            // txt_CteEmpTelefono
            // 
            this.txt_CteEmpTelefono.Location = new System.Drawing.Point(700, 154);
            this.txt_CteEmpTelefono.Name = "txt_CteEmpTelefono";
            this.txt_CteEmpTelefono.Size = new System.Drawing.Size(235, 20);
            this.txt_CteEmpTelefono.TabIndex = 13;
            this.txt_CteEmpTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteEmpTelefono_KeyPress);
            // 
            // txt_CteEmpAntDomicilio
            // 
            this.txt_CteEmpAntDomicilio.Location = new System.Drawing.Point(175, 205);
            this.txt_CteEmpAntDomicilio.Name = "txt_CteEmpAntDomicilio";
            this.txt_CteEmpAntDomicilio.Size = new System.Drawing.Size(759, 20);
            this.txt_CteEmpAntDomicilio.TabIndex = 16;
            // 
            // lbl_CteNoTrabaja
            // 
            this.lbl_CteNoTrabaja.AutoSize = true;
            this.lbl_CteNoTrabaja.Location = new System.Drawing.Point(45, 264);
            this.lbl_CteNoTrabaja.Name = "lbl_CteNoTrabaja";
            this.lbl_CteNoTrabaja.Size = new System.Drawing.Size(81, 13);
            this.lbl_CteNoTrabaja.TabIndex = 55;
            this.lbl_CteNoTrabaja.Text = "Observaciones:";
            // 
            // txt_CteEmpAntEmpresa
            // 
            this.txt_CteEmpAntEmpresa.Location = new System.Drawing.Point(576, 179);
            this.txt_CteEmpAntEmpresa.Name = "txt_CteEmpAntEmpresa";
            this.txt_CteEmpAntEmpresa.Size = new System.Drawing.Size(358, 20);
            this.txt_CteEmpAntEmpresa.TabIndex = 15;
            // 
            // txt_CteEmpCruces
            // 
            this.txt_CteEmpCruces.Location = new System.Drawing.Point(124, 179);
            this.txt_CteEmpCruces.Name = "txt_CteEmpCruces";
            this.txt_CteEmpCruces.Size = new System.Drawing.Size(355, 20);
            this.txt_CteEmpCruces.TabIndex = 14;
            // 
            // txt_CteEmpDomicilio
            // 
            this.txt_CteEmpDomicilio.Location = new System.Drawing.Point(124, 128);
            this.txt_CteEmpDomicilio.Name = "txt_CteEmpDomicilio";
            this.txt_CteEmpDomicilio.Size = new System.Drawing.Size(519, 20);
            this.txt_CteEmpDomicilio.TabIndex = 9;
            // 
            // txt_CteEmpAntCp
            // 
            this.txt_CteEmpAntCp.Location = new System.Drawing.Point(827, 231);
            this.txt_CteEmpAntCp.Name = "txt_CteEmpAntCp";
            this.txt_CteEmpAntCp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteEmpAntCp.TabIndex = 19;
            // 
            // txt_CteEmpCp
            // 
            this.txt_CteEmpCp.Location = new System.Drawing.Point(535, 154);
            this.txt_CteEmpCp.Name = "txt_CteEmpCp";
            this.txt_CteEmpCp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteEmpCp.TabIndex = 12;
            // 
            // lbl_empCteColonia
            // 
            this.lbl_empCteColonia.AutoSize = true;
            this.lbl_empCteColonia.Location = new System.Drawing.Point(649, 131);
            this.lbl_empCteColonia.Name = "lbl_empCteColonia";
            this.lbl_empCteColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_empCteColonia.TabIndex = 46;
            this.lbl_empCteColonia.Text = "Colonia:";
            // 
            // lbl_CteEmpAntMunicipio
            // 
            this.lbl_CteEmpAntMunicipio.AutoSize = true;
            this.lbl_CteEmpAntMunicipio.Location = new System.Drawing.Point(408, 235);
            this.lbl_CteEmpAntMunicipio.Name = "lbl_CteEmpAntMunicipio";
            this.lbl_CteEmpAntMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteEmpAntMunicipio.TabIndex = 45;
            this.lbl_CteEmpAntMunicipio.Text = "Municipio:";
            // 
            // lbl_empCteMunicipio
            // 
            this.lbl_empCteMunicipio.AutoSize = true;
            this.lbl_empCteMunicipio.Location = new System.Drawing.Point(42, 157);
            this.lbl_empCteMunicipio.Name = "lbl_empCteMunicipio";
            this.lbl_empCteMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_empCteMunicipio.TabIndex = 44;
            this.lbl_empCteMunicipio.Text = "Municipio:";
            // 
            // lbl_empCteTelefono
            // 
            this.lbl_empCteTelefono.AutoSize = true;
            this.lbl_empCteTelefono.Location = new System.Drawing.Point(643, 157);
            this.lbl_empCteTelefono.Name = "lbl_empCteTelefono";
            this.lbl_empCteTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_empCteTelefono.TabIndex = 43;
            this.lbl_empCteTelefono.Text = "Teléfono:";
            // 
            // lbl_CteEmpAntColonia
            // 
            this.lbl_CteEmpAntColonia.AutoSize = true;
            this.lbl_CteEmpAntColonia.Location = new System.Drawing.Point(42, 235);
            this.lbl_CteEmpAntColonia.Name = "lbl_CteEmpAntColonia";
            this.lbl_CteEmpAntColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteEmpAntColonia.TabIndex = 42;
            this.lbl_CteEmpAntColonia.Text = "Colonia:";
            // 
            // lbl_CteEmpAntDomicilio
            // 
            this.lbl_CteEmpAntDomicilio.AutoSize = true;
            this.lbl_CteEmpAntDomicilio.Location = new System.Drawing.Point(42, 208);
            this.lbl_CteEmpAntDomicilio.Name = "lbl_CteEmpAntDomicilio";
            this.lbl_CteEmpAntDomicilio.Size = new System.Drawing.Size(130, 13);
            this.lbl_CteEmpAntDomicilio.TabIndex = 41;
            this.lbl_CteEmpAntDomicilio.Text = "Domicilio Trabajo Anterior:";
            // 
            // lbl_CteEmpAntEmpresa
            // 
            this.lbl_CteEmpAntEmpresa.AutoSize = true;
            this.lbl_CteEmpAntEmpresa.Location = new System.Drawing.Point(485, 182);
            this.lbl_CteEmpAntEmpresa.Name = "lbl_CteEmpAntEmpresa";
            this.lbl_CteEmpAntEmpresa.Size = new System.Drawing.Size(85, 13);
            this.lbl_CteEmpAntEmpresa.TabIndex = 41;
            this.lbl_CteEmpAntEmpresa.Text = "Trabajo Anterior:";
            // 
            // lbl_empCteCruces
            // 
            this.lbl_empCteCruces.AutoSize = true;
            this.lbl_empCteCruces.Location = new System.Drawing.Point(42, 182);
            this.lbl_empCteCruces.Name = "lbl_empCteCruces";
            this.lbl_empCteCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_empCteCruces.TabIndex = 40;
            this.lbl_empCteCruces.Text = "Cruces:";
            // 
            // lbl_CteEmpAntCp
            // 
            this.lbl_CteEmpAntCp.AutoSize = true;
            this.lbl_CteEmpAntCp.Location = new System.Drawing.Point(791, 235);
            this.lbl_CteEmpAntCp.Name = "lbl_CteEmpAntCp";
            this.lbl_CteEmpAntCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteEmpAntCp.TabIndex = 50;
            this.lbl_CteEmpAntCp.Text = "C.P.:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(499, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "C.P.:";
            // 
            // lbl_empCteDomicililo
            // 
            this.lbl_empCteDomicililo.AutoSize = true;
            this.lbl_empCteDomicililo.Location = new System.Drawing.Point(42, 131);
            this.lbl_empCteDomicililo.Name = "lbl_empCteDomicililo";
            this.lbl_empCteDomicililo.Size = new System.Drawing.Size(52, 13);
            this.lbl_empCteDomicililo.TabIndex = 36;
            this.lbl_empCteDomicililo.Text = "Domicilio:";
            // 
            // gb_DRPersonales
            // 
            this.gb_DRPersonales.Controls.Add(this.panel2);
            this.gb_DRPersonales.Controls.Add(this.panel1);
            this.gb_DRPersonales.Controls.Add(this.ddl_CteRef2Parentesco);
            this.gb_DRPersonales.Controls.Add(this.ddl_CteRef1Parentesco);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2NumCuenta);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1NumCuenta);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Telefono);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Telefono);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Colonia);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Colonia);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Municipio);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Municipio);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Domicilio);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Domicilio);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Nombre);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Nombre);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2NumCuenta);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1NumCuenta);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef2Cp);
            this.gb_DRPersonales.Controls.Add(this.txt_CteRef1Cp);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2EsCliente);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1EsCliente);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Municipio);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Colonia);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Municipio);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Telefono);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Colonia);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Domicilio);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Telefono);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Parentesco);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Domicilio);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Cp);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Parentesco);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef2Nombre);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Cp);
            this.gb_DRPersonales.Controls.Add(this.lbl_CteRef1Nombre);
            this.gb_DRPersonales.Location = new System.Drawing.Point(12, 1162);
            this.gb_DRPersonales.Name = "gb_DRPersonales";
            this.gb_DRPersonales.Size = new System.Drawing.Size(989, 190);
            this.gb_DRPersonales.TabIndex = 6;
            this.gb_DRPersonales.TabStop = false;
            this.gb_DRPersonales.Text = "DOS REFERENCIAS PERSONALES";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdb_CteRef2EsClienteSi);
            this.panel2.Controls.Add(this.rdb_CteRef2EsClienteNo);
            this.panel2.Location = new System.Drawing.Point(584, 156);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(84, 27);
            this.panel2.TabIndex = 51;
            // 
            // rdb_CteRef2EsClienteSi
            // 
            this.rdb_CteRef2EsClienteSi.AutoSize = true;
            this.rdb_CteRef2EsClienteSi.Location = new System.Drawing.Point(3, 7);
            this.rdb_CteRef2EsClienteSi.Name = "rdb_CteRef2EsClienteSi";
            this.rdb_CteRef2EsClienteSi.Size = new System.Drawing.Size(34, 17);
            this.rdb_CteRef2EsClienteSi.TabIndex = 18;
            this.rdb_CteRef2EsClienteSi.TabStop = true;
            this.rdb_CteRef2EsClienteSi.Text = "Si";
            this.rdb_CteRef2EsClienteSi.UseVisualStyleBackColor = true;
            this.rdb_CteRef2EsClienteSi.CheckedChanged += new System.EventHandler(this.rdb_CteRef2EsClienteSi_CheckedChanged);
            // 
            // rdb_CteRef2EsClienteNo
            // 
            this.rdb_CteRef2EsClienteNo.AutoSize = true;
            this.rdb_CteRef2EsClienteNo.Checked = true;
            this.rdb_CteRef2EsClienteNo.Location = new System.Drawing.Point(40, 7);
            this.rdb_CteRef2EsClienteNo.Name = "rdb_CteRef2EsClienteNo";
            this.rdb_CteRef2EsClienteNo.Size = new System.Drawing.Size(39, 17);
            this.rdb_CteRef2EsClienteNo.TabIndex = 19;
            this.rdb_CteRef2EsClienteNo.TabStop = true;
            this.rdb_CteRef2EsClienteNo.Text = "No";
            this.rdb_CteRef2EsClienteNo.UseVisualStyleBackColor = true;
            this.rdb_CteRef2EsClienteNo.CheckedChanged += new System.EventHandler(this.rdb_CteRef2EsClienteNo_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdb_CteRef1EsClienteSi);
            this.panel1.Controls.Add(this.rdb_CteRef1EsClienteNo);
            this.panel1.Location = new System.Drawing.Point(580, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(84, 27);
            this.panel1.TabIndex = 51;
            // 
            // rdb_CteRef1EsClienteSi
            // 
            this.rdb_CteRef1EsClienteSi.AutoSize = true;
            this.rdb_CteRef1EsClienteSi.Location = new System.Drawing.Point(3, 7);
            this.rdb_CteRef1EsClienteSi.Name = "rdb_CteRef1EsClienteSi";
            this.rdb_CteRef1EsClienteSi.Size = new System.Drawing.Size(34, 17);
            this.rdb_CteRef1EsClienteSi.TabIndex = 8;
            this.rdb_CteRef1EsClienteSi.Text = "Si";
            this.rdb_CteRef1EsClienteSi.UseVisualStyleBackColor = true;
            this.rdb_CteRef1EsClienteSi.CheckedChanged += new System.EventHandler(this.rdb_CteRef1EsClienteSi_CheckedChanged);
            // 
            // rdb_CteRef1EsClienteNo
            // 
            this.rdb_CteRef1EsClienteNo.AutoSize = true;
            this.rdb_CteRef1EsClienteNo.Checked = true;
            this.rdb_CteRef1EsClienteNo.Location = new System.Drawing.Point(40, 7);
            this.rdb_CteRef1EsClienteNo.Name = "rdb_CteRef1EsClienteNo";
            this.rdb_CteRef1EsClienteNo.Size = new System.Drawing.Size(39, 17);
            this.rdb_CteRef1EsClienteNo.TabIndex = 9;
            this.rdb_CteRef1EsClienteNo.TabStop = true;
            this.rdb_CteRef1EsClienteNo.Text = "No";
            this.rdb_CteRef1EsClienteNo.UseVisualStyleBackColor = true;
            this.rdb_CteRef1EsClienteNo.CheckedChanged += new System.EventHandler(this.rdb_CteRef1EsClienteNo_CheckedChanged);
            // 
            // ddl_CteRef2Parentesco
            // 
            this.ddl_CteRef2Parentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteRef2Parentesco.FormattingEnabled = true;
            this.ddl_CteRef2Parentesco.Location = new System.Drawing.Point(537, 108);
            this.ddl_CteRef2Parentesco.Name = "ddl_CteRef2Parentesco";
            this.ddl_CteRef2Parentesco.Size = new System.Drawing.Size(177, 21);
            this.ddl_CteRef2Parentesco.TabIndex = 12;
            // 
            // ddl_CteRef1Parentesco
            // 
            this.ddl_CteRef1Parentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteRef1Parentesco.Location = new System.Drawing.Point(537, 24);
            this.ddl_CteRef1Parentesco.Name = "ddl_CteRef1Parentesco";
            this.ddl_CteRef1Parentesco.Size = new System.Drawing.Size(177, 21);
            this.ddl_CteRef1Parentesco.TabIndex = 2;
            // 
            // txt_CteRef2NumCuenta
            // 
            this.txt_CteRef2NumCuenta.Enabled = false;
            this.txt_CteRef2NumCuenta.Location = new System.Drawing.Point(742, 158);
            this.txt_CteRef2NumCuenta.Name = "txt_CteRef2NumCuenta";
            this.txt_CteRef2NumCuenta.Size = new System.Drawing.Size(189, 20);
            this.txt_CteRef2NumCuenta.TabIndex = 20;
            // 
            // txt_CteRef1NumCuenta
            // 
            this.txt_CteRef1NumCuenta.Enabled = false;
            this.txt_CteRef1NumCuenta.Location = new System.Drawing.Point(742, 75);
            this.txt_CteRef1NumCuenta.Name = "txt_CteRef1NumCuenta";
            this.txt_CteRef1NumCuenta.Size = new System.Drawing.Size(189, 20);
            this.txt_CteRef1NumCuenta.TabIndex = 10;
            // 
            // txt_CteRef2Telefono
            // 
            this.txt_CteRef2Telefono.Location = new System.Drawing.Point(769, 108);
            this.txt_CteRef2Telefono.Name = "txt_CteRef2Telefono";
            this.txt_CteRef2Telefono.Size = new System.Drawing.Size(163, 20);
            this.txt_CteRef2Telefono.TabIndex = 13;
            // 
            // txt_CteRef1Telefono
            // 
            this.txt_CteRef1Telefono.Location = new System.Drawing.Point(769, 25);
            this.txt_CteRef1Telefono.Name = "txt_CteRef1Telefono";
            this.txt_CteRef1Telefono.Size = new System.Drawing.Size(163, 20);
            this.txt_CteRef1Telefono.TabIndex = 3;
            // 
            // txt_CteRef2Colonia
            // 
            this.txt_CteRef2Colonia.Location = new System.Drawing.Point(584, 134);
            this.txt_CteRef2Colonia.Name = "txt_CteRef2Colonia";
            this.txt_CteRef2Colonia.Size = new System.Drawing.Size(347, 20);
            this.txt_CteRef2Colonia.TabIndex = 15;
            // 
            // txt_CteRef1Colonia
            // 
            this.txt_CteRef1Colonia.Location = new System.Drawing.Point(584, 51);
            this.txt_CteRef1Colonia.Name = "txt_CteRef1Colonia";
            this.txt_CteRef1Colonia.Size = new System.Drawing.Size(347, 20);
            this.txt_CteRef1Colonia.TabIndex = 5;
            // 
            // txt_CteRef2Municipio
            // 
            this.txt_CteRef2Municipio.Location = new System.Drawing.Point(92, 158);
            this.txt_CteRef2Municipio.Name = "txt_CteRef2Municipio";
            this.txt_CteRef2Municipio.Size = new System.Drawing.Size(265, 20);
            this.txt_CteRef2Municipio.TabIndex = 16;
            // 
            // txt_CteRef1Municipio
            // 
            this.txt_CteRef1Municipio.Location = new System.Drawing.Point(92, 75);
            this.txt_CteRef1Municipio.Name = "txt_CteRef1Municipio";
            this.txt_CteRef1Municipio.Size = new System.Drawing.Size(265, 20);
            this.txt_CteRef1Municipio.TabIndex = 6;
            // 
            // txt_CteRef2Domicilio
            // 
            this.txt_CteRef2Domicilio.Location = new System.Drawing.Point(92, 134);
            this.txt_CteRef2Domicilio.Name = "txt_CteRef2Domicilio";
            this.txt_CteRef2Domicilio.Size = new System.Drawing.Size(439, 20);
            this.txt_CteRef2Domicilio.TabIndex = 14;
            // 
            // txt_CteRef1Domicilio
            // 
            this.txt_CteRef1Domicilio.Location = new System.Drawing.Point(92, 51);
            this.txt_CteRef1Domicilio.Name = "txt_CteRef1Domicilio";
            this.txt_CteRef1Domicilio.Size = new System.Drawing.Size(439, 20);
            this.txt_CteRef1Domicilio.TabIndex = 4;
            // 
            // txt_CteRef2Nombre
            // 
            this.txt_CteRef2Nombre.Location = new System.Drawing.Point(92, 108);
            this.txt_CteRef2Nombre.Name = "txt_CteRef2Nombre";
            this.txt_CteRef2Nombre.Size = new System.Drawing.Size(368, 20);
            this.txt_CteRef2Nombre.TabIndex = 11;
            // 
            // txt_CteRef1Nombre
            // 
            this.txt_CteRef1Nombre.Location = new System.Drawing.Point(92, 25);
            this.txt_CteRef1Nombre.Name = "txt_CteRef1Nombre";
            this.txt_CteRef1Nombre.Size = new System.Drawing.Size(368, 20);
            this.txt_CteRef1Nombre.TabIndex = 1;
            // 
            // lbl_CteRef2NumCuenta
            // 
            this.lbl_CteRef2NumCuenta.AutoSize = true;
            this.lbl_CteRef2NumCuenta.Location = new System.Drawing.Point(666, 161);
            this.lbl_CteRef2NumCuenta.Name = "lbl_CteRef2NumCuenta";
            this.lbl_CteRef2NumCuenta.Size = new System.Drawing.Size(74, 13);
            this.lbl_CteRef2NumCuenta.TabIndex = 3;
            this.lbl_CteRef2NumCuenta.Text = "N° de Cuenta:";
            // 
            // lbl_CteRef1NumCuenta
            // 
            this.lbl_CteRef1NumCuenta.AutoSize = true;
            this.lbl_CteRef1NumCuenta.Location = new System.Drawing.Point(666, 78);
            this.lbl_CteRef1NumCuenta.Name = "lbl_CteRef1NumCuenta";
            this.lbl_CteRef1NumCuenta.Size = new System.Drawing.Size(74, 13);
            this.lbl_CteRef1NumCuenta.TabIndex = 3;
            this.lbl_CteRef1NumCuenta.Text = "N° de Cuenta:";
            // 
            // txt_CteRef2Cp
            // 
            this.txt_CteRef2Cp.Location = new System.Drawing.Point(395, 158);
            this.txt_CteRef2Cp.Name = "txt_CteRef2Cp";
            this.txt_CteRef2Cp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteRef2Cp.TabIndex = 17;
            // 
            // txt_CteRef1Cp
            // 
            this.txt_CteRef1Cp.Location = new System.Drawing.Point(395, 75);
            this.txt_CteRef1Cp.Name = "txt_CteRef1Cp";
            this.txt_CteRef1Cp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteRef1Cp.TabIndex = 7;
            // 
            // lbl_CteRef2EsCliente
            // 
            this.lbl_CteRef2EsCliente.AutoSize = true;
            this.lbl_CteRef2EsCliente.Location = new System.Drawing.Point(486, 161);
            this.lbl_CteRef2EsCliente.Name = "lbl_CteRef2EsCliente";
            this.lbl_CteRef2EsCliente.Size = new System.Drawing.Size(97, 13);
            this.lbl_CteRef2EsCliente.TabIndex = 3;
            this.lbl_CteRef2EsCliente.Text = "Es cliente de casa:";
            // 
            // lbl_CteRef1EsCliente
            // 
            this.lbl_CteRef1EsCliente.AutoSize = true;
            this.lbl_CteRef1EsCliente.Location = new System.Drawing.Point(486, 78);
            this.lbl_CteRef1EsCliente.Name = "lbl_CteRef1EsCliente";
            this.lbl_CteRef1EsCliente.Size = new System.Drawing.Size(97, 13);
            this.lbl_CteRef1EsCliente.TabIndex = 3;
            this.lbl_CteRef1EsCliente.Text = "Es cliente de casa:";
            // 
            // lbl_CteRef2Municipio
            // 
            this.lbl_CteRef2Municipio.AutoSize = true;
            this.lbl_CteRef2Municipio.Location = new System.Drawing.Point(39, 161);
            this.lbl_CteRef2Municipio.Name = "lbl_CteRef2Municipio";
            this.lbl_CteRef2Municipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteRef2Municipio.TabIndex = 3;
            this.lbl_CteRef2Municipio.Text = "Municipio:";
            // 
            // lbl_CteRef2Colonia
            // 
            this.lbl_CteRef2Colonia.AutoSize = true;
            this.lbl_CteRef2Colonia.Location = new System.Drawing.Point(537, 137);
            this.lbl_CteRef2Colonia.Name = "lbl_CteRef2Colonia";
            this.lbl_CteRef2Colonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteRef2Colonia.TabIndex = 2;
            this.lbl_CteRef2Colonia.Text = "Colonia:";
            // 
            // lbl_CteRef1Municipio
            // 
            this.lbl_CteRef1Municipio.AutoSize = true;
            this.lbl_CteRef1Municipio.Location = new System.Drawing.Point(39, 78);
            this.lbl_CteRef1Municipio.Name = "lbl_CteRef1Municipio";
            this.lbl_CteRef1Municipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteRef1Municipio.TabIndex = 3;
            this.lbl_CteRef1Municipio.Text = "Municipio:";
            // 
            // lbl_CteRef2Telefono
            // 
            this.lbl_CteRef2Telefono.AutoSize = true;
            this.lbl_CteRef2Telefono.Location = new System.Drawing.Point(720, 111);
            this.lbl_CteRef2Telefono.Name = "lbl_CteRef2Telefono";
            this.lbl_CteRef2Telefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteRef2Telefono.TabIndex = 1;
            this.lbl_CteRef2Telefono.Text = "Teléfono:";
            // 
            // lbl_CteRef1Colonia
            // 
            this.lbl_CteRef1Colonia.AutoSize = true;
            this.lbl_CteRef1Colonia.Location = new System.Drawing.Point(537, 54);
            this.lbl_CteRef1Colonia.Name = "lbl_CteRef1Colonia";
            this.lbl_CteRef1Colonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteRef1Colonia.TabIndex = 2;
            this.lbl_CteRef1Colonia.Text = "Colonia:";
            // 
            // lbl_CteRef2Domicilio
            // 
            this.lbl_CteRef2Domicilio.AutoSize = true;
            this.lbl_CteRef2Domicilio.Location = new System.Drawing.Point(39, 137);
            this.lbl_CteRef2Domicilio.Name = "lbl_CteRef2Domicilio";
            this.lbl_CteRef2Domicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteRef2Domicilio.TabIndex = 1;
            this.lbl_CteRef2Domicilio.Text = "Domicilio:";
            // 
            // lbl_CteRef1Telefono
            // 
            this.lbl_CteRef1Telefono.AutoSize = true;
            this.lbl_CteRef1Telefono.Location = new System.Drawing.Point(720, 28);
            this.lbl_CteRef1Telefono.Name = "lbl_CteRef1Telefono";
            this.lbl_CteRef1Telefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteRef1Telefono.TabIndex = 1;
            this.lbl_CteRef1Telefono.Text = "Teléfono:";
            // 
            // lbl_CteRef2Parentesco
            // 
            this.lbl_CteRef2Parentesco.AutoSize = true;
            this.lbl_CteRef2Parentesco.Location = new System.Drawing.Point(472, 111);
            this.lbl_CteRef2Parentesco.Name = "lbl_CteRef2Parentesco";
            this.lbl_CteRef2Parentesco.Size = new System.Drawing.Size(64, 13);
            this.lbl_CteRef2Parentesco.TabIndex = 0;
            this.lbl_CteRef2Parentesco.Text = "Parentesco:";
            // 
            // lbl_CteRef1Domicilio
            // 
            this.lbl_CteRef1Domicilio.AutoSize = true;
            this.lbl_CteRef1Domicilio.Location = new System.Drawing.Point(39, 54);
            this.lbl_CteRef1Domicilio.Name = "lbl_CteRef1Domicilio";
            this.lbl_CteRef1Domicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteRef1Domicilio.TabIndex = 1;
            this.lbl_CteRef1Domicilio.Text = "Domicilio:";
            // 
            // lbl_CteRef2Cp
            // 
            this.lbl_CteRef2Cp.AutoSize = true;
            this.lbl_CteRef2Cp.Location = new System.Drawing.Point(359, 162);
            this.lbl_CteRef2Cp.Name = "lbl_CteRef2Cp";
            this.lbl_CteRef2Cp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteRef2Cp.TabIndex = 50;
            this.lbl_CteRef2Cp.Text = "C.P.:";
            // 
            // lbl_CteRef1Parentesco
            // 
            this.lbl_CteRef1Parentesco.AutoSize = true;
            this.lbl_CteRef1Parentesco.Location = new System.Drawing.Point(472, 28);
            this.lbl_CteRef1Parentesco.Name = "lbl_CteRef1Parentesco";
            this.lbl_CteRef1Parentesco.Size = new System.Drawing.Size(64, 13);
            this.lbl_CteRef1Parentesco.TabIndex = 0;
            this.lbl_CteRef1Parentesco.Text = "Parentesco:";
            // 
            // lbl_CteRef2Nombre
            // 
            this.lbl_CteRef2Nombre.AutoSize = true;
            this.lbl_CteRef2Nombre.Location = new System.Drawing.Point(39, 111);
            this.lbl_CteRef2Nombre.Name = "lbl_CteRef2Nombre";
            this.lbl_CteRef2Nombre.Size = new System.Drawing.Size(47, 13);
            this.lbl_CteRef2Nombre.TabIndex = 0;
            this.lbl_CteRef2Nombre.Text = "Nombre:";
            // 
            // lbl_CteRef1Cp
            // 
            this.lbl_CteRef1Cp.AutoSize = true;
            this.lbl_CteRef1Cp.Location = new System.Drawing.Point(359, 79);
            this.lbl_CteRef1Cp.Name = "lbl_CteRef1Cp";
            this.lbl_CteRef1Cp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteRef1Cp.TabIndex = 50;
            this.lbl_CteRef1Cp.Text = "C.P.:";
            // 
            // lbl_CteRef1Nombre
            // 
            this.lbl_CteRef1Nombre.AutoSize = true;
            this.lbl_CteRef1Nombre.Location = new System.Drawing.Point(39, 28);
            this.lbl_CteRef1Nombre.Name = "lbl_CteRef1Nombre";
            this.lbl_CteRef1Nombre.Size = new System.Drawing.Size(47, 13);
            this.lbl_CteRef1Nombre.TabIndex = 0;
            this.lbl_CteRef1Nombre.Text = "Nombre:";
            // 
            // gb_RCCTE
            // 
            this.gb_RCCTE.Controls.Add(this.txt_CteRefComer3);
            this.gb_RCCTE.Controls.Add(this.txt_CteRefComer2);
            this.gb_RCCTE.Controls.Add(this.txt_CteRefComer1);
            this.gb_RCCTE.Controls.Add(this.lbl_CteRefComer3);
            this.gb_RCCTE.Controls.Add(this.lbl_CteRefComer2);
            this.gb_RCCTE.Controls.Add(this.lbl_CteRefComer1);
            this.gb_RCCTE.Location = new System.Drawing.Point(12, 1367);
            this.gb_RCCTE.Name = "gb_RCCTE";
            this.gb_RCCTE.Size = new System.Drawing.Size(989, 63);
            this.gb_RCCTE.TabIndex = 7;
            this.gb_RCCTE.TabStop = false;
            this.gb_RCCTE.Text = "REFERENCIAS COMERCIALES";
            // 
            // txt_CteRefComer3
            // 
            this.txt_CteRefComer3.Location = new System.Drawing.Point(666, 32);
            this.txt_CteRefComer3.Name = "txt_CteRefComer3";
            this.txt_CteRefComer3.Size = new System.Drawing.Size(271, 20);
            this.txt_CteRefComer3.TabIndex = 3;
            // 
            // txt_CteRefComer2
            // 
            this.txt_CteRefComer2.Location = new System.Drawing.Point(361, 32);
            this.txt_CteRefComer2.Name = "txt_CteRefComer2";
            this.txt_CteRefComer2.Size = new System.Drawing.Size(271, 20);
            this.txt_CteRefComer2.TabIndex = 2;
            // 
            // txt_CteRefComer1
            // 
            this.txt_CteRefComer1.Location = new System.Drawing.Point(64, 32);
            this.txt_CteRefComer1.Name = "txt_CteRefComer1";
            this.txt_CteRefComer1.Size = new System.Drawing.Size(271, 20);
            this.txt_CteRefComer1.TabIndex = 1;
            // 
            // lbl_CteRefComer3
            // 
            this.lbl_CteRefComer3.AutoSize = true;
            this.lbl_CteRefComer3.Location = new System.Drawing.Point(641, 35);
            this.lbl_CteRefComer3.Name = "lbl_CteRefComer3";
            this.lbl_CteRefComer3.Size = new System.Drawing.Size(19, 13);
            this.lbl_CteRefComer3.TabIndex = 0;
            this.lbl_CteRefComer3.Text = "3.-";
            // 
            // lbl_CteRefComer2
            // 
            this.lbl_CteRefComer2.AutoSize = true;
            this.lbl_CteRefComer2.Location = new System.Drawing.Point(341, 35);
            this.lbl_CteRefComer2.Name = "lbl_CteRefComer2";
            this.lbl_CteRefComer2.Size = new System.Drawing.Size(19, 13);
            this.lbl_CteRefComer2.TabIndex = 0;
            this.lbl_CteRefComer2.Text = "2.-";
            // 
            // lbl_CteRefComer1
            // 
            this.lbl_CteRefComer1.AutoSize = true;
            this.lbl_CteRefComer1.Location = new System.Drawing.Point(39, 35);
            this.lbl_CteRefComer1.Name = "lbl_CteRefComer1";
            this.lbl_CteRefComer1.Size = new System.Drawing.Size(19, 13);
            this.lbl_CteRefComer1.TabIndex = 0;
            this.lbl_CteRefComer1.Text = "1.-";
            // 
            // gb_RBCTE
            // 
            this.gb_RBCTE.Controls.Add(this.lbl_TCreBancoNum2);
            this.gb_RBCTE.Controls.Add(this.lbl_TComEmisorNum2);
            this.gb_RBCTE.Controls.Add(this.lbl_TComEmisorNum1);
            this.gb_RBCTE.Controls.Add(this.lbl_TCreBancoNum1);
            this.gb_RBCTE.Controls.Add(this.txt_TCreBancoNum2);
            this.gb_RBCTE.Controls.Add(this.txt_TComEmisorNum2);
            this.gb_RBCTE.Controls.Add(this.txt_TComEmisorNum1);
            this.gb_RBCTE.Controls.Add(this.txt_TCreBancoNum1);
            this.gb_RBCTE.Location = new System.Drawing.Point(12, 1442);
            this.gb_RBCTE.Name = "gb_RBCTE";
            this.gb_RBCTE.Size = new System.Drawing.Size(989, 103);
            this.gb_RBCTE.TabIndex = 8;
            this.gb_RBCTE.TabStop = false;
            this.gb_RBCTE.Text = "REFERENCIAS BANCARIAS (NO CUENTAS DE CHEQUES)";
            // 
            // lbl_TCreBancoNum2
            // 
            this.lbl_TCreBancoNum2.AutoSize = true;
            this.lbl_TCreBancoNum2.Location = new System.Drawing.Point(487, 32);
            this.lbl_TCreBancoNum2.Name = "lbl_TCreBancoNum2";
            this.lbl_TCreBancoNum2.Size = new System.Drawing.Size(129, 13);
            this.lbl_TCreBancoNum2.TabIndex = 0;
            this.lbl_TCreBancoNum2.Text = "Tarj. Crédito Banco y No.:";
            // 
            // lbl_TComEmisorNum2
            // 
            this.lbl_TComEmisorNum2.AutoSize = true;
            this.lbl_TComEmisorNum2.Location = new System.Drawing.Point(487, 61);
            this.lbl_TComEmisorNum2.Name = "lbl_TComEmisorNum2";
            this.lbl_TComEmisorNum2.Size = new System.Drawing.Size(142, 13);
            this.lbl_TComEmisorNum2.TabIndex = 0;
            this.lbl_TComEmisorNum2.Text = "Tarj. Comercial Emisor y No.:";
            // 
            // lbl_TComEmisorNum1
            // 
            this.lbl_TComEmisorNum1.AutoSize = true;
            this.lbl_TComEmisorNum1.Location = new System.Drawing.Point(39, 61);
            this.lbl_TComEmisorNum1.Name = "lbl_TComEmisorNum1";
            this.lbl_TComEmisorNum1.Size = new System.Drawing.Size(142, 13);
            this.lbl_TComEmisorNum1.TabIndex = 0;
            this.lbl_TComEmisorNum1.Text = "Tarj. Comercial Emisor y No.:";
            // 
            // lbl_TCreBancoNum1
            // 
            this.lbl_TCreBancoNum1.AutoSize = true;
            this.lbl_TCreBancoNum1.Location = new System.Drawing.Point(39, 32);
            this.lbl_TCreBancoNum1.Name = "lbl_TCreBancoNum1";
            this.lbl_TCreBancoNum1.Size = new System.Drawing.Size(129, 13);
            this.lbl_TCreBancoNum1.TabIndex = 0;
            this.lbl_TCreBancoNum1.Text = "Tarj. Crédito Banco y No.:";
            // 
            // txt_TCreBancoNum2
            // 
            this.txt_TCreBancoNum2.Location = new System.Drawing.Point(643, 29);
            this.txt_TCreBancoNum2.Name = "txt_TCreBancoNum2";
            this.txt_TCreBancoNum2.Size = new System.Drawing.Size(289, 20);
            this.txt_TCreBancoNum2.TabIndex = 3;
            // 
            // txt_TComEmisorNum2
            // 
            this.txt_TComEmisorNum2.Location = new System.Drawing.Point(643, 58);
            this.txt_TComEmisorNum2.Name = "txt_TComEmisorNum2";
            this.txt_TComEmisorNum2.Size = new System.Drawing.Size(289, 20);
            this.txt_TComEmisorNum2.TabIndex = 4;
            // 
            // txt_TComEmisorNum1
            // 
            this.txt_TComEmisorNum1.Location = new System.Drawing.Point(187, 58);
            this.txt_TComEmisorNum1.Name = "txt_TComEmisorNum1";
            this.txt_TComEmisorNum1.Size = new System.Drawing.Size(289, 20);
            this.txt_TComEmisorNum1.TabIndex = 2;
            // 
            // txt_TCreBancoNum1
            // 
            this.txt_TCreBancoNum1.Location = new System.Drawing.Point(187, 29);
            this.txt_TCreBancoNum1.Name = "txt_TCreBancoNum1";
            this.txt_TCreBancoNum1.Size = new System.Drawing.Size(289, 20);
            this.txt_TCreBancoNum1.TabIndex = 1;
            // 
            // gb_DEConyugeCte
            // 
            this.gb_DEConyugeCte.Controls.Add(this.ddl_CteConyugeEmpPeriodoIngresos);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpPuestoJefe);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpColonia);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpIngresos);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntMunicipio);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpMunicipio);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntColonia);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpTelefono);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntDomicilio);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntEmpresa);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpCruces);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpDomicilio);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntiguedad);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpJefe);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpPuestoJefe);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpJefe);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpDpto);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpFunciones);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpEmpresa);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpEmpresa);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpDpto);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpAntCp);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpCp);
            this.gb_DEConyugeCte.Controls.Add(this.txt_CteConyugeEmpFunciones);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpColonia);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntMunicipio);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpMunicipio);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpTelefono);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntColonia);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntDomicilio);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntEmpresa);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpCruces);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpPeriodoIngresos);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpIngresos);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntiguedad);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpAntCp);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpCp);
            this.gb_DEConyugeCte.Controls.Add(this.lbl_CteConyugeEmpDomicilio);
            this.gb_DEConyugeCte.Location = new System.Drawing.Point(12, 897);
            this.gb_DEConyugeCte.Name = "gb_DEConyugeCte";
            this.gb_DEConyugeCte.Size = new System.Drawing.Size(989, 252);
            this.gb_DEConyugeCte.TabIndex = 5;
            this.gb_DEConyugeCte.TabStop = false;
            this.gb_DEConyugeCte.Text = "DATOS DEL EMPLEO DEL CONYUGE DEL CLIENTE";
            // 
            // ddl_CteConyugeEmpPeriodoIngresos
            // 
            this.ddl_CteConyugeEmpPeriodoIngresos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_CteConyugeEmpPeriodoIngresos.Enabled = false;
            this.ddl_CteConyugeEmpPeriodoIngresos.Location = new System.Drawing.Point(692, 75);
            this.ddl_CteConyugeEmpPeriodoIngresos.Name = "ddl_CteConyugeEmpPeriodoIngresos";
            this.ddl_CteConyugeEmpPeriodoIngresos.Size = new System.Drawing.Size(240, 21);
            this.ddl_CteConyugeEmpPeriodoIngresos.TabIndex = 8;
            // 
            // txt_CteConyugeEmpPuestoJefe
            // 
            this.txt_CteConyugeEmpPuestoJefe.Enabled = false;
            this.txt_CteConyugeEmpPuestoJefe.Location = new System.Drawing.Point(598, 52);
            this.txt_CteConyugeEmpPuestoJefe.Name = "txt_CteConyugeEmpPuestoJefe";
            this.txt_CteConyugeEmpPuestoJefe.Size = new System.Drawing.Size(334, 20);
            this.txt_CteConyugeEmpPuestoJefe.TabIndex = 5;
            // 
            // txt_CteConyugeEmpColonia
            // 
            this.txt_CteConyugeEmpColonia.Enabled = false;
            this.txt_CteConyugeEmpColonia.Location = new System.Drawing.Point(697, 102);
            this.txt_CteConyugeEmpColonia.Name = "txt_CteConyugeEmpColonia";
            this.txt_CteConyugeEmpColonia.Size = new System.Drawing.Size(234, 20);
            this.txt_CteConyugeEmpColonia.TabIndex = 10;
            // 
            // txt_CteConyugeEmpIngresos
            // 
            this.txt_CteConyugeEmpIngresos.Enabled = false;
            this.txt_CteConyugeEmpIngresos.Location = new System.Drawing.Point(438, 76);
            this.txt_CteConyugeEmpIngresos.Name = "txt_CteConyugeEmpIngresos";
            this.txt_CteConyugeEmpIngresos.Size = new System.Drawing.Size(143, 20);
            this.txt_CteConyugeEmpIngresos.TabIndex = 7;
            this.txt_CteConyugeEmpIngresos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteConyugeEmpIngresos_KeyPress);
            // 
            // txt_CteConyugeEmpAntMunicipio
            // 
            this.txt_CteConyugeEmpAntMunicipio.Enabled = false;
            this.txt_CteConyugeEmpAntMunicipio.Location = new System.Drawing.Point(462, 206);
            this.txt_CteConyugeEmpAntMunicipio.Name = "txt_CteConyugeEmpAntMunicipio";
            this.txt_CteConyugeEmpAntMunicipio.Size = new System.Drawing.Size(318, 20);
            this.txt_CteConyugeEmpAntMunicipio.TabIndex = 18;
            // 
            // txt_CteConyugeEmpMunicipio
            // 
            this.txt_CteConyugeEmpMunicipio.Enabled = false;
            this.txt_CteConyugeEmpMunicipio.Location = new System.Drawing.Point(121, 128);
            this.txt_CteConyugeEmpMunicipio.Name = "txt_CteConyugeEmpMunicipio";
            this.txt_CteConyugeEmpMunicipio.Size = new System.Drawing.Size(361, 20);
            this.txt_CteConyugeEmpMunicipio.TabIndex = 11;
            // 
            // txt_CteConyugeEmpAntColonia
            // 
            this.txt_CteConyugeEmpAntColonia.Enabled = false;
            this.txt_CteConyugeEmpAntColonia.Location = new System.Drawing.Point(90, 205);
            this.txt_CteConyugeEmpAntColonia.Name = "txt_CteConyugeEmpAntColonia";
            this.txt_CteConyugeEmpAntColonia.Size = new System.Drawing.Size(306, 20);
            this.txt_CteConyugeEmpAntColonia.TabIndex = 17;
            // 
            // txt_CteConyugeEmpTelefono
            // 
            this.txt_CteConyugeEmpTelefono.Enabled = false;
            this.txt_CteConyugeEmpTelefono.Location = new System.Drawing.Point(697, 128);
            this.txt_CteConyugeEmpTelefono.Name = "txt_CteConyugeEmpTelefono";
            this.txt_CteConyugeEmpTelefono.Size = new System.Drawing.Size(235, 20);
            this.txt_CteConyugeEmpTelefono.TabIndex = 13;
            this.txt_CteConyugeEmpTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CteConyugeEmpTelefono_KeyPress);
            // 
            // txt_CteConyugeEmpAntDomicilio
            // 
            this.txt_CteConyugeEmpAntDomicilio.Enabled = false;
            this.txt_CteConyugeEmpAntDomicilio.Location = new System.Drawing.Point(172, 179);
            this.txt_CteConyugeEmpAntDomicilio.Name = "txt_CteConyugeEmpAntDomicilio";
            this.txt_CteConyugeEmpAntDomicilio.Size = new System.Drawing.Size(759, 20);
            this.txt_CteConyugeEmpAntDomicilio.TabIndex = 16;
            // 
            // txt_CteConyugeEmpAntEmpresa
            // 
            this.txt_CteConyugeEmpAntEmpresa.Enabled = false;
            this.txt_CteConyugeEmpAntEmpresa.Location = new System.Drawing.Point(573, 153);
            this.txt_CteConyugeEmpAntEmpresa.Name = "txt_CteConyugeEmpAntEmpresa";
            this.txt_CteConyugeEmpAntEmpresa.Size = new System.Drawing.Size(358, 20);
            this.txt_CteConyugeEmpAntEmpresa.TabIndex = 15;
            // 
            // txt_CteConyugeEmpCruces
            // 
            this.txt_CteConyugeEmpCruces.Enabled = false;
            this.txt_CteConyugeEmpCruces.Location = new System.Drawing.Point(121, 153);
            this.txt_CteConyugeEmpCruces.Name = "txt_CteConyugeEmpCruces";
            this.txt_CteConyugeEmpCruces.Size = new System.Drawing.Size(355, 20);
            this.txt_CteConyugeEmpCruces.TabIndex = 14;
            // 
            // txt_CteConyugeEmpDomicilio
            // 
            this.txt_CteConyugeEmpDomicilio.Enabled = false;
            this.txt_CteConyugeEmpDomicilio.Location = new System.Drawing.Point(121, 102);
            this.txt_CteConyugeEmpDomicilio.Name = "txt_CteConyugeEmpDomicilio";
            this.txt_CteConyugeEmpDomicilio.Size = new System.Drawing.Size(519, 20);
            this.txt_CteConyugeEmpDomicilio.TabIndex = 9;
            // 
            // txt_CteConyugeEmpAntiguedad
            // 
            this.txt_CteConyugeEmpAntiguedad.Enabled = false;
            this.txt_CteConyugeEmpAntiguedad.Location = new System.Drawing.Point(121, 77);
            this.txt_CteConyugeEmpAntiguedad.Name = "txt_CteConyugeEmpAntiguedad";
            this.txt_CteConyugeEmpAntiguedad.Size = new System.Drawing.Size(246, 20);
            this.txt_CteConyugeEmpAntiguedad.TabIndex = 6;
            // 
            // txt_CteConyugeEmpJefe
            // 
            this.txt_CteConyugeEmpJefe.Enabled = false;
            this.txt_CteConyugeEmpJefe.Location = new System.Drawing.Point(121, 52);
            this.txt_CteConyugeEmpJefe.Name = "txt_CteConyugeEmpJefe";
            this.txt_CteConyugeEmpJefe.Size = new System.Drawing.Size(339, 20);
            this.txt_CteConyugeEmpJefe.TabIndex = 4;
            // 
            // lbl_CteConyugeEmpPuestoJefe
            // 
            this.lbl_CteConyugeEmpPuestoJefe.AutoSize = true;
            this.lbl_CteConyugeEmpPuestoJefe.Location = new System.Drawing.Point(460, 55);
            this.lbl_CteConyugeEmpPuestoJefe.Name = "lbl_CteConyugeEmpPuestoJefe";
            this.lbl_CteConyugeEmpPuestoJefe.Size = new System.Drawing.Size(132, 13);
            this.lbl_CteConyugeEmpPuestoJefe.TabIndex = 53;
            this.lbl_CteConyugeEmpPuestoJefe.Text = "Puesto del Jefe Inmediato:";
            // 
            // lbl_CteConyugeEmpJefe
            // 
            this.lbl_CteConyugeEmpJefe.AutoSize = true;
            this.lbl_CteConyugeEmpJefe.Location = new System.Drawing.Point(39, 55);
            this.lbl_CteConyugeEmpJefe.Name = "lbl_CteConyugeEmpJefe";
            this.lbl_CteConyugeEmpJefe.Size = new System.Drawing.Size(79, 13);
            this.lbl_CteConyugeEmpJefe.TabIndex = 52;
            this.lbl_CteConyugeEmpJefe.Text = "Jefe Inmediato:";
            // 
            // lbl_CteConyugeEmpDpto
            // 
            this.lbl_CteConyugeEmpDpto.AutoSize = true;
            this.lbl_CteConyugeEmpDpto.Location = new System.Drawing.Point(703, 29);
            this.lbl_CteConyugeEmpDpto.Name = "lbl_CteConyugeEmpDpto";
            this.lbl_CteConyugeEmpDpto.Size = new System.Drawing.Size(77, 13);
            this.lbl_CteConyugeEmpDpto.TabIndex = 51;
            this.lbl_CteConyugeEmpDpto.Text = "Departamento:";
            // 
            // lbl_CteConyugeEmpFunciones
            // 
            this.lbl_CteConyugeEmpFunciones.AutoSize = true;
            this.lbl_CteConyugeEmpFunciones.Location = new System.Drawing.Point(472, 29);
            this.lbl_CteConyugeEmpFunciones.Name = "lbl_CteConyugeEmpFunciones";
            this.lbl_CteConyugeEmpFunciones.Size = new System.Drawing.Size(59, 13);
            this.lbl_CteConyugeEmpFunciones.TabIndex = 50;
            this.lbl_CteConyugeEmpFunciones.Text = "Funciones:";
            // 
            // lbl_CteConyugeEmpEmpresa
            // 
            this.lbl_CteConyugeEmpEmpresa.AutoSize = true;
            this.lbl_CteConyugeEmpEmpresa.Location = new System.Drawing.Point(42, 29);
            this.lbl_CteConyugeEmpEmpresa.Name = "lbl_CteConyugeEmpEmpresa";
            this.lbl_CteConyugeEmpEmpresa.Size = new System.Drawing.Size(51, 13);
            this.lbl_CteConyugeEmpEmpresa.TabIndex = 49;
            this.lbl_CteConyugeEmpEmpresa.Text = "Empresa:";
            // 
            // txt_CteConyugeEmpEmpresa
            // 
            this.txt_CteConyugeEmpEmpresa.Enabled = false;
            this.txt_CteConyugeEmpEmpresa.Location = new System.Drawing.Point(121, 26);
            this.txt_CteConyugeEmpEmpresa.Name = "txt_CteConyugeEmpEmpresa";
            this.txt_CteConyugeEmpEmpresa.Size = new System.Drawing.Size(342, 20);
            this.txt_CteConyugeEmpEmpresa.TabIndex = 1;
            // 
            // txt_CteConyugeEmpDpto
            // 
            this.txt_CteConyugeEmpDpto.Enabled = false;
            this.txt_CteConyugeEmpDpto.Location = new System.Drawing.Point(786, 26);
            this.txt_CteConyugeEmpDpto.Name = "txt_CteConyugeEmpDpto";
            this.txt_CteConyugeEmpDpto.Size = new System.Drawing.Size(145, 20);
            this.txt_CteConyugeEmpDpto.TabIndex = 3;
            // 
            // txt_CteConyugeEmpAntCp
            // 
            this.txt_CteConyugeEmpAntCp.Enabled = false;
            this.txt_CteConyugeEmpAntCp.Location = new System.Drawing.Point(826, 205);
            this.txt_CteConyugeEmpAntCp.Name = "txt_CteConyugeEmpAntCp";
            this.txt_CteConyugeEmpAntCp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteConyugeEmpAntCp.TabIndex = 19;
            // 
            // txt_CteConyugeEmpCp
            // 
            this.txt_CteConyugeEmpCp.Enabled = false;
            this.txt_CteConyugeEmpCp.Location = new System.Drawing.Point(532, 128);
            this.txt_CteConyugeEmpCp.Name = "txt_CteConyugeEmpCp";
            this.txt_CteConyugeEmpCp.Size = new System.Drawing.Size(106, 20);
            this.txt_CteConyugeEmpCp.TabIndex = 12;
            // 
            // txt_CteConyugeEmpFunciones
            // 
            this.txt_CteConyugeEmpFunciones.Enabled = false;
            this.txt_CteConyugeEmpFunciones.Location = new System.Drawing.Point(537, 26);
            this.txt_CteConyugeEmpFunciones.Name = "txt_CteConyugeEmpFunciones";
            this.txt_CteConyugeEmpFunciones.Size = new System.Drawing.Size(158, 20);
            this.txt_CteConyugeEmpFunciones.TabIndex = 2;
            // 
            // lbl_CteConyugeEmpColonia
            // 
            this.lbl_CteConyugeEmpColonia.AutoSize = true;
            this.lbl_CteConyugeEmpColonia.Location = new System.Drawing.Point(646, 105);
            this.lbl_CteConyugeEmpColonia.Name = "lbl_CteConyugeEmpColonia";
            this.lbl_CteConyugeEmpColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteConyugeEmpColonia.TabIndex = 46;
            this.lbl_CteConyugeEmpColonia.Text = "Colonia:";
            // 
            // lbl_CteConyugeEmpAntMunicipio
            // 
            this.lbl_CteConyugeEmpAntMunicipio.AutoSize = true;
            this.lbl_CteConyugeEmpAntMunicipio.Location = new System.Drawing.Point(405, 209);
            this.lbl_CteConyugeEmpAntMunicipio.Name = "lbl_CteConyugeEmpAntMunicipio";
            this.lbl_CteConyugeEmpAntMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteConyugeEmpAntMunicipio.TabIndex = 45;
            this.lbl_CteConyugeEmpAntMunicipio.Text = "Municipio:";
            // 
            // lbl_CteConyugeEmpMunicipio
            // 
            this.lbl_CteConyugeEmpMunicipio.AutoSize = true;
            this.lbl_CteConyugeEmpMunicipio.Location = new System.Drawing.Point(39, 131);
            this.lbl_CteConyugeEmpMunicipio.Name = "lbl_CteConyugeEmpMunicipio";
            this.lbl_CteConyugeEmpMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_CteConyugeEmpMunicipio.TabIndex = 44;
            this.lbl_CteConyugeEmpMunicipio.Text = "Municipio:";
            // 
            // lbl_CteConyugeEmpTelefono
            // 
            this.lbl_CteConyugeEmpTelefono.AutoSize = true;
            this.lbl_CteConyugeEmpTelefono.Location = new System.Drawing.Point(640, 131);
            this.lbl_CteConyugeEmpTelefono.Name = "lbl_CteConyugeEmpTelefono";
            this.lbl_CteConyugeEmpTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteConyugeEmpTelefono.TabIndex = 43;
            this.lbl_CteConyugeEmpTelefono.Text = "Teléfono:";
            // 
            // lbl_CteConyugeEmpAntColonia
            // 
            this.lbl_CteConyugeEmpAntColonia.AutoSize = true;
            this.lbl_CteConyugeEmpAntColonia.Location = new System.Drawing.Point(39, 209);
            this.lbl_CteConyugeEmpAntColonia.Name = "lbl_CteConyugeEmpAntColonia";
            this.lbl_CteConyugeEmpAntColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_CteConyugeEmpAntColonia.TabIndex = 42;
            this.lbl_CteConyugeEmpAntColonia.Text = "Colonia:";
            // 
            // lbl_CteConyugeEmpAntDomicilio
            // 
            this.lbl_CteConyugeEmpAntDomicilio.AutoSize = true;
            this.lbl_CteConyugeEmpAntDomicilio.Location = new System.Drawing.Point(39, 182);
            this.lbl_CteConyugeEmpAntDomicilio.Name = "lbl_CteConyugeEmpAntDomicilio";
            this.lbl_CteConyugeEmpAntDomicilio.Size = new System.Drawing.Size(130, 13);
            this.lbl_CteConyugeEmpAntDomicilio.TabIndex = 41;
            this.lbl_CteConyugeEmpAntDomicilio.Text = "Domicilio Trabajo Anterior:";
            // 
            // lbl_CteConyugeEmpAntEmpresa
            // 
            this.lbl_CteConyugeEmpAntEmpresa.AutoSize = true;
            this.lbl_CteConyugeEmpAntEmpresa.Location = new System.Drawing.Point(482, 156);
            this.lbl_CteConyugeEmpAntEmpresa.Name = "lbl_CteConyugeEmpAntEmpresa";
            this.lbl_CteConyugeEmpAntEmpresa.Size = new System.Drawing.Size(85, 13);
            this.lbl_CteConyugeEmpAntEmpresa.TabIndex = 41;
            this.lbl_CteConyugeEmpAntEmpresa.Text = "Trabajo Anterior:";
            // 
            // lbl_CteConyugeEmpCruces
            // 
            this.lbl_CteConyugeEmpCruces.AutoSize = true;
            this.lbl_CteConyugeEmpCruces.Location = new System.Drawing.Point(39, 156);
            this.lbl_CteConyugeEmpCruces.Name = "lbl_CteConyugeEmpCruces";
            this.lbl_CteConyugeEmpCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_CteConyugeEmpCruces.TabIndex = 40;
            this.lbl_CteConyugeEmpCruces.Text = "Cruces:";
            // 
            // lbl_CteConyugeEmpPeriodoIngresos
            // 
            this.lbl_CteConyugeEmpPeriodoIngresos.AutoSize = true;
            this.lbl_CteConyugeEmpPeriodoIngresos.Location = new System.Drawing.Point(587, 80);
            this.lbl_CteConyugeEmpPeriodoIngresos.Name = "lbl_CteConyugeEmpPeriodoIngresos";
            this.lbl_CteConyugeEmpPeriodoIngresos.Size = new System.Drawing.Size(104, 13);
            this.lbl_CteConyugeEmpPeriodoIngresos.TabIndex = 38;
            this.lbl_CteConyugeEmpPeriodoIngresos.Text = "Periodo de Ingresos:";
            // 
            // lbl_CteConyugeEmpIngresos
            // 
            this.lbl_CteConyugeEmpIngresos.AutoSize = true;
            this.lbl_CteConyugeEmpIngresos.Location = new System.Drawing.Point(373, 80);
            this.lbl_CteConyugeEmpIngresos.Name = "lbl_CteConyugeEmpIngresos";
            this.lbl_CteConyugeEmpIngresos.Size = new System.Drawing.Size(59, 13);
            this.lbl_CteConyugeEmpIngresos.TabIndex = 37;
            this.lbl_CteConyugeEmpIngresos.Text = "Ingresos $:";
            // 
            // lbl_CteConyugeEmpAntiguedad
            // 
            this.lbl_CteConyugeEmpAntiguedad.AutoSize = true;
            this.lbl_CteConyugeEmpAntiguedad.Location = new System.Drawing.Point(39, 80);
            this.lbl_CteConyugeEmpAntiguedad.Name = "lbl_CteConyugeEmpAntiguedad";
            this.lbl_CteConyugeEmpAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_CteConyugeEmpAntiguedad.TabIndex = 39;
            this.lbl_CteConyugeEmpAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_CteConyugeEmpAntCp
            // 
            this.lbl_CteConyugeEmpAntCp.AutoSize = true;
            this.lbl_CteConyugeEmpAntCp.Location = new System.Drawing.Point(790, 209);
            this.lbl_CteConyugeEmpAntCp.Name = "lbl_CteConyugeEmpAntCp";
            this.lbl_CteConyugeEmpAntCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteConyugeEmpAntCp.TabIndex = 50;
            this.lbl_CteConyugeEmpAntCp.Text = "C.P.:";
            // 
            // lbl_CteConyugeEmpCp
            // 
            this.lbl_CteConyugeEmpCp.AutoSize = true;
            this.lbl_CteConyugeEmpCp.Location = new System.Drawing.Point(496, 131);
            this.lbl_CteConyugeEmpCp.Name = "lbl_CteConyugeEmpCp";
            this.lbl_CteConyugeEmpCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_CteConyugeEmpCp.TabIndex = 50;
            this.lbl_CteConyugeEmpCp.Text = "C.P.:";
            // 
            // lbl_CteConyugeEmpDomicilio
            // 
            this.lbl_CteConyugeEmpDomicilio.AutoSize = true;
            this.lbl_CteConyugeEmpDomicilio.Location = new System.Drawing.Point(39, 105);
            this.lbl_CteConyugeEmpDomicilio.Name = "lbl_CteConyugeEmpDomicilio";
            this.lbl_CteConyugeEmpDomicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_CteConyugeEmpDomicilio.TabIndex = 36;
            this.lbl_CteConyugeEmpDomicilio.Text = "Domicilio:";
            // 
            // gb_DGAval
            // 
            this.gb_DGAval.Controls.Add(this.gb_ObligatorioDGAval);
            this.gb_DGAval.Controls.Add(this.lbl_AvalObservaciones);
            this.gb_DGAval.Controls.Add(this.chk_SinAval);
            this.gb_DGAval.Controls.Add(this.txt_AvalObservaciones);
            this.gb_DGAval.Controls.Add(this.txt_AvalDomAnterior);
            this.gb_DGAval.Controls.Add(this.txt_AvalMunicipioAnterior);
            this.gb_DGAval.Controls.Add(this.lbl_AvalMunicipioAnterior);
            this.gb_DGAval.Controls.Add(this.txt_AvalColoniaAnterior);
            this.gb_DGAval.Controls.Add(this.txt_AvalCpAnterior);
            this.gb_DGAval.Controls.Add(this.lbl_AvalCpAnterior);
            this.gb_DGAval.Controls.Add(this.lbl_AvalColoniaAnterior);
            this.gb_DGAval.Controls.Add(this.lbl_AvalDomAnterior);
            this.gb_DGAval.Location = new System.Drawing.Point(12, 1553);
            this.gb_DGAval.Name = "gb_DGAval";
            this.gb_DGAval.Size = new System.Drawing.Size(989, 359);
            this.gb_DGAval.TabIndex = 9;
            this.gb_DGAval.TabStop = false;
            this.gb_DGAval.Text = "DATOS GENERALES DEL AVAL";
            // 
            // gb_ObligatorioDGAval
            // 
            this.gb_ObligatorioDGAval.Controls.Add(this.ddl_AvalParentesco);
            this.gb_ObligatorioDGAval.Controls.Add(this.ddl_AvalEdoCivil);
            this.gb_ObligatorioDGAval.Controls.Add(this.dtp_AvalConyugeFechaNacimiento);
            this.gb_ObligatorioDGAval.Controls.Add(this.ddl_AvalCalidadVive);
            this.gb_ObligatorioDGAval.Controls.Add(this.dtp_AvalFechaNacimiento);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalMunicipio);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalCruces);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalMunicipio);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalDomicilio);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalConyuge);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalTelefono);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalCalidadVive);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalColonia);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalAntiguedad);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalCp);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalConyugeEdad);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval7);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalEdad);
            this.gb_ObligatorioDGAval.Controls.Add(this.txt_AvalNombre);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalEdoCivil);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalParentesco);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalTelefono);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalCp);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalColonia);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalCruces);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalAntiguedad);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalDomicilio);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalConyugeFechaNacimiento);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalConyugeEdad);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalConyuge);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalFechaNacimiento);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalEdad);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_AvalNombre);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval6);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval5);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval4);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval3);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval2);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval10);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval15);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval14);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval13);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval12);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval11);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval9);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval8);
            this.gb_ObligatorioDGAval.Controls.Add(this.lbl_Aval1);
            this.gb_ObligatorioDGAval.Location = new System.Drawing.Point(20, 27);
            this.gb_ObligatorioDGAval.Name = "gb_ObligatorioDGAval";
            this.gb_ObligatorioDGAval.Size = new System.Drawing.Size(939, 193);
            this.gb_ObligatorioDGAval.TabIndex = 2;
            this.gb_ObligatorioDGAval.TabStop = false;
            // 
            // ddl_AvalParentesco
            // 
            this.ddl_AvalParentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_AvalParentesco.Location = new System.Drawing.Point(92, 36);
            this.ddl_AvalParentesco.Name = "ddl_AvalParentesco";
            this.ddl_AvalParentesco.Size = new System.Drawing.Size(160, 21);
            this.ddl_AvalParentesco.TabIndex = 4;
            // 
            // ddl_AvalEdoCivil
            // 
            this.ddl_AvalEdoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_AvalEdoCivil.Location = new System.Drawing.Point(318, 36);
            this.ddl_AvalEdoCivil.Name = "ddl_AvalEdoCivil";
            this.ddl_AvalEdoCivil.Size = new System.Drawing.Size(121, 21);
            this.ddl_AvalEdoCivil.TabIndex = 5;
            this.ddl_AvalEdoCivil.SelectedIndexChanged += new System.EventHandler(this.ddl_AvalEdoCivil_SelectedIndexChanged);
            // 
            // dtp_AvalConyugeFechaNacimiento
            // 
            this.dtp_AvalConyugeFechaNacimiento.Enabled = false;
            this.dtp_AvalConyugeFechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_AvalConyugeFechaNacimiento.Location = new System.Drawing.Point(797, 62);
            this.dtp_AvalConyugeFechaNacimiento.Name = "dtp_AvalConyugeFechaNacimiento";
            this.dtp_AvalConyugeFechaNacimiento.Size = new System.Drawing.Size(113, 20);
            this.dtp_AvalConyugeFechaNacimiento.TabIndex = 8;
            // 
            // ddl_AvalCalidadVive
            // 
            this.ddl_AvalCalidadVive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_AvalCalidadVive.Location = new System.Drawing.Point(128, 166);
            this.ddl_AvalCalidadVive.Name = "ddl_AvalCalidadVive";
            this.ddl_AvalCalidadVive.Size = new System.Drawing.Size(187, 21);
            this.ddl_AvalCalidadVive.TabIndex = 16;
            // 
            // dtp_AvalFechaNacimiento
            // 
            this.dtp_AvalFechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_AvalFechaNacimiento.Location = new System.Drawing.Point(796, 12);
            this.dtp_AvalFechaNacimiento.Name = "dtp_AvalFechaNacimiento";
            this.dtp_AvalFechaNacimiento.Size = new System.Drawing.Size(113, 20);
            this.dtp_AvalFechaNacimiento.TabIndex = 3;
            // 
            // txt_AvalMunicipio
            // 
            this.txt_AvalMunicipio.Location = new System.Drawing.Point(79, 140);
            this.txt_AvalMunicipio.Name = "txt_AvalMunicipio";
            this.txt_AvalMunicipio.Size = new System.Drawing.Size(375, 20);
            this.txt_AvalMunicipio.TabIndex = 13;
            // 
            // txt_AvalCruces
            // 
            this.txt_AvalCruces.Location = new System.Drawing.Point(79, 114);
            this.txt_AvalCruces.Name = "txt_AvalCruces";
            this.txt_AvalCruces.Size = new System.Drawing.Size(562, 20);
            this.txt_AvalCruces.TabIndex = 11;
            // 
            // lbl_AvalMunicipio
            // 
            this.lbl_AvalMunicipio.AutoSize = true;
            this.lbl_AvalMunicipio.Location = new System.Drawing.Point(22, 143);
            this.lbl_AvalMunicipio.Name = "lbl_AvalMunicipio";
            this.lbl_AvalMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalMunicipio.TabIndex = 47;
            this.lbl_AvalMunicipio.Text = "Municipio:";
            // 
            // txt_AvalDomicilio
            // 
            this.txt_AvalDomicilio.Location = new System.Drawing.Point(79, 88);
            this.txt_AvalDomicilio.Name = "txt_AvalDomicilio";
            this.txt_AvalDomicilio.Size = new System.Drawing.Size(562, 20);
            this.txt_AvalDomicilio.TabIndex = 9;
            // 
            // txt_AvalConyuge
            // 
            this.txt_AvalConyuge.Enabled = false;
            this.txt_AvalConyuge.Location = new System.Drawing.Point(79, 62);
            this.txt_AvalConyuge.Name = "txt_AvalConyuge";
            this.txt_AvalConyuge.Size = new System.Drawing.Size(430, 20);
            this.txt_AvalConyuge.TabIndex = 6;
            // 
            // txt_AvalTelefono
            // 
            this.txt_AvalTelefono.Location = new System.Drawing.Point(680, 140);
            this.txt_AvalTelefono.Name = "txt_AvalTelefono";
            this.txt_AvalTelefono.Size = new System.Drawing.Size(230, 20);
            this.txt_AvalTelefono.TabIndex = 15;
            // 
            // lbl_AvalCalidadVive
            // 
            this.lbl_AvalCalidadVive.AutoSize = true;
            this.lbl_AvalCalidadVive.Location = new System.Drawing.Point(22, 169);
            this.lbl_AvalCalidadVive.Name = "lbl_AvalCalidadVive";
            this.lbl_AvalCalidadVive.Size = new System.Drawing.Size(99, 13);
            this.lbl_AvalCalidadVive.TabIndex = 51;
            this.lbl_AvalCalidadVive.Text = "Vive en Calidad de:";
            // 
            // txt_AvalColonia
            // 
            this.txt_AvalColonia.Location = new System.Drawing.Point(717, 114);
            this.txt_AvalColonia.Name = "txt_AvalColonia";
            this.txt_AvalColonia.Size = new System.Drawing.Size(193, 20);
            this.txt_AvalColonia.TabIndex = 12;
            // 
            // txt_AvalAntiguedad
            // 
            this.txt_AvalAntiguedad.Location = new System.Drawing.Point(717, 88);
            this.txt_AvalAntiguedad.Name = "txt_AvalAntiguedad";
            this.txt_AvalAntiguedad.Size = new System.Drawing.Size(193, 20);
            this.txt_AvalAntiguedad.TabIndex = 10;
            // 
            // txt_AvalCp
            // 
            this.txt_AvalCp.Location = new System.Drawing.Point(496, 140);
            this.txt_AvalCp.Name = "txt_AvalCp";
            this.txt_AvalCp.Size = new System.Drawing.Size(120, 20);
            this.txt_AvalCp.TabIndex = 14;
            // 
            // txt_AvalConyugeEdad
            // 
            this.txt_AvalConyugeEdad.Enabled = false;
            this.txt_AvalConyugeEdad.Location = new System.Drawing.Point(558, 62);
            this.txt_AvalConyugeEdad.MaxLength = 2;
            this.txt_AvalConyugeEdad.Name = "txt_AvalConyugeEdad";
            this.txt_AvalConyugeEdad.Size = new System.Drawing.Size(121, 20);
            this.txt_AvalConyugeEdad.TabIndex = 7;
            this.txt_AvalConyugeEdad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalConyugeEdad_KeyPress);
            // 
            // lbl_Aval7
            // 
            this.lbl_Aval7.AutoSize = true;
            this.lbl_Aval7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval7.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval7.Location = new System.Drawing.Point(8, 164);
            this.lbl_Aval7.Name = "lbl_Aval7";
            this.lbl_Aval7.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval7.TabIndex = 57;
            this.lbl_Aval7.Text = "*";
            // 
            // txt_AvalEdad
            // 
            this.txt_AvalEdad.Location = new System.Drawing.Point(558, 12);
            this.txt_AvalEdad.MaxLength = 2;
            this.txt_AvalEdad.Name = "txt_AvalEdad";
            this.txt_AvalEdad.Size = new System.Drawing.Size(121, 20);
            this.txt_AvalEdad.TabIndex = 2;
            this.txt_AvalEdad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalEdad_KeyPress);
            // 
            // txt_AvalNombre
            // 
            this.txt_AvalNombre.AcceptsReturn = true;
            this.txt_AvalNombre.Location = new System.Drawing.Point(79, 12);
            this.txt_AvalNombre.Name = "txt_AvalNombre";
            this.txt_AvalNombre.Size = new System.Drawing.Size(430, 20);
            this.txt_AvalNombre.TabIndex = 1;
            // 
            // lbl_AvalEdoCivil
            // 
            this.lbl_AvalEdoCivil.AutoSize = true;
            this.lbl_AvalEdoCivil.Location = new System.Drawing.Point(270, 39);
            this.lbl_AvalEdoCivil.Name = "lbl_AvalEdoCivil";
            this.lbl_AvalEdoCivil.Size = new System.Drawing.Size(51, 13);
            this.lbl_AvalEdoCivil.TabIndex = 56;
            this.lbl_AvalEdoCivil.Text = "Edo Civil:";
            // 
            // lbl_AvalParentesco
            // 
            this.lbl_AvalParentesco.AutoSize = true;
            this.lbl_AvalParentesco.Location = new System.Drawing.Point(22, 40);
            this.lbl_AvalParentesco.Name = "lbl_AvalParentesco";
            this.lbl_AvalParentesco.Size = new System.Drawing.Size(64, 13);
            this.lbl_AvalParentesco.TabIndex = 54;
            this.lbl_AvalParentesco.Text = "Parentesco:";
            // 
            // lbl_AvalTelefono
            // 
            this.lbl_AvalTelefono.AutoSize = true;
            this.lbl_AvalTelefono.Location = new System.Drawing.Point(629, 143);
            this.lbl_AvalTelefono.Name = "lbl_AvalTelefono";
            this.lbl_AvalTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalTelefono.TabIndex = 46;
            this.lbl_AvalTelefono.Text = "Teléfono:";
            // 
            // lbl_AvalCp
            // 
            this.lbl_AvalCp.AutoSize = true;
            this.lbl_AvalCp.Location = new System.Drawing.Point(460, 143);
            this.lbl_AvalCp.Name = "lbl_AvalCp";
            this.lbl_AvalCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalCp.TabIndex = 45;
            this.lbl_AvalCp.Text = "C.P.:";
            // 
            // lbl_AvalColonia
            // 
            this.lbl_AvalColonia.AutoSize = true;
            this.lbl_AvalColonia.Location = new System.Drawing.Point(661, 117);
            this.lbl_AvalColonia.Name = "lbl_AvalColonia";
            this.lbl_AvalColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalColonia.TabIndex = 44;
            this.lbl_AvalColonia.Text = "Colonia:";
            // 
            // lbl_AvalCruces
            // 
            this.lbl_AvalCruces.AutoSize = true;
            this.lbl_AvalCruces.Location = new System.Drawing.Point(22, 117);
            this.lbl_AvalCruces.Name = "lbl_AvalCruces";
            this.lbl_AvalCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_AvalCruces.TabIndex = 43;
            this.lbl_AvalCruces.Text = "Cruces:";
            // 
            // lbl_AvalAntiguedad
            // 
            this.lbl_AvalAntiguedad.AutoSize = true;
            this.lbl_AvalAntiguedad.Location = new System.Drawing.Point(654, 91);
            this.lbl_AvalAntiguedad.Name = "lbl_AvalAntiguedad";
            this.lbl_AvalAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_AvalAntiguedad.TabIndex = 42;
            this.lbl_AvalAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_AvalDomicilio
            // 
            this.lbl_AvalDomicilio.AutoSize = true;
            this.lbl_AvalDomicilio.Location = new System.Drawing.Point(22, 91);
            this.lbl_AvalDomicilio.Name = "lbl_AvalDomicilio";
            this.lbl_AvalDomicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalDomicilio.TabIndex = 41;
            this.lbl_AvalDomicilio.Text = "Domicilio:";
            // 
            // lbl_AvalConyugeFechaNacimiento
            // 
            this.lbl_AvalConyugeFechaNacimiento.AutoSize = true;
            this.lbl_AvalConyugeFechaNacimiento.Location = new System.Drawing.Point(689, 65);
            this.lbl_AvalConyugeFechaNacimiento.Name = "lbl_AvalConyugeFechaNacimiento";
            this.lbl_AvalConyugeFechaNacimiento.Size = new System.Drawing.Size(111, 13);
            this.lbl_AvalConyugeFechaNacimiento.TabIndex = 40;
            this.lbl_AvalConyugeFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lbl_AvalConyugeEdad
            // 
            this.lbl_AvalConyugeEdad.AutoSize = true;
            this.lbl_AvalConyugeEdad.Location = new System.Drawing.Point(521, 65);
            this.lbl_AvalConyugeEdad.Name = "lbl_AvalConyugeEdad";
            this.lbl_AvalConyugeEdad.Size = new System.Drawing.Size(35, 13);
            this.lbl_AvalConyugeEdad.TabIndex = 39;
            this.lbl_AvalConyugeEdad.Text = "Edad:";
            // 
            // lbl_AvalConyuge
            // 
            this.lbl_AvalConyuge.AutoSize = true;
            this.lbl_AvalConyuge.Location = new System.Drawing.Point(22, 65);
            this.lbl_AvalConyuge.Name = "lbl_AvalConyuge";
            this.lbl_AvalConyuge.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalConyuge.TabIndex = 38;
            this.lbl_AvalConyuge.Text = "Conyuge:";
            // 
            // lbl_AvalFechaNacimiento
            // 
            this.lbl_AvalFechaNacimiento.AutoSize = true;
            this.lbl_AvalFechaNacimiento.Location = new System.Drawing.Point(689, 15);
            this.lbl_AvalFechaNacimiento.Name = "lbl_AvalFechaNacimiento";
            this.lbl_AvalFechaNacimiento.Size = new System.Drawing.Size(111, 13);
            this.lbl_AvalFechaNacimiento.TabIndex = 37;
            this.lbl_AvalFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lbl_AvalEdad
            // 
            this.lbl_AvalEdad.AutoSize = true;
            this.lbl_AvalEdad.Location = new System.Drawing.Point(523, 15);
            this.lbl_AvalEdad.Name = "lbl_AvalEdad";
            this.lbl_AvalEdad.Size = new System.Drawing.Size(35, 13);
            this.lbl_AvalEdad.TabIndex = 36;
            this.lbl_AvalEdad.Text = "Edad:";
            // 
            // lbl_AvalNombre
            // 
            this.lbl_AvalNombre.AutoSize = true;
            this.lbl_AvalNombre.Location = new System.Drawing.Point(22, 15);
            this.lbl_AvalNombre.Name = "lbl_AvalNombre";
            this.lbl_AvalNombre.Size = new System.Drawing.Size(31, 13);
            this.lbl_AvalNombre.TabIndex = 35;
            this.lbl_AvalNombre.Text = "Aval:";
            // 
            // lbl_Aval6
            // 
            this.lbl_Aval6.AutoSize = true;
            this.lbl_Aval6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval6.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval6.Location = new System.Drawing.Point(10, 140);
            this.lbl_Aval6.Name = "lbl_Aval6";
            this.lbl_Aval6.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval6.TabIndex = 57;
            this.lbl_Aval6.Text = "*";
            // 
            // lbl_Aval5
            // 
            this.lbl_Aval5.AutoSize = true;
            this.lbl_Aval5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval5.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval5.Location = new System.Drawing.Point(10, 112);
            this.lbl_Aval5.Name = "lbl_Aval5";
            this.lbl_Aval5.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval5.TabIndex = 57;
            this.lbl_Aval5.Text = "*";
            // 
            // lbl_Aval4
            // 
            this.lbl_Aval4.AutoSize = true;
            this.lbl_Aval4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval4.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval4.Location = new System.Drawing.Point(10, 86);
            this.lbl_Aval4.Name = "lbl_Aval4";
            this.lbl_Aval4.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval4.TabIndex = 57;
            this.lbl_Aval4.Text = "*";
            // 
            // lbl_Aval3
            // 
            this.lbl_Aval3.AutoSize = true;
            this.lbl_Aval3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval3.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval3.Location = new System.Drawing.Point(10, 60);
            this.lbl_Aval3.Name = "lbl_Aval3";
            this.lbl_Aval3.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval3.TabIndex = 57;
            this.lbl_Aval3.Text = "*";
            // 
            // lbl_Aval2
            // 
            this.lbl_Aval2.AutoSize = true;
            this.lbl_Aval2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval2.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval2.Location = new System.Drawing.Point(10, 37);
            this.lbl_Aval2.Name = "lbl_Aval2";
            this.lbl_Aval2.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval2.TabIndex = 57;
            this.lbl_Aval2.Text = "*";
            // 
            // lbl_Aval10
            // 
            this.lbl_Aval10.AutoSize = true;
            this.lbl_Aval10.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval10.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval10.Location = new System.Drawing.Point(511, 62);
            this.lbl_Aval10.Name = "lbl_Aval10";
            this.lbl_Aval10.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval10.TabIndex = 57;
            this.lbl_Aval10.Text = "*";
            // 
            // lbl_Aval15
            // 
            this.lbl_Aval15.AutoSize = true;
            this.lbl_Aval15.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval15.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval15.Location = new System.Drawing.Point(618, 140);
            this.lbl_Aval15.Name = "lbl_Aval15";
            this.lbl_Aval15.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval15.TabIndex = 57;
            this.lbl_Aval15.Text = "*";
            // 
            // lbl_Aval14
            // 
            this.lbl_Aval14.AutoSize = true;
            this.lbl_Aval14.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval14.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval14.Location = new System.Drawing.Point(645, 114);
            this.lbl_Aval14.Name = "lbl_Aval14";
            this.lbl_Aval14.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval14.TabIndex = 57;
            this.lbl_Aval14.Text = "*";
            // 
            // lbl_Aval13
            // 
            this.lbl_Aval13.AutoSize = true;
            this.lbl_Aval13.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval13.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval13.Location = new System.Drawing.Point(642, 88);
            this.lbl_Aval13.Name = "lbl_Aval13";
            this.lbl_Aval13.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval13.TabIndex = 57;
            this.lbl_Aval13.Text = "*";
            // 
            // lbl_Aval12
            // 
            this.lbl_Aval12.AutoSize = true;
            this.lbl_Aval12.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval12.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval12.Location = new System.Drawing.Point(679, 63);
            this.lbl_Aval12.Name = "lbl_Aval12";
            this.lbl_Aval12.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval12.TabIndex = 57;
            this.lbl_Aval12.Text = "*";
            // 
            // lbl_Aval11
            // 
            this.lbl_Aval11.AutoSize = true;
            this.lbl_Aval11.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval11.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval11.Location = new System.Drawing.Point(680, 13);
            this.lbl_Aval11.Name = "lbl_Aval11";
            this.lbl_Aval11.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval11.TabIndex = 57;
            this.lbl_Aval11.Text = "*";
            // 
            // lbl_Aval9
            // 
            this.lbl_Aval9.AutoSize = true;
            this.lbl_Aval9.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval9.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval9.Location = new System.Drawing.Point(512, 13);
            this.lbl_Aval9.Name = "lbl_Aval9";
            this.lbl_Aval9.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval9.TabIndex = 57;
            this.lbl_Aval9.Text = "*";
            // 
            // lbl_Aval8
            // 
            this.lbl_Aval8.AutoSize = true;
            this.lbl_Aval8.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval8.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval8.Location = new System.Drawing.Point(258, 38);
            this.lbl_Aval8.Name = "lbl_Aval8";
            this.lbl_Aval8.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval8.TabIndex = 57;
            this.lbl_Aval8.Text = "*";
            // 
            // lbl_Aval1
            // 
            this.lbl_Aval1.AutoSize = true;
            this.lbl_Aval1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aval1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aval1.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aval1.Location = new System.Drawing.Point(10, 12);
            this.lbl_Aval1.Name = "lbl_Aval1";
            this.lbl_Aval1.Size = new System.Drawing.Size(15, 20);
            this.lbl_Aval1.TabIndex = 57;
            this.lbl_Aval1.Text = "*";
            // 
            // lbl_AvalObservaciones
            // 
            this.lbl_AvalObservaciones.AutoSize = true;
            this.lbl_AvalObservaciones.Location = new System.Drawing.Point(42, 281);
            this.lbl_AvalObservaciones.Name = "lbl_AvalObservaciones";
            this.lbl_AvalObservaciones.Size = new System.Drawing.Size(81, 13);
            this.lbl_AvalObservaciones.TabIndex = 1;
            this.lbl_AvalObservaciones.Text = "Observaciones:";
            // 
            // chk_SinAval
            // 
            this.chk_SinAval.AutoSize = true;
            this.chk_SinAval.Location = new System.Drawing.Point(476, 0);
            this.chk_SinAval.Name = "chk_SinAval";
            this.chk_SinAval.Size = new System.Drawing.Size(65, 17);
            this.chk_SinAval.TabIndex = 1;
            this.chk_SinAval.Text = "Sin Aval";
            this.chk_SinAval.UseVisualStyleBackColor = true;
            this.chk_SinAval.CheckedChanged += new System.EventHandler(this.chk_SinAval_CheckedChanged);
            // 
            // txt_AvalObservaciones
            // 
            this.txt_AvalObservaciones.Location = new System.Drawing.Point(116, 297);
            this.txt_AvalObservaciones.Multiline = true;
            this.txt_AvalObservaciones.Name = "txt_AvalObservaciones";
            this.txt_AvalObservaciones.Size = new System.Drawing.Size(817, 51);
            this.txt_AvalObservaciones.TabIndex = 21;
            this.txt_AvalObservaciones.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_AvalObservaciones_KeyDown);
            this.txt_AvalObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalObservaciones_KeyPress);
            this.txt_AvalObservaciones.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txt_AvalObservaciones_MouseDown);
            // 
            // txt_AvalDomAnterior
            // 
            this.txt_AvalDomAnterior.Location = new System.Drawing.Point(122, 229);
            this.txt_AvalDomAnterior.Name = "txt_AvalDomAnterior";
            this.txt_AvalDomAnterior.Size = new System.Drawing.Size(451, 20);
            this.txt_AvalDomAnterior.TabIndex = 17;
            // 
            // txt_AvalMunicipioAnterior
            // 
            this.txt_AvalMunicipioAnterior.Location = new System.Drawing.Point(122, 254);
            this.txt_AvalMunicipioAnterior.Name = "txt_AvalMunicipioAnterior";
            this.txt_AvalMunicipioAnterior.Size = new System.Drawing.Size(393, 20);
            this.txt_AvalMunicipioAnterior.TabIndex = 19;
            // 
            // lbl_AvalMunicipioAnterior
            // 
            this.lbl_AvalMunicipioAnterior.AutoSize = true;
            this.lbl_AvalMunicipioAnterior.Location = new System.Drawing.Point(42, 257);
            this.lbl_AvalMunicipioAnterior.Name = "lbl_AvalMunicipioAnterior";
            this.lbl_AvalMunicipioAnterior.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalMunicipioAnterior.TabIndex = 47;
            this.lbl_AvalMunicipioAnterior.Text = "Municipio:";
            // 
            // txt_AvalColoniaAnterior
            // 
            this.txt_AvalColoniaAnterior.Location = new System.Drawing.Point(630, 229);
            this.txt_AvalColoniaAnterior.Name = "txt_AvalColoniaAnterior";
            this.txt_AvalColoniaAnterior.Size = new System.Drawing.Size(299, 20);
            this.txt_AvalColoniaAnterior.TabIndex = 18;
            // 
            // txt_AvalCpAnterior
            // 
            this.txt_AvalCpAnterior.Location = new System.Drawing.Point(557, 258);
            this.txt_AvalCpAnterior.Name = "txt_AvalCpAnterior";
            this.txt_AvalCpAnterior.Size = new System.Drawing.Size(75, 20);
            this.txt_AvalCpAnterior.TabIndex = 20;
            // 
            // lbl_AvalCpAnterior
            // 
            this.lbl_AvalCpAnterior.AutoSize = true;
            this.lbl_AvalCpAnterior.Location = new System.Drawing.Point(521, 261);
            this.lbl_AvalCpAnterior.Name = "lbl_AvalCpAnterior";
            this.lbl_AvalCpAnterior.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalCpAnterior.TabIndex = 50;
            this.lbl_AvalCpAnterior.Text = "C.P.:";
            // 
            // lbl_AvalColoniaAnterior
            // 
            this.lbl_AvalColoniaAnterior.AutoSize = true;
            this.lbl_AvalColoniaAnterior.Location = new System.Drawing.Point(579, 232);
            this.lbl_AvalColoniaAnterior.Name = "lbl_AvalColoniaAnterior";
            this.lbl_AvalColoniaAnterior.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalColoniaAnterior.TabIndex = 49;
            this.lbl_AvalColoniaAnterior.Text = "Colonia:";
            // 
            // lbl_AvalDomAnterior
            // 
            this.lbl_AvalDomAnterior.AutoSize = true;
            this.lbl_AvalDomAnterior.Location = new System.Drawing.Point(42, 232);
            this.lbl_AvalDomAnterior.Name = "lbl_AvalDomAnterior";
            this.lbl_AvalDomAnterior.Size = new System.Drawing.Size(74, 13);
            this.lbl_AvalDomAnterior.TabIndex = 48;
            this.lbl_AvalDomAnterior.Text = "Dom. Anterior:";
            // 
            // gb_DEAval
            // 
            this.gb_DEAval.Controls.Add(this.gb_ObligatorioDEAval);
            this.gb_DEAval.Controls.Add(this.lbl_AvalNoTrabaja);
            this.gb_DEAval.Controls.Add(this.chk_AvalNoTrabaja);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpObservaciones);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpColonia);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpAntMunicipio);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpMunicipio);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpAntColonia);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpTelefono);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpAntDomicilio);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpAntEmpresa);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpCruces);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpDomicilio);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpAntCp);
            this.gb_DEAval.Controls.Add(this.txt_AvalEmpCp);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpColonia);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpAntMunicipio);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpMunicipio);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpTelefono);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpAntColonia);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpAntDomicilio);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpAntEmpresa);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpCruces);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpAntCp);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpCp);
            this.gb_DEAval.Controls.Add(this.lbl_AvalEmpDomicilio);
            this.gb_DEAval.Location = new System.Drawing.Point(12, 1922);
            this.gb_DEAval.Name = "gb_DEAval";
            this.gb_DEAval.Size = new System.Drawing.Size(989, 338);
            this.gb_DEAval.TabIndex = 10;
            this.gb_DEAval.TabStop = false;
            this.gb_DEAval.Text = "DATOS DEL EMPLEO DEL AVAL";
            // 
            // gb_ObligatorioDEAval
            // 
            this.gb_ObligatorioDEAval.Controls.Add(this.ddl_AvalEmpPeriodoIngresos);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpPuestoJefe);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpIngresos);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpAntiguedad);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpJefe);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpPuestoJefe);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpJefe);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpDpto);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpFunciones);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpEmpresa);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpEmpresa);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpDpto);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp2);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp5);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp7);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp4);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp1);
            this.gb_ObligatorioDEAval.Controls.Add(this.txt_AvalEmpFunciones);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpPeriodoIngresos);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpIngresos);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmpAntiguedad);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp8);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp6);
            this.gb_ObligatorioDEAval.Controls.Add(this.lbl_AvalEmp3);
            this.gb_ObligatorioDEAval.Location = new System.Drawing.Point(21, 22);
            this.gb_ObligatorioDEAval.Name = "gb_ObligatorioDEAval";
            this.gb_ObligatorioDEAval.Size = new System.Drawing.Size(937, 99);
            this.gb_ObligatorioDEAval.TabIndex = 2;
            this.gb_ObligatorioDEAval.TabStop = false;
            // 
            // ddl_AvalEmpPeriodoIngresos
            // 
            this.ddl_AvalEmpPeriodoIngresos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_AvalEmpPeriodoIngresos.Location = new System.Drawing.Point(671, 70);
            this.ddl_AvalEmpPeriodoIngresos.Name = "ddl_AvalEmpPeriodoIngresos";
            this.ddl_AvalEmpPeriodoIngresos.Size = new System.Drawing.Size(240, 21);
            this.ddl_AvalEmpPeriodoIngresos.TabIndex = 8;
            // 
            // txt_AvalEmpPuestoJefe
            // 
            this.txt_AvalEmpPuestoJefe.Location = new System.Drawing.Point(580, 45);
            this.txt_AvalEmpPuestoJefe.Name = "txt_AvalEmpPuestoJefe";
            this.txt_AvalEmpPuestoJefe.Size = new System.Drawing.Size(331, 20);
            this.txt_AvalEmpPuestoJefe.TabIndex = 5;
            // 
            // txt_AvalEmpIngresos
            // 
            this.txt_AvalEmpIngresos.Location = new System.Drawing.Point(417, 69);
            this.txt_AvalEmpIngresos.Name = "txt_AvalEmpIngresos";
            this.txt_AvalEmpIngresos.Size = new System.Drawing.Size(143, 20);
            this.txt_AvalEmpIngresos.TabIndex = 7;
            this.txt_AvalEmpIngresos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalEmpIngresos_KeyPress);
            // 
            // txt_AvalEmpAntiguedad
            // 
            this.txt_AvalEmpAntiguedad.Location = new System.Drawing.Point(100, 70);
            this.txt_AvalEmpAntiguedad.Name = "txt_AvalEmpAntiguedad";
            this.txt_AvalEmpAntiguedad.Size = new System.Drawing.Size(246, 20);
            this.txt_AvalEmpAntiguedad.TabIndex = 6;
            // 
            // txt_AvalEmpJefe
            // 
            this.txt_AvalEmpJefe.Location = new System.Drawing.Point(100, 45);
            this.txt_AvalEmpJefe.Name = "txt_AvalEmpJefe";
            this.txt_AvalEmpJefe.Size = new System.Drawing.Size(339, 20);
            this.txt_AvalEmpJefe.TabIndex = 4;
            // 
            // lbl_AvalEmpPuestoJefe
            // 
            this.lbl_AvalEmpPuestoJefe.AutoSize = true;
            this.lbl_AvalEmpPuestoJefe.Location = new System.Drawing.Point(449, 48);
            this.lbl_AvalEmpPuestoJefe.Name = "lbl_AvalEmpPuestoJefe";
            this.lbl_AvalEmpPuestoJefe.Size = new System.Drawing.Size(132, 13);
            this.lbl_AvalEmpPuestoJefe.TabIndex = 53;
            this.lbl_AvalEmpPuestoJefe.Text = "Puesto del Jefe Inmediato:";
            // 
            // lbl_AvalEmpJefe
            // 
            this.lbl_AvalEmpJefe.AutoSize = true;
            this.lbl_AvalEmpJefe.Location = new System.Drawing.Point(18, 48);
            this.lbl_AvalEmpJefe.Name = "lbl_AvalEmpJefe";
            this.lbl_AvalEmpJefe.Size = new System.Drawing.Size(79, 13);
            this.lbl_AvalEmpJefe.TabIndex = 52;
            this.lbl_AvalEmpJefe.Text = "Jefe Inmediato:";
            // 
            // lbl_AvalEmpDpto
            // 
            this.lbl_AvalEmpDpto.AutoSize = true;
            this.lbl_AvalEmpDpto.Location = new System.Drawing.Point(688, 22);
            this.lbl_AvalEmpDpto.Name = "lbl_AvalEmpDpto";
            this.lbl_AvalEmpDpto.Size = new System.Drawing.Size(77, 13);
            this.lbl_AvalEmpDpto.TabIndex = 51;
            this.lbl_AvalEmpDpto.Text = "Departamento:";
            // 
            // lbl_AvalEmpFunciones
            // 
            this.lbl_AvalEmpFunciones.AutoSize = true;
            this.lbl_AvalEmpFunciones.Location = new System.Drawing.Point(457, 22);
            this.lbl_AvalEmpFunciones.Name = "lbl_AvalEmpFunciones";
            this.lbl_AvalEmpFunciones.Size = new System.Drawing.Size(59, 13);
            this.lbl_AvalEmpFunciones.TabIndex = 50;
            this.lbl_AvalEmpFunciones.Text = "Funciones:";
            // 
            // lbl_AvalEmpEmpresa
            // 
            this.lbl_AvalEmpEmpresa.AutoSize = true;
            this.lbl_AvalEmpEmpresa.Location = new System.Drawing.Point(21, 22);
            this.lbl_AvalEmpEmpresa.Name = "lbl_AvalEmpEmpresa";
            this.lbl_AvalEmpEmpresa.Size = new System.Drawing.Size(51, 13);
            this.lbl_AvalEmpEmpresa.TabIndex = 49;
            this.lbl_AvalEmpEmpresa.Text = "Empresa:";
            // 
            // txt_AvalEmpEmpresa
            // 
            this.txt_AvalEmpEmpresa.Location = new System.Drawing.Point(100, 15);
            this.txt_AvalEmpEmpresa.Name = "txt_AvalEmpEmpresa";
            this.txt_AvalEmpEmpresa.Size = new System.Drawing.Size(342, 20);
            this.txt_AvalEmpEmpresa.TabIndex = 1;
            // 
            // txt_AvalEmpDpto
            // 
            this.txt_AvalEmpDpto.Location = new System.Drawing.Point(765, 19);
            this.txt_AvalEmpDpto.Name = "txt_AvalEmpDpto";
            this.txt_AvalEmpDpto.Size = new System.Drawing.Size(145, 20);
            this.txt_AvalEmpDpto.TabIndex = 3;
            // 
            // lbl_AvalEmp2
            // 
            this.lbl_AvalEmp2.AutoSize = true;
            this.lbl_AvalEmp2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp2.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp2.Location = new System.Drawing.Point(9, 43);
            this.lbl_AvalEmp2.Name = "lbl_AvalEmp2";
            this.lbl_AvalEmp2.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp2.TabIndex = 57;
            this.lbl_AvalEmp2.Text = "*";
            // 
            // lbl_AvalEmp5
            // 
            this.lbl_AvalEmp5.AutoSize = true;
            this.lbl_AvalEmp5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp5.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp5.Location = new System.Drawing.Point(440, 46);
            this.lbl_AvalEmp5.Name = "lbl_AvalEmp5";
            this.lbl_AvalEmp5.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp5.TabIndex = 57;
            this.lbl_AvalEmp5.Text = "*";
            // 
            // lbl_AvalEmp7
            // 
            this.lbl_AvalEmp7.AutoSize = true;
            this.lbl_AvalEmp7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp7.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp7.Location = new System.Drawing.Point(678, 21);
            this.lbl_AvalEmp7.Name = "lbl_AvalEmp7";
            this.lbl_AvalEmp7.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp7.TabIndex = 57;
            this.lbl_AvalEmp7.Text = "*";
            // 
            // lbl_AvalEmp4
            // 
            this.lbl_AvalEmp4.AutoSize = true;
            this.lbl_AvalEmp4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp4.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp4.Location = new System.Drawing.Point(448, 19);
            this.lbl_AvalEmp4.Name = "lbl_AvalEmp4";
            this.lbl_AvalEmp4.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp4.TabIndex = 57;
            this.lbl_AvalEmp4.Text = "*";
            // 
            // lbl_AvalEmp1
            // 
            this.lbl_AvalEmp1.AutoSize = true;
            this.lbl_AvalEmp1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp1.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp1.Location = new System.Drawing.Point(9, 19);
            this.lbl_AvalEmp1.Name = "lbl_AvalEmp1";
            this.lbl_AvalEmp1.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp1.TabIndex = 57;
            this.lbl_AvalEmp1.Text = "*";
            // 
            // txt_AvalEmpFunciones
            // 
            this.txt_AvalEmpFunciones.Location = new System.Drawing.Point(516, 19);
            this.txt_AvalEmpFunciones.Name = "txt_AvalEmpFunciones";
            this.txt_AvalEmpFunciones.Size = new System.Drawing.Size(158, 20);
            this.txt_AvalEmpFunciones.TabIndex = 2;
            // 
            // lbl_AvalEmpPeriodoIngresos
            // 
            this.lbl_AvalEmpPeriodoIngresos.AutoSize = true;
            this.lbl_AvalEmpPeriodoIngresos.Location = new System.Drawing.Point(569, 73);
            this.lbl_AvalEmpPeriodoIngresos.Name = "lbl_AvalEmpPeriodoIngresos";
            this.lbl_AvalEmpPeriodoIngresos.Size = new System.Drawing.Size(104, 13);
            this.lbl_AvalEmpPeriodoIngresos.TabIndex = 38;
            this.lbl_AvalEmpPeriodoIngresos.Text = "Periodo de Ingresos:";
            // 
            // lbl_AvalEmpIngresos
            // 
            this.lbl_AvalEmpIngresos.AutoSize = true;
            this.lbl_AvalEmpIngresos.Location = new System.Drawing.Point(359, 73);
            this.lbl_AvalEmpIngresos.Name = "lbl_AvalEmpIngresos";
            this.lbl_AvalEmpIngresos.Size = new System.Drawing.Size(59, 13);
            this.lbl_AvalEmpIngresos.TabIndex = 37;
            this.lbl_AvalEmpIngresos.Text = "Ingresos $:";
            // 
            // lbl_AvalEmpAntiguedad
            // 
            this.lbl_AvalEmpAntiguedad.AutoSize = true;
            this.lbl_AvalEmpAntiguedad.Location = new System.Drawing.Point(18, 73);
            this.lbl_AvalEmpAntiguedad.Name = "lbl_AvalEmpAntiguedad";
            this.lbl_AvalEmpAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_AvalEmpAntiguedad.TabIndex = 39;
            this.lbl_AvalEmpAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_AvalEmp8
            // 
            this.lbl_AvalEmp8.AutoSize = true;
            this.lbl_AvalEmp8.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp8.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp8.Location = new System.Drawing.Point(559, 70);
            this.lbl_AvalEmp8.Name = "lbl_AvalEmp8";
            this.lbl_AvalEmp8.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp8.TabIndex = 57;
            this.lbl_AvalEmp8.Text = "*";
            // 
            // lbl_AvalEmp6
            // 
            this.lbl_AvalEmp6.AutoSize = true;
            this.lbl_AvalEmp6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp6.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp6.Location = new System.Drawing.Point(350, 70);
            this.lbl_AvalEmp6.Name = "lbl_AvalEmp6";
            this.lbl_AvalEmp6.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp6.TabIndex = 57;
            this.lbl_AvalEmp6.Text = "*";
            // 
            // lbl_AvalEmp3
            // 
            this.lbl_AvalEmp3.AutoSize = true;
            this.lbl_AvalEmp3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_AvalEmp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AvalEmp3.ForeColor = System.Drawing.Color.Red;
            this.lbl_AvalEmp3.Location = new System.Drawing.Point(9, 69);
            this.lbl_AvalEmp3.Name = "lbl_AvalEmp3";
            this.lbl_AvalEmp3.Size = new System.Drawing.Size(15, 20);
            this.lbl_AvalEmp3.TabIndex = 57;
            this.lbl_AvalEmp3.Text = "*";
            // 
            // lbl_AvalNoTrabaja
            // 
            this.lbl_AvalNoTrabaja.AutoSize = true;
            this.lbl_AvalNoTrabaja.Location = new System.Drawing.Point(40, 256);
            this.lbl_AvalNoTrabaja.Name = "lbl_AvalNoTrabaja";
            this.lbl_AvalNoTrabaja.Size = new System.Drawing.Size(81, 13);
            this.lbl_AvalNoTrabaja.TabIndex = 1;
            this.lbl_AvalNoTrabaja.Text = "Observaciones:";
            // 
            // chk_AvalNoTrabaja
            // 
            this.chk_AvalNoTrabaja.AutoSize = true;
            this.chk_AvalNoTrabaja.Location = new System.Drawing.Point(459, 0);
            this.chk_AvalNoTrabaja.Name = "chk_AvalNoTrabaja";
            this.chk_AvalNoTrabaja.Size = new System.Drawing.Size(139, 17);
            this.chk_AvalNoTrabaja.TabIndex = 1;
            this.chk_AvalNoTrabaja.Text = "Aval se dedica al Hogar";
            this.chk_AvalNoTrabaja.UseVisualStyleBackColor = true;
            this.chk_AvalNoTrabaja.CheckedChanged += new System.EventHandler(this.chk_AvalNoTrabaja_CheckedChanged);
            // 
            // txt_AvalEmpObservaciones
            // 
            this.txt_AvalEmpObservaciones.Location = new System.Drawing.Point(114, 272);
            this.txt_AvalEmpObservaciones.MaxLength = 253;
            this.txt_AvalEmpObservaciones.Multiline = true;
            this.txt_AvalEmpObservaciones.Name = "txt_AvalEmpObservaciones";
            this.txt_AvalEmpObservaciones.Size = new System.Drawing.Size(817, 57);
            this.txt_AvalEmpObservaciones.TabIndex = 21;
            this.txt_AvalEmpObservaciones.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_AvalEmpObservaciones_KeyDown);
            this.txt_AvalEmpObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalEmpObservaciones_KeyPress);
            this.txt_AvalEmpObservaciones.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txt_AvalEmpObservaciones_MouseDown);
            // 
            // txt_AvalEmpColonia
            // 
            this.txt_AvalEmpColonia.Location = new System.Drawing.Point(697, 127);
            this.txt_AvalEmpColonia.Name = "txt_AvalEmpColonia";
            this.txt_AvalEmpColonia.Size = new System.Drawing.Size(234, 20);
            this.txt_AvalEmpColonia.TabIndex = 10;
            // 
            // txt_AvalEmpAntMunicipio
            // 
            this.txt_AvalEmpAntMunicipio.Location = new System.Drawing.Point(462, 231);
            this.txt_AvalEmpAntMunicipio.Name = "txt_AvalEmpAntMunicipio";
            this.txt_AvalEmpAntMunicipio.Size = new System.Drawing.Size(318, 20);
            this.txt_AvalEmpAntMunicipio.TabIndex = 18;
            // 
            // txt_AvalEmpMunicipio
            // 
            this.txt_AvalEmpMunicipio.Location = new System.Drawing.Point(121, 153);
            this.txt_AvalEmpMunicipio.Name = "txt_AvalEmpMunicipio";
            this.txt_AvalEmpMunicipio.Size = new System.Drawing.Size(361, 20);
            this.txt_AvalEmpMunicipio.TabIndex = 11;
            // 
            // txt_AvalEmpAntColonia
            // 
            this.txt_AvalEmpAntColonia.Location = new System.Drawing.Point(90, 230);
            this.txt_AvalEmpAntColonia.Name = "txt_AvalEmpAntColonia";
            this.txt_AvalEmpAntColonia.Size = new System.Drawing.Size(306, 20);
            this.txt_AvalEmpAntColonia.TabIndex = 17;
            // 
            // txt_AvalEmpTelefono
            // 
            this.txt_AvalEmpTelefono.Location = new System.Drawing.Point(697, 153);
            this.txt_AvalEmpTelefono.Name = "txt_AvalEmpTelefono";
            this.txt_AvalEmpTelefono.Size = new System.Drawing.Size(235, 20);
            this.txt_AvalEmpTelefono.TabIndex = 13;
            // 
            // txt_AvalEmpAntDomicilio
            // 
            this.txt_AvalEmpAntDomicilio.Location = new System.Drawing.Point(172, 204);
            this.txt_AvalEmpAntDomicilio.Name = "txt_AvalEmpAntDomicilio";
            this.txt_AvalEmpAntDomicilio.Size = new System.Drawing.Size(759, 20);
            this.txt_AvalEmpAntDomicilio.TabIndex = 16;
            // 
            // txt_AvalEmpAntEmpresa
            // 
            this.txt_AvalEmpAntEmpresa.Location = new System.Drawing.Point(573, 178);
            this.txt_AvalEmpAntEmpresa.Name = "txt_AvalEmpAntEmpresa";
            this.txt_AvalEmpAntEmpresa.Size = new System.Drawing.Size(358, 20);
            this.txt_AvalEmpAntEmpresa.TabIndex = 15;
            // 
            // txt_AvalEmpCruces
            // 
            this.txt_AvalEmpCruces.Location = new System.Drawing.Point(121, 178);
            this.txt_AvalEmpCruces.Name = "txt_AvalEmpCruces";
            this.txt_AvalEmpCruces.Size = new System.Drawing.Size(355, 20);
            this.txt_AvalEmpCruces.TabIndex = 14;
            // 
            // txt_AvalEmpDomicilio
            // 
            this.txt_AvalEmpDomicilio.Location = new System.Drawing.Point(121, 127);
            this.txt_AvalEmpDomicilio.Name = "txt_AvalEmpDomicilio";
            this.txt_AvalEmpDomicilio.Size = new System.Drawing.Size(519, 20);
            this.txt_AvalEmpDomicilio.TabIndex = 9;
            // 
            // txt_AvalEmpAntCp
            // 
            this.txt_AvalEmpAntCp.Location = new System.Drawing.Point(824, 220);
            this.txt_AvalEmpAntCp.Name = "txt_AvalEmpAntCp";
            this.txt_AvalEmpAntCp.Size = new System.Drawing.Size(106, 20);
            this.txt_AvalEmpAntCp.TabIndex = 19;
            // 
            // txt_AvalEmpCp
            // 
            this.txt_AvalEmpCp.Location = new System.Drawing.Point(532, 153);
            this.txt_AvalEmpCp.Name = "txt_AvalEmpCp";
            this.txt_AvalEmpCp.Size = new System.Drawing.Size(106, 20);
            this.txt_AvalEmpCp.TabIndex = 12;
            // 
            // lbl_AvalEmpColonia
            // 
            this.lbl_AvalEmpColonia.AutoSize = true;
            this.lbl_AvalEmpColonia.Location = new System.Drawing.Point(646, 130);
            this.lbl_AvalEmpColonia.Name = "lbl_AvalEmpColonia";
            this.lbl_AvalEmpColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalEmpColonia.TabIndex = 46;
            this.lbl_AvalEmpColonia.Text = "Colonia:";
            // 
            // lbl_AvalEmpAntMunicipio
            // 
            this.lbl_AvalEmpAntMunicipio.AutoSize = true;
            this.lbl_AvalEmpAntMunicipio.Location = new System.Drawing.Point(405, 234);
            this.lbl_AvalEmpAntMunicipio.Name = "lbl_AvalEmpAntMunicipio";
            this.lbl_AvalEmpAntMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalEmpAntMunicipio.TabIndex = 45;
            this.lbl_AvalEmpAntMunicipio.Text = "Municipio:";
            // 
            // lbl_AvalEmpMunicipio
            // 
            this.lbl_AvalEmpMunicipio.AutoSize = true;
            this.lbl_AvalEmpMunicipio.Location = new System.Drawing.Point(39, 156);
            this.lbl_AvalEmpMunicipio.Name = "lbl_AvalEmpMunicipio";
            this.lbl_AvalEmpMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalEmpMunicipio.TabIndex = 44;
            this.lbl_AvalEmpMunicipio.Text = "Municipio:";
            // 
            // lbl_AvalEmpTelefono
            // 
            this.lbl_AvalEmpTelefono.AutoSize = true;
            this.lbl_AvalEmpTelefono.Location = new System.Drawing.Point(640, 156);
            this.lbl_AvalEmpTelefono.Name = "lbl_AvalEmpTelefono";
            this.lbl_AvalEmpTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalEmpTelefono.TabIndex = 43;
            this.lbl_AvalEmpTelefono.Text = "Teléfono:";
            // 
            // lbl_AvalEmpAntColonia
            // 
            this.lbl_AvalEmpAntColonia.AutoSize = true;
            this.lbl_AvalEmpAntColonia.Location = new System.Drawing.Point(39, 234);
            this.lbl_AvalEmpAntColonia.Name = "lbl_AvalEmpAntColonia";
            this.lbl_AvalEmpAntColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalEmpAntColonia.TabIndex = 42;
            this.lbl_AvalEmpAntColonia.Text = "Colonia:";
            // 
            // lbl_AvalEmpAntDomicilio
            // 
            this.lbl_AvalEmpAntDomicilio.AutoSize = true;
            this.lbl_AvalEmpAntDomicilio.Location = new System.Drawing.Point(39, 207);
            this.lbl_AvalEmpAntDomicilio.Name = "lbl_AvalEmpAntDomicilio";
            this.lbl_AvalEmpAntDomicilio.Size = new System.Drawing.Size(130, 13);
            this.lbl_AvalEmpAntDomicilio.TabIndex = 41;
            this.lbl_AvalEmpAntDomicilio.Text = "Domicilio Trabajo Anterior:";
            // 
            // lbl_AvalEmpAntEmpresa
            // 
            this.lbl_AvalEmpAntEmpresa.AutoSize = true;
            this.lbl_AvalEmpAntEmpresa.Location = new System.Drawing.Point(482, 181);
            this.lbl_AvalEmpAntEmpresa.Name = "lbl_AvalEmpAntEmpresa";
            this.lbl_AvalEmpAntEmpresa.Size = new System.Drawing.Size(85, 13);
            this.lbl_AvalEmpAntEmpresa.TabIndex = 41;
            this.lbl_AvalEmpAntEmpresa.Text = "Trabajo Anterior:";
            // 
            // lbl_AvalEmpCruces
            // 
            this.lbl_AvalEmpCruces.AutoSize = true;
            this.lbl_AvalEmpCruces.Location = new System.Drawing.Point(39, 181);
            this.lbl_AvalEmpCruces.Name = "lbl_AvalEmpCruces";
            this.lbl_AvalEmpCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_AvalEmpCruces.TabIndex = 40;
            this.lbl_AvalEmpCruces.Text = "Cruces:";
            // 
            // lbl_AvalEmpAntCp
            // 
            this.lbl_AvalEmpAntCp.AutoSize = true;
            this.lbl_AvalEmpAntCp.Location = new System.Drawing.Point(788, 224);
            this.lbl_AvalEmpAntCp.Name = "lbl_AvalEmpAntCp";
            this.lbl_AvalEmpAntCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalEmpAntCp.TabIndex = 50;
            this.lbl_AvalEmpAntCp.Text = "C.P.:";
            // 
            // lbl_AvalEmpCp
            // 
            this.lbl_AvalEmpCp.AutoSize = true;
            this.lbl_AvalEmpCp.Location = new System.Drawing.Point(496, 156);
            this.lbl_AvalEmpCp.Name = "lbl_AvalEmpCp";
            this.lbl_AvalEmpCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalEmpCp.TabIndex = 50;
            this.lbl_AvalEmpCp.Text = "C.P.:";
            // 
            // lbl_AvalEmpDomicilio
            // 
            this.lbl_AvalEmpDomicilio.AutoSize = true;
            this.lbl_AvalEmpDomicilio.Location = new System.Drawing.Point(39, 130);
            this.lbl_AvalEmpDomicilio.Name = "lbl_AvalEmpDomicilio";
            this.lbl_AvalEmpDomicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalEmpDomicilio.TabIndex = 36;
            this.lbl_AvalEmpDomicilio.Text = "Domicilio:";
            // 
            // gb_DEConyugeAval
            // 
            this.gb_DEConyugeAval.Controls.Add(this.ddl_AvalConyugeEmpPeriodoIngresos);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpPuestoJefe);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpColonia);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpIngresos);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntMunicipio);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpMunicipio);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntColonia);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpTelefono);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntDomicilio);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntEmpresa);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpCruces);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpDomicilio);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntiguedad);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpJefe);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpPuestoJefe);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpJefe);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpDpto);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpFunciones);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpEmpresa);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpEmpresa);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpDpto);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpAntCp);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpCp);
            this.gb_DEConyugeAval.Controls.Add(this.txt_AvalConyugeEmpFunciones);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpColonia);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntMunicipio);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpMunicipio);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpTelefono);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntColonia);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntDomicilio);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntEmpresa);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpCruces);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpPeriodoIngresos);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpIngresos);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntiguedad);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpAntCp);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpCp);
            this.gb_DEConyugeAval.Controls.Add(this.lbl_AvalConyugeEmpDomicilio);
            this.gb_DEConyugeAval.Location = new System.Drawing.Point(12, 2270);
            this.gb_DEConyugeAval.Name = "gb_DEConyugeAval";
            this.gb_DEConyugeAval.Size = new System.Drawing.Size(989, 252);
            this.gb_DEConyugeAval.TabIndex = 11;
            this.gb_DEConyugeAval.TabStop = false;
            this.gb_DEConyugeAval.Text = "DATOS DEL EMPLEO DEL CONYUGE DEL AVAL";
            // 
            // ddl_AvalConyugeEmpPeriodoIngresos
            // 
            this.ddl_AvalConyugeEmpPeriodoIngresos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_AvalConyugeEmpPeriodoIngresos.Enabled = false;
            this.ddl_AvalConyugeEmpPeriodoIngresos.Location = new System.Drawing.Point(666, 74);
            this.ddl_AvalConyugeEmpPeriodoIngresos.Name = "ddl_AvalConyugeEmpPeriodoIngresos";
            this.ddl_AvalConyugeEmpPeriodoIngresos.Size = new System.Drawing.Size(240, 21);
            this.ddl_AvalConyugeEmpPeriodoIngresos.TabIndex = 8;
            // 
            // txt_AvalConyugeEmpPuestoJefe
            // 
            this.txt_AvalConyugeEmpPuestoJefe.Enabled = false;
            this.txt_AvalConyugeEmpPuestoJefe.Location = new System.Drawing.Point(572, 49);
            this.txt_AvalConyugeEmpPuestoJefe.Name = "txt_AvalConyugeEmpPuestoJefe";
            this.txt_AvalConyugeEmpPuestoJefe.Size = new System.Drawing.Size(334, 20);
            this.txt_AvalConyugeEmpPuestoJefe.TabIndex = 5;
            // 
            // txt_AvalConyugeEmpColonia
            // 
            this.txt_AvalConyugeEmpColonia.Enabled = false;
            this.txt_AvalConyugeEmpColonia.Location = new System.Drawing.Point(671, 99);
            this.txt_AvalConyugeEmpColonia.Name = "txt_AvalConyugeEmpColonia";
            this.txt_AvalConyugeEmpColonia.Size = new System.Drawing.Size(234, 20);
            this.txt_AvalConyugeEmpColonia.TabIndex = 10;
            // 
            // txt_AvalConyugeEmpIngresos
            // 
            this.txt_AvalConyugeEmpIngresos.Enabled = false;
            this.txt_AvalConyugeEmpIngresos.Location = new System.Drawing.Point(412, 73);
            this.txt_AvalConyugeEmpIngresos.Name = "txt_AvalConyugeEmpIngresos";
            this.txt_AvalConyugeEmpIngresos.Size = new System.Drawing.Size(143, 20);
            this.txt_AvalConyugeEmpIngresos.TabIndex = 7;
            this.txt_AvalConyugeEmpIngresos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AvalConyugeEmpIngresos_KeyPress);
            // 
            // txt_AvalConyugeEmpAntMunicipio
            // 
            this.txt_AvalConyugeEmpAntMunicipio.Enabled = false;
            this.txt_AvalConyugeEmpAntMunicipio.Location = new System.Drawing.Point(436, 203);
            this.txt_AvalConyugeEmpAntMunicipio.Name = "txt_AvalConyugeEmpAntMunicipio";
            this.txt_AvalConyugeEmpAntMunicipio.Size = new System.Drawing.Size(318, 20);
            this.txt_AvalConyugeEmpAntMunicipio.TabIndex = 18;
            // 
            // txt_AvalConyugeEmpMunicipio
            // 
            this.txt_AvalConyugeEmpMunicipio.Enabled = false;
            this.txt_AvalConyugeEmpMunicipio.Location = new System.Drawing.Point(95, 125);
            this.txt_AvalConyugeEmpMunicipio.Name = "txt_AvalConyugeEmpMunicipio";
            this.txt_AvalConyugeEmpMunicipio.Size = new System.Drawing.Size(361, 20);
            this.txt_AvalConyugeEmpMunicipio.TabIndex = 11;
            // 
            // txt_AvalConyugeEmpAntColonia
            // 
            this.txt_AvalConyugeEmpAntColonia.Enabled = false;
            this.txt_AvalConyugeEmpAntColonia.Location = new System.Drawing.Point(64, 202);
            this.txt_AvalConyugeEmpAntColonia.Name = "txt_AvalConyugeEmpAntColonia";
            this.txt_AvalConyugeEmpAntColonia.Size = new System.Drawing.Size(306, 20);
            this.txt_AvalConyugeEmpAntColonia.TabIndex = 17;
            // 
            // txt_AvalConyugeEmpTelefono
            // 
            this.txt_AvalConyugeEmpTelefono.Enabled = false;
            this.txt_AvalConyugeEmpTelefono.Location = new System.Drawing.Point(671, 125);
            this.txt_AvalConyugeEmpTelefono.Name = "txt_AvalConyugeEmpTelefono";
            this.txt_AvalConyugeEmpTelefono.Size = new System.Drawing.Size(235, 20);
            this.txt_AvalConyugeEmpTelefono.TabIndex = 13;
            // 
            // txt_AvalConyugeEmpAntDomicilio
            // 
            this.txt_AvalConyugeEmpAntDomicilio.Enabled = false;
            this.txt_AvalConyugeEmpAntDomicilio.Location = new System.Drawing.Point(146, 176);
            this.txt_AvalConyugeEmpAntDomicilio.Name = "txt_AvalConyugeEmpAntDomicilio";
            this.txt_AvalConyugeEmpAntDomicilio.Size = new System.Drawing.Size(759, 20);
            this.txt_AvalConyugeEmpAntDomicilio.TabIndex = 16;
            // 
            // txt_AvalConyugeEmpAntEmpresa
            // 
            this.txt_AvalConyugeEmpAntEmpresa.Enabled = false;
            this.txt_AvalConyugeEmpAntEmpresa.Location = new System.Drawing.Point(547, 150);
            this.txt_AvalConyugeEmpAntEmpresa.Name = "txt_AvalConyugeEmpAntEmpresa";
            this.txt_AvalConyugeEmpAntEmpresa.Size = new System.Drawing.Size(358, 20);
            this.txt_AvalConyugeEmpAntEmpresa.TabIndex = 15;
            // 
            // txt_AvalConyugeEmpCruces
            // 
            this.txt_AvalConyugeEmpCruces.Enabled = false;
            this.txt_AvalConyugeEmpCruces.Location = new System.Drawing.Point(95, 150);
            this.txt_AvalConyugeEmpCruces.Name = "txt_AvalConyugeEmpCruces";
            this.txt_AvalConyugeEmpCruces.Size = new System.Drawing.Size(355, 20);
            this.txt_AvalConyugeEmpCruces.TabIndex = 14;
            // 
            // txt_AvalConyugeEmpDomicilio
            // 
            this.txt_AvalConyugeEmpDomicilio.Enabled = false;
            this.txt_AvalConyugeEmpDomicilio.Location = new System.Drawing.Point(95, 99);
            this.txt_AvalConyugeEmpDomicilio.Name = "txt_AvalConyugeEmpDomicilio";
            this.txt_AvalConyugeEmpDomicilio.Size = new System.Drawing.Size(519, 20);
            this.txt_AvalConyugeEmpDomicilio.TabIndex = 9;
            // 
            // txt_AvalConyugeEmpAntiguedad
            // 
            this.txt_AvalConyugeEmpAntiguedad.Enabled = false;
            this.txt_AvalConyugeEmpAntiguedad.Location = new System.Drawing.Point(95, 74);
            this.txt_AvalConyugeEmpAntiguedad.Name = "txt_AvalConyugeEmpAntiguedad";
            this.txt_AvalConyugeEmpAntiguedad.Size = new System.Drawing.Size(246, 20);
            this.txt_AvalConyugeEmpAntiguedad.TabIndex = 6;
            // 
            // txt_AvalConyugeEmpJefe
            // 
            this.txt_AvalConyugeEmpJefe.Enabled = false;
            this.txt_AvalConyugeEmpJefe.Location = new System.Drawing.Point(95, 49);
            this.txt_AvalConyugeEmpJefe.Name = "txt_AvalConyugeEmpJefe";
            this.txt_AvalConyugeEmpJefe.Size = new System.Drawing.Size(339, 20);
            this.txt_AvalConyugeEmpJefe.TabIndex = 4;
            // 
            // lbl_AvalConyugeEmpPuestoJefe
            // 
            this.lbl_AvalConyugeEmpPuestoJefe.AutoSize = true;
            this.lbl_AvalConyugeEmpPuestoJefe.Location = new System.Drawing.Point(434, 52);
            this.lbl_AvalConyugeEmpPuestoJefe.Name = "lbl_AvalConyugeEmpPuestoJefe";
            this.lbl_AvalConyugeEmpPuestoJefe.Size = new System.Drawing.Size(132, 13);
            this.lbl_AvalConyugeEmpPuestoJefe.TabIndex = 53;
            this.lbl_AvalConyugeEmpPuestoJefe.Text = "Puesto del Jefe Inmediato:";
            // 
            // lbl_AvalConyugeEmpJefe
            // 
            this.lbl_AvalConyugeEmpJefe.AutoSize = true;
            this.lbl_AvalConyugeEmpJefe.Location = new System.Drawing.Point(13, 52);
            this.lbl_AvalConyugeEmpJefe.Name = "lbl_AvalConyugeEmpJefe";
            this.lbl_AvalConyugeEmpJefe.Size = new System.Drawing.Size(79, 13);
            this.lbl_AvalConyugeEmpJefe.TabIndex = 52;
            this.lbl_AvalConyugeEmpJefe.Text = "Jefe Inmediato:";
            // 
            // lbl_AvalConyugeEmpDpto
            // 
            this.lbl_AvalConyugeEmpDpto.AutoSize = true;
            this.lbl_AvalConyugeEmpDpto.Location = new System.Drawing.Point(677, 26);
            this.lbl_AvalConyugeEmpDpto.Name = "lbl_AvalConyugeEmpDpto";
            this.lbl_AvalConyugeEmpDpto.Size = new System.Drawing.Size(77, 13);
            this.lbl_AvalConyugeEmpDpto.TabIndex = 51;
            this.lbl_AvalConyugeEmpDpto.Text = "Departamento:";
            // 
            // lbl_AvalConyugeEmpFunciones
            // 
            this.lbl_AvalConyugeEmpFunciones.AutoSize = true;
            this.lbl_AvalConyugeEmpFunciones.Location = new System.Drawing.Point(446, 26);
            this.lbl_AvalConyugeEmpFunciones.Name = "lbl_AvalConyugeEmpFunciones";
            this.lbl_AvalConyugeEmpFunciones.Size = new System.Drawing.Size(59, 13);
            this.lbl_AvalConyugeEmpFunciones.TabIndex = 50;
            this.lbl_AvalConyugeEmpFunciones.Text = "Funciones:";
            // 
            // lbl_AvalConyugeEmpEmpresa
            // 
            this.lbl_AvalConyugeEmpEmpresa.AutoSize = true;
            this.lbl_AvalConyugeEmpEmpresa.Location = new System.Drawing.Point(16, 26);
            this.lbl_AvalConyugeEmpEmpresa.Name = "lbl_AvalConyugeEmpEmpresa";
            this.lbl_AvalConyugeEmpEmpresa.Size = new System.Drawing.Size(51, 13);
            this.lbl_AvalConyugeEmpEmpresa.TabIndex = 49;
            this.lbl_AvalConyugeEmpEmpresa.Text = "Empresa:";
            // 
            // txt_AvalConyugeEmpEmpresa
            // 
            this.txt_AvalConyugeEmpEmpresa.Enabled = false;
            this.txt_AvalConyugeEmpEmpresa.Location = new System.Drawing.Point(95, 23);
            this.txt_AvalConyugeEmpEmpresa.Name = "txt_AvalConyugeEmpEmpresa";
            this.txt_AvalConyugeEmpEmpresa.Size = new System.Drawing.Size(342, 20);
            this.txt_AvalConyugeEmpEmpresa.TabIndex = 1;
            // 
            // txt_AvalConyugeEmpDpto
            // 
            this.txt_AvalConyugeEmpDpto.Enabled = false;
            this.txt_AvalConyugeEmpDpto.Location = new System.Drawing.Point(760, 23);
            this.txt_AvalConyugeEmpDpto.Name = "txt_AvalConyugeEmpDpto";
            this.txt_AvalConyugeEmpDpto.Size = new System.Drawing.Size(145, 20);
            this.txt_AvalConyugeEmpDpto.TabIndex = 3;
            // 
            // txt_AvalConyugeEmpAntCp
            // 
            this.txt_AvalConyugeEmpAntCp.Enabled = false;
            this.txt_AvalConyugeEmpAntCp.Location = new System.Drawing.Point(800, 202);
            this.txt_AvalConyugeEmpAntCp.Name = "txt_AvalConyugeEmpAntCp";
            this.txt_AvalConyugeEmpAntCp.Size = new System.Drawing.Size(106, 20);
            this.txt_AvalConyugeEmpAntCp.TabIndex = 19;
            // 
            // txt_AvalConyugeEmpCp
            // 
            this.txt_AvalConyugeEmpCp.Enabled = false;
            this.txt_AvalConyugeEmpCp.Location = new System.Drawing.Point(506, 125);
            this.txt_AvalConyugeEmpCp.Name = "txt_AvalConyugeEmpCp";
            this.txt_AvalConyugeEmpCp.Size = new System.Drawing.Size(106, 20);
            this.txt_AvalConyugeEmpCp.TabIndex = 12;
            // 
            // txt_AvalConyugeEmpFunciones
            // 
            this.txt_AvalConyugeEmpFunciones.Enabled = false;
            this.txt_AvalConyugeEmpFunciones.Location = new System.Drawing.Point(511, 23);
            this.txt_AvalConyugeEmpFunciones.Name = "txt_AvalConyugeEmpFunciones";
            this.txt_AvalConyugeEmpFunciones.Size = new System.Drawing.Size(158, 20);
            this.txt_AvalConyugeEmpFunciones.TabIndex = 2;
            // 
            // lbl_AvalConyugeEmpColonia
            // 
            this.lbl_AvalConyugeEmpColonia.AutoSize = true;
            this.lbl_AvalConyugeEmpColonia.Location = new System.Drawing.Point(620, 102);
            this.lbl_AvalConyugeEmpColonia.Name = "lbl_AvalConyugeEmpColonia";
            this.lbl_AvalConyugeEmpColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalConyugeEmpColonia.TabIndex = 46;
            this.lbl_AvalConyugeEmpColonia.Text = "Colonia:";
            // 
            // lbl_AvalConyugeEmpAntMunicipio
            // 
            this.lbl_AvalConyugeEmpAntMunicipio.AutoSize = true;
            this.lbl_AvalConyugeEmpAntMunicipio.Location = new System.Drawing.Point(379, 206);
            this.lbl_AvalConyugeEmpAntMunicipio.Name = "lbl_AvalConyugeEmpAntMunicipio";
            this.lbl_AvalConyugeEmpAntMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalConyugeEmpAntMunicipio.TabIndex = 45;
            this.lbl_AvalConyugeEmpAntMunicipio.Text = "Municipio:";
            // 
            // lbl_AvalConyugeEmpMunicipio
            // 
            this.lbl_AvalConyugeEmpMunicipio.AutoSize = true;
            this.lbl_AvalConyugeEmpMunicipio.Location = new System.Drawing.Point(13, 128);
            this.lbl_AvalConyugeEmpMunicipio.Name = "lbl_AvalConyugeEmpMunicipio";
            this.lbl_AvalConyugeEmpMunicipio.Size = new System.Drawing.Size(55, 13);
            this.lbl_AvalConyugeEmpMunicipio.TabIndex = 44;
            this.lbl_AvalConyugeEmpMunicipio.Text = "Municipio:";
            // 
            // lbl_AvalConyugeEmpTelefono
            // 
            this.lbl_AvalConyugeEmpTelefono.AutoSize = true;
            this.lbl_AvalConyugeEmpTelefono.Location = new System.Drawing.Point(614, 128);
            this.lbl_AvalConyugeEmpTelefono.Name = "lbl_AvalConyugeEmpTelefono";
            this.lbl_AvalConyugeEmpTelefono.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalConyugeEmpTelefono.TabIndex = 43;
            this.lbl_AvalConyugeEmpTelefono.Text = "Teléfono:";
            // 
            // lbl_AvalConyugeEmpAntColonia
            // 
            this.lbl_AvalConyugeEmpAntColonia.AutoSize = true;
            this.lbl_AvalConyugeEmpAntColonia.Location = new System.Drawing.Point(13, 206);
            this.lbl_AvalConyugeEmpAntColonia.Name = "lbl_AvalConyugeEmpAntColonia";
            this.lbl_AvalConyugeEmpAntColonia.Size = new System.Drawing.Size(45, 13);
            this.lbl_AvalConyugeEmpAntColonia.TabIndex = 42;
            this.lbl_AvalConyugeEmpAntColonia.Text = "Colonia:";
            // 
            // lbl_AvalConyugeEmpAntDomicilio
            // 
            this.lbl_AvalConyugeEmpAntDomicilio.AutoSize = true;
            this.lbl_AvalConyugeEmpAntDomicilio.Location = new System.Drawing.Point(13, 179);
            this.lbl_AvalConyugeEmpAntDomicilio.Name = "lbl_AvalConyugeEmpAntDomicilio";
            this.lbl_AvalConyugeEmpAntDomicilio.Size = new System.Drawing.Size(130, 13);
            this.lbl_AvalConyugeEmpAntDomicilio.TabIndex = 41;
            this.lbl_AvalConyugeEmpAntDomicilio.Text = "Domicilio Trabajo Anterior:";
            // 
            // lbl_AvalConyugeEmpAntEmpresa
            // 
            this.lbl_AvalConyugeEmpAntEmpresa.AutoSize = true;
            this.lbl_AvalConyugeEmpAntEmpresa.Location = new System.Drawing.Point(456, 153);
            this.lbl_AvalConyugeEmpAntEmpresa.Name = "lbl_AvalConyugeEmpAntEmpresa";
            this.lbl_AvalConyugeEmpAntEmpresa.Size = new System.Drawing.Size(85, 13);
            this.lbl_AvalConyugeEmpAntEmpresa.TabIndex = 41;
            this.lbl_AvalConyugeEmpAntEmpresa.Text = "Trabajo Anterior:";
            // 
            // lbl_AvalConyugeEmpCruces
            // 
            this.lbl_AvalConyugeEmpCruces.AutoSize = true;
            this.lbl_AvalConyugeEmpCruces.Location = new System.Drawing.Point(13, 153);
            this.lbl_AvalConyugeEmpCruces.Name = "lbl_AvalConyugeEmpCruces";
            this.lbl_AvalConyugeEmpCruces.Size = new System.Drawing.Size(43, 13);
            this.lbl_AvalConyugeEmpCruces.TabIndex = 40;
            this.lbl_AvalConyugeEmpCruces.Text = "Cruces:";
            // 
            // lbl_AvalConyugeEmpPeriodoIngresos
            // 
            this.lbl_AvalConyugeEmpPeriodoIngresos.AutoSize = true;
            this.lbl_AvalConyugeEmpPeriodoIngresos.Location = new System.Drawing.Point(561, 77);
            this.lbl_AvalConyugeEmpPeriodoIngresos.Name = "lbl_AvalConyugeEmpPeriodoIngresos";
            this.lbl_AvalConyugeEmpPeriodoIngresos.Size = new System.Drawing.Size(104, 13);
            this.lbl_AvalConyugeEmpPeriodoIngresos.TabIndex = 38;
            this.lbl_AvalConyugeEmpPeriodoIngresos.Text = "Periodo de Ingresos:";
            // 
            // lbl_AvalConyugeEmpIngresos
            // 
            this.lbl_AvalConyugeEmpIngresos.AutoSize = true;
            this.lbl_AvalConyugeEmpIngresos.Location = new System.Drawing.Point(347, 77);
            this.lbl_AvalConyugeEmpIngresos.Name = "lbl_AvalConyugeEmpIngresos";
            this.lbl_AvalConyugeEmpIngresos.Size = new System.Drawing.Size(59, 13);
            this.lbl_AvalConyugeEmpIngresos.TabIndex = 37;
            this.lbl_AvalConyugeEmpIngresos.Text = "Ingresos $:";
            // 
            // lbl_AvalConyugeEmpAntiguedad
            // 
            this.lbl_AvalConyugeEmpAntiguedad.AutoSize = true;
            this.lbl_AvalConyugeEmpAntiguedad.Location = new System.Drawing.Point(13, 77);
            this.lbl_AvalConyugeEmpAntiguedad.Name = "lbl_AvalConyugeEmpAntiguedad";
            this.lbl_AvalConyugeEmpAntiguedad.Size = new System.Drawing.Size(64, 13);
            this.lbl_AvalConyugeEmpAntiguedad.TabIndex = 39;
            this.lbl_AvalConyugeEmpAntiguedad.Text = "Antigüedad:";
            // 
            // lbl_AvalConyugeEmpAntCp
            // 
            this.lbl_AvalConyugeEmpAntCp.AutoSize = true;
            this.lbl_AvalConyugeEmpAntCp.Location = new System.Drawing.Point(764, 206);
            this.lbl_AvalConyugeEmpAntCp.Name = "lbl_AvalConyugeEmpAntCp";
            this.lbl_AvalConyugeEmpAntCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalConyugeEmpAntCp.TabIndex = 50;
            this.lbl_AvalConyugeEmpAntCp.Text = "C.P.:";
            // 
            // lbl_AvalConyugeEmpCp
            // 
            this.lbl_AvalConyugeEmpCp.AutoSize = true;
            this.lbl_AvalConyugeEmpCp.Location = new System.Drawing.Point(470, 128);
            this.lbl_AvalConyugeEmpCp.Name = "lbl_AvalConyugeEmpCp";
            this.lbl_AvalConyugeEmpCp.Size = new System.Drawing.Size(30, 13);
            this.lbl_AvalConyugeEmpCp.TabIndex = 50;
            this.lbl_AvalConyugeEmpCp.Text = "C.P.:";
            // 
            // lbl_AvalConyugeEmpDomicilio
            // 
            this.lbl_AvalConyugeEmpDomicilio.AutoSize = true;
            this.lbl_AvalConyugeEmpDomicilio.Location = new System.Drawing.Point(13, 102);
            this.lbl_AvalConyugeEmpDomicilio.Name = "lbl_AvalConyugeEmpDomicilio";
            this.lbl_AvalConyugeEmpDomicilio.Size = new System.Drawing.Size(52, 13);
            this.lbl_AvalConyugeEmpDomicilio.TabIndex = 36;
            this.lbl_AvalConyugeEmpDomicilio.Text = "Domicilio:";
            // 
            // gb_RCAval
            // 
            this.gb_RCAval.Controls.Add(this.txt_AvalRefComer3);
            this.gb_RCAval.Controls.Add(this.txt_AvalRefComer2);
            this.gb_RCAval.Controls.Add(this.txt_AvalRefComer1);
            this.gb_RCAval.Controls.Add(this.lbl_AvalRefComer3);
            this.gb_RCAval.Controls.Add(this.lbl_AvalRefComer2);
            this.gb_RCAval.Controls.Add(this.lbl_AvalRefComer1);
            this.gb_RCAval.Location = new System.Drawing.Point(12, 2528);
            this.gb_RCAval.Name = "gb_RCAval";
            this.gb_RCAval.Size = new System.Drawing.Size(989, 63);
            this.gb_RCAval.TabIndex = 12;
            this.gb_RCAval.TabStop = false;
            this.gb_RCAval.Text = "REFERENCIAS COMERCIALES";
            // 
            // txt_AvalRefComer3
            // 
            this.txt_AvalRefComer3.Location = new System.Drawing.Point(634, 29);
            this.txt_AvalRefComer3.Name = "txt_AvalRefComer3";
            this.txt_AvalRefComer3.Size = new System.Drawing.Size(271, 20);
            this.txt_AvalRefComer3.TabIndex = 3;
            // 
            // txt_AvalRefComer2
            // 
            this.txt_AvalRefComer2.Location = new System.Drawing.Point(329, 29);
            this.txt_AvalRefComer2.Name = "txt_AvalRefComer2";
            this.txt_AvalRefComer2.Size = new System.Drawing.Size(271, 20);
            this.txt_AvalRefComer2.TabIndex = 2;
            // 
            // txt_AvalRefComer1
            // 
            this.txt_AvalRefComer1.Location = new System.Drawing.Point(32, 29);
            this.txt_AvalRefComer1.Name = "txt_AvalRefComer1";
            this.txt_AvalRefComer1.Size = new System.Drawing.Size(271, 20);
            this.txt_AvalRefComer1.TabIndex = 1;
            // 
            // lbl_AvalRefComer3
            // 
            this.lbl_AvalRefComer3.AutoSize = true;
            this.lbl_AvalRefComer3.Location = new System.Drawing.Point(609, 32);
            this.lbl_AvalRefComer3.Name = "lbl_AvalRefComer3";
            this.lbl_AvalRefComer3.Size = new System.Drawing.Size(19, 13);
            this.lbl_AvalRefComer3.TabIndex = 0;
            this.lbl_AvalRefComer3.Text = "3.-";
            // 
            // lbl_AvalRefComer2
            // 
            this.lbl_AvalRefComer2.AutoSize = true;
            this.lbl_AvalRefComer2.Location = new System.Drawing.Point(309, 32);
            this.lbl_AvalRefComer2.Name = "lbl_AvalRefComer2";
            this.lbl_AvalRefComer2.Size = new System.Drawing.Size(19, 13);
            this.lbl_AvalRefComer2.TabIndex = 0;
            this.lbl_AvalRefComer2.Text = "2.-";
            // 
            // lbl_AvalRefComer1
            // 
            this.lbl_AvalRefComer1.AutoSize = true;
            this.lbl_AvalRefComer1.Location = new System.Drawing.Point(7, 32);
            this.lbl_AvalRefComer1.Name = "lbl_AvalRefComer1";
            this.lbl_AvalRefComer1.Size = new System.Drawing.Size(19, 13);
            this.lbl_AvalRefComer1.TabIndex = 0;
            this.lbl_AvalRefComer1.Text = "1.-";
            // 
            // gb_RBAval
            // 
            this.gb_RBAval.Controls.Add(this.label1);
            this.gb_RBAval.Controls.Add(this.label2);
            this.gb_RBAval.Controls.Add(this.label4);
            this.gb_RBAval.Controls.Add(this.label5);
            this.gb_RBAval.Controls.Add(this.txt_TCreBancoNumAval2);
            this.gb_RBAval.Controls.Add(this.txt_TComEmisorNumAval2);
            this.gb_RBAval.Controls.Add(this.txt_TComEmisorNumAval1);
            this.gb_RBAval.Controls.Add(this.txt_TCreBancoNumAval1);
            this.gb_RBAval.Location = new System.Drawing.Point(12, 2597);
            this.gb_RBAval.Name = "gb_RBAval";
            this.gb_RBAval.Size = new System.Drawing.Size(989, 103);
            this.gb_RBAval.TabIndex = 13;
            this.gb_RBAval.TabStop = false;
            this.gb_RBAval.Text = "REFERENCIAS BANCARIAS (NO CUENTAS DE CHEQUES)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(461, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tarj. Crédito Banco y No.:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(461, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tarj. Comercial Emisor y No.:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tarj. Comercial Emisor y No.:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tarj. Crédito Banco y No.:";
            // 
            // txt_TCreBancoNumAval2
            // 
            this.txt_TCreBancoNumAval2.Location = new System.Drawing.Point(617, 26);
            this.txt_TCreBancoNumAval2.Name = "txt_TCreBancoNumAval2";
            this.txt_TCreBancoNumAval2.Size = new System.Drawing.Size(289, 20);
            this.txt_TCreBancoNumAval2.TabIndex = 3;
            // 
            // txt_TComEmisorNumAval2
            // 
            this.txt_TComEmisorNumAval2.Location = new System.Drawing.Point(617, 55);
            this.txt_TComEmisorNumAval2.Name = "txt_TComEmisorNumAval2";
            this.txt_TComEmisorNumAval2.Size = new System.Drawing.Size(289, 20);
            this.txt_TComEmisorNumAval2.TabIndex = 4;
            // 
            // txt_TComEmisorNumAval1
            // 
            this.txt_TComEmisorNumAval1.Location = new System.Drawing.Point(161, 55);
            this.txt_TComEmisorNumAval1.Name = "txt_TComEmisorNumAval1";
            this.txt_TComEmisorNumAval1.Size = new System.Drawing.Size(289, 20);
            this.txt_TComEmisorNumAval1.TabIndex = 2;
            // 
            // txt_TCreBancoNumAval1
            // 
            this.txt_TCreBancoNumAval1.Location = new System.Drawing.Point(161, 26);
            this.txt_TCreBancoNumAval1.Name = "txt_TCreBancoNumAval1";
            this.txt_TCreBancoNumAval1.Size = new System.Drawing.Size(289, 20);
            this.txt_TCreBancoNumAval1.TabIndex = 1;
            // 
            // btn_guardar
            // 
            this.btn_guardar.Location = new System.Drawing.Point(773, 2709);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(117, 42);
            this.btn_guardar.TabIndex = 14;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.Location = new System.Drawing.Point(812, 2709);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(117, 42);
            this.btn_actualizar.TabIndex = 16;
            this.btn_actualizar.Text = "Actualizar";
            this.btn_actualizar.UseVisualStyleBackColor = true;
            this.btn_actualizar.Visible = false;
            this.btn_actualizar.Click += new System.EventHandler(this.actualizar_Click);
            // 
            // btn_Imprimir
            // 
            this.btn_Imprimir.Image = ((System.Drawing.Image)(resources.GetObject("btn_Imprimir.Image")));
            this.btn_Imprimir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Imprimir.Location = new System.Drawing.Point(789, 2709);
            this.btn_Imprimir.Name = "btn_Imprimir";
            this.btn_Imprimir.Size = new System.Drawing.Size(117, 42);
            this.btn_Imprimir.TabIndex = 15;
            this.btn_Imprimir.Text = "Imprimir";
            this.btn_Imprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Imprimir.UseVisualStyleBackColor = true;
            this.btn_Imprimir.Click += new System.EventHandler(this.btn_Imprimir_Click);
            // 
            // FRM_HOJA_VERDE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1039, 560);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.gb_DGAval);
            this.Controls.Add(this.gb_RBAval);
            this.Controls.Add(this.gb_RBCTE);
            this.Controls.Add(this.gb_RCAval);
            this.Controls.Add(this.gb_RCCTE);
            this.Controls.Add(this.gb_DRPersonales);
            this.Controls.Add(this.gb_DEConyugeAval);
            this.Controls.Add(this.gb_DEConyugeCte);
            this.Controls.Add(this.gb_DEAval);
            this.Controls.Add(this.gb_DECte);
            this.Controls.Add(this.gb_DGCte);
            this.Controls.Add(this.gb_DatosEncabezado);
            this.Controls.Add(this.btn_Imprimir);
            this.Controls.Add(this.btn_actualizar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FRM_HOJA_VERDE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HOJA VERDE";
            this.Load += new System.EventHandler(this.FRM_HOJA_VERDE_Load);
            this.gb_DatosEncabezado.ResumeLayout(false);
            this.gb_DatosEncabezado.PerformLayout();
            this.gb_DGCte.ResumeLayout(false);
            this.gb_DGCte.PerformLayout();
            this.gb_obligatorioDGCte.ResumeLayout(false);
            this.gb_obligatorioDGCte.PerformLayout();
            this.gb_DECte.ResumeLayout(false);
            this.gb_DECte.PerformLayout();
            this.gb_ObligatorioDECte.ResumeLayout(false);
            this.gb_ObligatorioDECte.PerformLayout();
            this.gb_DRPersonales.ResumeLayout(false);
            this.gb_DRPersonales.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_RCCTE.ResumeLayout(false);
            this.gb_RCCTE.PerformLayout();
            this.gb_RBCTE.ResumeLayout(false);
            this.gb_RBCTE.PerformLayout();
            this.gb_DEConyugeCte.ResumeLayout(false);
            this.gb_DEConyugeCte.PerformLayout();
            this.gb_DGAval.ResumeLayout(false);
            this.gb_DGAval.PerformLayout();
            this.gb_ObligatorioDGAval.ResumeLayout(false);
            this.gb_ObligatorioDGAval.PerformLayout();
            this.gb_DEAval.ResumeLayout(false);
            this.gb_DEAval.PerformLayout();
            this.gb_ObligatorioDEAval.ResumeLayout(false);
            this.gb_ObligatorioDEAval.PerformLayout();
            this.gb_DEConyugeAval.ResumeLayout(false);
            this.gb_DEConyugeAval.PerformLayout();
            this.gb_RCAval.ResumeLayout(false);
            this.gb_RCAval.PerformLayout();
            this.gb_RBAval.ResumeLayout(false);
            this.gb_RBAval.PerformLayout();
            this.ResumeLayout(false);

        }

       

      
        #endregion

        private System.Windows.Forms.GroupBox gb_DatosEncabezado;
        private System.Windows.Forms.TextBox txt_NumSolicitud;
        private System.Windows.Forms.Label lbl_nSolicitud;
        private System.Windows.Forms.TextBox txt_NumProspecto;
        private System.Windows.Forms.Label lbl_nProspecto;
        private System.Windows.Forms.TextBox txt_Importe;
        private System.Windows.Forms.Label lbl_importe;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.GroupBox gb_DGCte;
        private System.Windows.Forms.TextBox txt_CteObservaciones;
        private System.Windows.Forms.TextBox txt_CteDireccionRecom;
        private System.Windows.Forms.TextBox txt_CteDomAnterior;
        private System.Windows.Forms.TextBox txt_CteRecomendado;
        private System.Windows.Forms.TextBox txt_CteCruces;
        private System.Windows.Forms.TextBox txt_CteDomicilio;
        private System.Windows.Forms.TextBox txt_CteConyuge;
        private System.Windows.Forms.TextBox txt_CteMunicipio;
        private System.Windows.Forms.TextBox txt_CteTelefono;
        private System.Windows.Forms.TextBox txt_CteColonia;
        private System.Windows.Forms.TextBox txt_CteAntiguedad;
        private System.Windows.Forms.TextBox txt_CteColoniaAnterior;
        private System.Windows.Forms.TextBox txt_CteCpAnterior;
        private System.Windows.Forms.TextBox txt_CteCp;
        private System.Windows.Forms.TextBox txt_CteConyugeEdad;
        private System.Windows.Forms.TextBox txt_CteEdad;
        private System.Windows.Forms.TextBox txt_CteNombre;
        private System.Windows.Forms.Label lbl_CteEdoCivil;
        private System.Windows.Forms.Label lbl_CteObservaciones;
        private System.Windows.Forms.Label lbl_CteRecomParentezco;
        private System.Windows.Forms.Label lbl_CteDireccionRecom;
        private System.Windows.Forms.Label lbl_CteRecomendado;
        private System.Windows.Forms.Label lbl_CteCalidadVive;
        private System.Windows.Forms.Label lbl_CteCpAnterior;
        private System.Windows.Forms.Label lbl_CteColoniaAnterior;
        private System.Windows.Forms.Label lbl_CteDomAnterior;
        private System.Windows.Forms.Label lbl_CteMunicipio;
        private System.Windows.Forms.Label lbl_CteTelefono;
        private System.Windows.Forms.Label lbl_CteCp;
        private System.Windows.Forms.Label lbl_CteColonia;
        private System.Windows.Forms.Label lbl_CteCruces;
        private System.Windows.Forms.Label lbl_CteAntiguedad;
        private System.Windows.Forms.Label lbl_CteDomicilio;
        private System.Windows.Forms.Label lbl_CteConyugeFechaNacimiento;
        private System.Windows.Forms.Label lbl_CteConyugeEdad;
        private System.Windows.Forms.Label lbl_CteConyuge;
        private System.Windows.Forms.Label lbl_CteFechaNacimiento;
        private System.Windows.Forms.Label lbl_CteEdad;
        private System.Windows.Forms.Label lbl_CteNombre;
        private System.Windows.Forms.GroupBox gb_DECte;
        private System.Windows.Forms.Label lbl_empCtePuestoJefe;
        private System.Windows.Forms.Label lbl_empCteJefe;
        private System.Windows.Forms.Label lbl_empCteDpto;
        private System.Windows.Forms.Label lbl_empCteFunciones;
        private System.Windows.Forms.Label lbl_empCteEmpresa;
        private System.Windows.Forms.TextBox txt_CteEmpEmpresa;
        private System.Windows.Forms.TextBox txt_CteEmpFunciones;
        private System.Windows.Forms.Label lbl_empCteColonia;
        private System.Windows.Forms.Label lbl_CteEmpAntMunicipio;
        private System.Windows.Forms.Label lbl_empCteMunicipio;
        private System.Windows.Forms.Label lbl_empCteTelefono;
        private System.Windows.Forms.Label lbl_CteEmpAntColonia;
        private System.Windows.Forms.Label lbl_CteEmpAntEmpresa;
        private System.Windows.Forms.Label lbl_empCteCruces;
        private System.Windows.Forms.Label lbl_empCtePeriodoIngresos;
        private System.Windows.Forms.Label lbl_empCteIngresos;
        private System.Windows.Forms.Label lbl_empCteAntiguedad;
        private System.Windows.Forms.Label lbl_empCteDomicililo;
        private System.Windows.Forms.TextBox txt_CteEmpJefe;
        private System.Windows.Forms.TextBox txt_CteEmpDpto;
        private System.Windows.Forms.TextBox txt_CteEmpPuestoJefe;
        private System.Windows.Forms.TextBox txt_CteEmpColonia;
        private System.Windows.Forms.TextBox txt_CteEmpIngresos;
        private System.Windows.Forms.TextBox txt_CteEmpAntMunicipio;
        private System.Windows.Forms.TextBox txt_CteEmpMunicipio;
        private System.Windows.Forms.TextBox txt_CteEmpAntColonia;
        private System.Windows.Forms.TextBox txt_CteEmpTelefono;
        private System.Windows.Forms.TextBox txt_CteEmpAntEmpresa;
        private System.Windows.Forms.TextBox txt_CteEmpCruces;
        private System.Windows.Forms.TextBox txt_CteEmpDomicilio;
        private System.Windows.Forms.TextBox txt_CteEmpAntiguedad;
        private System.Windows.Forms.GroupBox gb_DRPersonales;
        private System.Windows.Forms.RadioButton rdb_CteRef1EsClienteNo;
        private System.Windows.Forms.RadioButton rdb_CteRef1EsClienteSi;
        private System.Windows.Forms.Label lbl_CteRef1EsCliente;
        private System.Windows.Forms.Label lbl_CteRef1Municipio;
        private System.Windows.Forms.Label lbl_CteRef1Colonia;
        private System.Windows.Forms.Label lbl_CteRef1Telefono;
        private System.Windows.Forms.Label lbl_CteRef1Domicilio;
        private System.Windows.Forms.Label lbl_CteRef1Parentesco;
        private System.Windows.Forms.Label lbl_CteRef1Nombre;
        private System.Windows.Forms.TextBox txt_CteRef1NumCuenta;
        private System.Windows.Forms.TextBox txt_CteRef1Telefono;
        private System.Windows.Forms.TextBox txt_CteRef1Colonia;
        private System.Windows.Forms.TextBox txt_CteRef1Municipio;
        private System.Windows.Forms.TextBox txt_CteRef1Domicilio;
        private System.Windows.Forms.TextBox txt_CteRef1Nombre;
        private System.Windows.Forms.Label lbl_CteRef1NumCuenta;
        private System.Windows.Forms.GroupBox gb_RCCTE;
        private System.Windows.Forms.TextBox txt_CteRefComer3;
        private System.Windows.Forms.TextBox txt_CteRefComer2;
        private System.Windows.Forms.TextBox txt_CteRefComer1;
        private System.Windows.Forms.Label lbl_CteRefComer3;
        private System.Windows.Forms.Label lbl_CteRefComer2;
        private System.Windows.Forms.Label lbl_CteRefComer1;
        private System.Windows.Forms.GroupBox gb_RBCTE;
        private System.Windows.Forms.Label lbl_TCreBancoNum1;
        private System.Windows.Forms.Label lbl_TCreBancoNum2;
        private System.Windows.Forms.Label lbl_TComEmisorNum2;
        private System.Windows.Forms.Label lbl_TComEmisorNum1;
        private System.Windows.Forms.TextBox txt_TCreBancoNum2;
        private System.Windows.Forms.TextBox txt_TComEmisorNum2;
        private System.Windows.Forms.TextBox txt_TComEmisorNum1;
        private System.Windows.Forms.TextBox txt_TCreBancoNum1;
        private System.Windows.Forms.DateTimePicker dtp_Fecha;
        private System.Windows.Forms.ComboBox ddl_CteRecomParentesco;
        private System.Windows.Forms.ComboBox ddl_CteCalidadVive;
        private System.Windows.Forms.ComboBox ddl_CteEdoCivil;
        private System.Windows.Forms.DateTimePicker dtp_CteConyugeFechaNacimiento;
        private System.Windows.Forms.DateTimePicker dtp_CteFechaNacimiento;
        private System.Windows.Forms.TextBox txt_CteMunicipioAnterior;
        private System.Windows.Forms.Label lbl_CteMunicipioAnterior;
        private System.Windows.Forms.TextBox txt_CteEmpCp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_CteEmpAntDomicilio;
        private System.Windows.Forms.Label lbl_CteEmpAntDomicilio;
        private System.Windows.Forms.TextBox txt_CteEmpAntCp;
        private System.Windows.Forms.Label lbl_CteEmpAntCp;
        private System.Windows.Forms.GroupBox gb_DEConyugeCte;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpPuestoJefe;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpColonia;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpIngresos;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntMunicipio;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpMunicipio;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntColonia;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpTelefono;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntDomicilio;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntEmpresa;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpCruces;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpDomicilio;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntiguedad;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpJefe;
        private System.Windows.Forms.Label lbl_CteConyugeEmpPuestoJefe;
        private System.Windows.Forms.Label lbl_CteConyugeEmpJefe;
        private System.Windows.Forms.Label lbl_CteConyugeEmpDpto;
        private System.Windows.Forms.Label lbl_CteConyugeEmpFunciones;
        private System.Windows.Forms.Label lbl_CteConyugeEmpEmpresa;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpEmpresa;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpDpto;
        private System.Windows.Forms.TextBox txt_CteRef1Cp;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpCp;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpFunciones;
        private System.Windows.Forms.Label lbl_CteConyugeEmpColonia;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntMunicipio;
        private System.Windows.Forms.Label lbl_CteConyugeEmpMunicipio;
        private System.Windows.Forms.Label lbl_CteConyugeEmpTelefono;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntColonia;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntDomicilio;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntEmpresa;
        private System.Windows.Forms.Label lbl_CteConyugeEmpCruces;
        private System.Windows.Forms.Label lbl_CteConyugeEmpPeriodoIngresos;
        private System.Windows.Forms.Label lbl_CteConyugeEmpIngresos;
        private System.Windows.Forms.Label lbl_CteRef1Cp;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntiguedad;
        private System.Windows.Forms.Label lbl_CteConyugeEmpCp;
        private System.Windows.Forms.Label lbl_CteConyugeEmpDomicilio;
        private System.Windows.Forms.TextBox txt_CteRef2NumCuenta;
        private System.Windows.Forms.TextBox txt_CteRef2Telefono;
        private System.Windows.Forms.TextBox txt_CteRef2Colonia;
        private System.Windows.Forms.TextBox txt_CteRef2Municipio;
        private System.Windows.Forms.TextBox txt_CteRef2Domicilio;
        private System.Windows.Forms.TextBox txt_CteRef2Nombre;
        private System.Windows.Forms.Label lbl_CteRef2NumCuenta;
        private System.Windows.Forms.TextBox txt_CteRef2Cp;
        private System.Windows.Forms.Label lbl_CteRef2EsCliente;
        private System.Windows.Forms.Label lbl_CteRef2Municipio;
        private System.Windows.Forms.Label lbl_CteRef2Colonia;
        private System.Windows.Forms.Label lbl_CteRef2Telefono;
        private System.Windows.Forms.Label lbl_CteRef2Domicilio;
        private System.Windows.Forms.Label lbl_CteRef2Parentesco;
        private System.Windows.Forms.Label lbl_CteRef2Cp;
        private System.Windows.Forms.Label lbl_CteRef2Nombre;
        private System.Windows.Forms.GroupBox gb_DGAval;
        private System.Windows.Forms.ComboBox ddl_AvalParentesco;
        private System.Windows.Forms.ComboBox ddl_AvalCalidadVive;
        private System.Windows.Forms.ComboBox ddl_AvalEdoCivil;
        private System.Windows.Forms.DateTimePicker dtp_AvalConyugeFechaNacimiento;
        private System.Windows.Forms.DateTimePicker dtp_AvalFechaNacimiento;
        private System.Windows.Forms.TextBox txt_AvalDomAnterior;
        private System.Windows.Forms.TextBox txt_AvalMunicipioAnterior;
        private System.Windows.Forms.TextBox txt_AvalMunicipio;
        private System.Windows.Forms.TextBox txt_AvalCruces;
        private System.Windows.Forms.Label lbl_AvalMunicipioAnterior;
        private System.Windows.Forms.Label lbl_AvalMunicipio;
        private System.Windows.Forms.TextBox txt_AvalDomicilio;
        private System.Windows.Forms.TextBox txt_AvalConyuge;
        private System.Windows.Forms.TextBox txt_AvalTelefono;
        private System.Windows.Forms.TextBox txt_AvalColonia;
        private System.Windows.Forms.TextBox txt_AvalAntiguedad;
        private System.Windows.Forms.TextBox txt_AvalColoniaAnterior;
        private System.Windows.Forms.TextBox txt_AvalCpAnterior;
        private System.Windows.Forms.TextBox txt_AvalCp;
        private System.Windows.Forms.TextBox txt_AvalConyugeEdad;
        private System.Windows.Forms.TextBox txt_AvalEdad;
        private System.Windows.Forms.TextBox txt_AvalNombre;
        private System.Windows.Forms.Label lbl_AvalEdoCivil;
        private System.Windows.Forms.Label lbl_AvalParentesco;
        private System.Windows.Forms.Label lbl_AvalCalidadVive;
        private System.Windows.Forms.Label lbl_AvalCpAnterior;
        private System.Windows.Forms.Label lbl_AvalColoniaAnterior;
        private System.Windows.Forms.Label lbl_AvalDomAnterior;
        private System.Windows.Forms.Label lbl_AvalTelefono;
        private System.Windows.Forms.Label lbl_AvalCp;
        private System.Windows.Forms.Label lbl_AvalColonia;
        private System.Windows.Forms.Label lbl_AvalCruces;
        private System.Windows.Forms.Label lbl_AvalAntiguedad;
        private System.Windows.Forms.Label lbl_AvalDomicilio;
        private System.Windows.Forms.Label lbl_AvalConyugeFechaNacimiento;
        private System.Windows.Forms.Label lbl_AvalConyugeEdad;
        private System.Windows.Forms.Label lbl_AvalConyuge;
        private System.Windows.Forms.Label lbl_AvalFechaNacimiento;
        private System.Windows.Forms.Label lbl_AvalEdad;
        private System.Windows.Forms.Label lbl_AvalNombre;
        private System.Windows.Forms.ComboBox ddl_CteRef2Parentesco;
        private System.Windows.Forms.ComboBox ddl_CteRef1Parentesco;
        private System.Windows.Forms.TextBox txt_CteConyugeEmpAntCp;
        private System.Windows.Forms.Label lbl_CteConyugeEmpAntCp;
        private System.Windows.Forms.GroupBox gb_DEAval;
        private System.Windows.Forms.TextBox txt_AvalEmpPuestoJefe;
        private System.Windows.Forms.TextBox txt_AvalEmpColonia;
        private System.Windows.Forms.TextBox txt_AvalEmpIngresos;
        private System.Windows.Forms.TextBox txt_AvalEmpAntMunicipio;
        private System.Windows.Forms.TextBox txt_AvalEmpMunicipio;
        private System.Windows.Forms.TextBox txt_AvalEmpAntColonia;
        private System.Windows.Forms.TextBox txt_AvalEmpTelefono;
        private System.Windows.Forms.TextBox txt_AvalEmpAntDomicilio;
        private System.Windows.Forms.TextBox txt_AvalEmpAntEmpresa;
        private System.Windows.Forms.TextBox txt_AvalEmpCruces;
        private System.Windows.Forms.TextBox txt_AvalEmpDomicilio;
        private System.Windows.Forms.TextBox txt_AvalEmpAntiguedad;
        private System.Windows.Forms.TextBox txt_AvalEmpJefe;
        private System.Windows.Forms.Label lbl_AvalEmpPuestoJefe;
        private System.Windows.Forms.Label lbl_AvalEmpJefe;
        private System.Windows.Forms.Label lbl_AvalEmpDpto;
        private System.Windows.Forms.Label lbl_AvalEmpFunciones;
        private System.Windows.Forms.Label lbl_AvalEmpEmpresa;
        private System.Windows.Forms.TextBox txt_AvalEmpEmpresa;
        private System.Windows.Forms.TextBox txt_AvalEmpDpto;
        private System.Windows.Forms.TextBox txt_AvalEmpAntCp;
        private System.Windows.Forms.TextBox txt_AvalEmpCp;
        private System.Windows.Forms.TextBox txt_AvalEmpFunciones;
        private System.Windows.Forms.Label lbl_AvalEmpColonia;
        private System.Windows.Forms.Label lbl_AvalEmpAntMunicipio;
        private System.Windows.Forms.Label lbl_AvalEmpMunicipio;
        private System.Windows.Forms.Label lbl_AvalEmpTelefono;
        private System.Windows.Forms.Label lbl_AvalEmpAntColonia;
        private System.Windows.Forms.Label lbl_AvalEmpAntDomicilio;
        private System.Windows.Forms.Label lbl_AvalEmpAntEmpresa;
        private System.Windows.Forms.Label lbl_AvalEmpCruces;
        private System.Windows.Forms.Label lbl_AvalEmpPeriodoIngresos;
        private System.Windows.Forms.Label lbl_AvalEmpIngresos;
        private System.Windows.Forms.Label lbl_AvalEmpAntCp;
        private System.Windows.Forms.Label lbl_AvalEmpAntiguedad;
        private System.Windows.Forms.Label lbl_AvalEmpCp;
        private System.Windows.Forms.Label lbl_AvalEmpDomicilio;
        private System.Windows.Forms.GroupBox gb_DEConyugeAval;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpPuestoJefe;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpColonia;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpIngresos;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntMunicipio;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpMunicipio;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntColonia;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpTelefono;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntDomicilio;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntEmpresa;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpCruces;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpDomicilio;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntiguedad;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpJefe;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpPuestoJefe;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpJefe;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpDpto;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpFunciones;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpEmpresa;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpEmpresa;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpDpto;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpAntCp;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpCp;
        private System.Windows.Forms.TextBox txt_AvalConyugeEmpFunciones;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpColonia;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntMunicipio;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpMunicipio;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpTelefono;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntColonia;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntDomicilio;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntEmpresa;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpCruces;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpPeriodoIngresos;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpIngresos;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntiguedad;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpAntCp;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpCp;
        private System.Windows.Forms.Label lbl_AvalConyugeEmpDomicilio;
        private System.Windows.Forms.GroupBox gb_RCAval;
        private System.Windows.Forms.TextBox txt_AvalRefComer3;
        private System.Windows.Forms.TextBox txt_AvalRefComer2;
        private System.Windows.Forms.TextBox txt_AvalRefComer1;
        private System.Windows.Forms.Label lbl_AvalRefComer3;
        private System.Windows.Forms.Label lbl_AvalRefComer2;
        private System.Windows.Forms.Label lbl_AvalRefComer1;
        private System.Windows.Forms.GroupBox gb_RBAval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_TCreBancoNumAval2;
        private System.Windows.Forms.TextBox txt_TComEmisorNumAval2;
        private System.Windows.Forms.TextBox txt_TComEmisorNumAval1;
        private System.Windows.Forms.TextBox txt_TCreBancoNumAval1;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.ComboBox ddl_CteEmpPeriodoIngresos;
        private System.Windows.Forms.ComboBox ddl_CteConyugeEmpPeriodoIngresos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdb_CteRef2EsClienteSi;
        private System.Windows.Forms.RadioButton rdb_CteRef2EsClienteNo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox ddl_AvalEmpPeriodoIngresos;
        private System.Windows.Forms.ComboBox ddl_AvalConyugeEmpPeriodoIngresos;
        private System.Windows.Forms.Label lbl_AvalObservaciones;
        private System.Windows.Forms.TextBox txt_AvalObservaciones;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.Button btn_Imprimir;
     //   private Microsoft.VisualBasic.PowerPacks.Printing.PrintForm printForm1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_ObligatorioConyugeCte;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_ObligatorioFechaNacCnyugeCte;
        private System.Windows.Forms.Label lbl_ObligatorioEdadConyugeCte;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_Obligatorio;
        private System.Windows.Forms.GroupBox gb_obligatorioDGCte;
        private System.Windows.Forms.CheckBox chk_SoloReferencias;
        private System.Windows.Forms.CheckBox chk_SoloAval;
        private System.Windows.Forms.Label lbl_EmpCte1;
        private System.Windows.Forms.CheckBox chk_CteNoTrabaja;
        private System.Windows.Forms.TextBox txt_CteEmpObservaciones;
        private System.Windows.Forms.Label lbl_CteNoTrabaja;
        private System.Windows.Forms.GroupBox gb_ObligatorioDECte;
        private System.Windows.Forms.Label lbl_EmpCte3;
        private System.Windows.Forms.Label lbl_EmpCte2;
        private System.Windows.Forms.Label lbl_EmpCte4;
        private System.Windows.Forms.Label lbl_EmpCte5;
        private System.Windows.Forms.Label lbl_EmpCte8;
        private System.Windows.Forms.Label lbl_EmpCte7;
        private System.Windows.Forms.Label lbl_EmpCte6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chk_SinAval;
        private System.Windows.Forms.GroupBox gb_ObligatorioDGAval;
        private System.Windows.Forms.Label lbl_Aval7;
        private System.Windows.Forms.Label lbl_Aval6;
        private System.Windows.Forms.Label lbl_Aval5;
        private System.Windows.Forms.Label lbl_Aval4;
        private System.Windows.Forms.Label lbl_Aval3;
        private System.Windows.Forms.Label lbl_Aval2;
        private System.Windows.Forms.Label lbl_Aval10;
        private System.Windows.Forms.Label lbl_Aval15;
        private System.Windows.Forms.Label lbl_Aval14;
        private System.Windows.Forms.Label lbl_Aval13;
        private System.Windows.Forms.Label lbl_Aval12;
        private System.Windows.Forms.Label lbl_Aval11;
        private System.Windows.Forms.Label lbl_Aval9;
        private System.Windows.Forms.Label lbl_Aval8;
        private System.Windows.Forms.Label lbl_Aval1;
        private System.Windows.Forms.GroupBox gb_ObligatorioDEAval;
        private System.Windows.Forms.Label lbl_AvalNoTrabaja;
        private System.Windows.Forms.CheckBox chk_AvalNoTrabaja;
        private System.Windows.Forms.TextBox txt_AvalEmpObservaciones;
        private System.Windows.Forms.Label lbl_AvalEmp3;
        private System.Windows.Forms.Label lbl_AvalEmp2;
        private System.Windows.Forms.Label lbl_AvalEmp5;
        private System.Windows.Forms.Label lbl_AvalEmp7;
        private System.Windows.Forms.Label lbl_AvalEmp4;
        private System.Windows.Forms.Label lbl_AvalEmp1;
        private System.Windows.Forms.Label lbl_AvalEmp8;
        private System.Windows.Forms.Label lbl_AvalEmp6;
        private System.Windows.Forms.Label lbl_FechaRes;

    }
}

