﻿namespace PuntoVenta.View
{
    partial class DM0312_DetalleCodigoPostal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_DetalleCodigoPostal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.Aceptar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dgv_cps = new System.Windows.Forms.DataGridView();
            this.lbl_Estado = new System.Windows.Forms.Label();
            this.cb_Estado = new System.Windows.Forms.ComboBox();
            this.cb_delegacion = new System.Windows.Forms.ComboBox();
            this.lbl_delegacion = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cps)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(598, 53);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(133, 15);
            this.lbl_name.TabIndex = 1;
            this.lbl_name.Text = "Colonia / código postal:";
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(737, 48);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(161, 22);
            this.txt_search.TabIndex = 2;
            this.txt_search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_search_KeyPress);
            this.txt_search.Leave += new System.EventHandler(this.Txt_search_Leave);
            // 
            // Aceptar
            // 
            this.Aceptar.BackColor = System.Drawing.Color.White;
            this.Aceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Aceptar.FlatAppearance.BorderSize = 0;
            this.Aceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aceptar.Image = ((System.Drawing.Image)(resources.GetObject("Aceptar.Image")));
            this.Aceptar.Location = new System.Drawing.Point(2, 58);
            this.Aceptar.Name = "Aceptar";
            this.Aceptar.Size = new System.Drawing.Size(66, 73);
            this.Aceptar.TabIndex = 45;
            this.Aceptar.Text = "Aceptar (Crtl-G)";
            this.Aceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Aceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Aceptar.UseVisualStyleBackColor = false;
            this.Aceptar.Click += new System.EventHandler(this.Aceptar_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(2, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 72);
            this.button1.TabIndex = 47;
            this.button1.Text = "Regresar (Esc)";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Btn_Regresar_Click);
            // 
            // dgv_cps
            // 
            this.dgv_cps.AllowUserToAddRows = false;
            this.dgv_cps.AllowUserToDeleteRows = false;
            this.dgv_cps.AllowUserToResizeColumns = false;
            this.dgv_cps.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_cps.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_cps.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_cps.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_cps.BackgroundColor = System.Drawing.Color.White;
            this.dgv_cps.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_cps.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_cps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cps.EnableHeadersVisualStyles = false;
            this.dgv_cps.Location = new System.Drawing.Point(81, 86);
            this.dgv_cps.Margin = new System.Windows.Forms.Padding(10, 3, 200, 10);
            this.dgv_cps.MultiSelect = false;
            this.dgv_cps.Name = "dgv_cps";
            this.dgv_cps.ReadOnly = true;
            this.dgv_cps.RowHeadersVisible = false;
            this.dgv_cps.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_cps.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_cps.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_cps.Size = new System.Drawing.Size(894, 416);
            this.dgv_cps.TabIndex = 48;
            this.dgv_cps.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_cps_CellDoubleClick);
            this.dgv_cps.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Dgv_cps_ColumnHeaderMouseClick);
            // 
            // lbl_Estado
            // 
            this.lbl_Estado.AutoSize = true;
            this.lbl_Estado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estado.Location = new System.Drawing.Point(115, 50);
            this.lbl_Estado.Name = "lbl_Estado";
            this.lbl_Estado.Size = new System.Drawing.Size(46, 15);
            this.lbl_Estado.TabIndex = 49;
            this.lbl_Estado.Text = "Estado:";
            // 
            // cb_Estado
            // 
            this.cb_Estado.FormattingEnabled = true;
            this.cb_Estado.Location = new System.Drawing.Point(167, 48);
            this.cb_Estado.Name = "cb_Estado";
            this.cb_Estado.Size = new System.Drawing.Size(166, 21);
            this.cb_Estado.TabIndex = 50;
            this.cb_Estado.SelectedIndexChanged += new System.EventHandler(this.cb_Estado_SelectedIndexChanged);
            this.cb_Estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cb_Estado_KeyPress);
            this.cb_Estado.Validating += new System.ComponentModel.CancelEventHandler(this.cb_Estado_Validating);
            // 
            // cb_delegacion
            // 
            this.cb_delegacion.FormattingEnabled = true;
            this.cb_delegacion.Location = new System.Drawing.Point(417, 48);
            this.cb_delegacion.Name = "cb_delegacion";
            this.cb_delegacion.Size = new System.Drawing.Size(166, 21);
            this.cb_delegacion.TabIndex = 52;
            this.cb_delegacion.SelectedIndexChanged += new System.EventHandler(this.cb_delegacion_SelectedIndexChanged);
            this.cb_delegacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cb_delegacion_KeyPress);
            this.cb_delegacion.Validating += new System.ComponentModel.CancelEventHandler(this.cb_delegacion_Validating);
            // 
            // lbl_delegacion
            // 
            this.lbl_delegacion.AutoSize = true;
            this.lbl_delegacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_delegacion.Location = new System.Drawing.Point(339, 50);
            this.lbl_delegacion.Name = "lbl_delegacion";
            this.lbl_delegacion.Size = new System.Drawing.Size(72, 15);
            this.lbl_delegacion.TabIndex = 51;
            this.lbl_delegacion.Text = "Delegación:";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(95, 7);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(878, 35);
            this.txt_Comentarios.TabIndex = 112;
            // 
            // DM0312_DetalleCodigoPostal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(985, 511);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.dgv_cps);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Aceptar);
            this.Controls.Add(this.cb_delegacion);
            this.Controls.Add(this.lbl_delegacion);
            this.Controls.Add(this.cb_Estado);
            this.Controls.Add(this.lbl_Estado);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.lbl_name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_DetalleCodigoPostal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalogo de Direcciones ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_DetalleCodigoPostal_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_DetalleCodigoPostal_Load);
            this.LocationChanged += new System.EventHandler(this.DM0312_DetalleCodigoPostal_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_DetalleCodigoPostal_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button Aceptar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgv_cps;
        private System.Windows.Forms.Label lbl_Estado;
        private System.Windows.Forms.ComboBox cb_Estado;
        private System.Windows.Forms.ComboBox cb_delegacion;
        private System.Windows.Forms.Label lbl_delegacion;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}