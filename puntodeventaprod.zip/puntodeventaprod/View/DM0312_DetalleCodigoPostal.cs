﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleCodigoPostal : Form
    {
        public static bool regresar;
        private bool Buscando;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public MCodigosPostales CodigoPostalSeleccionado = new MCodigosPostales();
        private List<MCodigosPostales> CodigosPostales = new List<MCodigosPostales>();
        private List<MCodigosPostales> CodigosPostalesGlobales = new List<MCodigosPostales>();
        private readonly CDetalleVenta ControladorDetalleVenta = new CDetalleVenta();
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();
        private bool ModeloSeleccionado;

        public DM0312_DetalleCodigoPostal()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
        }

        ~DM0312_DetalleCodigoPostal()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Load de forma
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private async void DM0312_DetalleCodigoPostal_Load(object sender, EventArgs e)
        {
            List<string> ListaEstados = ObtenerEstados();
            BindingSource bsource = new BindingSource();
            bsource.DataSource = ListaEstados;
            cb_Estado.DataSource = bsource.DataSource;
            cb_Estado.DisplayMember = "Name";
            cb_Estado.ValueMember = "";
            cb_Estado.Text = "Jalisco";

            List<string> ListaDelegaciones = ObtenerDelegaciones();
            bsource = new BindingSource();
            bsource.DataSource = ListaDelegaciones;
            cb_delegacion.DataSource = bsource.DataSource;
            cb_delegacion.DisplayMember = "Name";
            cb_delegacion.ValueMember = "";
            cb_delegacion.Text = "Guadalajara";

            dgv_cps.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 12f, FontStyle.Bold);
            dgv_cps.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);


            toolTip1.SetToolTip(cb_Estado, "INGRESAR ESTADO A BUSCAR");
            toolTip1.SetToolTip(cb_delegacion, "INGRESAR DELEGACION A BUSCAR");
            toolTip1.SetToolTip(txt_search,
                "INGRESAR LA COLONIA O CODIGO POSTAL DE LA DIRECCION A BUSCAR, DAR ENTER AL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
            toolTip1.SetToolTip(lbl_Estado, "INGRESAR ESTADO A BUSCAR");
            toolTip1.SetToolTip(lbl_delegacion, "INGRESAR DELEGACION A BUSCAR");
            toolTip1.SetToolTip(lbl_name, "INGRESAR LA COLONIA O CODIGO POSTAL DE LA DIRECCION A BUSCAR");
            toolTip1.SetToolTip(Aceptar, "SELECCIONAR SI YA ENCONTRO LA DIRECCION DEL CLIENTE");
            toolTip1.SetToolTip(button1, "SALIR DEL ASISTENTES DE DIRECCIONES");
            txt_Comentarios.Text =
                "ASISTENTE DE DIRECCION, BUSCAR LA DIRECCION DEL CLIENTE, SE PUEDE FILTRAR POR ESTADO, DELEGACION, COLONIA Y CODIGO POSTAR AL ENCONTRAR LA DIRECCION DAR CLICK AL BOTON DE ACEPTAR";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_cps.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_cps.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_cps.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") dgv_cps.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            try
            {
                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    CDetalleVenta.DesabilitarControles(false, this);
                }

                CodigosPostalesGlobales = await Task.Run(() => ControladorDetalleVenta.ObtenerCps());
                CodigosPostalesGlobales = CodigosPostalesGlobales.OrderBy(x => x.CP).ToList();
                //txt_search.Text = "Guadalajara";
                Busqueda();
                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    CDetalleVenta.DesabilitarControles(true, this);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DM0312_DetalleCodigoPostal_Load", "DM0312_DetalleCodigoPostal.cs", ex);
                MessageBox.Show(ex.Message +
                                " function DM0312_DetalleCodigoPostal_Load, class: DM0312_DetalleCodigoPostal");
            }
        }

        /// <summary>
        ///     Obtiene colonias, delegacion o codigo postales de acuerdo a la busqueda
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 29/009/17
        private void ObtenerColonias()
        {
            try
            {
                Busqueda();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerColonias", "DM0312_DetalleCodigoPostal.cs", ex);
                MessageBox.Show(ex.Message + " function ObtenerColonias, class: DM0312_DetalleCodigoPostal.cs");
            }
        }

        /// <summary>
        ///     Cierra el dialogo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            regresar = true;
            Close();
        }

        /// <summary>
        ///     Key press de texto de busqueda
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private void Txt_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txt_search.Text.Length > 3)
                    ObtenerColonias();
                else if (txt_search.Text != string.Empty)
                    MessageBox.Show("La busqueda tiene que ser mayor a 3 caracteres", "Informacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    Busqueda();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     Evento cuando el focus se pierde del control de busqueda
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private void Txt_search_Leave(object sender, EventArgs e)
        {
            dgv_cps.Visible = true;
            if (txt_search.Text.Length > 3)
                ObtenerColonias();
            else if (txt_search.Text != string.Empty)
                MessageBox.Show("La busqueda tiene que ser mayor a 3 caracteres", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            else
                Busqueda();
        }

        /// <summary>
        ///     Boton aceptar que carga los datos seleccionados
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private void Aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_cps.CurrentCell != null)
            {
                CodigoPostalSeleccionado = CodigosPostales[dgv_cps.CurrentCell.RowIndex];
                ModeloSeleccionado = true;
                Close();
            }
            else
            {
                MessageBox.Show("Se debe seleccionar un código postal", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Closing de codigo postal
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">FormClosingEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/10/17
        private void DM0312_DetalleCodigoPostal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((sender is Button && string.Equals((sender as Button).Name, @"Aceptar")) || ModeloSeleccionado)
            {
            }
            else
            {
                Dispose();
                regresar = true;
            }
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_cps_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(CodigosPostales.ToList());
            funciones.OrderGridview(dgv_cps, e.ColumnIndex, TempObjects,
                CodigosPostales.GetType().GetGenericArguments().Single());
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleCodigoPostal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                regresar = true;
                Close();
            }

            if (e.Control && e.KeyCode == Keys.G)
                if (Aceptar.Visible)
                {
                    if (dgv_cps.CurrentCell != null)
                    {
                        CodigoPostalSeleccionado = CodigosPostales[dgv_cps.CurrentCell.RowIndex];
                        ModeloSeleccionado = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Se debe seleccionar un código postal", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
        }

        /// <summary>
        ///     Detecta cuando se mueve la forma para reacomodar el loader
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 28/11/17
        private void DM0312_DetalleCodigoPostal_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        /// <summary>
        ///     double clic de codigos postales
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 29/09/17
        private void dgv_cps_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                if (dgv_cps.CurrentCell != null)
                {
                    CodigoPostalSeleccionado.Estado = dgv_cps.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
                    CodigoPostalSeleccionado.Delegacion = dgv_cps.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
                    CodigoPostalSeleccionado.Colonia = dgv_cps.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
                    CodigoPostalSeleccionado.CP = dgv_cps.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
                    ModeloSeleccionado = true;
                    Close();
                }
        }


        private List<string> ObtenerEstados()
        {
            List<string> ListaEstados = new List<string>();
            string query = "Select Estado From CodigoPostal WITH(NOLOCK) Group By estado";
            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        ListaEstados.Add(dr["Estado"].ToString());
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerEstados", "DM0312_DetalleCodigoPostal", ex);
                MessageBox.Show(ex.Message);
            }

            return ListaEstados.OrderBy(x => x).ToList();
        }

        private List<string> ObtenerDelegaciones()
        {
            List<string> ListaDelegaciones = new List<string>();
            string query =
                "Select Delegacion From CodigoPostal WITH(NOLOCK) WHERE Estado = @Estado Group By Delegacion";

            try
            {
                SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Estado", cb_Estado.Text);
                SqlDataReader dr = sqlCommand.ExecuteReader();
                if (dr.HasRows)
                    while (dr.Read())
                        ListaDelegaciones.Add(dr["Delegacion"].ToString());
                dr.Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenerDelegaciones", "DM0312_DetalleCodigoPostal", ex);
                MessageBox.Show(ex.Message);
            }

            return ListaDelegaciones.OrderBy(x => x).ToList();
        }

        private void cb_Estado_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> ListaDelegaciones = ObtenerDelegaciones();
            BindingSource bsource = new BindingSource();
            bsource.DataSource = ListaDelegaciones;
            cb_delegacion.DataSource = bsource.DataSource;
            cb_delegacion.DisplayMember = "Name";
            cb_delegacion.ValueMember = "";
            Busqueda();
        }

        private void Busqueda()
        {
            if (!Buscando)
            {
                Buscando = true;
                dgv_cps.Visible = true;
                CodigosPostales = CodigosPostalesGlobales.Where
                (x =>
                    (x.CP.Contains(txt_search.Text) ||
                     x.Colonia.Contains(txt_search.Text.ToUpper())
                    ) &&
                    x.Delegacion == cb_delegacion.Text &&
                    x.Estado == cb_Estado.Text
                ).ToList();

                dgv_cps.DataSource = null;

                dgv_cps.DataSource = CodigosPostales;
                //dgv_cps.Select();

                if (dgv_cps.Rows.Count == 0) dgv_cps.Visible = false;


                Buscando = false;
            }
        }

        private void cb_delegacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            Busqueda();
        }

        private void cb_Estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];

            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                List<string> ListaDelegaciones = ObtenerDelegaciones();
                BindingSource bsource = new BindingSource();
                bsource.DataSource = ListaDelegaciones;
                cb_delegacion.DataSource = bsource.DataSource;
                cb_delegacion.DisplayMember = "Name";
                cb_delegacion.ValueMember = "";
                Busqueda();
            }
        }

        private void cb_delegacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) Busqueda();
        }

        private void cb_delegacion_Validating(object sender, CancelEventArgs e)
        {
            Busqueda();
        }

        private void cb_Estado_Validating(object sender, CancelEventArgs e)
        {
            List<string> ListaDelegaciones = ObtenerDelegaciones();
            BindingSource bsource = new BindingSource();
            bsource.DataSource = ListaDelegaciones;
            cb_delegacion.DataSource = bsource.DataSource;
            cb_delegacion.DisplayMember = "Name";
            cb_delegacion.ValueMember = "";
            Busqueda();
        }
    }
}