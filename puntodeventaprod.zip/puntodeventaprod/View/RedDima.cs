﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class RedDima : Form
    {
        public bool CerrarVentana = false;
        private readonly DM0312_CPuntoDeVenta controller = new DM0312_CPuntoDeVenta();
        private CDetalleVenta controllerD = new CDetalleVenta();
        public string cuenta = "";

        public RedDima()
        {
            InitializeComponent();
        }

        ~RedDima()
        {
            GC.Collect();
        }

        private void btnBuscarClienteAlerta_Click(object sender, EventArgs e)
        {
            ClientesRedDIMA frmC = new ClientesRedDIMA();
            Hide();
            frmC.ShowDialog();
            if (!frmC.CerrarVentana)
            {
                Show();
                StartPosition = FormStartPosition.CenterScreen;
                cbx_Cuenta.Text = frmC.cuentaR;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Aceptar();
        }

        public void Aceptar()
        {
            if (cbx_Cuenta.Text.Trim() == "")
            {
                MessageBox.Show("Debe agregar una cuenta", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cbx_Cuenta.Text = "";
            }
            else
            {
                int ResulDimaR = controller.ValidaCuentasDimaR(cbx_Cuenta.Text, cuenta);

                if (ResulDimaR == 5)
                {
                    MessageBox.Show("El Afiliador Dima no puede ser el mismo cliente Dima ", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cbx_Cuenta.Text = "";
                }
                else
                {
                    if (controller.ClienteRedV(cbx_Cuenta.Text.Trim()) == "NO" && cbx_Cuenta.Text != "")
                    {
                        MessageBox.Show("Cuenta incorrecta ", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cbx_Cuenta.Text = "";
                    }
                    else
                    {
                        if (ResulDimaR == 1)
                        {
                            MessageBox.Show("Cuenta no es DIMA ", "Advertencia", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                        else
                        {
                            if (ResulDimaR == 2)
                            {
                                MessageBox.Show("Ya fue recomendado por nip y foto ", "Advertencia",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else
                            {
                                if (ResulDimaR == 3)
                                {
                                    MessageBox.Show("Ya fue recomendado ", "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    Process pTicket = new Process();
                                    pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"RutaTicket.exe";
                                    pTicket.StartInfo.Verb = "runas";
                                    pTicket.StartInfo.Arguments = "SHM4 " + cuenta + " " + cbx_Cuenta.Text.Trim() +
                                                                  " " + ClaseEstatica.Usuario.sucursal + " " +
                                                                  ClaseEstatica.WorkStation + " " +
                                                                  ClaseEstatica.Usuario.Usser;
                                    pTicket.StartInfo.UseShellExecute = false;
                                    pTicket.Start();
                                    if (true) pTicket.WaitForExit();
                                    pTicket.Dispose();
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void RedDima_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.Control && e.KeyCode == Keys.G)
            {
            }
        }

        private void cbx_Cuenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (controller.ClienteRedV(cbx_Cuenta.Text.Trim()) == "NO" && cbx_Cuenta.Text != "")
                {
                    MessageBox.Show("Cuenta incorrecta ", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cbx_Cuenta.Text = "";
                    cbx_Cuenta.Focus();
                }
                else
                {
                    btnAceptar.Focus();
                }
            }
        }
    }
}