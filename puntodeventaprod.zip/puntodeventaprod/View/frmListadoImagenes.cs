﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Properties;

namespace PuntoVenta.View
{
    public partial class frmListadoImagenes : Form
    {
        public string cCliente = "";
        private readonly DM0312_C_CampoExtra cExtra = new DM0312_C_CampoExtra();

        private readonly fusionAppControlador controller = new fusionAppControlador();
        public bool guardado;
        private readonly int iIdVenta;
        private readonly List<appFusionModel> imagenesCliente;
        private readonly string sEstatus;

        public frmListadoImagenes(List<appFusionModel> listaImagenes, int iIdVenta, string sEstatus)
        {
            InitializeComponent();
            imagenesCliente = listaImagenes;
            this.iIdVenta = iIdVenta;
            this.sEstatus = sEstatus;
        }


        ~frmListadoImagenes()
        {
            GC.Collect();
        }


        private void frmListadoImagenes_Load(object sender, EventArgs e)
        {
            try
            {
                if (imagenesCliente.Count > 1)
                {
                    dgListadoImagenes.DataSource = imagenesCliente;
                    dgListadoImagenes.RowTemplate.Resizable = DataGridViewTriState.True;

                    dgListadoImagenes.Columns[1].Width = 272;

                    dgListadoImagenes.Columns[1].ReadOnly = true;
                    dgListadoImagenes.Columns[3].ReadOnly = true;

                    dgListadoImagenes.Columns[0].Visible = false;
                    dgListadoImagenes.Columns[2].Visible = true;
                    dgListadoImagenes.Columns[2].Width = 300;


                    dgListadoImagenes.Columns[4].Visible = false;
                    dgListadoImagenes.Columns[5].Visible = false;
                }
                else
                {
                    dgListadoImagenes.DataSource = imagenesCliente;
                    showVisorImagenes();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void showVisorImagenes()
        {
            appFusionModel dato = (appFusionModel)dgListadoImagenes.CurrentRow.DataBoundItem;
            if (dato != null)
            {
                frmVisorImagenes visor = new frmVisorImagenes(dato.imgImagen);
                visor.ShowDialog();
                if (visor.bEstatusImangen)
                {
                    dato.bEstatusValidacion = visor.bEstatusImangen;
                    dato.imgEstatus = controller.ScaleImage(Resources.comprobar, 20, 20);

                    if (dgListadoImagenes.RowCount == 1)
                    {
                        guardado = true;
                        guardarEvento();
                    }
                }
                else
                {
                    dato.bEstatusValidacion = visor.bEstatusImangen;
                    dato.imgEstatus = controller.ScaleImage(Resources.Cancelar_50, 20, 20);
                    if (dgListadoImagenes.RowCount == 1)
                    {
                        if (!string.IsNullOrEmpty(cCliente) && !visor.bEstatusImangen)
                        {
                            guardado = true;
                            controller.borrarImagen(cCliente, dato.sIdImagen);
                        }

                        Close();
                    }
                }

                dgListadoImagenes.Refresh(); // Make sure this comes first
                dgListadoImagenes.Parent.Refresh();
            }
        }

        private void dgListadoImagenes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            click();
        }

        private void dgListadoImagenes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            click();
        }

        private void click()
        {
            try
            {
                showVisorImagenes();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            guardado = true;
            if (todasImagenesValidas())
            {
                guardarEvento();
            }
            else
            {
                DialogResult result = MessageBox.Show("Faltan imagenes por validar, ¿Desea Salir?", "Punto De Venta",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    Close();
                else
                    guardado = false;
            }
        }

        public bool todasImagenesValidas()
        {
            bool todasValidas = true;
            foreach (DataGridViewRow item in dgListadoImagenes.Rows)
            {
                appFusionModel registro = (appFusionModel)item.DataBoundItem;
                if (!registro.bEstatusValidacion) todasValidas = false;
            }

            return todasValidas;
        }

        private void guardarEvento()
        {
            string insert = null;
            foreach (DataGridViewRow item in dgListadoImagenes.Rows)
            {
                appFusionModel registro = (appFusionModel)item.DataBoundItem;

                if (insert == null)
                    insert = "(" + iIdVenta + "," + registro.idImagen + ",'" + ClaseEstatica.Usuario.usuario + "','" +
                             registro.bEstatusValidacion + "' )";
                else
                    insert = insert + " , (" + iIdVenta + "," + registro.idImagen + ",'" +
                             ClaseEstatica.Usuario.usuario + "', '" + registro.bEstatusValidacion + "' )";
            }

            if (!controller.insertDocData(insert))
            {
                MessageBox.Show("Error al Insertar");
            }
            else
            {
                bool bTodoCorrecto = false;
                foreach (DataGridViewRow item in dgListadoImagenes.Rows)
                {
                    appFusionModel r = (appFusionModel)item.DataBoundItem;
                    if (!r.bEstatusValidacion)
                        break;
                    bTodoCorrecto = true;
                }

                if (bTodoCorrecto)
                    cExtra.insertarEvento(iIdVenta, sEstatus, ClaseEstatica.Usuario.sRefCtaCajero, "VTA00012",
                        "App Fusion");
            }

            Close();
        }

        private void frmListadoImagenes_FormClosing(object sender, CancelEventArgs e)
        {
            //C01381523
            if (imagenesCliente.Count == 1)
            {
                e.Cancel = false;
            }
            //C01631261
            else
            {
                if (guardado)
                {
                    e.Cancel = false;
                }
                else
                {
                    if (algunaImageneAceptada() || todasImagenesValidas())
                    {
                        if (DialogResult.Yes ==
                            MessageBox.Show("¿desea salir de esta ventana?\nLos cambios no guardados se perderán",
                                "Confirmación", MessageBoxButtons.YesNo))
                            e.Cancel = false;
                        else
                            e.Cancel = true;
                    }
                    else
                    {
                        e.Cancel = false;
                    }
                }
            }
        }

        public bool algunaImageneAceptada()
        {
            bool imagenesAceptada = false;
            foreach (DataGridViewRow item in dgListadoImagenes.Rows)
            {
                appFusionModel registro = (appFusionModel)item.DataBoundItem;
                if (registro.bEstatusValidacion) imagenesAceptada = true;
            }

            return imagenesAceptada;
        }
    }
}