﻿using System;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_LoginBloqueoCargaPrecios : Form
    {
        private readonly DM0312__CLoginCancelacion controller = new DM0312__CLoginCancelacion();
        public string mensajeBloqueo = string.Empty;

        public DM0312_LoginBloqueoCargaPrecios(string MensajeBloqueo)
        {
            InitializeComponent();
            lblMensajeBloqueo.Text = MensajeBloqueo;
        }

        public string sUsuarioAutoriza { get; set; }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void Login()
        {
            DM0312_C_ExploradorVenta CExploradorVenta = new DM0312_C_ExploradorVenta();

            if (controller.LoginCancelacion(txtUsuario.Text, txtContrasena.Text))
            {
                if (CExploradorVenta.ValidarPerfilDesbloqueoCargaPrecios(txtUsuario.Text))
                {
                    DialogResult = DialogResult.OK;
                    sUsuarioAutoriza = txtUsuario.Text;
                    txtUsuario.Text = string.Empty;
                    txtContrasena.Text = string.Empty;
                    Close();
                }
                else
                {
                    MessageBox.Show("El usuario no tiene permisos.", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    txtUsuario.Text = string.Empty;
                    txtContrasena.Text = string.Empty;
                }
            }
            else
            {
                MessageBox.Show("Usuario y/o contraseña incorrecta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                txtContrasena.Text = string.Empty;
            }
        }
    }
}