﻿namespace PuntoVenta.View
{
    partial class DM0312_PuntoDeVentaCanalNuevo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_PuntoDeVentaCanalNuevo));
            this.lbl_NombreCanal = new System.Windows.Forms.Label();
            this.lbl_IdCanal = new System.Windows.Forms.Label();
            this.txt_NombreCanal = new System.Windows.Forms.TextBox();
            this.txt_Id = new System.Windows.Forms.TextBox();
            this.dgv_Canales = new System.Windows.Forms.DataGridView();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Canales)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_NombreCanal
            // 
            this.lbl_NombreCanal.AutoSize = true;
            this.lbl_NombreCanal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NombreCanal.Location = new System.Drawing.Point(94, 81);
            this.lbl_NombreCanal.Name = "lbl_NombreCanal";
            this.lbl_NombreCanal.Size = new System.Drawing.Size(54, 15);
            this.lbl_NombreCanal.TabIndex = 9;
            this.lbl_NombreCanal.Text = "Nombre:";
            // 
            // lbl_IdCanal
            // 
            this.lbl_IdCanal.AutoSize = true;
            this.lbl_IdCanal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_IdCanal.Location = new System.Drawing.Point(94, 48);
            this.lbl_IdCanal.Name = "lbl_IdCanal";
            this.lbl_IdCanal.Size = new System.Drawing.Size(21, 15);
            this.lbl_IdCanal.TabIndex = 8;
            this.lbl_IdCanal.Text = "Id:";
            // 
            // txt_NombreCanal
            // 
            this.txt_NombreCanal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NombreCanal.Location = new System.Drawing.Point(154, 74);
            this.txt_NombreCanal.Name = "txt_NombreCanal";
            this.txt_NombreCanal.ReadOnly = true;
            this.txt_NombreCanal.Size = new System.Drawing.Size(234, 20);
            this.txt_NombreCanal.TabIndex = 7;
            // 
            // txt_Id
            // 
            this.txt_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Id.Location = new System.Drawing.Point(154, 45);
            this.txt_Id.Name = "txt_Id";
            this.txt_Id.ReadOnly = true;
            this.txt_Id.Size = new System.Drawing.Size(42, 20);
            this.txt_Id.TabIndex = 6;
            // 
            // dgv_Canales
            // 
            this.dgv_Canales.AllowUserToAddRows = false;
            this.dgv_Canales.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Canales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Canales.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgv_Canales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Canales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_Canales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Canales.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_Canales.EnableHeadersVisualStyles = false;
            this.dgv_Canales.Location = new System.Drawing.Point(78, 105);
            this.dgv_Canales.Name = "dgv_Canales";
            this.dgv_Canales.ReadOnly = true;
            this.dgv_Canales.RowHeadersVisible = false;
            this.dgv_Canales.Size = new System.Drawing.Size(407, 183);
            this.dgv_Canales.TabIndex = 5;
            this.dgv_Canales.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Canales_CellClick);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnCancelar.FlatAppearance.BorderSize = 0;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancelar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.Location = new System.Drawing.Point(0, 103);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(62, 74);
            this.BtnCancelar.TabIndex = 12;
            this.BtnCancelar.Text = "Cerrar (Esc)";
            this.BtnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("btnAceptar.Image")));
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAceptar.Location = new System.Drawing.Point(0, 33);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(62, 64);
            this.btnAceptar.TabIndex = 11;
            this.btnAceptar.Text = "Agregar";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(78, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(407, 33);
            this.txt_Comentarios.TabIndex = 106;
            // 
            // DM0312_PuntoDeVentaCanalNuevo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(497, 295);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.lbl_NombreCanal);
            this.Controls.Add(this.lbl_IdCanal);
            this.Controls.Add(this.txt_NombreCanal);
            this.Controls.Add(this.txt_Id);
            this.Controls.Add(this.dgv_Canales);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_PuntoDeVentaCanalNuevo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nuevo Canal";
            this.Load += new System.EventHandler(this.DM0312_PuntoDeVentaCanalNuevo_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_PuntoDeVentaCanalNuevo_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Canales)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_NombreCanal;
        private System.Windows.Forms.Label lbl_IdCanal;
        private System.Windows.Forms.TextBox txt_NombreCanal;
        private System.Windows.Forms.TextBox txt_Id;
        private System.Windows.Forms.DataGridView dgv_Canales;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TextBox txt_Comentarios;

    }
}