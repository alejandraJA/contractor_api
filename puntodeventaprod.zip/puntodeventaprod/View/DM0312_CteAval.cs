﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_CteAval : Form
    {
        private readonly DM0312_C_Prospecto_A_Cliente cnn;

        public string codcliente = string.Empty;
        public List<DM0312_MCte> Lista = new List<DM0312_MCte>();

        private DM0312_MCte model = new DM0312_MCte();

        public DM0312_CteAval()
        {
            InitializeComponent();
            cnn = new DM0312_C_Prospecto_A_Cliente();
        }

        ~DM0312_CteAval()
        {
            GC.Collect();
        }

        private void DM0312_CteAval_Load(object sender, EventArgs e)
        {
            Lista = cnn.GetAvales(codcliente);

            DM0312_MCte cte = new DM0312_MCte();

            cte = Lista.Where(x => x.Cliente == "No hay Coincidencias").FirstOrDefault();

            if (cte == null)
            {
                dgv_Avales.DataSource = null;
                dgv_Avales.DataSource = Lista;
            }
            else
            {
                dgv_Avales.Enabled = false;
                BtnAceptar.Enabled = false;
            }

            ToolTip ToolBtnAsignarAval = new ToolTip();
            ToolBtnAsignarAval.SetToolTip(BtnAsignarAval, "Asignar Aval");

            ToolTip ToolAceptar = new ToolTip();
            ToolAceptar.SetToolTip(BtnAceptar, "Aceptar");

            ToolTip ToolCancelar = new ToolTip();
            ToolCancelar.SetToolTip(btnCancelar, "Cancelar");
        }

        private void BtnAsignarAval_Click(object sender, EventArgs e)
        {
            GenerarAvalSinGrid();
            Close();
        }

        private void dgv_Avales_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            model = (DM0312_MCte)dgv_Avales.SelectedRows[0].DataBoundItem;
        }

        private void dgv_Avales_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Funciones funciones = new Funciones();

            List<object> TempObjects = new List<object>(Lista);
            funciones.OrderGridview(dgv_Avales, e.ColumnIndex, ref TempObjects,
                Lista.GetType().GetGenericArguments().Single());
        }

        #region Eventos

        private async void BtnAceptar_Click(object sender, EventArgs e)
        {
            await Task.Run(() => GenerarCuentaAval());
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DM0312_CteAval_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (!flag)
            //{
            //    e.Cancel = true;
            //    MessageBox.Show("Tiene que guardar la información", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        #endregion

        #region Metodos

        private void GenerarCuentaAval()
        {
            model = (DM0312_MCte)dgv_Avales.SelectedRows[0].DataBoundItem;

            string res_inser = cnn.InsertaAvalCliente(codcliente, model.Cliente, "Informacion");

            MessageBox.Show(res_inser, "Infomación", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (res_inser.Contains("Validado Proceso"))
            {
                string res_insert = cnn.InsertaAvalCliente(codcliente, model.Cliente, "Inserta");
                MessageBox.Show(res_insert, "Infomación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void GenerarAvalSinGrid()
        {
            string res = cnn.GeneracionCuentaAval(codcliente, "NoInserta");

            MessageBox.Show(res, "Infomación", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (res.Contains("El Aval ya es cliente.."))
            {
                BtnAceptar.Enabled = true;
                return;
            }

            string res_ = cnn.GeneracionCuentaAval(codcliente, "Inserta");
            MessageBox.Show(res_, "Infomación", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void sleep()
        {
            Thread.Sleep(5000);
        }

        #endregion
    }
}