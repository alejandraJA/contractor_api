﻿using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class ClientesRedDIMA : Form
    {
        public bool CerrarVentana = false;
        private readonly DM0312_CPuntoDeVenta controller = new DM0312_CPuntoDeVenta();
        public string cuentaR = "";
        private DM0312_Loading_ frmLoading = new DM0312_Loading_();

        public ClientesRedDIMA()
        {
            InitializeComponent();
        }

        ~ClientesRedDIMA()
        {
            GC.Collect();
        }

        private void ClientesRedDIMA_Load(object sender, EventArgs e)
        {
            ClientesRed();
        }

        public async void ClientesRed()
        {
            frmLoading = new DM0312_Loading_();
            frmLoading.Show(this);
            DataTable dataSet = new DataTable();
            dataSet = await Task.Run(() => controller.ClienteRed());
            frmLoading.Hide();
            dgv_Cuentas.DataSource = null;
            dgv_Cuentas.DataSource = dataSet;
        }

        private void dgv_Cuentas_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int indice = -1;
            indice = e.RowIndex;
            if (indice >= 0)
            {
                cuentaR = dgv_Cuentas.Rows[e.RowIndex].Cells["CLIENTE"].FormattedValue.ToString();
                Close();
            }
        }

        private void txt_Cuenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
        }

        private void txt_Cuenta_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_Cuenta.Text))
                (dgv_Cuentas.DataSource as DataTable).DefaultView.RowFilter = string.Empty;
            else
                (dgv_Cuentas.DataSource as DataTable).DefaultView.RowFilter =
                    string.Format("CLIENTE LIKE '{0}%'", txt_Cuenta.Text);
        }

        private void txt_nombre_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_nombre.Text))
                (dgv_Cuentas.DataSource as DataTable).DefaultView.RowFilter = string.Empty;
            else
                (dgv_Cuentas.DataSource as DataTable).DefaultView.RowFilter =
                    string.Format("NOMBRE LIKE '{0}%'", txt_nombre.Text);
        }
    }
}