﻿using System;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class EscanearArticuloPequeno : Form
    {
        private readonly DM0312_CPuntoDeVenta CPuntoDeVenta = new DM0312_CPuntoDeVenta();
        internal string sArticulo;

        public EscanearArticuloPequeno(string Articulo)
        {
            InitializeComponent();
            Text = "Escanear artículo: " + Articulo;
            sArticulo = Articulo;
        }

        private void btnValidarGerente_Click(object sender, EventArgs e)
        {
            ValidarGerente();
        }

        private void txtArticulo_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarArticulo(e.KeyChar);
        }

        private void ValidarArticulo(char Caracter)
        {
            if (Caracter == Convert.ToChar(Keys.Enter))
            {
                if (txtArticulo.Text == CPuntoDeVenta.buscarArticuloCB(sArticulo, 2))
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Número de serie no corresponde con el artículo", "Mensaje", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }

                txtArticulo.Text = string.Empty;
            }
        }

        private void ValidarGerente()
        {
            LoginAutorizacion loginAutorizacion = new LoginAutorizacion();
            loginAutorizacion.ShowDialog();

            if (loginAutorizacion.DialogResult == DialogResult.OK)
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}