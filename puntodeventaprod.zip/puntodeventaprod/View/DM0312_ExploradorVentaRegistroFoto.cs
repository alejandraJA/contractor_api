﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class DM0312_ExploradorVentaRegistroFoto : Form
    {
        public Image Imagen;

        public DM0312_ExploradorVentaRegistroFoto()
        {
            InitializeComponent();
        }

        ~DM0312_ExploradorVentaRegistroFoto()
        {
            GC.Collect();
        }

        private void DM0312_ExploradorVentaRegistroFoto_Load(object sender, EventArgs e)
        {
            pb_FotoExpandida.Image = Imagen;
            Height = 480;
            Width = 720;
            StartPosition = FormStartPosition.CenterScreen;
        }
    }
}