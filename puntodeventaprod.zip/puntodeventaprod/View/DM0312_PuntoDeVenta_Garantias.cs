﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using Conversiones;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_PuntoDeVenta_Garantias : Form
    {
        public string Articulo;


        public int Cantidad;
        public int CantidadPaquetes;

        private readonly Conv conversion = new Conv();

        public bool flag;
        public bool flagPaquetes;
        public DM0312_MVentaDetalle garantias = new DM0312_MVentaDetalle();

        public DM0312_PuntoDeVenta_Garantias()
        {
            InitializeComponent();
            flag = false;
        }

        ~DM0312_PuntoDeVenta_Garantias()
        {
            GC.Collect();
        }

        private void DM0312_PuntoDeVenta_Garantias_Load(object sender, EventArgs e)
        {
            lblArticulo.Text = garantias.Articulo_Ligado;
            if (flagPaquetes)
            {
                txtCantArt.Text = Convert.ToString(CantidadPaquetes);
                txtCantGaran.Text = Convert.ToString(CantidadPaquetes);
                txtCantArt.Enabled = false;
                //txtCantGaran.Enabled = false;
            }

            llenarText();
            txtTotal.Text =
                (1 * garantias.Precio).ToString("C",
                    Thread.CurrentThread.CurrentCulture); //"$" + (1 * garantias.Precio).ToString();
        }

        #region Metodos

        //llenar txtinfo
        private void llenarText()
        {
            txtPrecio.Text =
                garantias.Precio.ToString("C",
                    Thread.CurrentThread.CurrentCulture); //"$" + garantias.Precio.ToString();
        }

        private void actualizaMov(string cambio)
        {
            double cantidad = Convert.ToDouble(cambio);

            //saca valor del Iva
            double iva = garantias.impuesto / 100 + 1;

            double subtotalParcial = cantidad * (garantias.Precio / iva);

            double value = Math.Truncate(100 * subtotalParcial) / 100;

            garantias.SubTotal = Convert.ToDouble(value);

            garantias.Total = cantidad * garantias.Precio;

            garantias.TotalS =
                (cantidad * garantias.Precio).ToString("C",
                    Thread.CurrentThread.CurrentCulture); //"$" + cantidad * garantias.Precio;

            garantias.impuesto2 = garantias.Cantidad;
        }

        #endregion

        #region Eventos

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (txtCantArt.Text == string.Empty || txtCantGaran.Text == string.Empty)
            {
                MessageBox.Show("Error debe llenar los campos", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (txtCantGaran.Text == "0")
            {
                MessageBox.Show("Si no requiere garantia de al boton de cancelar ", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            //txtTotal.Text = conversion.ConvertFormatMoney(txtTotal.Text).ToString() ;//txtTotal.Text.Replace("$", "");

            flag = true;
            garantias.Cantidad = Convert.ToInt32(txtCantGaran.Text);
            garantias.Total = conversion.ConvertFormatMoney(txtTotal.Text); //Convert.ToDouble(txtTotal.Text);
            Cantidad = Convert.ToInt32(txtCantArt.Text);

            actualizaMov(garantias.Cantidad.ToString());

            Close();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            errorProvider_.SetError(txtCantArt, string.Empty);
            errorProvider_.SetError(txtCantGaran, string.Empty);

            flag = false;
            Close();
        }

        //Solo Numeros es Texto Cantidad
        private void txtCantArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //Solo Numeros es Texto Garantias
        private void txtCantGaran_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //valida garantias
        private void txtCantGaran_TextChanged(object sender, EventArgs e)
        {
            if (txtCantArt.Text.Length == 0 || txtCantGaran.Text.Length == 0)
                return;

            int CantidadArt = Convert.ToInt32(txtCantArt.Text);

            int CantGaran = Convert.ToInt32(txtCantGaran.Text);

            if (CantGaran > CantidadArt)
            {
                MessageBox.Show("La cantidad de garantias excede la cantidad de articulos", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                txtCantGaran.Text = "1";

                txtCantGaran.SelectionStart = 1;

                txtCantGaran.SelectionLength = txtCantGaran.Text.Length;

                //txtTotal.Text = "$0.00";

                return;
            }

            if (CantGaran == 0)
            {
                MessageBox.Show("Si no requiere garantia de al boton de cancelar", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtCantGaran.Text = "1";

                txtCantGaran.SelectionStart = 1;

                txtCantGaran.SelectionLength = txtCantGaran.Text.Length;
                return;
            }

            double value = CantGaran * garantias.Precio;

            if (value == 0)
                txtTotal.Text = "$0.00";
            else
                txtTotal.Text = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + (value).ToString();
        }

        //validando cantidad de articulos
        private void txtCantArt_Validating(object sender, CancelEventArgs e)
        {
            if (txtCantArt.Text == string.Empty)
            {
                errorProvider_.SetError(txtCantArt, "El valor tiene que ser mayor a 0");
                return;
            }

            int Articulo = 0;

            Articulo = Convert.ToInt32(txtCantArt.Text);

            if (Articulo == 0)
            {
                errorProvider_.SetError(txtCantArt, "El valor tiene que ser mayor a 0");
                e.Cancel = true;
            }
            else
            {
                errorProvider_.SetError(txtCantArt, string.Empty);
            }
        }

        //validando cantidad de garantias
        private void txtCantGaran_Validating(object sender, CancelEventArgs e)
        {
            //if (txtCantGaran.Text == string.Empty)
            //{
            //    errorProvider_.SetError(txtCantGaran, "El valor tiene que ser mayor a 0");
            //    return;
            //}

            //int Articulo = 0;

            //Articulo = Convert.ToInt32(txtCantGaran.Text);

            //if (Articulo == 0)
            //{
            //    errorProvider_.SetError(txtCantGaran, "El valor tiene que ser mayor a 0");
            //    e.Cancel = true;
            //}
            //else
            //{
            //    errorProvider_.SetError(txtCantGaran, string.Empty);
            //}
        }

        #endregion
    }
}