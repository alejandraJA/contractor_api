﻿namespace PuntoVenta
{
    partial class CancelarEcommerce
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CancelarEcommerce));
            this.btnAceptar = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.txt_Otro = new System.Windows.Forms.TextBox();
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.cb_opciones = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnAceptar
            // 
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("btnAceptar.Image")));
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAceptar.Location = new System.Drawing.Point(226, 213);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(358, 5, 3, 10);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 76);
            this.btnAceptar.TabIndex = 5;
            this.btnAceptar.Text = "Aceptar (Crtl-G)";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(4, 1);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(310, 43);
            this.txt_Comentarios.TabIndex = 108;
            this.txt_Comentarios.Text = "AGREGAR EL MOTIVO DE CANCELACION PARA PEDIDOS DE SUCURSAL 41 y 90";
            // 
            // txt_Otro
            // 
            this.txt_Otro.Location = new System.Drawing.Point(27, 157);
            this.txt_Otro.MaxLength = 150;
            this.txt_Otro.Multiline = true;
            this.txt_Otro.Name = "txt_Otro";
            this.txt_Otro.Size = new System.Drawing.Size(274, 48);
            this.txt_Otro.TabIndex = 109;
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar.Location = new System.Drawing.Point(24, 92);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(203, 15);
            this.lbl_Buscar.TabIndex = 113;
            this.lbl_Buscar.Text = "Seleccione un motivo de cancelacion";
            // 
            // cb_opciones
            // 
            this.cb_opciones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_opciones.FormattingEnabled = true;
            this.cb_opciones.Location = new System.Drawing.Point(27, 110);
            this.cb_opciones.Name = "cb_opciones";
            this.cb_opciones.Size = new System.Drawing.Size(274, 21);
            this.cb_opciones.TabIndex = 112;
            this.cb_opciones.SelectedIndexChanged += new System.EventHandler(this.cb_opciones_SelectedIndexChanged);
            // 
            // CancelarEcommerce
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(313, 293);
            this.ControlBox = false;
            this.Controls.Add(this.lbl_Buscar);
            this.Controls.Add(this.cb_opciones);
            this.Controls.Add(this.txt_Otro);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.btnAceptar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "CancelarEcommerce";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Motivo de cancelacion";
            this.Load += new System.EventHandler(this.CancelarEcommerce_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CancelarEcommerce_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.TextBox txt_Otro;
        private System.Windows.Forms.Label lbl_Buscar;
        private System.Windows.Forms.ComboBox cb_opciones;
    }
}