﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class frmArticulosPromocion : Form
    {
        public static List<clsModeloArtPromocion> lModeloPromocion = new List<clsModeloArtPromocion>();
        public static List<clsModeloArtPromocion> lModeloPromocionFiltrados = new List<clsModeloArtPromocion>();
        public static List<clsModeloPromocionDetalle> lsConfiguracion = new List<clsModeloPromocionDetalle>();
        public static List<string> lsFamilias = new List<string>();
        public static List<modeloLinea> lsLinea = new List<modeloLinea>();
        public static List<string> lsCampanas = new List<string>();
        public static int iCantidadPermitida = 0;
        public static int iCantidadPermitidaTipoDos = 0;
        public static List<DM0312_MVentaDetalle> ListVentaDetalle = new List<DM0312_MVentaDetalle>();
        public static List<clsModeloTipoPromocion> listadoArticulos = new List<clsModeloTipoPromocion>();

        public static string sArticuloP;
        public new static DialogResult DialogResult;

        public static bool Disminuir;

        //public static List<clsModeloPromociones> ListVentaDetalle = new List<clsModeloPromociones>();
        private List<DM0312_MVentaDetalle> ArticulosIncluidos;
        public bool bBandera; //Se usa para validar la promocion en un articulo.

        private bool bBotonCerrar;
        private bool Cerrar;

        private readonly clsControladorPromociones clsControladorPromociones = new clsControladorPromociones();
        private readonly DM0312_CPuntoDeVenta cPv = new DM0312_CPuntoDeVenta();
        public int iCantP;

        public int iContadorCerrado = 0;
        private List<DM0312_MPuntoDeVentaAlmacen> listaAlmacenes = new List<DM0312_MPuntoDeVentaAlmacen>();

        public DM0312_MVentaDetalle regalo = new DM0312_MVentaDetalle();

        public frmArticulosPromocion(List<clsModeloTipoPromocion> listadoArticulosCtor, int iCantidad,
            List<DM0312_MVentaDetalle> ArticulosIncluidos)
        {
            InitializeComponent();
            this.ArticulosIncluidos = ArticulosIncluidos;
            Text = "Promoción Activa";
            listadoArticulos = listadoArticulosCtor;
            iCantP = iCantidad;
            DialogResult = DialogResult.None;
            LlenarDatos();
        }

        ~frmArticulosPromocion()
        {
            GC.Collect();
        }

        public void LlenarDatos(List<clsModeloArtPromocion> lModeloPromocionPar = null)
        {
            try
            {
                if (lModeloPromocionPar != null)
                {
                    dgvArtPromocion.DataSource = null;
                    dgvArtPromocion.DataSource = lModeloPromocionPar;
                }
                else
                {
                    dgvArtPromocion.DataSource = lModeloPromocion;
                }

                foreach (DataGridViewColumn dgvc in dgvArtPromocion.Columns) dgvc.ReadOnly = true;

                dgvArtPromocion.Columns[0].Visible = false;
                //1829 Mostrar descripción1 del artículo
                //dgvArtPromocion.Columns[8].Visible = false;
                dgvArtPromocion.Columns[9].Visible = false;
                dgvArtPromocion.Columns[10].Visible = false;
                dgvArtPromocion.Columns[11].Visible = false;
                dgvArtPromocion.Columns[12].Visible = false;
                dgvArtPromocion.Columns[13].Visible = false;
                dgvArtPromocion.Columns[14].Visible = false;
                dgvArtPromocion.Columns[15].Visible = false;
                dgvArtPromocion.Columns[16].Visible = false;
                dgvArtPromocion.Columns[17].Visible = false;

                dgvArtPromocion.Columns[5].DefaultCellStyle.Format = "c";
                dgvArtPromocion.Columns[5].DefaultCellStyle.FormatProvider = Thread.CurrentThread.CurrentCulture;
                dgvArtPromocion.Columns[7].ReadOnly = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }


        private void btnAceptar_Click(object sender, EventArgs e)
        {
            bool bBorro = false;
            foreach (clsModeloArtPromocion item in lModeloPromocion.Where(a => a.iCantidad > 0))
            {
                int vPromo = item.iIdPromocion;
                string vArticuloH = item.sArticulo;
                int vCantidad = item.iCantidad;
                int vPzaMax = item.iPiezasMaximas;
                string vDesc = item.dPorDec;
                double vPrecio = item.dPrecioFinal;
                string vNombreCampaña = item.sNombreCampaña;
                int vTipoPromocion = item.iTipoPromocion;
                int vMontoIncremental = item.iMontoIncremental;

                if (!bBorro) ListVentaDetalle.RemoveAll(x => x.idPromocion == vPromo);
                bBorro = true;
                string sComentario = string.Empty;

                if (ListVentaDetalle.Count >= 1)
                {
                    DM0312_MVentaDetalle a = ListVentaDetalle.FirstOrDefault(x => x.idPromocion == vPromo);
                    if (a == null)
                    {
                        MessageBox.Show("Solo puede agregar un tipo de promoción", "Punto De Venta",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                if (vPzaMax * iCantP < vCantidad)
                {
                    if (clsControladorPromociones.validarSiEsPorMontoMinimo(vPromo))
                    {
                        MessageBox.Show(
                            "El número máximo TOTAL de artículos para la campaña " + vNombreCampaña + " es " +
                            (iCantidadPermitida == 0 ? vPzaMax : iCantidadPermitida), "Alerta", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        ListVentaDetalle.Clear();
                        return;
                    }

                    MessageBox.Show(
                        "El número máximo TOTAL de Artículos hijo para la campaña " + vNombreCampaña + " es " +
                        (iCantidadPermitida == 0 ? vPzaMax : iCantidadPermitida) + " por Artículo Padre", "Alerta",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ListVentaDetalle.Clear();
                    return;
                }

                int totalarts = lModeloPromocion.Where(x => x.iIdPromocion == vPromo).Select(a => a.iCantidad)
                    .Aggregate((a, b) => a + b);
                List<clsModeloPromocion> lsModeloPromocion = clsControladorPromociones.ObtenerPromocion(vPromo);
                int cantidadAValidar = iCantidadPermitida == 0
                    ? lsModeloPromocion[0].ArticulosPermitidos * iCantP
                    : iCantidadPermitida;


                if (vTipoPromocion == 1 || vTipoPromocion == 3)
                    cantidadAValidar = lsModeloPromocion[0].ArticulosPermitidos;
                if (vTipoPromocion == 2 || vTipoPromocion == 4) cantidadAValidar = iCantidadPermitidaTipoDos;
                if (vTipoPromocion == 5) cantidadAValidar = vPzaMax;

                if (cantidadAValidar < totalarts)
                {
                    MessageBox.Show(
                        "El número máximo TOTAL de artículos hijo para la campaña " + lsModeloPromocion[0].sNombre +
                        " es " + (cantidadAValidar == 0 ? lsModeloPromocion[0].ArticulosPermitidos : cantidadAValidar) +
                        " por artículo padre.", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ListVentaDetalle.Clear();
                    return;
                }

                if (clsControladorPromociones.validarSiEsPorMontoMinimo(vPromo) && vCantidad > vPzaMax)
                {
                    MessageBox.Show(
                        $"El número máximo TOTAL de artículos para la campaña {lsModeloPromocion[0].sNombre} es {lsModeloPromocion[0].ArticulosPermitidos}.",
                        "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ListVentaDetalle.Clear();
                    return;
                }

                if (vDesc == "0%")
                    sComentario = "$" + vPrecio + " Precio fijo por campaña";
                else
                    sComentario = vDesc + " Descuento X Campaña";
                regalo = new DM0312_MVentaDetalle();
                //regalo.Articulo_Ligado = listadoArticulos.FirstOrDefault(x => x.iTipoPromocion == vPromo).sArticulo;
                regalo.listaPadres = listadoArticulos;
                regalo.Articulo = vArticuloH;
                regalo.Cantidad = vCantidad;
                regalo.Precio = vPrecio;
                regalo.PrecioS = vPrecio.ToString("C", Thread.CurrentThread.CurrentCulture);
                regalo.bArtPromocion = true;
                regalo.idPromocion = vPromo;
                regalo.Observaciones = sComentario;
                regalo.iIdTipoPromocion = vTipoPromocion;
                ListVentaDetalle.Add(regalo);
                int vTotalArt = ListVentaDetalle.Sum(x => x.Cantidad);

                if (vTotalArt > vPzaMax * iCantP)
                    bBandera = true;
            }

            LlenarDatos();
            cbCampanas.SelectedIndex = 0;
            cbFamilia.SelectedIndex = 0;
            cbLinea.SelectedIndex = 0;
            txtBuscar.Text = string.Empty;

            //cambiar la Cells[4] por Cells[2]
            List<DataGridViewRow> articulos = dgvArtPromocion.Rows.Cast<DataGridViewRow>()
                .Where(r => r.Cells[3].Value.ToString().Replace("$", "") == "0.01").ToList();
            bool agregados = articulos.Count > 0
                ? articulos.Select(r => int.Parse(r.Cells[5].Value.ToString()) > 0).Aggregate((a, b) => a || b)
                : false;

            Cerrar = agregados;
            bBotonCerrar = true;
            Close();
            Cerrar = false;
        }


        private bool Obligar()
        {
            //Validación Criterio 3
            List<DataGridViewRow> articulos = dgvArtPromocion.Rows.Cast<DataGridViewRow>()
                .Where(r => r.Cells[3].Value.ToString() == "0.01").ToList();
            bool obligar = articulos.Count > 0
                ? articulos.Select(r =>
                {
                    int cantidad = clsControladorPromociones.ExistenciaSucursal(r.Cells[1].Value.ToString(),
                        ClaseEstatica.Usuario.sucursal);
                    return cantidad > 0;
                }).Aggregate((a, b) => a || b)
                : false;

            if (obligar && !Cerrar)
                MessageBox.Show("Es obligatorio capturar un artículo de regalo", "Artículo de regalo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            return obligar;
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {
        }

        #region Handlers

        private void frmArticulosPromocion_Load(object sender, EventArgs e)
        {
            try
            {
                //Obtener almacenes
                listaAlmacenes = cPv.LlenaAlmacen().Where(x => x.Almacen != "V00097").ToList();
                if (listaAlmacenes.Count > 0)
                {
                    cbAlmacen.DataSource = listaAlmacenes;
                    cbAlmacen.ValueMember = "Almacen";
                    cbAlmacen.DisplayMember = "Almacen";
                }

                cbFamilia.DataSource = lsFamilias;

                cbLinea.DataSource = lsLinea;
                cbLinea.ValueMember = "sLinea";
                cbLinea.DisplayMember = "sLinea";

                cbCampanas.DataSource = lsCampanas;

                cbAlmacen.Text = cPv.LlenaAlmacen(ClaseEstatica.Usuario.sucursal);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Boton encargado de filtrar la informacion
        /// </summary>
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            List<string> lsArticulos = new List<string>();
            string sFamilia = cbFamilia.SelectedValue.ToString();
            string sLinea = cbLinea.SelectedValue.ToString();
            string sCampana = cbCampanas.SelectedValue.ToString();

            bool bFamilia = false;
            bool bFamiliaLinea = false;
            bool bFamiliLineaCampana = false;
            bool bFamiliaCampana = false;
            bool bCamapna = false;
            bool bGeneral = false;
            bool bTextoYCampana = false;
            bool bTexto = false;

            List<string> lsArticulosFiltro = new List<string>();
            try
            {
                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    //Busqueda por familia
                    if (!string.IsNullOrEmpty(sFamilia) && string.IsNullOrEmpty(sLinea) &&
                        string.IsNullOrEmpty(sCampana))
                    {
                        List<clsModeloArtPromocion> listaArts =
                            lModeloPromocion.Where(x => x.sFamilia == sFamilia).ToList();
                        if (listaArts.Count > 0)
                            foreach (clsModeloArtPromocion item in listaArts)
                                lsArticulosFiltro.Add(item.sArticulo);
                        bFamilia = true;
                    }

                    //Busqueda por familia-linea
                    if (!string.IsNullOrEmpty(sFamilia) && !string.IsNullOrEmpty(sLinea) &&
                        string.IsNullOrEmpty(sCampana))
                    {
                        List<clsModeloArtPromocion> listaArts = lModeloPromocion
                            .Where(x => x.sFamilia == sFamilia && x.sLinea == sLinea).ToList();
                        if (listaArts.Count > 0)
                            foreach (clsModeloArtPromocion item in listaArts)
                                lsArticulosFiltro.Add(item.sArticulo);
                        bFamiliaLinea = true;
                    }

                    //Busqueda por familia-linea-campaña
                    if (!string.IsNullOrEmpty(sFamilia) && !string.IsNullOrEmpty(sLinea) &&
                        !string.IsNullOrEmpty(sCampana))
                    {
                        List<clsModeloArtPromocion> listaArts = lModeloPromocion.Where(x =>
                            x.sFamilia == sFamilia && x.sLinea == sLinea && x.sNombreCampaña == sCampana).ToList();
                        if (listaArts.Count > 0)
                            foreach (clsModeloArtPromocion item in listaArts)
                                lsArticulosFiltro.Add(item.sArticulo);
                        bFamiliLineaCampana = true;
                    }

                    //Busqueda por familia-campaña
                    if (!string.IsNullOrEmpty(sFamilia) && string.IsNullOrEmpty(sLinea) &&
                        !string.IsNullOrEmpty(sCampana))
                    {
                        List<clsModeloArtPromocion> listaArts = lModeloPromocion
                            .Where(x => x.sFamilia == sFamilia && x.sNombreCampaña == sCampana).ToList();
                        if (listaArts.Count > 0)
                            foreach (clsModeloArtPromocion item in listaArts)
                                lsArticulosFiltro.Add(item.sArticulo);

                        bFamiliaCampana = true;
                    }

                    //Busqueda por campaña
                    if (string.IsNullOrEmpty(sFamilia) && string.IsNullOrEmpty(sLinea) &&
                        !string.IsNullOrEmpty(sCampana))
                    {
                        List<clsModeloArtPromocion> listaArts =
                            lModeloPromocion.Where(x => x.sNombreCampaña == sCampana).ToList();
                        if (listaArts.Count > 0)
                            foreach (clsModeloArtPromocion item in listaArts)
                                lsArticulosFiltro.Add(item.sArticulo);
                        bCamapna = true;
                    }

                    //BusQuedaGeneral
                    if (string.IsNullOrEmpty(sFamilia) && string.IsNullOrEmpty(sLinea) &&
                        string.IsNullOrEmpty(sCampana))
                    {
                        foreach (clsModeloArtPromocion item in lModeloPromocion) lsArticulosFiltro.Add(item.sArticulo);
                        bGeneral = true;
                    }
                }
                else
                {
                    //-Busqueda por texto
                    if (!string.IsNullOrEmpty(cbCampanas.Text))
                    {
                        List<clsModeloArtPromocion> listaArts = lModeloPromocion.Where(x =>
                            x.sArticulo.Contains(txtBuscar.Text.ToUpper()) && x.sNombreCampaña == sCampana).ToList();
                        foreach (clsModeloArtPromocion item in listaArts) lsArticulosFiltro.Add(item.sArticulo);
                        bTextoYCampana = true;
                    }
                    else
                    {
                        List<clsModeloArtPromocion> listaArts = lModeloPromocion
                            .Where(x => x.sArticulo.Contains(txtBuscar.Text.ToUpper())).ToList();
                        foreach (clsModeloArtPromocion item in listaArts) lsArticulosFiltro.Add(item.sArticulo);
                        bTexto = true;
                    }
                }

                XElement xmlElements =
                    new XElement("Articulos", lsArticulosFiltro.Select(i => new XElement("Articulo", i)));

                //lsArticulosFiltro = clsControladorPromociones.eliminarSinAlmacen(xmlElements.ToString(), cbAlmacen.SelectedValue.ToString());

                //buscamos los articulos filtrados
                if (lsArticulosFiltro.Count > 0)
                {
                    lModeloPromocionFiltrados = new List<clsModeloArtPromocion>();

                    if (bFamilia)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar =
                                lModeloPromocion.FirstOrDefault(x =>
                                    x.sArticulo == item.Trim() && x.sFamilia == sFamilia);
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bFamiliaLinea)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar = lModeloPromocion.FirstOrDefault(x =>
                                x.sArticulo == item.Trim() && x.sFamilia == sFamilia && x.sLinea == sLinea);
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bFamiliLineaCampana)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar = lModeloPromocion.FirstOrDefault(x =>
                                x.sArticulo == item.Trim() && x.sFamilia == sFamilia && x.sLinea == sLinea &&
                                x.sNombreCampaña == sCampana);
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bFamiliaCampana)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar = lModeloPromocion.FirstOrDefault(x =>
                                x.sArticulo == item.Trim() && x.sFamilia == sFamilia && x.sNombreCampaña == sCampana);
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bCamapna)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar = lModeloPromocion.FirstOrDefault(x =>
                                x.sArticulo == item.Trim() && x.sNombreCampaña == sCampana);
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bGeneral)
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar =
                                lModeloPromocion.FirstOrDefault(x => x.sArticulo == item.Trim());
                            if (artABuscar != null) lModeloPromocionFiltrados.Add(artABuscar);
                        }

                    if (bTextoYCampana)
                    {
                        List<clsModeloArtPromocion> lista = lModeloPromocion.ToList();
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar = lista.FirstOrDefault(x =>
                                x.sArticulo.Contains(txtBuscar.Text.ToUpper()) && x.sNombreCampaña == cbCampanas.Text);
                            if (artABuscar != null)
                            {
                                lModeloPromocionFiltrados.Add(artABuscar);
                                lista.Remove(artABuscar);
                            }
                        }
                    }

                    if (bTexto)
                    {
                        List<clsModeloArtPromocion> lista = lModeloPromocion.ToList();
                        foreach (string item in lsArticulosFiltro)
                        {
                            clsModeloArtPromocion artABuscar =
                                lista.FirstOrDefault(x => x.sArticulo.Contains(txtBuscar.Text.ToUpper()));
                            if (artABuscar != null)
                            {
                                lModeloPromocionFiltrados.Add(artABuscar);
                                lista.Remove(artABuscar);
                            }
                        }
                    }

                    lModeloPromocionFiltrados = clsControladorPromociones.obtenerExistencias(lModeloPromocionFiltrados,
                        xmlElements.ToString(), cbAlmacen.SelectedValue.ToString());

                    LlenarDatos(lModeloPromocionFiltrados);
                }
                //else
                //{
                //    MessageBox.Show("No se encontraron articulos para el almacen " + cbAlmacen.SelectedValue.ToString(), "Modulo Promociones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    LlenarDatos(lModeloPromocionFiltrados = new List<clsModeloArtPromocion>());
                //}
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de cambiar las lineas en base a las familias
        /// </summary>
        private void cbFamilia_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                string sFamilia = cbFamilia.SelectedValue.ToString();

                if (!string.IsNullOrEmpty(sFamilia))
                {
                    List<modeloLinea> lsFiltrada =
                        lsLinea.Where(x => x.sFamilia == sFamilia).ToList();

                    lsFiltrada.Insert(0, new modeloLinea { sFamilia = "", sLinea = "" });

                    cbLinea.DataSource = lsFiltrada;
                    cbLinea.ValueMember = "sLinea";
                    cbLinea.DisplayMember = "sLinea";
                    cbLinea.Enabled = true;
                }
                else
                {
                    cbLinea.Enabled = false;
                    cbLinea.Text = "";
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        ///     metodo encargado de filtrar la informacion de la lista que esta en el grid
        /// </summary>
        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBuscar.Text))
            {
                cbFamilia.SelectedIndex = 0;
                cbFamilia.Enabled = false;

                cbLinea.SelectedIndex = 0;
                cbLinea.Enabled = false;
            }
            else
            {
                cbFamilia.SelectedIndex = 0;
                cbFamilia.Enabled = true;

                cbLinea.SelectedIndex = 0;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            if (!Obligar())
            {
                bBotonCerrar = true;
                Close();
            }
        }

        /// <summary>
        ///     Metodo que se ejecuta al cerrar el formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmArticulosPromocion_FormClosing(object sender, FormClosingEventArgs e)
        {
            switch (e.CloseReason)
            {
                case CloseReason.UserClosing:
                    if (!bBotonCerrar) e.Cancel = true;
                    break;
            }

            if (Obligar() && !Cerrar) e.Cancel = true;
            if (sender != this) btnCancelar_Click(btnCancelar, new EventArgs());
        }

        private void frmArticulosPromocion_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnBuscar_Click(null, null);
            if (e.Control && e.KeyCode == Keys.G) btnAceptar_Click(null, null);
            if (e.KeyCode == Keys.Escape) Close();
        }

        /// <summary>
        ///     Metodo que se ejecuta al editar una columna
        /// </summary>
        private void dgvArtPromocion_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= Columns_KeyPress;
            if (dgvArtPromocion.CurrentCell.ColumnIndex == 5) //Columnas deseadas
            {
                //if (dgvArtPromocion.CurrentCell[7].Value == 0)
                {
                    object articulo = dgvArtPromocion.CurrentRow.Cells[1].Value;
                    PuntoDeVenta.ListVentaDetalle.RemoveAll(x => x.Articulo == articulo);
                }


                TextBox tb = e.Control as TextBox;
                if (tb != null) tb.KeyPress += Columns_KeyPress;
            }
        }

        /// <summary>
        ///     Metodo encargado de validar solo numeros en las celdas (se usa para validar la celda de la cantidad)
        /// </summary>
        private void Columns_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        }

        /// <summary>
        ///     Metodo encargado de evaluar errores en el datagrid en el datagrid
        /// </summary>
        private void dgvArtPromocion_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 5)
                {
                    DataGridView dg = (DataGridView)sender;

                    clsModeloArtPromocion a = (clsModeloArtPromocion)dg.CurrentRow.DataBoundItem;

                    a.iCantidad = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion
    }
}