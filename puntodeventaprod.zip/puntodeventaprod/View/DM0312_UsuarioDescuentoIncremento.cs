﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Conversiones;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_UsuarioDescuentoIncremento : Form
    {
        private readonly DM0312_C_UsuarioDescuentoIncremento controller;

        private readonly Conv conversiones = new Conv();
        public DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();

        public string Mov;
        /*******************************/

        /*variables de retorno*/
        public bool Operacion;
        public double precioActualizado;
        public string PwdAuto;
        public string PwdNvoProp;

        public string UserAuto;

        /**variables de la forma*********/
        public string UserNvoProp;

        public bool usrDescIncreLinea = false;

        public DM0312_UsuarioDescuentoIncremento()
        {
            InitializeComponent();
            controller = new DM0312_C_UsuarioDescuentoIncremento();
        }

        public int IdVenta { get; set; }
        public int canal { get; set; }
        public string almacen { get; set; }
        public string agente { get; set; }
        public int UEN { get; set; }
        public string tipo { get; set; }
        public string TipoString { get; set; }

        ~DM0312_UsuarioDescuentoIncremento()
        {
            GC.Collect();
        }

        private void DM0312_UsuarioDescuentoIncremento_Load(object sender, EventArgs e)
        {
            //validate 
            if (!validateVenta())
            {
                MessageBox.Show("Este articulo no cumple las reglas para hacer " + TipoString, "Error!!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Close();
            }

            if (tipo == "UsrIncremento")
            {
                label1.Text = "Usuario:                  ";

                if (canal == 11)
                {
                    label1.Visible = false;
                    cmbNuevoPro.Visible = false;
                    label2.Visible = false;
                    txtPWD.Visible = false;
                    label4.Visible = false;
                    cmbAutoriza.Visible = false;
                }
                else
                {
                    label4.Visible = false;
                    cmbAutoriza.Visible = false;
                }
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            double Importe = 0;

            Importe = conversiones.ConvertFormatMoney(txtImport.Text); //txtImport.Text.Replace("$", "");

            if (txtImport.Text.Length == 0)
            {
                MessageBox.Show("Error debe capturar un importe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                return;
            }

            //usuario incremento
            if (tipo == "UsrIncremento")
            {
                if (canal != 11)
                {
                    if ((cmbNuevoPro.Text.Length == 0) | (txtPWD.Text.Length == 0))
                    {
                        MessageBox.Show("Error debe capturar usuario y contraseña", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        return;
                    }

                    //bool UserValidate = controller.GetUserValidate(cmbNuevoPro.Text, txtPWD.Text);

                    if (!controller.GetUserValidate(cmbNuevoPro.Text, txtPWD.Text))
                    {
                        MessageBox.Show("no se pudo validar el usuario", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Asterisk);
                        //var importe_ = Importe.ToString("C", Thread.CurrentThread.CurrentCulture);
                        txtImport.Text =
                            Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                        return;
                    }
                }

                //double importe = Convert.ToDouble(txtImport.Text);

                //bool validaInsertarVenta = controller.ValidaInsertaVenta(model.Articulo, IdVenta);

                if (!controller.ValidaInsertaVenta(model.Articulo, IdVenta, model.Renglon))
                {
                    if (controller.ValidaRenglonID(IdVenta, model.RenglonID, model.Renglon))
                    {
                        model.RenglonID = model.RenglonID + 1;
                        model.Renglon = 2048 * model.RenglonID;
                    }

                    //inserta datos en ventaD
                    //bool inserto = controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 1);

                    if (!controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 1))
                    {
                        MessageBox.Show("Ocurrio un error al insertar articulos", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Asterisk);
                        txtImport.Text =
                            Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                        return;
                    }
                }

                //bool Incremento = controller.exec_spPropreIncremento(IdVenta, model, Importe, cmbNuevoPro.Text);

                if (!controller.exec_spPropreIncremento(IdVenta, model, Importe, cmbNuevoPro.Text))
                {
                    if (usrDescIncreLinea == false)
                    {
                        controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 2);
                        return;
                    }

                    return;
                }

                if (canal != 11)
                {
                    //bool InsertaAutorizacion = controller.exec_SP_DM0313AutorizaIncremento(IdVenta, model, Mov);

                    if (!controller.exec_SP_DM0313AutorizaIncremento(IdVenta, model, Mov))
                    {
                        Operacion = false;
                        MessageBox.Show("La operacion se efectuo con errores", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        txtImport.Text =
                            Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                        return;
                    }

                    precioActualizado = Importe;
                    Operacion = true;
                    MessageBox.Show("La operacion se efectuo correctamente", "Exito", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    model.RenglonAnterior = model.Renglon;
                    model.TipoUsrDes_Incr = tipo;
                    Close();
                }
                else
                {
                    precioActualizado = Importe;
                    Operacion = true;
                    MessageBox.Show("La operacion se efectuo correctamente", "Exito", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                    model.RenglonAnterior = model.Renglon;
                    model.TipoUsrDes_Incr = tipo;
                    Close();
                }
            }

            //usuario descuento
            if (tipo == "UsrDescuento")
            {
                if ((cmbNuevoPro.Text.Length == 0) | (txtPWD.Text.Length == 0))
                {
                    MessageBox.Show("Error debe capturar usuario,contraseña y autorizacion ", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                    return;
                }

                //valida datos correctos
                if (!UsrAutPrecio())
                {
                    MessageBox.Show("Verificar todos los datos", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Asterisk);
                    txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                    return;
                }
                //bool validaInsertarVenta = controller.ValidaInsertaVenta(model.Articulo, IdVenta);

                if (!controller.ValidaInsertaVenta(model.Articulo, IdVenta, model.Renglon))
                {
                    if (controller.ValidaRenglonID(IdVenta, model.RenglonID, model.Renglon))
                    {
                        model.RenglonID = model.RenglonID + 1;
                        model.Renglon = 2048 * model.RenglonID;
                    }

                    //inserta datos en ventaD
                    // bool inserto = controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 1);

                    //si no inserto se retorna
                    if (!controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 1))
                    {
                        MessageBox.Show("Ocurrio un error al insertar articulos", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Asterisk);
                        txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture);
                        return;
                    }
                }
                //double importe = Convert.ToDouble(txtImport.Text);

                // bool AutorizaDesc = controller.exec_spPropreAutorizarDescuento(cmbNuevoPro.Text, txtPWD.Text, IdVenta, model, Importe);

                if (!controller.exec_spPropreAutorizarDescuento(cmbNuevoPro.Text, txtPWD.Text, IdVenta, model, Importe))
                {
                    MessageBox.Show("Ocurrio un error al autorizar descuento", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Asterisk);

                    if (usrDescIncreLinea == false) controller.InsertVentaD_(model, IdVenta, canal, almacen, agente, 2);

                    txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                    return;
                }

                //bool InsertaAutPrecio = controller.exec_SP_MAVIRM0850InsertaAutPrecioXUsr(IdVenta, cmbAutoriza.Text, cmbNuevoPro.Text, model);

                if (controller.exec_SP_MAVIRM0850InsertaAutPrecioXUsr(IdVenta, cmbAutoriza.Text, cmbNuevoPro.Text,
                        model))
                {
                    precioActualizado = Importe;
                    Operacion = true;
                    MessageBox.Show("La operacion se efectuo correctamente", "Exito", MessageBoxButtons.OK);
                    model.RenglonAnterior = model.Renglon;
                    model.TipoUsrDes_Incr = tipo;
                    Close();
                }
                else
                {
                    Operacion = false;
                    MessageBox.Show("La operacion se efectuo con errores", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    txtImport.Text = Importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
                }
            }
        }

        private void cmbNuevoPro_DropDown(object sender, EventArgs e)
        {
            DM0312_Forma_NvoProp_Autorizo forma = new DM0312_Forma_NvoProp_Autorizo();
            forma.Origen = true;
            forma.ShowDialog();
            if (forma.cancel_)
            {
                SendKeys.Send("{ENTER}");
                return;
            }

            UserNvoProp = forma.user;
            PwdNvoProp = forma.pwd;


            cmbNuevoPro.Text = string.Empty;
            cmbNuevoPro.Text = UserNvoProp;

            SendKeys.Send("{ENTER}");
        }

        private void cmbAutoriza_DropDown(object sender, EventArgs e)
        {
            DM0312_Forma_NvoProp_Autorizo forma = new DM0312_Forma_NvoProp_Autorizo();
            forma.Origen = false;
            forma.Width = 480;
            forma.ShowDialog();
            if (forma.cancel_)
            {
                SendKeys.Send("{ENTER}");
                return;
            }

            UserAuto = forma.user;

            cmbAutoriza.Text = string.Empty;
            cmbAutoriza.Text = UserAuto;

            SendKeys.Send("{ENTER}");
        }

        private void txtImport_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                double import = Convert.ToDouble(txtImport.Text);
            }
            catch (Exception ex)
            {
                if (ex.Message == "La cadena de entrada no tiene el formato correcto.")
                {
                    MessageBox.Show("el campo importe es de solo numeros decimales y enteros", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Cancel = true;
                    txtImport.Text = "$0.0";
                    txtImport.Select();
                }
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cmbNuevoPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = char.ToUpper(e.KeyChar);

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cmbNuevoPro.Select();
        }

        private void cmbAutoriza_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = char.ToUpper(e.KeyChar);

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) btnAceptar.Select();
        }

        private void txtImport_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtImport.Text.Contains("."))
            {
                if (e.KeyChar.ToString() == ".")
                {
                    e.Handled = true;
                    return;
                }
            }
            else
            {
                if ((e.KeyChar.ToString() == ".") & (txtImport.Text.Length == 0))
                {
                    e.Handled = true;
                    return;
                }
            }


            if (char.IsDigit(e.KeyChar) || e.KeyChar.ToString() == ".")
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txtImport_Enter(object sender, EventArgs e)
        {
            txtImport.Text =
                conversiones.ConvertFormatMoney(txtImport.Text).ToString(); //txtImport.Text.Replace("$", "");
            txtImport.Focus();
            txtImport.SelectAll();
        }

        private void txtImport_Leave(object sender, EventArgs e)
        {
            double import = 0;

            import = conversiones.ConvertFormatMoney(txtImport.Text);

            txtImport.Text = import.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + txtImport.Text;
        }

        private void txtImport_Click(object sender, EventArgs e)
        {
            txtImport.SelectionStart = 0;

            txtImport.SelectionLength = txtImport.Text.Length;
        }

        private void txtPWD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txtImport.Select();
        }

        #region Metodos

        private bool validateVenta()
        {
            string estatus;
            string origen;
            string origenID;
            string mov;
            string PagoTipo;

            bool res_ = false;

            string rest = string.Empty;
            PropertyInfo Reflection_;
            object res = controller.VentaValidate(IdVenta);

            //estatus
            Reflection_ = res.GetType().GetProperty("estatus");
            estatus = (string)Reflection_.GetValue(res, null);

            //origen
            Reflection_ = res.GetType().GetProperty("origen");
            origen = (string)Reflection_.GetValue(res, null);

            //origenID
            Reflection_ = res.GetType().GetProperty("origenID");
            origenID = (string)Reflection_.GetValue(res, null);

            //mov
            Reflection_ = res.GetType().GetProperty("mov");
            Mov = (string)Reflection_.GetValue(res, null);

            mov = Mov;

            //PagoTipo
            Reflection_ = res.GetType().GetProperty("PagoTipo");
            PagoTipo = (string)Reflection_.GetValue(res, null);

            string cadena = PagoTipo.ToUpper();

            if (((estatus == "SINAFECTAR") & (origen == string.Empty) & (origenID == string.Empty) &
                 ((mov == "Solicitud Credito") | (mov == "Solicitud Mayoreo") | (mov == "Pedido Mayoreo")))
                | ((mov == "Pedido") & (cadena == "CONTADO") & (estatus == "SINAFECTAR")))
                res_ = true;
            else
                res_ = false;


            if (tipo == "UsrIncremento")
            {
                int Incremento = controller.UsrAutIncremento();
                if (Incremento == 1)
                    res_ = false;
                else
                    res_ = true;
            }

            return res_;
        }

        private bool UsrAutPrecio()
        {
            //if (cmbAutoriza.Text == string.Empty)
            //{
            //    MessageBox.Show("El Usuario debe tener un tipo de descuento Especifico...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return false;
            //}

            int count = controller.UsrAutPrecio(cmbAutoriza.Text);

            if (count > 0 || cmbAutoriza.Text.Length == 0) return true;

            MessageBox.Show("El Usuario debe tener un tipo de descuento Especifico...", "Error", MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return false;
        }

        #endregion
    }
}