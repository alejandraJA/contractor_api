﻿namespace PuntoVenta.View
{
    partial class DM0312_ComentariosVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_ComentariosVenta));
            this.dgvComentarios = new System.Windows.Forms.DataGridView();
            this.cmbModulo = new System.Windows.Forms.ComboBox();
            this.lbl_Campo = new System.Windows.Forms.Label();
            this.txtCampo = new System.Windows.Forms.TextBox();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoRegistroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regresarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_Filtrar = new System.Windows.Forms.Label();
            this.pnl_Guardar = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ModuloGuardar = new System.Windows.Forms.TextBox();
            this.txt_ComentarioGuardar = new System.Windows.Forms.TextBox();
            this.txt_CampoGuardar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_ModuloGuardar = new System.Windows.Forms.ComboBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.guardarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.regresarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComentarios)).BeginInit();
            this.menu.SuspendLayout();
            this.pnl_Guardar.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvComentarios
            // 
            this.dgvComentarios.AllowUserToAddRows = false;
            this.dgvComentarios.AllowUserToDeleteRows = false;
            this.dgvComentarios.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvComentarios.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvComentarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvComentarios.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvComentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvComentarios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvComentarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvComentarios.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvComentarios.EnableHeadersVisualStyles = false;
            this.dgvComentarios.Location = new System.Drawing.Point(12, 136);
            this.dgvComentarios.Name = "dgvComentarios";
            this.dgvComentarios.RowHeadersVisible = false;
            this.dgvComentarios.Size = new System.Drawing.Size(524, 304);
            this.dgvComentarios.TabIndex = 0;
            this.dgvComentarios.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvComentarios_CellClick);
            this.dgvComentarios.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvComentarios_CellValueChanged);
            this.dgvComentarios.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvComentarios_ColumnHeaderMouseClick);
            // 
            // cmbModulo
            // 
            this.cmbModulo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbModulo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbModulo.FormattingEnabled = true;
            this.cmbModulo.Location = new System.Drawing.Point(12, 65);
            this.cmbModulo.Name = "cmbModulo";
            this.cmbModulo.Size = new System.Drawing.Size(133, 23);
            this.cmbModulo.TabIndex = 1;
            this.cmbModulo.SelectedIndexChanged += new System.EventHandler(this.cmbModulo_SelectedIndexChanged);
            // 
            // lbl_Campo
            // 
            this.lbl_Campo.AutoSize = true;
            this.lbl_Campo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Campo.Location = new System.Drawing.Point(163, 47);
            this.lbl_Campo.Name = "lbl_Campo";
            this.lbl_Campo.Size = new System.Drawing.Size(48, 15);
            this.lbl_Campo.TabIndex = 3;
            this.lbl_Campo.Text = "Campo:";
            // 
            // txtCampo
            // 
            this.txtCampo.Location = new System.Drawing.Point(166, 66);
            this.txtCampo.Name = "txtCampo";
            this.txtCampo.Size = new System.Drawing.Size(153, 20);
            this.txtCampo.TabIndex = 5;
            this.txtCampo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCampo_KeyPress);
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.SystemColors.Window;
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarToolStripMenuItem,
            this.nuevoRegistroToolStripMenuItem,
            this.regresarToolStripMenuItem1});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(691, 24);
            this.menu.TabIndex = 7;
            this.menu.Text = "menuStrip1";
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editarToolStripMenuItem.Image")));
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(131, 20);
            this.editarToolStripMenuItem.Text = "Guardar Cambios";
            this.editarToolStripMenuItem.Click += new System.EventHandler(this.editarToolStripMenuItem_Click);
            // 
            // nuevoRegistroToolStripMenuItem
            // 
            this.nuevoRegistroToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nuevoRegistroToolStripMenuItem.Name = "nuevoRegistroToolStripMenuItem";
            this.nuevoRegistroToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.nuevoRegistroToolStripMenuItem.Text = "Nuevo Registro";
            this.nuevoRegistroToolStripMenuItem.Click += new System.EventHandler(this.nuevoRegistroToolStripMenuItem_Click);
            // 
            // regresarToolStripMenuItem1
            // 
            this.regresarToolStripMenuItem1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regresarToolStripMenuItem1.Name = "regresarToolStripMenuItem1";
            this.regresarToolStripMenuItem1.Size = new System.Drawing.Size(71, 20);
            this.regresarToolStripMenuItem1.Text = "Regresar";
            this.regresarToolStripMenuItem1.Click += new System.EventHandler(this.regresarToolStripMenuItem1_Click);
            // 
            // lbl_Filtrar
            // 
            this.lbl_Filtrar.AutoSize = true;
            this.lbl_Filtrar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Filtrar.Location = new System.Drawing.Point(12, 44);
            this.lbl_Filtrar.Name = "lbl_Filtrar";
            this.lbl_Filtrar.Size = new System.Drawing.Size(89, 15);
            this.lbl_Filtrar.TabIndex = 9;
            this.lbl_Filtrar.Text = "Filtrar Forma :";
            // 
            // pnl_Guardar
            // 
            this.pnl_Guardar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Guardar.Controls.Add(this.label1);
            this.pnl_Guardar.Controls.Add(this.txt_ModuloGuardar);
            this.pnl_Guardar.Controls.Add(this.txt_ComentarioGuardar);
            this.pnl_Guardar.Controls.Add(this.txt_CampoGuardar);
            this.pnl_Guardar.Controls.Add(this.label2);
            this.pnl_Guardar.Controls.Add(this.label3);
            this.pnl_Guardar.Controls.Add(this.label4);
            this.pnl_Guardar.Controls.Add(this.cmb_ModuloGuardar);
            this.pnl_Guardar.Controls.Add(this.menuStrip2);
            this.pnl_Guardar.Location = new System.Drawing.Point(52, 115);
            this.pnl_Guardar.Name = "pnl_Guardar";
            this.pnl_Guardar.Size = new System.Drawing.Size(583, 269);
            this.pnl_Guardar.TabIndex = 10;
            this.pnl_Guardar.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 15);
            this.label1.TabIndex = 17;
            this.label1.Text = "Filtrar";
            // 
            // txt_ModuloGuardar
            // 
            this.txt_ModuloGuardar.Location = new System.Drawing.Point(185, 68);
            this.txt_ModuloGuardar.Name = "txt_ModuloGuardar";
            this.txt_ModuloGuardar.Size = new System.Drawing.Size(129, 20);
            this.txt_ModuloGuardar.TabIndex = 16;
            // 
            // txt_ComentarioGuardar
            // 
            this.txt_ComentarioGuardar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ComentarioGuardar.Location = new System.Drawing.Point(22, 159);
            this.txt_ComentarioGuardar.Multiline = true;
            this.txt_ComentarioGuardar.Name = "txt_ComentarioGuardar";
            this.txt_ComentarioGuardar.Size = new System.Drawing.Size(482, 83);
            this.txt_ComentarioGuardar.TabIndex = 15;
            // 
            // txt_CampoGuardar
            // 
            this.txt_CampoGuardar.Location = new System.Drawing.Point(360, 68);
            this.txt_CampoGuardar.Name = "txt_CampoGuardar";
            this.txt_CampoGuardar.Size = new System.Drawing.Size(144, 20);
            this.txt_CampoGuardar.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "Comentario:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(357, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Campo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(182, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Modulo:";
            // 
            // cmb_ModuloGuardar
            // 
            this.cmb_ModuloGuardar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ModuloGuardar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ModuloGuardar.FormattingEnabled = true;
            this.cmb_ModuloGuardar.Location = new System.Drawing.Point(18, 67);
            this.cmb_ModuloGuardar.Name = "cmb_ModuloGuardar";
            this.cmb_ModuloGuardar.Size = new System.Drawing.Size(124, 23);
            this.cmb_ModuloGuardar.TabIndex = 10;
            this.cmb_ModuloGuardar.SelectedIndexChanged += new System.EventHandler(this.cmb_ModuloGuardar_SelectedIndexChanged);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.guardarToolStripMenuItem1,
            this.regresarToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(581, 24);
            this.menuStrip2.TabIndex = 18;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // guardarToolStripMenuItem1
            // 
            this.guardarToolStripMenuItem1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guardarToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("guardarToolStripMenuItem1.Image")));
            this.guardarToolStripMenuItem1.Name = "guardarToolStripMenuItem1";
            this.guardarToolStripMenuItem1.Size = new System.Drawing.Size(81, 20);
            this.guardarToolStripMenuItem1.Text = "Guardar";
            this.guardarToolStripMenuItem1.Click += new System.EventHandler(this.guardarToolStripMenuItem1_Click);
            // 
            // regresarToolStripMenuItem
            // 
            this.regresarToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regresarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("regresarToolStripMenuItem.Image")));
            this.regresarToolStripMenuItem.Name = "regresarToolStripMenuItem";
            this.regresarToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.regresarToolStripMenuItem.Text = "Regresar";
            this.regresarToolStripMenuItem.Click += new System.EventHandler(this.regresarToolStripMenuItem_Click);
            // 
            // DM0312_ComentariosVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(691, 461);
            this.Controls.Add(this.pnl_Guardar);
            this.Controls.Add(this.lbl_Filtrar);
            this.Controls.Add(this.txtCampo);
            this.Controls.Add(this.lbl_Campo);
            this.Controls.Add(this.cmbModulo);
            this.Controls.Add(this.dgvComentarios);
            this.Controls.Add(this.menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menu;
            this.Name = "DM0312_ComentariosVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configurar comentarios de venta";
            this.Load += new System.EventHandler(this.DM0312_ComentariosVenta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvComentarios)).EndInit();
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.pnl_Guardar.ResumeLayout(false);
            this.pnl_Guardar.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvComentarios;
        private System.Windows.Forms.ComboBox cmbModulo;
        private System.Windows.Forms.Label lbl_Campo;
        private System.Windows.Forms.TextBox txtCampo;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.Label lbl_Filtrar;
        private System.Windows.Forms.ToolStripMenuItem nuevoRegistroToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_Guardar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_ModuloGuardar;
        private System.Windows.Forms.TextBox txt_ComentarioGuardar;
        private System.Windows.Forms.TextBox txt_CampoGuardar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_ModuloGuardar;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem guardarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem regresarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regresarToolStripMenuItem1;
    }
}