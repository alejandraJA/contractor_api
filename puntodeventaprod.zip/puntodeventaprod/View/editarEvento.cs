﻿using System;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

//GESSY 1286
namespace PuntoVenta.View
{
    public partial class editarEvento : Form
    {
        protected static EventoController EventoC = new EventoController();
        protected static sqlHelper sqlH = new sqlHelper();
        protected static DM0312_MExploradorVenta ventaM = new DM0312_MExploradorVenta();
        private bool bGuardadoCorrecto = false;

        public string observaciones;

        private readonly SancionController SancionC = new SancionController();

        public editarEvento()
        {
            InitializeComponent();
        }

        public editarEvento(DM0312_MExploradorVenta Venta)
        {
            InitializeComponent();
            ventaM = Venta;
        }

        private void editarEvento_Load(object sender, EventArgs e)
        {
            setEventoValues();
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            Guardar();
            Dispose();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            cerrarVentana();
        }

        private void DM0312_AgregarEvento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) cerrarVentana();

            if (e.Control && e.KeyCode == Keys.G)
            {
                Guardar();
                Dispose();
            }
        }

        #region Metodos

        public void setEventoValues()
        {
            ModelAgregaEvento Evento = EventoC.ultimoEvento(ventaM.ID);

            txt_eventoClave.Text = Evento.clave;
            txt_eventoDescripcion.Text = Evento.descripcion;
            txt_AsuntObserva.Text = Evento.comentario;

            txt_Agente.Text = ventaM.Agente;
            txt_agenteDescripcion.Text = EventoC.nombreAgente(ventaM.Agente);

            txt_usuario.Text = ClaseEstatica.Usuario.usuario;
            txt_usuarioDescripcion.Text = EventoC.nombreUsuario(ClaseEstatica.Usuario.usuario);

            dtp_Fecha.Value = EventoC.FechaActualServidor();
            lbl_Cliente.Text = ventaM.Cliente + " - " + ventaM.Nombre;
            lbl_Mov.Text = ventaM.Mov + " " + ventaM.MovId;
        }

        private void cerrarVentana()
        {
            if (!string.IsNullOrWhiteSpace(txt_AsuntObserva.Text))
                if (MessageBox.Show(
                        "Se perderan los avances asunto vacio¿Esta seguro de Salir?", "Confirmar",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Dispose();
                    Close();
                }
        }

        private void Guardar()
        {
            if (txt_AsuntObserva.Text == observaciones)
                if (MessageBox.Show("el asunto no se a modificado ¿desea continuar?", "Confirmar",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                }

            if (EventoC.InsertaEvento(getModeloEventoNuevo())) MessageBox.Show("Recalificado Correctamente");

            if (!SancionC.guardarSancionPendiente(ClaseEstatica.sancion)) MessageBox.Show("Error al Insertar Sancion");
        }

        private ModelAgregaEvento getModeloEventoNuevo()
        {
            ModelAgregaEvento eventoNuevo = new ModelAgregaEvento();
            try
            {
                eventoNuevo.agente = txt_Agente.Text;
                eventoNuevo.clave = txt_eventoClave.Text;
                eventoNuevo.modulo = "VTAS";
                eventoNuevo.idVenta = ventaM.ID;

                eventoNuevo.fecha = sqlH.getFechaActualServidor().ToString("yyyy/MM/dd HH:mm");

                eventoNuevo.evento = txt_AsuntObserva.Text;
                eventoNuevo.sucursal = ClaseEstatica.iSucural;
                eventoNuevo.usuario = ClaseEstatica.Usuario.usuario;
                eventoNuevo.tipo = "COMENTARIO";
                eventoNuevo.estuatus = ventaM.Estatus;
                eventoNuevo.situacion = ventaM.Situacion;
                eventoNuevo.citaCliente = 0;
                eventoNuevo.citaaval = 0;
                eventoNuevo.citaFecha = dtp_Fecha.Value;
                eventoNuevo.citaHora = " ";
                eventoNuevo.TipoEvento = "EVENTO";
                eventoNuevo.mov = ventaM.Mov;
                eventoNuevo.cliente = ventaM.Cliente;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return eventoNuevo;
        }

        #endregion
    }
}