﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DetalleEnganches : Form
    {
        private List<MDetalleEnganchePendientes> AnticiposPendientes;
        private List<MDetalleEngancheRealizados> AnticiposRealizados;
        private readonly CDetalleVenta cdetalle = new CDetalleVenta();
        private readonly CDetalleEnganche DetalleEngancheControlador = new CDetalleEnganche();
        private readonly Funciones funciones = new Funciones();
        public int PaginadoActual = 0;
        public List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public DM0312_DetalleEnganches()
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
        }

        ~DM0312_DetalleEnganches()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Load de enganches
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        private void DM0312_DetalleEnganches_Load(object sender, EventArgs e)
        {
            dgv_pendientes.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 12f, FontStyle.Bold);
            dgv_pendientes.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            dgv_realizados.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 12f, FontStyle.Bold);
            dgv_realizados.DefaultCellStyle.Font = new Font("Times New Roman", 10f, FontStyle.Regular);
            string CurrentMov = VentasSeleccionadas[PaginadoActual].Mov;
            string CurrentMovID = VentasSeleccionadas[PaginadoActual].MovId;
            string Cuenta = string.Empty;
            double TotalAnticiposPendientes = 0;
            AnticiposPendientes = DetalleEngancheControlador.ObtenerPendientes(CurrentMov, CurrentMovID, ref Cuenta,
                ref TotalAnticiposPendientes);
            dgv_pendientes.DataSource = null;
            dgv_pendientes.DataSource = AnticiposPendientes;
            dgv_pendientes.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            lbl_cuenta.Text = Cuenta;
            lbl_totales.Text = AnticiposPendientes.Count + " Saldo: " + TotalAnticiposPendientes.ToString("C");

            ObtenerRealizados();

            Text = "Anticipos - " + CurrentMov + " " + CurrentMovID;

            btn_Imprimir.Visible = false;

            toolTip1.SetToolTip(btn_Regresar, "REGRESAR AL DETALLE DE LA VENTA");
            toolTip1.SetToolTip(btn_Imprimir, "SELECCIONAR PARA IMPRIMIR EL ANTICIPO SELECCIONADO");
            txt_Comentarios.Text = "FORMA DE CONSULTA DE LOS ANTICIPOS REALIZADOS Y DEL SALDO PENDIENTE";


            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_pendientes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_pendientes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_pendientes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_pendientes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        /// <summary>
        ///     Obtener anticipos realizados
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        private void ObtenerRealizados()
        {
            //Loader por si tardan los datos en cargar
            dgv_realizados.Visible = false;
            lbl_totalRealizados.ForeColor = Color.DarkBlue;
            lbl_totalRealizados.Font = new Font("Times New Roman", 10);
            lbl_totalRealizados.Text = "Cargando registros... espere un momento por favor";

            double TotalAnticiposRealizados = 0;
            AnticiposRealizados = DetalleEngancheControlador.ObtenerRealizados(VentasSeleccionadas[PaginadoActual].Mov,
                VentasSeleccionadas[PaginadoActual].MovId, ref TotalAnticiposRealizados);
            dgv_realizados.DataSource = null;
            dgv_realizados.DataSource = AnticiposRealizados;
            dgv_realizados.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //Una vez cargados los datos se limpia el loader y se pone lo que debe de ir
            lbl_totalRealizados.Font = new Font("Microsoft Sans Serif", 8);
            dgv_realizados.Visible = true;
            lbl_totalRealizados.ForeColor = Color.Black;

            lbl_totalRealizados.Text = AnticiposRealizados.Count + " Abono: " + TotalAnticiposRealizados.ToString("C");
        }

        /// <summary>
        ///     Regresa a la forma anterior cerrando la forma
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 31/08/17
        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_pendientes_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(AnticiposPendientes.ToList());
            funciones.OrderGridview(dgv_pendientes, e.ColumnIndex, TempObjects,
                AnticiposPendientes.GetType().GetGenericArguments().Single());
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_realizados_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(AnticiposRealizados.ToList());
            funciones.OrderGridview(dgv_realizados, e.ColumnIndex, ref TempObjects,
                AnticiposRealizados.GetType().GetGenericArguments().Single());
            AnticiposRealizados = TempObjects.OfType<MDetalleEngancheRealizados>().ToList();
        }

        /// <summary>
        ///     Impresion de anticipos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Btn_Imprimir_Click(object sender, EventArgs e)
        {
            if (dgv_realizados.SelectedRows.Count > 0)
            {
                int IDSelected =
                    AnticiposRealizados[dgv_realizados.SelectedRows[dgv_realizados.SelectedRows.Count - 1].Index].ID;
                cdetalle.ImprimirAnticipos(IDSelected);
            }
            else
            {
                MessageBox.Show("No hay nada para imprimir", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Click to show/hide print
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 14/11/17
        private void TabControl1_Click(object sender, EventArgs e)
        {
            btn_Imprimir.Visible = false;
            if (tabControl1.SelectedIndex == 1) btn_Imprimir.Visible = true;
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleEnganches_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }
    }
}