﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_CatalogoArticulos : Form
    {
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public static List<DM0312_MPuntoDeVentaAlmacen> listaAlmacen = new List<DM0312_MPuntoDeVentaAlmacen>();
        public static List<DM0312_MPuntoDeVentaArt> Lista = new List<DM0312_MPuntoDeVentaArt>();
        public static List<DM0312_MPuntoDeVentaArt> ListaC = new List<DM0312_MPuntoDeVentaArt>();
        public static List<DM0312_MPuntoDeVentaArt> ListaPrecios;
        public static DM0312_MPuntoDeVentaArt ModelSeleccionado;

        //-Datalogic
        public static List<clsModeloRecarga> ListaRecargas = new List<clsModeloRecarga>();
        private string Estatus, Almacen, Linea, Articulo;
        private bool Existencia, Entra;

        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();

        private readonly Funciones funciones = new Funciones();

        //-Datalogic
        public string idArticulo, NomArt, dispo, unidad, impuesto, LineaPV, Tipo, Proveedor, acreedor, codigoIntelisis;
        public int indice = -1;
        public int monto;
        public string Rcliente;

        public DM0312_CatalogoArticulos()
        {
            ModelSeleccionado = new DM0312_MPuntoDeVentaArt();
            InitializeComponent();
        }

        public string sTipoDima { get; set; }

        ~DM0312_CatalogoArticulos()
        {
            GC.Collect();
        }

        private void DM0312_CatalogoArticulos_Load(object sender, EventArgs e)
        {
            //-Datalogic
            if (ClaseEstatica.iRecarga == 1)
            {
                frmLoading.Show(this);
                cmb_Estatus.Visible = false;
                lbl_Estatus.Visible = false;
                cmb_Linea.Visible = false;
                lbl_Linea.Visible = false;
                cmb_Almacen.Visible = false;
                lbl_Almacen.Visible = false;
                cb_Existencia.Visible = false;

                llenarRecargas();
                frmLoading.Hide();
            }
            else
            {
                LlenaLinea();
                LlenaAlmacen();
                LlenaEstatus();
                cb_Existencia.Checked = true;
                //string Condicion = string.Empty;
                //if (cb_Existencia.Checked)
                //{
                //    Condicion = "AND Disponible > 0 ";
                //}
                //LlenaArticulos(Condicion);

                string art = txt_Buscar.Text;
                art = art.Replace("*", "");
                string Condicion = string.Empty;
                if (txt_Buscar.Text.Trim() == "")
                    Articulo = "";
                else
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;

                Condicion = "";
                if (Existencia)
                {
                    string tipo = "";
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }

                txt_Buscar.Select();
                Entra = true;

                //

                toolTip1.SetToolTip(lbl_Buscar,
                    "BUSCADOR DE ARTICULOS INGRESAR EL CODIGO DEL ARTICULO O SU DESCRICION");
                toolTip1.SetToolTip(txt_Buscar,
                    "BUSCADOR DE ARTICULOS INGRESAR EL CODIGO DEL ARTICULO O SU DESCRICION");
                toolTip1.SetToolTip(lbl_Estatus, "ESTATUS DEL ARTICULO QUE DESEA BUSCAR");
                toolTip1.SetToolTip(cmb_Estatus, "INGRESAR EL ESTATUS DEL ARTICULO QUE DESEA BUSCAR");
                toolTip1.SetToolTip(lbl_Linea, "LINEA DEL ARTICULO QUE DESEA ENCONTRAR");
                toolTip1.SetToolTip(cmb_Linea, "INGRESAR LA LINEA EN LA CUAL SE ENCUENTRA EL ARTICULO A VENDER");
                toolTip1.SetToolTip(lbl_Almacen, "ALMACEN DEL CUAL SE MOSTRARAN LAS EXISTENCIAS");
                toolTip1.SetToolTip(cmb_Almacen, "INGRESAR EL ALMACEN PARA VER LAS EXISTENCIAS DE ARTICULOS");
                toolTip1.SetToolTip(cb_Existencia, "SELECCIONAR EL CHECK PARA VER ARTICULOS CON EXISTENCIAS");
                txt_Comentarios.Text =
                    "CATALOGO DE ARTICULOS, BUSCAR EL ARTICULO QUE DESEA VENDER DAR DOBLE CLICK SOBRE EL PARA CONTINUAR LA VENTA, SI DESEA VER LOS PRECIOS DAR CLICK DERECHO SOBRE EL ARTICULO A BUSCAR";

                if (ClaseEstatica.Usuario.color == "Azul")
                    dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                if (ClaseEstatica.Usuario.color == "Rosa")
                    dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                if (ClaseEstatica.Usuario.color == "Verde")
                    dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                if (ClaseEstatica.Usuario.color == "Gris")
                    dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }

        /// <summary>
        ///     Metodo encargado de obtener las recargas
        /// </summary>
        public async void llenarRecargas()
        {
            ListaRecargas = new List<clsModeloRecarga>();
            if (ListaRecargas.Count == 0)
            {
                DM0312_Loading_ frmLoading = new DM0312_Loading_();
                ListaRecargas = await Task.Run(() => controlador.obtenerRecargas(1));
                dgv_Articulos.DataSource = ListaRecargas;
                dgv_Articulos.Columns[0].Visible = false;
            }

            txt_Buscar.Focus();
        }

        private void cmb_Linea_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ValidarArticulos();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void cmb_Almacen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ValidarArticulos();
        }

        //public bool CandadoEdad(string cliente)
        //{
        //    DM0312_CPuntoDeVenta controladorP = new DM0312_CPuntoDeVenta();
        //    DM0312_CVentanaEntrada controladorV = new DM0312_CVentanaEntrada();
        //    int anios = 0;
        //    anios = controladorP.CandadoEdadAños("SEGURO DE VIDA");

        //    DateTime nacimiento = controladorV.FechaNacimientoCliente(cliente); //Fecha de nacimiento
        //    int edad = DateTime.Today.AddTicks(-nacimiento.Ticks).Year - 1;

        //    if (edad >= anios)
        //    {
        //        MessageBox.Show("Cliente " + cliente + " no califica por edad", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        return false;
        //    }
        //    return true;
        //}

        public bool CandadoEdad(string cliente)
        {
            DM0312_CPuntoDeVenta controladorP = new DM0312_CPuntoDeVenta();
            DM0312_CVentanaEntrada controladorV = new DM0312_CVentanaEntrada();
            int anios = 0;
            anios = controladorP.CandadoEdadAños("SEGURO DE VIDA");

            DateTime nacimiento = controladorV.FechaNacimientoCliente(cliente); //Fecha de nacimiento
            int edad = DateTime.Today.AddTicks(-nacimiento.Ticks).Year - 1;

            if (edad > anios && anios != 0)
            {
                MessageBox.Show("Cliente " + cliente + " no califica por edad", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return false;
            }

            return true;
        }


        private void dgv_Articulos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indice = e.RowIndex;
            if (indice >= 0)
            {
                if (ClaseEstatica.iRecarga == 1)
                {
                    idArticulo = dgv_Articulos.Rows[e.RowIndex].Cells["sCodigoIntelisis"].FormattedValue.ToString();
                    NomArt = dgv_Articulos.Rows[e.RowIndex].Cells["sNombre"].FormattedValue.ToString();
                    Tipo = dgv_Articulos.Rows[e.RowIndex].Cells["sTIpo"].FormattedValue.ToString();
                    Proveedor = dgv_Articulos.Rows[e.RowIndex].Cells["sProv"].FormattedValue.ToString();
                    monto = int.Parse(dgv_Articulos.Rows[e.RowIndex].Cells["sMonto"].FormattedValue.ToString());
                    acreedor = dgv_Articulos.Rows[e.RowIndex].Cells["sAcreedor"].FormattedValue.ToString();
                    codigoIntelisis = dgv_Articulos.Rows[e.RowIndex].Cells["sCodigo"].FormattedValue.ToString();
                }
                else
                {
                    idArticulo = dgv_Articulos.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
                    NomArt = dgv_Articulos.Rows[e.RowIndex].Cells["Nombre"].FormattedValue.ToString();
                    dispo = dgv_Articulos.Rows[e.RowIndex].Cells["Disponible"].FormattedValue.ToString();
                    impuesto = dgv_Articulos.Rows[e.RowIndex].Cells["Impuesto"].FormattedValue.ToString();
                    unidad = dgv_Articulos.Rows[e.RowIndex].Cells["unidad"].FormattedValue.ToString();
                    LineaPV = dgv_Articulos.Rows[e.RowIndex].Cells["Linea"].FormattedValue.ToString();
                    Tipo = dgv_Articulos.Rows[e.RowIndex].Cells["Tipo"].FormattedValue.ToString();
                }

                if (LineaPV == "SEGUROS DE VIDA")
                    if (!CandadoEdad(Rcliente))
                    {
                        idArticulo = "";
                        NomArt = "";
                        dispo = "";
                        impuesto = "";
                        unidad = "";
                        LineaPV = "";
                        Tipo = "";
                        return;
                    }

                Close();
            }
        }

        private void DM0312_CatalogoArticulos_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        private void dgv_Articulos_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(Lista);
            funciones.OrderGridview(dgv_Articulos, e.ColumnIndex, TempObjects,
                Lista.GetType().GetGenericArguments().Single());
            dgv_Articulos.Columns[7].Visible = false;
            dgv_Articulos.Columns[5].Visible = false;
        }

        private void DM0312_CatalogoArticulos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();

            if (e.Control && e.KeyCode == Keys.P)
            {
                DM0312_MPuntoDeVentaArt model_ = new DM0312_MPuntoDeVentaArt();
                model_ = (DM0312_MPuntoDeVentaArt)dgv_Articulos.CurrentRow.DataBoundItem;

                DM0312_PreciosArticulos Precios = new DM0312_PreciosArticulos();
                Precios.recibeArticulo = model_.Codigo;
                Precios.Show();
            }
        }

        private void preciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DM0312_MPuntoDeVentaArt model_ = new DM0312_MPuntoDeVentaArt();
            model_ = (DM0312_MPuntoDeVentaArt)dgv_Articulos.CurrentRow.DataBoundItem;

            DM0312_PreciosArticulos Precios = new DM0312_PreciosArticulos();
            Precios.recibeArticulo = model_.Codigo;
            Precios.Show();
        }

        private void dgv_Articulos_SelectionChanged(object sender, EventArgs e)
        {
            //ListaPrecios = new List<DM0312_MPuntoDeVentaArt>();
            //    DM0312_MPuntoDeVentaArt model_ = new DM0312_MPuntoDeVentaArt();
            //    model_ = (DM0312_MPuntoDeVentaArt)dgv_Articulos.SelectedRows[0].DataBoundItem;
            //    ListaPrecios.Add(model_);  

            //ModelSeleccionado = ListaPrecios.FirstOrDefault();
        }

        #region "Metodos"

        public void LlenaEstatus()
        {
            try
            {
                cmb_Estatus.Items.Add("Todos");
                cmb_Estatus.Items.Add("Alta");
                cmb_Estatus.Items.Add("Bloqueado");
                cmb_Estatus.Text = "Todos";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaEstatus", "DM0312_CatalogoArticulos", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaLinea()
        {
            try
            {
                DataTable tabla = new DataTable();
                tabla = controlador.LlenaLinea();
                cmb_Linea.DataSource = tabla;
                cmb_Linea.ValueMember = "Linea";
                cmb_Linea.Text = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaLinea", "DM0312_CatalogoArticulos", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAlmacen()
        {
            try
            {
                listaAlmacen = new List<DM0312_MPuntoDeVentaAlmacen>();
                listaAlmacen = controlador.LlenaAlmacen();
                //var var = from h in listaAlmacen
                //          where h.Almacen.ToString().Contains('V')
                //          select new
                //          {
                //              Almacen = h.Almacen
                //          };
                cmb_Almacen.DataSource = listaAlmacen;
                cmb_Almacen.ValueMember = "Almacen";
                cmb_Almacen.Text = PuntoDeVenta.Almacen;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_CatalogoArticulos", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public async void LlenaArticulos(string var)
        {
            try
            {
                if (ClaseEstatica.iRecarga == 1)
                {
                    frmLoading.Show(this);
                    ListaRecargas = await Task.Run(() => controlador.obtenerRecargas(2, var));
                    dgv_Articulos.DataSource = ListaRecargas;
                }
                else
                {
                    Lista = new List<DM0312_MPuntoDeVentaArt>();
                    if (Lista.Count == 0)
                    {
                        int iOpcion = 1;

                        if (!string.IsNullOrEmpty(sTipoDima)) iOpcion = 3;
                        DM0312_Loading_ frmLoading = new DM0312_Loading_();
                        frmLoading.Show(this);
                        lbl_Buscar.Enabled = false;
                        txt_Buscar.Enabled = false;
                        lbl_Estatus.Enabled = false;
                        cmb_Estatus.Enabled = false;
                        lbl_Linea.Enabled = false;
                        cmb_Linea.Enabled = false;
                        lbl_Almacen.Enabled = false;
                        cmb_Almacen.Enabled = false;
                        cb_Existencia.Enabled = false;
                        Lista = await Task.Run(() =>
                            controlador.BuscaArticulos(Articulo, Almacen, var, iOpcion, sTipoDima));
                        frmLoading.Hide();
                        lbl_Buscar.Enabled = true;
                        txt_Buscar.Enabled = true;
                        lbl_Estatus.Enabled = true;
                        cmb_Estatus.Enabled = true;
                        lbl_Linea.Enabled = true;
                        cmb_Linea.Enabled = true;
                        lbl_Almacen.Enabled = true;
                        cmb_Almacen.Enabled = true;
                        cb_Existencia.Enabled = true;
                    }

                    if (Lista.Count == 0)
                    {
                        Articulo = " AND Descripcion1 Like  '%" + txt_Buscar.Text + "%'";
                        Lista = controlador.BuscaArticulos(Articulo, Almacen, var, 2);
                    }

                    List<DM0312_MPuntoDeVentaArt> objetos = Lista.Take(2000).ToList();
                    dgv_Articulos.DataSource = objetos;
                    dgv_Articulos.Visible = true;

                    if (Lista.Count > 0)
                    {
                        dgv_Articulos.Columns[7].Visible = false;
                        dgv_Articulos.Columns[5].Visible = false;
                    }

                    if (Lista.Count == 0)
                    {
                        if (cmb_Linea.Text == "" || (cmb_Linea.Text != "" && txt_Buscar.Text != ""))
                        {
                            MessageBox.Show("Articulo incorrecto", "Informacion", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            //txt_Buscar.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("No se encuentran articulos en la linea " + cmb_Linea.Text, "Informacion",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            cmb_Linea.Text = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaArticulos", "DM0312_CatalogoArticulos", ex);
                MessageBox.Show(ex.Message);
            }

            txt_Buscar.Focus();
        }

        #endregion

        #region "Eventos"

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ValidarArticulos();

            //if (Char.IsLetterOrDigit(e.KeyChar) || Char.IsControl(e.KeyChar) || e.KeyChar == (char)32 || e.KeyChar == '#')
            //{
            //    e.Handled = false;
            //}
            //else
            //{
            //    e.Handled = true;
            //}
        }

        private void ValidarArticulos()
        {
            //-Datalogic
            if (ClaseEstatica.iRecarga == 1)
            {
                string sCosulta = string.Format("SELECT " +
                                                "pago.Codigo," +
                                                "ISNULL(CodigoIntelisis, '') AS CodigoIntelisis," +
                                                "Nombre," +
                                                "pago.Tipo," +
                                                "Prov," +
                                                "Monto," +
                                                "ISNULL(Acreedor, '') AS Acreedor " +
                                                "FROM dm0216pagoexternoart pago WITH (NOLOCK) " +
                                                "INNER JOIN art ar WITH (NOLOCK) " +
                                                "ON(ar.Articulo = pago.CodigoIntelisis) " +
                                                "WHERE ar.Estatus = 'ALTA' " +
                                                "AND pago.Tipo = 'TAE' " +
                                                "AND pago.Estatus <> 'BAJA' " +
                                                "AND pago.CodigoIntelisis Like '%{0}%'", txt_Buscar.Text);
                LlenaArticulos(sCosulta);
            }
            else
            {
                string art = txt_Buscar.Text;
                string Condicion = string.Empty;
                if (art.Contains("*"))
                {
                    art = art.Replace("*", "");
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                }
                else
                {
                    if (txt_Buscar.Text.Trim() == "")
                        Articulo = "";
                    else
                        Articulo = " AND (art.Articulo Like  '" + art + "%' OR art.DESCRIPCION1 Like  '" + art + "%' )";
                }

                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;

                Condicion = "";
                if (Existencia)
                {
                    string tipo = "";
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }
            }
        }

        private void cmb_Estatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Entra)
            {
                string art = txt_Buscar.Text;
                art = art.Replace("*", "");
                string Condicion = string.Empty;
                if (txt_Buscar.Text.Trim() == "")
                    Articulo = "";
                else
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;

                Condicion = "";
                if (Existencia)
                {
                    string tipo = "";
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }
            }
        }

        private void cmb_Linea_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Entra)
            {
                string art = txt_Buscar.Text;
                art = art.Replace("*", "");
                string Condicion = string.Empty;
                if (txt_Buscar.Text.Trim() == "")
                    Articulo = "";
                else
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;

                Condicion = "";
                if (Existencia)
                {
                    string tipo = "";
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }
            }
        }

        private void cmb_Almacen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Entra)
            {
                string art = txt_Buscar.Text;
                art = art.Replace("*", "");
                string Condicion = string.Empty;
                if (txt_Buscar.Text.Trim() == "")
                    Articulo = "";
                else
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;

                Condicion = "";
                if (Existencia)
                {
                    string tipo = "";
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }
            }
        }

        private void cb_Existencia_CheckedChanged(object sender, EventArgs e)
        {
            if (Entra)
            {
                string art = txt_Buscar.Text;
                art = art.Replace("*", "");
                string Condicion = string.Empty;
                if (txt_Buscar.Text.Trim() == "")
                    Articulo = "";
                else
                    Articulo = " AND (art.Articulo Like  '%" + art + "%' OR art.DESCRIPCION1 Like  '%" + art + "%' )";
                Existencia = cb_Existencia.Checked;
                Linea = cmb_Linea.Text;
                Almacen = cmb_Almacen.Text;
                Estatus = cmb_Estatus.Text;
                string tipo = "";
                Condicion = "";
                if (Existencia)
                {
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND ActivoFDisponible.Disponible > 0 ";
                    else
                        Condicion = "AND ArtDisponible.Disponible > 0 ";
                }
                else
                {
                    tipo = controlador.AlmacenActivoFijo(Almacen);
                    if (tipo == "Activos Fijos")
                        Condicion = "AND (ActivoFDisponible.Disponible = 0 or ActivoFDisponible.Disponible is null) ";
                    else
                        Condicion = "AND (ArtDisponible.Disponible = 0 or ArtDisponible.Disponible is null) ";
                }

                if (Estatus != "" && Estatus != "Todos") Condicion = Condicion + " AND Estatus = '" + Estatus + "'";
                if (Linea != "") Condicion = Condicion + " AND Linea = '" + Linea + "'";
                if (Almacen != "" && Articulo != "")
                {
                    LlenaArticulos(Condicion);
                }
                else
                {
                    if (Articulo == "")
                        LlenaArticulos(Condicion);
                    else
                        MessageBox.Show("Seleccione un almacen valido", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                }
            }
        }

        #endregion
    }
}