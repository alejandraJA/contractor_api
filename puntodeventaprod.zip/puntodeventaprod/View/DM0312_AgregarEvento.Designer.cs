﻿namespace PuntoVenta
{
    partial class DM0312_AgregarEvento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
           
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_AgregarEvento));
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_Mov = new System.Windows.Forms.Label();
            this.lbl_MovId = new System.Windows.Forms.Label();
            this.lbl_Clave = new System.Windows.Forms.Label();
            this.lbl_Agente = new System.Windows.Forms.Label();
            this.lbl_Fecha = new System.Windows.Forms.Label();
            this.lbl_Asunto = new System.Windows.Forms.Label();
            this.txt_AgenteDescripcion = new System.Windows.Forms.TextBox();
            this.txt_AsuntObserva = new System.Windows.Forms.TextBox();
            this.txt_Descripcion = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ck_Aval = new System.Windows.Forms.CheckBox();
            this.ck_Cliente = new System.Windows.Forms.CheckBox();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.txt_Fecha = new System.Windows.Forms.TextBox();
            this.cbx_Hora = new System.Windows.Forms.ComboBox();
            this.cbx_Agente = new System.Windows.Forms.ComboBox();
            this.dtp_Fecha = new System.Windows.Forms.DateTimePicker();
            this.lbl_Observaciones = new System.Windows.Forms.Label();
            this.lbl_Hora = new System.Windows.Forms.Label();
            this.cbx_Clave = new System.Windows.Forms.ComboBox();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_CancelarVenta = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Movimiento = new System.Windows.Forms.Label();
            this.lbl_MovimientoID = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.iconError = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.iconError)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(156, 353);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(50, 15);
            this.lbl_Cliente.TabIndex = 4;
            this.lbl_Cliente.Text = "Cliente ";
            // 
            // lbl_Mov
            // 
            this.lbl_Mov.AutoSize = true;
            this.lbl_Mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Mov.Location = new System.Drawing.Point(567, 353);
            this.lbl_Mov.Name = "lbl_Mov";
            this.lbl_Mov.Size = new System.Drawing.Size(29, 15);
            this.lbl_Mov.TabIndex = 5;
            this.lbl_Mov.Text = "Mov";
            // 
            // lbl_MovId
            // 
            this.lbl_MovId.AutoSize = true;
            this.lbl_MovId.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_MovId.Location = new System.Drawing.Point(737, 353);
            this.lbl_MovId.Name = "lbl_MovId";
            this.lbl_MovId.Size = new System.Drawing.Size(42, 15);
            this.lbl_MovId.TabIndex = 6;
            this.lbl_MovId.Text = "MovID";
            // 
            // lbl_Clave
            // 
            this.lbl_Clave.AutoSize = true;
            this.lbl_Clave.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Clave.Location = new System.Drawing.Point(28, 55);
            this.lbl_Clave.Name = "lbl_Clave";
            this.lbl_Clave.Size = new System.Drawing.Size(47, 15);
            this.lbl_Clave.TabIndex = 0;
            this.lbl_Clave.Text = "*Clave ";
            // 
            // lbl_Agente
            // 
            this.lbl_Agente.AutoSize = true;
            this.lbl_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Agente.Location = new System.Drawing.Point(245, 253);
            this.lbl_Agente.Name = "lbl_Agente";
            this.lbl_Agente.Size = new System.Drawing.Size(56, 15);
            this.lbl_Agente.TabIndex = 1;
            this.lbl_Agente.Text = "*Agente ";
            // 
            // lbl_Fecha
            // 
            this.lbl_Fecha.AutoSize = true;
            this.lbl_Fecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Fecha.Location = new System.Drawing.Point(28, 253);
            this.lbl_Fecha.Name = "lbl_Fecha";
            this.lbl_Fecha.Size = new System.Drawing.Size(42, 15);
            this.lbl_Fecha.TabIndex = 2;
            this.lbl_Fecha.Text = "Fecha ";
            // 
            // lbl_Asunto
            // 
            this.lbl_Asunto.AutoSize = true;
            this.lbl_Asunto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Asunto.Location = new System.Drawing.Point(28, 104);
            this.lbl_Asunto.Name = "lbl_Asunto";
            this.lbl_Asunto.Size = new System.Drawing.Size(49, 15);
            this.lbl_Asunto.TabIndex = 3;
            this.lbl_Asunto.Text = "Asunto ";
            // 
            // txt_AgenteDescripcion
            // 
            this.txt_AgenteDescripcion.Enabled = false;
            this.txt_AgenteDescripcion.Location = new System.Drawing.Point(437, 253);
            this.txt_AgenteDescripcion.Name = "txt_AgenteDescripcion";
            this.txt_AgenteDescripcion.ReadOnly = true;
            this.txt_AgenteDescripcion.Size = new System.Drawing.Size(240, 20);
            this.txt_AgenteDescripcion.TabIndex = 8;
            this.txt_AgenteDescripcion.Click += new System.EventHandler(this.txt_AgenteDescripcion_Click);
            // 
            // txt_AsuntObserva
            // 
            this.txt_AsuntObserva.BackColor = System.Drawing.Color.Snow;
            this.txt_AsuntObserva.Location = new System.Drawing.Point(91, 104);
            this.txt_AsuntObserva.MaxLength = 200;
            this.txt_AsuntObserva.Multiline = true;
            this.txt_AsuntObserva.Name = "txt_AsuntObserva";
            this.txt_AsuntObserva.Size = new System.Drawing.Size(489, 96);
            this.txt_AsuntObserva.TabIndex = 5;
            this.txt_AsuntObserva.Click += new System.EventHandler(this.txt_AsuntObserva_Click);
            // 
            // txt_Descripcion
            // 
            this.txt_Descripcion.Enabled = false;
            this.txt_Descripcion.Location = new System.Drawing.Point(218, 51);
            this.txt_Descripcion.Name = "txt_Descripcion";
            this.txt_Descripcion.ReadOnly = true;
            this.txt_Descripcion.Size = new System.Drawing.Size(276, 20);
            this.txt_Descripcion.TabIndex = 2;
            this.txt_Descripcion.Click += new System.EventHandler(this.txt_Descripcion_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.ck_Aval);
            this.groupBox1.Controls.Add(this.ck_Cliente);
            this.groupBox1.Controls.Add(this.txt_ComentarioAyuda);
            this.groupBox1.Controls.Add(this.txt_Fecha);
            this.groupBox1.Controls.Add(this.cbx_Hora);
            this.groupBox1.Controls.Add(this.cbx_Agente);
            this.groupBox1.Controls.Add(this.dtp_Fecha);
            this.groupBox1.Controls.Add(this.lbl_Observaciones);
            this.groupBox1.Controls.Add(this.lbl_Hora);
            this.groupBox1.Controls.Add(this.txt_Descripcion);
            this.groupBox1.Controls.Add(this.cbx_Clave);
            this.groupBox1.Controls.Add(this.txt_AsuntObserva);
            this.groupBox1.Controls.Add(this.txt_AgenteDescripcion);
            this.groupBox1.Controls.Add(this.lbl_Asunto);
            this.groupBox1.Controls.Add(this.lbl_Fecha);
            this.groupBox1.Controls.Add(this.lbl_Agente);
            this.groupBox1.Controls.Add(this.lbl_Clave);
            this.groupBox1.Location = new System.Drawing.Point(102, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(710, 295);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // ck_Aval
            // 
            this.ck_Aval.AutoSize = true;
            this.ck_Aval.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.ck_Aval.Location = new System.Drawing.Point(571, 19);
            this.ck_Aval.Name = "ck_Aval";
            this.ck_Aval.Size = new System.Drawing.Size(58, 23);
            this.ck_Aval.TabIndex = 20;
            this.ck_Aval.Text = "Aval";
            this.ck_Aval.UseVisualStyleBackColor = true;
            this.ck_Aval.Visible = false;
            this.ck_Aval.CheckedChanged += new System.EventHandler(this.ck_Aval_CheckedChanged);
            // 
            // ck_Cliente
            // 
            this.ck_Cliente.AutoSize = true;
            this.ck_Cliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.ck_Cliente.Location = new System.Drawing.Point(480, 19);
            this.ck_Cliente.Name = "ck_Cliente";
            this.ck_Cliente.Size = new System.Drawing.Size(76, 23);
            this.ck_Cliente.TabIndex = 19;
            this.ck_Cliente.Text = "Cliente";
            this.ck_Cliente.UseVisualStyleBackColor = true;
            this.ck_Cliente.Visible = false;
            this.ck_Cliente.CheckedChanged += new System.EventHandler(this.ck_Cliente_CheckedChanged);
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(6, 10);
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(526, 13);
            this.txt_ComentarioAyuda.TabIndex = 18;
            // 
            // txt_Fecha
            // 
            this.txt_Fecha.Location = new System.Drawing.Point(91, 253);
            this.txt_Fecha.Name = "txt_Fecha";
            this.txt_Fecha.ReadOnly = true;
            this.txt_Fecha.Size = new System.Drawing.Size(68, 20);
            this.txt_Fecha.TabIndex = 17;
            this.txt_Fecha.Click += new System.EventHandler(this.txt_Fecha_Click);
            this.txt_Fecha.TextChanged += new System.EventHandler(this.txt_Fecha_TextChanged);
            // 
            // cbx_Hora
            // 
            this.cbx_Hora.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Hora.FormattingEnabled = true;
            this.cbx_Hora.Items.AddRange(new object[] {"11:00 am  - 13:00 pm", "13:00 pm - 15:00 pm", "15:00 pm - 17:00 pm", "17:00 pm - 19:00 pm", "19:00 pm - 21:00 pm"});
            this.cbx_Hora.Location = new System.Drawing.Point(551, 51);
            this.cbx_Hora.Name = "cbx_Hora";
            this.cbx_Hora.Size = new System.Drawing.Size(121, 21);
            this.cbx_Hora.TabIndex = 15;
            this.cbx_Hora.Click += new System.EventHandler(this.cbx_Hora_Click);
            this.cbx_Hora.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Hora_KeyPress);
            // 
            // cbx_Agente
            // 
            this.cbx_Agente.FormattingEnabled = true;
            this.cbx_Agente.Location = new System.Drawing.Point(300, 253);
            this.cbx_Agente.Name = "cbx_Agente";
            this.cbx_Agente.Size = new System.Drawing.Size(121, 21);
            this.cbx_Agente.TabIndex = 13;
            this.cbx_Agente.Click += new System.EventHandler(this.cbx_Agente_Click);
            this.cbx_Agente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Agente_KeyPress);
            // 
            // dtp_Fecha
            // 
            this.dtp_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Fecha.Location = new System.Drawing.Point(156, 253);
            this.dtp_Fecha.Name = "dtp_Fecha";
            this.dtp_Fecha.Size = new System.Drawing.Size(19, 20);
            this.dtp_Fecha.TabIndex = 6;
            this.dtp_Fecha.Value = new System.DateTime(2017, 10, 9, 10, 17, 32, 0);
            this.dtp_Fecha.ValueChanged += new System.EventHandler(this.dtp_Fecha_ValueChanged);
            // 
            // lbl_Observaciones
            // 
            this.lbl_Observaciones.AutoSize = true;
            this.lbl_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Observaciones.Location = new System.Drawing.Point(28, 82);
            this.lbl_Observaciones.Name = "lbl_Observaciones";
            this.lbl_Observaciones.Size = new System.Drawing.Size(90, 15);
            this.lbl_Observaciones.TabIndex = 12;
            this.lbl_Observaciones.Text = "Observaciones ";
            // 
            // lbl_Hora
            // 
            this.lbl_Hora.AutoSize = true;
            this.lbl_Hora.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Hora.Location = new System.Drawing.Point(508, 55);
            this.lbl_Hora.Name = "lbl_Hora";
            this.lbl_Hora.Size = new System.Drawing.Size(37, 15);
            this.lbl_Hora.TabIndex = 10;
            this.lbl_Hora.Text = "Hora ";
            // 
            // cbx_Clave
            // 
            this.cbx_Clave.FormattingEnabled = true;
            this.cbx_Clave.Location = new System.Drawing.Point(91, 51);
            this.cbx_Clave.Name = "cbx_Clave";
            this.cbx_Clave.Size = new System.Drawing.Size(121, 21);
            this.cbx_Clave.TabIndex = 0;
            this.cbx_Clave.DropDown += new System.EventHandler(this.cbx_Clave_DropDown);
            this.cbx_Clave.SelectedIndexChanged += new System.EventHandler(this.cbx_Clave_SelectedIndexChanged);
            this.cbx_Clave.Click += new System.EventHandler(this.cbx_Clave_Click);
            this.cbx_Clave.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Clave_KeyPress);
            this.cbx_Clave.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_Clave_Validating);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_Regresar.Image = ((System.Drawing.Image) (resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 83);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(73, 73);
            this.btn_Regresar.TabIndex = 10;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_Guardar.Image = ((System.Drawing.Image) (resources.GetObject("btn_Guardar.Image")));
            this.btn_Guardar.Location = new System.Drawing.Point(3, 3);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(73, 74);
            this.btn_Guardar.TabIndex = 9;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_ayuda.Image = ((System.Drawing.Image) (resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ayuda.Location = new System.Drawing.Point(3, 241);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(73, 65);
            this.btn_ayuda.TabIndex = 11;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_Guardar);
            this.flowLayoutPanel1.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel1.Controls.Add(this.btn_CancelarVenta);
            this.flowLayoutPanel1.Controls.Add(this.btn_ayuda);
            this.flowLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 7);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(82, 347);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // btn_CancelarVenta
            // 
            this.btn_CancelarVenta.BackColor = System.Drawing.Color.White;
            this.btn_CancelarVenta.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_CancelarVenta.FlatAppearance.BorderSize = 0;
            this.btn_CancelarVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CancelarVenta.Image = ((System.Drawing.Image) (resources.GetObject("btn_CancelarVenta.Image")));
            this.btn_CancelarVenta.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CancelarVenta.Location = new System.Drawing.Point(3, 162);
            this.btn_CancelarVenta.Name = "btn_CancelarVenta";
            this.btn_CancelarVenta.Size = new System.Drawing.Size(77, 73);
            this.btn_CancelarVenta.TabIndex = 12;
            this.btn_CancelarVenta.Text = "Cancelar Venta";
            this.btn_CancelarVenta.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CancelarVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CancelarVenta.UseVisualStyleBackColor = false;
            this.btn_CancelarVenta.Click += new System.EventHandler(this.btn_CancelarVenta_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label1.Location = new System.Drawing.Point(99, 353);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "Cliente:";
            // 
            // lbl_Movimiento
            // 
            this.lbl_Movimiento.AutoSize = true;
            this.lbl_Movimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_Movimiento.Location = new System.Drawing.Point(487, 353);
            this.lbl_Movimiento.Name = "lbl_Movimiento";
            this.lbl_Movimiento.Size = new System.Drawing.Size(74, 15);
            this.lbl_Movimiento.TabIndex = 15;
            this.lbl_Movimiento.Text = "Movimiento:";
            // 
            // lbl_MovimientoID
            // 
            this.lbl_MovimientoID.AutoSize = true;
            this.lbl_MovimientoID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_MovimientoID.Location = new System.Drawing.Point(685, 353);
            this.lbl_MovimientoID.Name = "lbl_MovimientoID";
            this.lbl_MovimientoID.Size = new System.Drawing.Size(46, 15);
            this.lbl_MovimientoID.TabIndex = 16;
            this.lbl_MovimientoID.Text = "MovID:";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(102, 0);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(710, 59);
            this.txt_Comentarios.TabIndex = 110;
            // 
            // iconError
            // 
            this.iconError.ContainerControl = this;
            // 
            // DM0312_AgregarEvento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(845, 377);
            this.ControlBox = false;
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.lbl_MovimientoID);
            this.Controls.Add(this.lbl_Movimiento);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.lbl_MovId);
            this.Controls.Add(this.lbl_Mov);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "DM0312_AgregarEvento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agregar Evento";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AgregarEvento_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AgregarEvento_FormClosed);
            this.Load += new System.EventHandler(this.AgregarEvento_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_AgregarEvento_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.iconError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.Label lbl_Mov;
        private System.Windows.Forms.Label lbl_MovId;
        private System.Windows.Forms.Label lbl_Clave;
        private System.Windows.Forms.Label lbl_Agente;
        private System.Windows.Forms.Label lbl_Fecha;
        private System.Windows.Forms.Label lbl_Asunto;
        public System.Windows.Forms.TextBox txt_AgenteDescripcion;
        public System.Windows.Forms.TextBox txt_AsuntObserva;
        public  System.Windows.Forms.TextBox txt_Descripcion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Label lbl_Observaciones;
        private System.Windows.Forms.Label lbl_Hora;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.DateTimePicker dtp_Fecha;
        public System.Windows.Forms.ComboBox cbx_Clave;
        public System.Windows.Forms.ComboBox cbx_Agente;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ComboBox cbx_Hora;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        public System.Windows.Forms.TextBox txt_Fecha;
        private System.Windows.Forms.Button btn_CancelarVenta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Movimiento;
        private System.Windows.Forms.Label lbl_MovimientoID;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ErrorProvider iconError;
        private System.Windows.Forms.CheckBox ck_Aval;
        private System.Windows.Forms.CheckBox ck_Cliente;
    }
}