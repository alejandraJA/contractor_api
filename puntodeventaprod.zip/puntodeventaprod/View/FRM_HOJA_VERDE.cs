﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PuntoVenta
{
    public partial class FRM_HOJA_VERDE : Form
    {
        public FRM_HOJA_VERDE()
        {
            InitializeComponent();
        }

        public FRM_HOJA_VERDE(string tipo, string cuenta = "", string solicitud = "",
            float importe = 0f) //Tipo: CAPTURARHOJAVERDE/MOSTRARHOJAVERDE
        {
            //if (buro.CondicionMenu())
            //    k.kill();

            InitializeComponent();
            CargarDdls();
            if (!string.IsNullOrEmpty(cuenta))
            {
                txt_NumProspecto.Text = cuenta;
                txt_NumProspecto.Enabled = false;
                txt_NumSolicitud.Text = solicitud;
                txt_Importe.Text = importe.ToString();
                CargarCliente(cuenta, tipo);
            }

            btn_Imprimir.Visible = false;

            if (tipo == "MOSTRARHOJAVERDE")
            {
                btn_actualizar.Visible = false;
                btn_guardar.Visible = false;
                btn_Imprimir.Visible = true;

                foreach (Control control in Controls)
                {
                    GroupBox gb = control as GroupBox;
                    if (gb != null)
                        HabilitarControles(gb);

                    foreach (Control item in control.Controls)
                    {
                        GroupBox gb1 = item as GroupBox;
                        if (gb1 != null)
                            HabilitarControles(gb1);

                        TextBox TB = item as TextBox;
                        if (TB != null) TB.ReadOnly = true;

                        if (item.GetType() != typeof(Label) && item.GetType() != typeof(TextBox) &&
                            item.GetType() != typeof(GroupBox))
                            item.Enabled = false;

                        foreach (Control item1 in item.Controls)
                        {
                            GroupBox gb2 = item1 as GroupBox;
                            if (gb2 != null)
                                HabilitarControles(gb2);

                            TextBox TB1 = item1 as TextBox;
                            if (TB1 != null) TB1.ReadOnly = true;

                            if (item1.GetType() != typeof(Label) && item1.GetType() != typeof(TextBox) &&
                                item1.GetType() != typeof(GroupBox))
                                item1.Enabled = false;
                        }
                    }
                }
            }
        }

        ~FRM_HOJA_VERDE()
        {
            GC.Collect();
        }


        private void CargarCliente(string cuenta, string tipo)
        {
        }

        private void CargarDdls()
        {
            Dictionary<int, string> ListaItems = new Dictionary<int, string>();
            Dictionary<int, string> ListaItemsParentesco = new Dictionary<int, string>();
            Dictionary<int, string> ListaItemPeriodo = new Dictionary<int, string>();
            Dictionary<int, string> ListaItemEdoCivil = new Dictionary<int, string>();

            ComboboxItem item;


            //Cargar los ComboBox de Calidad en la que vive
            foreach (KeyValuePair<int, string> Item in ListaItems)
            {
                item = new ComboboxItem();
                item.Value = Item.Key;
                item.Text = Item.Value;

                ddl_CteCalidadVive.Items.Add(item);
                ddl_AvalCalidadVive.Items.Add(item);
            }


            foreach (KeyValuePair<int, string> Item in ListaItemsParentesco)
            {
                item = new ComboboxItem();
                item.Value = Item.Key;
                item.Text = Item.Value;

                ddl_AvalParentesco.Items.Add(item);
                ddl_CteRecomParentesco.Items.Add(item);
                ddl_CteRef1Parentesco.Items.Add(item);
                ddl_CteRef2Parentesco.Items.Add(item);
            }

            foreach (KeyValuePair<int, string> Item in ListaItemPeriodo)
            {
                item = new ComboboxItem();
                item.Value = Item.Key;
                item.Text = Item.Value;

                ddl_CteEmpPeriodoIngresos.Items.Add(item);
                ddl_CteConyugeEmpPeriodoIngresos.Items.Add(item);
                ddl_AvalEmpPeriodoIngresos.Items.Add(item);
                ddl_AvalConyugeEmpPeriodoIngresos.Items.Add(item);
            }


            foreach (KeyValuePair<int, string> Item in ListaItemEdoCivil)
            {
                item = new ComboboxItem();
                item.Value = Item.Key;
                item.Text = Item.Value;

                ddl_CteEdoCivil.Items.Add(item);
                ddl_AvalEdoCivil.Items.Add(item);
            }

            ddl_CteEdoCivil.SelectedIndex = 0;
            ddl_AvalEdoCivil.SelectedIndex = 0;
        }

        private void FRM_HOJA_VERDE_Load(object sender, EventArgs e)
        {
        }


        private void btn_guardar_Click(object sender, EventArgs e)
        {
            Dispose();
            //Guardar_Actualizar_Hoja(sender, e, 1);
        }

        private void actualizar_Click(object sender, EventArgs e)
        {
            Guardar_Actualizar_Hoja(sender, e, 2);
        }

        private void Guardar_Actualizar_Hoja(object sender, EventArgs e, int tipo)
        {
        }

        private void txt_CteEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Función para que sólo se acepten números

            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_CteConyugeEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Función para que sólo se acepten números

            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_AvalEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Función para que sólo se acepten números

            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_AvalConyugeEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Función para que sólo se acepten números

            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_Importe_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (e.KeyChar == '.')
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_CteEmpIngresos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (e.KeyChar == '.')
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_CteConyugeEmpIngresos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (e.KeyChar == '.')
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_AvalEmpIngresos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (e.KeyChar == '.')
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void txt_AvalConyugeEmpIngresos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (e.KeyChar == '.')
                e.Handled = false;
            else if (char.IsControl(e.KeyChar)) //Permite teclas de contorl como retroceso
                e.Handled = false;
            else
                //el resto de las teclas se desactiva
                e.Handled = true;
        }

        private void ddl_CteEdoCivil_SelectedIndexChanged(object sender, EventArgs e)
        {
            //SI EL COMBO DE EDOCIVIL SE SELECCIONA CASADO O UNION LIBRE, SE HABILITAN LOS CAMPOS DEL CONYUGE
            ComboboxItem cbxMember = ddl_CteEdoCivil.Items[ddl_CteEdoCivil.SelectedIndex] as ComboboxItem;
            //if (ddl_CteEdoCivil.SelectedValue.ToString().Equals("2") || ddl_CteEdoCivil.SelectedValue.ToString().Equals("3")) // safety check
            if (cbxMember.Value.Equals(2) || cbxMember.Value.Equals(3))
            {
                ///Label Obligatorio
                ///
                ///
                lbl_ObligatorioConyugeCte.Visible = true;
                lbl_ObligatorioEdadConyugeCte.Visible = true;
                lbl_ObligatorioFechaNacCnyugeCte.Visible = true;

                dtp_CteConyugeFechaNacimiento.Enabled = true;
                txt_CteConyuge.Enabled = true;
                txt_CteConyugeEdad.Enabled = true;
                ddl_CteConyugeEmpPeriodoIngresos.Enabled = true;
                txt_CteConyugeEmpPuestoJefe.Enabled = true;
                txt_CteConyugeEmpColonia.Enabled = true;
                txt_CteConyugeEmpIngresos.Enabled = true;
                txt_CteConyugeEmpAntMunicipio.Enabled = true;
                txt_CteConyugeEmpMunicipio.Enabled = true;
                txt_CteConyugeEmpAntColonia.Enabled = true;
                txt_CteConyugeEmpTelefono.Enabled = true;
                txt_CteConyugeEmpAntDomicilio.Enabled = true;
                txt_CteConyugeEmpAntEmpresa.Enabled = true;
                txt_CteConyugeEmpCruces.Enabled = true;
                txt_CteConyugeEmpDomicilio.Enabled = true;
                txt_CteConyugeEmpAntiguedad.Enabled = true;
                txt_CteConyugeEmpJefe.Enabled = true;
                txt_CteConyugeEmpEmpresa.Enabled = true;
                txt_CteConyugeEmpDpto.Enabled = true;
                txt_CteConyugeEmpAntCp.Enabled = true;
                txt_CteConyugeEmpCp.Enabled = true;
                txt_CteConyugeEmpFunciones.Enabled = true;
            }
            else
            {
                lbl_ObligatorioConyugeCte.Visible = false;
                lbl_ObligatorioEdadConyugeCte.Visible = false;
                lbl_ObligatorioFechaNacCnyugeCte.Visible = false;


                dtp_CteConyugeFechaNacimiento.Enabled = false;
                txt_CteConyuge.Enabled = false;
                txt_CteConyugeEdad.Enabled = false;
                ddl_CteConyugeEmpPeriodoIngresos.Enabled = false;
                txt_CteConyugeEmpPuestoJefe.Enabled = false;
                txt_CteConyugeEmpColonia.Enabled = false;
                txt_CteConyugeEmpIngresos.Enabled = false;
                txt_CteConyugeEmpAntMunicipio.Enabled = false;
                txt_CteConyugeEmpMunicipio.Enabled = false;
                txt_CteConyugeEmpAntColonia.Enabled = false;
                txt_CteConyugeEmpTelefono.Enabled = false;
                txt_CteConyugeEmpAntDomicilio.Enabled = false;
                txt_CteConyugeEmpAntEmpresa.Enabled = false;
                txt_CteConyugeEmpCruces.Enabled = false;
                txt_CteConyugeEmpDomicilio.Enabled = false;
                txt_CteConyugeEmpAntiguedad.Enabled = false;
                txt_CteConyugeEmpJefe.Enabled = false;
                txt_CteConyugeEmpEmpresa.Enabled = false;
                txt_CteConyugeEmpDpto.Enabled = false;
                txt_CteConyugeEmpAntCp.Enabled = false;
                txt_CteConyugeEmpCp.Enabled = false;
                txt_CteConyugeEmpFunciones.Enabled = false;
            }
        }

        private void rdb_CteRef1EsClienteSi_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb_CteRef1EsClienteSi.Checked)
                txt_CteRef1NumCuenta.Enabled = true;
        }

        private void rdb_CteRef1EsClienteNo_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb_CteRef1EsClienteNo.Checked)
                txt_CteRef1NumCuenta.Enabled = false;
        }

        private void rdb_CteRef2EsClienteSi_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb_CteRef2EsClienteSi.Checked)
                txt_CteRef2NumCuenta.Enabled = true;
        }

        private void rdb_CteRef2EsClienteNo_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb_CteRef2EsClienteNo.Checked)
                txt_CteRef2NumCuenta.Enabled = false;
        }

        private void ddl_AvalEdoCivil_SelectedIndexChanged(object sender, EventArgs e)
        {
            //SI EL COMBO DE EDOCIVIL SE SELECCIONA CASADO O UNION LIBRE, SE HABILITAN LOS CAMPOS DEL CONYUGE
            ComboboxItem cbxMember = ddl_AvalEdoCivil.Items[ddl_AvalEdoCivil.SelectedIndex] as ComboboxItem;
            if (cbxMember.Value.Equals(2) || cbxMember.Value.Equals(3)) // safety check
                //if (ddl_AvalEdoCivil.SelectedValue.ToString().Equals("2") || ddl_AvalEdoCivil.SelectedValue.ToString().Equals("3")) // safety check
            {
                lbl_Aval3.Visible = true; //Aval Conyuge
                lbl_Aval10.Visible = true; //Aval Conyuge Edad
                lbl_Aval12.Visible = true; // Aval Conyuge Fecha Nac

                dtp_AvalConyugeFechaNacimiento.Enabled = true;
                txt_AvalConyuge.Enabled = true;
                txt_AvalConyugeEdad.Enabled = true;
                ddl_AvalConyugeEmpPeriodoIngresos.Enabled = true;
                txt_AvalConyugeEmpPuestoJefe.Enabled = true;
                txt_AvalConyugeEmpColonia.Enabled = true;
                txt_AvalConyugeEmpIngresos.Enabled = true;
                txt_AvalConyugeEmpAntMunicipio.Enabled = true;
                txt_AvalConyugeEmpMunicipio.Enabled = true;
                txt_AvalConyugeEmpAntColonia.Enabled = true;
                txt_AvalConyugeEmpTelefono.Enabled = true;
                txt_AvalConyugeEmpAntDomicilio.Enabled = true;
                txt_AvalConyugeEmpAntEmpresa.Enabled = true;
                txt_AvalConyugeEmpCruces.Enabled = true;
                txt_AvalConyugeEmpDomicilio.Enabled = true;
                txt_AvalConyugeEmpAntiguedad.Enabled = true;
                txt_AvalConyugeEmpJefe.Enabled = true;
                txt_AvalConyugeEmpEmpresa.Enabled = true;
                txt_AvalConyugeEmpDpto.Enabled = true;
                txt_AvalConyugeEmpAntCp.Enabled = true;
                txt_AvalConyugeEmpCp.Enabled = true;
                txt_AvalConyugeEmpFunciones.Enabled = true;
            }
            else
            {
                lbl_Aval3.Visible = false; //Aval Conyuge
                lbl_Aval10.Visible = false; //Aval Conyuge Edad
                lbl_Aval12.Visible = false; // Aval Conyuge Fecha Nac

                dtp_AvalConyugeFechaNacimiento.Enabled = false;
                txt_AvalConyuge.Enabled = false;
                txt_AvalConyugeEdad.Enabled = false;
                ddl_AvalConyugeEmpPeriodoIngresos.Enabled = false;
                txt_AvalConyugeEmpPuestoJefe.Enabled = false;
                txt_AvalConyugeEmpColonia.Enabled = false;
                txt_AvalConyugeEmpIngresos.Enabled = false;
                txt_AvalConyugeEmpAntMunicipio.Enabled = false;
                txt_AvalConyugeEmpMunicipio.Enabled = false;
                txt_AvalConyugeEmpAntColonia.Enabled = false;
                txt_AvalConyugeEmpTelefono.Enabled = false;
                txt_AvalConyugeEmpAntDomicilio.Enabled = false;
                txt_AvalConyugeEmpAntEmpresa.Enabled = false;
                txt_AvalConyugeEmpCruces.Enabled = false;
                txt_AvalConyugeEmpDomicilio.Enabled = false;
                txt_AvalConyugeEmpAntiguedad.Enabled = false;
                txt_AvalConyugeEmpJefe.Enabled = false;
                txt_AvalConyugeEmpEmpresa.Enabled = false;
                txt_AvalConyugeEmpDpto.Enabled = false;
                txt_AvalConyugeEmpAntCp.Enabled = false;
                txt_AvalConyugeEmpCp.Enabled = false;
                txt_AvalConyugeEmpFunciones.Enabled = false;
            }
        }

        private void btn_Imprimir_Click(object sender, EventArgs e)
        {
        }

        private void chk_SoloAval_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_SoloAval.Checked)
            {
                ///Solo se muestran los campos de captura para el Aval
                ///
                chk_SoloReferencias.Enabled = false;
                chk_SinAval.Checked = false;
                chk_SinAval.Enabled = false;
                BloquearLimpiarControles(gb_DGCte, "ddl_CteEdoCivil");
                BloquearLimpiarControles(gb_DECte, null);
                BloquearLimpiarControles(gb_DEConyugeCte, null);
                BloquearLimpiarControles(gb_DRPersonales, null);
                BloquearLimpiarControles(gb_RCCTE, null);
                BloquearLimpiarControles(gb_RBCTE, null);

                gb_DGCte.Visible = false;
                gb_DECte.Visible = false;
                gb_DEConyugeCte.Visible = false;
                gb_DRPersonales.Visible = false;
                gb_RBCTE.Visible = false;
                gb_RCCTE.Visible = false;
                gb_DGAval.Location = new Point(12, 160);
                gb_DEAval.Location = new Point(12, 535);
                gb_DEConyugeAval.Location = new Point(12, 897);
                gb_RCAval.Location = new Point(12, 1167);
                gb_RBAval.Location = new Point(12, 1237);
                btn_guardar.Location = new Point(773, 1357);
                btn_actualizar.Location = new Point(773, 1357);
                btn_Imprimir.Location = new Point(773, 1357);
            }
            else
            {
                ///Se vuelven a mostrar todos los campos
                ///
                chk_SinAval.Enabled = true;
                chk_SoloReferencias.Enabled = true;
                HabilitarControles(gb_DGCte);
                HabilitarControles(gb_DEConyugeCte);
                ddl_CteEdoCivil.SelectedIndex = 0;
                ddl_CteEdoCivil_SelectedIndexChanged(ddl_CteEdoCivil, new EventArgs());
                HabilitarControles(gb_DECte);
                HabilitarControles(gb_DRPersonales);
                HabilitarControles(gb_RCCTE);
                HabilitarControles(gb_RBCTE);

                gb_DGCte.Visible = true;
                gb_DECte.Visible = true;
                gb_DEConyugeCte.Visible = true;
                gb_DRPersonales.Visible = true;
                gb_RBCTE.Visible = true;
                gb_RCCTE.Visible = true;
                gb_DGAval.Location = new Point(12, 1553);
                gb_DEAval.Location = new Point(12, 1922);
                gb_DEConyugeAval.Location = new Point(12, 2270);
                gb_RCAval.Location = new Point(12, 2528);
                gb_RBAval.Location = new Point(12, 2597);
                btn_guardar.Location = new Point(773, 2709);
                btn_actualizar.Location = new Point(773, 2709);
                btn_Imprimir.Location = new Point(773, 2709);
            }
        }

        private void chk_CteNoTrabaja_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_CteNoTrabaja.Checked)
            {
                BloquearLimpiarControles(gb_DECte, "txt_CteEmpObservaciones", sender);

                chk_CteNoTrabaja.Enabled = true;
                lbl_CteNoTrabaja.Enabled = true;
                txt_CteEmpObservaciones.Enabled = true;
                txt_CteEmpObservaciones.Focus();

                string nombre = "";
                for (int i = 1; i < 9; i++)
                {
                    nombre = "lbl_EmpCte" + i;
                    Control[] matches = gb_ObligatorioDECte.Controls.Find(nombre, true);
                    matches[0].Visible = false;
                }
            }
            else
            {
                HabilitarControles(gb_DECte);

                string nombre = "";
                for (int i = 1; i < 9; i++)
                {
                    nombre = "lbl_EmpCte" + i;
                    Control[] matches = gb_ObligatorioDECte.Controls.Find(nombre, true);
                    matches[0].Visible = true;
                }
            }
        }

        private void chk_SinAval_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_SinAval.Checked)
            {
                BloquearLimpiarControles(gb_DGAval, "ddl_AvalEdoCivil", sender);
                BloquearLimpiarControles(gb_DEAval, null);
                chk_AvalNoTrabaja_CheckedChanged(chk_AvalNoTrabaja, new EventArgs());
                BloquearLimpiarControles(gb_DEAval, null);
                BloquearLimpiarControles(gb_DEConyugeAval, null);
                BloquearLimpiarControles(gb_RCAval, null);
                BloquearLimpiarControles(gb_RBAval, null);
                chk_SinAval.Enabled = true;


                //Ocultar * obligatorio
                string nombre = "";
                for (int i = 1; i < 16; i++)
                {
                    nombre = "lbl_Aval" + i;
                    Control[] matches = gb_ObligatorioDGAval.Controls.Find(nombre, true);
                    matches[0].Visible = false;
                }

                for (int i = 1; i < 9; i++)
                {
                    nombre = "lbl_AvalEmp" + i;
                    Control[] matches = gb_ObligatorioDEAval.Controls.Find(nombre, true);
                    matches[0].Visible = false;
                }
            }
            else
            {
                HabilitarControles(gb_DGAval);
                HabilitarControles(gb_DEAval);
                HabilitarControles(gb_DEConyugeAval);
                ddl_AvalEdoCivil.SelectedIndex = 0;
                ddl_AvalEdoCivil_SelectedIndexChanged(ddl_AvalEdoCivil, new EventArgs());
                HabilitarControles(gb_RCAval);
                HabilitarControles(gb_RBAval);

                string nombre = "";
                for (int i = 1; i < 16; i++)
                {
                    nombre = "lbl_Aval" + i;
                    Control[] matches = gb_ObligatorioDGAval.Controls.Find(nombre, true);
                    matches[0].Visible = true;
                }
            }

            ddl_AvalEdoCivil.SelectedIndex = 0; // Siempre empieza seleccionado SOLTERO(A)
        }

        private void BloquearLimpiarControles(GroupBox gb, string evitar, object sender = null)
        {
            foreach (Control item in gb.Controls)
            {
                item.Enabled = false;
                TextBox TB = item as TextBox;
                if (TB != null && TB.Name != evitar)
                {
                    TB.Text = "";
                }
                else
                {
                    ComboBox cmb = item as ComboBox;

                    foreach (Control item1 in item.Controls)
                    {
                        TextBox TB1 = item1 as TextBox;
                        if (TB1 != null && TB1.Name != evitar)
                        {
                            TB1.Text = "";
                        }
                        else
                        {
                            ComboBox cmb1 = item1 as ComboBox;
                            if (cmb1 != null)
                                if (cmb1.Name != evitar)
                                    cmb1.SelectedIndex = -1;


                            DateTimePicker dtp1 = item1 as DateTimePicker;

                            if (dtp1 != null)
                                dtp1.Value = DateTime.Parse("01-01-1900");

                            CheckBox chk1 = item1 as CheckBox;
                            if (chk1 != null)
                            {
                                CheckBox checkbox1 = (CheckBox)sender;
                                if (checkbox1 != null)
                                {
                                    if (!chk1.Name.Equals(checkbox1.Name))
                                        chk1.Checked = false;
                                }
                                else
                                {
                                    chk1.Checked = false;
                                }
                            }

                            RadioButton rdb1 = item1 as RadioButton;
                            if (rdb1 != null)
                                rdb1.Checked = false;
                        }
                    }

                    if (cmb != null)
                        if (cmb.Name != evitar)
                            cmb.SelectedIndex = -1;

                    DateTimePicker dtp = item as DateTimePicker;

                    if (dtp != null)
                        dtp.Value = DateTime.Parse("01-01-1900");

                    CheckBox chk = item as CheckBox;
                    if (chk != null)
                    {
                        CheckBox checkbox = (CheckBox)sender;
                        if (checkbox != null)
                        {
                            if (!chk.Name.Equals(checkbox.Name))
                                chk.Checked = false;
                        }
                        else
                        {
                            chk.Checked = false;
                        }
                    }

                    RadioButton rdb = item as RadioButton;
                    if (rdb != null)
                        rdb.Checked = false;
                }
            }
        }

        private void HabilitarControles(GroupBox gb)
        {
            foreach (Control item in gb.Controls)
            {
                DateTimePicker dtp = item as DateTimePicker;
                item.Enabled = true;

                if (dtp != null) dtp.Value = DateTime.Now;

                foreach (Control item1 in item.Controls)
                {
                    DateTimePicker dtp1 = item1 as DateTimePicker;
                    if (dtp1 != null)
                        dtp1.Value = DateTime.Now;
                }
            }
        }

        private bool ValidarCampos(GroupBox gb, string tipo)
        {
            foreach (Control item in gb.Controls)
            {
                TextBox TB = item as TextBox;


                if (TB != null)
                {
                    if (!TB.Name.Equals("txt_" + tipo + "Cp")) //El campo Codigo Postal no es obligatorio.
                        if (!TB.Name.Equals("txt_" + tipo + "Conyuge") &&
                            !TB.Name.Equals("txt_" + tipo +
                                            "ConyugeEdad")) //Si el Aval no es Casada o vive en unión libre.. los campos del conyuge no son obligatorios
                            if (TB.Text.Equals(""))
                            {
                                MessageBox.Show("Todos los campos marcados son Obligatorios " + TB.Name, "Usuario",
                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return false;
                            }

                    if (TB.Name.Equals("txt_" + tipo + "Edad"))
                        if (int.Parse(TB.Text) <= 0)
                        {
                            MessageBox.Show("La Edad debe ser mayor a 0", "Usuario", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            return false;
                        }
                }
                else
                {
                    ComboBox cmb = item as ComboBox;
                    if (cmb != null)
                        //MessageBox.Show(cmb.SelectedIndex.ToString());
                        if (cmb.SelectedIndex < 0)
                        {
                            MessageBox.Show("Todos los campos marcados son Obligatorios " + cmb.Name, "Usuario",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;
                        }
                }
            }

            return true;
        }

        private void chk_AvalNoTrabaja_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_AvalNoTrabaja.Checked)
            {
                BloquearLimpiarControles(gb_DEAval, "txt_AvalEmpObservaciones", sender);
                chk_AvalNoTrabaja.Enabled = true;
                lbl_AvalNoTrabaja.Enabled = true;
                txt_AvalEmpObservaciones.Enabled = true;
                txt_AvalEmpObservaciones.Focus();

                //Ocultar * obligatorio
                string nombre = "";
                for (int i = 1; i < 9; i++)
                {
                    nombre = "lbl_AvalEmp" + i;
                    Control[] matches = gb_ObligatorioDEAval.Controls.Find(nombre, true);
                    matches[0].Visible = false;
                }
            }
            else
            {
                HabilitarControles(gb_DEAval);

                string nombre = "";
                for (int i = 1; i < 9; i++)
                {
                    nombre = "lbl_AvalEmp" + i;
                    Control[] matches = gb_ObligatorioDEAval.Controls.Find(nombre, true);
                    matches[0].Visible = true;
                }
            }
        }

        private void chk_SoloReferencias_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_SoloReferencias.Checked)
            {
                ///Solo se muestran los campos de captura para las Referencias Personales
                ///
                chk_SoloAval.Enabled = false;
                BloquearLimpiarControles(gb_DGCte, "ddl_CteEdoCivil");
                BloquearLimpiarControles(gb_DECte, null);
                BloquearLimpiarControles(gb_DEConyugeCte, null);
                BloquearLimpiarControles(gb_RCCTE, null);
                BloquearLimpiarControles(gb_RBCTE, null);
                BloquearLimpiarControles(gb_DGAval, "ddl_AvalEdoCivil");
                BloquearLimpiarControles(gb_DEAval, null);
                BloquearLimpiarControles(gb_DEConyugeAval, null);
                BloquearLimpiarControles(gb_RCAval, null);
                BloquearLimpiarControles(gb_RBAval, null);

                gb_DGCte.Visible = false;
                gb_DECte.Visible = false;
                gb_DEConyugeCte.Visible = false;
                gb_RBCTE.Visible = false;
                gb_RCCTE.Visible = false;
                gb_DGAval.Visible = false;
                gb_DEAval.Visible = false;
                gb_DEConyugeAval.Visible = false;
                gb_RCAval.Visible = false;
                gb_RBAval.Visible = false;

                //gb_DRPersonales.Location = new System.Drawing.Point(12, 1162);
                gb_DRPersonales.Location = new Point(12, 160);
                btn_guardar.Location = new Point(773, 360);
                btn_actualizar.Location = new Point(773, 360);
                btn_Imprimir.Location = new Point(773, 360);
            }
            else
            {
                chk_SoloAval.Enabled = true;
                HabilitarControles(gb_DGCte);
                HabilitarControles(gb_DECte);
                HabilitarControles(gb_DEConyugeCte);
                ddl_CteEdoCivil_SelectedIndexChanged(ddl_CteEdoCivil, new EventArgs());
                HabilitarControles(gb_RCCTE);
                HabilitarControles(gb_RBCTE);
                HabilitarControles(gb_DGAval);
                HabilitarControles(gb_DEAval);
                HabilitarControles(gb_DEConyugeAval);
                ddl_AvalEdoCivil_SelectedIndexChanged(ddl_AvalEdoCivil, new EventArgs());
                HabilitarControles(gb_RCAval);
                HabilitarControles(gb_RBAval);


                gb_DGCte.Visible = true;
                gb_DECte.Visible = true;
                gb_DEConyugeCte.Visible = true;
                gb_RBCTE.Visible = true;
                gb_RCCTE.Visible = true;
                gb_DGAval.Visible = true;
                gb_DEAval.Visible = true;
                gb_DEConyugeAval.Visible = true;
                gb_RCAval.Visible = true;
                gb_RBAval.Visible = true;

                gb_DRPersonales.Location = new Point(12, 1162);
                btn_guardar.Location = new Point(773, 2709);
                btn_actualizar.Location = new Point(773, 2709);
                btn_Imprimir.Location = new Point(773, 2709);
            }
        }


        // evita que se escriban mas de 255 caracteres 
        private void txt_CteObservaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_CteObservaciones.Text.Count() >= 255 && Convert.ToInt32(e.KeyChar) != 8)
            {
                e.Handled = true;
                MessageBox.Show("El limite de texto es de 255 caracteres", "Limite", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                e.Handled = false;
            }
        }

        // evita el ctrl + v para pegar algub texto
        private void txt_CteObservaciones_KeyDown(object sender, KeyEventArgs e)
        {
            Clipboard.Clear();
        }

        // evita pegar texto click derecho 
        private void txt_CteObservaciones_MouseDown(object sender, MouseEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_CteEmpObservaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_CteEmpObservaciones.Text.Count() >= 255 && Convert.ToInt32(e.KeyChar) != 8)
            {
                e.Handled = true;
                MessageBox.Show("El limite de texto es de 255 caracteres", "Limite", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                e.Handled = false;
            }
        }

        private void txt_CteEmpObservaciones_KeyDown(object sender, KeyEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_CteEmpObservaciones_MouseDown(object sender, MouseEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_AvalObservaciones_KeyDown(object sender, KeyEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_AvalObservaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_AvalObservaciones.Text.Count() >= 255 && Convert.ToInt32(e.KeyChar) != 8)
            {
                e.Handled = true;
                MessageBox.Show("El limite de texto es de 255 caracteres", "Limite", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                e.Handled = false;
            }
        }

        private void txt_AvalObservaciones_MouseDown(object sender, MouseEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_AvalEmpObservaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_AvalEmpObservaciones.Text.Count() >= 255 && Convert.ToInt32(e.KeyChar) != 8)
            {
                e.Handled = true;
                MessageBox.Show("El limite de texto es de 255 caracteres", "Limite", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                e.Handled = false;
            }
        }

        private void txt_AvalEmpObservaciones_KeyDown(object sender, KeyEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_AvalEmpObservaciones_MouseDown(object sender, MouseEventArgs e)
        {
            Clipboard.Clear();
        }

        private void txt_CteTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || e.KeyChar == 8)
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_CteEmpTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || e.KeyChar == 8)
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_CteConyugeEmpTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || e.KeyChar == 8)
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}