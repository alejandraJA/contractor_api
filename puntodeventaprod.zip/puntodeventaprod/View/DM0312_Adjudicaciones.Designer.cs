﻿namespace PuntoVenta.View
{
    partial class DM0312_Adjudicaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_Adjudicaciones));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbx_menuPuntoVenta = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Situaciones = new System.Windows.Forms.Button();
            this.btn_InformacionCliente = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.Panel_UsuarioEstatus = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.lbl_Estatus = new System.Windows.Forms.Label();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_DatosGenerales = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_cliente = new System.Windows.Forms.Label();
            this.cbx_Cliente = new System.Windows.Forms.ComboBox();
            this.txt_ClienteNombre = new System.Windows.Forms.TextBox();
            this.lbl_Agente = new System.Windows.Forms.Label();
            this.cbx_Agente = new System.Windows.Forms.ComboBox();
            this.lbl_canal = new System.Windows.Forms.Label();
            this.cbx_Canal = new System.Windows.Forms.ComboBox();
            this.lbl_condicion = new System.Windows.Forms.Label();
            this.cbx_Condicion = new System.Windows.Forms.ComboBox();
            this.lbl_almacen = new System.Windows.Forms.Label();
            this.cbx_Almacen = new System.Windows.Forms.ComboBox();
            this.lbl_Concepto = new System.Windows.Forms.Label();
            this.cbx_Concepto = new System.Windows.Forms.ComboBox();
            this.lbl_Referencia = new System.Windows.Forms.Label();
            this.txt_Referencia = new System.Windows.Forms.TextBox();
            this.lbl_MonederoRedimido = new System.Windows.Forms.Label();
            this.txt_Pago = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Comentario = new System.Windows.Forms.Label();
            this.txt_Comentario = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Observaciones = new System.Windows.Forms.Label();
            this.txt_Observaciones = new System.Windows.Forms.TextBox();
            this.panel_Detalle = new System.Windows.Forms.Panel();
            this.btnImportExcel = new System.Windows.Forms.Button();
            this.txt_DetalleInformacion = new System.Windows.Forms.TextBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.btn_Detalle = new System.Windows.Forms.Button();
            this.gbx_VentaDetalle = new System.Windows.Forms.FlowLayoutPanel();
            this.lblUnidad = new System.Windows.Forms.Label();
            this.lblDescr = new System.Windows.Forms.Label();
            this.dvg_detalleVenta = new System.Windows.Forms.DataGridView();
            this.lbl_subt = new System.Windows.Forms.Label();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.lbl_Impuestos = new System.Windows.Forms.Label();
            this.txtImpuestos = new System.Windows.Forms.TextBox();
            this.lbl_total = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.lbl_Empresa = new System.Windows.Forms.Label();
            this.gbx_menuPuntoVenta.SuspendLayout();
            this.Panel_UsuarioEstatus.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panelContactos.SuspendLayout();
            this.gbx_DatosGenerales.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel_Detalle.SuspendLayout();
            this.gbx_VentaDetalle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).BeginInit();
            this.SuspendLayout();
            // 
            // gbx_menuPuntoVenta
            // 
            this.gbx_menuPuntoVenta.AutoScroll = true;
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_Regresar);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_Situaciones);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_InformacionCliente);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_ayuda);
            this.gbx_menuPuntoVenta.Location = new System.Drawing.Point(3, 64);
            this.gbx_menuPuntoVenta.Name = "gbx_menuPuntoVenta";
            this.gbx_menuPuntoVenta.Size = new System.Drawing.Size(86, 379);
            this.gbx_menuPuntoVenta.TabIndex = 100;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.CausesValidation = false;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(76, 78);
            this.btn_Regresar.TabIndex = 25;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Situaciones
            // 
            this.btn_Situaciones.BackColor = System.Drawing.Color.White;
            this.btn_Situaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Situaciones.FlatAppearance.BorderSize = 0;
            this.btn_Situaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Situaciones.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Situaciones.Image = ((System.Drawing.Image)(resources.GetObject("btn_Situaciones.Image")));
            this.btn_Situaciones.Location = new System.Drawing.Point(3, 87);
            this.btn_Situaciones.Name = "btn_Situaciones";
            this.btn_Situaciones.Size = new System.Drawing.Size(76, 63);
            this.btn_Situaciones.TabIndex = 33;
            this.btn_Situaciones.Text = "Situaciones";
            this.btn_Situaciones.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Situaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Situaciones.UseVisualStyleBackColor = false;
            this.btn_Situaciones.Click += new System.EventHandler(this.btn_Situaciones_Click);
            // 
            // btn_InformacionCliente
            // 
            this.btn_InformacionCliente.BackColor = System.Drawing.Color.White;
            this.btn_InformacionCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_InformacionCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_InformacionCliente.FlatAppearance.BorderSize = 0;
            this.btn_InformacionCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InformacionCliente.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InformacionCliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_InformacionCliente.Image")));
            this.btn_InformacionCliente.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_InformacionCliente.Location = new System.Drawing.Point(3, 156);
            this.btn_InformacionCliente.Name = "btn_InformacionCliente";
            this.btn_InformacionCliente.Size = new System.Drawing.Size(79, 91);
            this.btn_InformacionCliente.TabIndex = 29;
            this.btn_InformacionCliente.Text = "Informacion del Cliente (Crtl-I)";
            this.btn_InformacionCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InformacionCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InformacionCliente.UseVisualStyleBackColor = false;
            this.btn_InformacionCliente.Click += new System.EventHandler(this.btn_InformacionCliente_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(3, 253);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(79, 60);
            this.btn_ayuda.TabIndex = 32;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(95, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(599, 55);
            this.txt_Comentarios.TabIndex = 106;
            // 
            // Panel_UsuarioEstatus
            // 
            this.Panel_UsuarioEstatus.Controls.Add(this.textBox1);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_Usuario);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_Estatus);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_ID);
            this.Panel_UsuarioEstatus.Location = new System.Drawing.Point(700, 0);
            this.Panel_UsuarioEstatus.Name = "Panel_UsuarioEstatus";
            this.Panel_UsuarioEstatus.Size = new System.Drawing.Size(386, 61);
            this.Panel_UsuarioEstatus.TabIndex = 107;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(382, 20);
            this.textBox1.TabIndex = 117;
            this.textBox1.Text = "LOS CAMPOS CON * ES OBLIGATORIO LA CAPTURA DE DATOS";
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Usuario.Location = new System.Drawing.Point(3, 28);
            this.lbl_Usuario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(125, 22);
            this.lbl_Usuario.TabIndex = 96;
            this.lbl_Usuario.Text = "Usuario";
            // 
            // lbl_Estatus
            // 
            this.lbl_Estatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estatus.Location = new System.Drawing.Point(134, 28);
            this.lbl_Estatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.lbl_Estatus.Name = "lbl_Estatus";
            this.lbl_Estatus.Size = new System.Drawing.Size(119, 22);
            this.lbl_Estatus.TabIndex = 103;
            this.lbl_Estatus.Text = "ESTATUS";
            // 
            // lbl_ID
            // 
            this.lbl_ID.ContextMenuStrip = this.contextMenuStrip1;
            this.lbl_ID.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_ID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(259, 28);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(99, 22);
            this.lbl_ID.TabIndex = 102;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(110, 26);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copiarToolStripMenuItem.Image")));
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.CausesValidation = false;
            this.panelContactos.Controls.Add(this.gbx_DatosGenerales);
            this.panelContactos.Controls.Add(this.panel_Detalle);
            this.panelContactos.Controls.Add(this.gbx_VentaDetalle);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(95, 64);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(937, 532);
            this.panelContactos.TabIndex = 108;
            // 
            // gbx_DatosGenerales
            // 
            this.gbx_DatosGenerales.CausesValidation = false;
            this.gbx_DatosGenerales.Controls.Add(this.lbl_cliente);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Cliente);
            this.gbx_DatosGenerales.Controls.Add(this.txt_ClienteNombre);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Agente);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Agente);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_canal);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Canal);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_condicion);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Condicion);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_almacen);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Almacen);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Concepto);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Concepto);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Referencia);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Referencia);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_MonederoRedimido);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Pago);
            this.gbx_DatosGenerales.Controls.Add(this.flowLayoutPanel2);
            this.gbx_DatosGenerales.Controls.Add(this.flowLayoutPanel1);
            this.gbx_DatosGenerales.Location = new System.Drawing.Point(3, 3);
            this.gbx_DatosGenerales.Name = "gbx_DatosGenerales";
            this.gbx_DatosGenerales.Size = new System.Drawing.Size(795, 184);
            this.gbx_DatosGenerales.TabIndex = 108;
            // 
            // lbl_cliente
            // 
            this.lbl_cliente.AutoSize = true;
            this.lbl_cliente.BackColor = System.Drawing.Color.White;
            this.lbl_cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cliente.Location = new System.Drawing.Point(3, 10);
            this.lbl_cliente.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_cliente.Name = "lbl_cliente";
            this.lbl_cliente.Size = new System.Drawing.Size(57, 15);
            this.lbl_cliente.TabIndex = 1;
            this.lbl_cliente.Text = "*Cliente ";
            // 
            // cbx_Cliente
            // 
            this.cbx_Cliente.BackColor = System.Drawing.Color.White;
            this.cbx_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Cliente.FormattingEnabled = true;
            this.cbx_Cliente.Location = new System.Drawing.Point(66, 3);
            this.cbx_Cliente.MaxLength = 9;
            this.cbx_Cliente.Name = "cbx_Cliente";
            this.cbx_Cliente.Size = new System.Drawing.Size(140, 21);
            this.cbx_Cliente.TabIndex = 1;
            // 
            // txt_ClienteNombre
            // 
            this.txt_ClienteNombre.BackColor = System.Drawing.Color.White;
            this.txt_ClienteNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_ClienteNombre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ClienteNombre.Location = new System.Drawing.Point(219, 3);
            this.txt_ClienteNombre.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.txt_ClienteNombre.Name = "txt_ClienteNombre";
            this.txt_ClienteNombre.ReadOnly = true;
            this.txt_ClienteNombre.Size = new System.Drawing.Size(311, 22);
            this.txt_ClienteNombre.TabIndex = 2;
            // 
            // lbl_Agente
            // 
            this.lbl_Agente.AutoSize = true;
            this.lbl_Agente.BackColor = System.Drawing.Color.White;
            this.lbl_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Agente.Location = new System.Drawing.Point(543, 7);
            this.lbl_Agente.Margin = new System.Windows.Forms.Padding(10, 7, 3, 0);
            this.lbl_Agente.Name = "lbl_Agente";
            this.lbl_Agente.Size = new System.Drawing.Size(53, 15);
            this.lbl_Agente.TabIndex = 2;
            this.lbl_Agente.Text = "*Agente";
            // 
            // cbx_Agente
            // 
            this.cbx_Agente.BackColor = System.Drawing.Color.White;
            this.cbx_Agente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Agente.FormattingEnabled = true;
            this.cbx_Agente.Location = new System.Drawing.Point(602, 10);
            this.cbx_Agente.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Agente.MaxLength = 8;
            this.cbx_Agente.Name = "cbx_Agente";
            this.cbx_Agente.Size = new System.Drawing.Size(166, 21);
            this.cbx_Agente.TabIndex = 52;
            this.cbx_Agente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Agente_KeyPress);
            // 
            // lbl_canal
            // 
            this.lbl_canal.AutoSize = true;
            this.lbl_canal.BackColor = System.Drawing.Color.White;
            this.lbl_canal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_canal.Location = new System.Drawing.Point(3, 44);
            this.lbl_canal.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_canal.Name = "lbl_canal";
            this.lbl_canal.Size = new System.Drawing.Size(46, 15);
            this.lbl_canal.TabIndex = 3;
            this.lbl_canal.Text = "*Canal";
            // 
            // cbx_Canal
            // 
            this.cbx_Canal.BackColor = System.Drawing.Color.White;
            this.cbx_Canal.DropDownHeight = 1;
            this.cbx_Canal.DropDownWidth = 1;
            this.cbx_Canal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Canal.FormattingEnabled = true;
            this.cbx_Canal.IntegralHeight = false;
            this.cbx_Canal.Location = new System.Drawing.Point(66, 44);
            this.cbx_Canal.Margin = new System.Windows.Forms.Padding(14, 10, 3, 3);
            this.cbx_Canal.MaxLength = 2;
            this.cbx_Canal.Name = "cbx_Canal";
            this.cbx_Canal.Size = new System.Drawing.Size(140, 21);
            this.cbx_Canal.TabIndex = 4;
            // 
            // lbl_condicion
            // 
            this.lbl_condicion.AutoSize = true;
            this.lbl_condicion.BackColor = System.Drawing.Color.White;
            this.lbl_condicion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_condicion.Location = new System.Drawing.Point(219, 44);
            this.lbl_condicion.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_condicion.Name = "lbl_condicion";
            this.lbl_condicion.Size = new System.Drawing.Size(69, 15);
            this.lbl_condicion.TabIndex = 11;
            this.lbl_condicion.Text = "*Condición";
            // 
            // cbx_Condicion
            // 
            this.cbx_Condicion.BackColor = System.Drawing.Color.White;
            this.cbx_Condicion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Condicion.FormattingEnabled = true;
            this.cbx_Condicion.Location = new System.Drawing.Point(294, 44);
            this.cbx_Condicion.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Condicion.Name = "cbx_Condicion";
            this.cbx_Condicion.Size = new System.Drawing.Size(236, 21);
            this.cbx_Condicion.TabIndex = 5;
            // 
            // lbl_almacen
            // 
            this.lbl_almacen.AutoSize = true;
            this.lbl_almacen.BackColor = System.Drawing.Color.White;
            this.lbl_almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_almacen.Location = new System.Drawing.Point(543, 44);
            this.lbl_almacen.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_almacen.Name = "lbl_almacen";
            this.lbl_almacen.Size = new System.Drawing.Size(62, 15);
            this.lbl_almacen.TabIndex = 7;
            this.lbl_almacen.Text = "*Almacen";
            // 
            // cbx_Almacen
            // 
            this.cbx_Almacen.BackColor = System.Drawing.Color.White;
            this.cbx_Almacen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Almacen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Almacen.FormattingEnabled = true;
            this.cbx_Almacen.Location = new System.Drawing.Point(611, 44);
            this.cbx_Almacen.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Almacen.Name = "cbx_Almacen";
            this.cbx_Almacen.Size = new System.Drawing.Size(157, 21);
            this.cbx_Almacen.TabIndex = 6;
            this.cbx_Almacen.SelectedIndexChanged += new System.EventHandler(this.cbx_Almacen_SelectedIndexChanged);
            this.cbx_Almacen.Click += new System.EventHandler(this.cbx_Almacen_Click);
            // 
            // lbl_Concepto
            // 
            this.lbl_Concepto.AutoSize = true;
            this.lbl_Concepto.BackColor = System.Drawing.Color.White;
            this.lbl_Concepto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Concepto.Location = new System.Drawing.Point(3, 78);
            this.lbl_Concepto.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Concepto.Name = "lbl_Concepto";
            this.lbl_Concepto.Size = new System.Drawing.Size(57, 15);
            this.lbl_Concepto.TabIndex = 4;
            this.lbl_Concepto.Text = "Concepto";
            // 
            // cbx_Concepto
            // 
            this.cbx_Concepto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Concepto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Concepto.FormattingEnabled = true;
            this.cbx_Concepto.Location = new System.Drawing.Point(66, 78);
            this.cbx_Concepto.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Concepto.Name = "cbx_Concepto";
            this.cbx_Concepto.Size = new System.Drawing.Size(208, 21);
            this.cbx_Concepto.TabIndex = 59;
            this.cbx_Concepto.SelectedIndexChanged += new System.EventHandler(this.cbx_Concepto_SelectedIndexChanged);
            this.cbx_Concepto.Click += new System.EventHandler(this.cbx_Concepto_Click);
            // 
            // lbl_Referencia
            // 
            this.lbl_Referencia.AutoSize = true;
            this.lbl_Referencia.BackColor = System.Drawing.Color.White;
            this.lbl_Referencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Referencia.Location = new System.Drawing.Point(287, 81);
            this.lbl_Referencia.Margin = new System.Windows.Forms.Padding(10, 13, 3, 0);
            this.lbl_Referencia.Name = "lbl_Referencia";
            this.lbl_Referencia.Size = new System.Drawing.Size(67, 15);
            this.lbl_Referencia.TabIndex = 6;
            this.lbl_Referencia.Text = "Referencia";
            // 
            // txt_Referencia
            // 
            this.txt_Referencia.BackColor = System.Drawing.Color.White;
            this.txt_Referencia.Enabled = false;
            this.txt_Referencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Referencia.Location = new System.Drawing.Point(367, 78);
            this.txt_Referencia.Margin = new System.Windows.Forms.Padding(10, 10, 3, 3);
            this.txt_Referencia.Name = "txt_Referencia";
            this.txt_Referencia.ReadOnly = true;
            this.txt_Referencia.Size = new System.Drawing.Size(163, 22);
            this.txt_Referencia.TabIndex = 15;
            // 
            // lbl_MonederoRedimido
            // 
            this.lbl_MonederoRedimido.AutoSize = true;
            this.lbl_MonederoRedimido.BackColor = System.Drawing.Color.White;
            this.lbl_MonederoRedimido.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonederoRedimido.Location = new System.Drawing.Point(543, 78);
            this.lbl_MonederoRedimido.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_MonederoRedimido.Name = "lbl_MonederoRedimido";
            this.lbl_MonederoRedimido.Size = new System.Drawing.Size(112, 15);
            this.lbl_MonederoRedimido.TabIndex = 10;
            this.lbl_MonederoRedimido.Text = "MonederoRedimido";
            // 
            // txt_Pago
            // 
            this.txt_Pago.BackColor = System.Drawing.Color.White;
            this.txt_Pago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Pago.Location = new System.Drawing.Point(661, 78);
            this.txt_Pago.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_Pago.Name = "txt_Pago";
            this.txt_Pago.Size = new System.Drawing.Size(107, 22);
            this.txt_Pago.TabIndex = 22;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.lbl_Comentario);
            this.flowLayoutPanel2.Controls.Add(this.txt_Comentario);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 106);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(690, 34);
            this.flowLayoutPanel2.TabIndex = 110;
            // 
            // lbl_Comentario
            // 
            this.lbl_Comentario.AutoSize = true;
            this.lbl_Comentario.BackColor = System.Drawing.Color.White;
            this.lbl_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comentario.Location = new System.Drawing.Point(3, 10);
            this.lbl_Comentario.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Comentario.Name = "lbl_Comentario";
            this.lbl_Comentario.Size = new System.Drawing.Size(77, 15);
            this.lbl_Comentario.TabIndex = 17;
            this.lbl_Comentario.Text = "Comentarios";
            // 
            // txt_Comentario
            // 
            this.txt_Comentario.BackColor = System.Drawing.Color.White;
            this.txt_Comentario.Location = new System.Drawing.Point(95, 10);
            this.txt_Comentario.Margin = new System.Windows.Forms.Padding(12, 10, 3, 3);
            this.txt_Comentario.Name = "txt_Comentario";
            this.txt_Comentario.Size = new System.Drawing.Size(585, 20);
            this.txt_Comentario.TabIndex = 24;
            this.txt_Comentario.Click += new System.EventHandler(this.txt_Comentario_Click);
            this.txt_Comentario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Comentario_KeyPress);
            this.txt_Comentario.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Comentario_Validating);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lbl_Observaciones);
            this.flowLayoutPanel1.Controls.Add(this.txt_Observaciones);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 146);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(690, 32);
            this.flowLayoutPanel1.TabIndex = 110;
            // 
            // lbl_Observaciones
            // 
            this.lbl_Observaciones.AutoSize = true;
            this.lbl_Observaciones.BackColor = System.Drawing.Color.White;
            this.lbl_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Observaciones.Location = new System.Drawing.Point(3, 10);
            this.lbl_Observaciones.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Observaciones.Name = "lbl_Observaciones";
            this.lbl_Observaciones.Size = new System.Drawing.Size(87, 15);
            this.lbl_Observaciones.TabIndex = 16;
            this.lbl_Observaciones.Text = "Observaciones";
            // 
            // txt_Observaciones
            // 
            this.txt_Observaciones.BackColor = System.Drawing.Color.White;
            this.txt_Observaciones.Location = new System.Drawing.Point(96, 10);
            this.txt_Observaciones.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_Observaciones.Name = "txt_Observaciones";
            this.txt_Observaciones.Size = new System.Drawing.Size(584, 20);
            this.txt_Observaciones.TabIndex = 23;
            this.txt_Observaciones.Click += new System.EventHandler(this.txt_Observaciones_Click);
            this.txt_Observaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Observaciones_KeyPress);
            this.txt_Observaciones.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Observaciones_Validating);
            // 
            // panel_Detalle
            // 
            this.panel_Detalle.Controls.Add(this.btnImportExcel);
            this.panel_Detalle.Controls.Add(this.txt_DetalleInformacion);
            this.panel_Detalle.Controls.Add(this.BtnAdd);
            this.panel_Detalle.Controls.Add(this.btn_Detalle);
            this.panel_Detalle.Location = new System.Drawing.Point(3, 193);
            this.panel_Detalle.Name = "panel_Detalle";
            this.panel_Detalle.Size = new System.Drawing.Size(711, 57);
            this.panel_Detalle.TabIndex = 109;
            // 
            // btnImportExcel
            // 
            this.btnImportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnImportExcel.BackColor = System.Drawing.Color.White;
            this.btnImportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImportExcel.FlatAppearance.BorderSize = 0;
            this.btnImportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportExcel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnImportExcel.Image")));
            this.btnImportExcel.Location = new System.Drawing.Point(426, 3);
            this.btnImportExcel.Name = "btnImportExcel";
            this.btnImportExcel.Size = new System.Drawing.Size(155, 51);
            this.btnImportExcel.TabIndex = 107;
            this.btnImportExcel.Text = "Importar de Excel";
            this.btnImportExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImportExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnImportExcel.UseVisualStyleBackColor = false;
            this.btnImportExcel.Click += new System.EventHandler(this.btnImportExcel_Click);
            // 
            // txt_DetalleInformacion
            // 
            this.txt_DetalleInformacion.BackColor = System.Drawing.Color.White;
            this.txt_DetalleInformacion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_DetalleInformacion.Enabled = false;
            this.txt_DetalleInformacion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleInformacion.Location = new System.Drawing.Point(110, 3);
            this.txt_DetalleInformacion.Multiline = true;
            this.txt_DetalleInformacion.Name = "txt_DetalleInformacion";
            this.txt_DetalleInformacion.Size = new System.Drawing.Size(296, 51);
            this.txt_DetalleInformacion.TabIndex = 105;
            // 
            // BtnAdd
            // 
            this.BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnAdd.BackColor = System.Drawing.Color.White;
            this.BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAdd.FlatAppearance.BorderSize = 0;
            this.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAdd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.Image = ((System.Drawing.Image)(resources.GetObject("BtnAdd.Image")));
            this.BtnAdd.Location = new System.Drawing.Point(587, 3);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(121, 51);
            this.BtnAdd.TabIndex = 99;
            this.BtnAdd.Text = "Agregar";
            this.BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // btn_Detalle
            // 
            this.btn_Detalle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Detalle.BackColor = System.Drawing.Color.White;
            this.btn_Detalle.FlatAppearance.BorderSize = 0;
            this.btn_Detalle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Detalle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Detalle.Image = ((System.Drawing.Image)(resources.GetObject("btn_Detalle.Image")));
            this.btn_Detalle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Detalle.Location = new System.Drawing.Point(3, 3);
            this.btn_Detalle.Name = "btn_Detalle";
            this.btn_Detalle.Size = new System.Drawing.Size(96, 51);
            this.btn_Detalle.TabIndex = 98;
            this.btn_Detalle.Text = "Detalle";
            this.btn_Detalle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Detalle.UseVisualStyleBackColor = false;
            // 
            // gbx_VentaDetalle
            // 
            this.gbx_VentaDetalle.Controls.Add(this.lblUnidad);
            this.gbx_VentaDetalle.Controls.Add(this.lblDescr);
            this.gbx_VentaDetalle.Controls.Add(this.dvg_detalleVenta);
            this.gbx_VentaDetalle.Controls.Add(this.lbl_subt);
            this.gbx_VentaDetalle.Controls.Add(this.txtSubTotal);
            this.gbx_VentaDetalle.Controls.Add(this.lbl_Impuestos);
            this.gbx_VentaDetalle.Controls.Add(this.txtImpuestos);
            this.gbx_VentaDetalle.Controls.Add(this.lbl_total);
            this.gbx_VentaDetalle.Controls.Add(this.txtTotal);
            this.gbx_VentaDetalle.Controls.Add(this.flowLayoutPanel5);
            this.gbx_VentaDetalle.Location = new System.Drawing.Point(3, 256);
            this.gbx_VentaDetalle.Name = "gbx_VentaDetalle";
            this.gbx_VentaDetalle.Size = new System.Drawing.Size(931, 273);
            this.gbx_VentaDetalle.TabIndex = 100;
            // 
            // lblUnidad
            // 
            this.lblUnidad.AutoSize = true;
            this.lblUnidad.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnidad.Location = new System.Drawing.Point(3, 10);
            this.lblUnidad.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lblUnidad.Name = "lblUnidad";
            this.lblUnidad.Size = new System.Drawing.Size(56, 19);
            this.lblUnidad.TabIndex = 46;
            this.lblUnidad.Text = "Unidad";
            // 
            // lblDescr
            // 
            this.lblDescr.AutoSize = true;
            this.lblDescr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescr.Location = new System.Drawing.Point(72, 10);
            this.lblDescr.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lblDescr.Name = "lblDescr";
            this.lblDescr.Size = new System.Drawing.Size(88, 19);
            this.lblDescr.TabIndex = 47;
            this.lblDescr.Text = "Descripcion";
            // 
            // dvg_detalleVenta
            // 
            this.dvg_detalleVenta.AllowUserToResizeColumns = false;
            this.dvg_detalleVenta.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dvg_detalleVenta.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dvg_detalleVenta.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dvg_detalleVenta.BackgroundColor = System.Drawing.Color.Snow;
            this.dvg_detalleVenta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dvg_detalleVenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dvg_detalleVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg_detalleVenta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dvg_detalleVenta.EnableHeadersVisualStyles = false;
            this.dvg_detalleVenta.Location = new System.Drawing.Point(3, 36);
            this.dvg_detalleVenta.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.dvg_detalleVenta.Name = "dvg_detalleVenta";
            this.dvg_detalleVenta.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            this.dvg_detalleVenta.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dvg_detalleVenta.Size = new System.Drawing.Size(912, 196);
            this.dvg_detalleVenta.TabIndex = 39;
            this.dvg_detalleVenta.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dvg_detalleVenta_CellBeginEdit);
            this.dvg_detalleVenta.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellClick);
            this.dvg_detalleVenta.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellContentClick);
            this.dvg_detalleVenta.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dvg_detalleVenta_CellPainting);
            this.dvg_detalleVenta.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellValueChanged);
            this.dvg_detalleVenta.SelectionChanged += new System.EventHandler(this.dvg_detalleVenta_SelectionChanged);
            this.dvg_detalleVenta.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dvg_detalleVenta_KeyDown);
            // 
            // lbl_subt
            // 
            this.lbl_subt.AutoSize = true;
            this.lbl_subt.BackColor = System.Drawing.Color.White;
            this.lbl_subt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subt.Location = new System.Drawing.Point(3, 245);
            this.lbl_subt.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_subt.Name = "lbl_subt";
            this.lbl_subt.Size = new System.Drawing.Size(62, 15);
            this.lbl_subt.TabIndex = 51;
            this.lbl_subt.Text = "Sub Total:";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.BackColor = System.Drawing.Color.White;
            this.txtSubTotal.Enabled = false;
            this.txtSubTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubTotal.Location = new System.Drawing.Point(71, 238);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.Size = new System.Drawing.Size(92, 22);
            this.txtSubTotal.TabIndex = 53;
            // 
            // lbl_Impuestos
            // 
            this.lbl_Impuestos.AutoSize = true;
            this.lbl_Impuestos.BackColor = System.Drawing.Color.White;
            this.lbl_Impuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Impuestos.Location = new System.Drawing.Point(169, 243);
            this.lbl_Impuestos.Margin = new System.Windows.Forms.Padding(3, 8, 3, 0);
            this.lbl_Impuestos.Name = "lbl_Impuestos";
            this.lbl_Impuestos.Size = new System.Drawing.Size(65, 15);
            this.lbl_Impuestos.TabIndex = 49;
            this.lbl_Impuestos.Text = "Impuestos ";
            // 
            // txtImpuestos
            // 
            this.txtImpuestos.BackColor = System.Drawing.Color.White;
            this.txtImpuestos.Enabled = false;
            this.txtImpuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImpuestos.Location = new System.Drawing.Point(240, 238);
            this.txtImpuestos.Name = "txtImpuestos";
            this.txtImpuestos.Size = new System.Drawing.Size(126, 22);
            this.txtImpuestos.TabIndex = 52;
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.Location = new System.Drawing.Point(372, 243);
            this.lbl_total.Margin = new System.Windows.Forms.Padding(3, 8, 3, 0);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(34, 15);
            this.lbl_total.TabIndex = 48;
            this.lbl_total.Text = "Total";
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.White;
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(412, 238);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(111, 22);
            this.txtTotal.TabIndex = 50;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Location = new System.Drawing.Point(529, 238);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(366, 22);
            this.flowLayoutPanel5.TabIndex = 54;
            // 
            // lbl_Empresa
            // 
            this.lbl_Empresa.AutoSize = true;
            this.lbl_Empresa.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Empresa.Location = new System.Drawing.Point(12, 19);
            this.lbl_Empresa.Name = "lbl_Empresa";
            this.lbl_Empresa.Size = new System.Drawing.Size(59, 22);
            this.lbl_Empresa.TabIndex = 112;
            this.lbl_Empresa.Text = "label1";
            // 
            // DM0312_Adjudicaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1091, 597);
            this.Controls.Add(this.lbl_Empresa);
            this.Controls.Add(this.panelContactos);
            this.Controls.Add(this.Panel_UsuarioEstatus);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.gbx_menuPuntoVenta);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_Adjudicaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adjudicacion";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_Adjudicaciones_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_Adjudicaciones_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_Adjudicaciones_KeyDown);
            this.gbx_menuPuntoVenta.ResumeLayout(false);
            this.Panel_UsuarioEstatus.ResumeLayout(false);
            this.Panel_UsuarioEstatus.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panelContactos.ResumeLayout(false);
            this.gbx_DatosGenerales.ResumeLayout(false);
            this.gbx_DatosGenerales.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel_Detalle.ResumeLayout(false);
            this.panel_Detalle.PerformLayout();
            this.gbx_VentaDetalle.ResumeLayout(false);
            this.gbx_VentaDetalle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel gbx_menuPuntoVenta;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Situaciones;
        private System.Windows.Forms.Button btn_InformacionCliente;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.FlowLayoutPanel Panel_UsuarioEstatus;
        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.Label lbl_Estatus;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        private System.Windows.Forms.FlowLayoutPanel gbx_DatosGenerales;
        private System.Windows.Forms.Label lbl_cliente;
        private System.Windows.Forms.ComboBox cbx_Cliente;
        private System.Windows.Forms.TextBox txt_ClienteNombre;
        private System.Windows.Forms.Label lbl_Agente;
        private System.Windows.Forms.ComboBox cbx_Agente;
        private System.Windows.Forms.Label lbl_canal;
        private System.Windows.Forms.ComboBox cbx_Canal;
        private System.Windows.Forms.Label lbl_condicion;
        private System.Windows.Forms.ComboBox cbx_Condicion;
        private System.Windows.Forms.Label lbl_almacen;
        private System.Windows.Forms.ComboBox cbx_Almacen;
        private System.Windows.Forms.Label lbl_Concepto;
        private System.Windows.Forms.ComboBox cbx_Concepto;
        private System.Windows.Forms.Label lbl_Referencia;
        private System.Windows.Forms.TextBox txt_Referencia;
        private System.Windows.Forms.Label lbl_MonederoRedimido;
        private System.Windows.Forms.TextBox txt_Pago;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lbl_Observaciones;
        private System.Windows.Forms.TextBox txt_Observaciones;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label lbl_Comentario;
        private System.Windows.Forms.TextBox txt_Comentario;
        private System.Windows.Forms.Panel panel_Detalle;
        private System.Windows.Forms.TextBox txt_DetalleInformacion;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button btn_Detalle;
        private System.Windows.Forms.FlowLayoutPanel gbx_VentaDetalle;
        private System.Windows.Forms.Label lblUnidad;
        private System.Windows.Forms.Label lblDescr;
        private System.Windows.Forms.DataGridView dvg_detalleVenta;
        private System.Windows.Forms.Label lbl_subt;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.Label lbl_Impuestos;
        private System.Windows.Forms.TextBox txtImpuestos;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.Button btnImportExcel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.Label lbl_Empresa;
        private System.Windows.Forms.TextBox textBox1;

    }
}