﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_CatalogosPuntoDeVenta : Form
    {
        public static string Cliente = string.Empty;
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public static List<DM0312_MPuntoDeVentaCliente> listaEmpleados = new List<DM0312_MPuntoDeVentaCliente>();

        public static List<DM0312_MPuntoDeVentaAgente> listaAgente = new List<DM0312_MPuntoDeVentaAgente>();

        //  public static List<DM0312_MPuntoDeVentaCanales> listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
        public static List<DM0312_MPuntoDeVentaAlmacen> listaAlmacenFiltrados = new List<DM0312_MPuntoDeVentaAlmacen>();
        public static List<DM0312_MPuntoDeVentaAlmacen> listaAlmacen = new List<DM0312_MPuntoDeVentaAlmacen>();
        public static List<DM0312_MPuntoDeVentaCanales> listaCanalesFiltrados = new List<DM0312_MPuntoDeVentaCanales>();
        public int CatalogoMostrar, indice = -1;
        private DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();
        public List<DM0312_MPuntoDeVentaAgente> listaAgenteFiltrados = new List<DM0312_MPuntoDeVentaAgente>();
        public List<DM0312_MPuntoDeVentaCliente> listaEmpleadosFiltrados = new List<DM0312_MPuntoDeVentaCliente>();
        public int suc = 0;

        public DM0312_CatalogosPuntoDeVenta(int Menu)
        {
            InitializeComponent();
            CatalogoMostrar = Menu;
            Cliente = PuntoDeVenta.Codigo;
            dgv_Menu.DataSource = null;
        }

        public string codigo { get; set; }

        ~DM0312_CatalogosPuntoDeVenta()
        {
            GC.Collect();
        }

        private void DM0312_CatalogosPuntoDeVenta_Load(object sender, EventArgs e)
        {
            switch (CatalogoMostrar)
            {
                case 1:
                    lbl_Buscar1.Text = "Codigo: ";
                    lbl_Buscar2.Text = "Nombre: ";
                    btn_AgregarCanal.Visible = false;
                    Text = "Catalogo de Clientes";
                    LlenaClientes();

                    toolTip1.SetToolTip(txt_Buscar1,
                        "INGRESAR LA CUENTA DEL CLIENTE A BUSCAR, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(txt_Buscar2,
                        "INGRESAR EL NOMBRE DEL CLIENTE A BUSCAR, PUEDE BUSCARLO POR NOMBRE, APELLIDOS O AMBOS INICIANDO POR SU APELLIDO,DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(lbl_Buscar1, "CUENTA DEL CLIENTE");
                    toolTip1.SetToolTip(lbl_Buscar2, "NOMBRE DEL CLIENTE");
                    txt_Comentarios.Text =
                        "ASISTENTE PARA BUSCAR UN CLIENTE PUEDE BUSCARLO POR LA CUENTA O POR SU NOMBRE, UNA VEZ ENCONTRADO EL CLIENTE DAR DOBLE CLICK SOBRE EL PARA SEGUIR EL PROCESO";

                    break;
                case 2:
                    lbl_Buscar1.Text = "Agente: ";
                    lbl_Buscar2.Text = "Nombre: ";
                    btn_AgregarCanal.Visible = false;
                    Text = "Catalogo de Agentes";
                    LlenaAgente();

                    toolTip1.SetToolTip(txt_Buscar1,
                        "INGRESAR LA NOMINA DEL AGENTE, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(txt_Buscar2,
                        "INGRESAR EL NOMBRE DEL AGENTE, PUEDE BUSCARLO POR NOMBRE, APELLIDOS O AMBOS INICIANDO POR SU APELLIDO, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(lbl_Buscar1, "NOMINA DEL AGENTE");
                    toolTip1.SetToolTip(lbl_Buscar2, "NOMBRE DEL AGENTE");
                    txt_Comentarios.Text =
                        "ASISTENTE DE AGENTES DONDE SE PUEDE BUSCAR EL AGENTE QUE SE DESEA ASIGNAR A LA VENTA, DAR DOBLE CLICK SOBRE EL AGENTE PARA PODER AGREGARLO A LA VENTA";
                    break;
                case 3:
                    lbl_Buscar1.Visible = false;
                    lbl_Buscar2.Visible = false;
                    txt_Buscar1.Visible = false;
                    txt_Buscar2.Visible = false;
                    lbl_Buscar.Visible = false;
                    btn_AgregarCanal.Visible = true;
                    LlenaCanalCliente();

                    toolTip1.SetToolTip(btn_AgregarCanal,
                        "SELECCIONAR PARA AGREGAR UN NUEVO CANAL AL CLIENTE SELECCIONADO");
                    txt_Comentarios.Text = "ASISTENTE DONDE SE MUESTRAN LOS CANALES DEL CLIENTE: " + Cliente +
                                           " DAR DOBLE CLICK EN EL CANAL QUE SE DESEA VENDER SI NO SE ENCUENTRA EL CANAL DAR CLICK AL BOTON DE AGREGAR CANAL";
                    Text = "Catalogo de Canales";
                    break;
                case 4:
                    lbl_Buscar1.Text = "Almacen: ";
                    lbl_Buscar2.Text = "Nombre: ";
                    btn_AgregarCanal.Visible = false;
                    LlenaAlmacen();

                    toolTip1.SetToolTip(txt_Buscar1,
                        "INGRESAR LA CLAVE DEL ALMACEN QUE DESEA BUSCAR, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(txt_Buscar2,
                        "INGRESAR EL NOMBRE DEL ALMACEN QUE DESEA BUSCAR, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(lbl_Buscar1, "CLAVE DEL ALMACEN");
                    toolTip1.SetToolTip(lbl_Buscar2, "NOMBRE DEL ALMACEN");
                    toolTip1.SetToolTip(btn_AgregarCanal, "TIPO DE VENTA");
                    txt_Comentarios.Text =
                        "ASISTENTES DE ALMACEN PARA LA BUSQUEDA DEL ALMACEN AL QUE SE DESEA HACER LA VENTA, DAR DOBLE CLICK EN EL ALMACEN PARA CONTINUAR CON LA VENTA";
                    Text = "Catalogo de Almacenes";
                    break;
                case 5:
                    lbl_Buscar1.Text = "Agente: ";
                    lbl_Buscar2.Text = "Nombre: ";
                    btn_AgregarCanal.Visible = false;
                    Text = "Catalogo de Agentes";
                    LlenaAgente();
                    toolTip1.SetToolTip(txt_Buscar1,
                        "INGRESAR LA NOMINA DEL AGENTE TELEFONICO, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(txt_Buscar2,
                        "INGRESAR EL NOMBRE DEL AGENTE TELEFONICO, PUEDE BUSCARLO POR NOMBRE, APELLIDOS O AMBOS INICIANDO POR SU APELLIDO, DAR ENTER SOBRE EL CAMPO PARA ACTUALIZAR LA BUSQUEDA");
                    toolTip1.SetToolTip(lbl_Buscar1, "NOMINA DEL AGENTE TELEFONICO");
                    toolTip1.SetToolTip(lbl_Buscar2, "NOMBRE DEL AGENTE TELEFONICO");
                    txt_Comentarios.Text =
                        "ASISTENTE DE AGENTES TELEFONICOS DONDE SE PUEDE BUSCAR EL AGENTE QUE SE DESEA ASIGNAR A LA VENTA, DAR DOBLE CLICK SOBRE EL AGENTE PARA PODER AGREGARLO A LA VENTA";
                    break;
            }

            txt_Buscar1.Select();

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Menu.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Menu.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Menu.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") dgv_Menu.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void txt_Buscar1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                switch (CatalogoMostrar)
                {
                    case 1:
                        BuscaCliente();
                        break;
                    case 2:
                        BuscarAgente(1);
                        break;
                    case 4:
                        BuscaAlmacen(1);
                        break;
                    case 5:
                        BuscarAgente(1);
                        break;
                }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_Buscar2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                switch (CatalogoMostrar)
                {
                    case 1:
                        BuscaCliente();
                        break;
                    case 2:
                        BuscarAgente(2);
                        break;
                    case 4:
                        BuscaAlmacen(2);
                        break;
                    case 5:
                        BuscarAgente(2);
                        break;
                }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void DM0312_CatalogosPuntoDeVenta_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        private void dgv_Menu_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            switch (CatalogoMostrar)
            {
                case 1:
                    List<object> TempObjects = new List<object>(listaEmpleadosFiltrados);
                    funciones.OrderGridview(dgv_Menu, e.ColumnIndex, TempObjects,
                        listaEmpleadosFiltrados.GetType().GetGenericArguments().Single());
                    break;
                case 2:
                    List<object> TempObjects2 = new List<object>(listaAgenteFiltrados);
                    funciones.OrderGridview(dgv_Menu, e.ColumnIndex, TempObjects2,
                        listaAgenteFiltrados.GetType().GetGenericArguments().Single());
                    break;
                case 3:
                    List<object> TempObjects3 = new List<object>(listaCanalesFiltrados);
                    funciones.OrderGridview(dgv_Menu, e.ColumnIndex, TempObjects3,
                        listaCanalesFiltrados.GetType().GetGenericArguments().Single());
                    break;
                case 4:
                    List<object> TempObjects4 = new List<object>(listaAlmacenFiltrados);
                    funciones.OrderGridview(dgv_Menu, e.ColumnIndex, TempObjects4,
                        listaAlmacenFiltrados.GetType().GetGenericArguments().Single());
                    break;
                case 5:
                    List<object> TempObjects5 = new List<object>(listaAgenteFiltrados);
                    funciones.OrderGridview(dgv_Menu, e.ColumnIndex, TempObjects5,
                        listaAgenteFiltrados.GetType().GetGenericArguments().Single());
                    break;
            }
        }

        private void DM0312_CatalogosPuntoDeVenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        private void dgv_Menu_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridViewCell cell = dgv_Menu.Rows[e.RowIndex].Cells[e.ColumnIndex];


            switch (CatalogoMostrar)
            {
                case 1:
                    cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON EL PROCESO";
                    break;
                case 2:
                    cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UNA AGENTE Y CONTINUAR CON LA VENTA";
                    break;
                case 3:
                    cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CANAL Y CONTINUAR CON LA VENTA";
                    break;
                case 4:
                    cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN ALMACEN Y CONTINUAR CON LA VENTA";
                    break;
                case 5:
                    cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN AGENTE TELEFONICO Y CONTINUAR CON LA VENTA";
                    break;
            }
        }

        #region "METODOS"

        public async void LlenaClientes()
        {
            try
            {
                if (listaEmpleados.Count == 0)
                {
                    frmLoading = new DM0312_Loading_();
                    frmLoading.Show(this);
                    txt_Buscar1.Enabled = false;
                    txt_Buscar2.Enabled = false;
                    lbl_Buscar2.Enabled = false;
                    lbl_Buscar1.Enabled = false;
                    lbl_Buscar.Enabled = false;
                    listaEmpleados = new List<DM0312_MPuntoDeVentaCliente>();
                    listaEmpleados = await Task.Run(() => controlador.TodosClientes());
                    frmLoading.Hide();
                    txt_Buscar1.Enabled = true;
                    txt_Buscar2.Enabled = true;
                    lbl_Buscar2.Enabled = true;
                    lbl_Buscar1.Enabled = true;
                    lbl_Buscar.Enabled = true;
                }

                var var = from h in listaEmpleados
                    select new
                    {
                        h.Codigo,
                        h.Nombre,
                        Email = h.eMail
                    };

                var objetos = var.Take(2000).ToList();
                listaEmpleadosFiltrados = listaEmpleados.Take(2000).ToList();
                //listaEmpleadosFiltrados.Add(objetos);
                dgv_Menu.DataSource = objetos;
                dgv_Menu.Columns[0].Width = 100;
                dgv_Menu.Columns[1].Width = 250;

                //txt_Buscar1.Focus();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llenaClientes", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAgente()
        {
            try
            {
                listaAgente = new List<DM0312_MPuntoDeVentaAgente>();
                listaAgente = controlador.TodosAgentes(suc);
                listaAgenteFiltrados = listaAgente;
                if (listaAgente.Count == 0)
                {
                    dgv_Menu.DataSource = listaAgente.ToList();
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                    dgv_Menu.Columns[2].Width = 100;
                    dgv_Menu.Columns[3].Width = 100;
                    dgv_Menu.Columns[4].Width = 50;
                }
                else
                {
                    dgv_Menu.DataSource = listaAgente.ToList();
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                    dgv_Menu.Columns[2].Width = 100;
                    dgv_Menu.Columns[3].Width = 100;
                    dgv_Menu.Columns[4].Width = 50;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llenaAgente", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaCanalCliente()
        {
            try
            {
                PuntoDeVenta.listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
                PuntoDeVenta.listaCanal = controlador.LlenaCanalesCliente(Cliente);
                listaCanalesFiltrados = PuntoDeVenta.listaCanal;
                dgv_Menu.DataSource = PuntoDeVenta.listaCanal.ToList();
                dgv_Menu.Columns[0].Width = 50;
                dgv_Menu.Columns[1].Width = 50;
                dgv_Menu.Columns[2].Width = 250;
                dgv_Menu.Columns[3].Width = 250;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llenaCanalCliente", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAlmacen()
        {
            try
            {
                if (listaAlmacen.Count == 0)
                {
                    listaAlmacen = new List<DM0312_MPuntoDeVentaAlmacen>();
                    listaAlmacen = controlador.LlenaAlmacen();
                    listaAlmacenFiltrados = listaAlmacen;
                    dgv_Menu.DataSource = listaAlmacen.ToList();
                    dgv_Menu.Columns[0].Width = 70;
                    dgv_Menu.Columns[1].Width = 300;
                    dgv_Menu.Columns[2].Width = 50;
                    dgv_Menu.Columns[3].Width = 50;
                }
                else
                {
                    dgv_Menu.DataSource = listaAlmacen.ToList();
                    dgv_Menu.Columns[0].Width = 70;
                    dgv_Menu.Columns[1].Width = 300;
                    dgv_Menu.Columns[2].Width = 50;
                    dgv_Menu.Columns[3].Width = 50;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llenaAlmacen", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void BuscaCliente()
        {
            try
            {
                listaEmpleadosFiltrados = new List<DM0312_MPuntoDeVentaCliente>();
                frmLoading = new DM0312_Loading_();
                frmLoading.Show(this);
                string buscar = string.Empty;
                string buscar2 = string.Empty;
                buscar = txt_Buscar1.Text;
                buscar2 = txt_Buscar2.Text;
                buscar = buscar.Replace("*", "");
                buscar2 = buscar2.Replace("*", "");
                txt_Buscar1.Enabled = false;
                txt_Buscar2.Enabled = false;
                lbl_Buscar2.Enabled = false;
                lbl_Buscar1.Enabled = false;
                lbl_Buscar.Enabled = false;
                dgv_Menu.Visible = true;

                if (txt_Buscar1.Text != "" && txt_Buscar2.Text != "")
                {
                    listaEmpleadosFiltrados = listaEmpleados
                        .Where(x => x.Codigo.Contains(buscar) && x.Nombre.Contains(buscar2)).ToList();
                    listaEmpleadosFiltrados = listaEmpleadosFiltrados.Take(2000).ToList();

                    dgv_Menu.DataSource = listaEmpleadosFiltrados;
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                }
                else if (txt_Buscar1.Text != "")
                {
                    listaEmpleadosFiltrados = listaEmpleados.Where(x => x.Codigo.Contains(buscar)).ToList();
                    listaEmpleadosFiltrados = listaEmpleadosFiltrados.Take(2000).ToList();
                    dgv_Menu.DataSource = listaEmpleadosFiltrados; //await Task.Run(() =>var.ToList());
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                }
                else if (txt_Buscar2.Text != "")
                {
                    listaEmpleadosFiltrados = listaEmpleados.Where(x => x.Nombre.Contains(buscar2)).ToList();
                    listaEmpleadosFiltrados = listaEmpleadosFiltrados.Take(2000).ToList();
                    dgv_Menu.DataSource = listaEmpleadosFiltrados; //await Task.Run(() =>var.ToList());
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                }

                frmLoading.Hide();
                txt_Buscar1.Enabled = true;
                txt_Buscar2.Enabled = true;
                lbl_Buscar2.Enabled = true;
                lbl_Buscar1.Enabled = true;
                lbl_Buscar.Enabled = true;
                if (dgv_Menu.Rows.Count == 0)
                {
                    MessageBox.Show("No hay registros", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_Menu.Visible = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscarCliente", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void BuscarAgente(int opc)
        {
            try
            {
                if (opc == 1)
                {
                    string buscar = string.Empty;
                    buscar = txt_Buscar1.Text;
                    buscar = buscar.Replace("*", "");
                    listaAgenteFiltrados = listaAgente.Where(x => x.Agente.Contains(buscar)).ToList();
                    listaAgenteFiltrados = listaAgenteFiltrados.Take(2000).ToList();

                    dgv_Menu.DataSource = listaAgenteFiltrados;
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                    dgv_Menu.Columns[2].Width = 100;
                    dgv_Menu.Columns[3].Width = 100;
                    dgv_Menu.Columns[4].Width = 50;
                }
                else
                {
                    string buscar = string.Empty;
                    buscar = txt_Buscar2.Text;
                    buscar = buscar.Replace("*", "");
                    listaAgenteFiltrados = listaAgente.Where(x => x.Nombre.Contains(buscar)).ToList();
                    listaAgenteFiltrados = listaAgenteFiltrados.Take(2000).ToList();
                    dgv_Menu.DataSource = listaAgenteFiltrados;
                    dgv_Menu.Columns[0].Width = 100;
                    dgv_Menu.Columns[1].Width = 250;
                    dgv_Menu.Columns[2].Width = 100;
                    dgv_Menu.Columns[3].Width = 100;
                    dgv_Menu.Columns[4].Width = 50;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscarAgente", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void BuscaAlmacen(int opc)
        {
            try
            {
                if (opc == 1)
                {
                    string buscar = string.Empty;
                    buscar = txt_Buscar1.Text;
                    buscar = buscar.Replace("*", "");
                    listaAlmacenFiltrados = listaAlmacen.Where(x => x.Almacen.Contains(buscar)).ToList();
                    listaAlmacenFiltrados = listaAlmacenFiltrados.Take(2000).ToList();
                    dgv_Menu.DataSource = listaAlmacenFiltrados;
                    dgv_Menu.Columns[0].Width = 70;
                    dgv_Menu.Columns[1].Width = 300;
                    dgv_Menu.Columns[2].Width = 50;
                    dgv_Menu.Columns[3].Width = 50;
                }
                else
                {
                    string buscar = string.Empty;
                    buscar = txt_Buscar2.Text;
                    buscar = buscar.Replace("*", "");
                    listaAlmacenFiltrados = listaAlmacen.Where(x => x.Nombre.Contains(buscar)).ToList();
                    listaAlmacenFiltrados = listaAlmacenFiltrados.Take(2000).ToList();
                    dgv_Menu.DataSource = listaAlmacenFiltrados;
                    dgv_Menu.Columns[0].Width = 70;
                    dgv_Menu.Columns[1].Width = 300;
                    dgv_Menu.Columns[2].Width = 50;
                    dgv_Menu.Columns[3].Width = 50;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscarAlmacen", "DM0312_CatalogosPuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region "EVENTOS"

        private void dgv_Menu_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indice = e.RowIndex;
            if (indice >= 0)
            {
                switch (CatalogoMostrar)
                {
                    case 1:
                        PuntoDeVenta.Codigo = dgv_Menu.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
                        DM0312_SolicitudValera.Codigo =
                            dgv_Menu.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
                        codigo = dgv_Menu.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
                        break;
                    case 2:
                        PuntoDeVenta.Agente = dgv_Menu.Rows[e.RowIndex].Cells["Agente"].FormattedValue.ToString();
                        DM0312_SolicitudValera.Agente =
                            dgv_Menu.Rows[e.RowIndex].Cells["Agente"].FormattedValue.ToString();
                        break;
                    case 3:
                        PuntoDeVenta.Canal =
                            Convert.ToInt32(dgv_Menu.Rows[e.RowIndex].Cells["Canal"].FormattedValue.ToString());
                        break;
                    case 4:
                        PuntoDeVenta.Almacen = dgv_Menu.Rows[e.RowIndex].Cells["Almacen"].FormattedValue.ToString();
                        DM0312_SolicitudValera.Almacen =
                            dgv_Menu.Rows[e.RowIndex].Cells["Almacen"].FormattedValue.ToString();
                        DM0312_DevolucionAdj.Almacen =
                            dgv_Menu.Rows[e.RowIndex].Cells["Almacen"].FormattedValue.ToString();
                        break;
                    case 5:
                        PuntoDeVenta.AgenteTelefonico =
                            dgv_Menu.Rows[e.RowIndex].Cells["Agente"].FormattedValue.ToString();
                        break;
                }

                Close();
            }
        }

        private void txt_Buscar1_TextChanged(object sender, EventArgs e)
        {
        }

        private void txt_Buscar2_TextChanged(object sender, EventArgs e)
        {
        }

        private void btn_AgregarCanal_Click(object sender, EventArgs e)
        {
            DM0312_PuntoDeVentaCanalNuevo catalogo = new DM0312_PuntoDeVentaCanalNuevo();
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            LlenaCanalCliente();
        }

        #endregion
    }
}