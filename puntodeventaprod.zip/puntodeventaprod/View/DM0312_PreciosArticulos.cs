﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_PreciosArticulos : Form
    {
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public string recibeArticulo;

        public DM0312_PreciosArticulos()
        {
            InitializeComponent();
        }

        ~DM0312_PreciosArticulos()
        {
            GC.Collect();
        }

        private void DM0312_PreciosArticulos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        private void InformacionPrecios()
        {
            try
            {
                DataTable dataSet = new DataTable();
                dataSet = controlador.PreciosCondicion(recibeArticulo, ClaseEstatica.Usuario.Uen, 1);

                dgv_Precios.DataSource = null;
                dgv_Precios.DataSource = dataSet;

                if (dgv_Precios.Rows.Count <= 0)
                {
                    dataSet = controlador.PreciosCondicion(recibeArticulo, ClaseEstatica.Usuario.Uen, 2);
                    dgv_Precios.DataSource = null;
                    dgv_Precios.DataSource = dataSet;
                    if (dgv_Precios.Rows.Count <= 0)
                    {
                        Close();
                        MessageBox.Show(
                            "El articulo " + recibeArticulo +
                            " no cuenta con precios en ninguna condicion de la empresa", "Mensaje!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException sqlException)
            {
                DM0312_ErrorLog.RegistraError("InformacionPrecios", "DM0312_PreciosArticulos", sqlException);
                MessageBox.Show(sqlException.Message);
            }
        }

        private void DM0312_PreciosArticulos_Load(object sender, EventArgs e)
        {
            InformacionPrecios();
            txt_ComentarioAyuda.Text = "ASISTENTE DE PRECIOS EN EL CUAL SE MUESTRAN LOS PRECIOS DEL ARTÍCULO: " +
                                       recibeArticulo + " EN TODAS LAS CONDICIONES EN LAS QUE SE PUEDE VENDER";
            lbl_Precio.Text = recibeArticulo;

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Precios.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Precios.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Precios.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") dgv_Precios.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}