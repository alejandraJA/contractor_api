﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_ComentariosVenta : Form
    {
        public static List<DM0312_MComentariosVenta> listaModelo = new List<DM0312_MComentariosVenta>();
        public static DM0312_C_ComentariosVenta controlador = new DM0312_C_ComentariosVenta();
        public static List<string> listaModulos = new List<string>();
        private string filtro, campo, modulo, comentario;
        private readonly Funciones funciones = new Funciones();
        public DM0312_MComentariosVenta ListTempUpdate = new DM0312_MComentariosVenta();
        public List<DM0312_MComentariosVenta> listUpdate = new List<DM0312_MComentariosVenta>();

        public DM0312_ComentariosVenta()
        {
            InitializeComponent();
        }

        ~DM0312_ComentariosVenta()
        {
            GC.Collect();
        }

        #region "Methods"

        public void LlenaCombo()
        {
            DataTable dataSet = new DataTable();

            cmbModulo.DataSource = null;
            cmb_ModuloGuardar.DataSource = null;
            cmbModulo.Items.Clear();
            cmb_ModuloGuardar.Items.Clear();
            dataSet = controlador.ObtieneModulos();
            cmbModulo.Items.Add("Todos");
            cmb_ModuloGuardar.Items.Add("Todos");

            foreach (DataRow row in dataSet.Rows)
            {
                cmbModulo.Items.Add(Convert.ToString(row[0]));
                cmb_ModuloGuardar.Items.Add(Convert.ToString(row[0]));
            }

            cmbModulo.SelectedIndex = 0;
            cmbModulo.DisplayMember = "value";
            cmbModulo.ValueMember = "key";

            cmb_ModuloGuardar.SelectedIndex = 0;
            cmb_ModuloGuardar.DisplayMember = "value";
            cmb_ModuloGuardar.ValueMember = "key";
        }

        public void LlenaComentariosTodos()
        {
            dgvComentarios.DataSource = "";
            listaModelo = new List<DM0312_MComentariosVenta>();
            listaModelo = controlador.ObtieneComentarios();
            dgvComentarios.DataSource = listaModelo.ToList();

            dgvComentarios.Columns["id"].Visible = false;
            dgvComentarios.Columns[2].Width = 255;
            dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
        }

        public void LlenaFiltro()
        {
            dgvComentarios.DataSource = null;
            listaModelo = new List<DM0312_MComentariosVenta>();
            List<DM0312_MComentariosVenta> listTe = new List<DM0312_MComentariosVenta>();
            listaModelo = controlador.ObtieneComentarios();
            listTe = listaModelo.Where(x => x.Modulo == filtro).ToList();
            dgvComentarios.DataSource = listTe.ToList();
            dgvComentarios.Columns["id"].Visible = false;
        }

        public bool Guardar()
        {
            dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
            listaModelo = controlador.ObtieneComentarios();
            campo = txt_CampoGuardar.Text;
            modulo = txt_ModuloGuardar.Text;
            comentario = txt_ComentarioGuardar.Text;
            string valida = listaModelo.Where(x => x.Modulo == modulo && x.Campo == campo).Select(x => x.Campo)
                .FirstOrDefault();
            if (campo != valida)
            {
                bool New = controlador.Inserta(campo, modulo, comentario);
                return New;
            }

            MessageBox.Show("El campo ya existe en el Modulo seleccionado");

            return false;
        }

        public void Actualiza()
        {
            bool Update = controlador.Actualiza(campo, modulo, comentario);
        }

        #endregion

        #region "Handles"

        private void DM0312_ComentariosVenta_Load(object sender, EventArgs e)
        {
            LlenaCombo();
            LlenaComentariosTodos();
            dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
        }

        private void cmbModulo_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtro = Convert.ToString(cmbModulo.SelectedItem);
            if (filtro == "Todos")
                LlenaComentariosTodos();
            else
                LlenaFiltro();
        }

        private void dgvComentarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
                dgvComentarios.Rows[e.RowIndex].Cells["Campo"].ReadOnly = true;
                dgvComentarios.Rows[e.RowIndex].Cells["Modulo"].ReadOnly = true;
                dgvComentarios.Rows[e.RowIndex].Cells["Comentario"].ReadOnly = false;
            }
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgvComentarios.EndEdit();
            bool Update = false;
            int contador = 0;
            int contadorTemp = 0;
            foreach (DM0312_MComentariosVenta item in listUpdate)
            {
                contadorTemp++;
                Update = controlador.Actualiza(item.Campo, item.Modulo, item.Comentario);
                if (Update) contador++;
            }

            if (contador == contadorTemp)
                MessageBox.Show("Registro almacenado correctamente", "!Aviso¡", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
        }

        private void nuevoRegistroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pnl_Guardar.Visible)
            {
                pnl_Guardar.Visible = false;
                LlenaCombo();
                dgvComentarios.Visible = true;
                lbl_Filtrar.Visible = true;
                txtCampo.Visible = true;
                cmbModulo.Visible = true;
            }
            else
            {
                dgvComentarios.Visible = false;
                pnl_Guardar.Visible = true;
                lbl_Campo.Visible = false;
                lbl_Filtrar.Visible = false;
                txtCampo.Visible = false;
                cmbModulo.Visible = false;
                menu.Visible = false;
            }
        }

        private void guardarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (txt_CampoGuardar.Text != "" && txt_ModuloGuardar.Text.Trim() != "")
            {
                if (Guardar())
                {
                    MessageBox.Show("Datos guardados con éxito", "Correcto");
                    LlenaComentariosTodos();
                    LlenaCombo();
                }
            }
            else
            {
                if (txt_ModuloGuardar.Text == "")
                    MessageBox.Show("Debe insertar un modulo", "Error");
                else if (txt_CampoGuardar.Text == "")
                    MessageBox.Show("Debe insertar un campo", "Error");
                else
                    MessageBox.Show("Debe insertar un comentario", "Error");
            }
        }

        private void cmb_ModuloGuardar_SelectedIndexChanged(object sender, EventArgs e)
        {
            string var = string.Empty;
            var = Convert.ToString(cmb_ModuloGuardar.SelectedItem);
            if (var != "Todos") txt_ModuloGuardar.Text = var;
        }

        private void regresarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_Guardar.Visible = false;
            LlenaCombo();
            dgvComentarios.Visible = true;
            lbl_Filtrar.Visible = true;
            txtCampo.Visible = true;
            cmbModulo.Visible = true;
            menu.Visible = true;
        }


        private void dgvComentarios_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                ListTempUpdate = (DM0312_MComentariosVenta)dgvComentarios.CurrentRow.DataBoundItem;
                listUpdate.Add(ListTempUpdate);
                dgvComentarios.EndEdit();
                dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
            }
        }

        private void txtCampo_KeyPress(object sender, KeyPressEventArgs e)
        {
            string value = txtCampo.Text;
            string asterisco = "*";
            if (value.Contains(asterisco)) value = value.Substring(0, value.IndexOf("*"));
            if (e.KeyChar == (int)Keys.Enter)
            {
                List<DM0312_MComentariosVenta> valorBusqueda = listaModelo.Where(x => x.Campo.Contains(value)).ToList();
                dgvComentarios.DataSource = null;
                dgvComentarios.DataSource = valorBusqueda;
                dgvComentarios.Columns["Id"].Visible = false;
                dgvComentarios.Columns["Modulo"].HeaderText = "Forma";
            }
        }

        private void dgvComentarios_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var projectList = (from row in dgvComentarios.Rows.OfType<DataGridViewRow>()
                select new
                {
                    Id = row.Cells[0].Value.ToString(),
                    Campo = row.Cells[1].Value.ToString(),
                    Forma = row.Cells[2].Value.ToString(),
                    Comentario = row.Cells[3].Value.ToString()
                }).ToList();

            List<object> TempObjects = new List<object>(projectList);
            funciones.OrderGridview(dgvComentarios, e.ColumnIndex, TempObjects,
                projectList.GetType().GetGenericArguments().Single());
            dgvComentarios.Columns["Id"].Visible = false;
        }

        private void regresarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        #endregion
    }
}