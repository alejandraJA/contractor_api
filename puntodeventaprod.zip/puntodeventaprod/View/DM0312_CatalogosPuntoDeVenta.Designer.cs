﻿namespace PuntoVenta.View
{
    partial class DM0312_CatalogosPuntoDeVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_CatalogosPuntoDeVenta));
            this.dgv_Menu = new System.Windows.Forms.DataGridView();
            this.lbl_Buscar1 = new System.Windows.Forms.Label();
            this.lbl_Buscar2 = new System.Windows.Forms.Label();
            this.txt_Buscar1 = new System.Windows.Forms.TextBox();
            this.txt_Buscar2 = new System.Windows.Forms.TextBox();
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.btn_AgregarCanal = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_Menu
            // 
            this.dgv_Menu.AllowUserToAddRows = false;
            this.dgv_Menu.AllowUserToDeleteRows = false;
            this.dgv_Menu.AllowUserToResizeColumns = false;
            this.dgv_Menu.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Menu.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Menu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Menu.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgv_Menu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Menu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Menu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Menu.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Menu.EnableHeadersVisualStyles = false;
            this.dgv_Menu.Location = new System.Drawing.Point(3, 151);
            this.dgv_Menu.Name = "dgv_Menu";
            this.dgv_Menu.ReadOnly = true;
            this.dgv_Menu.RowHeadersVisible = false;
            this.dgv_Menu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_Menu.Size = new System.Drawing.Size(878, 357);
            this.dgv_Menu.TabIndex = 0;
            this.dgv_Menu.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Menu_CellDoubleClick);
            this.dgv_Menu.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_Menu_CellFormatting);
            this.dgv_Menu.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Menu_ColumnHeaderMouseClick);
            // 
            // lbl_Buscar1
            // 
            this.lbl_Buscar1.AutoSize = true;
            this.lbl_Buscar1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar1.Location = new System.Drawing.Point(3, 22);
            this.lbl_Buscar1.Name = "lbl_Buscar1";
            this.lbl_Buscar1.Size = new System.Drawing.Size(40, 15);
            this.lbl_Buscar1.TabIndex = 1;
            this.lbl_Buscar1.Text = "label1";
            // 
            // lbl_Buscar2
            // 
            this.lbl_Buscar2.AutoSize = true;
            this.lbl_Buscar2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar2.Location = new System.Drawing.Point(3, 50);
            this.lbl_Buscar2.Name = "lbl_Buscar2";
            this.lbl_Buscar2.Size = new System.Drawing.Size(40, 15);
            this.lbl_Buscar2.TabIndex = 2;
            this.lbl_Buscar2.Text = "label2";
            // 
            // txt_Buscar1
            // 
            this.txt_Buscar1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Buscar1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Buscar1.Location = new System.Drawing.Point(79, 25);
            this.txt_Buscar1.MaxLength = 11;
            this.txt_Buscar1.Name = "txt_Buscar1";
            this.txt_Buscar1.Size = new System.Drawing.Size(139, 22);
            this.txt_Buscar1.TabIndex = 3;
            this.txt_Buscar1.TextChanged += new System.EventHandler(this.txt_Buscar1_TextChanged);
            this.txt_Buscar1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Buscar1_KeyPress);
            // 
            // txt_Buscar2
            // 
            this.txt_Buscar2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Buscar2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Buscar2.Location = new System.Drawing.Point(79, 53);
            this.txt_Buscar2.Name = "txt_Buscar2";
            this.txt_Buscar2.Size = new System.Drawing.Size(139, 22);
            this.txt_Buscar2.TabIndex = 4;
            this.txt_Buscar2.TextChanged += new System.EventHandler(this.txt_Buscar2_TextChanged);
            this.txt_Buscar2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Buscar2_KeyPress);
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar.Location = new System.Drawing.Point(3, 0);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(68, 15);
            this.lbl_Buscar.TabIndex = 5;
            this.lbl_Buscar.Text = "Buscar por";
            // 
            // btn_AgregarCanal
            // 
            this.btn_AgregarCanal.BackColor = System.Drawing.SystemColors.Window;
            this.btn_AgregarCanal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AgregarCanal.FlatAppearance.BorderSize = 0;
            this.btn_AgregarCanal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgregarCanal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AgregarCanal.Image = ((System.Drawing.Image)(resources.GetObject("btn_AgregarCanal.Image")));
            this.btn_AgregarCanal.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_AgregarCanal.Location = new System.Drawing.Point(726, 3);
            this.btn_AgregarCanal.Name = "btn_AgregarCanal";
            this.btn_AgregarCanal.Size = new System.Drawing.Size(93, 45);
            this.btn_AgregarCanal.TabIndex = 6;
            this.btn_AgregarCanal.Text = "Nuevo Canal";
            this.btn_AgregarCanal.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_AgregarCanal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_AgregarCanal.UseVisualStyleBackColor = false;
            this.btn_AgregarCanal.Click += new System.EventHandler(this.btn_AgregarCanal_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgv_Menu, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 363F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(884, 511);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.64516F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 59.35484F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(878, 142);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.58801F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.41199F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 143F));
            this.tableLayoutPanel3.Controls.Add(this.lbl_Buscar, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lbl_Buscar1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.txt_Buscar2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lbl_Buscar2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.txt_Buscar1, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 60);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 44F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(401, 77);
            this.tableLayoutPanel3.TabIndex = 111;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.00654F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.99346F));
            this.tableLayoutPanel4.Controls.Add(this.txt_Comentarios, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_AgregarCanal, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(872, 51);
            this.tableLayoutPanel4.TabIndex = 112;
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(3, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(717, 45);
            this.txt_Comentarios.TabIndex = 110;
            // 
            // DM0312_CatalogosPuntoDeVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(884, 511);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_CatalogosPuntoDeVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalogos";
            this.Load += new System.EventHandler(this.DM0312_CatalogosPuntoDeVenta_Load);
            this.LocationChanged += new System.EventHandler(this.DM0312_CatalogosPuntoDeVenta_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_CatalogosPuntoDeVenta_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Menu;
        private System.Windows.Forms.Label lbl_Buscar1;
        private System.Windows.Forms.Label lbl_Buscar2;
        private System.Windows.Forms.TextBox txt_Buscar1;
        private System.Windows.Forms.TextBox txt_Buscar2;
        private System.Windows.Forms.Label lbl_Buscar;
        private System.Windows.Forms.Button btn_AgregarCanal;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}