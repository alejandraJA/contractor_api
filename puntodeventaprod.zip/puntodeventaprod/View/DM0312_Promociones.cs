﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_Promociones : Form
    {
        private readonly DM0312_C_Promociones controller = new DM0312_C_Promociones();
        private byte[] fileData1;
        private byte[] fileData2;
        private byte[] fileData3;
        private byte[] fileData4;
        private List<DM0312_MPromociones> list;
        public int[] valida = new int[4];
        private int validaDelete;
        public int[] validaInsert = new int[4];

        public DM0312_Promociones()
        {
            list = new List<DM0312_MPromociones>();
            InitializeComponent();
        }

        ~DM0312_Promociones()
        {
            GC.Collect();
        }

        #region "Methods"

        public int[] InsertImageMA()
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 1).ToList();
            int valida = 0;
            if (promosion.Count != 4)
            {
                try
                {
                    if (fileData1 != null && pictureBox1.Image == null)
                    {
                        string query =
                            "INSERT INTO [AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen, @IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                        sqlCommand.Parameters.AddWithValue("@UEN", 1);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData1);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 1);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[0] = 1;
                        else
                            validaInsert[0] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData2 != null && pictureBox2.Image == null)
                    {
                        valida = 0;
                        string query =
                            "INSERT INTO [AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen, @IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 1);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData2);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 2);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[1] = 1;
                        else
                            validaInsert[1] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData3 != null && pictureBox3.Image == null)
                    {
                        valida = 0;
                        string query =
                            "INSERT INTO [AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen, @IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstaticaAndroid);
                        sqlCommand.Parameters.AddWithValue("@UEN", 1);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData3);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 3);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[2] = 1;
                        else
                            validaInsert[2] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData4 != null && pictureBox4.Image == null)
                    {
                        valida = 0;
                        string query =
                            "INSERT INTO [maviandroid01].[AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen, @IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 1);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData4);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 4);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[3] = 1;
                        else
                            validaInsert[3] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return validaInsert;
        }


        public void AddPicture()
        {
            List<DM0312_MPromociones> promocion = list.Where(x => x.Uen == 1).ToList();
            int validaUpdate = 0;
            foreach (DM0312_MPromociones item in promocion)
            {
                if (item.IdImagen == 1 && fileData1 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData1, 1);

                if (item.IdImagen == 2 && fileData2 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData2, 2);

                if (item.IdImagen == 3 && fileData3 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData3, 3);

                if (item.IdImagen == 4 && fileData4 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData4, 4);
            }

            valida = InsertImageMA();
            int totalInsert = 0;
            for (int i = 0; i < 4; i++)
                if (valida[i] == 1)
                    totalInsert++;
            list = controller.FillImage();
            Imagen();
        }

        public void AddPictureViu()
        {
            List<DM0312_MPromociones> promocion = list.Where(x => x.Uen == 2).ToList();
            int validaUpdate = 0;
            foreach (DM0312_MPromociones item in promocion)
            {
                if (item.IdImagen == 5 && fileData1 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData1, 5);

                if (item.IdImagen == 6 && fileData2 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData2, 6);

                if (item.IdImagen == 7 && fileData3 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData3, 7);

                if (item.IdImagen == 8 && fileData4 != null && item.Imagen.Length >= 1)
                    validaUpdate = controller.UpdatePicture(fileData4, 8);
            }

            valida = InsertImageVIU();
            int totalInsert = 0;

            for (int i = 0; i < 4; i++)
                if (validaInsert[i] == 1)
                    totalInsert++;

            list = controller.FillImage();
            Imagen();
        }


        public int[] InsertImageVIU()
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 2).ToList();
            int valida = 0;
            if (promosion.Count != 4)
            {
                try
                {
                    if (fileData1 != null && pictureBox1VIU.Image == null)
                    {
                        string query =
                            "INSERT INTO [maviandroid01].[AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen,@IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 2);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData1);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 5);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[0] = 1;
                        else
                            validaInsert[0] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData2 != null && pictureBox2VIU.Image == null)
                    {
                        string query =
                            "INSERT INTO [maviandroid01].[AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen,@IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 2);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData2);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 6);
                        valida = sqlCommand.ExecuteNonQuery();
                        if (valida == 1 || valida == -1)
                            validaInsert[1] = 1;
                        else
                            validaInsert[1] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData3 != null && pictureBox3VIU.Image == null)
                    {
                        string query =
                            "INSERT INTO [maviandroid01].[AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen,@IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 2);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData3);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 7);
                        valida = sqlCommand.ExecuteNonQuery();

                        if (valida == 1 || valida == -1)
                            validaInsert[2] = 1;
                        else
                            validaInsert[2] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    if (fileData4 != null && pictureBox4VIU.Image == null)
                    {
                        string query =
                            "INSERT INTO [maviandroid01].[AdminDoc].[dbo].[TREDM0312_Promociones] (UEN, Modulo, Imagen, IdImagen) VALUES (@UEN, @Modulo,@Imagen,@IdImagen)";
                        SqlCommand sqlCommand = new SqlCommand(query, ClaseEstatica.ConexionEstatica);
                        sqlCommand.Parameters.AddWithValue("@UEN", 2);
                        sqlCommand.Parameters.AddWithValue("@Modulo", "Ventas");
                        sqlCommand.Parameters.AddWithValue("@Imagen", fileData4);
                        sqlCommand.Parameters.AddWithValue("@IdImagen", 8);
                        valida = sqlCommand.ExecuteNonQuery();

                        if (valida == 1 || valida == -1)
                            validaInsert[3] = 1;
                        else
                            validaInsert[3] = 0;
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_Promociones", ex);
                    MessageBox.Show(ex.Message);
                }
            }

            return validaInsert;
        }

        public void Imagen()
        {
            List<DM0312_MPromociones> listTemp = list.ToList();
            foreach (DM0312_MPromociones item in listTemp)
            {
                if (item.Uen == 1)
                    switch (item.IdImagen)
                    {
                        case 1:
                            pictureBox1.Image = byteArrayToImage(item.Imagen);
                            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 2:
                            pictureBox2.Image = byteArrayToImage(item.Imagen);
                            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 3:
                            pictureBox3.Image = byteArrayToImage(item.Imagen);
                            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 4:
                            pictureBox4.Image = byteArrayToImage(item.Imagen);
                            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                    }

                if (item.Uen == 2)
                    switch (item.IdImagen)
                    {
                        case 5:
                            pictureBox1VIU.Image = byteArrayToImage(item.Imagen);
                            pictureBox1VIU.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 6:
                            pictureBox2VIU.Image = byteArrayToImage(item.Imagen);
                            pictureBox2VIU.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 7:
                            pictureBox3VIU.Image = byteArrayToImage(item.Imagen);
                            pictureBox3VIU.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                        case 8:
                            pictureBox4VIU.Image = byteArrayToImage(item.Imagen);
                            pictureBox4VIU.SizeMode = PictureBoxSizeMode.Zoom;
                            break;
                    }
            }
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            Image returnImage = null;
            try
            {
                MemoryStream ms = new MemoryStream(byteArrayIn, 0, byteArrayIn.Length);
                ms.Write(byteArrayIn, 0, byteArrayIn.Length);
                returnImage = Image.FromStream(ms, true);
            }
            catch
            {
            }

            return returnImage;
        }

        #endregion

        #region "Handles"

        private void DM0312_Promociones_Load(object sender, EventArgs e)
        {
            AutoSize = false;
            list = controller.FillImage();
            Imagen();
            txt_Comentarios.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen1.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData1 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPicture();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }

            btn_Imagen2.Visible = true;
            txt_Imagen2.Visible = true;
            label2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen2.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData2 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPicture();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen3.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData3 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPicture();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen4.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData4 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPicture();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen1VIU.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData1 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPictureViu();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }

                list = controller.FillImage();
                Imagen();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen2VIU.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData2 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPictureViu();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen3VIU.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData3 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPictureViu();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Files|*.jpg;*.jpeg;*.png";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                try
                {
                    FileInfo fi = new FileInfo(openFileDialog.FileName);
                    txt_Imagen4VIU.Text = fi.ToString();
                    MessageBox.Show("Imagen almacenada correctamente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);
                    BinaryReader rdr = new BinaryReader(fs);
                    fileData4 = rdr.ReadBytes((int)fs.Length);
                    rdr.Close();
                    fs.Close();
                    AddPictureViu();
                }
                catch (FileLoadException)
                {
                    MessageBox.Show("Error: No se pudo leer el archivo : ", "¡Aviso!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 1).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 1)
                {
                    pictureBox1.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(1, 1);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox1.Image = null;
                    txt_Imagen1.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 1).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 2)
                {
                    pictureBox2.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(2, 1);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox2.Image = null;
                    txt_Imagen2.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 1).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 3)
                {
                    pictureBox3.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(3, 1);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox3.Image = null;
                    txt_Imagen3.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 1).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 4)
                {
                    pictureBox4.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(4, 1);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox4.Image = null;
                    txt_Imagen4.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox1VIU_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 2).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1VIU.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 5)
                {
                    pictureBox1VIU.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(5, 2);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox1VIU.Image = null;
                    txt_Imagen1VIU.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox2VIU_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 2).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1VIU.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 6)
                {
                    pictureBox2VIU.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(6, 2);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox2VIU.Image = null;
                    txt_Imagen2VIU.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox3VIU_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 2).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1VIU.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 7)
                {
                    pictureBox3VIU.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(7, 2);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox3VIU.Image = null;
                    txt_Imagen3VIU.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void pictureBox4VIU_Click(object sender, EventArgs e)
        {
            List<DM0312_MPromociones> promosion = list.Where(x => x.Uen == 2).ToList();
            if (promosion.Count == 0)
            {
                pictureBox1VIU.Visible = false;
                return;
            }

            foreach (DM0312_MPromociones item in promosion)
                if (item.Imagen.Length == 1 && item.IdImagen == 8)
                {
                    pictureBox4VIU.Visible = false;
                    return;
                }

            DialogResult dialogResult =
                MessageBox.Show(" ¿ Desea  eliminar la foto ?", "Aviso!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                validaDelete = controller.DeletePicture(8, 2);
                if (validaDelete == 1)
                {
                    MessageBox.Show("Registro eliminado con exito", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    pictureBox4VIU.Image = null;
                    txt_Imagen4VIU.Text = "";
                }
                else
                {
                    MessageBox.Show("Error al eliminar la foto", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        #endregion
    }
}