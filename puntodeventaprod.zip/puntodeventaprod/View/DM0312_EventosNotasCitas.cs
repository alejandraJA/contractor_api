﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_EventosNotasCitas : Form
    {
        public static string recibeMov;
        public static string recibeMovId;
        public static string recibeCliente;
        public static string recibeSituacion;
        public static string recibeEstatus;
        public static string recibeSucursal;
        public static string recibeUsuario;
        public static string recibeMensaje;
        public static string recibeIdventa;
        public static int ValidaCanalVenta;
        public static bool FlagEventosDetalle = false;

        public static string recibeIdecommerce;

        //-Dineralia
        public static int iCanalVenta;
        private string agente;

        private readonly List<DM0312_MVerificaConfiguracionUsuario> configUser =
            new List<DM0312_MVerificaConfiguracionUsuario>();

        private CrtlConsultaEvento controlConsultarEvento = new CrtlConsultaEvento();

        private bool ExecuteCheckboxEvents = true;
        public List<DM0312_MComentariosVenta> ListaEventosNotasCitasComentario;

        // GESSY 1286
        private DM0312_MExploradorVenta modeloVenta;
        private readonly string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        public bool validaVistaHistorialSol = false;

        public DM0312_EventosNotasCitas(DM0312_MExploradorVenta ModeloVenta = null)
        {
            InitializeComponent();
            configUser = Funciones.VerificaConfiguracionUsuario(ClaseEstatica.Usuario.Acceso);

            // GESSY 1286
            if (ModeloVenta != null) setModeloVentaValues(ModeloVenta);
        }

        ~DM0312_EventosNotasCitas()
        {
            GC.Collect();
        }

        public void setModeloVentaValues(DM0312_MExploradorVenta ModeloVenta)
        {
            modeloVenta = ModeloVenta;

            recibeCliente = ModeloVenta.Cliente;
            recibeMov = ModeloVenta.Mov;
            recibeMovId = Convert.ToString(ModeloVenta.MovId);
            recibeIdventa = Convert.ToString(ModeloVenta.ID);
            recibeUsuario = ClaseEstatica.Usuario.Usser;
            recibeSituacion = ModeloVenta.Situacion;
            recibeEstatus = ModeloVenta.Estatus;
            recibeSucursal = Convert.ToString(ModeloVenta.Suc);
            iCanalVenta = int.Parse(ModeloVenta.EnviarA);
            recibeIdecommerce = ModeloVenta.IDEcommerce;
        }

        #region "Methods"

        public bool ValidateConfigUser(string Campo)
        {
            List<DM0312_MVerificaConfiguracionUsuario> ListaControles = configUser.Where
            (
                x => x.Forma == "DM0312_EventosNotasCitas"
                     && x.Acceso == ClaseEstatica.Usuario.Acceso
                     && x.Estatus == false
                     && x.Campo == Campo
            ).ToList();

            if (ListaControles.Count > 0) return false;

            return true;
        }

        #endregion

        private void DM0312_EventosNotasCitas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                DM0312_ExploradorVentas.EjecutaEvento = true;
                Dispose();
            }
        }

        #region "Handlers"

        private void EventosNotasCitas_Load(object sender, EventArgs e)
        {
            chk_Eventos.Checked = true;
            ListaEventosNotasCitasComentario = Funciones.ConsultaComentario("Eventos Notas Citas");

            //ValitateConfigUsser();
            lbl_Cliente.Text = recibeUsuario;
            lbl_Mov.Text = recibeMov;
            lbl_MovID.Text = recibeMovId;
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR");

            toolTip1.SetToolTip(chk_Eventos, "SELECCIONAR PARA PODER AGREGAR O MOSTRAR EVENTOS");
            toolTip1.SetToolTip(chk_Nota, "SELECCIONAR PARA PODER AGREGAR O MOSTRAR NOTAS");
            toolTip1.SetToolTip(chk_CitaSupervicion, "SELECCIONAR PARA PODER AGREGAR O MOSTRAR CITAS DE SUPERVISION");
            if (chk_Eventos.Checked)
            {
                toolTip1.SetToolTip(btn_AgregarEvento, "SELECCIONAR PARA AGREGAR UN EVENTO");
            }
            else
            {
                if (chk_Nota.Checked)
                {
                    toolTip1.SetToolTip(btn_AgregarEvento, "SELECCIONAR PARA AGREGAR UNA NOTA");
                }
                else
                {
                    if (chk_CitaSupervicion.Checked)
                        toolTip1.SetToolTip(btn_AgregarEvento, "SELECCIONAR PARA AGREGAR UNA CITA DE SUPERVISION");
                }
            }

            if (chk_Eventos.Checked)
            {
                toolTip1.SetToolTip(btn_Consultar, "SELECCIONAR PARA CONSULTAR UN EVENTO");
            }
            else
            {
                if (chk_Nota.Checked)
                {
                    toolTip1.SetToolTip(btn_Consultar, "SELECCIONAR PARA CONSULTAR UNA NOTA");
                }
                else
                {
                    if (chk_CitaSupervicion.Checked)
                        toolTip1.SetToolTip(btn_Consultar, "SELECCIONAR PARA CONSULTAR UNA CITA DE SUPERVISION");
                }
            }
        }

        private void btn_AgregarEvento_Click(object sender, EventArgs e)
        {
            DM0312_AgregarEvento.list.Clear();
            DM0312_AgregarEvento.recibeTexto = "";

            DM0312_AgregarEvento agregaEvento = new DM0312_AgregarEvento();
            agregaEvento.recibeIdVenta = recibeIdventa;
            agregaEvento.recibeUsuario = recibeUsuario;
            agregaEvento.recibeSucursal = recibeSucursal;
            agregaEvento.recibeEstatus = recibeEstatus;
            agregaEvento.recibeMov = recibeMov;
            agregaEvento.recibeMovId = recibeMovId;
            agregaEvento.recibeSituacion = recibeSituacion;
            agregaEvento.recibeCliente = recibeCliente;
            agregaEvento.iCanalVenta = iCanalVenta;
            agregaEvento.recibeIdecommerce = recibeIdecommerce;

            // GESSY 1286
            if (chk_Eventos.Checked)
            {
                if ((getAccesoUsuario() == "VENTP" || getAccesoUsuario() == "VENTR")
                    && agregaEvento.recibeMov == "Analisis Credito"
                   )
                {
                    frmEventoReactivacion ER = new frmEventoReactivacion(modeloVenta);
                    Visible = false;
                    ER.ShowDialog();
                    Visible = true;
                }
                else if (getAccesoUsuario() == "VENTP" || getAccesoUsuario() == "VENTR" ||
                         getAccesoUsuario() == "VENTM" || getAccesoUsuario() == "COBMA")
                {
                    agregaEvento.ValidaCanalVenta = ValidaCanalVenta;
                    agregaEvento.recibeMensaje = (int)Enums.EventoNotacita.Evento;
                    mostrarAgregarEvento(agregaEvento, Enums.EventoNotacita.Evento);
                }

                if (getAccesoUsuario() == "CREDI")
                {
                    agregaEvento.ValidaCanalVenta = ValidaCanalVenta;
                    agregaEvento.recibeMensaje = (int)Enums.EventoNotacita.Evento;
                    mostrarAgregarEvento(agregaEvento, Enums.EventoNotacita.Evento);
                }
            }

            // GESSY 1286
            if (chk_Nota.Checked) mostrarAgregarEvento(agregaEvento, Enums.EventoNotacita.Nota);

            // GESSY 1286
            if (chk_CitaSupervicion.Checked) mostrarAgregarEvento(agregaEvento, Enums.EventoNotacita.Cita);
        }

        private static string getAccesoUsuario()
        {
            return ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        }

        // GESSY 1286
        private void mostrarAgregarEvento(DM0312_AgregarEvento agregaEvento, Enums.EventoNotacita EventoNotacita)
        {
            agregaEvento.recibeMensaje = (int)EventoNotacita;
            agregaEvento.recibeCliente = recibeCliente;

            if (!FlagEventosDetalle) Visible = false;
            agregaEvento.ShowDialog();
        }

        private void chkNota_CheckedChanged(object sender, EventArgs e)
        {
            if (ExecuteCheckboxEvents)
            {
                ExecuteCheckboxEvents = false;
                chk_Nota.Checked = true;
                if (chk_Nota.Checked)
                {
                    chk_CitaSupervicion.Checked = false;
                    chk_Eventos.Checked = false;
                    btn_AgregarEvento.Enabled = ValidateConfigUser("AgregarNota");
                }

                ExecuteCheckboxEvents = true;
            }
        }

        private void chkCitaSupervicion_CheckedChanged(object sender, EventArgs e)
        {
            if (ExecuteCheckboxEvents)
            {
                ExecuteCheckboxEvents = false;
                chk_CitaSupervicion.Checked = true;
                if (chk_CitaSupervicion.Checked)
                {
                    chk_Nota.Checked = false;
                    chk_Eventos.Checked = false;
                    btn_AgregarEvento.Enabled = ValidateConfigUser("AgregarCita");
                    if (validaVistaHistorialSol && usuarioVenta == "VENTP") btn_AgregarEvento.Enabled = false;
                }

                ExecuteCheckboxEvents = true;
            }
        }

        private void chk_Eventos_CheckedChanged(object sender, EventArgs e)
        {
            if (ExecuteCheckboxEvents)
            {
                ExecuteCheckboxEvents = false;
                chk_Eventos.Checked = true;
                if (chk_Eventos.Checked)
                {
                    chk_Nota.Checked = false;
                    chk_CitaSupervicion.Checked = false;
                    btn_AgregarEvento.Enabled = ValidateConfigUser("AgregarEvento");
                    if (validaVistaHistorialSol && usuarioVenta == "VENTP") btn_AgregarEvento.Enabled = false;
                }

                ExecuteCheckboxEvents = true;
            }
        }

        private void btn_Consultar_Click(object sender, EventArgs e)
        {
            DM0312_ConsultarEvento consultaEvento = new DM0312_ConsultarEvento();
            consultaEvento.recibeMovId = recibeMovId;
            consultaEvento.recibeMov = recibeMov;
            consultaEvento.recibeUsuario = recibeUsuario;
            consultaEvento.recibeIdVenta = recibeIdventa;
            consultaEvento.recibeCliente = recibeCliente;
            string EventNotaCitaTitle = "Evento";

            if (chk_Eventos.Checked)
            {
                EventNotaCitaTitle = "Eventos";
                consultaEvento.opcionForma = (int)Enums.EventoNotacita.Evento;
            }
            else if (chk_Nota.Checked)
            {
                EventNotaCitaTitle = "Nota";
                consultaEvento.opcionForma = (int)Enums.EventoNotacita.Nota;
            }
            else if (chk_CitaSupervicion.Checked)
            {
                EventNotaCitaTitle = "Cita";
                consultaEvento.opcionForma = (int)Enums.EventoNotacita.Cita;
            }

            consultaEvento.CargarLista();

            if (consultaEvento.listMain.Count == 0)
            {
                MessageBox.Show("No cuenta con movimientos a consultar", EventNotaCitaTitle, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                Visible = false;
                consultaEvento.ShowDialog();
                Visible = true;
            }
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            DM0312_ExploradorVentas.EjecutaEvento = true;
            Dispose();
        }

        private void chk_Eventos_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta evento =
                ListaEventosNotasCitasComentario.FirstOrDefault(x => x.Campo.Equals("Evento"));
            txt_ComentarioAyuda.Text = evento != null ? evento.Comentario : "";
        }

        private void chk_Nota_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta
                nota = ListaEventosNotasCitasComentario.FirstOrDefault(x => x.Campo.Equals("Nota"));
            txt_ComentarioAyuda.Text = nota != null ? nota.Comentario : "";
        }

        private void chk_CitaSupervicion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta nota = ListaEventosNotasCitasComentario
                .Where(x => x.Campo.Equals("Cita Supervision")).FirstOrDefault();
            txt_ComentarioAyuda.Text = nota != null ? nota.Comentario : "";
        }

        #endregion
    }
}