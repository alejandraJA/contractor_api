﻿namespace PuntoVenta.View
{
    partial class RedDima
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RedDima));
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.cbx_Cuenta = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnBuscarClienteAlerta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(-2, 2);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(285, 35);
            this.txt_Comentarios.TabIndex = 108;
            this.txt_Comentarios.Text = "SI CUENTAS CON RECOMENDADOR INGRESA CUENTA  SI NO PRESIONA CANCELAR";
            // 
            // cbx_Cuenta
            // 
            this.cbx_Cuenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Cuenta.Location = new System.Drawing.Point(77, 80);
            this.cbx_Cuenta.MaxLength = 9;
            this.cbx_Cuenta.Name = "cbx_Cuenta";
            this.cbx_Cuenta.Size = new System.Drawing.Size(100, 22);
            this.cbx_Cuenta.TabIndex = 109;
            this.cbx_Cuenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Cuenta_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(79, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 15);
            this.label15.TabIndex = 110;
            this.label15.Text = "Cliente";
            // 
            // btnAceptar
            // 
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Image = ((System.Drawing.Image)(resources.GetObject("btnAceptar.Image")));
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAceptar.Location = new System.Drawing.Point(127, 140);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(358, 5, 3, 10);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 76);
            this.btnAceptar.TabIndex = 112;
            this.btnAceptar.Text = "Aceptar (Crtl-G)";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancelar.Location = new System.Drawing.Point(208, 140);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 76);
            this.btnCancelar.TabIndex = 113;
            this.btnCancelar.Text = "Cancelar (Esc)";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnBuscarClienteAlerta
            // 
            this.btnBuscarClienteAlerta.BackColor = System.Drawing.Color.White;
            this.btnBuscarClienteAlerta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBuscarClienteAlerta.BackgroundImage")));
            this.btnBuscarClienteAlerta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBuscarClienteAlerta.FlatAppearance.BorderSize = 0;
            this.btnBuscarClienteAlerta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarClienteAlerta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarClienteAlerta.Location = new System.Drawing.Point(183, 80);
            this.btnBuscarClienteAlerta.Name = "btnBuscarClienteAlerta";
            this.btnBuscarClienteAlerta.Size = new System.Drawing.Size(25, 23);
            this.btnBuscarClienteAlerta.TabIndex = 111;
            this.btnBuscarClienteAlerta.UseVisualStyleBackColor = false;
            this.btnBuscarClienteAlerta.Click += new System.EventHandler(this.btnBuscarClienteAlerta_Click);
            // 
            // RedDima
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(281, 215);
            this.ControlBox = false;
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnBuscarClienteAlerta);
            this.Controls.Add(this.cbx_Cuenta);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_Comentarios);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Name = "RedDima";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ingreso Red DIMA";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RedDima_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.Button btnBuscarClienteAlerta;
        private System.Windows.Forms.TextBox cbx_Cuenta;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
    }
}