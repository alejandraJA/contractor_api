﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Conversiones;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.Properties;
using PuntoVenta.Reports;
using PuntoVenta.Utilidades;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_DetalleVenta : Form
    {
        public static List<MDetalleVenta> ListaDetalles = new List<MDetalleVenta>();
        public static bool EventoInsertado;
        public static DM0312_CPuntoDeVenta controladorV = new DM0312_CPuntoDeVenta();
        public static bool VerCantidadPendiente;

        //-Venta Cruzada
        //Variables estaticas para la forma de Situacion (DM0312_DetalleSituaciones) que se manda a llamar desde ClaveSeguimiento.cs
        public static List<DM0312_MExploradorVenta> VentasSelecEventos = new List<DM0312_MExploradorVenta>();
        public static int paginaSeleccionada;

        //-Primera Fase Automatizacion
        public static bool almacen96Afectar;
        public static bool almacen2000Afectar;
        public static string usuarioAlmacen96 =
#if PRODUCCION
            "FACTU00046"; //Usuario Generico para poder afectar almacen V00096  
#else
            "FACTU00046";
#endif
        public static string usuarioAlmacen2000 =
#if PRODUCCION
            "FACTU00053"; //Usuario Generico para poder afectar almacen V02000  
#else
            "FACTU00053";
#endif

        private bool Afectando;
        private List<MAlmacen> AlmacenesDisponibles = new List<MAlmacen>();
        private double BanderaRecibidoMinimo;
        private List<DatosEntrega> BitacoraEntregas = new List<DatosEntrega>();
        private string CategoriaEnviarA = string.Empty, ReporteServicio = string.Empty;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool ClienteC = false;
        public bool ClienteNuevo = false;
        private int contadorSMS;
        private readonly CAlmacenes ControladorAlmacenes = new CAlmacenes();
        private readonly CSerieArticulos ControladorSerie = new CSerieArticulos();
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        private List<MCodigosPostales> Cps = new List<MCodigosPostales>();
        private readonly CReporteServicios CReporte = new CReporteServicios();
        private readonly fusionAppControlador ctrFusionApp = new fusionAppControlador();
        public ConfiguracionesUsuario CUsuario = AccesosDeUsuario.CUsuario;
        private List<ArticulosDetalleVenta> DatosDetalles = new List<ArticulosDetalleVenta>();
        private List<ArticulosDetalleVenta> DatosDetallesSinOrdenar = new List<ArticulosDetalleVenta>();
        private List<string> Detalles = new List<string>();

        private readonly Action<bool, Form> EnableControls;

        private readonly int EnteroPosicionArticulo = 0;
        private readonly int EnteroPosicionCantidad = 1;
        public bool FlagAbrirDeHistorial = false, NuevaEntrega, AnticiposEnviados;
        private bool FlagToBlink, ActualizarReporte = true;
        private readonly List<string> FormasPagoAgregadas = new List<string>();
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public bool FromPuntoVenta = false;
        private readonly Funciones funciones = new Funciones();
        private int gpbxheightClosed = 480, gpbxheightOpen = 780, gpbxHeightC, gpbxHeightO, FormasPagoTag;
        private readonly Dictionary<int, string> LastFormaPagoSelected = new Dictionary<int, string>();
        private List<DM0312_MComentariosVenta> ListaAgregaEventoComentario = new List<DM0312_MComentariosVenta>();
        private readonly List<MAnticipos> ListaAnticipos = new List<MAnticipos>();
        public List<MDetalleVenta> ListaDetallesSeleccionados = new List<MDetalleVenta>();

        private List<appFusionModel> listaImagenes;
        private List<MSituaciones> ListaSituaciones = new List<MSituaciones>();

        //-CerradoIntelisis
        private readonly DM0312_C_Login loginC = new DM0312_C_Login();
        private readonly DM0312_MVentaDetalle modeloVentaDetalle = new DM0312_MVentaDetalle();
        private int modificarCobro;
        private bool MovEsValera;

        //-ReporteDescuento
        private string origenReporte = "";
        public int PaginadoActual;

        //-Aplinet
        public string[] ParametrosAfectarAnticipo;
        public string[] ParametrosAnticipos;

        private string PrecioCostoAnterior = "";

        //entero para saber cuantas formas de pago existen
        private readonly DM0312_CPuntoDeVenta pventa = new DM0312_CPuntoDeVenta();
        private double RecibidoMinimo;
        private double saldoRestante, montoTotal;

        private readonly SolicitudCancelacionesController
            solicitudCancelacionC = new SolicitudCancelacionesController();

        //-PedidoSinDetalle
        private readonly clsStd std = new clsStd();

        //-864 GESSY  Vars 
        private string str_CustomAlertResult = "";

        private readonly Dictionary<string, CDetalleVenta.ValAfectar> ValidaAfectacion =
            new Dictionary<string, CDetalleVenta.ValAfectar>();

        private VentaController ventaController = new VentaController();
        public List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
        private bool VerCosto;

        public DM0312_DetalleVenta()
        {
            InitializeComponent();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);
            MouseWheel += Wheel;
            panelmenu.Location = new Point(2, 1);
            timer1.Tick += PanelBlink;
            timer1.Interval = 500;
            timer1.Enabled = true;
            CDetalleVenta.FromDetalle = true;

            EnableControls = CDetalleVenta.DesabilitarControles;
            ValidaAfectacion["AntesDe"] = CDetalleVenta.ValidacionesAfectar;
            ValidaAfectacion["DespuesDe"] = CDetalleVenta.CondicionAfectar;
        }

        ~DM0312_DetalleVenta()
        {
            Trace.WriteLine("elimino ");
            Debug.WriteLine("Salio");

            //-PedidosSinDetalle
            foreach (DM0312_MExploradorVenta item in VentasSeleccionadas) std.insertarIdVenta(item.ID, 2);

            GC.Collect();
        }

        /// <summary>
        ///     Method to fix focus on form and work with repainting
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/10/17
        private void Wheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
                lbl_Cliente.Focus();
            else
                btn_Anticipo.Focus();
            panelmenu.Location = new Point(2, 1);
        }

        /// <summary>
        ///     Metodos de load
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        public async void LoadEvent()
        {
            btn_detalleAnterior.Visible = false;

            //Se asigna valores seleccionados del explorador a una nueva lista
            if (VentasSeleccionadas != null && VentasSeleccionadas.Count == 0)
            {
                VentasSeleccionadas = new List<DM0312_MExploradorVenta>(DM0312_ExploradorVentas.ListaExplorador);
                ListaDetallesSeleccionados = new List<MDetalleVenta>(ListaDetalles);
            }

            //-1235
            btn_Eliminar.Visible = VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR"
                                   && string.IsNullOrEmpty(VentasSeleccionadas[PaginadoActual].MovId)
                                   && !CDetalleVenta.obtenerDetalle(VentasSeleccionadas[PaginadoActual].ID);


            if (!CDetalleVenta.MovimientoGenerado)
            {
                PaginadoActual = 0;
                if (VentasSeleccionadas != null && VentasSeleccionadas.Count == 1)
                    btn_detallePosterior.Visible = false;
                else
                    btn_detallePosterior.Visible = true;
            }
            else
            {
                btn_detallePosterior.Visible = true;
                if (PaginadoActual > 0) btn_detalleAnterior.Visible = true;
                if (PaginadoActual == VentasSeleccionadas.Count - 1) btn_detallePosterior.Visible = false;
            }

            try
            {
                ObtenerInformacionTablero();
                if (dgv_detalle.Rows.Count > 0) dgv_detalle.Rows[0].Selected = true;

                CDetalleVenta.PaginadoActual = PaginadoActual;
                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    EnableControls(false, this);
                    panelmenu.Location = new Point(2, 1);
                }

                Cps = await Task.Run(() => CDetalleVenta.ObtenerCps());
                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    EnableControls(true, this);
                }
                //Metodo para mostar/ocultar botones dentro de la configuracion de usuario

                NuevaEntrega = false;

                //Parche para que el detalle que encima del tablero cuando se crea un nuevo movimiento
                await Task.Run(async () => { await Task.Delay(500); });
                TopMost = false;

                //Inserta anticipos
                if (AnticiposEnviados)
                {
                    AnticiposEnviados = false;
                    if (!frmLoading.Visible)
                    {
                        frmLoading.Show(this);
                        EnableControls(false, this);
                        panelmenu.Location = new Point(2, 1);
                    }

                    ParametrosAnticipos[(int)Enums.ParametrosAnticipos.Referencia] =
                        VentasSeleccionadas[PaginadoActual].Mov + " " + VentasSeleccionadas[PaginadoActual].MovId;
                    int nuevoID = 0;
                    Afectando = true;
                    string RespuestaTransaction =
                        await Task.Run(() => CDetalleVenta.InsertAnticipos(ParametrosAnticipos, out nuevoID));
                    string[] Parametros =
                    {
                        VentasSeleccionadas[PaginadoActual].Mov,
                        VentasSeleccionadas[PaginadoActual].MovId,
                        VentasSeleccionadas[PaginadoActual].MovTipo,
                        VentasSeleccionadas[PaginadoActual].ID.ToString()
                    };
                    string c = "";
                    ObtenerAnticipos(Parametros, c);
                    if (frmLoading.Visible)
                    {
                        frmLoading.Hide();
                        EnableControls(true, this);
                    }

                    Afectando = false;

                    if (RespuestaTransaction != string.Empty && RespuestaTransaction != "80030")
                    {
                        MessageBox.Show(RespuestaTransaction, ParametrosAnticipos[(int)Enums.ParametrosAnticipos.Mov],
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        CDetalleVenta.ImprimirAnticipos(nuevoID);
                        Fajillas(true);
                    }

                    ObtenerInformacionTablero();
                }

                gb_anticipos.Visible = false;

                //Agregar combobox y label de pago
                AgregarFormaPago();
                txt_anticipototal.Text = "$ 0";

                if (contadorSMS == 1)
                {
                    string Canal = txt_Canal.Text;
                    string categoria = CDetalleVenta.ObtenerCategoriaT(Canal);
                    if ((VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "Prestamo Personal" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "Credilana" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU") &&
                        VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
                    {
                        if (controladorV.ValidarClienteGenerico(VentasSeleccionadas[PaginadoActual].Cliente) == "NO")
                            if (controladorV.SucursalesSinTarjeta() == "NO")
                            {
                                string catF = "";
                                if (categoria.Contains("_"))
                                    catF = categoria.Replace("_", " ");
                                else
                                    catF = categoria;
                                if (controladorV.TarjetaDep(catF) == "SI")
                                    if (controladorV.NumTarj(VentasSeleccionadas[PaginadoActual].Cliente) == "0")
                                    {
                                        if (Convert.ToInt32(Canal) == 6)
                                        {
                                            if (controladorV.VentasMenudeo(VentasSeleccionadas[PaginadoActual]
                                                    .Cliente) != "NO")
                                            {
                                                DialogResult dialogResult = MessageBox.Show(
                                                    "El cliente " + VentasSeleccionadas[PaginadoActual].Cliente +
                                                    " no tiene registrada una tarjeta departamental ¿Desea registrar una?",
                                                    "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                if (dialogResult == DialogResult.Yes) TarjetaDepartamental(true);
                                            }
                                        }
                                        else
                                        {
                                            DialogResult dialogResult = MessageBox.Show(
                                                "El cliente " + VentasSeleccionadas[PaginadoActual].Cliente +
                                                " no tiene registrada una tarjeta departamental ¿Desea registrar una?",
                                                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                            if (dialogResult == DialogResult.Yes) TarjetaDepartamental(true);
                                        }
                                    }
                            }

                        int canal = controllerExplorador.idCanal(VentasSeleccionadas[PaginadoActual].Canal);
                        if (CDetalleVenta.SMStablaConversion(canal) != "NO")
                        {
                            string ClienteN = "";
                            int Nuevo = 0;
                            if (canal == 3)
                            {
                                if (CDetalleVenta.SMStablaConversionValor(canal) == "1")
                                {
                                    ClienteN = controladorV.validaCasa(VentasSeleccionadas[PaginadoActual].Cliente,
                                        canal);
                                    if (ClienteN == "Nuevo") Nuevo = 1;
                                }
                            }
                            else
                            {
                                if (canal == 7)
                                    if (CDetalleVenta.SMStablaConversionValor(canal) == "1")
                                    {
                                        ClienteN = controladorV.validaCasa(VentasSeleccionadas[PaginadoActual].Cliente,
                                            canal);
                                        if (ClienteN == "Nuevo") Nuevo = 2;
                                    }
                            }

                            CDetalleVenta.SMSCompras(VentasSeleccionadas[PaginadoActual].ID,
                                VentasSeleccionadas[PaginadoActual].Cliente, Nuevo);
                        }

                        if (CDetalleVenta.SMStablaConversionSegurosValor() == "1")
                            if (canal == 76)
                            {
                                string clienteF = "";
                                clienteF = CDetalleVenta.ClienteFinal(VentasSeleccionadas[PaginadoActual].ID);
                                CDetalleVenta.SMSBeneficiarioFinal(VentasSeleccionadas[PaginadoActual].ID,
                                    VentasSeleccionadas[PaginadoActual].Cliente, clienteF);
                            }
                    }
                }

                contadorSMS = 0;

                if (VentasSeleccionadas[PaginadoActual].Mov != "Analisis Credito")
                {
                    DM0312_CPuntoDeVenta cPuntoDeVenta = new DM0312_CPuntoDeVenta();
                    if (cPuntoDeVenta.ValidarSucursalDie())
                        if (cPuntoDeVenta.validarCanalVentaDie(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA)))
                        {
                            bool dieC = CDetalleVenta.VerificarDie(VentasSeleccionadas[PaginadoActual].ID);
                            if (dieC)
                            {
                                bool bEstatusDie =
                                    CDetalleVenta.obtenerEstatusDie(VentasSeleccionadas[PaginadoActual].ID);
                                chx_Die.Visible = true;
                                chx_Die.Checked = bEstatusDie;
                                if (!bEstatusDie)
                                {
                                    bool bEstatusStp =
                                        CDetalleVenta.obtenerEstatusStp(VentasSeleccionadas[PaginadoActual].ID);
                                    chkTransferencia.Visible = true;
                                    chkTransferencia.Checked = bEstatusStp;
                                }
                            }
                            else
                            {
                                chx_Die.Visible = false;
                                chx_Die.Checked = dieC;

                                chkTransferencia.Visible = false;
                                chkTransferencia.Checked = dieC;
                            }
                        }
                }


                //-1592
                //chkTransferencia.Checked = ListaDetalles[PaginadoActual].bCheckMondero;
                if (chkTransferencia.Checked)
                {
                    chkTransferencia.Visible = true;
                    if (!string.IsNullOrEmpty(ListaDetalles[PaginadoActual].sCuentaClabe))
                    {
                        string sUltimosDigitos = ListaDetalles[PaginadoActual].sCuentaClabe
                            .Substring(ListaDetalles[PaginadoActual].sCuentaClabe.Length - 4, 4);
                        txtCuentaClabe.Text = "****-****-****-**" + sUltimosDigitos.Replace("-", "");
                        txtBanco.Text = ListaDetalles[PaginadoActual].sBanco;
                    }
                }

                //CorrecionDie
                //chx_Die.Enabled = true;
                if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
                {
                    if (chx_Die.Visible) chx_Die.Enabled = false;
                    if (chkTransferencia.Visible)
                    {
                        chkTransferencia.Enabled = false;
                        camposBanco(false, 2);
                    }
                }

                //-864 GESSY  Historia 1 Deshabilitar Check chx_Die
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito") chx_Die.Enabled = false;

                if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                    VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE"
                    && (VentasSeleccionadas[PaginadoActual].Situacion == "Liberado"
                        || VentasSeleccionadas[PaginadoActual].Situacion == "No liberado"
                        || VentasSeleccionadas[PaginadoActual].Situacion == "En espera de autorizacion"
                        || string.IsNullOrEmpty(VentasSeleccionadas[PaginadoActual].Situacion)
                    )
                   )
                    chx_Die.Enabled = false;

                // 1573 DISABLE CHK
                if (VentasSeleccionadas[PaginadoActual].Mov == "CREDILANA" &&
                    VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                    chx_Die.Enabled = false;

                if (ClaseEstatica.Usuario.Sucursal == 96 || ClaseEstatica.Usuario.Sucursal == 98)
                    cb_Almacen.Text = CDetalleVenta.obtenerAlmace(VentasSeleccionadas[PaginadoActual].ID);

                btn_datosEntrega.Visible = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LoadEvent", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LlenaFormaDeCobroLinea(string formaActual)
        {
            try
            {
                modificarCobro = 1;
                List<string> datosFormaCobroLinea = new List<string>();
                datosFormaCobroLinea = new List<string>();
                datosFormaCobroLinea = controladorV.LlenaFormaDeCobro(formaActual);
                if (datosFormaCobroLinea.Count > 0)
                {
                    txt_FormaCo.DataSource = null;
                    modificarCobro = 1;
                    txt_FormaCo.DataSource = datosFormaCobroLinea.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaFormaDeEnvio", "DM0312_DetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     form load event
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void Detalle_Load(object sender, EventArgs e)
        {
            chx_Die.Visible = false;
            btn_Situaciones.Enabled = true;
            label1.Visible = false;
            txt_FormaCo.Visible = false;

            dgv_detalle.ColumnHeadersDefaultCellStyle.Font =
                new Font(new FontFamily("Times New Roman"), 12f, FontStyle.Bold);
            dgv_datosEntrega.ColumnHeadersDefaultCellStyle.Font =
                new Font(new FontFamily("Times New Roman"), 12f, FontStyle.Bold);
            ListaAgregaEventoComentario = Funciones.ConsultaComentario("DETALLE");
            DM0312_MComentariosVenta Mcomentario =
                ListaAgregaEventoComentario.FirstOrDefault(x => x.Campo.Equals("lbl_comentariosDatosEntrega"));
            if (Mcomentario != null)
                lbl_comentariosDatosEntrega.Text = Mcomentario.Comentario;
            else
                lbl_comentariosDatosEntrega.Text = "";

            btn_detalleAnterior.Visible = false;
            LoadEvent();
            std.insertarIdVenta(VentasSeleccionadas[PaginadoActual].ID, 1);
            if (!CDetalleVenta.MovimientoGenerado)
            {
                PaginadoActual = 0;
                if (VentasSeleccionadas != null && VentasSeleccionadas.Count == 1)
                    btn_detallePosterior.Visible = false;
                else
                    btn_detallePosterior.Visible = true;
            }
            else
            {
                btn_detallePosterior.Visible = true;
                if (PaginadoActual > 0) btn_detalleAnterior.Visible = true;
                if (PaginadoActual == VentasSeleccionadas.Count - 1) btn_detallePosterior.Visible = false;
            }

            if (dgv_detalle.Rows.Count > 0) dgv_detalle.Rows[0].Selected = true;

            gbx_DatosEntrega.Visible = false;
            if (lbl_Comentario.Visible)
            {
                gpbxheightClosed = gpbxheightClosed + 20;
                gpbxheightOpen = gpbxheightOpen + 20;
            }

            if (chk_Mayoreo.Visible)
            {
                gpbxheightClosed = gpbxheightClosed + 10;
                gpbxheightOpen = gpbxheightOpen + 10;
            }

            if (lbl_Observaciones.Visible)
            {
                gpbxheightClosed = gpbxheightClosed + 20;
                gpbxheightOpen = gpbxheightOpen + 20;
            }

            if (lbl_CtaPago.Visible)
            {
                gpbxheightClosed = gpbxheightClosed + 20;
                gpbxheightOpen = gpbxheightOpen + 20;
            }

            if (txt_FormaPago.Visible)
            {
                gpbxheightClosed = gpbxheightClosed + 60;
                gpbxheightOpen = gpbxheightOpen + 60;
            }

            gpbxHeightC = gpbxheightClosed;
            gpbxHeightO = gpbxheightOpen;
            for (int i = 0; i < dgv_detalle.Rows.Count; i++)
            {
                gpbxHeightC = gpbxHeightC + 10;
                gpbxHeightO = gpbxHeightO + 10;
            }

            flpanel.Height = gpbxHeightC;
            if (FromPuntoVenta && ClienteNuevo && ClienteC) Btn_HojaV_Click(null, null);

            //-Datalogic
            if (ClaseEstatica.iRecarga == 1 &&
                !CDetalleVenta.validarCanalVenta(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA)))
            {
                btn_datosEntrega.Visible = false;
                btn_Situaciones.Enabled = false;
            }

            btn_Situaciones.Enabled = true;

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_detalle.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                panelmenu.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_detalle.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_detalle.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                panelmenu.BackColor = Color.LightCyan;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_detalle.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                panelmenu.BackColor = Color.WhiteSmoke;
            }

            if (btn_datosEntrega.Visible)
                lbl_comentariosDatosEntrega.Visible = true;
            else
                lbl_comentariosDatosEntrega.Visible = false;

            Tooltip();

            txt_Comentario.Enabled = true;
            txt_Comentario.Select();
            btnGuardarComentarios.Visible = true;


            //-Die
            if (VentasSeleccionadas[PaginadoActual].Mov != "Analisis Credito")
            {
                DM0312_CPuntoDeVenta cPuntoDeVenta = new DM0312_CPuntoDeVenta();
                if (cPuntoDeVenta.ValidarSucursalDie())
                    if (cPuntoDeVenta.validarCanalVentaDie(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA)))
                    {
                        bool dieC = CDetalleVenta.VerificarDie(VentasSeleccionadas[PaginadoActual].ID);
                        if (dieC)
                        {
                            bool bEstatusDie = CDetalleVenta.obtenerEstatusDie(VentasSeleccionadas[PaginadoActual].ID);
                            chx_Die.Visible = true;
                            chx_Die.Checked = bEstatusDie;
                        }
                        else
                        {
                            chx_Die.Visible = false;
                            chx_Die.Checked = dieC;
                        }
                    }
            }

            //CorrecionDie
            if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
                if (chx_Die.Visible)
                    chx_Die.Enabled = false;

            //-596AlmacenensVirtuales
            if (CDetalleVenta.validarSucursalAlmacenVirtual())
            {
                label1.Visible = true;
                txt_FormaCo.Visible = true;
                string formaC = "";
                formaC = CDetalleVenta.FormaCobroL(VentasSeleccionadas[PaginadoActual].ID);

                if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                {
                    modificarCobro = 1;
                    LlenaFormaDeCobroLinea(formaC);
                }
                else
                {
                    modificarCobro = 1;
                    txt_FormaCo.Text = formaC;
                    txt_FormaCo.Enabled = false;
                }

                txt_Commerce.Enabled = true;
                txt_FormaPago.Enabled = true;
            }

            //-MejorasMayoreo
            if (VentasSeleccionadas[PaginadoActual].Mov.Equals("Pedido Mayoreo") &&
                VentasSeleccionadas[PaginadoActual].Estatus.Equals("PENDIENTE"))
            {
                btn_datosEntrega.Visible = false;
                lbl_comentariosDatosEntrega.Visible = false;
            }

            //-AsignacionCanalVenta
            if (!ValidaCanal()) AgregaNuevoCanal();

            listaImagenes = ctrFusionApp.obtenerImagenes(VentasSeleccionadas[PaginadoActual].Cliente);
            if (listaImagenes.Count >= 1)
                if (!ctrFusionApp.validarImagenesValidadas(VentasSeleccionadas[PaginadoActual].ID))
                    btnDocumentos.Visible = true;

            //-1450
            if (std.usuarioTieneAccesoAbtnEmbarcar() &&
                !CDetalleVenta.validarEmbarcado(VentasSeleccionadas[PaginadoActual].ID))
                if (new[] { "Pedido", "Pedido Mayoreo", "Factura", "Factura VIU", " Factura Mayoreo" }.Contains(
                        VentasSeleccionadas[PaginadoActual].Mov))
                    btnEmbarcar.Visible = true;

            if (CDetalleVenta.EsTransferenciaSpei(VentasSeleccionadas[PaginadoActual].MovId))
                btn_Cancelar.Enabled = false;

            // 1707
            string[] subs = txt_Correo.Text.Split('@');
            if (subs.Contains("@GENAV.MX"))
                txt_Correo.Text = "SINCORREO@SINCORREO.COM";
        }

        /// <summary>
        ///     Metodo encargado de insertar el canal de venta en caso de no tenerlo
        /// </summary>
        public void AgregaNuevoCanal()
        {
            try
            {
                bool Inserta = new bool();
                DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
                Inserta = controlador.AgregaNuevoCanal(VentasSeleccionadas[PaginadoActual].Cliente,
                    Convert.ToInt32(VentasSeleccionadas[PaginadoActual].EnviarA));
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de validar si el cliente cuenta con el canal de venta de que se esta validando
        /// </summary>
        /// <returns>retorna true si se encuentra el canla de venta de lo contrario regresa false</returns>
        public bool ValidaCanal()
        {
            bool bExiste = false;
            try
            {
                DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
                List<DM0312_MPuntoDeVentaCanales> listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
                listaCanal = controlador.LlenaCanalesCliente(VentasSeleccionadas[PaginadoActual].Cliente);
                DM0312_MPuntoDeVentaCanales var = listaCanal
                    .Where(x => x.Canal == Convert.ToInt32(VentasSeleccionadas[PaginadoActual].EnviarA))
                    .FirstOrDefault();
                if (var != null)
                    bExiste = true;
                else
                    bExiste = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }

            return bExiste;
        }


        public void Tooltip()
        {
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR AL EXPLORADOR DE VENTAS");
            toolTip1.SetToolTip(btn_Imprimir,
                "SELECCIONAR PARA IMPRIMIR EL/LA " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(btn_Situaciones,
                "SELECCIONAR PARA SEGUIR EL PROCESO DE LA VENTA Y PODER AFECTARLA ANTES SE TIENEN QUE AGREGAR LAS SITUACIONES CORRESPONDIENTES PARA EL MOVIMIENTO " +
                VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(btn_Afectar,
                "SELECCIONAR PARA CONTINUAR EL PROCESO Y AFECTAR EL MOVIMIENTO: " +
                VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(btn_Eliminar,
                "SELECCIONAR PARA ELIMINAR EL MOVIMIENTO: " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(btn_Cancelar,
                "SELECCIONAR PARA CANCELAR EL MOVIMIENTO: " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(btn_InfoArt,
                "SELECCIONAR PARA VER LA INFORMACION MAS IMPORTANTE DEL ARTICULO SELECCIONADO");
            toolTip1.SetToolTip(btn_Eventos,
                "SELECCIONAR PARA MANDAR LLAMAR LA HERRAMIENTAS DE EVENTOS, NOTAS Y CITAS");
            toolTip1.SetToolTip(btn_HojaV,
                "SELECCIONAR SI NECESITA CONSULTAR O ACTUALIZAR LA INFORMACION DEL CLIENTE: " +
                VentasSeleccionadas[PaginadoActual].Cliente.ToUpper());
            toolTip1.SetToolTip(btn_SHM,
                "SELECCIONAR PARA MANDAR LLAMAR EL SHM Y ACTUALIZAR O AGREGAR LA VALIDACION DE CREDITO");
            toolTip1.SetToolTip(btn_AdjuntarSHM,
                "SELECCIONAR PARA ADJUNTAR DOCUMENTOS AL CLIENTE: " +
                VentasSeleccionadas[PaginadoActual].Cliente.ToUpper());
            toolTip1.SetToolTip(btn_Ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DEL DETALLE DE LA VENTA");
            toolTip1.SetToolTip(btn_detalleAnterior, "SELECCIONAR PARA PASAR A LA INFORMACION DEL MOVIMIENTO ANTERIOR");
            toolTip1.SetToolTip(btn_detallePosterior,
                "SELECCIONAR PARA PASAR A LA INFORMACION DEL MOVIMIENTO POSTERIOR");

            toolTip1.SetToolTip(lbl_Cliente, "NUMERO DE CUENTA DEL CLIENTE");
            toolTip1.SetToolTip(txt_Cliente, "NUMERO DE CUENTA DEL CLIENTE");
            toolTip1.SetToolTip(txt_Cliente1, "NOMBRE DEL CLIENTE");
            toolTip1.SetToolTip(lbl_TipoVenta, "FORMA DE PAGAR LA VENTA");
            toolTip1.SetToolTip(txt_TipoVenta, "FORMA DE PAGAR LA VENTA");
            toolTip1.SetToolTip(lbl_Agente, " VENDEDOR QUE REALIZA EL MOVIMIENTO");
            toolTip1.SetToolTip(txt_Agente, " VENDEDOR QUE REALIZA EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Canal, "FORMA DE VENTA COMO APARTADO,CONTADO,CREDITO,ETC");
            toolTip1.SetToolTip(txt_Canal, "FORMA DE VENTA COMO APARTADO,CONTADO,CREDITO,ETC");
            toolTip1.SetToolTip(txt_Canal1, "NOMBRE DEL CANAL");

            toolTip1.SetToolTip(lbl_Condiciones, "EL PLAZO DE LA VENTA");
            toolTip1.SetToolTip(txt_Condiciones, "EL PLAZO DE LA VENTA");
            toolTip1.SetToolTip(lbl_Almacen, "ALMACEN DONDE SE VA A FACTURAR LA MERCANCIA PARA EL CLIENTE");
            toolTip1.SetToolTip(cb_Almacen,
                "ALMACEN DONDE SE VA A FACTURAR LA MERCANCIA PARA EL CLIENTE, SE PUEDE MODIFICAR MIENTRAS EL MOVMIENTO ESTE CON ESTATUS PENDIENTE");
            toolTip1.SetToolTip(lbl_Correo, "MUESTRA LA CUENTA Y EL DOMINIO DE CORREO ELECTRONICO");
            toolTip1.SetToolTip(txt_Correo, "MUESTRA LA CUENTA Y EL DOMINIO DE CORREO ELECTRONICO");
            toolTip1.SetToolTip(lbl_Referencia, "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA DEVOLUCION VENTA");
            toolTip1.SetToolTip(txt_Referencia, "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA DEVOLUCION VENTA");
            toolTip1.SetToolTip(lbl_Concepto, "CAUSA POR LAS QUE SE GENERA LA DEVOLUCION O ADJUDICACION");
            toolTip1.SetToolTip(txt_Concepto, "CAUSA POR LAS QUE SE GENERA LA DEVOLUCION O ADJUDICACION");

            toolTip1.SetToolTip(lbl_Ecommerce, "FOLIO DEL PEDIDO REALIZADO VIA INTERNET");
            toolTip1.SetToolTip(txt_Commerce, "FOLIO DEL PEDIDO REALIZADO VIA INTERNET");
            toolTip1.SetToolTip(lbl_FormaPago, "FORMA EN QUE PAGARA EL CLIENTE ");
            toolTip1.SetToolTip(txt_FormaPago, "FORMA EN QUE PAGARA EL CLIENTE ");
            toolTip1.SetToolTip(lbl_Enganche,
                "EL TOTAL DE ANTICIPOS O ENGANCES QUE SE HAN REALIZADO AL MOVIMIENTO " +
                VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(txt_Enganche,
                "EL TOTAL DE ANTICIPOS O ENGANCES QUE SE HAN REALIZADO AL MOVIMIENTO " +
                VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].MovId.ToUpper() + " " +
                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper());
            toolTip1.SetToolTip(lbl_RedMonedero, "IMPORTE DE REDENCION EN LA CUENTA MONEDERO");
            toolTip1.SetToolTip(txt_Monedero, "IMPORTE DE REDENCION EN LA CUENTA MONEDERO");
            toolTip1.SetToolTip(lbl_Embarque, "FOLIO DEL EMBARQUE");
            toolTip1.SetToolTip(txt_Embarque, "FOLIO DEL EMBARQUE");

            toolTip1.SetToolTip(txt_EmbarqueFecha, "FECHA POSIBLE DEL EMBARQUE");
            toolTip1.SetToolTip(chk_Mayoreo,
                "SI ESTA ACTIVO GENERA 50 % DE COMISION AL AGENTE EXTERNO POR PRODUCTO COTIZADO");
            toolTip1.SetToolTip(chk_Custodia, "INDICA QUE LA MERCANCIA QUEDA EN RESGUARDO");
            toolTip1.SetToolTip(chk_Iva, "MUESTRA EL IVA DESGLOSADO EN LA FACTURA MAYOREO");
            toolTip1.SetToolTip(chk_Comentario, "");
            toolTip1.SetToolTip(lbl_AgenteServicio, "AGENTE EXTERNO QUE REALIZO LA VENTA");
            toolTip1.SetToolTip(txt_AgenteServicio, "AGENTE EXTERNO QUE REALIZO LA VENTA");
            toolTip1.SetToolTip(lbl_FormaEnvio, "FORMA EN QUE PAGARA EL CLIENTE ");
            toolTip1.SetToolTip(txt_FormaEnvio, "FORMA EN QUE PAGARA EL CLIENTE ");
            toolTip1.SetToolTip(lbl_CtaPago, "");

            toolTip1.SetToolTip(txt_CtaPago, "");
            toolTip1.SetToolTip(cb_ServicioReporte, "SELECCIONAR PARA OFRECER UN SERVICIO A UN ARTICULO DAÑADO");
            toolTip1.SetToolTip(lbl_nomina, "MUESTRA LA NOMINA DEL EMPLEADO AL QUE SE LE REALIZO LA VENTA");
            toolTip1.SetToolTip(tb_nomina, "MUESTRA LA NOMINA DEL EMPLEADO AL QUE SE LE REALIZO LA VENTA");
            toolTip1.SetToolTip(lbl_Observaciones, "");
            toolTip1.SetToolTip(txt_Observaciones, "");
            toolTip1.SetToolTip(lbl_Comentario, "");
            toolTip1.SetToolTip(txt_Comentario, "");

            /////////////////////////////DETALLE DE VENTA Y NIP////////////////////////////////////

            toolTip1.SetToolTip(lbl_SubTotal, "PRECIO DE LA COMPRA SIN IMPUESTOS");
            toolTip1.SetToolTip(txt_SubTotal, "PRECIO DE LA COMPRA SIN IMPUESTOS");
            toolTip1.SetToolTip(lbl_Impuestos, "LOS IMPUESTOS QUE GENERO LA COMPRA");
            toolTip1.SetToolTip(txt_Impuestos, "LOS IMPUESTOS QUE GENERO LA COMPRA");
            toolTip1.SetToolTip(lbl_Total, "PRECIO TOTAL: SUMA DEL SUBTOTAL Y DE LOS IMPUESTOS DE LA COMPRA");
            toolTip1.SetToolTip(txt_Total, "PRECIO TOTAL: SUMA DEL SUBTOTAL Y DE LOS IMPUESTOS DE LA COMPRA");
            toolTip1.SetToolTip(txt_NIP, "NIP DE VENTA PERSONAL DEL CLIENTE DIMA, FAVOR DE SOLICITARLO");
            toolTip1.SetToolTip(txt_vale, "NUMERO DEL VALE DE COMPRA DIMA");

            //////////////////////////datos entrega//////////////////////////////////////
            lbl_comentariosDatosEntrega.Text =
                "SELECCIONAR LA DIRECCION DE ENTREGA DE LA MERCANCIA SI NO EXISTE EN EL CATALOGO DE DIRECCIONES DEL CLIENTE SELECCIONAR EL BOTON DE NUEVO";
            toolTip1.SetToolTip(btn_nuevaEntrega, "SELECCIONAR PARA AGREGAR NUEVA DIRECCION DE ENTREGA DE MERCANCIA");
            toolTip1.SetToolTip(btn_guardar,
                "SELECCIONAR PARA GUARDAR LA DIRECCION DE ENTREGA VERIFICAR QUE LA INFORMACION SEA CORRECTA");
            toolTip1.SetToolTip(txt_direccionEntrega, "AGREGAR LA DIRECCION A LA QUE SE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(lbl_direccion, "DIRECCION A LA QUE SE ENTEGARA LA MERCANCIA");
            toolTip1.SetToolTip(cb_colonia, "AGREGAR LA COLONIA A LA QUE SE ENTEGARA LA MERCANCIA");
            toolTip1.SetToolTip(lbl_colonia, "COLONIA A LA QUE SE ENTEGARA LA MERCANCIA");
            toolTip1.SetToolTip(label27, "CODIGO POSTAL DE LA COLONIA A LA QUE SE LE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(btn_datosEntrega,
                "SELECCIONAR PARA AGREGAR UNA DIRECCION DE ENTREGA DE MERCANCIA, PUEDE SER UNA QUE YA TENGA EL CLIENTE REGISTRADA O AGREGAR UNA NUEVA");
            toolTip1.SetToolTip(btn_Anticipo, "SELECCIONAR PARA AGREGAR UN ANTICIPO O ENGANCHE A LA VENTA REALIZADA");

            toolTip1.SetToolTip(txt_CPEntrega,
                "AGREGAR CODIGO POSTAL DE LA COLONIA A LA QUE SE LE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(lbl_poblacion, "POBLACION DE ENTREGA DE MERCANCIA");
            toolTip1.SetToolTip(txt_PoblacionEntrega, "AGREGAR POBLACION DE ENTREGA DE MERCANCIA");
            toolTip1.SetToolTip(label25, "ESTADO DONDE SE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(txt_EstadoEntrega, "AGREGAR ESTADO DONDE SE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(txt_EntreCallesEntrega, "");
            toolTip1.SetToolTip(label24, "");

            toolTip1.SetToolTip(label4, "TELEFONO PARTICULAR");
            toolTip1.SetToolTip(txt_TelParticularEntrega,
                "AGREGAR TELEFONO PARTICULAR DEL QUE VA A RECIBIR LA MERCANCIA");
            toolTip1.SetToolTip(label5, "TELEFONO MOVIL");
            toolTip1.SetToolTip(txt_MovilEntrega, "AGREGAR TELEFONO MOVIL DEL QUE VA A RECIBIR LA MERCANCIA");
            toolTip1.SetToolTip(label33, "POSIBLES REFERENCIAS DE LA DIRECCION DONDE SE ENTREGARA LA MERCANCIA");
            toolTip1.SetToolTip(txt_ReferenciaEntrega,
                "AGREGAR REFERENCIAS DE LA UBICACION DE LA DIRECCION DE ENTREGA DE MERCANCIA");
            toolTip1.SetToolTip(btn_guardarAnticipos, "SELECCIONAR PARA GENERER UN ANTICIPO");

            if (btn_Afectar.Visible)
            {
                txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                       VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                       " DONDE SE ENCUENTRAN LOS DATOS IMPORTANTES DEL MOVIMIENTO, SI EN LA COMPRA SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE, SI LA VENTA ES CORRECTA SELECCIONAR EL BOTON DE AFECTAR PARA SEGUIR EL PROCESO";
            }
            else
            {
                if (btn_Situaciones.Visible)
                    txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                           VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                           " DONDE SE ENCUENTRAN LOS DATOS IMPORTANTES DEL MOVIMIENTO, SI EN LA COMPRA SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE, SELECCIONAR EL BOTON DE SITUACIONES PARA SEGUIR EL PROCESO";
                else
                    txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                           VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                           " DONDE SE ENCUENTRAN LOS DATOS IMPORTANTES DEL MOVIMIENTO, SI EN LA COMPRA SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE";
            }
        }

        /// <summary>
        ///     LLenado de articulos de venta seleccionada
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 13/07/17
        private void FillArticulos()
        {
            DatosDetalles = new List<ArticulosDetalleVenta>();
            DatosDetalles = ListaDetallesSeleccionados.Where(x => x.ID == VentasSeleccionadas[PaginadoActual].ID)
                .Select(x => new ArticulosDetalleVenta
                {
                    Articulo = x.Articulo,
                    Cantidad = x.Cantidad,
                    Embarque = x.Embarque,
                    EsPaquete = Convert.ToBoolean(x.EsPaquete),
                    EsComponentePaquete = Convert.ToBoolean(x.EsComponentePaquete),
                    RenglonDeArticulo = DatosDetalles.Count,
                    EmbarqueFecha = x.EmbarqueFecha != string.Empty
                        ? Convert.ToDateTime(x.EmbarqueFecha).ToString("dd/MM/yyyy")
                        : string.Empty,
                    Precio = Convert.ToDouble(x.Precio).ToString("C"),
                    Importe = (Convert.ToDouble(x.Precio) * Convert.ToDouble(x.Cantidad)).ToString("C"),
                    Costo = x.Costo,
                    Observaciones = x.Observaciones,
                    Serie = "",
                    CantidadPendiente = x.CantidadPendiente,
                    RenglonID = x.RenglonID,
                    Tipo = x.Tipo,
                    CantidadAAfectar = x.CantidadAAfectar,
                    sPuntosMonedero = string.Format("{0:C}", x.dPuntosMonedero),
                    dPuntosMonedero = x.dPuntosMonedero
                }).ToList();

            btnCartaFactura.Visible = false;

            foreach (ArticulosDetalleVenta Detalle in DatosDetalles)
            {
                List<MSerieArticulos> TempSerie =
                    ControladorSerie.ObtenerSeriesArticulos(VentasSeleccionadas[PaginadoActual].ID, Detalle.Articulo);
                if (TempSerie.Count > 0)
                {
                    if (TempSerie[0].Cuadro.Length > 0 &&
                        new[] { "FACTURA", "FACTURA VIU" }.Contains(VentasSeleccionadas[PaginadoActual].Mov.ToUpper()))
                        btnCartaFactura.Visible = true;

                    if (TempSerie.Count > 1)
                        Detalle.Serie = "...";
                    else if (TempSerie.Count == 1) Detalle.Serie = TempSerie[0].Serie;
                }
            }

            DatosDetallesSinOrdenar = new List<ArticulosDetalleVenta>(DatosDetalles);

            txt_SubTotal.Text = Convert.ToDouble(ListaDetallesSeleccionados[PaginadoActual].Importe).ToString("C");
            txt_Impuestos.Text = Convert.ToDouble(ListaDetallesSeleccionados[PaginadoActual].Impuestos).ToString("C");
            txt_Total.Text = Convert.ToDouble(ListaDetallesSeleccionados[PaginadoActual].ImporteTotal).ToString("C");
            txt_Referencia.Text = ListaDetallesSeleccionados[PaginadoActual].Referencia;
            txt_Canal.Text = ListaDetallesSeleccionados[PaginadoActual].CanalClave;
            txt_Canal1.Text = ListaDetallesSeleccionados[PaginadoActual].CanalNombre;
            txt_Correo.Text = ListaDetallesSeleccionados[PaginadoActual].Email;
            txt_Condiciones.Text = ListaDetallesSeleccionados[PaginadoActual].Condicion;
            txt_Concepto.Text = ListaDetallesSeleccionados[PaginadoActual].Concepto;
            txt_FormaPago.Text = ListaDetallesSeleccionados[PaginadoActual].FormaPagoTipo;
            txt_Embarque.Text = ListaDetallesSeleccionados[PaginadoActual].Embarque;
            txtMonedero.Text = DatosDetalles.Where(x => x.dPuntosMonedero != 0).Sum(x => x.dPuntosMonedero)
                .ToString("C", Thread.CurrentThread.CurrentCulture);
            if (ListaDetallesSeleccionados[PaginadoActual].EmbarqueFecha != string.Empty)
                txt_EmbarqueFecha.Text = Convert.ToDateTime(ListaDetallesSeleccionados[PaginadoActual].EmbarqueFecha)
                    .ToString("dd/MM/yyyy");

            dgv_detalle.DataSource = null;
            dgv_detalle.DataSource = DatosDetalles;
            ConfiguracionGridviewDetalle();
            //dgv_detalle

            lbl_Descripcion.Text = "Descripcion: ";
            lbl_Unidad.Text = "Unidad: ";

            MDetalleVenta detalle =
                ListaDetallesSeleccionados.FirstOrDefault(x => x.ID == VentasSeleccionadas[PaginadoActual].ID);
            lbl_Descripcion.Text = "Descripcion: ";
            if (detalle != null)
            {
                if (detalle.Descripcion.Length > 80)
                    lbl_Descripcion.Text = lbl_Descripcion.Text + detalle.Descripcion.Substring(0, 80) + "...";
                else
                    lbl_Descripcion.Text = lbl_Descripcion.Text + detalle.Descripcion;
                lbl_Unidad.Text = "Unidad: " + detalle.Unidad;
            }
        }

        /// <summary>
        ///     Regresar (o cerrar)
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/10/17
        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            //-PedidosSinDetalle
            foreach (DM0312_MExploradorVenta item in VentasSeleccionadas) std.insertarIdVenta(item.ID, 2);

            Dispose();
            DM0312_ExploradorVentas expl = (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
            expl.Focus();
        }

        /// <summary>
        ///     abre Informacion de articulo seleccionado
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private void Btn_InfoArt_Click(object sender, EventArgs e)
        {
            if (dgv_detalle.SelectedRows.Count > 0)
            {
                DM0312_DetalleInformacionArticulo.ArticuloSeleccionado = dgv_detalle
                    .SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionArticulo].Value.ToString();
                DM0312_DetalleInformacionArticulo infoArt = new DM0312_DetalleInformacionArticulo();
                List<ArticulosDetalleVenta> ImportarDetalles = new List<ArticulosDetalleVenta>(DatosDetallesSinOrdenar);
                if (DatosDetalles[dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Index].EsPaquete)
                {
                    infoArt.EsPaquete = true;
                    List<ArticulosDetalleVenta> DetallesSinPaqueteSeleccionado =
                        new List<ArticulosDetalleVenta>(ImportarDetalles
                            .Skip(DatosDetalles[dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Index]
                                .RenglonDeArticulo + 1).Take(ImportarDetalles.Count));
                    infoArt.DetallesPaquete = new List<ArticulosDetalleVenta>(DetallesSinPaqueteSeleccionado
                        .TakeWhile(detalle => detalle.EsComponentePaquete).ToList());
                }

                TopMost = false;
                infoArt.Show();
            }
        }

        private void Btn_Eventos_Click(object sender, EventArgs e)
        {
            //-Venta Cruzada
            //Para ClaveSeguimiento.cs
            paginaSeleccionada = PaginadoActual;
            VentasSelecEventos = VentasSeleccionadas;

            DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            eventNotaCita = (DM0312_EventosNotasCitas)UsuarioAcceso.AplicarVistas(eventNotaCita);
            DM0312_EventosNotasCitas.recibeCliente = VentasSeleccionadas[PaginadoActual].Cliente;
            DM0312_EventosNotasCitas.recibeMov = VentasSeleccionadas[PaginadoActual].Mov;
            DM0312_EventosNotasCitas.recibeMovId = VentasSeleccionadas[PaginadoActual].MovId;
            DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(VentasSeleccionadas[PaginadoActual].ID);
            DM0312_EventosNotasCitas.recibeUsuario = VentasSeleccionadas[PaginadoActual].Usuario;
            DM0312_EventosNotasCitas.recibeSituacion = VentasSeleccionadas[PaginadoActual].Situacion;
            DM0312_EventosNotasCitas.recibeEstatus = VentasSeleccionadas[PaginadoActual].Estatus;
            DM0312_EventosNotasCitas.recibeSucursal = Convert.ToString(VentasSeleccionadas[PaginadoActual].Sucursal);
            DM0312_EventosNotasCitas.FlagEventosDetalle = true;
            TopMost = false;
            //-Revision de Procesos
            //eventNotaCita.ShowDialog();
            eventNotaCita.Show();
            if (EventoInsertado) ObtenerInformacionTablero();
        }

        private void Detalle_Scroll(object sender, ScrollEventArgs e)
        {
            panelmenu.Location = new Point(2, 1);
        }

        private void Gbx_menuDetall_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void flpanelDatos_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void Gbx_DatosEntrega_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void Gbx_menuDetall_Paint_1(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        /// <summary>
        ///     boton siguiente fila seleccionada de tablero
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 11/07/2017
        private void Btn_detallePosterior_Click(object sender, EventArgs e)
        {
            if (PaginadoActual < VentasSeleccionadas.Count) PaginadoActual = PaginadoActual + 1;
            btn_detallePosterior.Visible = true;
            btn_detalleAnterior.Visible = true;
            if (PaginadoActual == VentasSeleccionadas.Count - 1) btn_detallePosterior.Visible = false;
            if (PaginadoActual == 0) btn_detalleAnterior.Visible = false;
            ObtenerInformacionTablero();
            Dgv_detalle_RowEnter(null, null);
        }

        /// <summary>
        ///     boton anterior fila seleccionada de tablero
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 11/07/2017
        private void Btn_detalleAnterior_Click(object sender, EventArgs e)
        {
            if (PaginadoActual > 0) PaginadoActual = PaginadoActual - 1;
            btn_detallePosterior.Visible = true;
            btn_detalleAnterior.Visible = true;

            if (PaginadoActual == 0) btn_detalleAnterior.Visible = false;
            ObtenerInformacionTablero();
        }

        /// <summary>
        ///     Obtiener la informacion del tablero
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 13/07/17
        protected async void ObtenerInformacionTablero()
        {
            almacen96Afectar = false;
            almacen2000Afectar = false;
            EventoInsertado = false;
            timer1.Enabled = true;

            //Limpia las formas de pago
            Tb_efectivoRecibido.Text = "0";
            lbl_cambio.Text = "Cambio: $ 0.00";
            RemoverAnticipos();

            if (VentasSeleccionadas != null && VentasSeleccionadas.Count > 0)
            {
                if ((VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Unicaja" ||
                     VentasSeleccionadas[PaginadoActual].MovTipo == "VTAS.D") &&
                    !AccesosDeUsuario.CUsuario.BloquearCostos && AccesosDeUsuario.CUsuario.Costos)
                    VerCosto = true;
                cb_ServicioReporte.Visible = false;
                cb_ServicioReporte.Enabled = true;

                //-ReporteDescuento
                int idReporteDescuento = CDetalleVenta.getIdReporteDescuento(VentasSeleccionadas[PaginadoActual].ID);

                if (CReporte.ArticulosConReporte(VentasSeleccionadas[PaginadoActual].ID) ||
                    CReporte.ArticulosConReporteDescuento(VentasSeleccionadas[PaginadoActual].ID) ||
                    idReporteDescuento != 0) cb_ServicioReporte.Visible = true;


                ReporteServicio = CReporte.MovConReporte(VentasSeleccionadas[PaginadoActual].ID);
                ActualizarReporte = false;
                if (ReporteServicio != string.Empty)
                    cb_ServicioReporte.Checked = true;
                else if (idReporteDescuento != 0)
                    cb_ServicioReporte.Checked = true;
                else
                    cb_ServicioReporte.Checked = false;

                ActualizarReporte = true;
                gbx_DatosEntrega.Visible = false;
                gb_anticipos.Visible = false;
                lbl_ID.Text = VentasSeleccionadas[PaginadoActual].ID.ToString();
                txt_Cliente.Text = VentasSeleccionadas[PaginadoActual].Cliente;
                txt_Cliente1.Text = VentasSeleccionadas[PaginadoActual].Nombre;
                cb_Almacen.Text = VentasSeleccionadas[PaginadoActual].Almacen;
                //Cambiar almacen
                if (PuntoDeVenta.ActualizarAlmacen)
                {
                    PuntoDeVenta.ActualizarAlmacen = false;
                    ActualizarAlmacen();
                    cb_Almacen.Text = PuntoDeVenta.Alm;
                    //VentasSeleccionadas[PaginadoActual].SucursalDestino = PuntoDeVenta.
                }

                txt_Agente.Text = VentasSeleccionadas[PaginadoActual].Agente;
                Text = string.Format("Detalle - {0} {1} {2} ", VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId,
                    Convert.ToDateTime(VentasSeleccionadas[PaginadoActual].FechaAlta).ToShortDateString());
                lbl_mov.Text = "";
                lbl_movID.Text = "";
                lbl_fecha.Text = "";
                lbl_fecha.Text = VentasSeleccionadas[PaginadoActual].Situacion;
                txt_TipoVenta.Text = VentasSeleccionadas[PaginadoActual].MaviTipoVenta;
                if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "0")
                    txt_Commerce.Text = VentasSeleccionadas[PaginadoActual].IDEcommerce;

                if (VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                    VentasSeleccionadas[PaginadoActual].Sucursal == 41)
                {
                    lbl_Ecommerce.Visible = true;
                    txt_Commerce.Visible = true;
                    lbl_FormaPago.Visible = true;
                    txt_FormaPago.Visible = true;
                    pan_formaPago.Visible = true;
                }
                else
                {
                    lbl_Ecommerce.Visible = false;
                    txt_Commerce.Visible = false;
                    lbl_FormaPago.Visible = false;
                    txt_FormaPago.Visible = false;
                    pan_formaPago.Visible = false;
                }

                ObtenerPaginado(VentasSeleccionadas.Count);
                if (ListaDetallesSeleccionados.Count > 0)
                {
                    FillArticulos();
                }
                else
                {
                    DM0312_C_ExploradorVenta explorador = new DM0312_C_ExploradorVenta();
                    DM0312_MVentaDetalle VentaDetalle = explorador.ConsultaDetalle("", "", lbl_ID.Text);
                    txt_Canal.Text = VentaDetalle.CanalClave;
                    txt_Canal1.Text = VentaDetalle.CanalNombre;
                    txt_Embarque.Text = VentaDetalle.Embarque;
                    if (VentaDetalle.EmbarqueFecha != string.Empty)
                        txt_EmbarqueFecha.Text = Convert.ToDateTime(VentaDetalle.EmbarqueFecha).ToString("dd/MM/yyyy");
                }

                lbl_estatus.Text = VentasSeleccionadas[PaginadoActual].Estatus;


                if (new[] { "CREDILANA", "PRESTAMO PERSONAL" }.Contains(VentasSeleccionadas[PaginadoActual].Mov
                        .ToUpper()))
                    btn_Cancelar.Visible =
                        CDetalleVenta.validarCancelacionMovimiento(VentasSeleccionadas[PaginadoActual].ID);

                string MovTipo = VentasSeleccionadas[PaginadoActual].MovTipo;
                string Estatus = VentasSeleccionadas[PaginadoActual].Estatus;
                CDetalleVenta.PaginadoActual = PaginadoActual;
                if (!CDetalleVenta.ChecarSiSePuedeCancelar(MovTipo, Estatus,
                        VentasSeleccionadas)) // Cancelación permisos de usuario
                    btn_Cancelar.Visible = false;

                string[] Parametros =
                {
                    VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId,
                    MovTipo,
                    VentasSeleccionadas[PaginadoActual].ID.ToString()
                };

                CategoriaEnviarA = string.Empty;

                CDetalleVenta.PaginadoActual = PaginadoActual;
                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    EnableControls(false, this);
                    panelmenu.Location = new Point(2, 1);
                }

                Detalles = await Task.Run(() => CDetalleVenta.ObtenerDetallesVenta(Parametros, ref CategoriaEnviarA));
                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    EnableControls(true, this);
                }

                double Enganche_Anticipo = 0;
                if (Detalles[(int)Enums.DetallesVenta.Enganche] != null &&
                    Detalles[(int)Enums.DetallesVenta.Enganche] != string.Empty)
                    Enganche_Anticipo = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.Enganche]);
                txt_Enganche.Text = Enganche_Anticipo.ToString("C");

                txt_Monedero.Text = string.Empty;
                if (Detalles[(int)Enums.DetallesVenta.RedMonedero] != string.Empty)
                    txt_Monedero.Text = double
                        .Parse(Detalles[(int)Enums.DetallesVenta.RedMonedero], CultureInfo.InvariantCulture)
                        .ToString("C");
                double monedero = txt_Monedero.Text != string.Empty
                    ? Convert.ToDouble(txt_Monedero.Text.Replace("$", ""))
                    : 0;
                if (txt_Total.Text != string.Empty)
                {
                    double total = Convert.ToDouble(txt_Total.Text.Replace("$", ""));
                    saldoRestante = total - Enganche_Anticipo - monedero;
                }

                if (Detalles[(int)Enums.DetallesVenta.AfectaComisionMavi] != string.Empty)
                    chk_Mayoreo.Checked = bool.Parse(Detalles[(int)Enums.DetallesVenta.AfectaComisionMavi]);
                else
                    chk_Mayoreo.Checked = false;


                //GESSY Codigo Recomendado
                if (!string.IsNullOrEmpty(txt_Cliente.Text)
                    && CanalDeCodigoRecomendadorEsValido(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA))
                   )
                {
                    txt_CodigoRecomendado.Visible = true;
                    txt_CodigoRecomendado.ReadOnly = true;
                    lbl_CodigoRecomendado.Visible = true;
                    txt_CodigoRecomendado.Text = CDetalleVenta.obtenerCodigoRecomendado(txt_Cliente.Text,
                        int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA));

                    if (VentasSeleccionadas[PaginadoActual].Estatus == "CANCELADO")
                        if (string.IsNullOrEmpty(txt_CodigoRecomendado.Text))
                        {
                            txt_CodigoRecomendado.Visible = false;
                            lbl_CodigoRecomendado.Visible = false;
                        }
                }

                //-MejorasMayoreo
                if (VentasSeleccionadas[PaginadoActual].Estatus.Equals("SINAFECTAR") &&
                    (ClaseEstatica.Usuario.Grupo.Equals("VENTAS MAYOREO") ||
                     ClaseEstatica.Usuario.Grupo.Equals("CREDITO MAYOREO")))
                {
                    chk_Mayoreo.Enabled = true;
                    chk_Mayoreo.CheckedChanged += chk_Mayoreo_CheckedChanged;
                }
                else
                {
                    chk_Mayoreo.Enabled = false;
                }

                if (Detalles[(int)Enums.DetallesVenta.FacDesgloseIva] != string.Empty)
                    chk_Iva.Checked = bool.Parse(Detalles[(int)Enums.DetallesVenta.FacDesgloseIva]);

                txt_AgenteServicio.Text = Detalles[(int)Enums.DetallesVenta.AgenteServicio];

                if (Detalles[(int)Enums.DetallesVenta.Causa] != string.Empty)
                    chk_Custodia.Checked = true;
                else
                    chk_Custodia.Checked = false;
                if (Detalles[(int)Enums.DetallesVenta.ServicioTipo] == "SI")
                    chk_Comentario.Checked = true;
                else
                    chk_Comentario.Checked = false;
                txt_Observaciones.Text = Detalles[(int)Enums.DetallesVenta.Observaciones];
                txt_Comentario.Text = Detalles[(int)Enums.DetallesVenta.Comentarios];
                txt_FormaEnvio.Text = Detalles[(int)Enums.DetallesVenta.FormaEnvio];
                txt_CtaPago.Text = Detalles[(int)Enums.DetallesVenta.NoCtapago];

                string Canal = txt_Canal.Text;

                CDetalleVenta.PaginadoActual = PaginadoActual;
                string[] IDyCategoria = CDetalleVenta.ObtenerCategoriaCanal(Canal);
                int IDDeCanal = 0;
                int IDDeCategoria = 1;
                txt_Canal.Text = IDyCategoria[IDDeCanal];

                if (txt_Canal.Text == "") txt_Canal.Text = Canal;

                lbl_Enganche.Text = "Enganches";
                btn_Anticipo.Text = "Enganche";
                if (IDyCategoria[IDDeCategoria] == "CONTADO" || IDyCategoria[IDDeCategoria] == "CREDITO EXTERNO")
                {
                    lbl_Enganche.Text = "Anticipos contado";
                    btn_Anticipo.Text = "Anticipos";
                }
                else if (IDyCategoria[IDDeCategoria] == "MAYOREO")
                {
                    lbl_Enganche.Text = "Anticipos mayoreo";
                    btn_Anticipo.Text = "Anticipos";
                }

                btn_Afectar.Visible = true;

                CDetalleVenta.PaginadoActual = PaginadoActual;
                if (!CDetalleVenta.PuedeAfectar(VentasSeleccionadas[PaginadoActual].Usuario,
                        VentasSeleccionadas[PaginadoActual].Estatus, VentasSeleccionadas[PaginadoActual].Situacion,
                        VentasSeleccionadas[PaginadoActual].Mov)) btn_Afectar.Visible = false;
                AccesosDeUsuario au = new AccesosDeUsuario();
                string MovAcceso = VentasSeleccionadas[PaginadoActual].Mov;

                if (CDetalleVenta.MovEsValera(VentasSeleccionadas[PaginadoActual].ID))
                {
                    //Si el mov es valera se muestran diferentes controles
                    MovAcceso = "Valera";
                    MovEsValera = true;
                }

                //Parametros utilizados en Obtener situaciones
                Dm0312DetalleSituaciones.IdVenta = VentasSeleccionadas[PaginadoActual].ID;
                Dm0312DetalleSituaciones.Estatus = VentasSeleccionadas[PaginadoActual].Estatus;
                Dm0312DetalleSituaciones.Mov = VentasSeleccionadas[PaginadoActual].Mov;
                Dm0312DetalleSituaciones.MovId = VentasSeleccionadas[PaginadoActual].MovId;
                ListaSituaciones = CSituaciones.ObtenerSituaciones();
                btn_Situaciones.Visible = false;
                if (ListaSituaciones.Count > 1)
                {
                    btn_Situaciones.Visible = true;
                    if (MovEsValera)
                        if (CDetalleVenta.SituacionesValera(VentasSeleccionadas[PaginadoActual].Situacion,
                                VentasSeleccionadas[PaginadoActual].Mov))
                            btn_Situaciones.Visible = false;
                    if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR" &&
                        VentasSeleccionadas[PaginadoActual].Situacion == "En revision Cobranza Mayoreo")
                        btn_Situaciones.Visible = false;
                }

                Dictionary<string, bool> accesos = au.ObtenerAccesosVentas(MovAcceso);
                au.AplicarVistasDetalle(Controls);

                //Validacion para ventas en linea (tiene que sobrescribir cualquier configuracion segun lol)
                if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                    VentasSeleccionadas[PaginadoActual].Sucursal == 90)
                {
                    lbl_Ecommerce.Visible = true;
                    txt_Commerce.Visible = true;
                    txt_FormaPago.Visible = true;
                    lbl_FormaPago.Visible = true;
                }
                else
                {
                    lbl_FormaPago.Visible = false;
                    lbl_Ecommerce.Visible = false;
                    txt_Commerce.Visible = false;
                    txt_FormaPago.Visible = false;
                }

                //Embarcar movimiento solo si es almacen 96
                if (
                    (
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU" ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo"
                    )
                    &&
                    VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO"
                    &&
                    (VentasSeleccionadas[PaginadoActual].Almacen == "V00096" ||
                     VentasSeleccionadas[PaginadoActual].Almacen == "V02000")
                )
                    if (!CDetalleVenta.MovEmbarcado(VentasSeleccionadas[PaginadoActual].MovId))
                    {
                        string[] parametros =
                        {
                            VentasSeleccionadas[PaginadoActual].ID.ToString(), VentasSeleccionadas[PaginadoActual].Mov,
                            VentasSeleccionadas[PaginadoActual].MovId, "0"
                        };
                        if (CDetalleVenta.MovimientoGenerado)
                            await Task.Delay(5000).ContinueWith(x => CDetalleVenta.Embarcar(parametros));
                        else
                            CDetalleVenta.Embarcar(parametros);
                    }

                gpbxHeightC = gpbxheightClosed;
                gpbxHeightO = gpbxheightOpen;
                for (int i = 0; i < dgv_detalle.Rows.Count; i++)
                {
                    gpbxHeightC = gpbxHeightC + 25;
                    gpbxHeightO = gpbxHeightO + 25;
                }

                flpanel.Height = gpbxHeightC;


                Parametros = new[]
                {
                    VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId,
                    "VTAS",
                    VentasSeleccionadas[PaginadoActual].ID.ToString(),
                    VentasSeleccionadas[PaginadoActual].Cliente,
                    VentasSeleccionadas[PaginadoActual].Estatus,
                    VentasSeleccionadas[PaginadoActual].EnviarA,
                    VentasSeleccionadas[PaginadoActual].FechaAlta.ToString(),
                    VentasSeleccionadas[PaginadoActual].Sucursal.ToString(),
                    VentasSeleccionadas[PaginadoActual].Condicion,
                    CategoriaEnviarA
                };

                //muestra/esconde pequeño panel de vales (esto se valida al dar click en afectar)
                if (CDetalleVenta.ShowNipVales(Parametros, 0)) //-ValeDigital
                {
                    pan_Vales.Visible = true;
                    dgv_detalle.Margin = new Padding(10, 3, 10, 10);

                    if (ListaDetallesSeleccionados[PaginadoActual].Referencia == "AEA00035 SELP MOBILE ONLINE")
                    {
                        pan_Vales.Visible = false;
                        dgv_detalle.Margin = new Padding(10, 3, 200, 10);
                    }
                }
                else
                {
                    pan_Vales.Visible = false;
                    dgv_detalle.Margin = new Padding(10, 3, 200, 10);
                }

                if (txt_Canal.Text == "34")
                {
                    if (VentasSeleccionadas[PaginadoActual].Nomina != null &&
                        VentasSeleccionadas[PaginadoActual].Nomina != string.Empty)
                    {
                        Label lbl_nomina = new Label
                        {
                            Name = "lbl_Nomina",
                            Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                            Text = "Nomina: " + VentasSeleccionadas[PaginadoActual].Nomina,
                            Width = 140,
                            Location = new Point(260, 41)
                        };
                        Controls.Add(lbl_nomina);
                    }
                    else if (Controls.ContainsKey("lbl_Nomina"))
                    {
                        Controls.RemoveByKey("lbl_Nomina");
                    }
                }
                else if (Controls.ContainsKey("lbl_Nomina"))
                {
                    Controls.RemoveByKey("lbl_Nomina");
                }

                //double ImporteAPagar = saldoRestante + monedero;
                lbl_importeTotal.Text = string.Format("Puede generar anticipos por la cantidad de: {0}",
                    saldoRestante.ToString("C"));


                if (lbl_Enganche.Visible == false) panel2.Visible = false;
                if (lbl_Referencia.Visible == false) pan_refConcepto.Visible = false;
                if (lbl_FormaPago.Visible == false) pan_formaPago.Visible = false;
                if (lbl_Correo.Visible == false) pan_correo.Visible = false;
                if (txt_FormaCo.Visible) pan_formaPago.Visible = true;
                if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                    VentasSeleccionadas[PaginadoActual].Sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41 ||
                    ClaseEstatica.Usuario.sucursal == 90) pan_formaPago.Visible = true;
            }

            //Configuraciones de usuario que tienen prioridad sobre los botones
            ConfigurarUsuario();

            ConfiguracionesPorMovEstatus();

            if (btn_Afectar.Visible)
            {
                txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                       VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                       " DONDE SE ENCUENTRA LA INFORMACION DEL MOVIMIENTO, SI SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE, SI ES CORRECTO SELECCIONAR EL BOTON DE AFECTAR PARA SEGUIR EL PROCESO";
            }
            else
            {
                if (btn_Situaciones.Visible)
                    txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                           VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                           " DONDE SE ENCUENTRA LA INFORMACION DEL MOVIMIENTO, SI SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE, SELECCIONAR EL BOTON DE SITUACIONES PARA SEGUIR EL PROCESO";
                else
                    txt_Comentarios.Text = "DETALLE DE " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                           VentasSeleccionadas[PaginadoActual].MovId.ToUpper() +
                                           " DONDE SE ENCUENTRAN LOS DATOS IMPORTANTES DEL MOVIMIENTO, SI EN LA COMPRA SE ENCUENTRAN ARTICULOS DE SERIE DAR DOBLE CLICK A LA COLUMNA DE SERIE PARA AGREGAR LA SERIE CORRESPONDIENTE";
            }

            if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
            {
                label1.Visible = true;
                txt_FormaCo.Visible = true;
                string formaC = "";
                formaC = CDetalleVenta.FormaCobroL(VentasSeleccionadas[PaginadoActual].ID);

                if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                {
                    modificarCobro = 1;
                    LlenaFormaDeCobroLinea(formaC);
                }
                else
                {
                    modificarCobro = 1;
                    txt_FormaCo.Text = formaC;
                    txt_FormaCo.Enabled = false;
                }
            }

            ///aquiiiiiii
            ///
            if (txt_Referencia.Text != "")
            {
                pan_refConcepto.Visible = true;
                txt_Referencia.Visible = true;
                lbl_Referencia.Visible = true;
            }

            if (controladorV.ValidarDie() == "NO") chx_Die.Visible = false;
            //-Die ↓ 2019-05-25
            if (txt_Canal.Text == "76") chx_Die.Visible = false;
        }


        /// <summary>
        ///     Metodo encargado de validar si el canal de venta puede tener codigo recomendador
        /// </summary>
        /// <param name="Canal">canal a validar</param>
        /// <returns>retorna true si el canal de venta puede tener codigo recomendador</returns>
        private bool CanalDeCodigoRecomendadorEsValido(int Canal)
        {
            switch (Canal)
            {
                case 3:
                    return true;
                case 7:
                    return true;
                case 76:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        ///     Handler de impresion
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/09/17
        private void Btn_Imprimir_Click(object sender, EventArgs e)
        {
            CDetalleVenta.TopArticulosSobrepasado = false;
            if (dgv_detalle.SelectedRows.Count > 0)
            {
                string msgPrecaucion = string.Empty;
                //-BotonImprimir
                if (VentasSeleccionadas[PaginadoActual].Almacen == "V00096" && ClaseEstatica.Usuario.sucursal != 96 &&
                    ClaseEstatica.Usuario.sucursal != 98)
                {
                    MessageBox.Show("Solo Usuarios de la sucursal 96 y 98 pueden imprimir este movimiento",
                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (dgv_detalle.Rows.Count > 14) CDetalleVenta.TopArticulosSobrepasado = true;

                string[] Parametros =
                {
                    VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId,
                    "VTAS",
                    VentasSeleccionadas[PaginadoActual].ID.ToString(),
                    VentasSeleccionadas[PaginadoActual].Cliente,
                    VentasSeleccionadas[PaginadoActual].Estatus,
                    VentasSeleccionadas[PaginadoActual].EnviarA,
                    VentasSeleccionadas[PaginadoActual].FechaAlta.ToString(),
                    VentasSeleccionadas[PaginadoActual].Sucursal.ToString(),
                    VentasSeleccionadas[PaginadoActual].Condicion,
                    CategoriaEnviarA,
                    dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionArticulo].Value
                        .ToString()
                };

                // seleccioamos todos los productos de la familia de moticicletas
                List<string> articulos = (dgv_detalle.DataSource as List<ArticulosDetalleVenta>)
                    .Select(x => x.Articulo)
                    .ToList();
                if (CDetalleVenta.ValidacionesImprimir(Parametros, VentasSeleccionadas))
                {
                    float dImpuesto = CDetalleVenta.obtenerImpuesto(VentasSeleccionadas[PaginadoActual].ID) / 100 + 1;
                    ReporteVenta.Referencia = txt_Referencia.Text;
                    ReporteVenta.Observaciones = txt_Observaciones.Text;
                    ReporteVenta.ListaImpresionVenta = ListaDetallesSeleccionados
                        .Where(x => x.ID == VentasSeleccionadas[PaginadoActual].ID)
                        .Select(x => new MImpresionVenta
                        {
                            Articulo = x.Articulo,
                            Opcion = "",
                            Descripcion = x.Descripcion,
                            Almacen = cb_Almacen.Text,
                            Cantidad = x.Cantidad,
                            Precio = Convert.ToDouble(x.Precio).ToString("C"),
                            Desc = "",
                            //Importe = ((Convert.ToDouble(x.Precio) - (Convert.ToDouble(x.Precio) * .016)) * Convert.ToDouble(x.Cantidad)).ToString("C"),
                            Importe = "$" + (Convert.ToDouble(x.Cantidad) * Convert.ToDouble(x.Precio) / dImpuesto)
                                .ToString("#.0000")
                        }).ToList();
                    ReporteVenta.MovAImprimir = VentasSeleccionadas[PaginadoActual];
                    ReporteVenta.Unidad = ListaDetallesSeleccionados
                        .Where(x => x.ID == VentasSeleccionadas[PaginadoActual].ID).ToList()[0].Unidad;

                    CDetalleVenta.Imprimir(Parametros, VentasSeleccionadas, ref msgPrecaucion);
                }
            }
            else
            {
                MessageBox.Show("No hay articulos para imprimir.", "Salida diversa", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     show current page from articulos
        /// </summary>
        /// <param name="TotalFilas">int</param>
        /// Developer: Dan Palacios
        /// Date: 12/07/2017
        protected void ObtenerPaginado(int TotalFilas)
        {
            lbl_paginaActual.Text = string.Empty;
            if (TotalFilas > 1) lbl_paginaActual.Text = PaginadoActual + 1 + " de " + TotalFilas;
        }

        /// <summary>
        ///     fila seleccionada de articulo para seleccionar la descripcion
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/07/2017
        private void Dgv_detalle_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv_detalle.SelectedRows.Count > 0)
            {
                MDetalleVenta detalle = ListaDetallesSeleccionados.FirstOrDefault(x =>
                    x.Articulo == dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1]
                        .Cells[EnteroPosicionArticulo].Value.ToString());
                if (detalle != null)
                {
                    lbl_Descripcion.Text = "Descripcion: ";
                    lbl_Descripcion.Text = detalle.Descripcion.Length > 80
                        ? lbl_Descripcion.Text + detalle.Descripcion.Substring(0, 80) + "..."
                        : lbl_Descripcion.Text + detalle.Descripcion;
                    lbl_Unidad.Text = "Unidad: " + detalle.Unidad;
                }
            }
        }

        /// <summary>
        ///     Elimina el movimiento de las tablas correspondientes
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 21/07/2017
        private async void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            GC.Collect();
            //-ReservaOnline
            if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "")
                if (CDetalleVenta.validarRecogerSucursal(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                    if ((VentasSeleccionadas[PaginadoActual].Situacion == "Liberado" &&
                         VentasSeleccionadas[PaginadoActual].Mov == "Pedido") ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                        if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                            VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                            VentasSeleccionadas[PaginadoActual].Suc == 41 ||
                            VentasSeleccionadas[PaginadoActual].Suc == 90)
                        {
                            frmSolicitudContraseña frmSolicitudContraseña = new frmSolicitudContraseña();
                            frmSolicitudContraseña.ShowDialog();
                            if (!frmSolicitudContraseña.bEsCorrecto)
                            {
                                MessageBox.Show(
                                    "No se puede afectar el moviemiento debido a que no se cumplio la validacion",
                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }

                            CDetalleVenta.cancelarReservacion(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                        }

            if (VentasSeleccionadas[PaginadoActual].Estatus != "SINAFECTAR")
            {
                MessageBox.Show("Solo se puede eliminar movimientos que no han sido afectados", "Eliminar",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //-Datalogic
                if (ClaseEstatica.iRecarga == 1)
                    if (CDetalleVenta.valdiarRecarga(VentasSeleccionadas[PaginadoActual].ID) == 1)
                    {
                        MessageBox.Show("No Se Puede Cancelar El Moviemiento Debido A Que Ya Se Realizo La Recarga",
                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                DialogResult result = MessageBox.Show("Esta seguro que desea eliminar este movimiento", "Eliminar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    if (!frmLoading.Visible)
                    {
                        frmLoading.Show(this);
                        EnableControls(false, this);
                        panelmenu.Location = new Point(2, 1);
                    }

                    Afectando = true;
                    // Registro Eliminacion Pedidos
                    if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                    {
                        string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
                        string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
                        controladorV.GuardarRegistroEliminado(myIP, VentasSeleccionadas[PaginadoActual].ID);
                    }

                    /////////////////////////
                    string msgPrecaucion = await Task.Run(() => CDetalleVenta.EliminarMovimiento(VentasSeleccionadas));
                    if (frmLoading.Visible)
                    {
                        frmLoading.Hide();
                        EnableControls(true, this);
                    }

                    if (msgPrecaucion != string.Empty)
                    {
                        MessageBox.Show(msgPrecaucion, "Eliminar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (msgPrecaucion == "Registro eliminado satisfactoriamente")
                        {
                            Visible = false;
                            DM0312_ExploradorVentas ExploradorVentas =
                                (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                            ExploradorVentas.TableroMovimientos();

                            if (VentasSeleccionadas.Count > 1)
                            {
                                VentasSeleccionadas.RemoveAt(PaginadoActual);
                                if (PaginadoActual > 0)
                                {
                                    PaginadoActual = PaginadoActual - 1;
                                    CDetalleVenta.PaginadoActual = PaginadoActual;
                                }

                                CDetalleVenta.MovimientoGenerado = true;
                            }
                            else
                            {
                                Dispose();
                            }

                            ExploradorVentas.CargarNuevasAfectaciones(this, VentasSeleccionadas);
                            ////////borrar registro de tarjetamonederoMavi
                            CDetalleVenta.DeleteTarjetaMonMavi(VentasSeleccionadas[PaginadoActual].ID);
                        }
                    }

                    Afectando = false;
                }
            }
        }

        public bool CandadoEdad65(string cliente)
        {
            int anios = 0;
            int edad = 0;
            DM0312_CVentanaEntrada controladorVe = new DM0312_CVentanaEntrada();
            DateTime nacimiento = controladorVe.FechaNacimientoCliente(cliente); //Fecha de nacimiento
            if (nacimiento > DateTime.Now)
                anios = 0;
            else
                edad = DateTime.Today.AddTicks(-nacimiento.Ticks).Year - 1;

            anios = controladorV.CandadoEdadAños("SEGURO DE VIDA");
            if (edad >= anios) return false;

            return true;
        }

        /// <summary>
        ///     Afecta el movimiento actual
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 20/09/17
        private async void Btn_Afectar_Click(object sender, EventArgs e)
        {
            GC.Collect();
            //-CerradoIntelisis
            loginC.checkSession();

            //-PedidoSinDetalle
            if (std.obtenerEstatuMovimiento(VentasSeleccionadas[PaginadoActual].ID) != lbl_estatus.Text)
                MessageBox.Show("El estatus del moviemiento no corresponde al original.", "Punto De Venta",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Pedido" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Credilana")
            {
                //-ValidarPedidos
                if (CDetalleVenta.pedidoDoble(VentasSeleccionadas[PaginadoActual].ID))
                {
                    MessageBox.Show(
                        "El cliente cuenta con más de un moviminto, Favor de revisar y cancelar los duplicados",
                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (CDetalleVenta.validarSiguientePedido(VentasSeleccionadas[PaginadoActual].Mov,
                        VentasSeleccionadas[PaginadoActual].MovId))
                {
                    MessageBox.Show("El cliente ya cuenta con una credilana o factura sin afectar favor de concluirla",
                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            //-ReservaOnline //-PrimeraFaseDeAutomatizacion
            if (VentasSeleccionadas[PaginadoActual].Almacen != "V00096")
                if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "")
                    if (CDetalleVenta.validarRecogerSucursal(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                        if ((VentasSeleccionadas[PaginadoActual].Situacion == "Liberado" &&
                             VentasSeleccionadas[PaginadoActual].Mov == "Pedido") ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                            if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                                VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 41 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 90)
                            {
                                frmSolicitudContraseña frmSolicitudContraseña = new frmSolicitudContraseña();
                                frmSolicitudContraseña.ShowDialog();
                                if (!frmSolicitudContraseña.bEsCorrecto)
                                {
                                    MessageBox.Show(
                                        "No se puede afectar el movimiento debido a que no se cumplio la validacion",
                                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }

                                CDetalleVenta.cancelarReservacion(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                            }

            if (CDetalleVenta.SMStablaConversionSegurosValor() == "1")
                if (CandadoEdad65(VentasSeleccionadas[PaginadoActual].Cliente))
                    if (CDetalleVenta.SucursalesSinSeguro(VentasSeleccionadas[PaginadoActual].Suc) != "SI")
                        if (txt_Canal.Text != "76" && txt_Canal.Text != "34" && txt_Canal.Text != "2" &&
                            txt_Canal.Text != "6")
                            if (CDetalleVenta.AutorizaCancelacion(VentasSeleccionadas[PaginadoActual].MovId,
                                    VentasSeleccionadas[PaginadoActual].Cliente) == "NO")
                                if (CDetalleVenta.AutorizaCancelacionSolicitud(
                                        VentasSeleccionadas[PaginadoActual].MovId,
                                        VentasSeleccionadas[PaginadoActual].Cliente) == "NO")
                                    if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                        VentasSeleccionadas[PaginadoActual].Situacion == "Liberado")
                                    {
                                        bool VentaCredilana =
                                            CDetalleVenta.ConsultarVentaCredilana(VentasSeleccionadas[PaginadoActual].ID
                                                .ToString());
                                        if (VentaCredilana)
                                        {
                                            //-CambioCandadoSegurosdeVida 2019-03-30
                                            bool segundaventa = false;
                                            bool segurovida = false;
                                            bool ventacampo = false;
                                            string artCredilana = "";
                                            double capitalCredilana = 0;
                                            double saldoPendienteCliente = 0, limiteSaldoSeguro = 0;

                                            string cliente = VentasSeleccionadas[PaginadoActual].Cliente;
                                            int uen = int.Parse(Detalles[(int)Enums.DetallesVenta.UEN]);

                                            string movIdSolicitud =
                                                CDetalleVenta.getMovIDSolicitud(VentasSeleccionadas[PaginadoActual].ID
                                                    .ToString());

                                            segundaventa = CDetalleVenta.SegundaVentaSHM(cliente);
                                            segurovida = CDetalleVenta.SeguroVidaSHM(cliente);
                                            ventacampo = CDetalleVenta.VentaCampo(cliente, movIdSolicitud);
                                            double SolicitudTotal = Convert.ToDouble(txt_Total.Text.Replace("$", ""));
                                            artCredilana =
                                                CDetalleVenta.ArticuloCredilana(VentasSeleccionadas[PaginadoActual].ID);
                                            capitalCredilana = CDetalleVenta.CapitalCredilana(artCredilana);
                                            //importeCredilana = (Convert.ToDouble(CDetalleVenta.SMStablaConversionSeguros()));
                                            saldoPendienteCliente = CDetalleVenta.getCantidadSaldoPendiente(cliente);
                                            limiteSaldoSeguro = CDetalleVenta.getLimiteSaldoSeguroDeVida(uen);

                                            //if (segundaventa == true && segurovida == false && ventacampo == true && capitalCredilana >= importeCredilana)
                                            if (VentasSeleccionadas[PaginadoActual].Suc == 504 ||
                                                VentasSeleccionadas[PaginadoActual].Suc == 505 ||
                                                VentasSeleccionadas[PaginadoActual].Sucursal == 504 ||
                                                VentasSeleccionadas[PaginadoActual].Sucursal == 505)
                                                ventacampo = true;

                                            if (segundaventa && segurovida == false && ventacampo &&
                                                saldoPendienteCliente >= limiteSaldoSeguro)
                                            {
                                                MessageBox.Show(
                                                    "EL cliente " + VentasSeleccionadas[PaginadoActual].Cliente +
                                                    " no cuenta con seguro de vida", "Usuario", MessageBoxButtons.OK,
                                                    MessageBoxIcon.Warning);
                                                return;
                                            }
                                        }
                                    }


            string estatusAct = CDetalleVenta.EstatusActual(VentasSeleccionadas[PaginadoActual].ID);

            if (estatusAct != VentasSeleccionadas[PaginadoActual].Estatus)
            {
                MessageBox.Show(
                    "El movimiento " + VentasSeleccionadas[PaginadoActual].Mov + " " +
                    VentasSeleccionadas[PaginadoActual].MovId +
                    " ya ah sido afectado o esta en seguimiento por otro usuario, favor de regresar a su explorador y refrescarlo (F5) para obtener los movimientos a los que le puede dar seguimiento",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //Analisis de credito canal 7 o 3, ejecutar plugin.
            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                (VentasSeleccionadas[PaginadoActual].EnviarA == "7" ||
                 VentasSeleccionadas[PaginadoActual].EnviarA == "3") &&
                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                if (VentasSeleccionadas[PaginadoActual].Sucursal == 504 ||
                    VentasSeleccionadas[PaginadoActual].Sucursal == 505 ||
                    VentasSeleccionadas[PaginadoActual].Suc == 505 || VentasSeleccionadas[PaginadoActual].Suc == 504)
                    CDetalleVenta.LiberarLinea(VentasSeleccionadas[PaginadoActual].IDEcommerce);

            //-430
            if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76 ||
                int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 80)
                if (CDetalleVenta.validarDimaNuevo(VentasSeleccionadas[PaginadoActual].ID))
                    if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" &&
                        VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                    {
                        if (CDetalleVenta.validarFecha(VentasSeleccionadas[PaginadoActual].MovId,
                                VentasSeleccionadas[PaginadoActual].Mov))
                        {
                            foreach (DM0312_MExploradorVenta item in VentasSeleccionadas)
                            {
                                List<string> lsDatos = CDetalleVenta.ObtenerComentarios(item.MovId, item.Mov);
                                CDetalleVenta.guardarHistorialDima(VentasSeleccionadas[PaginadoActual], lsDatos, "",
                                    true);
                                break;
                            }
                        }
                        else
                        {
                            if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito")
                            {
                            }

                            List<string> lsDatos = CDetalleVenta.ObtenerComentarios(
                                VentasSeleccionadas[PaginadoActual].MovId, VentasSeleccionadas[PaginadoActual].Mov);
                            CDetalleVenta.actualiarHistorialDima(VentasSeleccionadas[PaginadoActual], lsDatos[0],
                                VentasSeleccionadas[PaginadoActual].Estatus);
                        }
                    }

            Thread thr = new Thread(proceso);
            //-864 GESSY  Val Suc
            if ((controladorV.ValidarSucursalDie() &&
                 controladorV.validarCanalVentaDie(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA))) ||
                chkTransferencia.Checked)
            {
                string esDie = CDetalleVenta.validaEsDie(VentasSeleccionadas[PaginadoActual].ID);
                if (esDie != "NO")
                {
                    bool bSucursal = false;
                    bool bDie = false;
                    bool bStp = false;
                    //-864 GESSY  Historia 1 El sistema mostrará un mensaje solicitando el medio de pago 
                    desicion();
                    string msg = "";

                    switch (str_CustomAlertResult)
                    {
                        case "SUCURSAL":
                            msg = '\r' + " " + '\n' + "   VERIFICA QUE TENGAS EL EFECTIVO EN CAJA.";
                            confirmar(msg);
                            if (str_CustomAlertResult == "ACEPTAR")
                            {
                                chx_Die.Enabled = false;
                                chx_Die.Checked = false;

                                chkTransferencia.Enabled = false;
                                chkTransferencia.Checked = false;
                                controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                                controladorV.acutalizarTransferenciaStp(chkTransferencia.Checked,
                                    VentasSeleccionadas[PaginadoActual].ID);
                                bSucursal = true;
                            }
                            else
                            {
                                return;
                            }

                            break;
                        case "BANCO":

                            if (txt_Cliente1.Text.Length > 39)
                            {
                                MessageBox.Show("No procede dispersión, el nombre debe ser menor a 40 caracteres",
                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }

                            msg = '\r' + " " + '\n' +
                                  "PARA EL COBRO EN EL MISMO DIA ES ANTES DE LAS 11:00 HRS. DE LUNES A VIERNES A EXCEPCION DE DIAS FESTIVOS.";
                            confirmar(msg);
                            if (str_CustomAlertResult == "ACEPTAR")
                            {
                                chx_Die.Enabled = false;
                                chx_Die.Checked = true;

                                chkTransferencia.Enabled = false;
                                chkTransferencia.Checked = false;

                                bDie = true;
                            }
                            else
                            {
                                return;
                            }

                            break;
                        case "TRANSFERENCIA":
                            if ((VentasSeleccionadas[PaginadoActual].Mov == "Pedido" ||
                                 VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito") &&
                                VentasSeleccionadas[PaginadoActual].Estatus.ToUpper() == "PENDIENTE" &&
                                VentasSeleccionadas[PaginadoActual].Situacion == "Liberado")
                            {
                                //Validar que la tarjeta esta valdiadada
                                string sCliente = string.Empty;
                                if (new[] { 76, 80 }.Contains(int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA)))
                                    sCliente = CDetalleVenta.BeneficiarioFinal(VentasSeleccionadas[PaginadoActual].ID);
                                else
                                    sCliente = VentasSeleccionadas[PaginadoActual].Cliente;

                                if (!CDetalleVenta.validarCuentaClabe(sCliente))
                                {
                                    MessageBox.Show(
                                        "La cuenta clabe no a sido validada, favor de validarla o utilizar otro método para la entrega del efectivo",
                                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                            }

                            msg = '\r' + " " + '\n' + "      INFORMA AL CLIENTE QUE PUEDE DEMORAR 30 MIN." + '\r' +
                                  "                 EN VERSE REFLEJADO EN SU CUENTA.";
                            confirmar(msg);
                            if (str_CustomAlertResult == "ACEPTAR")
                            {
                                chx_Die.Enabled = false;
                                chx_Die.Checked = false;

                                chkTransferencia.Enabled = false;
                                chkTransferencia.Checked = true;

                                bStp = true;
                            }
                            else
                            {
                                return;
                            }

                            break;
                    }

                    thr.Start();

                    //DialogResult dialogResult = new DialogResult();
                    //-864 GESSY  CAMBIAR LA VALIDACION
                    if (bDie || bStp)
                    {
                        if (bDie)
                        {
                            controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                            LayoutDIE();
                        }

                        if (!bDie) controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                        if (bStp)
                            controladorV.acutalizarTransferenciaStp(chkTransferencia.Checked,
                                VentasSeleccionadas[PaginadoActual].ID);

                        CDetalleVenta.VTASsucoDie(VentasSeleccionadas[PaginadoActual].ID);
                        ///////////////////////////////
                        Visible = false;
                        DM0312_ExploradorVentas ExploradorVentas =
                            (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                        ExploradorVentas.TableroMovimientos();
                        int idGenerado = 0;

                        CDetalleVenta.MovimientoGenerado = true;
                        idGenerado = CDetalleVenta.obtenerIdGenerado(VentasSeleccionadas[PaginadoActual].ID);
                        CDetalleVenta.CargaMovimientoCreado(Convert.ToInt32(VentasSeleccionadas[PaginadoActual].ID),
                            idGenerado, VentasSeleccionadas, true);

                        thr.Abort();

                        if (idGenerado != 0)
                        {
                            MessageBox.Show("Movimiento Afectado correctamente", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            if (bStp) CDetalleVenta.realizarDispersion(idGenerado);
                        }

                        ExploradorVentas.CargarNuevasAfectaciones(this, VentasSeleccionadas);
                        //-864 GESSY  CERRAR LA VENTANA DE PROCESO

                        //////////////////////////////////////
                        return;
                    }
                }
            }

            //checar si el usuario puede afectar otros movs o solo los suyos
            bool PuedeAfectar = true;
            contadorSMS = 1;

            if (!CUsuario.AfectarOtrosMovs)
                if (CUsuario.Usuario != VentasSeleccionadas[PaginadoActual].Usuario)
                    PuedeAfectar = false;

            if (VentasSeleccionadas[PaginadoActual].Estatus != "SINAFECTAR" &&
                VentasSeleccionadas[PaginadoActual].Estatus != "PENDIENTE")
                PuedeAfectar = false;

            if (!PuedeAfectar)
            {
                MessageBox.Show("No puede afectar movimientos que no sean creados por su usuario", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string articuloSeleccionado = string.Empty;
                if (dgv_detalle.SelectedRows.Count > 0 &&
                    dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells.Count > 0)
                    articuloSeleccionado = dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1]
                        .Cells[EnteroPosicionArticulo].Value.ToString();
                string UEN = string.Empty;
                string OrigenID = string.Empty;
                string ReferenciaOrdenCompra = string.Empty;
                string Origen = string.Empty;
                string CadenaSumaImporte = string.Empty;
                string Vencimiento = string.Empty;
                string OrigenTipo = string.Empty;
                string Impuestos = string.Empty;
                string Importe = string.Empty;
                string OrigenTipoMov = string.Empty;

                if (Detalles.Count > 0)
                {
                    UEN = Detalles[(int)Enums.DetallesVenta.UEN];
                    OrigenID = Detalles[(int)Enums.DetallesVenta.OrigenID];
                    ReferenciaOrdenCompra = Detalles[(int)Enums.DetallesVenta.ReferenciaOrdenCompra];
                    Origen = Detalles[(int)Enums.DetallesVenta.Origen];

                    CDetalleVenta.PaginadoActual = PaginadoActual;
                    CadenaSumaImporte = CDetalleVenta.CalculaImporte(Detalles).ToString();
                    Vencimiento = Detalles[(int)Enums.DetallesVenta.Vencimiento];
                    OrigenTipo = Detalles[(int)Enums.DetallesVenta.OrigenTipo];
                    Impuestos = Detalles[(int)Enums.DetallesVenta.Impuestos];
                    Importe = Detalles[(int)Enums.DetallesVenta.Importe];
                    OrigenTipoMov = Detalles[(int)Enums.DetallesVenta.OrigenTipoMov];
                }

                string[] Parametros =
                {
                    VentasSeleccionadas[PaginadoActual].Mov,
                    VentasSeleccionadas[PaginadoActual].MovId,
                    "VTAS",
                    VentasSeleccionadas[PaginadoActual].ID.ToString(),
                    VentasSeleccionadas[PaginadoActual].Cliente,
                    VentasSeleccionadas[PaginadoActual].Estatus,
                    VentasSeleccionadas[PaginadoActual].EnviarA,
                    VentasSeleccionadas[PaginadoActual].FechaAlta.ToString(),
                    VentasSeleccionadas[PaginadoActual].Sucursal.ToString(),
                    VentasSeleccionadas[PaginadoActual].Condicion,
                    CategoriaEnviarA,
                    articuloSeleccionado,
                    VentasSeleccionadas[PaginadoActual].Almacen,
                    UEN,
                    OrigenID,
                    ReferenciaOrdenCompra,
                    Origen,
                    CadenaSumaImporte,
                    VentasSeleccionadas[PaginadoActual].MovTipo,
                    Vencimiento,
                    OrigenTipo,
                    Impuestos,
                    Importe,
                    OrigenTipoMov,
                    VentasSeleccionadas[PaginadoActual].IDEcommerce,
                    txt_Canal.Text,
                    txt_Referencia.Text,
                    string.Empty,
                    string.Empty
                };

                string msgPrecaucion = string.Empty;
                string msgTitulo = "";

                if (!frmLoading.Visible)
                {
                    frmLoading.Show(this);
                    EnableControls(false, this);
                    panelmenu.Location = new Point(2, 1);
                }

                bool NIPValido = true;

                if (pan_Vales.Visible)
                {
                    //Validacion nip y vale
                    if (txt_vale.Text != string.Empty && txt_NIP.Text != string.Empty)
                    {
                        if (await Task.Run(() => CDetalleVenta.ValidarNipVale(ref msgPrecaucion, Parametros,
                                txt_vale.Text.Trim(), txt_NIP.Text.Trim(), 0)))
                        {
                        }
                        else
                        {
                            NIPValido = false;
                        }
                    }
                    else
                    {
                        NIPValido = false;
                        msgPrecaucion = "NIP y Vale no pueden ser campos vacios";
                    }
                }

                string MovIDSalidaDiversa = string.Empty;

                if (NIPValido)
                {
                    CDetalleVenta.PaginadoActual = PaginadoActual;

                    bool SalidaDiversaConcluida = true;

                    //inserta salida diversa antes de la devolucion
                    if (VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Unicaja" &&
                        VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                    {
                        Afectando = true;
                        if (!frmLoading.Visible)
                        {
                            frmLoading.Show(this);
                            EnableControls(false, this);
                            panelmenu.Location = new Point(2, 1);
                        }

                        string msg = await Task.Run(() => CDetalleVenta.InsertarSalidaDiversa(VentasSeleccionadas,
                            ref SalidaDiversaConcluida, ref MovIDSalidaDiversa));
                        if (msg != string.Empty)
                            MessageBox.Show(msg, "Salida diversa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Afectando = false;
                        if (frmLoading.Visible)
                        {
                            frmLoading.Hide();
                            EnableControls(true, this);
                        }
                    }

                    CDetalleVenta.MovimientoGenerado = false;

                    if (SalidaDiversaConcluida)
                    {
                        if (!frmLoading.Visible)
                        {
                            frmLoading.Show(this);
                            EnableControls(false, this);
                            panelmenu.Location = new Point(2, 1);
                        }

                        Afectando = true;
                        //if (VerCantidadPendiente)
                        //{
                        //    await Task.Run(() => CDetalleVenta.InsertCantidadAAfectar(VentasSeleccionadas[PaginadoActual].ID, DatosDetalles));
                        //}
                        if (await Task.Run(() => ValidaAfectacion["AntesDe"](Parametros, ref msgPrecaucion)))
                            if (await Task.Run(() => ValidaAfectacion["DespuesDe"](Parametros, ref msgPrecaucion)))
                            {
                                //-FlujoMonedero
                                if (!almacen96Afectar) //-Primera Fase Automatizacion
                                    if (!controladorV.ExcluirSucursales(VentasSeleccionadas[PaginadoActual].Suc) &&
                                        VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                        VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                                        (VentasSeleccionadas[PaginadoActual].EnviarA == "2" ||
                                         VentasSeleccionadas[PaginadoActual].EnviarA == "6"))
                                        if (!ClaseEstatica.Usuario.usuario.Contains("FACTU"))
                                            if (!controladorV.puedeAfectarPedidoContado(
                                                    VentasSeleccionadas[PaginadoActual].ID))
                                            {
                                                MessageBox.Show(
                                                    "El pedido no ha sido liquidado en su totalidad y/o la sucursal origen es diferente a la sucursal destino",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                if (frmLoading.Visible)
                                                {
                                                    Afectando = false;
                                                    frmLoading.Hide();
                                                    EnableControls(true, this);
                                                }

                                                return;
                                            }

                                // Cambia la situacion del Movimiento
                                if (await Task.Run(() => CDetalleVenta.Afectar(Parametros, ref msgPrecaucion,
                                        ref msgTitulo, VentasSeleccionadas)))
                                {
                                    if (frmLoading.Visible)
                                    {
                                        frmLoading.Hide();
                                        EnableControls(true, this);
                                    }

                                    if (msgPrecaucion == string.Empty && (!CDetalleVenta.MovimientoGenerado ||
                                                                          (CDetalleVenta.MovimientoGenerado &&
                                                                           VentasSeleccionadas[PaginadoActual]
                                                                               .Estatus == "CONCLUIDO")))
                                        MessageBox.Show("Movimiento afectado satisfactoriamente", "Informacion",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    if ((VentasSeleccionadas[PaginadoActual].Mov == "Pedido" ||
                                         VentasSeleccionadas[PaginadoActual].Mov == "Pedido Mayoreo")
                                        && VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                                        CDetalleVenta.actualizarSituacion(VentasSeleccionadas[PaginadoActual].ID,
                                            VentasSeleccionadas[PaginadoActual].MovId);

                                    //this.Dispose();
                                    Visible = false;
                                    DM0312_ExploradorVentas ExploradorVentas =
                                        (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                                    ExploradorVentas.TableroMovimientos();
                                    if (!CDetalleVenta.MovimientoGenerado)
                                    {
                                        CDetalleVenta.MovimientoGenerado = true;
                                        CDetalleVenta.CargaMovimientoCreado(
                                            Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                            Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                            VentasSeleccionadas, true);
                                        //1573 desde aqui se puede validar que no se cambie el check
                                    }

                                    ExploradorVentas.CargarNuevasAfectaciones(this, VentasSeleccionadas);
                                }
                            }

                        Afectando = false;
                    }
                }

                if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                    (VentasSeleccionadas[PaginadoActual].EnviarA == "3" ||
                     VentasSeleccionadas[PaginadoActual].EnviarA == "7")
                    && VentasSeleccionadas[PaginadoActual].MaviTipoVenta == "Casa")
                {
                    DM0312_C_CampoExtra cExtra = new DM0312_C_CampoExtra();
                    cExtra.insertarEvento(VentasSeleccionadas[PaginadoActual].ID,
                        VentasSeleccionadas[PaginadoActual].Estatus, VentasSeleccionadas[PaginadoActual].Agente,
                        "VTA00015", "Campos Extras");
                }

                if (frmLoading.Visible)
                {
                    frmLoading.Hide();
                    EnableControls(true, this);
                }

                if (msgPrecaucion != string.Empty)
                {
                    string Titulo = "Afectar";
                    if (msgTitulo != string.Empty) Titulo = "Error: " + msgTitulo;
                    MessageBox.Show(msgPrecaucion, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Cancelar salida diversa si fue creada
                    if (MovIDSalidaDiversa != string.Empty) CDetalleVenta.CancelarSalidaDiversa(MovIDSalidaDiversa);
                }
            }

            //-430
            if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76 ||
                int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 80)
                if (VentasSeleccionadas.Count > 1)
                    if (CDetalleVenta.validarDimaNuevo(VentasSeleccionadas[PaginadoActual].ID))
                        if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                            VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                        {
                            List<string> lsDatos = CDetalleVenta.ObtenerComentarios(
                                VentasSeleccionadas[PaginadoActual - 1].MovId,
                                VentasSeleccionadas[PaginadoActual - 1].Mov);
                            string sAgente = CDetalleVenta.obtenerAgente(VentasSeleccionadas[PaginadoActual - 1].MovId);
                            CDetalleVenta.guardarHistorialDima(VentasSeleccionadas[PaginadoActual], lsDatos,
                                "PENDIENTE");
                        }

            //-997
            if (VentasSeleccionadas[PaginadoActual].Mov == "Credilana" &&
                VentasSeleccionadas[PaginadoActual].EnviarA == "77")
            {
                string sNombreCliente = CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente);
                string precio = CDetalleVenta.obtenerTotalVenta(VentasSeleccionadas[PaginadoActual].ID);
                CDetalleVenta.insertarDatosSms(VentasSeleccionadas[PaginadoActual].Cliente, precio,
                    VentasSeleccionadas[PaginadoActual].ID, "ACEPTADO",
                    sNombreCliente.Split(' ')[sNombreCliente.Split(' ').Length - 1]);

                CDetalleVenta.insertarSms(VentasSeleccionadas[PaginadoActual].Cliente,
                    VentasSeleccionadas[PaginadoActual].ID, 38);
            }

            // 1609
            /* GESSY 1609 025-0001-0010
                Yo como Subgerente Crédito Menudeo Administrativo.
                Necesito que se le envíe al cliente una notofocación para seguimiento de su trámite de credito.
                Con la finalidad de mantener informado al cliente sobre la evolución de su solicitud.
                1.-	Mensaje SMS de seguimiento
                  - En caso de que el cliente tenga una solicitud de
                    credilana desde punto de venta.
                  - Al generar una nueva solicitud de credito y esta se afecte a estatus pendiente
                    (Cliente nuevo y de casa)
                  - El sistema deberá enviar un SMS con el número de seguimiento de su solicitud
                    generada de los canales de venta de crédito: 3, 4. y 7
            */
            if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" &&
                (VentasSeleccionadas[PaginadoActual].EnviarA == "3" ||
                 VentasSeleccionadas[PaginadoActual].EnviarA == "4" ||
                 VentasSeleccionadas[PaginadoActual].EnviarA == "7"))
                //Mensaje MSN
                CDetalleVenta.insertarSms(VentasSeleccionadas[PaginadoActual].Cliente,
                    VentasSeleccionadas[PaginadoActual].ID, 40);


            //-Datalogic
            /*Llamado al modulo de racargas*/
            if (ClaseEstatica.iRecarga == 1 && (VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                                                VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                                                VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU"))
                try
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pTicket.StartInfo.FileName =
                        ClaseEstatica.plugInPath + "moduloRecargas\\ModuloRecargas\\moduloRecargas.exe";
                    //pTicket.StartInfo.FileName = @"C:\Users\noreyes\source\repos\moduloRecargas\moduloRecargas\bin\Debug\moduloRecargas.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = VentasSeleccionadas[PaginadoActual].ID + " " +
                                                  VentasSeleccionadas[PaginadoActual].Sucursal + " " +
                                                  VentasSeleccionadas[PaginadoActual].Usuario;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.WaitForExit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            //-MejorasMayoreo
            if (VentasSeleccionadas[PaginadoActual].Mov.Equals("Pedido Mayoreo") &&
                VentasSeleccionadas[PaginadoActual].Estatus.Equals("PENDIENTE"))
            {
                btn_datosEntrega.Visible = false;
                lbl_comentariosDatosEntrega.Visible = false;
            }

            //-PrimeraFaseAutomatizacion
            almacen96Afectar = false;


            //-ReservaOnline //-PrimeraFaseDeAutomatizacion
            if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "")
                if (VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                    if (VentasSeleccionadas[PaginadoActual].Suc == 41 || VentasSeleccionadas[PaginadoActual].Suc == 90)
                        CDetalleVenta.actualizarReservaOnline(VentasSeleccionadas[PaginadoActual].IDEcommerce);

            //-864 GESSY tERMINAR PROCESO DE AFECTAR Y CERRAR VENTANAS 
            // Solo si es Pedido Pendiente y liberado
            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                VentasSeleccionadas[PaginadoActual].Estatus == "Pendiente")
                procesoTerminado();

            thr.Abort();
        }

        private void LayoutDIE()
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "DM0325DIE\\DM0325_LayoutsGenDIES.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = "L" + " " + "A" + " " + VentasSeleccionadas[PaginadoActual].ID;
                pTicket.StartInfo.UseShellExecute = false;
                //MessageBox.Show(pTicket.StartInfo.FileName.ToString()+" "+ pTicket.StartInfo.Arguments.ToString());
                pTicket.Start();
                pTicket.WaitForExit();
                //pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LayoutDIE", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function: LayoutDIE, class: DM0312_DetalleVenta.cs");
            }
        }


        /// <summary>
        ///     Cancelar un movimiento despues de validar que se pueda cancelar
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/07/2017
        private async void Btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (!ClaseEstatica.ListaPermisosCreacion.Contains("VTAS." + VentasSeleccionadas[PaginadoActual].Mov))
            {
                MessageBox.Show(
                    "El usuario no tiene acceso a editar el movimiento: " + VentasSeleccionadas[PaginadoActual].Mov,
                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //-CandadoEmbarque
            if (VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Mayoreo")
            {
                DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
                string[] sDatosEmbarque = DevolucionMov
                    .validarEstatusEmbarque(VentasSeleccionadas[PaginadoActual].MovId).Split('|');
                if (sDatosEmbarque.Length > 0)
                    if (sDatosEmbarque[0] == "SINAFECTAR" || sDatosEmbarque[0] == "PENDIENTE")
                    {
                        MessageBox.Show(
                            "La factura se encuentra en el embarque ID:" + sDatosEmbarque[1] +
                            ", en estatus sin afectar o pendiente, no se puede realizar la cancelación", "Precaucion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
            }

            //obtener numero de vale
            string sNumeroVale = CDetalleVenta.obtenerNumeroVale(VentasSeleccionadas[PaginadoActual].ID);

            //-PrimeraFaseDeAutomatizacion //-ReservaOnline
            if (VentasSeleccionadas[PaginadoActual].Almacen != "V00096")
                if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "")
                    if (CDetalleVenta.validarRecogerSucursal(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                        if ((VentasSeleccionadas[PaginadoActual].Situacion == "Liberado" &&
                             VentasSeleccionadas[PaginadoActual].Mov == "Pedido") ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura Mayoreo" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                            if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                                VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 41 ||
                                VentasSeleccionadas[PaginadoActual].Suc == 90)
                            {
                                frmSolicitudContraseña frmSolicitudContraseña = new frmSolicitudContraseña();
                                frmSolicitudContraseña.ShowDialog();
                                if (!frmSolicitudContraseña.bEsCorrecto)
                                {
                                    MessageBox.Show(
                                        "No se puede afectar el movimiento debido a que no se cumplio la validacion",
                                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }

                                CDetalleVenta.cancelarReservacion(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                            }

            //-AppDima
            string sReferencia = CDetalleVenta.EsAPPDIMA(VentasSeleccionadas[PaginadoActual].ID);
            if (sReferencia == "Credilana APPDIMA" || sReferencia == "Venta APPFINALES")
                if (VentasSeleccionadas[PaginadoActual].Mov == "Credilana")
                {
                    MessageBox.Show("No puede cancelar movimientos cuando provenga de APPDIMA", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            //-Datalogic
            if (ClaseEstatica.iRecarga == 1)
                if (CDetalleVenta.valdiarRecarga(VentasSeleccionadas[PaginadoActual].ID) == 1)
                {
                    MessageBox.Show("No Se Puede Cancelar El Moviemiento Debido A Que Ya Se Realizo La Recarga",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            //checar si el usuario puede cancelar otros movs o solo los suyos
            bool PuedeCancelar = true;
            if (!CUsuario.CancelarOtrosMovs)
                //DataTable TablaDatosTableroSeleccionadosPublica = (DataTable)TablaDatosGlobal.TablaDatosTableroSeleccionadosPublica;
                if (CUsuario.Usuario != VentasSeleccionadas[PaginadoActual].Usuario)
                    PuedeCancelar = false;
            if (!PuedeCancelar)
            {
                MessageBox.Show("No puede cancelar movimientos que no sean creados por otro usuario", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (
                    (
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura" ||
                        VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU"
                    )
                    && VentasSeleccionadas[PaginadoActual].Sucursal != ClaseEstatica.Usuario.sucursal
                )
                {
                    MessageBox.Show(
                        "No se puede cancelar movimientos generados en otra sucursal " +
                        VentasSeleccionadas[PaginadoActual].Sucursal, "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else
                {
                    CDetalleVenta.PaginadoActual = PaginadoActual;
                    int MovimientoSePuedeCancelar =
                        CDetalleVenta.ValidacionCancelacion(VentasSeleccionadas[PaginadoActual].Sucursal,
                            VentasSeleccionadas);
                    string Message = "¿ Esta seguro que desea cancelar el movimiento ?";
                    if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoSiSePuedeCancelar ||
                        MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoGeneraMovContrario)
                    {
                        if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoGeneraMovContrario)
                            Message = "Nota: Esta cancelación va a generar un movimiento contrario. " +
                                      Environment.NewLine + Environment.NewLine + Message;
                        bool respuesta = false;
                        DialogResult result = MessageBox.Show(Message, "Cancelacion",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            respuesta = true;
                            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                (VentasSeleccionadas[PaginadoActual].Estatus == "Pendiente" ||
                                 VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE") &&
                                (VentasSeleccionadas[PaginadoActual].Suc == 90 ||
                                 VentasSeleccionadas[PaginadoActual].Suc == 41))
                            {
                                CancelarEcommerce cancelarE = new CancelarEcommerce();
                                cancelarE.idventa = VentasSeleccionadas[PaginadoActual].ID;
                                cancelarE.ShowDialog();
                            }
                        }

                        if (respuesta)
                        {
                            //-FlujoMonedero

                            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                                controladorV.checarPedidoContado(int.Parse(VentasSeleccionadas[PaginadoActual]
                                    .EnviarA)))
                                if (controladorV.checarAnticipos(VentasSeleccionadas[PaginadoActual].ID))
                                {
                                    DialogResult res = MessageBox.Show(
                                        "El pedido cuenta con anticipos hechos. Se encuentra el cliente presente con usted?",
                                        "Cancelacion", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (res == DialogResult.Yes)
                                    {
                                        DM0312_LoginCancelacion LoginCancelacion = new DM0312_LoginCancelacion();

                                        if (LoginCancelacion.ShowDialog() == DialogResult.OK)
                                            try
                                            {
                                                string response =
                                                    controladorV.devolucionAnticipos(VentasSeleccionadas[PaginadoActual]
                                                        .ID);
                                                MessageBox.Show(response, "Cancelacion",
                                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }
                                            catch
                                            {
                                                MessageBox.Show("No se pudieron devolver los anticipos", "Cancelacion",
                                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }
                                        else
                                            return;
                                    }
                                    else
                                    {
                                        MessageBox.Show(
                                            "Es necesario que el cliente se encuentre con usted para poder realizar la cancelacion.",
                                            "Cancelacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        return;
                                    }
                                }

                            /*if (PermisoSolicitudCancelacion()) {
                                using (SolicitudCancelacionMovimiento SCM =
                                       new SolicitudCancelacionMovimiento(VentasSeleccionadas[PaginadoActual])) {
                                    SCM.ShowDialog();
                                }
                                return;
                            }*/

                            ////////Inicia se libera el Descuento ZZZ despues de Cancelar el Análisis de Crédito o Pedido de Crédito de los Canales 3 o 7
                            int idReporteDescuento =
                                CDetalleVenta.getIdReporteDescuento(VentasSeleccionadas[PaginadoActual].ID);
                            if ((VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                                 VentasSeleccionadas[PaginadoActual].Mov == "Pedido") &&
                                (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 03 ||
                                 int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 07) &&
                                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                                idReporteDescuento != 0)
                                CDetalleVenta.UpdateDescuentoZZZ(VentasSeleccionadas[PaginadoActual].ID);
                            ///////Termina se libera el Descuento ZZZ despues de Cancelar el Análisis de Crédito o Pedido de Crédito de los Canales 3 o 7 

                            if (!frmLoading.Visible)
                            {
                                frmLoading.Show(this);
                                EnableControls(false, this);
                                panelmenu.Location = new Point(2, 1);
                            }

                            Afectando = true;
                            string tipomsgRef = string.Empty;
                            string msgPrecaucion = await Task.Run(() => CancelarMovimiento(ref tipomsgRef));
                            if (frmLoading.Visible)
                            {
                                frmLoading.Hide();
                                EnableControls(true, this);
                            }

                            if (msgPrecaucion != string.Empty)
                            {
                                if (tipomsgRef != string.Empty)
                                {
                                    if (tipomsgRef == "PRECAUCION")
                                    {
                                        msgPrecaucion = msgPrecaucion + Environment.NewLine + "Movimiento: " +
                                                        VentasSeleccionadas[PaginadoActual].Mov + " " +
                                                        VentasSeleccionadas[PaginadoActual].MovId;
                                        MessageBox.Show(msgPrecaucion, "Precaución", MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                                    }
                                    else if (tipomsgRef == "ERROR")
                                    {
                                        MessageBox.Show(msgPrecaucion, "Error", MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                                    }
                                    else
                                    {
                                        MessageBox.Show(msgPrecaucion, "Advertencia", MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(msgPrecaucion, "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                    //-ValeDigital

                                    if (msgPrecaucion == "Registro cancelado satisfactoriamente")
                                        if (VentasSeleccionadas[PaginadoActual].Canal == "VTAVALE")
                                            if (!string.IsNullOrEmpty(sNumeroVale))
                                                CDetalleVenta.cancelarVale(sNumeroVale);
                                }
                            }

                            if (msgPrecaucion == "Registro cancelado satisfactoriamente" || tipomsgRef == "Monedero")
                            {
                                //this.Dispose();
                                Visible = false;
                                DM0312_ExploradorVentas ExploradorVentas =
                                    (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                                ExploradorVentas.TableroMovimientos();
                                if (VentasSeleccionadas.Count > 1)
                                {
                                    string MovOrigen =
                                        CDetalleVenta.ObtenerMovOrigen(VentasSeleccionadas[PaginadoActual].ID);
                                    DM0312_MExploradorVenta modeloOrigen =
                                        VentasSeleccionadas.FirstOrDefault(x => x.Mov + " " + x.MovId == MovOrigen);
                                    if (modeloOrigen != null)
                                        CDetalleVenta.CargaMovimientoCreado(modeloOrigen.ID, modeloOrigen.ID,
                                            VentasSeleccionadas, true);
                                    CDetalleVenta.CargaMovimientoCreado(VentasSeleccionadas[PaginadoActual].ID,
                                        VentasSeleccionadas[PaginadoActual].ID, VentasSeleccionadas);
                                    VentasSeleccionadas.RemoveAt(PaginadoActual);
                                    if (PaginadoActual > 0)
                                    {
                                        PaginadoActual = PaginadoActual - 1;
                                        CDetalleVenta.PaginadoActual = PaginadoActual;
                                    }

                                    CDetalleVenta.MovimientoGenerado = true;
                                }
                                else
                                {
                                    CDetalleVenta.MovimientoGenerado = false;
                                    //this.Dispose();
                                }

                                ExploradorVentas.CargarNuevasAfectaciones(this, VentasSeleccionadas);
                                if (VentasSeleccionadas.Count > 1 && VentasSeleccionadas.Count < PaginadoActual)
                                    Btn_detallePosterior_Click(null, null);

                                if (controladorV.ValidarDie() != "NO")
                                    if (CDetalleVenta.validaCancelaDIE(VentasSeleccionadas[PaginadoActual].ID) == "SI")
                                        LayoutCancelaDIE();


                                //-430
                                if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76 ||
                                    int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 80)
                                    if (CDetalleVenta.validarDimaNuevo(VentasSeleccionadas[PaginadoActual].ID))
                                        foreach (DM0312_MExploradorVenta item in VentasSeleccionadas)
                                        {
                                            item.Estatus = CDetalleVenta.obtenerEstatusVenta(item.ID);
                                            if ((item.Mov == "Analisis Credito" || item.Mov == "Solicitud Credito") &&
                                                item.Estatus == "CANCELADO")
                                            {
                                                List<string> datos =
                                                    CDetalleVenta.FechaActualizacion(item, "PENDIENTE");
                                                if (datos.Count > 0)
                                                {
                                                    CDetalleVenta.GuardaNuevoRegistro(datos, item.Estatus);
                                                }
                                                else
                                                {
                                                    List<string> lsDatos =
                                                        CDetalleVenta.ObtenerComentarios(
                                                            VentasSeleccionadas[PaginadoActual].MovId,
                                                            VentasSeleccionadas[PaginadoActual].Mov);
                                                    CDetalleVenta.actualiarHistorialDima(item, lsDatos[0], "CANCELADO");
                                                }
                                            }
                                        }
                            }

                            Afectando = false;
                        }
                    }
                    else if (MovimientoSePuedeCancelar ==
                             (int)Enums.MovCancelacionBanderas.MovimientoFacturaDeOtraSucursal)
                    {
                        MessageBox.Show("No se puede cancelar movimientos generados en otra sucursal", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoYaCancelado)
                    {
                        MessageBox.Show("Este movimiento ya ha sido cancelado", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoConNota)
                    {
                        MessageBox.Show("Cancelar nota", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else if (MovimientoSePuedeCancelar == (int)Enums.MovCancelacionBanderas.MovimientoPendiente)
                    {
                        MessageBox.Show("Cancelar venta pendiente", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
            }

            //CDetalleVenta.EstatusMonedero(VentasSeleccionadas[PaginadoActual].ID, "EstatusCancelado");
        }

        private bool PermisoSolicitudCancelacion()
        {
            bool permisos = true;
            string[] SucursalEcommerce = { "90", "41" };
            List<int> sucursalTecnologicas = solicitudCancelacionC.ListaSucursalVirtual();
            string[] mov = { "FACTURA", "FACTURA VIU", "FACTURA MAYOREO" };
            string FechaActual = DateTime.Now.ToString("yy/M/d");

            try
            {
                if (SucursalEcommerce.Contains(VentasSeleccionadas[PaginadoActual].Suc.ToString()))
                    permisos = false;

                if ((ClaseEstatica.Usuario.Acceso != "VENTR_GERA" &&
                     !sucursalTecnologicas.Contains(VentasSeleccionadas[PaginadoActual].Suc)) ||
                    ClaseEstatica.Usuario.Acceso == "VENTR_GERA")
                    permisos = false;

                if (VentasSeleccionadas[PaginadoActual].Estatus == "SIN AFECTAR")
                    permisos = false;

                if (mov.Contains(VentasSeleccionadas[PaginadoActual].Mov.ToUpper()) &&
                    VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("yy/M/d") != FechaActual)
                    permisos = false;
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                //sbp_EstatusPrograma.Text = @"Error: " + e.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }

            return permisos;
        }

        private void LayoutCancelaDIE()
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\DM0325DIE\\DM0325_LayoutsGenDIES.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = "L" + " " + "B" + " " + VentasSeleccionadas[PaginadoActual].ID;
                pTicket.StartInfo.UseShellExecute = false;
                //MessageBox.Show(pTicket.StartInfo.FileName.ToString() + " " + pTicket.StartInfo.Arguments.ToString());
                pTicket.Start();
                pTicket.WaitForExit();
                //pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LayoutDIE", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function: LayoutDIE, class: DM0312_DetalleVenta.cs");
            }
        }

        /// <summary>
        ///     Cancelacion de movimiento
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 31/07/2017
        protected string CancelarMovimiento(ref string tipomsgRef)
        {
            string msgRespuesta = string.Empty;

            string MovID = VentasSeleccionadas[PaginadoActual].MovId;
            string Usuario = VentasSeleccionadas[PaginadoActual].Usuario;
            string Mov = VentasSeleccionadas[PaginadoActual].Mov;
            string ID = VentasSeleccionadas[PaginadoActual].ID.ToString();
            int? Sucursal = VentasSeleccionadas[PaginadoActual].Sucursal;
            int EnviarA = 0;
            if (VentasSeleccionadas[PaginadoActual].EnviarA != null &&
                VentasSeleccionadas[PaginadoActual].EnviarA != string.Empty)
                EnviarA = int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA);
            string IDECommerce = "0";
            if (VentasSeleccionadas[PaginadoActual].IDEcommerce != null &&
                VentasSeleccionadas[PaginadoActual].IDEcommerce != string.Empty)
                IDECommerce = VentasSeleccionadas[PaginadoActual].IDEcommerce;
            IDECommerce = txt_Commerce.Text;
            CDetalleVenta.PaginadoActual = PaginadoActual;
            msgRespuesta = CDetalleVenta.CancelarMovimiento(ID, Mov, MovID, ClaseEstatica.Usuario.Usser, Sucursal,
                EnviarA, IDECommerce, ref tipomsgRef);

            //-864 GESSY  Funcion que Cancela los Mov
            if (VentasSeleccionadas[PaginadoActual].Mov == "Credilana" &&
                VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
                CDetalleVenta.CancelarMovPadreCredilana(ID, Mov, MovID, ClaseEstatica.Usuario.Usser, Sucursal, EnviarA,
                    IDECommerce, ref tipomsgRef);

            if (msgRespuesta == string.Empty) msgRespuesta = "Registro cancelado satisfactoriamente";

            return msgRespuesta;
        }

        /// <summary>
        ///     Cambio de fila seleccionada
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        protected void ChangeSelectedCheckbox()
        {
            int selectedRowCount = dgv_datosEntrega.Rows.GetRowCount(DataGridViewElementStates.Selected);

            foreach (DataGridViewRow dgrow in dgv_datosEntrega.Rows)
                if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                {
                    DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                    if (selectedRowCount > 0 &&
                        dgrow.Index == dgv_datosEntrega.SelectedRows[selectedRowCount - 1].Index)
                        dcb.Value = true;
                    else
                        dcb.Value = false;
                }
        }

        /// <summary>
        ///     evento de fila seleccionada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        private void Dgv_datosEntrega_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            NuevaEntrega = false;
            btn_nuevaEntrega.Enabled = true;
            gb_CamposEntrega.Visible = true;
            gbx_DatosEntrega.Height = 354;
            ChangeSelectedCheckbox();

            dgv_datosEntrega.RefreshEdit();
            if (dgv_datosEntrega.Rows.Count > 0) dgv_datosEntrega.NotifyCurrentCellDirty(true);

            DataGridViewSelectedRowCollection selectedRows = dgv_datosEntrega.SelectedRows;
            if (selectedRows.Count > 0 && BitacoraEntregas != null &&
                selectedRows[selectedRows.Count - 1].Index < BitacoraEntregas.Count)
            {
                txt_direccionEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Direccion;
                cb_colonia.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Colonia;
                txt_CPEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].CP;
                txt_PoblacionEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Poblacion;
                txt_EstadoEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Estado;
                txt_EntreCallesEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].EntreCalles;
                txt_TelParticularEntrega.Text =
                    BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].TelefonoParticular;
                txt_MovilEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].TelefonoMovil;
                txt_ReferenciaEntrega.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].Referencia;
                txt_numE.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].NumExt;
                txt_NumI.Text = BitacoraEntregas[selectedRows[selectedRows.Count - 1].Index].NumInt;
            }
            else
            {
                txt_direccionEntrega.Text = "";
                cb_colonia.Text = string.Empty;
                txt_CPEntrega.Text = "";
                txt_PoblacionEntrega.Text = "";
                txt_EstadoEntrega.Text = "";
                txt_EntreCallesEntrega.Text = "";
                txt_TelParticularEntrega.Text = "";
                txt_MovilEntrega.Text = "";
                txt_ReferenciaEntrega.Text = "";
                txt_numE.Text = "";
                txt_NumI.Text = "";
            }

            gb_CamposEntrega.Focus();
            flpanel.Height = gpbxHeightO;
        }

        /// <summary>
        ///     Guarda o crea nueva fila para datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        private void Btn_guardar_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dgv_datosEntrega.SelectedRows;

            if (cb_colonia.Text != string.Empty && txt_numE.Text != string.Empty &&
                txt_CPEntrega.Text != string.Empty &&
                txt_PoblacionEntrega.Text != string.Empty && txt_direccionEntrega.Text != string.Empty &&
                (txt_TelParticularEntrega.Text != string.Empty || txt_TelParticularEntrega.Text == "0000000000")
                && (txt_MovilEntrega.Text != string.Empty || txt_MovilEntrega.Text == "0000000000"))
            {
                bool telefonosValidos = true;
                bool MovilEntregaValido = true;
                bool ParticularValido = true;
                if (txt_MovilEntrega.Text != string.Empty && !funciones.ValidaTelefonos(txt_MovilEntrega.Text))
                {
                    telefonosValidos = false;
                    MovilEntregaValido = false;
                }

                if (txt_TelParticularEntrega.Text != string.Empty &&
                    !funciones.ValidaTelefonos(txt_TelParticularEntrega.Text))
                {
                    telefonosValidos = false;
                    ParticularValido = false;
                }

                if (telefonosValidos)
                {
                    //Parametros que se guardaran en los datos de entrega
                    string[] Parametros =
                    {
                        txt_Cliente.Text,
                        txt_direccionEntrega.Text,
                        cb_colonia.Text,
                        txt_PoblacionEntrega.Text,
                        txt_CPEntrega.Text,
                        txt_EstadoEntrega.Text,
                        txt_EntreCallesEntrega.Text,
                        txt_TelParticularEntrega.Text,
                        txt_MovilEntrega.Text,
                        txt_ReferenciaEntrega.Text,
                        txt_numE.Text,
                        txt_NumI.Text
                    };

                    CDetalleVenta.PaginadoActual = PaginadoActual;
                    CDetalleVenta.GuardarDatosEntrega(selectedRows, BitacoraEntregas, Parametros,
                        VentasSeleccionadas[PaginadoActual].ID, VentasSeleccionadas[PaginadoActual].Sucursal,
                        NuevaEntrega);

                    chkDomicilioCliente.Visible = false;
                    lbl_comentariosDatosEntrega.Visible = true;

                    BitacoraEntregas.Clear();
                    string IDSeleccionado = string.Empty;
                    BitacoraEntregas = CDetalleVenta.ObtenerBitacoraEntregas(txt_Cliente.Text, ref IDSeleccionado,
                        VentasSeleccionadas[PaginadoActual].ID.ToString());

                    int? BitacoraSeleccionada =
                        CDetalleVenta.ObtenerBitacoraSeleccionada(IDSeleccionado, BitacoraEntregas);

                    dgv_datosEntrega.DataSource = null;
                    dgv_datosEntrega.DataSource = BitacoraEntregas;
                    CDetalleVenta.FillDataGridDatosEntrega(BitacoraEntregas, ref dgv_datosEntrega,
                        BitacoraSeleccionada);
                    btn_nuevaEntrega.Enabled = true;
                }
                else
                {
                    string PhoneValido = string.Empty;
                    if (!MovilEntregaValido) PhoneValido = "Teléfono movil";
                    if (!ParticularValido)
                    {
                        if (PhoneValido != string.Empty)
                            PhoneValido = PhoneValido + " y teléfono particular";
                        else
                            PhoneValido = "Teléfono particular";
                    }

                    MessageBox.Show(PhoneValido + " con formato incorrecto", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
            else
            {
                string Faltantes = "";
                if (cb_colonia.Text == string.Empty) Faltantes += "Colonia";
                if (txt_numE.Text == string.Empty) Faltantes += "Numero Exterior";
                if (txt_CPEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", código postal" : "Código postal";
                if (txt_PoblacionEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", población" : "Población";
                if (txt_direccionEntrega.Text == string.Empty)
                    Faltantes += Faltantes != "" ? ", dirección" : "Dirección";
                if (txt_TelParticularEntrega.Text == string.Empty && txt_TelParticularEntrega.Text != "0000000000")
                    Faltantes += Faltantes != "" ? ", teléfono particular" : "Teléfono particular";
                if (txt_MovilEntrega.Text == string.Empty && txt_MovilEntrega.Text != "0000000000")
                    Faltantes += Faltantes != "" ? ", teléfono movil" : "Teléfono movil";

                MessageBox.Show("Falta agregar " + Faltantes + " para poder guardar la direccion de entrega",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ComponentesFocus();
            }
        }

        public void ComponentesFocus()
        {
            if (txt_direccionEntrega.Text == string.Empty)
            {
                txt_direccionEntrega.Select();
            }
            else
            {
                if (cb_colonia.Text == string.Empty)
                {
                    cb_colonia.Select();
                }
                else
                {
                    if (txt_CPEntrega.Text == string.Empty)
                    {
                        txt_CPEntrega.Select();
                    }
                    else
                    {
                        if (txt_PoblacionEntrega.Text == string.Empty)
                        {
                            txt_PoblacionEntrega.Select();
                        }
                        else
                        {
                            if (txt_TelParticularEntrega.Text == string.Empty &&
                                txt_TelParticularEntrega.Text != "0000000000")
                            {
                                txt_TelParticularEntrega.Select();
                            }
                            else
                            {
                                if (txt_MovilEntrega.Text == string.Empty && txt_MovilEntrega.Text != "0000000000")
                                    txt_MovilEntrega.Select();
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        ///     quita las lineas del groupbox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">PaintEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 08/08/17
        private void Gbx_DatosEntrega_Paint_1(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        /// <summary>
        ///     solo números en telefono
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void Txt_TelParticularEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_MovilEntrega.Select();
        }

        /// <summary>
        ///     solo números en telefono
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void Txt_MovilEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_ReferenciaEntrega.Select();
        }

        /// <summary>
        ///     boton para indicar que se hara una nueva entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 10/08/17
        private void Btn_nuevo_Click(object sender, EventArgs e)
        {
            NuevaEntrega = true;
            gb_CamposEntrega.Visible = true;
            gbx_DatosEntrega.Height = 354;

            btn_nuevaEntrega.Enabled = false;
            txt_direccionEntrega.Text = string.Empty;
            cb_colonia.Text = string.Empty;
            txt_CPEntrega.Text = string.Empty;
            txt_PoblacionEntrega.Text = string.Empty;
            txt_EstadoEntrega.Text = string.Empty;
            txt_EntreCallesEntrega.Text = string.Empty;
            txt_TelParticularEntrega.Text = string.Empty;
            txt_MovilEntrega.Text = string.Empty;
            txt_ReferenciaEntrega.Text = string.Empty;
            txt_numE.Text = string.Empty;
            txt_NumI.Text = string.Empty;

            chkDomicilioCliente.Visible = true;
            lbl_comentariosDatosEntrega.Visible = false;

            foreach (DataGridViewRow dgrow in dgv_datosEntrega.Rows)
                if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                {
                    DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                    dcb.Value = false;
                }

            dgv_datosEntrega.ClearSelection();

            flpanel.Height = gpbxHeightO;
            gb_CamposEntrega.Focus();
        }

        /// <summary>
        ///     Cambia el color de los grids si son paquetes
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        protected void ConfiguracionGridviewDetalle()
        {
            int gvheight = 40;
            for (int i = 0; i < ListaDetallesSeleccionados.Count; i++)
            for (int h = 0; h < DatosDetalles.Count; h++)
                if (ListaDetallesSeleccionados[i].ID == VentasSeleccionadas[PaginadoActual].ID)
                {
                    if (ListaDetallesSeleccionados[i].RenglonDeArticulo == DatosDetalles[h].RenglonDeArticulo &&
                        DatosDetalles[h].EsComponentePaquete)
                    {
                        if (dgv_detalle.CurrentCell != null && dgv_detalle.CurrentCell.ColumnIndex == h)
                            dgv_detalle.Rows[h].DefaultCellStyle.SelectionForeColor = Color.LightGray;
                        dgv_detalle.Rows[h].DefaultCellStyle.ForeColor = Color.DimGray;
                    }

                    if (ListaDetallesSeleccionados[i].Tipo == "Serie")
                        dgv_detalle.Rows[h].Cells[(int)Enums.gvDetallesArticulos.Series].ToolTipText =
                            "Dar doble clic para editar series";
                }

            for (int i = 0; i < dgv_detalle.Rows.Count; i++)
                if (i < 14)
                    gvheight = gvheight + 20;
                else
                    break;

            VerCantidadPendiente = false;

            if (VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                VentasSeleccionadas[PaginadoActual].Mov == "Pedido Mayoreo")
                VerCantidadPendiente = true;

            dgv_detalle.Height = gvheight;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Costo].Visible = VerCosto;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Articulo].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Cantidad].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Precio].ReadOnly = !VerCosto;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Importe].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Costo].ReadOnly = !VerCosto;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Series].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.Observaciones].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.CantidadPendiente].Visible = VerCantidadPendiente;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.CantidadPendiente].ReadOnly = true;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.CantidadAAfectar].Visible = VerCantidadPendiente;
            dgv_detalle.Columns[(int)Enums.gvDetallesArticulos.CantidadAAfectar].ReadOnly = false;

            dgv_detalle.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_detalle.Columns[0].Width = 140;
            dgv_detalle.Columns[1].Width = 60;
            dgv_detalle.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv_detalle.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv_detalle.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv_detalle.Columns[3].Width = 140;
            dgv_detalle.Columns[dgv_detalle.Columns.Count - 5].Width = 180;
            dgv_detalle.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ValidacionEmbarque();
            Dgv_detalle_RowEnter(null, null);
        }

        /// <summary>
        ///     Abre dialogo de situaciones
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        private void Btn_Situaciones_Click(object sender, EventArgs e)
        {
            string beneficiario = CDetalleVenta.BeneficiarioFinal(VentasSeleccionadas[PaginadoActual].ID);
            int valSit = 0;
            if (CSituaciones.Validacion76(VentasSeleccionadas[PaginadoActual].ID.ToString(),
                    VentasSeleccionadas[PaginadoActual].EnviarA, VentasSeleccionadas[PaginadoActual].Situacion))
                if (ListaSituaciones.Count > 0)
                {
                    if ((VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "AnalisisCredito") &&
                        VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                        (VentasSeleccionadas[PaginadoActual].Cliente.Contains("P") || beneficiario.Contains("P")))
                        valSit = 1;

                    Dm0312DetalleSituaciones.Situaciones = ListaSituaciones;

                    Dm0312DetalleSituaciones situaciones = new Dm0312DetalleSituaciones(VentasSeleccionadas)
                    {
                        PaginadoActual = PaginadoActual
                    };

                    if (MovEsValera)
                        //Checar si viene aceptado y remover de la lista (solo si el mov contiene articulos de valr)
                        ListaSituaciones = CDetalleVenta.SituacionAceptadoValera(ListaSituaciones);
                    TopMost = false;
                    situaciones.ContSit = valSit;
                    situaciones.ShowDialog();
                    if (situaciones.ValidaSituacion)
                    {
                        ListaSituaciones = CSituaciones.ObtenerSituaciones();
                        ObtenerInformacionTablero();
                        CDetalleVenta.actualizarCodigoRecomendadorDima(txt_Cliente.Text);
                    }
                }

            // GESSY 1030/1061 DIMA Mensaje MSN
            if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito"
                && VentasSeleccionadas[PaginadoActual].Situacion == "Aceptado"
                && VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE"
                && (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76
                    || int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 7
                    || int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 3
                )
               )
                if (!CDetalleVenta.tieneAnalisisCreditoAceptado76(VentasSeleccionadas[PaginadoActual].Cliente))
                    //Validar red dima
                    if (!CDetalleVenta.validarRedDima(VentasSeleccionadas[PaginadoActual].Cliente))
                    {
                        CDetalleVenta.actualizarCodigoRecomendador(VentasSeleccionadas[PaginadoActual].Cliente,
                            int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA));
                        string a = CDetalleVenta.generarRedDima(VentasSeleccionadas[PaginadoActual].Cliente,
                            VentasSeleccionadas[PaginadoActual].Nombre);
                    }

            //-430
            if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 76 ||
                int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 80)
                if (CDetalleVenta.validarDimaNuevo(VentasSeleccionadas[PaginadoActual].ID))
                    if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                        VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                    {
                        if (CDetalleVenta.validarFecha(VentasSeleccionadas[PaginadoActual].MovId,
                                VentasSeleccionadas[PaginadoActual].Mov))
                            foreach (DM0312_MExploradorVenta item in VentasSeleccionadas)
                            {
                                List<string> lsDatos = CDetalleVenta.ObtenerComentarios(item.MovId, item.Mov);
                                CDetalleVenta.guardarHistorialDima(VentasSeleccionadas[PaginadoActual], lsDatos,
                                    VentasSeleccionadas[PaginadoActual].Estatus);
                                break;
                            }
                        else
                            CDetalleVenta.actualiarHistorialDima(VentasSeleccionadas[PaginadoActual], "",
                                VentasSeleccionadas[PaginadoActual].Estatus);
                    }

            //-VentaCredito
            if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "0" &&
                (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                 VentasSeleccionadas[PaginadoActual].Sucursal == 90 ||
                 VentasSeleccionadas[PaginadoActual].Sucursal == 504 ||
                 VentasSeleccionadas[PaginadoActual].Sucursal == 505) &&
                (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" ||
                 VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito") &&
                VentasSeleccionadas[PaginadoActual].Situacion == "Cancelado")
            {
                string ArgumentosPlugin =
                    "VTASPEDIDO " + VentasSeleccionadas[PaginadoActual].IDEcommerce + " " + "CANCELADO";
                CDetalleVenta.EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe",
                    ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
            }

            //-Dineralia
            if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                VentasSeleccionadas[PaginadoActual].EnviarA == "77" &&
                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
            {
                string sCorreo = CDetalleVenta.validarCorreo(VentasSeleccionadas[PaginadoActual].ID,
                    VentasSeleccionadas[PaginadoActual].Situacion);
                if (!string.IsNullOrEmpty(sCorreo))
                {
                    //aqui mando el aceptado
                    string sHtml = hmtlDineralia(sCorreo, VentasSeleccionadas[PaginadoActual].Cliente,
                        VentasSeleccionadas[PaginadoActual].ID);
                    string sCorreoCliente =
                        CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente, 2);
                    List<string> lsCorreoCliente = new List<string>();
                    lsCorreoCliente.Add(sCorreoCliente);
                    if (sCorreo == "CreditoNoAprobado")
                        enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");
                    if (sCorreo == "CONDICIONADO" || sCorreo == "CreditoAprobadoAjuste")
                    {
                        string sClave = CDetalleVenta.obtenerUltimoEvento(VentasSeleccionadas[PaginadoActual].ID);
                        CDetalleVenta.insertarDatosSms(VentasSeleccionadas[PaginadoActual].Cliente, sClave,
                            VentasSeleccionadas[PaginadoActual].ID, "PRETENCIONES", "");
                        enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");
                        CDetalleVenta.insertarSms(VentasSeleccionadas[PaginadoActual].Cliente,
                            VentasSeleccionadas[PaginadoActual].ID, 37);
                    }

                    if (sCorreo == "CreditoAprobado") enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");
                    CDetalleVenta.actualizarCorreoEnviado(VentasSeleccionadas[PaginadoActual].ID);
                }
            }

            //Analisis de credito canal 7 o 3, ejecutar plugin.
            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                (VentasSeleccionadas[PaginadoActual].EnviarA == "7" ||
                 VentasSeleccionadas[PaginadoActual].EnviarA == "3") &&
                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                if (VentasSeleccionadas[PaginadoActual].Sucursal == 504 ||
                    VentasSeleccionadas[PaginadoActual].Sucursal == 505 ||
                    VentasSeleccionadas[PaginadoActual].Suc == 505 || VentasSeleccionadas[PaginadoActual].Suc == 504)
                    CDetalleVenta.LiberarLinea(VentasSeleccionadas[PaginadoActual].IDEcommerce);

            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                VentasSeleccionadas[PaginadoActual].Situacion == "Liberado")
                if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
                    CDetalleVenta.LiberarLinea(VentasSeleccionadas[PaginadoActual].IDEcommerce);

            if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" &&
                VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                VentasSeleccionadas[PaginadoActual].Situacion == "Liberado")
                if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
                {
                    string articuloSeleccionado = string.Empty;
                    if (dgv_detalle.SelectedRows.Count > 0 &&
                        dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells.Count > 0)
                        articuloSeleccionado = dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1]
                            .Cells[EnteroPosicionArticulo].Value.ToString();
                    string UEN = string.Empty;
                    string OrigenID = string.Empty;
                    string ReferenciaOrdenCompra = string.Empty;
                    string Origen = string.Empty;
                    string CadenaSumaImporte = string.Empty;
                    string Vencimiento = string.Empty;
                    string OrigenTipo = string.Empty;
                    string Impuestos = string.Empty;
                    string Importe = string.Empty;
                    string OrigenTipoMov = string.Empty;


                    if (Detalles.Count > 0)
                    {
                        UEN = Detalles[(int)Enums.DetallesVenta.UEN];
                        OrigenID = Detalles[(int)Enums.DetallesVenta.OrigenID];
                        ReferenciaOrdenCompra = Detalles[(int)Enums.DetallesVenta.ReferenciaOrdenCompra];
                        Origen = Detalles[(int)Enums.DetallesVenta.Origen];

                        CDetalleVenta.PaginadoActual = PaginadoActual;
                        CadenaSumaImporte = CDetalleVenta.CalculaImporte(Detalles).ToString();
                        Vencimiento = Detalles[(int)Enums.DetallesVenta.Vencimiento];
                        OrigenTipo = Detalles[(int)Enums.DetallesVenta.OrigenTipo];
                        Impuestos = Detalles[(int)Enums.DetallesVenta.Impuestos];
                        Importe = Detalles[(int)Enums.DetallesVenta.Importe];
                        OrigenTipoMov = Detalles[(int)Enums.DetallesVenta.OrigenTipoMov];
                    }
                }

            //-PedidosMayoreo
            if (VentasSeleccionadas[PaginadoActual].Situacion == "Liberado"
                && VentasSeleccionadas[PaginadoActual].Mov == "Pedido Mayoreo"
                && VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE"
                && VentasSeleccionadas[PaginadoActual].Almacen == "V00096")
                if (CDetalleVenta.validarExistenciasParcialidad(VentasSeleccionadas[PaginadoActual].ID))
                    if (!CDetalleVenta.validarVentaConSerie(VentasSeleccionadas[PaginadoActual].ID))
                    {
                        if (CDetalleVenta.validarExistencia(VentasSeleccionadas[PaginadoActual].ID,
                                VentasSeleccionadas[PaginadoActual].Almacen))
                        {
                            bool bActualizo = CDetalleVenta.actualizarCantidadAfectar(
                                VentasSeleccionadas[PaginadoActual].ID, VentasSeleccionadas[PaginadoActual].Almacen);
                            if (bActualizo)
                            {
                                MessageBox.Show(
                                    "El pedido mayoreo tiene una parcialidad de Existencia. Sera modificado de forma Automatica",
                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                VerCantidadPendiente = true;
                            }
                        }
                        else
                        {
                            VerCantidadPendiente = false;
                        }

                        if (frmLoading.Visible)
                        {
                            frmLoading.Hide();
                            EnableControls(true, this);
                            frmLoading.Visible = false;
                        }

                        almacen96Afectar = true;
                        Btn_Afectar_Click(sender, e);
                    }
        }

        private bool ValidarArticuloyAlmacen()
        {
            try
            {
                if (VentasSeleccionadas[paginaSeleccionada].Almacen != "V00096") return false;
                List<string> data = (dgv_detalle.DataSource as List<ArticulosDetalleVenta>).Select(x => x.Articulo)
                    .ToList();
                return data.ObtenerInformacionArticulo();
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        ///     Muestra los almacenes disponibles para poder cambiar el actual
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/08/17
        private void Txt_Almacen_Click(object sender, EventArgs e)
        {
            bool bPuedeCambiarAlmacen = false;
            if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Devolucion" &&
                VentasSeleccionadas[PaginadoActual].Sucursal == 2000)
            {
                if (std.validarCambioAlmacen()) bPuedeCambiarAlmacen = true;
            }
            else
            {
                bPuedeCambiarAlmacen = true;
            }

            if (VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Unicaja" &&
                VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Mayoreo" &&
                bPuedeCambiarAlmacen &&
                VentasSeleccionadas[PaginadoActual].MovTipo != "VTAS.D")
            {
                DM0312_DetalleCambiarAlmacen Almacenes = new DM0312_DetalleCambiarAlmacen();
                DM0312_DetalleCambiarAlmacen.IDVenta = VentasSeleccionadas[PaginadoActual].ID;
                DM0312_DetalleCambiarAlmacen.AlmacenActual = VentasSeleccionadas[PaginadoActual].Almacen;
                DM0312_DetalleCambiarAlmacen.AlmacenAntes = VentasSeleccionadas[PaginadoActual].Almacen;
                DM0312_DetalleCambiarAlmacen.commerce = txt_Commerce.Text;

                Almacenes.VentasSeleccionadas = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
                Almacenes.PaginadoActual = PaginadoActual;
                TopMost = false;
                Almacenes.ShowDialog();
                cb_Almacen.Text = VentasSeleccionadas[PaginadoActual].Almacen;
                CDetalleVenta.PaginadoActual = PaginadoActual;
                CDetalleVenta.EliminaSeries();
                DatosDetalles.Select(x => x.Serie = "").ToList();
                dgv_detalle.DataSource = null;
                dgv_detalle.DataSource = DatosDetalles;
                ConfiguracionGridviewDetalle();
                //validar si tiene un articulo con familia motocicletas
                if (ValidarArticuloyAlmacen())
                {
                    MessageBox.Show("no se pueden facturar Motocicletas por distribución".ToUpper(), "Facturación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                ////-CambioAgente
                List<modeloHistorialId> listaHistorial = new List<modeloHistorialId>();
                if (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                    VentasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE" &&
                    (VentasSeleccionadas[PaginadoActual].Situacion == "Aceptado" ||
                     VentasSeleccionadas[PaginadoActual].Situacion == "Aceptado Condicionado"))
                    /* revisar la tabla std*/
                    if (!new[] { "P000504", "P000505" }.Contains(VentasSeleccionadas[PaginadoActual].Agente))
                    {
                        bool bPuedeCambiarAgente = CDetalleVenta.validarSucursal(ClaseEstatica.Usuario.Sucursal);
                        if (bPuedeCambiarAgente)
                        {
                            /*si cumple validar que el agente que se encuentre no se un generico*/
                            string sLetraAgente = CDetalleVenta
                                .obtenerAgenteDeLaVenta(VentasSeleccionadas[PaginadoActual].ID).Substring(0, 1);
                            if (sLetraAgente == "P")
                            {
                                string sAgente = CDetalleVenta.obtenerAgenteDeUsuario(ClaseEstatica.Usuario.usuario);
                                if (!string.IsNullOrEmpty(sAgente))
                                {
                                    listaHistorial =
                                        CDetalleVenta.obtenerHistoriaId(VentasSeleccionadas[PaginadoActual].ID);
                                    foreach (modeloHistorialId item in listaHistorial)
                                        if (!CDetalleVenta.actualizarVenta(item, sAgente))
                                            MessageBox.Show("Error al realizar el cambio de agente, favor de verificar",
                                                "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                else
                                {
                                    MessageBox.Show("El usuario no cuenta con agente valido", "Punto De Venta",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                        }
                    }

                //-ReservaOnline ->
                if (!CDetalleVenta.validarSucursal(VentasSeleccionadas[PaginadoActual].Almacen))
                    if (validarReserva())
                    {
                        List<string> listaArticulo =
                            CDetalleVenta.obtenerarticulosAReservar(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                        bool bPuedeReservar = false;

                        foreach (string sArticulo in listaArticulo)
                            if (CDetalleVenta.validarArticulosAReservar(sArticulo,
                                    VentasSeleccionadas[PaginadoActual].Almacen))
                            {
                                bPuedeReservar = true;
                            }
                            else
                            {
                                bPuedeReservar = false;
                                break;
                            }

                        if (bPuedeReservar)
                        {
                            CDetalleVenta.EjecutarPlugins(VentasSeleccionadas[PaginadoActual].IDEcommerce,
                                "cambioCodigoRecogeSucursal.exe",
                                ClaseEstatica.plugInPath + "cambioCodigoRecogeSucursal\\");
                            List<string> sCorreo =
                                CDetalleVenta.obtenerCorreos(VentasSeleccionadas[PaginadoActual].SucursalDestino);

                            int iUen = CDetalleVenta.obtenerUen(VentasSeleccionadas[PaginadoActual].Sucursal);

                            string htmlCorreo = obtenerHtmlCorreo(iUen);
#if PRODUCCION
                            enviarCorreos("Recoger Articulos Sucursal", htmlCorreo, sCorreo, "", 1, 0, "");
#endif

                            string sHtmlCorreoCliente = obtenerCorreoCliente(iUen);
                            string sCorreoCliente =
                                CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente, 2);

                            sCorreo = new List<string>();
                            sCorreo.Add(sCorreoCliente);

                            //enviarCorreos("Recoger Articulos Sucursal", sHtmlCorreoCliente, sCorreo, "", 1, 0, "");
                            //Validamos si ya se encuentra registrado el idecommerce
                            if (CDetalleVenta.validarExistenciaReserva(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                            {
                                //si se encuentra el idecommerce se actualiza el almacen
                                foreach (string item in listaArticulo)
                                    if (!CDetalleVenta.actualizarAlmacen(
                                            VentasSeleccionadas[PaginadoActual].IDEcommerce,
                                            VentasSeleccionadas[PaginadoActual].Almacen, item))
                                        MessageBox.Show(
                                            "Error al actualizar la reservacion al almacen " +
                                            VentasSeleccionadas[PaginadoActual].Almacen + "", "Punto De Venta",
                                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else
                            {
                                //si no se encuentra se insertan los articulos
                                foreach (string item in listaArticulo)
                                {
                                    int iCantidadArticulos =
                                        CDetalleVenta.obtenerCantidadArticulos(
                                            VentasSeleccionadas[PaginadoActual].IDEcommerce, item);
                                    CDetalleVenta.insertarReservacionArticulo(iCantidadArticulos, item,
                                        VentasSeleccionadas[PaginadoActual].Almacen,
                                        VentasSeleccionadas[PaginadoActual].IDEcommerce);
                                }
                            }
                        }
                        else
                        {
                            CAlmacenes ControladorAlmacenes = new CAlmacenes();
                            DM0312_DetalleCambiarAlmacen.AlmacenActual = DM0312_DetalleCambiarAlmacen.AlmacenAntes;
                            ControladorAlmacenes.ActualizarAlmacen(VentasSeleccionadas[PaginadoActual].Estatus);
                            VentasSeleccionadas[PaginadoActual].Almacen = DM0312_DetalleCambiarAlmacen.AlmacenAntes;
                            cb_Almacen.Text = VentasSeleccionadas[PaginadoActual].Almacen;
                            MessageBox.Show("No se cumple con la regla de existencia, Favor de revisar",
                                "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                if ((VentasSeleccionadas[PaginadoActual].Almacen == "V00096" ||
                     VentasSeleccionadas[PaginadoActual].Almacen == "V02000") &&
                    (VentasSeleccionadas[PaginadoActual].Mov == "Pedido" ||
                     VentasSeleccionadas[PaginadoActual].Mov == "Pedido Mayoreo") &&
                    VentasSeleccionadas[PaginadoActual].Situacion == "Liberado")
                {
                    if (VentasSeleccionadas[PaginadoActual].Almacen == "V00096")
                        if (CDetalleVenta.verExistenciaProductosPedido())
                        {
                            almacen96Afectar = true;
                            Btn_Afectar_Click(sender, e);
                        }

                    if (VentasSeleccionadas[PaginadoActual].Almacen == "V02000")
                        if (!CDetalleVenta.validarVentaConSerie(VentasSeleccionadas[PaginadoActual].ID))
                        {
                            List<ArticulosDetalleVenta> a = (List<ArticulosDetalleVenta>)dgv_detalle.DataSource;
                            int iCantidad = 0;
                            foreach (ArticulosDetalleVenta item in a)
                                if (item.Tipo != "Servicio")
                                    iCantidad++;

                            int iCantidadDetalle =
                                CDetalleVenta.cantidadDisponibles(VentasSeleccionadas[PaginadoActual].ID);
                            bool bRequiereTraspaso = false;
                            if (iCantidad != iCantidadDetalle) bRequiereTraspaso = true;

                            if (bRequiereTraspaso)
                            {
                                CDetalleVenta.realizarTraspasos(VentasSeleccionadas[PaginadoActual].ID, "V00096",
                                    "V02000",
                                    VentasSeleccionadas[PaginadoActual].Mov + " " +
                                    VentasSeleccionadas[PaginadoActual].MovId);
                                if (CDetalleVenta.validarTraspaso(VentasSeleccionadas[PaginadoActual].Mov + " " +
                                                                  VentasSeleccionadas[PaginadoActual].MovId))
                                {
                                    almacen2000Afectar = true;
                                    Btn_Afectar_Click(sender, e);
                                }
                                else
                                {
                                    MessageBox.Show("No se puede realizar la afectacion automatica.", "Punto De Venta",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            else
                            {
                                almacen2000Afectar = true;
                                Btn_Afectar_Click(sender, e);
                            }
                        }
                }
            }
        }

        /// <summary>
        ///     metodo encargado de validar si la venta puede reservar los articulos
        /// </summary>
        /// <returns>retorna true si puede reservar</returns>
        public bool validarReserva()
        {
            bool bPuedeReservar = false;
            if (DM0312_DetalleCambiarAlmacen.AlmacenActual != "V00096")
                if (DM0312_DetalleCambiarAlmacen.AlmacenAntes != DM0312_DetalleCambiarAlmacen.AlmacenActual)
                    if (VentasSeleccionadas[PaginadoActual].IDEcommerce != "" &&
                        VentasSeleccionadas[PaginadoActual].IDEcommerce != "0")
                        //if (CDetalleVenta.validarCteRecoge(VentasSeleccionadas[PaginadoActual].IDEcommerce))
                        if (VentasSeleccionadas[PaginadoActual].Situacion == "Liberado" &&
                            VentasSeleccionadas[PaginadoActual].Mov == "Pedido")
                            if (VentasSeleccionadas[PaginadoActual].Sucursal == 41 ||
                                VentasSeleccionadas[PaginadoActual].Sucursal == 90)
                                if (!CDetalleVenta.EsEcommerce(VentasSeleccionadas[PaginadoActual].ID,
                                        VentasSeleccionadas[PaginadoActual].IDEcommerce))
                                    bPuedeReservar = true;

            return bPuedeReservar;
        }


        private void Btn_AdjuntarSHM_Click(object sender, EventArgs e)
        {
            LlamadaPlugInAdjuntar();
        }


        private void Btn_HojaV_Click(object sender, EventArgs e)
        {
            LlamadaPlugInHojaVerde();
        }

        private void LlamadaPlugInHojaVerde()
        {
            if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                return;

            string mov = string.Empty;

            string user = string.Empty;

            user = ClaseEstatica.Usuario.usuario.Substring(0, 5);

            mov = VentasSeleccionadas[PaginadoActual].Mov.Replace(" ", "_");
            try
            {
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Pedido")
                    if (CDetalleVenta.VerificarSucursal())
                    {
                        if (user == "CREDI")
                        {
                            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                            {
                                Process System = new Process();
                                System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                                System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                                System.StartInfo.Verb = "runas";
                                System.StartInfo.Arguments = "MOSTRARHOJAVERDE" + " " + txt_Cliente.Text + " " +
                                                             VentasSeleccionadas[PaginadoActual].MovId;
                                System.StartInfo.UseShellExecute = false;
                                System.Start();
                                //-Revision de Procesos 2019-05-28
                                //System.WaitForExit();
                            }
                        }
                        else
                        {
                            user = ClaseEstatica.Usuario.usuario.Substring(0, 4);
                        }

                        if (user == "VENT")
                        {
                            Conv conversion = new Conv();

                            double importe = 0;

                            importe = conversion.ConvertFormatMoney(txt_Total.Text);

                            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                            {
                                Process System = new Process();
                                System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                                System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                                System.StartInfo.Verb = "runas";
                                //-Modificacion Captura Hoja Verde
                                //System.StartInfo.Arguments = "CAPTURARHOJAVERDE" + " " + txt_Cliente.Text + " " + VentasSeleccionadas[PaginadoActual].MovId + " " + importe.ToString();
                                System.StartInfo.Arguments = "CAPTURARHOJAVERDE" + " " + txt_Cliente.Text + " " +
                                                             VentasSeleccionadas[PaginadoActual].MovId + " " + importe +
                                                             " " + ClaseEstatica.Usuario.Usser;
                                System.StartInfo.UseShellExecute = false;
                                System.Start();
                                //-Revision de Procesos 2019-05-28
                                //System.WaitForExit();
                            }
                        }
                    }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llamadaPlugInHojaVerde", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Bloquea las teclas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        private void Cb_Almacen_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Unicaja" &&
                VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Mayoreo" &&
                VentasSeleccionadas[PaginadoActual].Mov != "Solicitud Devolucion" &&
                VentasSeleccionadas[PaginadoActual].MovTipo != "VTAS.D")
            {
                if (e.KeyChar == 13) cb_Almacen_Leave(null, null);
            }
            else
            {
                e.Handled = true;
            }
        }

        /// <summary>
        ///     Abre ventana para ver los enganches
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/08/17
        private void Txt_Enganche_Click(object sender, EventArgs e)
        {
            DM0312_DetalleEnganches Enganches = new DM0312_DetalleEnganches
            {
                VentasSeleccionadas = new List<DM0312_MExploradorVenta>(VentasSeleccionadas),
                PaginadoActual = PaginadoActual
            };
            TopMost = false;
            Enganches.ShowDialog();
        }

        /// <summary>
        ///     cambia colonia seleccionada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/09/17
        private void Cb_colonia_Click(object sender, EventArgs e)
        {
            DM0312_DetalleCodigoPostal.regresar = false;
            DM0312_DetalleCodigoPostal cp = new DM0312_DetalleCodigoPostal();
            TopMost = false;
            cp.ShowDialog();
            if (!DM0312_DetalleCodigoPostal.regresar)
            {
                cb_colonia.Text = cp.CodigoPostalSeleccionado.Colonia;
                txt_CPEntrega.Text = cp.CodigoPostalSeleccionado.CP;
                txt_PoblacionEntrega.Text = cp.CodigoPostalSeleccionado.Delegacion;
                txt_EstadoEntrega.Text = cp.CodigoPostalSeleccionado.Estado;
                txt_TelParticularEntrega.Select();
            }
        }

        /// <summary>
        ///     colonia keypress
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private void Cb_colonia_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        /// <summary>
        ///     Ordenamiento de datagrid por columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/10/17
        private void Dgv_detalle_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //var TempObjects = new List<object>(DatosDetalles.ToList());
            //funciones.OrderGridview(dgv_detalle, e.ColumnIndex, ref TempObjects, DatosDetalles.GetType().GetGenericArguments().Single());
            //DatosDetalles = TempObjects.OfType<ArticulosDetalleVenta>().ToList();
            //ConfiguracionGridviewDetalle();
        }

        /// <summary>
        ///     datos entrega gridview content click
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void Dgv_datosEntrega_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgv_datosEntrega.RefreshEdit();
        }

        /// <summary>
        ///     keypress direccion entrega textbox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void Txt_direccionEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cb_colonia.Select();


            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     keypress textbox calles entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/10/17
        private void Txt_EntreCallesEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txt_TelParticularEntrega.Select();
        }

        /// <summary>
        ///     Parche para el loader!
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">FormClosingEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/10/17
        private void DM0312_DetalleVenta_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Afectando)
            {
                MessageBox.Show("Favor de esperar a que termine el proceso actual", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            //-PedidosSinDetalle
            foreach (DM0312_MExploradorVenta item in VentasSeleccionadas) std.insertarIdVenta(item.ID, 2);

            Dispose();
            if (FlagAbrirDeHistorial)
            {
                Dispose();
            }
            else
            {
                DM0312_ExploradorVentas
                    expl = (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                expl.Focus();
            }
        }

        /// <summary>
        ///     Validacion embarque
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 17/10/17
        private void ValidacionEmbarque()
        {
            //Validacion embarque
            if (VentasSeleccionadas[PaginadoActual].Mov != "Factura" &&
                VentasSeleccionadas[PaginadoActual].Mov != "Factura VIU" &&
                VentasSeleccionadas[PaginadoActual].Mov != "Factura Mayoreo")
            {
                lbl_Embarque.Visible = false;
                txt_Embarque.Visible = false;
                txt_EmbarqueFecha.Visible = false;
            }
            else if (VentasSeleccionadas[PaginadoActual].Estatus != "Concluido" &&
                     VentasSeleccionadas[PaginadoActual].Almacen != "V00096")
            {
                lbl_Embarque.Visible = false;
                txt_Embarque.Visible = false;
                txt_EmbarqueFecha.Visible = false;
            }
            else
            {
                lbl_Embarque.Visible = true;
                txt_Embarque.Visible = true;
                string cadenaEmbarqueFecha = ListaDetallesSeleccionados[PaginadoActual].EmbarqueFecha;
                if (cadenaEmbarqueFecha != string.Empty)
                    txt_EmbarqueFecha.Visible = true;
                else
                    txt_EmbarqueFecha.Visible = false;
            }
        }

        /// <summary>
        ///     Parpadeo de vales
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 17/10/17
        private void PanelBlink(object sender, EventArgs e)
        {
            if (pan_Vales.Visible)
            {
                FlagToBlink = FlagToBlink ? FlagToBlink = false : FlagToBlink = true;
                pan_Vales.Invalidate();
            }
            else
            {
                timer1.Stop();
            }
        }

        /// <summary>
        ///     Pintado de parpadeo de vales
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">PaintEventArgs</param>
        /// Developer: Dan Palacios
        /// Date:17/10/17
        private void Pan_Vales_Paint(object sender, PaintEventArgs e)
        {
            if (FlagToBlink)
            {
                Rectangle rect = pan_Vales.ClientRectangle;
                rect.Width--;
                rect.Height--;
                e.Graphics.DrawRectangle(Pens.Red, rect);
            }
            else
            {
                pan_Vales.BorderStyle = BorderStyle.None;
            }
        }

        /// <summary>
        ///     Referencia entrega keypress validaciones
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyPressEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private void Txt_ReferenciaEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        /// <summary>
        ///     mueve el loader de lugar para volver a centrarlo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        private void DM0312_DetalleVenta_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        /// <summary>
        ///     Abre los anticipos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 08/11/17
        private void Btn_Anticipo_Click(object sender, EventArgs e)
        {
            string defCuentaUsuario = "";
            defCuentaUsuario = controllerExplorador.ValidaCajaUsuario(ClaseEstatica.Usuario.Usser);
            if (controladorV.ValidaEstatusCaja(defCuentaUsuario))
            {
                if (controladorV.ClienteConCuenta(VentasSeleccionadas[PaginadoActual].Cliente))
                {
                    int camposEntregaVisible = 0;
                    int camposEntregaVisibleClosed = 0;

                    if (!gb_CamposEntrega.Visible)
                    {
                        if (gbx_DatosEntrega.Visible)
                        {
                            camposEntregaVisible = -HeightFixer();
                        }
                        else
                        {
                            camposEntregaVisible = -80;
                            camposEntregaVisibleClosed = 80;
                        }
                    }

                    if (gb_anticipos.Visible)
                    {
                        gb_anticipos.Visible = false;
                        gpbxHeightO = gpbxHeightO - 180;
                        gpbxHeightC = gpbxHeightC - 120;
                        if (gbx_DatosEntrega.Visible)
                        {
                            flpanel.Height = gpbxHeightO + camposEntregaVisible;
                            lbl_Cliente.Focus();
                        }
                        else
                        {
                            flpanel.Height = gpbxHeightC + camposEntregaVisibleClosed;
                            gbx_DatosEntrega.Focus();
                        }

                        panelmenu.Location = new Point(2, 1);
                    }
                    else
                    {
                        gb_anticipos.Visible = true;
                        gpbxHeightO = gpbxHeightO + 180;
                        gpbxHeightC = gpbxHeightC + 120;
                        if (gbx_DatosEntrega.Visible)
                            flpanel.Height = gpbxHeightO + camposEntregaVisible;
                        else
                            flpanel.Height = gpbxHeightC + camposEntregaVisibleClosed;
                        AutoScrollPosition = new Point(0, 1020);
                        panelmenu.Location = new Point(2, 1);
                    }
                }
                else
                {
                    MessageBox.Show(
                        "No puede hacer anticipos o enganches a prospectos debe asignarle cuenta de cliente",
                        "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show(
                    "No puede hacer anticipos por que la caja " + defCuentaUsuario + " se encuentra cerrada",
                    "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        ///     Agrega una nueva forma de pago
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void AgregarFormaPago()
        {
            if (CDetalleVenta.SMStablaConversionSegurosValor() == "1")
            {
                int valorN = 0;
                string mensaje = "";
                valorN = pventa.ContadorFormasPago(txt_Condiciones.Text);
                if (valorN > 5)
                {
                    valorN = 5;
                    mensaje = "Solo se permiten 5 formas de pago distintas";
                }
                else
                {
                    mensaje = "No se permite agregar un numero mayor de formas de pago de las que tiene la condicion";
                }

                if (FormasPagoAgregadas.Count < valorN || (FormasPagoAgregadas.Count == 0 && valorN != 0))
                {
                    Label lbl_formaPago = new Label
                    {
                        Name = "lbl_formaPago",
                        Text = "Forma pago",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(72, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_formaPago);

                    ComboBox cb_FormaPago = pventa.ObtenerFormasDePago(FormasPagoAgregadas, txt_Condiciones.Text);
                    cb_FormaPago.Tag = FormasPagoTag.ToString();
                    cb_FormaPago.DropDownWidth = 253;
                    cb_FormaPago.Size = new Size(100, 21);
                    cb_FormaPago.Click += FormaPagoClick;
                    cb_FormaPago.SelectedIndexChanged += ComboDropped;
                    cb_FormaPago.DropDownClosed += CambiarFormaPago;
                    cb_FormaPago.DropDownStyle = ComboBoxStyle.DropDownList;
                    LastFormaPagoSelected.Add(FormasPagoTag, cb_FormaPago.Text);

                    flp_FormaPago.Controls.Add(cb_FormaPago);

                    Label lbl_Monto = new Label
                    {
                        Text = "Monto",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(50, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Monto);

                    TextBox tb_Monto = new TextBox
                    {
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(60, 21)
                    };
                    tb_Monto.KeyPress += Txt_MovilEntrega_KeyPress;

                    tb_Monto.KeyUp += KeyDownUpMonto;
                    tb_Monto.KeyDown += KeyDownUpMonto;
                    tb_Monto.Enter += FocusEnMonto;
                    tb_Monto.Leave += SalirDeFocusEnMonto;
                    tb_Monto.Text = "0";
                    tb_Monto.Name = "tb_Monto";
                    tb_Monto.MaxLength = 20;
                    flp_FormaPago.Controls.Add(tb_Monto);

                    Label lbl_MontoCeros = new Label
                    {
                        Text = ".00",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(40, 15),
                        Margin = new Padding(3, 9, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_MontoCeros);

                    Label lbl_Referencia = new Label
                    {
                        Text = "Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(70, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Referencia);

                    TextBox tb_Referencia = new TextBox
                    {
                        Name = "tb_Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(150, 21),
                        MaxLength = 100
                    };
                    flp_FormaPago.Controls.Add(tb_Referencia);

                    Button btn_removeFormaPago = new Button
                    {
                        FlatStyle = FlatStyle.Flat
                    };
                    btn_removeFormaPago.FlatAppearance.BorderColor = Color.Black;
                    btn_removeFormaPago.BackColor = Color.LightGray;
                    btn_removeFormaPago.Text = "Remover";
                    btn_removeFormaPago.Tag = FormasPagoTag.ToString();
                    btn_removeFormaPago.Cursor = Cursors.Hand;
                    btn_removeFormaPago.Click += RemoveSelectedFormaPago;
                    flp_FormaPago.Controls.Add(btn_removeFormaPago);

                    FormasPagoTag = FormasPagoTag + 1;
                    flp_FormaPago.VerticalScroll.Value = flp_FormaPago.VerticalScroll.Maximum;
                    flp_FormaPago.PerformLayout();

                    EfectivoSeleccionado();
                    if (cb_FormaPago.Text == "EFECTIVO")
                    {
                        Tb_efectivoRecibido.Text = "0";
                        lbl_cambio.Text = "Cambio: $ 0.00";
                    }
                }
                else
                {
                    if (valorN != 0)
                        MessageBox.Show(mensaje, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                if (FormasPagoAgregadas.Count < 5)
                {
                    Label lbl_formaPago = new Label
                    {
                        Name = "lbl_formaPago",
                        Text = "Forma pago",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(72, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_formaPago);

                    ComboBox cb_FormaPago = pventa.ObtenerFormasDePago(FormasPagoAgregadas, "1");
                    cb_FormaPago.Tag = FormasPagoTag.ToString();
                    cb_FormaPago.DropDownWidth = 253;
                    cb_FormaPago.Size = new Size(100, 21);
                    cb_FormaPago.Click += FormaPagoClick;
                    cb_FormaPago.SelectedIndexChanged += ComboDropped;
                    cb_FormaPago.DropDownClosed += CambiarFormaPago;
                    cb_FormaPago.DropDownStyle = ComboBoxStyle.DropDownList;
                    LastFormaPagoSelected.Add(FormasPagoTag, cb_FormaPago.Text);

                    flp_FormaPago.Controls.Add(cb_FormaPago);

                    Label lbl_Monto = new Label
                    {
                        Text = "Monto",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(50, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Monto);

                    TextBox tb_Monto = new TextBox
                    {
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(60, 21)
                    };
                    tb_Monto.KeyPress += Txt_MovilEntrega_KeyPress;

                    tb_Monto.KeyUp += KeyDownUpMonto;
                    tb_Monto.KeyDown += KeyDownUpMonto;
                    tb_Monto.Enter += FocusEnMonto;
                    tb_Monto.Leave += SalirDeFocusEnMonto;
                    tb_Monto.Text = "0";
                    tb_Monto.Name = "tb_Monto";
                    tb_Monto.MaxLength = 20;
                    flp_FormaPago.Controls.Add(tb_Monto);

                    Label lbl_MontoCeros = new Label
                    {
                        Text = ".00",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(40, 15),
                        Margin = new Padding(3, 9, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_MontoCeros);

                    Label lbl_Referencia = new Label
                    {
                        Text = "Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Bold),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(70, 15),
                        Margin = new Padding(3, 5, 3, 3)
                    };
                    flp_FormaPago.Controls.Add(lbl_Referencia);

                    TextBox tb_Referencia = new TextBox
                    {
                        Name = "tb_Referencia",
                        Font = new Font(new FontFamily("Times New Roman"), 9.75f, FontStyle.Regular),
                        Tag = FormasPagoTag.ToString(),
                        Size = new Size(150, 21),
                        MaxLength = 100
                    };
                    flp_FormaPago.Controls.Add(tb_Referencia);

                    Button btn_removeFormaPago = new Button
                    {
                        FlatStyle = FlatStyle.Flat
                    };
                    btn_removeFormaPago.FlatAppearance.BorderColor = Color.Black;
                    btn_removeFormaPago.BackColor = Color.LightGray;
                    btn_removeFormaPago.Text = "Remover";
                    btn_removeFormaPago.Tag = FormasPagoTag.ToString();
                    btn_removeFormaPago.Cursor = Cursors.Hand;
                    btn_removeFormaPago.Click += RemoveSelectedFormaPago;
                    flp_FormaPago.Controls.Add(btn_removeFormaPago);

                    FormasPagoTag = FormasPagoTag + 1;
                    flp_FormaPago.VerticalScroll.Value = flp_FormaPago.VerticalScroll.Maximum;
                    flp_FormaPago.PerformLayout();

                    EfectivoSeleccionado();
                    if (cb_FormaPago.Text == "EFECTIVO")
                    {
                        Tb_efectivoRecibido.Text = "0";
                        lbl_cambio.Text = "Cambio: $ 0.00";
                    }
                }
                else
                {
                    MessageBox.Show("Solo se permiten 5 formas de pago distintas", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
        }

        /// <summary>
        ///     Remueve la linea de forma pago seleccionada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void RemoveSelectedFormaPago(object sender, EventArgs e)
        {
            Button btnsender = (Button)sender;
            if (FormasPagoAgregadas.Count > 1)
            {
                for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
                    if (flp_FormaPago.Controls[i].Tag.ToString() == btnsender.Tag.ToString())
                    {
                        if (flp_FormaPago.Controls[i] is ComboBox)
                        {
                            LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                            FormasPagoAgregadas.Remove(flp_FormaPago.Controls[i].Text);
                            //FormasPagoAgregadas.RemoveAt(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                        }

                        flp_FormaPago.Controls.RemoveAt(i);
                        AnticipoMontoTotal();
                    }

                EfectivoSeleccionado();
            }
            else
            {
                MessageBox.Show("Debe existir al menos una forma de pago", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Añade una nueva forma de pago
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void Btn_agregarFormaPago_Click(object sender, EventArgs e)
        {
            if (!CerosEnFormasDePago())
            {
                if (montoTotal == saldoRestante)
                    MessageBox.Show("El monto total ya es igual al total del movimiento", "Informacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    AgregarFormaPago();
            }
            else
            {
                MessageBox.Show("No pueden quedar formas de pago en 0", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        /// <summary>
        ///     Keyup para montos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 26/10/17
        private void KeyDownUpMonto(object sender, KeyEventArgs e)
        {
            TextBox tb_monto = (TextBox)sender;
            if (tb_monto.Text.Length > 0 && tb_monto.Text.Substring(0, 1) == "-")
                tb_monto.Text = tb_monto.Text.Substring(1, tb_monto.Text.Length - 1);
            double totalAntes = montoTotal;
            AnticipoMontoTotal();
            double Montototal = montoTotal;
            if (Montototal > saldoRestante)
            {
                Montototal = Montototal - Convert.ToDouble(tb_monto.Text);
                double MontoRestante = saldoRestante - Montototal;
                tb_monto.Text = MontoRestante.ToString();
                tb_monto.SelectionStart = tb_monto.Text.Length + 1;
            }

            if (tb_monto.Text.Length > 1 && tb_monto.Text.Substring(0, 1) == "0")
            {
                tb_monto.Text = tb_monto.Text.Substring(1, tb_monto.Text.Length - 1);
                tb_monto.SelectionStart = tb_monto.Text.Length + 1;
            }

            AnticipoMontoTotal();

            double montoEfectivo = 0;
            if (tb_monto.Text != string.Empty) montoEfectivo = Convert.ToDouble(tb_monto.Text);
            ObtenerCambioMinimo(tb_monto.Tag.ToString(), montoEfectivo);
        }

        /// <summary>
        ///     Focus de monto
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/11/17
        private void FocusEnMonto(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox tbsender = (TextBox)sender;
                if (tbsender.Text == "0") tbsender.Text = "";
            }
        }

        /// <summary>
        ///     Salir de focus de monto
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/11/17
        private void SalirDeFocusEnMonto(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                KeyDownUpMonto(sender, null);
                TextBox tbsender = (TextBox)sender;
                if (tbsender.Text == "") tbsender.Text = "0";
                ObtenerCambioMinimo(tbsender.Tag.ToString(), Convert.ToDouble(tbsender.Text));
            }
        }

        /// <summary>
        ///     Obtiene la minima cantidad que se podra poner en el textbox de recibido
        /// </summary>
        /// <param name="CurrentTag">string</param>
        /// <param name="LimiteRecibido">double</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void ObtenerCambioMinimo(string CurrentTag, double LimiteRecibido)
        {
            RecibidoMinimo = 0;
            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl.Tag.ToString() == CurrentTag && ctrl is ComboBox)
                {
                    ComboBox cboxFormaPago = (ComboBox)ctrl;
                    if (cboxFormaPago.Text == "EFECTIVO")
                    {
                        RecibidoMinimo = LimiteRecibido;
                        BanderaRecibidoMinimo = LimiteRecibido;
                        //Tb_efectivoRecibido.Text = "0";
                        lbl_cambio.Text = "Cambio: " +
                                          (Convert.ToDouble(Tb_efectivoRecibido.Text) - BanderaRecibidoMinimo).ToString(
                                              "C");
                    }
                }
        }

        /// <summary>
        ///     monto total de anticipos
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void AnticipoMontoTotal()
        {
            montoTotal = 0;
            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl is TextBox)
                {
                    TextBox txt_monto = (TextBox)ctrl;
                    if (txt_monto.Name == "tb_Monto")
                        if (txt_monto.Text != string.Empty)
                            montoTotal = montoTotal + Convert.ToDouble(txt_monto.Text);
                }

            txt_anticipototal.Text = montoTotal.ToString("C");
        }

        /// <summary>
        ///     Checar si hay ceros en formas de pago
        /// </summary>
        /// <returns>bool</returns>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private bool CerosEnFormasDePago()
        {
            bool MontoConCero = false;

            foreach (Control ctrl in flp_FormaPago.Controls)
                if (ctrl is TextBox)
                {
                    TextBox txt_monto = (TextBox)ctrl;
                    if (txt_monto.Name == "tb_Monto")
                        if (txt_monto.Text != string.Empty && (txt_monto.Text == "0" || txt_monto.Text.Trim() == ""))
                            return true;
                }

            return MontoConCero;
        }

        /// <summary>
        ///     Click en forma de pago para guardar el estatus anterior
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void FormaPagoClick(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] = cbFormaPago.Text;
        }

        /// <summary>
        ///     Double click de gridview de articulos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/09/17
        private void dgv_detalle_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex == (int)Enums.gvDetallesArticulos.Series)
            {
                if (VentasSeleccionadas[PaginadoActual].Mov != "Analisis Credito")
                {
                    //if (
                    //    ClaseEstatica.Usuario.Grupo == "VENTAS PISO" ||
                    //    ClaseEstatica.Usuario.Grupo == "CONTABILIDAD" ||
                    //    ClaseEstatica.Usuario.Grupo == "FACTURACION"
                    //   )
                    //{
                    if (dgv_detalle.SelectedRows.Count > 0)
                    {
                        DM0312_DetalleSerieArticulo.ArticuloSeleccionado = dgv_detalle
                            .SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionArticulo].Value
                            .ToString();
                        DM0312_DetalleSerieArticulo.IDVenta = VentasSeleccionadas[PaginadoActual].ID;
                        DM0312_DetalleSerieArticulo.AlmacenArticulo = VentasSeleccionadas[PaginadoActual].Almacen;
                        DM0312_DetalleSerieArticulo.SucursalOrigen = ClaseEstatica.Usuario.sucursal;
                        if (dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionCantidad]
                                .Value.ToString() != string.Empty)
                            DM0312_DetalleSerieArticulo.cantidadArticulo = Convert.ToInt32(dgv_detalle
                                .SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionCantidad].Value
                                .ToString());
                        ClaseEstatica.SeriesArticulos = ControladorSerie.ObtenerSeriesArticulos(
                            DM0312_DetalleSerieArticulo.IDVenta, DM0312_DetalleSerieArticulo.ArticuloSeleccionado);

                        if (VentasSeleccionadas[PaginadoActual].Estatus.ToUpper() == "CONCLUIDO" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Devolucion" ||
                            VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Unicaja")
                            DM0312_DetalleSerieArticulo.MovConcluido = true;
                        else
                            DM0312_DetalleSerieArticulo.MovConcluido = false;

                        bool ArticuloTipoSerie = false;
                        MDetalleVenta detalle = ListaDetallesSeleccionados.FirstOrDefault(x =>
                            x.Articulo == DM0312_DetalleSerieArticulo.ArticuloSeleccionado);
                        if (detalle != null)
                        {
                            if (detalle.RenglonID != 0)
                            {
                                DM0312_DetalleSerieArticulo.DescripcionArticulo = detalle.Descripcion;
                                DM0312_DetalleSerieArticulo.RenglonID = detalle.RenglonID;
                                if (detalle.Tipo == "Serie") ArticuloTipoSerie = true;
                            }
                            else
                            {
                                MessageBox.Show("No existe renglon ID", "Informacion", MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                            }
                        }

                        if (ArticuloTipoSerie)
                        {
                            bool SucursalIgual = false;

                            //validaciones para checar si la sucursal es diferente
                            if (
                                (
                                    VentasSeleccionadas[PaginadoActual].SucursalDestino != 0
                                    &&
                                    VentasSeleccionadas[PaginadoActual].SucursalDestino ==
                                    ClaseEstatica.Usuario.sucursal
                                )
                                ||
                                (
                                    VentasSeleccionadas[PaginadoActual].SucursalDestino == 0
                                    &&
                                    VentasSeleccionadas[PaginadoActual].Sucursal ==
                                    ClaseEstatica.Usuario.sucursal
                                )
                            )
                                SucursalIgual = true;

                            if (SucursalIgual)
                            {
                                CDetalleVenta.PaginadoActual = PaginadoActual;

                                DM0312_DetalleSerieArticulo serie = new DM0312_DetalleSerieArticulo();
                                TopMost = false;

                                List<MSerieArticulos> Catalogos = new List<MSerieArticulos>();
                                CSerieArticulos ControladorSerieArticulos = new CSerieArticulos();

                                Catalogos = ControladorSerieArticulos.ObtenerCatalogos(
                                    DM0312_DetalleSerieArticulo.IDVenta,
                                    DM0312_DetalleSerieArticulo.ArticuloSeleccionado,
                                    DM0312_DetalleSerieArticulo.AlmacenArticulo,
                                    DM0312_DetalleSerieArticulo.SucursalOrigen, string.Empty);
                                if (Catalogos.Count > 0)
                                {
                                    serie.ShowDialog();
                                    List<MSerieArticulos> TempSerie =
                                        ControladorSerie.ObtenerSeriesArticulos(VentasSeleccionadas[PaginadoActual].ID,
                                            DM0312_DetalleSerieArticulo.ArticuloSeleccionado);
                                    ArticulosDetalleVenta DetalleArticulo = DatosDetalles.FirstOrDefault(x =>
                                        x.Articulo == DM0312_DetalleSerieArticulo.ArticuloSeleccionado);
                                    DetalleArticulo.Serie = "";
                                    if (TempSerie.Count > 1)
                                        DetalleArticulo.Serie = "...";
                                    else if (TempSerie.Count == 1) DetalleArticulo.Serie = TempSerie[0].Serie;

                                    if (TempSerie.Count == 0)
                                    {
                                        dgv_detalle.CancelEdit();
                                        dgv_detalle.EndEdit();
                                    }

                                    //dgv_detalle.DataSource = null;
                                    dgv_detalle.DataSource = DatosDetalles;
                                    ConfiguracionGridviewDetalle();
                                }
                                else
                                {
                                    MessageBox.Show("No hay series disponibles", "Informacion", MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Solo se pueden asignar series si la sucursal es la misma",
                                    "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show("No hay información para mostrar", "Informacion", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No hay información para mostrar", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("La serie no puede ser editada ni añadida por este usuario");
                    //}
                }
                else
                {
                    MessageBox.Show("La serie no puede ser editada ni añadida en analisis credito", "Informacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        /// <summary>
        ///     Guarda el valor de la celda (valido solo para precios y costos)
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellCancelEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/11/17
        private void dgv_detalle_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            PrecioCostoAnterior = dgv_detalle[e.ColumnIndex, e.RowIndex].Value.ToString().Replace("$", "").Trim();
            dgv_detalle[e.ColumnIndex, e.RowIndex].Value = PrecioCostoAnterior;
        }

        /// <summary>
        ///     Valida y guarda nuevo valor de celda(valido solo para precios y costos)
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/11/17
        private void dgv_detalle_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            BeginInvoke(new MethodInvoker(() =>
            {
                if (e.ColumnIndex == (int)Enums.gvDetallesArticulos.CantidadAAfectar)
                {
                    ChecarCantidadesPendientes(e.ColumnIndex, e.RowIndex,
                        dgv_detalle[e.ColumnIndex, e.RowIndex].Value.ToString().Trim(),
                        dgv_detalle[(int)Enums.gvDetallesArticulos.CantidadPendiente, e.RowIndex].Value.ToString()
                            .Trim());
                }
                else
                {
                    if (PrecioCostoAnterior != dgv_detalle[e.ColumnIndex, e.RowIndex].Value.ToString().Trim())
                    {
                        bool PrecioValido = false;
                        double NuevoPrecio = 0;
                        if (double.TryParse(dgv_detalle[e.ColumnIndex, e.RowIndex].Value.ToString(), out NuevoPrecio))
                            PrecioValido = true;
                        if (PrecioValido)
                        {
                            bool EsCosto = false;
                            double PrecioCostoTotal = 0;
                            double? ImporteTotal = null;
                            double? Impuestos = null;
                            if (e.ColumnIndex == (int)Enums.gvDetallesArticulos.Costo) EsCosto = true;
                            PrecioCostoTotal = TotalPrecioCosto(EsCosto);
                            if (EsCosto)
                            {
                                string CadenaNuevoCosto = "$ " + dgv_detalle[e.ColumnIndex, e.RowIndex].Value;
                                DatosDetalles[e.RowIndex].Costo = CadenaNuevoCosto;
                                DatosDetallesSinOrdenar
                                        .SingleOrDefault(x => x.Articulo == DatosDetalles[e.RowIndex].Articulo).Costo =
                                    CadenaNuevoCosto;
                            }
                            else
                            {
                                ImporteTotal = PrecioCostoTotal / 1.16;
                                Impuestos = PrecioCostoTotal - ImporteTotal;
                                string CadenaNuevoPrecio = dgv_detalle[e.ColumnIndex, e.RowIndex].Value.ToString();
                                string CadenaNuevoImporte =
                                    (Convert.ToDouble(DatosDetalles[e.RowIndex].Precio.Replace("$", "").Trim()) *
                                     Convert.ToDouble(DatosDetalles[e.RowIndex].Cantidad)).ToString("C");
                                DatosDetalles[e.RowIndex].Precio = CadenaNuevoPrecio;
                                DatosDetalles[e.RowIndex].Importe = CadenaNuevoImporte;
                                DatosDetallesSinOrdenar
                                        .SingleOrDefault(x => x.Articulo == DatosDetalles[e.RowIndex].Articulo).Precio =
                                    CadenaNuevoPrecio;
                                DatosDetallesSinOrdenar
                                        .SingleOrDefault(x => x.Articulo == DatosDetalles[e.RowIndex].Articulo)
                                        .Importe =
                                    CadenaNuevoImporte;
                                txt_SubTotal.Text = Convert.ToDouble(ImporteTotal).ToString("C");
                                txt_Impuestos.Text = Convert.ToDouble(Impuestos).ToString("C");
                                txt_Total.Text = CadenaNuevoImporte;
                            }

                            CDetalleVenta.ActualizaCostoPrecio(VentasSeleccionadas[PaginadoActual].ID, NuevoPrecio,
                                PrecioCostoTotal, DatosDetalles[e.RowIndex].Articulo, EsCosto, ImporteTotal, Impuestos);
                            //dgv_detalle[e.ColumnIndex, e.RowIndex].Value = "$ " + dgv_detalle[e.ColumnIndex, e.RowIndex].Value;
                            dgv_detalle.DataSource = null;
                            dgv_detalle.DataSource = DatosDetalles;
                            ConfiguracionGridviewDetalle();
                            DM0312_ExploradorVentas ExploradorVentas =
                                (DM0312_ExploradorVentas)Application.OpenForms["DM0312_ExploradorVentas"];
                            ExploradorVentas.TableroMovimientos();
                        }
                        else
                        {
                            MessageBox.Show("Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            dgv_detalle[e.ColumnIndex, e.RowIndex].Value = "$ " + PrecioCostoAnterior;
                        }
                    }
                    else
                    {
                        dgv_detalle[e.ColumnIndex, e.RowIndex].Value =
                            "$ " + dgv_detalle[e.ColumnIndex, e.RowIndex].Value;
                    }
                }
            }));
        }


        private void ChecarCantidadesPendientes(int columnaIndex, int rowIndex, string CellValueCantidadAfectar,
            string CellValueCantidadPendiente)
        {
            bool CantidadCorrecta = false;
            int NuevaCantidad = 0;
            int CantidadPendiente = 0;
            if (int.TryParse(CellValueCantidadAfectar, out NuevaCantidad)) CantidadCorrecta = true;
            if (int.TryParse(CellValueCantidadPendiente, out CantidadPendiente)) CantidadCorrecta = true;
            if (CantidadCorrecta)
            {
                if (CantidadPendiente >= NuevaCantidad)
                {
                    DatosDetalles[rowIndex].CantidadAAfectar = NuevaCantidad;
                    DatosDetallesSinOrdenar.SingleOrDefault(x => x.Articulo == DatosDetalles[rowIndex].Articulo)
                        .CantidadAAfectar = NuevaCantidad;
                    ListaDetallesSeleccionados.SingleOrDefault(x => x.Articulo == DatosDetalles[rowIndex].Articulo)
                        .CantidadAAfectar = NuevaCantidad;
                    if (VerCantidadPendiente)
                        CDetalleVenta.InsertCantidadAAfectar(VentasSeleccionadas[PaginadoActual].ID, DatosDetalles);
                }
                else
                {
                    MessageBox.Show("Cantidad a afectar no puede ser mayor a cantidad pendiente", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dgv_detalle[columnaIndex, rowIndex].Value = PrecioCostoAnterior;
                }
            }
            else
            {
                MessageBox.Show("Formato incorrecto", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dgv_detalle[columnaIndex, rowIndex].Value = PrecioCostoAnterior;
            }
        }


        /// <summary>
        ///     Obtener total de precio o costo
        /// </summary>
        /// <param name="EsCosto">bool</param>
        /// <returns>double</returns>
        /// Developer: Dan Palacios
        /// Date: 27/11/17
        private double TotalPrecioCosto(bool EsCosto)
        {
            double TotalPrecioCosto = 0;
            foreach (DataGridViewRow dgvRow in dgv_detalle.Rows)
                if (EsCosto)
                    TotalPrecioCosto += Convert.ToDouble(dgvRow.Cells[(int)Enums.gvDetallesArticulos.Costo].Value
                        .ToString().Replace("$", "").Trim());
                else
                    TotalPrecioCosto += Convert.ToDouble(dgvRow.Cells[(int)Enums.gvDetallesArticulos.Precio].Value
                        .ToString().Replace("$", "").Trim());
            return TotalPrecioCosto;
        }

        /// <summary>
        ///     combo index changed
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/10/17
        private void ComboDropped(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            if (!cbFormaPago.DroppedDown)
                cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
        }

        /// <summary>
        ///     Evento cuando el textbox de recibido pierde focus
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_Leave(object sender, EventArgs e)
        {
            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text;
            if (Convert.ToDouble(Tb_efectivoRecibido.Text) < RecibidoMinimo)
            {
                Tb_efectivoRecibido.Text = "0";
                Tb_efectivoRecibido.SelectionStart = Tb_efectivoRecibido.Text.Length + 1;
            }

            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text != "" ? Tb_efectivoRecibido.Text : "0";
            lbl_cambio.Text = "Cambio: " +
                              (Convert.ToDouble(Tb_efectivoRecibido.Text) - BanderaRecibidoMinimo).ToString("C");
        }

        /// <summary>
        ///     Focus de textbox recbido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_Enter(object sender, EventArgs e)
        {
            Tb_efectivoRecibido.Text = Tb_efectivoRecibido.Text != "0" ? Tb_efectivoRecibido.Text : "";
        }

        /// <summary>
        ///     key down de textbox de recibido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                double Total = Convert.ToDouble(Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text) -
                               BanderaRecibidoMinimo;
                Total = Total < 0 ? 0 : Total;
                lbl_cambio.Text = "Cambio: " + Total.ToString("C");
            }
            catch
            {
            }
        }

        /// <summary>
        ///     key press de textbox de recibido
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void Tb_efectivoRecibido_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                double Total = Convert.ToDouble(Tb_efectivoRecibido.Text == "" ? "0" : Tb_efectivoRecibido.Text) -
                               BanderaRecibidoMinimo;
                Total = Total < 0 ? 0 : Total;
                lbl_cambio.Text = "Cambio: " + Total.ToString("C");
            }
            catch
            {
            }
        }

        /// <summary>
        ///     Boton para ejecutar SHM
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        private void btn_SHM_Click(object sender, EventArgs e)
        {
            CDetalleVenta.EjecutaSHM(VentasSeleccionadas, MovEsValera);
        }

        /// <summary>
        ///     Ordenamiento datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        private void dgv_datosEntrega_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 0)
                return;
            List<object> TempObjects = new List<object>(BitacoraEntregas);
            funciones.OrderGridview(dgv_datosEntrega, e.ColumnIndex, ref TempObjects,
                BitacoraEntregas.GetType().GetGenericArguments().Single());
            BitacoraEntregas = TempObjects.OfType<DatosEntrega>().ToList();
            Dgv_datosEntrega_CellClick(null, null);
        }

        /// <summary>
        ///     Checa si el almacen seleccionado existe
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/01/18
        private void cb_Almacen_Leave(object sender, EventArgs e)
        {
            if (cb_Almacen.Text != VentasSeleccionadas[PaginadoActual].Almacen)
            {
                if (VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Unicaja" &&
                    VentasSeleccionadas[PaginadoActual].Mov != "Sol Dev Mayoreo" &&
                    VentasSeleccionadas[PaginadoActual].Mov != "Solicitud Devolucion" &&
                    VentasSeleccionadas[PaginadoActual].MovTipo != "VTAS.D")
                {
                    AlmacenesDisponibles = ControladorAlmacenes.ObtenerAlmacenes();
                    MAlmacen NombreAlmacenActual =
                        AlmacenesDisponibles.SingleOrDefault(x => x.Clave == cb_Almacen.Text);
                    if (NombreAlmacenActual != null)
                    {
                        DM0312_DetalleCambiarAlmacen.IDVenta = Convert.ToInt32(lbl_ID.Text);
                        DM0312_DetalleCambiarAlmacen.AlmacenActual = cb_Almacen.Text;
                        CAlmacenes CambiarAlmacen = new CAlmacenes();
                        CambiarAlmacen.ActualizarAlmacen(VentasSeleccionadas[PaginadoActual].Estatus);
                        VentasSeleccionadas[PaginadoActual].Almacen = DM0312_DetalleCambiarAlmacen.AlmacenActual;
                        VentasSeleccionadas[PaginadoActual].SucursalDestino = NombreAlmacenActual.Sucursal;
                    }
                    else
                    {
                        MessageBox.Show("No existe el almacen", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cb_Almacen.Text = VentasSeleccionadas[PaginadoActual].Almacen;
                    }
                }
                else
                {
                    cb_Almacen.Text = VentasSeleccionadas[PaginadoActual].Almacen;
                }
            }
        }

        /// <summary>
        ///     Max lenght gridview detalles
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewEditingControlShowingEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 12/01/18
        private void dgv_detalle_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is TextBox)
            {
                TextBox tb_Ctrl = (TextBox)e.Control;
                tb_Ctrl.MaxLength = 10;
            }
        }

        /// <summary>
        ///     Abre la informacion de datos entrega
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 03/11/17
        private void Btn_datosEntrega_Click(object sender, EventArgs e)
        {
            flpanel.Height = gpbxHeightO;
            txt_direccionEntrega.Text = string.Empty;
            cb_colonia.Text = string.Empty;
            txt_CPEntrega.Text = string.Empty;
            txt_PoblacionEntrega.Text = string.Empty;
            txt_EstadoEntrega.Text = string.Empty;
            txt_EntreCallesEntrega.Text = string.Empty;
            txt_TelParticularEntrega.Text = string.Empty;
            txt_MovilEntrega.Text = string.Empty;
            txt_ReferenciaEntrega.Text = string.Empty;
            txt_IdCommerceL.Visible = false;
            txt_Correo_Linea.Visible = false;
            txt_Nombre_Linea.Visible = false;
            txt_TelefonoLinea.Visible = false;
            txt_IdEcommerce.Visible = false;
            txt_NombreLinea.Visible = false;
            lbl_correoLinea.Visible = false;
            lbl_TelefonoLinea.Visible = false;


            string IDSeleccionado = string.Empty;
            CDetalleVenta.PaginadoActual = PaginadoActual;
            BitacoraEntregas = CDetalleVenta.ObtenerBitacoraEntregas(txt_Cliente.Text, ref IDSeleccionado,
                VentasSeleccionadas[PaginadoActual].ID.ToString());
            int? BitacoraSeleccionada = CDetalleVenta.ObtenerBitacoraSeleccionada(IDSeleccionado, BitacoraEntregas);

            if (!gbx_DatosEntrega.Visible)
            {
                gbx_DatosEntrega.Visible = true;

                gb_CamposEntrega.Visible = false;

                flpanel.Height = gpbxHeightO - HeightFixer();
                gbx_DatosEntrega.Height = 150;
                if (BitacoraEntregas.Count > 0)
                    if (BitacoraSeleccionada != null)
                    {
                        int bitSel = Convert.ToInt32(BitacoraSeleccionada);
                        txt_direccionEntrega.Text = BitacoraEntregas[bitSel].Direccion;
                        cb_colonia.Text = BitacoraEntregas[bitSel].Colonia;
                        txt_CPEntrega.Text = BitacoraEntregas[bitSel].CP;
                        txt_PoblacionEntrega.Text = BitacoraEntregas[bitSel].Poblacion;
                        txt_EstadoEntrega.Text = BitacoraEntregas[bitSel].Estado;
                        txt_EntreCallesEntrega.Text = BitacoraEntregas[bitSel].EntreCalles;
                        txt_TelParticularEntrega.Text = BitacoraEntregas[bitSel].TelefonoParticular;
                        txt_MovilEntrega.Text = BitacoraEntregas[bitSel].TelefonoMovil;
                        txt_ReferenciaEntrega.Text = BitacoraEntregas[bitSel].Referencia;
                        txt_numE.Text = BitacoraEntregas[bitSel].NumExt;
                        txt_NumI.Text = BitacoraEntregas[bitSel].NumInt;
                        gb_CamposEntrega.Visible = true;
                        gbx_DatosEntrega.Height = 354;
                        flpanel.Height = gpbxHeightO;
                    }

                AutoScrollPosition = new Point(0, 820);
                panelmenu.Location = new Point(2, 1);
                if (BitacoraEntregas.Count == 0) Btn_nuevo_Click(null, null);

                if (VentasSeleccionadas[PaginadoActual].Suc == 41 || VentasSeleccionadas[PaginadoActual].Suc == 90)
                {
                    List<string> datosLinea = new List<string>();
                    txt_IdCommerceL.Visible = true;
                    txt_Correo_Linea.Visible = true;
                    txt_Nombre_Linea.Visible = true;
                    txt_TelefonoLinea.Visible = true;
                    txt_IdEcommerce.Visible = true;
                    txt_NombreLinea.Visible = true;
                    lbl_correoLinea.Visible = true;
                    lbl_TelefonoLinea.Visible = true;

                    txt_IdCommerceL.Enabled = false;
                    txt_Correo_Linea.Enabled = false;
                    txt_Nombre_Linea.Enabled = false;
                    txt_TelefonoLinea.Enabled = false;


                    datosLinea = CDetalleVenta.DatosEntregaLinea(VentasSeleccionadas[PaginadoActual].IDEcommerce);
                    if (datosLinea.Count > 0)
                    {
                        txt_IdCommerceL.Text = datosLinea[0];
                        txt_Correo_Linea.Text = datosLinea[2];
                        txt_Nombre_Linea.Text = datosLinea[1];
                        txt_TelefonoLinea.Text = datosLinea[3];
                    }
                }
            }
            else
            {
                int camposEntregaVisibleClosed = 0;
                if (gbx_DatosEntrega.Visible) camposEntregaVisibleClosed = 80;
                gbx_DatosEntrega.Visible = false;
                flpanel.Height = gpbxHeightC + camposEntregaVisibleClosed;
                lbl_Cliente.Focus();
                panelmenu.Location = new Point(2, 1);
            }

            if (dgv_datosEntrega.Columns.Count == 0)
            {
                DataGridViewCheckBoxColumn c = new DataGridViewCheckBoxColumn
                {
                    Name = ""
                };
                dgv_datosEntrega.Columns.Add(c);
            }

            dgv_datosEntrega.DataSource = null;
            dgv_datosEntrega.DataSource = BitacoraEntregas;
            CDetalleVenta.PaginadoActual = PaginadoActual;
            CDetalleVenta.FillDataGridDatosEntrega(BitacoraEntregas, ref dgv_datosEntrega, BitacoraSeleccionada);
            btn_nuevaEntrega.Enabled = true;


            if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
            {
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Pedido"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Factura"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                {
                    if (dgv_datosEntrega.Rows.Count == 0)
                    {
                        int camposEntregaVisibleClosed = 0;
                        if (gbx_DatosEntrega.Visible) camposEntregaVisibleClosed = 80;
                        gbx_DatosEntrega.Visible = false;
                        flpanel.Height = gpbxHeightC + camposEntregaVisibleClosed;
                        lbl_Cliente.Focus();
                        panelmenu.Location = new Point(2, 1);
                        MessageBox.Show(
                            "Al movimiento " + VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                            VentasSeleccionadas[PaginadoActual].MovId + " no se le asigno un dato de entrega",
                            "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        btn_nuevaEntrega.Visible = false;
                        btn_guardar.Visible = false;
                        dgv_datosEntrega.Enabled = false;
                        txt_direccionEntrega.Enabled = false;
                    }
                }
                else
                {
                    btn_nuevaEntrega.Visible = true;
                    btn_guardar.Visible = true;
                    dgv_datosEntrega.Enabled = true;
                }
            }
        }

        /// <summary>
        ///     Checa si el metodo de pago efectivo esta seleccionado en un combobox
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 01/12/17
        private void EfectivoSeleccionado()
        {
            lbl_recibido.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            Tb_efectivoRecibido.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            lbl_rec_ceros.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
            lbl_cambio.Visible = FormasPagoAgregadas.Contains("EFECTIVO") ? true : false;
        }

        private void dgv_detalle_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            double temp = 0;
            if (e.ColumnIndex == 4 || e.ColumnIndex == 8)
            {
                if (e.FormattedValue.ToString().Trim() == "")
                {
                    e.Cancel = true;
                    dgv_detalle.CancelEdit();
                    dgv_detalle[e.ColumnIndex, e.RowIndex].Value = PrecioCostoAnterior;
                }
                else if (double.TryParse(e.FormattedValue.ToString(), out temp))
                {
                    if (Convert.ToDouble(e.FormattedValue) % 1 != 0)
                    {
                        MessageBox.Show("No se aceptan numeros decimales", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        e.Cancel = true;
                        dgv_detalle.CancelEdit();
                        dgv_detalle[e.ColumnIndex, e.RowIndex].Value = PrecioCostoAnterior;
                    }
                }
            }
        }

        /// <summary>
        ///     Cambiar la forma de pago en el evento del combobox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 27/10/17
        private void CambiarFormaPago(object sender, EventArgs e)
        {
            ComboBox cbFormaPago = (ComboBox)sender;
            if (cbFormaPago.DroppedDown)
            {
                cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
                return;
            }

            if (FormasPagoAgregadas.Contains(cbFormaPago.Text))
            {
                if (LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] != cbFormaPago.Text)
                {
                    MessageBox.Show("No se pueden duplicar las formas de pago", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    cbFormaPago.Text = LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())];
                }
            }
            else
            {
                FormasPagoAgregadas.Add(cbFormaPago.Text);
                FormasPagoAgregadas.Remove(LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())]);
                LastFormaPagoSelected[Convert.ToInt32(cbFormaPago.Tag.ToString())] = cbFormaPago.Text;
            }

            EfectivoSeleccionado();
            if (cbFormaPago.Text == "EFECTIVO")
                foreach (Control ctrl in flp_FormaPago.Controls)
                    if (ctrl.Tag.ToString() == cbFormaPago.Tag.ToString() && ctrl is TextBox && ctrl.Name == "tb_Monto")
                    {
                        TextBox tb_Monto = (TextBox)ctrl;
                        ObtenerCambioMinimo(cbFormaPago.Tag.ToString(), Convert.ToDouble(tb_Monto.Text));
                        break;
                    }
        }

        /// <summary>
        ///     remover formas de pago
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 30/10/17
        private void RemoverAnticipos()
        {
            string comboboxSelected = string.Empty;
            for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
                if (FormasPagoAgregadas.Count > 1)
                {
                    if (flp_FormaPago.Controls[i] is ComboBox)
                    {
                        ComboBox cb_monto = (ComboBox)flp_FormaPago.Controls[i];
                        comboboxSelected = cb_monto.Text;
                    }

                    if (flp_FormaPago.Controls[i] is Label && flp_FormaPago.Controls[i].Name == "lbl_formaPago")
                    {
                        LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                        FormasPagoAgregadas.Remove(comboboxSelected);
                    }

                    flp_FormaPago.Controls.RemoveAt(i);
                }
                else
                {
                    if (flp_FormaPago.Controls[i] is TextBox)
                    {
                        TextBox txt_monto = (TextBox)flp_FormaPago.Controls[i];
                        if (txt_monto.Name == "tb_Monto") txt_monto.Text = "0";
                    }
                }

            ListaAnticipos.Clear();
            AnticipoMontoTotal();
        }


        /// <summary>
        ///     Guardado de anticipos
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 08/11/17
        private async void Btn_guardarAnticipos_Click(object sender, EventArgs e)
        {
            //-Datalogic
            bool bAnticipo = false;
            if (ClaseEstatica.iRecarga == 1)
            {
                if (int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 2 ||
                    int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 6 ||
                    int.Parse(VentasSeleccionadas[PaginadoActual].EnviarA) == 11)
                {
                    foreach (Control ctrl in flp_FormaPago.Controls)
                        if (ctrl is TextBox)
                        {
                            TextBox txt_Anticipo = (TextBox)ctrl;
                            if (txt_Anticipo.Name == "tb_Monto")
                            {
                                double dTotal = double.Parse(txt_Total.Text.Remove(0, 1));
                                double dAnticipo = double.Parse(txt_Anticipo.Text);
                                if (dTotal != dAnticipo)
                                {
                                    MessageBox.Show("El anticipo debe ser igual al total", "Punto De Venta",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    bAnticipo = false;
                                }
                                else
                                {
                                    btn_Situaciones.Enabled = true;
                                    bAnticipo = true;
                                }
                            }
                        }
                }
                else
                {
                    btn_Situaciones.Enabled = true;
                    bAnticipo = true;
                }
            }
            else
            {
                btn_Situaciones.Enabled = true;
                bAnticipo = true;
            }

            if (bAnticipo)
            {
                if (montoTotal != 0)
                {
                    MAnticipos NuevoAnticipo = new MAnticipos();
                    foreach (Control ctrl in flp_FormaPago.Controls)
                        if (ctrl is ComboBox)
                        {
                            ComboBox cb_FormaPago = (ComboBox)ctrl;
                            NuevoAnticipo = new MAnticipos
                            {
                                FormaPago = cb_FormaPago.Text
                            };
                        }
                        else if (ctrl is TextBox)
                        {
                            TextBox txt_Anticipo = (TextBox)ctrl;
                            if (txt_Anticipo.Name == "tb_Monto")
                            {
                                if (txt_Anticipo.Text != string.Empty) NuevoAnticipo.Importe = txt_Anticipo.Text;
                            }
                            else if (txt_Anticipo.Name == "tb_Referencia")
                            {
                                if (txt_Anticipo.Text != string.Empty) NuevoAnticipo.Referencia = txt_Anticipo.Text;
                                ListaAnticipos.Add(NuevoAnticipo);
                            }
                        }

                    string Referencia1 = "";
                    string Referencia2 = "";
                    string Referencia3 = "";
                    string Referencia4 = "";
                    string Referencia5 = "";
                    string Monto1 = "";
                    string Monto2 = "";
                    string Monto3 = "";
                    string Monto4 = "";
                    string Monto5 = "";
                    string FormaPago1 = "";
                    string FormaPago2 = "";
                    string FormaPago3 = "";
                    string FormaPago4 = "";
                    string FormaPago5 = "";

                    if (ListaAnticipos.Count > 0)
                        LLenarListaAnticipos(out Referencia1, out Monto1, out FormaPago1, ListaAnticipos[0]);
                    if (ListaAnticipos.Count > 1)
                        LLenarListaAnticipos(out Referencia2, out Monto2, out FormaPago2, ListaAnticipos[1]);
                    if (ListaAnticipos.Count > 2)
                        LLenarListaAnticipos(out Referencia3, out Monto3, out FormaPago3, ListaAnticipos[2]);
                    if (ListaAnticipos.Count > 3)
                        LLenarListaAnticipos(out Referencia4, out Monto4, out FormaPago4, ListaAnticipos[3]);
                    if (ListaAnticipos.Count > 4)
                        LLenarListaAnticipos(out Referencia5, out Monto5, out FormaPago5, ListaAnticipos[4]);

                    DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
                    string ctadinero = controllerExplorador.ValidaCajaUsuario(ClaseEstatica.Usuario.usuario);

                    string MovAnticipo = "Anticipo Contado";
                    string EnviarA = VentasSeleccionadas[PaginadoActual].EnviarA;
                    if ((EnviarA == "3" || EnviarA == "7" || EnviarA == "76" || EnviarA == "36") &&
                        (VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" ||
                         VentasSeleccionadas[PaginadoActual].Mov == "Pedido"))
                        MovAnticipo = "Enganche";
                    else if (VentasSeleccionadas[PaginadoActual].Mov == "Pedido Mayoreo")
                        MovAnticipo = "Anticipo Mayoreo";

                    //-ErrorIVA
                    double iva = controladorV.getIVA();
                    double totalMonto = montoTotal;
                    double MontoSubtotal = totalMonto / (1 + iva);
                    double impuestosMonto = MontoSubtotal * iva;

                    ParametrosAnticipos = new[]
                    {
                        MovAnticipo, ClaseEstatica.Usuario.usuario,
                        VentasSeleccionadas[PaginadoActual].Mov + " " + VentasSeleccionadas[PaginadoActual].MovId,
                        txt_Cliente.Text, txt_Canal.Text,
                        ctadinero, MontoSubtotal.ToString("0.0000"), impuestosMonto.ToString("0.0000"),
                        FormaPago1, FormaPago2, FormaPago3, FormaPago4, FormaPago5,
                        Referencia1, Referencia2, Referencia3, Referencia4, Referencia5,
                        Monto1, Monto2, Monto3, Monto4, Monto5,
                        txt_Agente.Text, ClaseEstatica.Usuario.sucursal.ToString(),
                        ClaseEstatica.Usuario.sucursal.ToString(),
                        pventa.ObtenerCajero(), ClaseEstatica.Usuario.Uen.ToString(),
                        ClaseEstatica.WorkStation.ToString()
                    };

                    if (!frmLoading.Visible)
                    {
                        frmLoading.Show(this);
                        EnableControls(false, this);
                        panelmenu.Location = new Point(2, 1);
                    }

                    int nuevoID = 0;
                    Afectando = true;
                    string RespuestaTransaction =
                        await Task.Run(() => CDetalleVenta.InsertAnticipos(ParametrosAnticipos, out nuevoID));

                    if (frmLoading.Visible)
                    {
                        frmLoading.Hide();
                        EnableControls(true, this);
                    }

                    if (RespuestaTransaction != string.Empty && RespuestaTransaction != "80030")
                    {
                        MessageBox.Show(RespuestaTransaction, "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Anticipos guardados", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        CDetalleVenta.ImprimirAnticipos(nuevoID);
                        RemoverAnticipos();
                        ObtenerInformacionTablero();
                        Controls[0].Select();
                        VerticalScroll.Value = 0;
                        panelmenu.Location = new Point(2, 1);
                        montoTotal = 0;
                        Fajillas(true);
                    }

                    ListaAnticipos.Clear();
                    Afectando = false;
                }
                else
                {
                    MessageBox.Show("No se pueden guardar anticipos en 0", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }


        public void Fajillas(bool waitForExit)
        {
            int alertaSalir = 0;
            try
            {
                Process pTicket = new Process();
                //-CambioPluginsJesus 2019-05-28 se cambio ruta de plugin
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"\AlertaFajillas\AlertaFajillas.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.Usuario.sucursal;
                pTicket.StartInfo.UseShellExecute = false;

                pTicket.Start();

                if (waitForExit) pTicket.WaitForExit();
                //alertaSalir = pTicket.ExitCode;
                //if (alertaSalir == 0 || alertaSalir == 1)
                //{
                //    Fajillas(true);
                //}
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Fajillas", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function: Fajillas, class: DM0312_DetalleVenta.cs");
            }
        }


        /// <summary>
        ///     Asigna valores a las variables de anticipos
        /// </summary>
        /// <param name="Referencia">out string</param>
        /// <param name="Monto">out string</param>
        /// <param name="FormaPago">out string</param>
        /// <param name="Anticipo">MAnticipos</param>
        /// Developer: Dan Palacios
        /// Date: 08/11/17
        private void LLenarListaAnticipos(out string Referencia, out string Monto, out string FormaPago,
            MAnticipos Anticipo)
        {
            Referencia = Anticipo.Referencia;
            Monto = Anticipo.Importe;
            FormaPago = Anticipo.FormaPago;
        }

        /// <summary>
        ///     Obtener anticipos
        /// </summary>
        /// <param name="Parametros">string[]</param>
        /// <param name="CategoriaEnviarA">string</param>
        /// Developer: Dan Palacios
        /// Date: 10/11/17
        private async void ObtenerAnticipos(string[] Parametros, string CategoriaEnviarA)
        {
            Detalles = await Task.Run(() => CDetalleVenta.ObtenerDetallesVenta(Parametros, ref CategoriaEnviarA));

            double Enganche_Anticipo = 0;
            if (Detalles[(int)Enums.DetallesVenta.Enganche] != null &&
                Detalles[(int)Enums.DetallesVenta.Enganche] != string.Empty)
                Enganche_Anticipo = Convert.ToDouble(Detalles[(int)Enums.DetallesVenta.Enganche]);
            txt_Enganche.Text = Enganche_Anticipo.ToString("C");
            if (txt_Total.Text != string.Empty)
            {
                double total = Convert.ToDouble(txt_Total.Text.Replace("$", ""));
                double monedero = txt_Monedero.Text != string.Empty
                    ? Convert.ToDouble(txt_Monedero.Text.Replace("$", ""))
                    : 0;
                saldoRestante = total - Enganche_Anticipo - monedero;
            }
        }

        /// <summary>
        ///     Height para acomodar tamaño de groupboxs
        /// </summary>
        /// <returns>int</returns>
        /// Developer: Dan Palacios
        /// Date: 15/11/17
        private int HeightFixer()
        {
            int newheight = 180;
            if (lbl_Comentario.Visible) newheight = newheight - 20;
            if (chk_Mayoreo.Visible) newheight = newheight - 10;
            if (lbl_Observaciones.Visible) newheight = newheight - 20;
            if (lbl_CtaPago.Visible) newheight = newheight - 20;
            return newheight;
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleVenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.D)
            {
                if (btn_InfoArt.Visible) Btn_InfoArt_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.I)
            {
                if (btn_Imprimir.Visible) Btn_Imprimir_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
            {
                if (btn_Situaciones.Visible) Btn_Situaciones_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.F)
            {
                if (btn_Afectar.Visible) Btn_Afectar_Click(null, null);
            }
            else if (e.KeyCode == Keys.F1)
            {
                if (btn_Eliminar.Visible) Btn_Eliminar_Click(null, null);
            }
            else if (e.KeyCode == Keys.F2)
            {
                if (btn_Cancelar.Visible) Btn_Cancelar_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.E)
            {
                if (btn_Eventos.Visible) Btn_Eventos_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
            {
                if (btn_HojaV.Visible) Btn_HojaV_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.H)
            {
                if (btn_SHM.Visible) btn_SHM_Click(null, null);
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.J)
            {
                if (btn_AdjuntarSHM.Visible) Btn_AdjuntarSHM_Click(null, null);
            }
        }


        //-ReporteDescuento
        /// <summary>
        ///     Abre ventana reporte servicios
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 21/11/17
        private void Cb_ServicioReporte_CheckedChanged(object sender, EventArgs e)
        {
            if (ActualizarReporte)
            {
                if (cb_ServicioReporte.Checked)
                {
                    DM0312_DetalleValidaReporteServicio ReporteServicios = new DM0312_DetalleValidaReporteServicio
                    {
                        IDVenta = VentasSeleccionadas[PaginadoActual].ID,
                        Sucursal = ClaseEstatica.Usuario.sucursal
                    };
                    TopMost = false;
                    ReporteServicios.ShowDialog();
                    if (ReporteServicios.ReporteSeleccionadoValido)
                    {
                        string reporteTxt = "Reporte Descuento ZZZ";
                        MessageBox.Show("Reporte servicio asignado correctamente", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

                        origenReporte = ReporteServicios.origen;

                        if (origenReporte == "Soporte")
                            ReporteServicio = CReporte.MovConReporte(VentasSeleccionadas[PaginadoActual].ID);
                        else if (origenReporte == "VTASDReporteDescuento")
                            ReporteServicio = ReporteServicios.IDReporte.ToString();
                        cb_ServicioReporte.Text = reporteTxt + " " + ReporteServicio;
                    }
                    else
                    {
                        cb_ServicioReporte.Checked = false;
                        ReporteServicio = string.Empty;
                    }
                }
                else
                {
                    CReporte.DesasignarReporte(VentasSeleccionadas[PaginadoActual].ID);
                    ReporteServicio = string.Empty;
                }
            }
        }

        /// <summary>
        ///     Tool tip click derecho para copiar labels
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// date: 23/11/17
        private void CopiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripItem menuItem = sender as ToolStripItem;
            if (menuItem != null)
            {
                // Retrieve the ContextMenu that contains this MenuItem
                ContextMenuStrip owner = menuItem.Owner as ContextMenuStrip;
                if (owner != null)
                {
                    // Get the control that is displaying this context menu
                    Control sourceControl = owner.SourceControl;
                    if (sourceControl is Label)
                    {
                        Label lbl_sender = (Label)sourceControl;
                        Clipboard.SetDataObject(lbl_sender.Text);
                    }
                    else if (sourceControl is DataGridView)
                    {
                        DataGridView gvSender = (DataGridView)sourceControl;

                        Clipboard.SetDataObject(gvSender.CurrentCell.Value);
                    }
                }
            }
        }

        private void txt_CPEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void actualizaPrecioConDescuento(double importe)
        {
            try
            {
                modeloVentaDetalle.Precio = importe;
                modeloVentaDetalle.PrecioS =
                    importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + importe;
                //modeloVentaDetalle = actualizaMovGarantias(modeloVentaDetalle);
                //llenarGrid();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("actualizaPrecioConDescuento", "DM0312_DetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        //-MejorasMayoreo
        private void chk_Mayoreo_CheckedChanged(object sender, EventArgs e)
        {
            int check = chk_Mayoreo.Checked ? 1 : 0;
            string estatus = CDetalleVenta.EstatusActual(VentasSeleccionadas[PaginadoActual].ID);

            if (estatus.Equals("SINAFECTAR"))
                CDetalleVenta.updateConMayoreo(check, VentasSeleccionadas[PaginadoActual].ID);
        }

        private void chkDomicilioCliente_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDomicilioCliente.Checked)
            {
                clsDatosEntregaCliente vDatosCliente =
                    CDetalleVenta.obtenerDatosCliente(VentasSeleccionadas[PaginadoActual].Cliente);
                if (vDatosCliente != null)
                {
                    txt_direccionEntrega.Text = vDatosCliente.sDireccion;
                    txt_numE.Text = vDatosCliente.sNumeroExt;
                    txt_NumI.Text = vDatosCliente.sNumeroInt;
                    cb_colonia.Text = vDatosCliente.sColonia;
                    txt_CPEntrega.Text = vDatosCliente.sCodigoPostal;
                    txt_PoblacionEntrega.Text = vDatosCliente.sPoblacion;
                    txt_EstadoEntrega.Text = vDatosCliente.sEstado;
                    txt_EntreCallesEntrega.Text = vDatosCliente.sEntreCalles;
                }
            }

            if (!chkDomicilioCliente.Checked)
            {
                txt_direccionEntrega.Text = string.Empty;
                txt_numE.Text = string.Empty;
                txt_NumI.Text = string.Empty;
                cb_colonia.Text = string.Empty;
                txt_CPEntrega.Text = string.Empty;
                txt_PoblacionEntrega.Text = string.Empty;
                txt_EstadoEntrega.Text = string.Empty;
                txt_EntreCallesEntrega.Text = string.Empty;
            }
        }

        private void txt_Comentarios_TextChanged(object sender, EventArgs e)
        {
        }

        private void txt_FormaCo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (modificarCobro == 0)
                CDetalleVenta.FormaCobroLUpdate(VentasSeleccionadas[PaginadoActual].ID, txt_FormaCo.Text);
            modificarCobro = 0;
        }

        private void Tb_efectivoRecibido_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void chx_Die_CheckedChanged(object sender, EventArgs e)
        {
            if (chx_Die.Checked)
            {
                if (VentasSeleccionadas[PaginadoActual].ID != 0)
                {
                    controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                    if (chkTransferencia.Checked)
                    {
                        chkTransferencia.Checked = false;
                        txtCuentaClabe.Text = string.Empty;
                        txtBanco.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
            else
            {
                if (VentasSeleccionadas[PaginadoActual].ID != 0)
                {
                    controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios ", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
        }


        #region -TarjetaDepartamental

        public void TarjetaDepartamental(bool waitForExit)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.FileName =
                    ClaseEstatica.plugInPath + @"TarjetaDepartamental\tarjetaDepartamental.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = "1" + " " + VentasSeleccionadas[PaginadoActual].Cliente + " " +
                                              ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.Usuario.sucursal;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                if (waitForExit) pTicket.WaitForExit();
                pTicket.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("TarjetaDepartamental", "DM0312_DetalleVenta.cs", ex);
                MessageBox.Show(ex.Message + " function: TarjetaDepartamental, class: DM0312_DetalleVenta.cs");
            }
        }

        #endregion


        //-PrimeraFaseDeAutomatizacion //-ReservaOnline
        public void enviarCorreos(string asunto, string cuerpo, List<string> correos, string rutaarchivo, int html,
            int uen, string bcc)
        {
            try
            {
#if PRODUCCION
                string sUsuario = "webmaster@mueblesamerica.mx";
                string sPassword = "6UUiwPdB6K";
                string sServidor = "mail.mueblesamerica.mx";
#elif CUBOS || PROSERVER
                string sUsuario = "webmaster@mueblesamerica.mx";
                string sPassword = "6UUiwPdB6K";
                string sServidor = "mail.mueblesamerica.mx";
#endif
                string from = string.Empty;
                if (uen == 1)
                {
                    if (asunto == "Dineralia")
                    {
                        from = "atencionaclientes@dineralia.mx";
                        sUsuario = "webmaster@dineralia.mx";
                        sPassword = "{#?xEvKaxT2P(y";
                        sServidor = "mail.dineralia.mx";
                    }
                    else
                    {
                        from = "no-reply@mueblesamerica.mx";
                    }
                }
                else if (uen == 2)
                {
                    from = "no-reply@viu.mx";
                }

                string[] datos =
                {
                    sUsuario,
                    sPassword,
                    sServidor,
                    from
                };


                SmtpClient smtp = new SmtpClient();
                smtp.Credentials = new NetworkCredential { UserName = datos[0], Password = datos[1] };

                smtp.Host = datos[2];
                smtp.Port = 587; //se cambia a est puerto porque l 25 y el 26 se estaban bloquenado en la ssalida del servidor200.4
                smtp.Timeout = 100000; //Tiempo de conexión
                smtp.EnableSsl = false;

                MailMessage enviacorreo = new MailMessage(); // objeto para ennviar el correo 
                enviacorreo.From = new MailAddress(datos[3]);

                foreach (string correo in correos) enviacorreo.To.Add(correo);

                if (bcc != "") enviacorreo.Bcc.Add(bcc);

                enviacorreo.Subject = asunto;
                enviacorreo.Body = cuerpo;

                if (html == 1)
                    enviacorreo.IsBodyHtml = true;
                else
                    enviacorreo.IsBodyHtml = false;

                enviacorreo.Priority = MailPriority.Normal;

                // Agrego el fichero como archivo adjunto
                if (rutaarchivo != "") enviacorreo.Attachments.Add(new Attachment(rutaarchivo));
                smtp.Send(enviacorreo);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("enviarCorreos", "DM0312_DetalleVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void chkTransferencia_CheckedChanged(object sender, EventArgs e)
        {
            if (chx_Die.Checked)
            {
                if (VentasSeleccionadas[PaginadoActual].ID != 0)
                {
                    controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                    if (chkTransferencia.Checked)
                    {
                        chkTransferencia.Checked = false;
                        txtCuentaClabe.Text = string.Empty;
                        txtBanco.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
            else
            {
                if (VentasSeleccionadas[PaginadoActual].ID != 0)
                {
                    controladorV.updateDieVenta(VentasSeleccionadas[PaginadoActual].ID, chx_Die.Checked);
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios ", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
        }

        #region Die

        //-864 GESSY  Decicion  
        /// <summary>
        ///     Custom alert payment metod selection
        /// </summary>
        /// Developer: Getsemani Avila
        /// Date: XX/XX/XXXX
        public void desicion()
        {
            using (Form form = new Form())
            {
                form.Text = "Decisión";
                form.Size = new Size(340, 140);

                Label lbl_img = new Label();

                lbl_img.Image = Resources.question_icon;
                lbl_img.Text = null;
                lbl_img.TabIndex = 0;
                //lbl_img.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_img.Size = new Size(58, 58);
                lbl_img.Location = new Point(12, 9);

                Label lbl_msg = new Label();
                lbl_msg.Text = "EL PAGO SE HARÁ POR:";
                lbl_msg.TabIndex = 0;
                //lbl_msg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_msg.Size = new Size(189, 58);
                lbl_msg.Location = new Point(76, 9);

                Button btn_sucursal = new Button();
                btn_sucursal.Text = "Sucursal";
                btn_sucursal.TabIndex = 0;
                btn_sucursal.Name = "btn_sucursal";
                btn_sucursal.Location = new Point(15, 70);
                btn_sucursal.Size = new Size(86, 20);
                btn_sucursal.UseVisualStyleBackColor = true;
                btn_sucursal.Click += (send, args) =>
                {
                    str_CustomAlertResult = "SUCURSAL";
                    form.Close();
                };

                Button btn_stp = new Button();
                btn_stp.Text = "Transferencia";
                btn_stp.TabIndex = 0;
                btn_stp.Name = "btn_stp";
                btn_stp.Location = new Point(115, 70);
                btn_stp.Size = new Size(86, 20);
                btn_stp.UseVisualStyleBackColor = true;
                btn_stp.Click += (send, args) =>
                {
                    str_CustomAlertResult = "TRANSFERENCIA";
                    form.Close();
                };

                Button btn_banco = new Button();
                btn_banco.Text = "Banco";
                btn_banco.TabIndex = 0;
                btn_banco.Name = "btn_banco";
                btn_banco.Location = new Point(215, 70);
                btn_banco.Size = new Size(86, 20);
                btn_banco.UseVisualStyleBackColor = true;
                btn_banco.Click += (send, args) =>
                {
                    str_CustomAlertResult = "BANCO";
                    form.Close();
                };

                form.Controls.Add(lbl_img);
                form.Controls.Add(lbl_msg);
                form.Controls.Add(btn_sucursal);
                form.Controls.Add(btn_stp);
                form.Controls.Add(btn_banco);

                form.ShowDialog();
            }
        }

        //-864 GESSY  Confimacion 
        /// <summary>
        ///     Custom alert Confirm payment metod selection
        /// </summary>
        /// Developer: Getsemani Avila
        /// Date: XX/XX/XXXX
        public void confirmar(string msg)
        {
            using (Form form = new Form())
            {
                form.Text = "Confirmar";
                form.Size = new Size(420, 160);

                Label lbl_img = new Label();

                lbl_img.Image = Resources.question_icon;
                lbl_img.Text = null;
                lbl_img.TabIndex = 0;
                //lbl_img.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_img.Size = new Size(58, 58);
                lbl_img.Location = new Point(12, 9);

                Label lbl_msg = new Label();
                lbl_msg.Text = "¿ESTÁ SEGURO QUE EL PAGO SERA POR " + str_CustomAlertResult + "?";
                lbl_msg.Text = lbl_msg.Text + msg;
                lbl_msg.TabIndex = 0;
                //lbl_msg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_msg.Size = new Size(330, 65);
                lbl_msg.Location = new Point(76, 9);

                Button btn_aceptar = new Button();
                btn_aceptar.Text = "Aceptar";
                btn_aceptar.TabIndex = 0;
                btn_aceptar.Name = "btn_aceptar";
                btn_aceptar.Location = new Point(90, 85);
                btn_aceptar.Size = new Size(86, 20);
                btn_aceptar.UseVisualStyleBackColor = true;
                btn_aceptar.Click += (send, args) =>
                {
                    str_CustomAlertResult = "ACEPTAR";
                    form.Close();
                };

                Button btn_cancelar = new Button();
                btn_cancelar.Text = "Cancelar";
                btn_cancelar.TabIndex = 0;
                btn_cancelar.Name = "btn_cancelar";
                btn_cancelar.Location = new Point(240, 85);
                btn_cancelar.Size = new Size(86, 20);
                btn_cancelar.UseVisualStyleBackColor = true;
                btn_cancelar.Click += (send, args) =>
                {
                    str_CustomAlertResult = "CANCELAR";
                    form.Close();
                };

                // form.Controls.Add(...);
                form.Controls.Add(lbl_img);
                form.Controls.Add(lbl_msg);
                form.Controls.Add(btn_aceptar);
                form.Controls.Add(btn_cancelar);

                form.ShowDialog();
            }
        }

        //-864 GESSY  En Proceso 
        /// <summary>
        ///     Custom alert Confirm payment metod selection
        /// </summary>
        /// Developer: Getsemani Avila
        /// Date: XX/XX/XXXX
        public void proceso()
        {
            using (Form form = new Form())
            {
                form.TopMost = true;
                form.Text = "Procesando";
                form.Size = new Size(293, 140);
                form.ControlBox = false;

                Label lbl_img = new Label();


                lbl_img.Image = Resources.sandclock;
                lbl_img.Text = null;
                lbl_img.TabIndex = 0;
                //lbl_img.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_img.Size = new Size(58, 58);
                lbl_img.Location = new Point(12, 9);

                Label lbl_msg = new Label();
                lbl_msg.Text = "MOVIMIENTO EN PROCESO...";
                lbl_msg.TabIndex = 0;
                //lbl_msg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_msg.Size = new Size(189, 58);
                lbl_msg.Location = new Point(76, 9);

                // form.Controls.Add(...);
                form.Controls.Add(lbl_img);
                form.Controls.Add(lbl_msg);

                form.ShowDialog();
            }
        }

        //-864 GESSY  ProcesoTerminado 
        /// <summary>
        ///     Custom alert Confirm payment metod selection
        /// </summary>
        /// Developer: Getsemani Avila
        /// Date: XX/XX/XXXX
        public void procesoTerminado()
        {
            using (Form form = new Form())
            {
                form.TopMost = true;
                form.Text = "Finalizar";
                form.Size = new Size(293, 140);

                Label lbl_img = new Label();

                lbl_img.Image = Resources.check1;
                lbl_img.Text = null;
                lbl_img.TabIndex = 0;
                //lbl_img.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_img.Size = new Size(58, 58);
                lbl_img.Location = new Point(12, 9);

                Label lbl_msg = new Label();
                lbl_msg.Text = "MOVIMIENTO CONCLUIDO";
                lbl_msg.TabIndex = 0;
                //lbl_msg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                lbl_msg.Size = new Size(189, 58);
                lbl_msg.Location = new Point(76, 9);

                // form.Controls.Add(...);
                form.Controls.Add(lbl_img);
                form.Controls.Add(lbl_msg);

                form.ShowDialog();
            }
        }

        #endregion

        #region Metodos

        /// <summary>
        ///     metodo encargado de obtener el html de correo dineralia
        /// </summary>
        /// <param name="RespuestaCredito"></param>
        /// <returns></returns>
        public string hmtlDineralia(string RespuestaCredito, string sCliente = "", int iId = 0)
        {
            string TituloCorreo;
            string CuerpoCorreo;
            DateTime dt =
                CDetalleVenta.obtnerFechaSolicitud(VentasSeleccionadas.Count > 0
                    ? VentasSeleccionadas[PaginadoActual].ID
                    : iId);
            //string monthName = new DateTime(dt.Year, dt.Month, dt.Year).ToString("MMM", CultureInfo.InvariantCulture);
            DateTimeFormatInfo formatoFecha = CultureInfo.CurrentCulture.DateTimeFormat;
            string nombreMes = formatoFecha.GetMonthName(dt.Month);
            string Fecha = dt.Day + " " + nombreMes + " " + dt.Year;
            string TerminacionTarjeta =
                CDetalleVenta.obtenerNumeroTarjeta(
                    VentasSeleccionadas.Count > 0 ? VentasSeleccionadas[PaginadoActual].Cliente : sCliente, 1);
            string Nombre =
                CDetalleVenta.obtenerNumeroTarjeta(
                    VentasSeleccionadas.Count > 0 ? VentasSeleccionadas[PaginadoActual].Cliente : sCliente, 2);
            string MontoSolicitado =
                CDetalleVenta.obtenerMontoSolicitado(VentasSeleccionadas.Count > 0
                    ? VentasSeleccionadas[PaginadoActual].ID
                    : iId) + ".00";
            string Facebook = "https://www.facebook.com/Dineralia-100737201752627";
            /*string UrlFacebook = "https://mueblesamerica.mx/pub/media/wysiwyg/img/IconFacebook.png";
            string UrlTwitter = "https://mueblesamerica.mx/pub/media/wysiwyg/img/IconTwitter.png";
            string UrlInstagram = "https://mueblesamerica.mx/pub/media/wysiwyg/img/IconInstagram.png";
            string LogoDineralia = "https://mueblesamerica.mx/pub/media/wysiwyg/img/LogoDineralia.png";*/
            string TituloUrl = "Dineralia";
            string infStd = CDetalleVenta.obtenerInformacionDineralia();
            string Url = infStd.Split('|')[0];
            string Telefono = infStd.Split('|')[1];
            string CantidadAprobada =
                CDetalleVenta.obtenernCapital(VentasSeleccionadas.Count > 0
                    ? VentasSeleccionadas[PaginadoActual].ID
                    : iId) + ".00";
            string FechaActual = DateTime.Now.ToString("d 'de' MMMM 'de' yyyy");

            switch (RespuestaCredito)
            {
                case "CreditoAprobado":
                    TituloCorreo = "¡Crédito aprobado!";
                    CuerpoCorreo = @"
                        <p>Te informamos que tu solicitud de crédito fue completada, muchas gracias.</p>
                        <p>Dineralia te autoriza un préstamo en efectivo por $" + MontoSolicitado +
                                   @", puedes consultar el saldo en la cuenta que registraste con terminación ********" +
                                   TerminacionTarjeta.Substring(TerminacionTarjeta.Length - 4, 4) +
                                   @" para validar que tu depósito se realizó de manera correcta.</p>
                        <p>Fue un placer, si tienes algún comentario comunícate con nosotros.</p>";
                    break;
                case "CreditoAprobadoAjuste":
                    TituloCorreo = "¡Crédito aprobado!";
                    CuerpoCorreo = @"
			            <p>Tu solicitud de préstamo en efectivo fue autorizada por la cantidad de: $" +
                                   CantidadAprobada + @".</p>
                        <p>Te solicitamos Ingresar a la Pagina de Dineralia, Ingresando tu Usuario y Contraseña y des click en Solicitar Prestamo.</p>
                        <p>Con esto podemos concluir tu tramite por la cantidad arriba mencionada.</p>
                        <p></p>
                        <p>Dineralia Agradece tu preferencia y deja el siguiente telefono para atender tus dudas.</p>";

                    break;
                case "CreditoNoAprobado":
                    TituloCorreo = "Crédito no aprobado";
                    CuerpoCorreo = @"
                        <p>Recibimos tu solicitud de crédito el día " + Fecha + @"; Muchas gracias.</p>
                        <p>Realizamos un análisis con base en la solicitud de crédito y te informamos que por políticas de la empresa no fue posible aprobar el préstamo en este momento.</p>
                        <p>Sentimos los inconvenientes que pudimos generar. Si tienes algún comentario comunícate con nosotros.</p>";
                    break;
                case "ProcesoNoConcluido":
                    TituloCorreo = "Proceso no concluido";
                    CuerpoCorreo = @"
                        <p>Te informamos que tu solicitud de crédito no ha sido completada, tu préstamo te espera.</p>
                        <p>Con Dineralia puedes solicitar un crédito de hasta $" + CantidadAprobada +
                                   @" de manera fácil y sencilla, solo concluye tu solicitud en: <a href='" + Url +
                                   @"'>" + TituloUrl +
                                   @"</a></p>
                        <p>Una vez terminada tu solicitud te contactaremos por correo electrónico para darte mayor información sobre tu crédito.</p>
                        <p>Muchas gracias, si tienes algún comentario comunícate con nosotros.</p>";
                    break;
                default:
                    TituloCorreo = "";
                    CuerpoCorreo = "";
                    break;
            }
#if PRODUCCION
            return @"
                <html>
                <head>
	                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                </head>
                <body>
	
		            <table style='width:100%;max-width:800px;margin:0 auto;border-collapse: collapse;font-family: Arial, Sans-Serif; font-size: 1rem; font-weight: 400; line-height: 1.5; color: #212529;'>
		                <thead>
		                <tr>
		                    <th colspan='3' style='text-align: center;'><img style='width: 270px;' src='https://www.dineralia.mx/img/Logo-horizontal.png' class='logo'></th>
		                </tr>
		                </thead>
		                <tbody>
		                <tr>
		                    <td colspan='3'>
		      	            <div style='padding: 20px 0px 20px 0px;'>
		      		            <center><h1 style='font-weight: bold; color: #6cb533; font-size: 2rem; margin-bottom: 50px; margin-top: 40px;'>" + TituloCorreo + @"</h1></center>


					            <div style='text-align: right;'>
						            <p>Guadalajara, Jalisco. " + FechaActual + @".</p>
					            </div>" +

                                (
                                    (Nombre != "") ?
                                    @"<p style='font-weight: bold; margin-bottom: 0px; font-size: 2em;'>Hola</p>
					                <p style='margin-top: 0px;'>" + Nombre + @"</p>" : @""
                                ) +

                                @"<div style='text-align: justify;'>" + CuerpoCorreo + @"</div>
		      	            </div>
		                    </td>
		                </tr>
		                </tbody>
		                <tfoot style='background-color:#434343;border-top:3px solid #6cb533;'>
		                <tr>
		                    <td style='width: 33%;text-align: left; color: white'><p style='margin-left: 10px'><b style='color:#6cb533'>Teléfono</b><br>" + Telefono + @"</p></td>
		                    <td style='width: 33%;text-align: center;'><a target='_blank' href='" + Facebook + @"'><img style='height: 50px;padding: 10px 0px 10px 0px;' src='https://www.dineralia.mx/img/facebook.png'></a></td>
		                    <td style='width: 33%;text-align: right;'><img style='height: 50px;padding: 10px 0px 10px 0px;margin-right: 10px' src='https://www.dineralia.mx/img/Logo-horizontal.png'></td>
		                </tr>
		                </tfoot>
		            </table>

                </body>	
                </html>";

#elif CUBOS || PROSERVER
            return @"
                <html>
                <head>
	                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                </head>
                <body>
	
		            <table style='width:100%;max-width:800px;margin:0 auto;border-collapse: collapse;font-family: Arial, Sans-Serif; font-size: 1rem; font-weight: 400; line-height: 1.5; color: #212529;'>
		                <thead>
		                <tr>
		                    <th colspan='3' style='text-align: center;'><img style='width: 270px;' src='https://www.dineralia.mx/img/Logo-horizontal.png' class='logo'></th>
		                </tr>
		                </thead>
		                <tbody>
		                <tr>
		                    <td colspan='3'>
		      	            <div style='padding: 20px 0px 20px 0px;'>
		      		            <center><h1 style='font-weight: bold; color: #6cb533; font-size: 2rem; margin-bottom: 50px; margin-top: 40px;'>" +
                   TituloCorreo + @"</h1></center>


					            <div style='text-align: right;'>
						            <p>Guadalajara, Jalisco. " + FechaActual + @".</p>
					            </div>" +
                   (
                       Nombre != ""
                           ? @"< p style='font-weight: bold; margin-bottom: 0px; font-size: 2em;'>Hola</p>
					                <p style='margin-top: 0px;'>" + Nombre + @"</p>"
                           : @""
                   ) +
                   @"<div style='text-align: justify;'>" + CuerpoCorreo + @"</div>
		      	            </div>
		                    </td>
		                </tr>
		                </tbody>
		                <tfoot style='background-color:#434343;border-top:3px solid #6cb533;'>
		                <tr>
		                    <td style='width: 33%;text-align: left; color: white'><p style='margin-left: 10px'><b style='color:#6cb533'>Teléfono</b><br>" +
                   Telefono + @"</p></td>
		                    <td style='width: 33%;text-align: center;'><a target='_blank' href='" + Facebook +
                   @"'><img style='height: 50px;padding: 10px 0px 10px 0px;' src='https://www.dineralia.mx/img/facebook.png'></a></td>
		                    <td style='width: 33%;text-align: right;'><img style='height: 50px;padding: 10px 0px 10px 0px;margin-right: 10px' src='https://www.dineralia.mx/img/Logo-horizontal.png'></td>
		                </tr>
		                </tfoot>
		            </table>

                </body>	
                </html>";

#endif
        }

        private void btnCartaFactura_Click(object sender, EventArgs e)
        {
            string actual = DateTime.UtcNow.ToString("yyyy");
            int _modelo = 0;
            string aa = DateTime.Now.Year.ToString();
            string mm = DateTime.Now.ToString("MM");
            string dd = DateTime.Now.Day.ToString();
            int mes = short.Parse(mm);
            mm = obtenerMes(mes);
            int item = 0;

            string[] datos;
            string eaa = VentasSeleccionadas[PaginadoActual].FechaAlta.Year.ToString();
            string emm = VentasSeleccionadas[PaginadoActual].FechaAlta.ToString("MM");
            string edd = VentasSeleccionadas[PaginadoActual].FechaAlta.Day.ToString();

            mes = short.Parse(emm);
            emm = obtenerMes(mes);
            foreach (MDetalleVenta Detalle in ListaDetallesSeleccionados)
            {
                MCartaFactura RCartaFactura = new MCartaFactura();
                try
                {
                    List<MCartaFactura> list = new List<MCartaFactura>();
                    List<MSerieArticulos> TempSerie =
                        ControladorSerie.ObtenerSeriesArticulos(VentasSeleccionadas[PaginadoActual].ID,
                            Detalle.Articulo);
                    if (TempSerie.Count > 0)
                    {
                        try
                        {
                            string[] aduana = TempSerie[item].FechaAduana.Split('-');
                            mes = short.Parse(aduana[1]);
                            string ames = obtenerMes(mes);
                            RCartaFactura.FechaAduana = aduana[item] + "-" + ames + "-" + aduana[2];
                        }
                        catch
                        {
                            RCartaFactura.FechaAduana = "N/A";
                        }

                        RCartaFactura.Aduana = TempSerie[item].Aduana;
                        RCartaFactura.Articulo = Detalle.Descripcion;
                        RCartaFactura.Cliente = txt_Cliente1.Text + ",";
                        RCartaFactura.Color = TempSerie[item].Color;
                        RCartaFactura.Cuadro = TempSerie[item].Cuadro;
                        RCartaFactura.Domicilio = ObtieneDomicilioCliente() + ".";
                        RCartaFactura.Factura = VentasSeleccionadas[PaginadoActual].MovId + ".";
                        RCartaFactura.FechaImpresion = dd + "-" + mm + "-" + aa;
                        RCartaFactura.FechaEmision = edd + "-" + emm + "-" + eaa;

                        RCartaFactura.DomicilioSucursal = ObtieneDomicilioSucursal(ClaseEstatica.Usuario.sucursal);
                        datos = RCartaFactura.DomicilioSucursal.Split('/');
                        RCartaFactura.DomicilioSucursal = datos[0];
                        RCartaFactura.Sucursal = datos[2];
                        if (datos[1].Length > 0)
                            RCartaFactura.ciudad = datos[1].Substring(0, 1);
                        else
                            RCartaFactura.ciudad = "M";
                        try
                        {
                            _modelo = int.Parse(TempSerie[item].Modelo);
                        }
                        catch
                        {
                            if (TempSerie[item].Modelo.Length > 6)
                                _modelo = int.Parse(TempSerie[item].Modelo.Substring(6));
                        }

                        RCartaFactura.Articulo = RCartaFactura.Articulo + ", MODELO " + _modelo + ",";
                        RCartaFactura.Modelo = _modelo.ToString();
                        RCartaFactura.Motor = TempSerie[item].Serie;

                        if (TempSerie[item].Pedimento == "")
                            RCartaFactura.Pedimento = "ENSAMBLADO EN MEXICO";
                        else
                            RCartaFactura.Pedimento = TempSerie[item].Pedimento;

                        RCartaFactura.Importe = Detalle.ImporteTotal;
                        RCartaFactura.logoM = true;
                        RCartaFactura.logoV = false;
                        RCartaFactura.TipoVenta = "A CRÉDITO CON UN PLAZO DE " +
                                                  VentasSeleccionadas[PaginadoActual].Condicion.Substring(0, 5);
                        if (VentasSeleccionadas[PaginadoActual].Condicion.Contains("CONTADO"))
                            RCartaFactura.TipoVenta = "DE CONTADO ";
                        list.Add(RCartaFactura);

                        if (RCartaFactura.Modelo == actual)
                        {
                            if (RCartaFactura.ciudad == "M")
                            {
                                DM0312_CartaFacM ReporCartaFactura = new DM0312_CartaFacM(list);
                                ReporCartaFactura.ShowDialog();
                                break;
                            }
                            else
                            {
                                DM0312_CartaFac ReporCartaFactura = new DM0312_CartaFac(list);
                                ReporCartaFactura.ShowDialog();
                                break;
                            }
                        }

                        if (RCartaFactura.ciudad == "M")
                        {
                            DM0312_CartaFacOldM ReporCartaFactura = new DM0312_CartaFacOldM(list);
                            ReporCartaFactura.ShowDialog();
                            break;
                        }
                        else
                        {
                            DM0312_CartaFacOld ReporCartaFactura = new DM0312_CartaFacOld(list);
                            ReporCartaFactura.ShowDialog();
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    //MessageBox.Show(ex.Message, "Punto De Venta Carta Factura", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public string ObtieneDomicilioSucursal(int msucursal)
        {
            DM0312_MSucursal temp = new DM0312_MSucursal();
            string Domicilio = "";
            DM0312_CSucursal sucursal = new DM0312_CSucursal();
            List<DM0312_MSucursal> list = sucursal.ObtenerSucursales();

            temp = list.Where(x => x.Sucursal == Convert.ToInt32(msucursal)).SingleOrDefault();

            Domicilio = "CALLE " + temp.Direccion + " No. " + temp.DireccionNumero;
            if (temp.DireccionNumeroInt != "") Domicilio = Domicilio + " Int. " + temp.DireccionNumeroInt;
            Domicilio = Domicilio + ", COLONIA " + temp.Colonia + ", " + temp.Poblacion + ", CP:" + temp.CodigoPostal +
                        ", ";
            Domicilio = Domicilio + temp.Estado + ", MÉXICO" + "/" + temp.Grupo + "/" + temp.Poblacion + ", " +
                        temp.Estado;

            return Domicilio;
        }

        public string ObtieneDomicilioCliente()
        {
            string Domicilio = "Sin domicilio";

            clsDatosEntregaCliente vDatosCliente =
                CDetalleVenta.obtenerDatosCliente(VentasSeleccionadas[PaginadoActual].Cliente);
            if (vDatosCliente != null)
            {
                Domicilio = "CALLE " + vDatosCliente.sDireccion + " No. " + vDatosCliente.sNumeroExt;
                if (vDatosCliente.sNumeroInt != "") Domicilio = Domicilio + " Int. " + vDatosCliente.sNumeroInt;
                Domicilio = Domicilio + ", COLONIA " + vDatosCliente.sColonia + ", " + vDatosCliente.sPoblacion + ", ";
                Domicilio = Domicilio + vDatosCliente.sEstado;
            }

            return Domicilio;
        }

        /// <summary>
        ///     metodo encargado de generar el correo
        /// </summary>
        /// <param name="iUen">Uen a la que pertenece la sucursal</param>
        /// <returns>retorna el correo el formato html</returns>
        private string obtenerHtmlCorreo(int iUen)
        {
            string sHtml = string.Empty;
            string sHeader = string.Empty;
            string sFooter = string.Empty;

            if (iUen == 1)
            {
                sHeader = "https://www.mueblesamerica.mx/media/wysiwyg/mail/ma/header_ma.jpg";
                sFooter = "https://www.mueblesamerica.mx/media/wysiwyg/mail/ma/footer_ma.jpg";
            }

            if (iUen == 2)
            {
                sHeader = "https://www.viu.mx/media/wysiwyg/mail/viu/header_viu.jpg";
                sFooter = "https://www.viu.mx/media/wysiwyg/mail/viu/footer_viu.jpg";
            }

            string sDetalle = CDetalleVenta.obtenerArticulosYDetalle(VentasSeleccionadas[PaginadoActual].ID);

            sHtml = @"<!DOCTYPE html> <html>
                <head>
                <meta http-equiv = 'Content-Type' content = 'text/html; charset=utf-8' /> 
                <meta name = 'viewport' content = 'initial-scale=1.0, width=device-width' />
                <meta http-equiv = 'X-UA-Compatible' content = 'IE=edge'/>
                <style type = 'text/css'>
                </style >
               </head >
               <body >
               

               <table width = '660' align = 'center' cellpadding = '0' cellspacing = '0' style = 'font-weight: 600; font-family: sans-serif;' >
                <tr>
                <td class='wrapper-inner' align='center'>
                <table class='main' align='center'>
                <tr>
                    <td class='header'>
                        <a class='logo'>
                            <img src = '" + sHeader + @"'/>
                        </a>
                    </td >
                </tr >
                <tr >
                    <td class='main-content'>  
                        <table width = '660' align='center' cellpadding='0' cellspacing='0' style='font-weight: 600; font-family: sans-serif;'>
                            <tr>
                                <td align = 'left' >
                                    <h3 style = 'font-weight: 700;' > Id Venta: " +
                    VentasSeleccionadas[PaginadoActual].IDEcommerce + @"</h3> 
                                    <h3 style = 'font-weight: 700;' > Fecha: " + DateTime.Now + @"</h3> 
                                    <h3 style = 'font-weight: 700;' > Cliente: " +
                    VentasSeleccionadas[PaginadoActual].Cliente + " -  " +
                    CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente) + @"</h3> 
                                    <h3 style = 'font-weight: 700;' > Correo: " +
                    CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente, 2) + @"</h3> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <hr style = 'border: 1px solid #31B0E2;margin: 5px 0;border-top: 1px solid #e1e1e1;margin-bottom: 20px;margin-top: 20px;' width='100%'>                            
                                </td>
                            </tr>
                            <tr>
                                <td align = 'center' >
                                    <h3 style='font-weight: 700;margin-top: 10px'>Detalles del pedido</h3>
                                </td>
                            </tr>
                            <tr>
                            <td align = 'center' >
                                   " + sDetalle + @"
                                </td>
                            </tr>                            
                            <tr>
                                <td style = '50px; text-align:center;' >
                                                <p ><b > Si hay algo más que podamos hacer, ponte en contacto con nosotros a los teléfonos:<br/>
                                    (33) 1201-1022<br/>
                                    (33) 1201-1030<br/>
                                    (33) 1201-1045<br/>
                                    (33) 1201-1027<br/>
                                    </b></p>
                                </td>
                            </tr>
                            <tr align = 'center' >
                                <td valign='bottom'>
                                    <br/><h3 style = 'font-weight: 700;' > Que siga teniendo un excelente día.</h3>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class='footer'>
                        <table>
                            <tr>
                                <td class='header'>
                                    <a class='logo'>
                                        <img src = '" + sFooter + @"' />
                                    </a >
                                </td >
                            </tr >
                        </table >
                    </td >
                </tr >
            </table >
        </td >
    </tr >
</table >
<!--End wrapper table -->
</body>
<p align = 'center' ><FONT SIZE=1>Por favor no responda a este mensaje.Se envía desde una dirección de correo automatizada</font></p>";


            return sHtml;
        }

        /// <summary>
        ///     Metodo encargado de generar el html del correo del cliente
        /// </summary>
        /// <param name="iUen">Uen de la sucursal</param>
        /// <returns>retorna el html del correo que se enviara al cliente</returns>
        private string obtenerCorreoCliente(int iUen)
        {
            string sHtml = string.Empty;
            string sHeader = string.Empty;
            string sFooter = string.Empty;
            string sMap = string.Empty;
            string sRedSocial = string.Empty;
            string sTelefonos = CDetalleVenta.ObtenerTelefonos(iUen);


            if (iUen == 1)
            {
                sHeader = "https://www.mueblesamerica.mx/media/wysiwyg/mail/ma/header_ma.jpg";
                sFooter = "https://www.mueblesamerica.mx/media/wysiwyg/mail/ma/footer_ma.jpg";
                sMap = @"<area shape='rect' coords='0,10,280,40' href='https://www.mueblesamerica.mx/electronica.html'>
                         <area shape = 'rect' coords = '0,60,290,90' href = 'https://www.mueblesamerica.mx/linea-blanca.html'>     
                         <area shape = 'rect' coords = '0,120,320,150' href = 'https://www.mueblesamerica.mx/electrodomesticos.html'>          
                         <area shape = 'rect' coords = '0,170,350,200' href = 'https://www.mueblesamerica.mx/muebles.html'>
                         <area shape = 'rect' coords = '0,210,380,240' href = 'https://www.mueblesamerica.mx/motocicletas-y-accesorios.html'>";
                sRedSocial = @"<area shape='rect' coords='120,50,147,76' href='https://www.facebook.com/mueblesamerica'>
                                <area shape='rect' coords='158,50,185,76' href='https://www.instagram.com/mueblesamerica/'>
                                <area shape='rect' coords='197,50,224,76' href='https://www.youtube.com/user/MueblesAmerica'>
                                <area shape='rect' coords='235,50,263,76' href='https://twitter.com/mueblesamerica'>";
            }

            if (iUen == 2)
            {
                sHeader = "https://www.viu.mx/media/wysiwyg/mail/viu/header_viu.jpg";
                sFooter = "https://www.viu.mx/media/wysiwyg/mail/viu/footer_viu.jpg";


                sMap = @"<area shape='rect' coords='50,10,270,45' href='https://www.viu.mx/electronica.html'> 
                         <area shape = 'rect' coords = '90,55,310,90' href = 'https://www.viu.mx/linea-blanca.html'> 
                         <area shape = 'rect' coords = '130,100,350,140' href = 'https://www.viu.mx/electrodomesticos.html'> 
                         <area shape = 'rect' coords = '170,150,390,190' href = 'https://www.viu.mx/muebles.html'>               
                         <area shape = 'rect' coords = '210,200,430,230' href = 'https://www.viu.mx/motocicletas-y-accesorios.html'>";
                sRedSocial =
                    @"<area shape='rect' coords='157,97,188,127' href='https://es-la.facebook.com/viutienesquever'>
                            <area shape='rect' coords='197,97,228,127' href='http://instagram.com/viutienesquever'>
                            <area shape='rect' coords='235,97,266,127' href='https://www.youtube.com/user/ViuTienesQueVer'>
                            <area shape='rect' coords='273,97,304,127' href='https://twitter.com/viutienesquever'>";
            }

            string sClaveCliente = CDetalleVenta.obtenerClaveCliente(VentasSeleccionadas[PaginadoActual].IDEcommerce);

            string sDetalle = CDetalleVenta.obtenerArticulosYDetalle(VentasSeleccionadas[PaginadoActual].ID);

            string sDireccionSucursal =
                CDetalleVenta.direccionSucursal(VentasSeleccionadas[PaginadoActual].SucursalDestino);

            sHtml =
                @"<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
                    <html xmlns='http://www.w3.org/1999/xhtml'>
                    <head>
                        <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
                        <meta name='viewport' content='initial-scale=1.0, width=device-width' />
                        <meta http-equiv='X-UA-Compatible' content='IE=edge' />
                        <style type='text/css'></style>
                    <body>
                    <map name='Map' id='Map'>
                        " + sMap + @"
                    </map>
                    <!-- Begin wrapper table -->
                    <table class='wrapper' width='100%'>
                        <tr>
                            <td class='wrapper-inner' align='center'>
                                <table class='main' align='center'>
                                    <tr>
                                        <td style= 'background-color: #ffffff; padding: 0;' class='header'>                                                
                                                <img src='" + sHeader + @"' width='100%' usemap='#Map'>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td align='right' style='background-color: white;padding-right: 30px'>
                                            <br/>
                                            <h1 style='font-weight: 600;'>
                                                <span style='font-size: 18px;'>Número de pedido: " +
                VentasSeleccionadas[PaginadoActual].IDEcommerce + @"</span>
                                            </h1>
                                            <h1 style='font-weight: 600;'>
                                                <span style='font-size: 18px;'>Clave para recoger en sucursal: " +
                sClaveCliente + @"</span>
                                            </h1>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class='main-content'>
                                            <!-- Begin Content -->
                                            <table width='660' align='center' cellpadding='0' cellspacing='0' style='font-weight: 600; font-family: sans-serif;background-color: white;'>
                                                <tbody>
                                                    <tr>
                                                        <td style='font-weight: normal; padding: 0 40px; font-family: sans-serif;'>
                                                            <img src='http://stage-qai.mueblesamerica.mx/media/wysiwyg/mail/r_sucursal.jpg' width='100%'/>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align='center'>
                                                            <h2 style='font-weight: 700;margin-top: 45px;'>¡ Tu pedido está listo para que lo recojas en la sucursal!</h2>
                                                            <h3 style='font-weight: 700;margin-top: 25px;'>Hola " +
                CDetalleVenta.obtenerNombreCliente(VentasSeleccionadas[PaginadoActual].Cliente) + @"</h3>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align='center'>
                                                            <p>
                                                                Tu pedido está listo para ser recogido en la sucursal que seleccionaste.<br>No olvides llevar tu identificación y tu clave para recoger en sucursal tu producto.
                                                            </p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <hr style='border: 1px solid #31B0E2;margin: 5px 0;border-top: 1px solid #e1e1e1;margin-bottom: 20px;margin-top: 20px;' width='100%'>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align='center'>
                                                            <h3 style='font-weight: 700; margin-top: 10px; font-size: 18px; margin-bottom: 10px;'>Detalles del pedido</h3>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align='center'>
                                                            <h4 style='font-weight: 700; font-size: 14px; margin-top: 20px; margin-bottom: 20px;'>Domicilio de sucursal: <br>
                                                                <span style='font-size: 12px;'>" + sDireccionSucursal +
                @"</span>
                                                            </h4>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align='center'>
                                                            " + sDetalle + @"
                                                    <tr>
                                                    </tr>
                                                    <tr>
                                                        <td style='50px; text-align:center;'>
                                                            <p>
                                                                <b>Si hay algo más que podamos hacer, ponte en contacto con nosotros a los teléfonos:<br/>
                                                                   " + sTelefonos + @"
                                                                </b>
                                                            </p>
                                                        </td>
                                                    </tr>
                                                    <tr align='center'>
                                                        <td valign='bottom'>
                                                            <br/>
                                                            <h3 style='font-weight: 700;'>Agradecemos tu preferencia</h3>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- End Content -->
                                        </td>
                                    </tr>
                                    <tr>
                                        <td  style= 'background-color: #ffffff; width:100%;'>
                                            <table style='width:100%'>
                                                <tr>
                                                    <td>
                                                        <img src= '" + sFooter + @"' width='100%' usemap='#Map2'>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    <!-- End wrapper table -->
                    <map name='Map2' id='Map2'>
                        " + sRedSocial + @"
                    </map>
                </body>

<p align='center'><FONT SIZE=1>  *Por favor no responda a este mensaje.  Se envía desde una dirección de correo automatizada </font></p>                    


";

            return sHtml;
        }

        private void LlamadaPlugInAdjuntar()
        {
            if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                return;
            string mov = string.Empty;

            mov = VentasSeleccionadas[PaginadoActual].Mov.Replace(" ", "_");
            try
            {
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" ||
                    VentasSeleccionadas[PaginadoActual].Mov == "Pedido")
                {
                    int num = CDetalleVenta.SucursalRDP(ClaseEstatica.Usuario.sucursal);

                    if (num == 1)
                    {
                        string movi = VentasSeleccionadas[PaginadoActual].Mov;
                        movi = movi.Replace(" ", "_");

                        string ArgumentosPlugin = "SHM2 "
                                                  + VentasSeleccionadas[PaginadoActual].MovId + " "
                                                  + ClaseEstatica.Usuario.usuario + " "
                                                  + movi + " "
                                                  + ClaseEstatica.Usuario.sucursal + " "
                                                  + ClaseEstatica.WorkStation;
                        CDetalleVenta.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                    }
                    else
                    {
                        if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                        {
                            Process System = new Process();
                            System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                            System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                            System.StartInfo.Verb = "runas";
                            System.StartInfo.Arguments = "ADJUNTAR" + " " + mov + " " +
                                                         VentasSeleccionadas[PaginadoActual].MovId + " " +
                                                         ClaseEstatica.Usuario.usuario;
                            System.StartInfo.UseShellExecute = false;
                            System.Start();
                            //-Revision de Procesos
                            //System.WaitForExit();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Actualiza almacen
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void ActualizarAlmacen()
        {
            try
            {
                DM0312_DetalleCambiarAlmacen.IDVenta = Convert.ToInt32(lbl_ID.Text);
                DM0312_DetalleCambiarAlmacen.AlmacenActual = PuntoDeVenta.Alm;
                CAlmacenes CambiarAlmacen = new CAlmacenes();
                CambiarAlmacen.ActualizarAlmacen(VentasSeleccionadas[PaginadoActual].Estatus);
                VentasSeleccionadas[PaginadoActual].Almacen = DM0312_DetalleCambiarAlmacen.AlmacenActual;
                VentasSeleccionadas[PaginadoActual].SucursalDestino = DM0312_DetalleCambiarAlmacen.SucursalDestino;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Metodo encargado de mostrar u ocultar los componentes stp
        /// </summary>
        /// <param name="bEstatus">Estatus que obtendran los componentes</param>
        public void camposBanco(bool bEstatus, int iOpcion)
        {
            if (iOpcion == 1)
            {
                lblBanco.Visible = bEstatus;
                lblCuentaClabe.Visible = bEstatus;
                txtBanco.Visible = bEstatus;
                txtCuentaClabe.Visible = bEstatus;
            }

            if (iOpcion == 2)
            {
                lblBanco.Enabled = bEstatus;
                lblCuentaClabe.Enabled = bEstatus;
                txtBanco.Enabled = bEstatus;
                txtCuentaClabe.Enabled = bEstatus;
                chkTransferencia.Enabled = bEstatus;
            }
        }

        #endregion

        #region Evento De Botones

        /// <summary>
        ///     Boton encargado de embarcar y desembarcar el movimiento
        /// </summary>
        private void btnEmbarcar_Click(object sender, EventArgs e)
        {
            try
            {
                bool bEstatusEmb = CDetalleVenta.MovEmbarcado(VentasSeleccionadas[PaginadoActual].MovId);
                if (ValidarArticuloyAlmacen())
                {
                    MessageBox.Show("no se pueden facturar Motocicletas por distribución".ToUpper(), "Facturación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result;
                if (bEstatusEmb)
                    result = MessageBox.Show(
                        $"¿Desea desembarcar el movimiento {VentasSeleccionadas[PaginadoActual].MovId} ?",
                        "Punto De Venta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                else
                    result = MessageBox.Show(
                        $"¿Desea embarcar el movimiento {VentasSeleccionadas[PaginadoActual].MovId} ?",
                        "Punto De Venta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string[] sParametros =
                    {
                        VentasSeleccionadas[PaginadoActual].ID.ToString(),
                        VentasSeleccionadas[PaginadoActual].Mov,
                        VentasSeleccionadas[PaginadoActual].MovId,
                        VentasSeleccionadas[PaginadoActual].Estatus,
                        Convert.ToInt32(bEstatusEmb).ToString()
                    };

                    CDetalleVenta.embarqueManual(sParametros);

                    if (bEstatusEmb)
                        MessageBox.Show("Movimiento desembarcado satisfactoriamente", "Punto De Venta",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Movimiento embarcado satisfactoriamente", "Punto De Venta",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDocumentos_Click(object sender, EventArgs e)
        {
            try
            {
                frmListadoImagenes frmlimagenes = new frmListadoImagenes(listaImagenes,
                    VentasSeleccionadas[PaginadoActual].ID, VentasSeleccionadas[PaginadoActual].Estatus);
                frmlimagenes.cCliente = VentasSeleccionadas[PaginadoActual].Cliente;
                frmlimagenes.ShowDialog();
                if (frmlimagenes.guardado) btnDocumentos.Enabled = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void UsrDescuento_Click(object sender, EventArgs e)
        {
            try
            {
                if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR" &&
                    VentasSeleccionadas[PaginadoActual].Mov == "Pedido")
                {
                    MDetalleVenta detalle =
                        ListaDetallesSeleccionados.FirstOrDefault(x => x.ID == VentasSeleccionadas[PaginadoActual].ID);
                    if (Convert.ToDouble(detalle.Precio) <= 0)
                    {
                        MessageBox.Show("No se puede aplicar un descuento a articulos con Precio menor o igual a 0",
                            "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    DM0312_UsuarioDescuentoIncremento frm = new DM0312_UsuarioDescuentoIncremento();
                    //dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionArticulo].Value.ToString();

                    ArticulosDetalleVenta art = (ArticulosDetalleVenta)dgv_detalle.CurrentRow.DataBoundItem;
                    modeloVentaDetalle.Articulo = art.Articulo;
                    modeloVentaDetalle.Cantidad = Convert.ToInt32(art.Cantidad);

                    modeloVentaDetalle.RenglonID = art.RenglonID;
                    modeloVentaDetalle.Renglon = art.RenglonID * 2048;
                    modeloVentaDetalle.Unidad = detalle.Unidad;
                    string precioM = Convert.ToString(art.Precio);
                    precioM = precioM.Replace("$", "");
                    modeloVentaDetalle.Precio = Convert.ToDouble(precioM);
                    modeloVentaDetalle.Costo = Convert.ToDouble(art.Costo);
                    bool redimirP = CDetalleVenta.CheckRedencion(VentasSeleccionadas[PaginadoActual].ID);
                    modeloVentaDetalle.PropreListaID = pventa.GetPropreListaID(VentasSeleccionadas[PaginadoActual].ID,
                        art.Articulo, Convert.ToBoolean(redimirP));

                    frm.model = modeloVentaDetalle;
                    frm.canal = Convert.ToInt32(txt_Canal.Text);
                    frm.IdVenta = VentasSeleccionadas[PaginadoActual].ID;
                    frm.almacen = cb_Almacen.Text;
                    frm.agente = txt_Agente.Text;
                    frm.tipo = "UsrDescuento";
                    frm.Text = "UsrDescuento";
                    frm.TipoString = "Usuario Descuento";
                    frm.usrDescIncreLinea = true;
                    frm.ShowDialog();
                    if (frm.Operacion)
                    {
                        modeloVentaDetalle.TipoUsrDes_Incr = frm.tipo;
                        actualizaPrecioConDescuento(frm.precioActualizado);
                        foreach (ArticulosDetalleVenta Detalle in DatosDetalles)
                            if (Detalle.Articulo == art.Articulo)
                            {
                                ListaDetalles = new List<MDetalleVenta>();
                                DM0312_ExploradorVentas UsuarioAcceso = new DM0312_ExploradorVentas();
                                Detalle.Precio = Convert.ToString(modeloVentaDetalle.Precio);

                                //ListaDetallesSeleccionados[6] = modeloVentaDetalle.Precio;
                                //DM0312_DetalleVenta.ListaDetalles = new List<MDetalleVenta>();
                                //ListaDetallesSeleccionados = new List<MDetalleVenta>(ListaDetalles);
                                DM0312_C_ExploradorVenta ControladorExplora = new DM0312_C_ExploradorVenta();
                                ControladorExplora.ConsultaDetalle(ListaDetalles,
                                    VentasSeleccionadas[PaginadoActual].MovId, VentasSeleccionadas[PaginadoActual].Mov,
                                    VentasSeleccionadas[PaginadoActual].ID);
                                ListaDetallesSeleccionados = new List<MDetalleVenta>(ListaDetalles);
                                Detalle_Load(null, null);
                                //this.Dispose();
                                //UsuarioAcceso.recibeDescuento = 1;
                            }
                    }
                }
                else
                {
                    MessageBox.Show("Solo para pedidos y con estatus Sin afectar", "!Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UsrIncremento_Click(object sender, EventArgs e)
        {
            if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR" &&
                VentasSeleccionadas[PaginadoActual].Mov == "Pedido")
            {
                //if (modeloVentaDetalle.Articulo == null)
                //    return;

                DM0312_UsuarioDescuentoIncremento frm = new DM0312_UsuarioDescuentoIncremento();
                //dgv_detalle.SelectedRows[dgv_detalle.SelectedRows.Count - 1].Cells[EnteroPosicionArticulo].Value.ToString();

                ArticulosDetalleVenta art = (ArticulosDetalleVenta)dgv_detalle.CurrentRow.DataBoundItem;
                modeloVentaDetalle.Articulo = art.Articulo;
                modeloVentaDetalle.Cantidad = Convert.ToInt32(art.Cantidad);

                modeloVentaDetalle.RenglonID = art.RenglonID;
                MDetalleVenta detalle =
                    ListaDetallesSeleccionados.FirstOrDefault(x => x.ID == VentasSeleccionadas[PaginadoActual].ID);
                modeloVentaDetalle.Renglon = art.RenglonID * 2048;
                modeloVentaDetalle.Unidad = detalle.Unidad;
                string precioM = Convert.ToString(art.Precio);
                precioM = precioM.Replace("$", "");
                modeloVentaDetalle.Precio = Convert.ToDouble(precioM);
                modeloVentaDetalle.Costo = Convert.ToDouble(art.Costo);

                frm.model = modeloVentaDetalle;
                frm.canal = Convert.ToInt32(txt_Canal.Text);
                frm.IdVenta = VentasSeleccionadas[PaginadoActual].ID;
                frm.almacen = cb_Almacen.Text;
                frm.agente = txt_Agente.Text;
                frm.usrDescIncreLinea = true;
                frm.tipo = "UsrIncremento";
                frm.Text = "UsrIncremento";
                frm.TipoString = "Usuario Incremento";
                frm.ShowDialog();
                if (frm.Operacion)
                {
                    modeloVentaDetalle.TipoUsrDes_Incr = frm.tipo;
                    actualizaPrecioConDescuento(frm.precioActualizado);

                    foreach (ArticulosDetalleVenta Detalle in DatosDetalles)
                        if (Detalle.Articulo == art.Articulo)
                        {
                            ListaDetalles = new List<MDetalleVenta>();
                            DM0312_ExploradorVentas UsuarioAcceso = new DM0312_ExploradorVentas();
                            Detalle.Precio = Convert.ToString(modeloVentaDetalle.Precio);

                            //ListaDetallesSeleccionados[6] = modeloVentaDetalle.Precio;
                            //DM0312_DetalleVenta.ListaDetalles = new List<MDetalleVenta>();
                            //ListaDetallesSeleccionados = new List<MDetalleVenta>(ListaDetalles);
                            DM0312_C_ExploradorVenta ControladorExplora = new DM0312_C_ExploradorVenta();
                            ControladorExplora.ConsultaDetalle(ListaDetalles, VentasSeleccionadas[PaginadoActual].MovId,
                                VentasSeleccionadas[PaginadoActual].Mov, VentasSeleccionadas[PaginadoActual].ID);
                            ListaDetallesSeleccionados = new List<MDetalleVenta>(ListaDetalles);
                            Detalle_Load(null, null);
                            //this.Dispose();
                            //UsuarioAcceso.recibeDescuento = 1;
                        }

                    Detalle_Load(null, null);
                }
            }
            else
            {
                MessageBox.Show("Solo para pedidos y con estatus Sin afectar", "!Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnGuardarComentarios_Click(object sender, EventArgs e)
        {
            if (txt_Comentario.Text.Trim() == "")
                MessageBox.Show("Sin informacion que guardar, favor de ingresar un comentario", "!Informacion",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                CDetalleVenta.UpdateComentarios(VentasSeleccionadas[PaginadoActual].ID, txt_Comentario.Text.Trim());
        }

        public string obtenerMes(int mes)
        {
            string mmes = "";
            string[] ames = new string[12]
            {
                "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO",
                "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"
            };
            mmes = ames[mes - 1];
            return mmes;
        }

        #endregion
    }
}