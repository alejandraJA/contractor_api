﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Office.Interop.Excel;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Properties;
using PuntoVenta.ShmCubos;
using PuntoVenta.View;
using Application = Microsoft.Office.Interop.Excel.Application;
using Button = System.Windows.Forms.Button;
using DataTable = System.Data.DataTable;
using Label = System.Windows.Forms.Label;
using Point = System.Drawing.Point;
using Timer = System.Timers.Timer;

namespace PuntoVenta
{
    public partial class PuntoDeVenta : Form
    {
        private const string dominioMavi = "GENAV.MX";
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public static DM0312_CVentanaEntrada controladorEntrada = new DM0312_CVentanaEntrada();
        public static List<DM0312_MPuntoDeVentaCanales> listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
        public static List<string> datosEmpleado = new List<string>();
        public static List<string> datosCondicion = new List<string>();
        public static List<string> datosConcepto = new List<string>();
        public static List<string> datosFormaEnvio = new List<string>();
        public static List<string> datosFormaCobroLinea = new List<string>();
        public static string Codigo, Agente, Almacen, TipoMovimiento, AgenteTelefonico = "";
        public static int Canal, MuestraTelefono;
        public static string Alm = "";
        public static List<DM0312_MVentaDetalle> ListVentaDetalle;
        public static bool ActualizarAlmacen = false;
        public static bool exit;
        private static MValeDigital valeDigitalDatos = new MValeDigital();

        public static List<DM0312_MVentaDetalle> listaPromos;

        public string AgenteModificado;
        public string almacenModificado;
        private string almacenOrigen;
        private List<DM0312_MVentaDetalle> ArticulosIncluidos;
        private readonly Timer aTimer = new Timer();
        private int bandera;
        private double BanderaRecibidoMinimo;
        private List<DatosEntrega> BitacoraEntregas = new List<DatosEntrega>();
        private int canalC;
        public bool CancelEvent, verCosto;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool CerrarVenta = false;

        private readonly DM0312_C_CampoExtra cExtra = new DM0312_C_CampoExtra();
        private ClienteController clientC = new ClienteController();
        private bool ClienteC;

        private readonly ClienteController ClienteCon = new ClienteController();
        private bool ClienteNuevo;
        private readonly clsControladorPromociones clsControladorPromociones = new clsControladorPromociones();


        //-ValeDigital
        public string codigoValeDigital;
        private string componenteValidado = "";
        public string CondicionModificada;
        private int contadorClick;
        private readonly CDetalleVenta controladorD = new CDetalleVenta();

        private readonly CSerieArticulos ControladorSerie = new CSerieArticulos();
        private DM0312_C_UsuarioDescuentoIncremento controller = new DM0312_C_UsuarioDescuentoIncremento();

        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        //List<DM0312_MGarantias> GarantiasList = new List<DM0312_MGarantias>();

        private readonly DM0312_C_Promociones controllerPromociones = new DM0312_C_Promociones();
        private string correoCompleto = "";

        private readonly DM0312_C_UsuarioDescuentoIncremento CUsuarioDes = new DM0312_C_UsuarioDescuentoIncremento();
        private DataSet dataSet = new DataSet();
        private DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();

        //-921
        private double dImporte;
        private double dImpuestos;
        private int EnviarA, index, NumValidacion;
        private bool existe, obligatorio;
        private string Factura;
        public bool FlagEventosPuntoVenta = false;

        private readonly List<string> FormasPagoAgregadas = new List<string>();

        //entero para saber cuantas formas de pago existen
        private int FormasPagoTag;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();
        public string idEcommerceModificado;
        public int idVenta;
        public Image img;
        private readonly Dictionary<int, string> LastFormaPagoSelected = new Dictionary<int, string>();
        private readonly List<MAnticipos> ListaAnticipos = new List<MAnticipos>();
        private List<int> listaCatalogoCapturaTelefono;
        public List<string> ListaControles;

        private List<string> listaCteGenericos;
        public List<DM0312_MPuntoDeVentaCliente> listaEmpleados = new List<DM0312_MPuntoDeVentaCliente>();
        private List<MArticulosEditar> ListaModificada = new List<MArticulosEditar>();
        public List<DM0312_MComentariosVenta> ListaPuntoVenta;
        private List<DM0312_MPromociones> listPromociones = new List<DM0312_MPromociones>();

        private List<clsModeloPromocionDetalle> lsConfiguracion = new List<clsModeloPromocionDetalle>();
        public string mensajeBoton;
        public DM0312_MVentaDetalle modeloVentaDetalle;
        private bool monederoRedimir, comMayoreo, iva;
        private double montofijovale;
        public string Mov;
        public string MovID;
        private string MuestraCorreo;

        private string nomina = "",
            Cliente = "",
            Vendedor = "",
            Movimiento = "",
            Condicion = "",
            NoCtaPago = "",
            Observacion = "",
            Comentario = ""; //Datos para obtener el idVenta

        private readonly string Concepto = ""; //Datos para obtener el idVenta
        private string FormaPago = ""; //Datos para obtener el idVenta
        private readonly string Referencia = ""; //Datos para obtener el idVenta

        private string
            FormaEnvio = "",
            pedComer = "",
            custodia = "",
            imprimirComentario = "",
            formaPagoTipo = ""; //Datos para obtener el idVenta

        public bool NuevaEntrega;

        private bool obligatorioCliente,
            obligatorioAgente,
            obligatorioCanal,
            obligatorioAlmacen,
            obligatorioCorreo,
            obligatorioParticular,
            obligatorioMovil,
            obligatorioNomina;

        public string oldValue = string.Empty;
        private double RecibidoMinimo;
        public bool Refacturacion;
        private List<int> Respetar = new List<int>();
        private int resultadoGuardarCorreo, validaDominio;
        private string resultadoValidacion;
        private double saldoRestante, montoTotal;
        private readonly BuroDigitalClient shm = new BuroDigitalClient();

        private string sTipoDima = string.Empty;
        private double subtotal, impuesto;
        private DC_Tarjeta tipoCuenta = new DC_Tarjeta();
        private int tipoVale = 0;
        public double total;
        public int uen, vale = 1;
        private readonly AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
        public int valedigital = 0;
        public string ValidaEstatus, mensajeValidacion = "", categoria = "";
        private string validaMensajeBoton;
        public int valorModificado;
        public int ValorModificadoM = 0;
        private readonly VentaController ventaC = new VentaController();
        private DM0312_VentaEntrada VentaEntrar = new DM0312_VentaEntrada();
        private bool verificaGuardar;

        public PuntoDeVenta(string Cliente, int i, string factura = null)
        {
            InitializeComponent();
            idVenta = 0;
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);
            Codigo = Cliente;
            Canal = i;
            canalC = i;
            ListVentaDetalle = new List<DM0312_MVentaDetalle>();

            //ClaseEstatica.FormActivo = "PuntoDeVenta";
            MouseWheel += Wheel;

            listaPromos = new List<DM0312_MVentaDetalle>();
        }

        ~PuntoDeVenta()
        {
            GC.Collect();
        }

        /// <summary>
        ///     Method to fix focus on form and work with repainting
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">MouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/10/17
        private void Wheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                if (btn_Afectar.Visible || btn_situaciones.Visible)
                {
                    if (!dvg_detalleVenta.Focused) cbx_Canal.Focus();
                }
                else
                {
                    ComponentesFocus();
                }
            }
            else
            {
                if (btn_Afectar.Visible)
                {
                    if (!dvg_detalleVenta.Focused)
                        btn_Afectar.Focus();
                }
                else if (btn_situaciones.Visible)
                {
                    if (!dvg_detalleVenta.Focused)
                        btn_situaciones.Focus();
                }
                else if (txtSubTotal.Visible)
                {
                    ComponentesFocus();
                }
            }

            gbx_menuPuntoVenta.Location = new Point(3, 73);
            flp_promociones.Location = new Point(1057, 56);
            Panel_UsuarioEstatus.Location = new Point(829, 7);
            if (pictureBox4.Visible) pictureBox4.Location = new Point(0, 4);

            if (pictureBox5.Visible) pictureBox5.Location = new Point(12, -14);

            if (pictureBox7.Visible) pictureBox7.Location = new Point(6, -11);
        }

        private void PuntoDeVenta_Load(object sender, EventArgs e)
        {
            /////boton guardar////
            if (ClaseEstatica.Usuario.sucursal == 98)
                btnGuardar.Visible = true;
            else
                btnGuardar.Visible = false;
            //////////////////////
            listaCteGenericos = ClienteCon.getListaCteGenericos();
            listaCatalogoCapturaTelefono = ventaC.getCatalogoCapturaTelefono();
            valeDigitalDatos = new MValeDigital();
            //-Die
            //El check nace apagado, mas adelante validamos si se puede activar
            chx_Die.Visible = false;

            controladorEntrada.GuardarDomicilioActualCasa(Codigo);
            lbl_Alerta.Text = "FALTA VALIDAR HUELLA SID";
            btnImportExcel.Enabled = false;
            btnGuardar.Enabled = false;
            ListaControles = new List<string>();
            validaVistaFotosPromosion();

            //System.Timers.Timer aTimer = new System.Timers.Timer();
            //aTimer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent);
            //aTimer.Interval = 50000;
            //aTimer.Enabled = true;

            panelMontoVale.Visible = false;
            lb_montovale.Text = "$0.00";


            //verificaUpdateFoto();
            Hide();
            EditImagen();
            MenuVentaDetalle.Visible = false;

            //flag = false;
            lbl_Estatus.Text = ValidaEstatus;
            lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
            ListaPuntoVenta = Funciones.ConsultaComentario("Punto de Venta");


            //llenarGrid();
            //BtnAdd.Enabled = false;
            validaMensajeBoton = mensajeBoton;
            /////////////////////////////////////////////VALIDACION VISTA BOTONES VENTANA ENTRADA ///////////////////////////////////////////
            ActualizarComponentes();

            //-ValeDigital
            if (valedigital == 1)
            {
                valeDigitalDatos = ValeDigitalController.getDatosValeDQ(codigoValeDigital);
                valeDigital();
            }


            llenarGrid();
            BtnAdd.Enabled = false;
            modificaFormaBoton(validaMensajeBoton);
            CargaCliente();
            LlenaComboCanal();
            if (validaMensajeBoton == "Mayoreo") LlenaFormaDeEnvio();

            if (valorModificado == 1)
            {
                Agente = AgenteModificado;
                Almacen = almacenModificado;
                pedComer = idEcommerceModificado;
                txb_Ecommerce.Text = idEcommerceModificado;
                ListaModificada = controlador.ArticulosEditar(idVenta);
            }

            //-596AlmacenensVirtuales
            if (controladorD.validarSucursalAlmacenVirtual()) LlenaFormaDeCobroLinea();

            ConsultaAlmacen();
            ConsultaAgente();
            //LlenaFormaDeEnvio();
            LlenaListaCanalesCliente();
            ValidaCanal();
            if (existe != true) AgregaNuevoCanal();
            ValidaTelefono();
            ValidaCorreo();
            if (validaMensajeBoton == "Instituciones") MostrarNomina();

            estatusComponentes();

            if (valorModificado == 1)
            {
                cbx_Agente.Text = AgenteModificado;
                lbl_ID.Text = Convert.ToString(idVenta);
                txb_Ecommerce.Text = idEcommerceModificado;
                txt_Comentarios.Text = "Modificar el movimiento una vez terminado seleccionar el boton de guardar";

                ///////////////////////////////////////////////////

                List<AccesoUsuario> ListaAccesos =
                    AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
                if (ListaAccesos.FirstOrDefault(x => x.campo == pnlBtn_DatosEntrega.Name) == null)
                    pnlBtn_DatosEntrega.Visible = true;
                //pnlBtn_DatosEntrega.Focus();
                btn_eventosNotasCitA.Visible = true;

                if (validaMensajeBoton == "Dima" || validaMensajeBoton == "Credito" ||
                    validaMensajeBoton == "Instituciones") btn_CampoExtra.Visible = true;

                if (ListaAccesos.FirstOrDefault(x => x.campo == btn_Anticipo.Name) == null) btn_Anticipo.Visible = true;
                BtnAdd.Enabled = true;
                btnImportExcel.Enabled = true;
                if (PuedeAfectar())
                {
                    if (!CDetalleVenta.PuedeAfectar(ClaseEstatica.Usuario.usuario, "SINAFECTAR", "", TipoMovimiento))
                        btn_Afectar.Visible = false;
                    else
                        btn_Afectar.Visible = true;
                }
                else
                {
                    btn_situaciones.Visible = true;
                    btn_Anticipo.Visible = false;
                }

                gbx_VentaDima.Visible = false;
                if (gbx_VentaDima.Visible)
                    txt_DetalleInformacion.Text =
                        "Favor de ingresar los articulos que el cliente desea comprar, una vez ingresados pasar al apartado de venta dima";
                else
                    txt_DetalleInformacion.Text =
                        "Favor de ingresar los articulos que el cliente desea comprar, una vez ingresados dar clic si lo necesita al boton Datos de Entrega o al de " +
                        btn_Anticipo.Text + " al terminar genere su " + TipoMovimiento;
                //btn_DatosEntrega.Focus();
                txt_ComentariosDatosEntrega.Text = "";
                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(model);
                llenarGrid();
                //this.Visible = true;
                StartPosition = FormStartPosition.CenterScreen;
                //ValidaTelefono();
                if (contadorClick == 0) dvg_detalleVenta.Select();
                contadorClick++;

                foreach (MArticulosEditar item in ListaModificada)
                {
                    if (!BuscarArticulos(item.Codigo, false, item.Cantidad))
                    {
                        dvg_detalleVenta.CancelEdit();
                        //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                        ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                        DM0312_MVentaDetalle model1 = new DM0312_MVentaDetalle();
                        ListVentaDetalle.Add(model1);
                        llenarGrid();
                    }

                    if (!string.IsNullOrEmpty(item.sUsuarioDescuento))
                    {
                        DM0312_MVentaDetalle articulo = ListVentaDetalle.FirstOrDefault(x => x.Articulo == item.Codigo);
                        modeloVentaDetalle = articulo;

                        MessageBox.Show(
                            "El articulo " + item.Codigo + " cuenta con un descuento de $" + item.fPrecioAnterior +
                            " a $" + item.fPrecio + Environment.NewLine + "Favor de autorizar el descuento",
                            "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        DM0312_UsuarioDescuentoIncremento frm = new DM0312_UsuarioDescuentoIncremento();
                        frm.model = modeloVentaDetalle;
                        frm.canal = Convert.ToInt32(cbx_Canal.Text);
                        frm.IdVenta = idVenta;
                        frm.almacen = cbx_Almacen.Text;
                        frm.agente = cbx_Agente.Text;
                        frm.tipo = "UsrDescuento";
                        frm.Text = "UsrDescuento";
                        frm.TipoString = "Usuario Descuento";
                        frm.ShowDialog();
                        if (frm.Operacion)
                        {
                            modeloVentaDetalle.TipoUsrDes_Incr = frm.tipo;
                            modeloVentaDetalle.Precio = item.fPrecio;
                            modeloVentaDetalle.PrecioS = item.fPrecio.ToString();
                            modeloVentaDetalle.Total = item.fPrecio;
                            modeloVentaDetalle.TotalS = item.fPrecio.ToString();
                            actualizaPrecioConDescuento(frm.precioActualizado);
                        }
                        else
                        {
                            controlador.eliminarDescuento(idVenta, item.Codigo, item.iRenglon);
                            controlador.eliminarUsuarioDescuento(idVenta, item.iRenglon);
                        }
                    }
                }

                //-921
                List<string> listaInfo = controlador.obtenerInformacionCliente(idVenta);
                if (listaInfo[2] == "CUSTODIA") chk_Custodia.Checked = true;
                if (listaInfo[3] == "SI") chk_Comentario.Checked = true;
                if (listaInfo[4] == "1") chk_Mayoreo.Checked = true;
                if (!string.IsNullOrEmpty(listaInfo[8])) txt_Pago.Text = listaInfo[8];
                if (bool.Parse(listaInfo[9]))
                    chk_Iva.Checked = true;
                else
                    chk_Iva.Checked = false;

                cbx_Condicion.Text = listaInfo[6];
                cbx_FormaEnvio.Text = listaInfo[7];

                txt_Observaciones.Text = listaInfo[0];
                txt_Comentario.Text = listaInfo[1];
                cbx_AgenteServicio.Text = listaInfo[5];

                btn_situaciones.Visible = false;
                btn_Anticipo.Visible = false;
                btn_Afectar.Visible = false;
                pnlBtn_DatosEntrega.Visible = false;
                valorModificado = 0;
            }

            if (ClaseEstatica.Usuario.sucursal == 98)
            {
                if (string.IsNullOrEmpty(txt_Correo.Text)) cxb_SinCorreo.Checked = true;
                if (string.IsNullOrEmpty(txt_movil.Text)) cbx_TelMovil.Checked = true;
                if (string.IsNullOrEmpty(txt_TelParticular.Text)) cbx_TelParticular.Checked = true;
            }

            if (cbx_Cliente.Text != "" && cbx_Canal.Text != "" && cbx_Agente.Text != "" && cbx_Condicion.Text != "" &&
                cbx_Almacen.Text != "" && txt_Correo.Text != "" && txt_Correo2.Text != "" &&
                txt_TelParticular.Text != "" && txt_movil.Text != "")
            {
                dvg_detalleVenta.ReadOnly = true;
                ValidaVenta();
            }
            else
            {
                dvg_detalleVenta.ReadOnly = true;
            }


            //Agregar combobox y label de pago
            AgregarFormaPago();
            txt_anticipototal.Text = "0";


            if (TipoMovimiento == "Pedido") btn_Anticipo.Text = "Anticipo";
            if (TipoMovimiento == "Pedido Mayoreo") btn_Anticipo.Text = "Anticipo Mayoreo";
            if (TipoMovimiento == "Solicitud Credito") btn_Anticipo.Text = "Enganche";

            Show();
            ComponentesFocus();


            if (ClaseEstatica.Usuario.Uen == 3)
            {
                toolTip1.SetToolTip(pictureBox7, "MAVI DE OCCIDENTE");
                pictureBox5.Visible = false;
                pictureBox4.Visible = false;
            }
            else
            {
                if (ClaseEstatica.Usuario.Uen == 1)
                {
                    toolTip1.SetToolTip(pictureBox4, "MUEBLES AMERICA");
                    pictureBox5.Visible = false;
                    pictureBox7.Visible = false;
                }
                else
                {
                    if (ClaseEstatica.Usuario.Uen == 2)
                    {
                        toolTip1.SetToolTip(pictureBox5, "VIU");
                        pictureBox4.Visible = false;
                        pictureBox7.Visible = false;
                    }
                    else
                    {
                        toolTip1.SetToolTip(pictureBox4, "");
                        pictureBox5.Visible = false;
                        pictureBox7.Visible = false;
                    }
                }
            }

            ToolTip();

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_datosEntrega.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }

            string casaNuevo = controlador.validaCasa(Codigo, Canal);
            ClienteNuevo = casaNuevo != string.Empty && casaNuevo == "Nuevo" ? true : false;

            List<AccesoUsuario> ListaAccesos2 =
                AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
            if (ListaAccesos2.FirstOrDefault(x => x.campo == btnImportExcel.Name) == null)
                btnImportExcel.Visible = true;


            //-ValeElectronico
            if (valeDigitalDatos.tipo == 1 || valeDigitalDatos.tipo == 2) BtnAdd.Visible = false;

            //-ModuloPromociones
            if (!string.IsNullOrEmpty(Factura))
            {
                //cbx_Agente.Text = "E002247";
                cbx_Agente_DropDown(null, null);
                LlenaAgente();
                cbx_Agente_Validating(null, null);
                CargarPedidoPromocionVencida();
            }

            if (canalC == 76) sTipoDima = controlador.obtenerTipoDima(Codigo);

            frmArticulosPromocion.ListVentaDetalle = new List<DM0312_MVentaDetalle>();
            btn_MostrarAbonos.Visible =
                ClaseEstatica.Usuario.Usser.Substring(0, 4) == "VENT" && validaMensajeBoton == "Credito";
            txt_TelParticular.Visible = true;
            txt_movil.Visible = true;
            CapturaTelefono();
            if (txt_Correo2.Text == dominioMavi)
            {
                txt_Correo.Text = "";
                txt_Correo2.Text = "";
                txt_Correo.Enabled = true;
                txt_Correo2.Enabled = true;

                cxb_SinCorreo.Enabled = true;
                cxb_SinCorreo.Visible = true;
                cxb_SinCorreo.Checked = false;
            }

            if (!string.IsNullOrEmpty(txt_TelParticular.Text))
                cbx_TelParticular.Visible = false;
            else
                cbx_TelParticular.Visible = true;
        }

        private void CapturaTelefono()
        {
            if (txt_TelParticular.Text == "0000000000" && listaCatalogoCapturaTelefono.Contains(Canal))
            {
                txt_TelParticular.Enabled = true;
                txt_TelParticular.Visible = true;
            }

            if (txt_movil.Text == "0000000000" && listaCatalogoCapturaTelefono.Contains(Canal))
            {
                txt_movil.Text = "";
                txt_movil.Enabled = true;
                txt_movil.Visible = true;

                cbx_TelMovil.Visible = false;
                cbx_TelMovil.Checked = false;
            }
        }

        public void ToolTip()
        {
            toolTip1.SetToolTip(cbx_Cliente,
                "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA VENTA " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(txt_ClienteNombre, "NOMBRE DEL CLIENTE");
            toolTip1.SetToolTip(cbx_Agente, "VENDEDOR QUE REALIZA LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(cbx_Canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(cbx_Condicion, "PLAZO DE PAGO DE LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(cbx_Almacen, "ALMACÉN DONDE SE REALIZA LA VENTA DE" + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(txt_Pago, "CUENTA DE PAGO");
            toolTip1.SetToolTip(txt_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(txt_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(txt_Correo, "MUESTRA Y/O CAPTURA LA CUENTA DE CORREO ELECTRONICO");
            toolTip1.SetToolTip(txt_Correo2, "EXTENSION DEL CORREO COMO PUEDE SER HOTMAIL.COM,YAHOO.COM");
            toolTip1.SetToolTip(txt_TelParticular,
                "CAPTURAR EL TELÉFONO PARTICULAR DEL CLIENTE CON TODO Y LADA SI NO CUENTA CON UN NUMERO DE TELÉFONO CAPTURAR 10 VECES EL NUMERO 0");
            toolTip1.SetToolTip(txt_movil,
                "CAPTURAR EL TELÉFONO MÓVIL DEL CLIENTE CON TODO Y LADA SI NO CUENTA CON UN NUMERO DE TELÉFONO CAPTURAR 10 VECES EL NUMERO 0");
            toolTip1.SetToolTip(txb_Ecommerce, "FOLIO DEL PEDIDO REALIZADO VIA INTERNET");
            toolTip1.SetToolTip(txt_FormaPago, "CLAVE DEL METODO DE PAGO");
            toolTip1.SetToolTip(chk_Mayoreo,
                "AL ACTIVARSE GENERA 50 % DE COMISION AL AGENTE EXTERNO POR PRODUCTO COTIZADO");
            toolTip1.SetToolTip(chk_Custodia, "AL SELECCIONAR ESTE BOX INDICARA QUE LA MERCANCIA QUEDA EN RESGUARDO");
            toolTip1.SetToolTip(chk_Iva, "SI SE SELECCIONA MOSTRARA EL IVA DESGLOSADO EN LA FACTURA MAYOREO");
            toolTip1.SetToolTip(chk_Comentario, "IMPRIMIR COMENTARIO");
            toolTip1.SetToolTip(cbx_AgenteServicio, "AGENTE EXTERNO QUE REALIZO LA VENTA");
            toolTip1.SetToolTip(lbl_FormaEnvio, "FORMA EN QUE PAGARA EL CLIENTE");
            toolTip1.SetToolTip(cbx_RedimirM, "IMPORTE DE REDENCION EN LA CUENTA MONEDERO");
            toolTip1.SetToolTip(txt_Nomina, "INSERTA LA NOMINA DEL EMPLEADO AL CUAL LE VAS A REALIZAR LA VENTA");
            toolTip1.SetToolTip(lbl_Usuario, "USUARIO");
            toolTip1.SetToolTip(lbl_Estatus, "ESTATUS DE LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_ID, "ID DE LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_cliente,
                "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA VENTA " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_Agente, "VENDEDOR QUE REALIZA LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(lbl_condicion, "PLAZO DE PAGO DE LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_almacen, "ALMACÉN DONDE SE REALIZA LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_Pago, "CUENTA DE PAGO");
            toolTip1.SetToolTip(lbl_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_correo, "CORREO ELECTRONICO DEL CLIENTE");
            toolTip1.SetToolTip(lbl_TelPart, "TELEFONO PARTICULAR DEL CLIENTE");
            toolTip1.SetToolTip(lbl_TelMovil, "TELEFONO MOVIL DEL CLIENTE");
            toolTip1.SetToolTip(lbl_Ecommerce, "FOLIO DEL PEDIDO REALIZADO VIA INTERNET");
            toolTip1.SetToolTip(lbl_FormaPago, "CLAVE DEL METODO DE PAGO");
            toolTip1.SetToolTip(lbl_AgenteServicio, "AGENTE EXTERNO QUE REALIZO LA VENTA");
            toolTip1.SetToolTip(lbl_FormaEnvio, "FORMA EN QUE PAGARA EL CLIENTE");
            toolTip1.SetToolTip(lbl_Nomina, "NOMINA DEL EMPLEADO AL CUAL LE VAS A REALIZAR LA VENTA");

            toolTip1.SetToolTip(btn_Regresar, "CANCELAR VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(btnGuardar,
                "GUARDAR DETALLE DE LA VENTA DE " + validaMensajeBoton.ToUpper() +
                ", SI TIENE ALGUN ARTICULO CON PRECIO PROTEGIDO NO SE PODRA GUARDAR EL DETALLE");
            toolTip1.SetToolTip(btn_eventosNotasCitA,
                "HERRAMIENTA DE EVENTOS, NOTAS Y CITAS, EN LA QUE SE PUEDEN AGREGAR Y CONSULTAR");
            toolTip1.SetToolTip(btn_InformacionCliente, "INFORMACION IMPORTANTE DEL CLIENTE CON CUENTA: " + Codigo);
            toolTip1.SetToolTip(btn_ayuda, "AYUDA");
            toolTip1.SetToolTip(btn_CampoExtra,
                "SELECCIONAR SI SE NECESITA ACTUALIZAR LA INFORMACION PRINCIPAL DEL CLIENTE CON CUENTA: " + Codigo);

            toolTip1.SetToolTip(lbl_Promo, "PROMOCIONES DE LA VENTA DE " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(btnImportExcel,
                "IMPORTADOR DE ARTICULOS, CREAR UN ARCHIVO .XLSX EN EL AGREGAR ENCABEZADO QUE CONSTA DE: ARTICULO Y CANTIDAD");
            toolTip1.SetToolTip(BtnAdd, "SELECCIONAR PARA ABRIR EL CATALOGO DE ARTICULOS DEL ALMACEN SELECCIONADO");
            toolTip1.SetToolTip(lbl_subT, "SUBTOTAL DE LA VENTA DE: " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_Impuestos,
                "TOTAL DE IMPUESTOS QUE GENERA LA VENTA DE: " + validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(lbl_Total, "SUMA DEL SUBTOTAL Y DE LOS IMPUESTOS");

            toolTip1.SetToolTip(txt_vale, "NUMERO DEL VALE DE COMPRA DIMA");
            toolTip1.SetToolTip(txt_NIP, "NIP DE VENTA PERSONAL DEL CLIENTE DIMA, FAVOR DE SOLICITARLO");
            toolTip1.SetToolTip(btn_DatosEntrega,
                "HERRAMIENTA DONDE SE PUEDE AGREGAR UNA NUEVA O EXISTENTE DIRECCION DONDE SE ENTREGARA LA MERCANCIA QUE EL CLIENTE COMPRO");
            toolTip1.SetToolTip(btn_nuevaEntrega,
                "SELECCIONAR PARA AGRAGAR NUEVA DIRECCION DE ENTREGA DE LA MERCANCIA");
            toolTip1.SetToolTip(btn_guardar,
                "SELECCIONAR PARA QUE SE GUARDE LA DIRECCION DE ENTREGA AL FOLIO DE LA VENTA");
            toolTip1.SetToolTip(btn_Anticipo,
                "SELECCIONAR PARA REALIZAR UN " + btn_Anticipo.Text + " PARA LA VENTA DE: " +
                validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(btn_Afectar,
                "SI TIENE LOS DATOS CORRECTOS DEL CLIENTE CON CUENTA " + Codigo +
                " Y YA SELECCIONO ALGÚN ARTICULO PRESIONAR BOTÓN PARA SEGUIR PROCESO DE SU VENTA DE: " +
                validaMensajeBoton.ToUpper());
            toolTip1.SetToolTip(btn_situaciones,
                "SI TIENE LOS DATOS CORRECTOS Y YA SE AGREGO AL DETALLE LOS ARTICULOS A VENDER PRESIONAR BOTÓN PARA SEGUIR PROCESO DE SU VENTA DE: " +
                validaMensajeBoton.ToUpper());

            toolTip1.SetToolTip(cbx_TelMovil, "SIN TELEFONO MOVIL");
            toolTip1.SetToolTip(cbx_TelParticular, "SIN TELEFONO PARTICULAR");
        }

        /// <summary>
        ///     Valida la vista de las fotos por UEN
        ///     Developer: Victor Avila
        ///     Date: 17/11/2017
        /// </summary>
        private void validaVistaFotosPromosion()
        {
            listPromociones = controllerPromociones.FillImage();
            List<DM0312_MPromociones> promosion = listPromociones.ToList();
            if (ClaseEstatica.Usuario.Uen == 1)
            {
                List<DM0312_MPromociones> validaMA = promosion.Where(x => x.Uen == 1).ToList();

                if (validaMA != null)
                {
                    foreach (DM0312_MPromociones item in validaMA)
                    {
                        if (item.Imagen.Length == 1 && item.IdImagen == 1)
                        {
                            pictureBox1.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 1)
                        {
                            pictureBox1.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 1);
                            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 2)
                        {
                            pictureBox2.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 2)
                        {
                            pictureBox2.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 2);
                            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 3)
                        {
                            pictureBox3.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 3)
                        {
                            pictureBox3.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 3);
                            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 4)
                        {
                            pictureBox6.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 4)
                        {
                            pictureBox6.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 4);
                            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
                        }
                    }

                    lbl_Promo.Visible = false;
                    flp_promociones.Visible = false;


                    return;
                }
            }

            if (ClaseEstatica.Usuario.Uen == 2)
            {
                List<DM0312_MPromociones> validaVIU = promosion.Where(x => x.Uen == 2).ToList();

                if (validaVIU != null)
                    foreach (DM0312_MPromociones item in promosion)
                    {
                        if (item.Imagen.Length == 1 && item.IdImagen == 5)
                        {
                            pictureBox1.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 5)
                        {
                            pictureBox1.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 5);
                            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 6)
                        {
                            pictureBox2.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 6)
                        {
                            pictureBox2.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 6);
                            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 7)
                        {
                            pictureBox3.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 7)
                        {
                            pictureBox3.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 7);
                            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                        }

                        if (item.Imagen.Length == 1 && item.IdImagen == 8)
                        {
                            pictureBox6.Visible = false;
                        }
                        else if (item.Imagen.Length > 1 && item.IdImagen == 8)
                        {
                            pictureBox6.Image = controlador.FillImage(ClaseEstatica.Usuario.Uen, 8);
                            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
                        }
                    }
            }
        }

        private void dvg_detalleVenta_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                if (e.RowIndex != ListVentaDetalle.Count - 1)
                    e.Graphics.DrawImage(img, e.CellBounds.Left + 4, e.CellBounds.Top + 1, 25, 25);

                dvg_detalleVenta.Rows[e.RowIndex].Height = 28;

                dvg_detalleVenta.Columns[e.ColumnIndex].Width = 28;

                e.Handled = true;
            }
        }

        private bool GarantiasAdd(string garantia, int cantidad)
        {
            DM0312_MVentaDetalle g = ListVentaDetalle.Where(x => x.Articulo == garantia).FirstOrDefault();

            if (g != null)
            {
                Dictionary<double, double> item_ = new Dictionary<double, double>();
                g.Cantidad = g.Cantidad + cantidad;
                item_ = actualizaMovPorModel(g.Cantidad.ToString(), g);
                g.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());
                g.Total = Convert.ToDouble(item_.Values.FirstOrDefault());
            }

            return g != null;
        }

        private void Txt_MovilEntrega_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private bool checkCantidadGarantias(string garantia, double cantidad)
        {
            List<DM0312_MVentaDetalle> artligado = ListVentaDetalle.Where(x => x.Articulo_Ligado == garantia).ToList();

            DM0312_MVentaDetalle artgarantia = ListVentaDetalle.Where(x => x.Articulo == garantia).FirstOrDefault();

            int sum = 0;

            sum = artligado.Sum(c => c.Cantidad);

            int sumGa = artgarantia.Cantidad;

            if (sumGa <= sum)
                return true;
            return false;
        }

        private void ReadOnlyColumns(int ColumnIndex, bool Series = false)
        {
            //dvg_detalleVenta.ReadOnly = true;

            //-ChecarEstatusPedido
            string estatusAct = controladorD.EstatusActual(idVenta);

            if (estatusAct != ValidaEstatus)
            {
                MessageBox.Show("El movimiento ya ha sido afectado o esta en seguimiento por otro usuario.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //boton editar
            if (ColumnIndex == 0)
            {
                return;
                dvg_detalleVenta.Columns[0].ReadOnly = true;
                dvg_detalleVenta.ReadOnly = true;
                dvg_detalleVenta.BeginEdit(true);

                if (modeloVentaDetalle.Articulo == null)
                    return;


                //si es garantia
                if (modeloVentaDetalle.Articulo.Contains("GARA"))
                {
                    MessageBox.Show("No se puede editar una garantia", "Aviso..", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                //si no existe el articulo
                if (modeloVentaDetalle.Descripcion == null)
                {
                    MessageBox.Show("Debe Agregar un articulo primero");
                    return;
                }

                if (modeloVentaDetalle.Juego != null)
                {
                    MessageBox.Show("No se puede editar el articulo es parte de un paquete");
                    return;
                }

                DialogResult dialogResult_ =
                    MessageBox.Show(
                        "SI el articulo tiene garantias/paquetes/series, si lo Edita se eliminaran, ¿Desea Continuar?",
                        "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult_ == DialogResult.No) return;

                DM0312_CatalogoArticulos catalogo = new DM0312_CatalogoArticulos();
                catalogo.Rcliente = Codigo;
                catalogo.ShowDialog();

                if ((catalogo.idArticulo == null) | (catalogo.idArticulo == string.Empty))
                    return;

                oldValue = modeloVentaDetalle.Articulo;

                modeloVentaDetalle.Articulo = catalogo.idArticulo;


                if (!BuscarArticulos(catalogo.idArticulo, true))
                {
                    ResetOldValue(catalogo.idArticulo, 1);

                    dvg_detalleVenta.CancelEdit();
                    //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                    ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                    ListVentaDetalle.Add(model);
                    llenarGrid();
                }
            }

            //articulos
            if (ColumnIndex == 1)
            {
                dvg_detalleVenta.Columns[1].ReadOnly = false;
                dvg_detalleVenta.ReadOnly = false;
                return;
            }

            //si ya tiene un modelo cantidad se puede editar
            if (modeloVentaDetalle.Articulo != null)
            {
                dvg_detalleVenta.Columns[2].ReadOnly = false;
                dvg_detalleVenta.Columns[5].ReadOnly = false;
                dvg_detalleVenta.Columns[8].ReadOnly = false;
                dvg_detalleVenta.ReadOnly = false;

                dvg_detalleVenta.Columns[6].ReadOnly = true;
                dvg_detalleVenta.Columns[4].ReadOnly = true;
                dvg_detalleVenta.Columns[3].ReadOnly = true;
                dvg_detalleVenta.Columns[7].ReadOnly = true;

                llenarLabels(modeloVentaDetalle);
            }
            else
            {
                dvg_detalleVenta.ReadOnly = true;
                dvg_detalleVenta.Columns[1].ReadOnly = false;
            }

            if (Series)
                //Serie
                if (ColumnIndex == 7)
                {
                    if (modeloVentaDetalle != null)
                    {
                        dvg_detalleVenta.Columns[7].ReadOnly = true;
                        dvg_detalleVenta.ReadOnly = true;

                        if (modeloVentaDetalle.Articulo != null)
                        {
                            if (modeloVentaDetalle.Disponible > 0)
                            {
                                ClaseEstatica.FormActivo = "PuntoDeVenta";
                                string serie = string.Empty;
                                serie = llenarSeries(modeloVentaDetalle);
                                if (serie != modeloVentaDetalle.Serie)
                                    controlador.DeleteSeriesLotes(modeloVentaDetalle.Serie, idVenta,
                                        modeloVentaDetalle.Articulo);
                                modeloVentaDetalle.Serie = serie;
                                //llenarGrid(); 
                                ClaseEstatica.FormActivo = string.Empty;
                            }
                            else
                            {
                                MessageBox.Show("No tienes series disponibles", "Error!", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                            }
                        }
                    }

                    dvg_detalleVenta.EndEdit();

                    llenarGrid();
                }
        }

        public void VerCosto()
        {
            bool res_ = false;
            List<string> TipoMovs = new List<string>();

            if ((AccesosDeUsuario.CUsuario.BloquearCostos == false) & AccesosDeUsuario.CUsuario.Costos)
            {
                TipoMovs = controlador.GetTiposMov();

                if (TipoMovs.Contains(TipoMovimiento))
                    res_ = true;
            }

            verCosto = res_;
        }


        #region botonGuardar

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (ValorModificadoM == 1)
            {
                verificaGuardar = false;

                //controlador.ArticulosEliminar(idVenta);
                if (guardarArticulos())
                {
                    //-PedidoSinDetalle
                    std.insertarIdVenta(idVenta, 1);
                    DialogResult dialogResult2 =
                        MessageBox.Show("Articulos guardados con exito, ¿Desea terminar de editar el movimiento? ",
                            "Exito en la operacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult2 == DialogResult.Yes)
                    {
                        idVenta = 0;
                        Dispose();
                    }
                    else
                    {
                        verificaGuardar = true;
                    }

                    verificaGuardar = true;
                }
            }
            else
            {
                if (Canal == 3 || canalC == 7)
                    // 1030/1061 NO DIMA GESSY Codigo Recomendado Valida canal 3 y 7
                    /*if (chx_CodigoRecomendado.Checked)
                    {
                        if (!validaExisteCodigoRecomendatoDima(txt_CodigoRecomendadoDima.Text))
                        {
                            customMessageCodigoRecomendado("Código Recomendado Inexistente", "Advertencia!!", "alert");
                            return;
                        }
                    }*/
                    if (controladorEntrada.validaVentasFinalesInternet(Codigo) == "NO")
                        if (std.realizarValidacion())
                        {
                            string TipoCredito = controllerExplorador.TipoCredito(Codigo);

                            int iSuc = std.obtenerSucursal(Codigo);

                            if (std.validarMx(TipoCredito))
                                if (iSuc != ClaseEstatica.Usuario.sucursal)
                                    if (!std.validarSucursalVentaEnLinea())
                                    {
                                        MessageBox.Show(
                                            "No es posible realizar la reactivación de movimientos en las sucursales no correspondientes.",
                                            "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }
                        }

                //if (Canal == 3 || canalC == 7)
                //{
                //    if (controladorEntrada.validaVentasFinalesInternet(Codigo) == "NO")
                //    {
                //        string TipoCredito = controllerExplorador.TipoCredito(Codigo);
                //        if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                //        {
                //            if (TipoCredito != "9")
                //            {
                //                MessageBox.Show("No es posible realizar la reactivación de movimientos en las sucursales no correspondientes.", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //                return;
                //            }
                //        }
                //        else
                //        {
                //            if (TipoCredito == "9")
                //            {
                //                MessageBox.Show("No es posible realizar la reactivación de movimientos en las sucursales no correspondientes.", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //                return;
                //            }
                //        }
                //    }
                //}

                verificaGuardar = false;
                DialogResult dialogResult = MessageBox.Show("¿Esta Seguro de Guardar los articulos del Detalle?",
                    "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    if (guardarArticulos())
                    {
                        std.insertarIdVenta(idVenta, 1);
                        MessageBox.Show("Articulos Guardados con Exito", "Exito en la operación", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }

                    verificaGuardar = true;
                }
            }
        }

        #endregion

        private void txb_Ecommerce_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text ||
                                      pedComer != txb_Ecommerce.Text))
                ActualizarInfoIdVenta();
        }

        private void txt_Pago_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text ||
                                      pedComer != txb_Ecommerce.Text))
                ActualizarInfoIdVenta();
        }

        private void cbx_AgenteServicio_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false)
            {
                mensajeValidacion = "";
                ValidaAgenteServicio();
                if (lbl_ID.Text == "")
                {
                    componenteValidado = "Agente Servicio";
                    ValidacionComponentes(componenteValidado);
                }

                if (cbx_AgenteServicio.Text == cbx_Agente.Text && cbx_Agente.Text != "")
                {
                    MessageBox.Show("El Agente Telefonico es incorrecto no puede ser igual al agente de la venta",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    cbx_AgenteServicio.Text = "";
                }
            }
        }

        private void cbx_AgenteServicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";

                componenteValidado = "Agente Servicio";
                ValidacionComponentes(componenteValidado);

                ComponentesFocus();
                if (cbx_AgenteServicio.Text == cbx_Agente.Text && cbx_Agente.Text != "")
                {
                    MessageBox.Show("El Agente Telefonico es incorrecto no puede ser igual al agente de la venta",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cbx_AgenteServicio.Text = "";
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dvg_detalleVenta_Paint(object sender, PaintEventArgs e)
        {
        }

        private void cbx_Cliente_DrawItem(object sender, DrawItemEventArgs e)
        {
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //if (backgroundWorker1.IsBusy)
            //{

            //}
        }

        private void dvg_detalleVenta_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            if (dvg_detalleVenta.Rows[e.RowIndex].Cells["Juego"].Value != null)
                foreach (DataGridViewCell cell in dvg_detalleVenta.Rows[e.RowIndex].Cells)
                {
                    cell.Style.ForeColor = Color.DimGray;

                    cell.Style.SelectionForeColor = Color.LightGray;
                }
        }

        private void PuntoDeVenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (lbl_ID.Text != "")
                {
                    if (verificaGuardar)
                    {
                        if (MessageBox.Show("Seguro que desea salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            idVenta = 0;
                            Dispose();
                        }
                    }
                    else
                    {
                        if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            //EliminarId();
                            //EliminarVentaD();
                            idVenta = 0;
                            Dispose();
                        }
                    }
                }
                else
                {
                    Dispose();
                }
            }

            if (e.Control && e.KeyCode == Keys.S) btn_Selp_Click(sender, e);

            if (e.Control && e.KeyCode == Keys.I)
                if (btn_InformacionCliente.Visible)
                    try
                    {
                        refrescarCanalCliente();
                        if (obligatorioCanal && obligatorioCliente)
                        {
                            if (string.IsNullOrEmpty(cbx_Cliente.Text))
                            {
                                MessageBox.Show("Ingrese un Cliente", "Advertencia", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                            }
                            else
                            {
                                if (controlador.ValidarCliente(cbx_Cliente.Text) == "NO")
                                {
                                    MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                    cbx_Cliente.Focus();
                                }
                                else
                                {
                                    InformacionCliente infoCliente = new InformacionCliente();
                                    infoCliente.mensaje = cbx_Cliente.Text;
                                    infoCliente.Show();
                                }
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }

            //if (e.Control && e.KeyCode == Keys.G)
            //{
            //    if (btnGuardar.Visible)
            //    {
            //        verificaGuardar = false;
            //        DialogResult dialogResult = MessageBox.Show("¿Esta Seguro de Guardar los articulos del Detalle?", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //        if (dialogResult == DialogResult.Yes)
            //        {
            //            if (guardarArticulos())
            //                MessageBox.Show("Articulos Guardados con Exito", "Exito en la operación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //            verificaGuardar = true;
            //        }
            //    }
            //}

            if (e.Control && e.KeyCode == Keys.E)
                if (btn_eventosNotasCitA.Visible)
                {
                    refrescarCanalCliente();
                    if (obligatorioCanal && obligatorioCliente)
                        if (FlagEventosPuntoVenta)
                        {
                            if (controlador.ValidarCliente(cbx_Cliente.Text) == "NO")
                            {
                                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                                cbx_Cliente.Focus();
                            }
                            else
                            {
                                DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
                                //         DM0312_EventosNotasCitas.recibeCliente = Codigo;
                                DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(idVenta);
                                DM0312_EventosNotasCitas.recibeUsuario = ClaseEstatica.Usuario.Usser;
                                DM0312_EventosNotasCitas.recibeMov = TipoMovimiento;
                                DM0312_EventosNotasCitas.recibeEstatus = ValidaEstatus;
                                DM0312_EventosNotasCitas.recibeCliente = Cliente;

                                //-Revision de Procesos 2019-05-28
                                //eventNotaCita.ShowDialog();
                                eventNotaCita.Show();
                            }
                        }
                }

            if (e.Control && e.KeyCode == Keys.F8)
                if (btn_CampoExtra.Visible)
                    CamposExtras();

            if (e.Control && e.KeyCode == Keys.A)
                if (btn_InfoArt.Visible)
                    if (modeloVentaDetalle.Articulo != null)
                    {
                        DM0312_DetalleInformacionArticulo.ArticuloSeleccionado = modeloVentaDetalle.Articulo;
                        DM0312_DetalleInformacionArticulo infoArt = new DM0312_DetalleInformacionArticulo();
                        if (modeloVentaDetalle.Tipo == "Juego")
                        {
                            infoArt.EsPaquete = true;
                            infoArt.DetallesPaquete =
                                ListVentaDetalle.Where
                                    (x => x.Articulo_Ligado == modeloVentaDetalle.Articulo && x.Juego != null).Select
                                (x => new ArticulosDetalleVenta
                                {
                                    Articulo = x.Articulo
                                }).ToList();
                        }

                        TopMost = false;
                        infoArt.ShowDialog();
                    }

            if (e.Control && e.KeyCode == Keys.F)
                if (btn_Afectar.Visible)
                    AfectarF();
        }

        private void cxb_SinCorreo_CheckedChanged(object sender, EventArgs e)
        {
            txt_Correo.Text = cxb_SinCorreo.Checked ? "SINCORREO" : string.Empty;
            txt_Correo2.Text = cxb_SinCorreo.Checked ? "SINCORREO.COM" : string.Empty;
            ValidacionInsertarCorreo();
            if (obligatorioCorreo && string.IsNullOrEmpty(lbl_ID.Text))
            {
                componenteValidado = "Correo";
                ValidacionComponentes(componenteValidado);
            }

            if (cxb_SinCorreo.Checked)
                ComponentesFocus();
            if (cxb_SinCorreo.Checked)
            {
                txt_Correo.Text = "SINCORREO";
                txt_Correo2.Text = "SINCORREO.COM";

                ValidacionInsertarCorreo();
                if (obligatorioCorreo && string.IsNullOrEmpty(lbl_ID.Text))
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }

                ComponentesFocus();
            }
            else
            {
                txt_Correo.Text = "";
                txt_Correo2.Text = "";

                ValidacionInsertarCorreo();
                if (obligatorioCorreo && string.IsNullOrEmpty(lbl_ID.Text))
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void btn_Selp_Click(object sender, EventArgs e)
        {
            refrescarCanalCliente();
            if (obligatorioCanal && obligatorioCliente)
                try
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + "\\SELP\\SELPDesktop.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.Usuario.Acceso +
                                                  " " + ClaseEstatica.Usuario.Uen + " " +
                                                  ClaseEstatica.Usuario.Sucursal;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.Dispose();
                }
                catch (Exception exception)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType?.Name, exception);
                    throw new Exception(
                        "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                        MethodBase.GetCurrentMethod().Name + "\nMessage:" + exception.Message, exception);
                }
        }


        private void cbx_TelMovil_CheckedChanged(object sender, EventArgs e)
        {
            if (cbx_TelMovil.Checked)
            {
                txt_movil.Text = "0000000000";

                telefonocorrectoMovil(txt_movil.Text);
                if (obligatorioMovil)
                {
                    componenteValidado = "Movil";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioMovil) ComponentesFocus();
            }
            else if (cbx_TelMovil.Focused)
            {
                txt_movil.Text = "";
                telefonocorrectoMovil(txt_movil.Text);
                if (obligatorioMovil)
                {
                    componenteValidado = "Movil";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioMovil) ComponentesFocus();
            }
        }


        private void cbx_TelParticular_CheckedChanged(object sender, EventArgs e)
        {
            if (cbx_TelParticular.Checked)
            {
                txt_TelParticular.Text = "0000000000";

                telefonocorrectoParticular(txt_TelParticular.Text);
                if (obligatorioParticular)
                {
                    componenteValidado = "Particular";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioParticular) ComponentesFocus();
            }
            else if (cbx_TelParticular.Focused)
            {
                txt_TelParticular.Text = "";
                telefonocorrectoParticular(txt_TelParticular.Text);
                if (obligatorioParticular)
                {
                    componenteValidado = "Particular";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioParticular) ComponentesFocus();
            }
        }


        private void txb_Ecommerce_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_FormaPago_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_Pago_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_FormaCo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarInfoIdVenta();
        }

        private void txt_vale_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void chx_Die_CheckedChanged(object sender, EventArgs e)
        {
            if (chx_Die.Checked)
            {
                if (idVenta != 0)
                {
                    controlador.updateDieVenta(idVenta, chx_Die.Checked);
                    if (chkTransferencia.Checked)
                    {
                        chkTransferencia.Checked = false;
                        txtCuentaClabe.Text = string.Empty;
                        txtBanco.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
            else
            {
                if (idVenta != 0)
                {
                    controlador.updateDieVenta(idVenta, chx_Die.Checked);
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chx_Die.Checked = false;
                }
            }
        }

        //LlenaCondicion
        private void valeDigital()
        {
            //tipoVale = modo;

            cbx_Cliente.Enabled = false;
            txt_ClienteNombre.Enabled = false;
            cbx_Canal.Enabled = false;
            cbx_Almacen.Enabled = false;
            dvg_detalleVenta.Visible = true;
            txt_vale.Text = valeDigitalDatos.vale;
            txt_vale.Enabled = false;

            txt_NIP.Text = ValeDigitalController.getNipCliente(valeDigitalDatos.cliente);
            txt_NIP.Enabled = false;
            cbx_Condicion.Enabled = false;
        }


        private void cargarPedidoValeDigital(int modo)
        {
            double montofijo = 0;
            string condicion = valeDigitalDatos.condicion;

            switch (modo)
            {
                case 1: //Productos

                    cbx_Condicion.Text = condicion;
                    //cbx_Condicion.SelectedValue = condicion;

                    //obtener articulos
                    string[] articulos = ValeDigitalController.getProductosVale(valeDigitalDatos.id_vale).ToArray();
                    //string[] articulos = { "goa" };

                    foreach (string sku in articulos)
                        if (!BuscarArticulos(sku, false))
                        {
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                            ListVentaDetalle.Add(model);
                        }

                    dvg_detalleVenta.Enabled = false;

                    break;

                case 2: //Credilana

                    //obtener articulos
                    string[] credilana = ValeDigitalController.getProductosVale(valeDigitalDatos.id_vale).ToArray();

                    foreach (string sku in credilana)
                        if (!BuscarArticulos(sku, false))
                        {
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                            ListVentaDetalle.Add(model);
                        }

                    dvg_detalleVenta.Enabled = false;

                    break;

                case 3: //MontoFIjo

                    montofijo = valeDigitalDatos.total;
                    montofijovale = montofijo;
                    panelMontoVale.Visible = true;
                    lb_montovale.Text = montofijo.ToString("C", Thread.CurrentThread.CurrentCulture);

                    break;
            }

            // GESSY 1601
            if (valeDigitalDatos.PuntosRedimidos > 0)
            {
                cbx_RedimirM.Checked = valeDigitalDatos.PuntosRedimidos > 0.0;

                lbl_MonederoARedimir.Text = valeDigitalDatos.PuntosRedimidos > 0.00
                    ? "Monedero a Redimir: $" + valeDigitalDatos.PuntosRedimidos
                    : "Monedero a Redimir: $0.00";

                lbl_MonederoARedimir.Visible = true;
                cbx_RedimirM.Checked = true;
            }
        }

        //1832
        private void ValidarArticuloPequeno()
        {
            if (ListVentaDetalle != null)
                for (int i = 0; i < ListVentaDetalle.Count; i++)
                {
                    ListVentaDetalle[i].ArticuloPequeno =
                        ListVentaDetalle[i].CantidadEscaneado != ListVentaDetalle[i].Cantidad &&
                        ListVentaDetalle[i].ArticuloPequeno != null
                            ? null
                            : ListVentaDetalle[i].ArticuloPequeno;

                    if (ListVentaDetalle[i].Articulo != null && ListVentaDetalle[i].ArticuloPequeno == null)
                    {
                        ListVentaDetalle[i].ArticuloPequeno = controladorD.EsArticuloPequeno(
                            ClaseEstatica.Usuario.Sucursal, ListVentaDetalle[i].Articulo,
                            ListVentaDetalle[i].Disponible);

                        if (ListVentaDetalle[i].ArticuloPequeno ?? true)
                            while (ListVentaDetalle[i].CantidadEscaneado < ListVentaDetalle[i].Cantidad)
                            {
                                EscanearArticuloPequeno frmEscanearArticulo =
                                    new EscanearArticuloPequeno(ListVentaDetalle[i].Articulo);
                                frmEscanearArticulo.ShowDialog();
                                ListVentaDetalle[i].CantidadEscaneado = ListVentaDetalle[i].CantidadEscaneado +
                                                                        (frmEscanearArticulo.DialogResult ==
                                                                         DialogResult.OK
                                                                            ? 1
                                                                            : 0);
                            }
                    }
                }
        }

        private void btnCuentaClabe_Click(object sender, EventArgs e)
        {
            string ctaCliente = cbx_Cliente.Text;

            if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
            {
                Process System = new Process();
                System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                System.StartInfo.Verb = "runas";
                System.StartInfo.Arguments = "ACTUALIZARCUENTABANCARIA " + ctaCliente + " " + idVenta + " " +
                                             ClaseEstatica.Usuario.usuario;
                System.StartInfo.UseShellExecute = false;
                System.Start();
                System.WaitForExit();

                tipoCuenta = shm.ObtenerInfoCLABE(ctaCliente);
                if (!string.IsNullOrEmpty(tipoCuenta.sTipo))
                {
                    txtBanco.Text = tipoCuenta.sBanco;

                    if (tipoCuenta.sTipo != "Cuenta CLABE")
                        txtCuentaClabe.Text = "****-****-****-" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                    else
                        txtCuentaClabe.Text = "****-****-****-**" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                }
            }
        }

        #region "METODOS"

        #region //-1030/1061

        /// <summary>
        ///     MensajeCustom Para codigo Recomendado
        /// </summary>
        /// <param name="Body">string</param>
        /// <param name="Tittle">string</param>
        /// <param name="Icon">string</param>
        /// Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// 1030/1061 DIMA GESSY
        public void customMessageCodigoRecomendado(string Body, string Tittle, string Icon)
        {
            using (Form form = new Form())
            {
                form.Text = Tittle;
                form.Size = new Size(293, 140);
                form.ControlBox = false;

                Label lbl_img = new Label();
                Button btn_aceptar = new Button();

                switch (Icon)
                {
                    case "check":
                        lbl_img.Image = Resources.check1;
                        Button btn_cancelar = new Button();
                        btn_cancelar.Text = "Cancelar";
                        btn_cancelar.TabIndex = 1;
                        btn_cancelar.Name = "btn_cancelar";
                        btn_cancelar.Location = new Point(179, 70);
                        btn_cancelar.Size = new Size(86, 20);
                        btn_cancelar.UseVisualStyleBackColor = true;
                        btn_cancelar.Click += (send, args) =>
                        {
                            txt_CodigoRecomendadoDima.ReadOnly = false;
                            txt_CodigoRecomendadoDima.Text = "";
                            form.Close();
                        };

                        btn_aceptar.Text = "Aceptar";
                        btn_aceptar.TabIndex = 0;
                        btn_aceptar.Name = "btn_Aceptar";
                        btn_aceptar.Location = new Point(12, 70);
                        btn_aceptar.Size = new Size(86, 20);
                        btn_aceptar.UseVisualStyleBackColor = true;
                        btn_aceptar.Click += (send, args) =>
                        {
                            txt_CodigoRecomendadoDima.ReadOnly = true;
                            form.Close();
                        };
                        form.Controls.Add(btn_cancelar);
                        break;
                    case "alert":
                        lbl_img.Image = Resources.alert1;

                        btn_aceptar.Text = "Aceptar";
                        btn_aceptar.TabIndex = 0;
                        btn_aceptar.Name = "btn_Aceptar";
                        btn_aceptar.Location = new Point(12, 70);
                        btn_aceptar.Size = new Size(86, 20);
                        btn_aceptar.UseVisualStyleBackColor = true;
                        btn_aceptar.Click += (send, args) =>
                        {
                            txt_CodigoRecomendadoDima.ReadOnly = false;
                            txt_CodigoRecomendadoDima.Text = "";
                            form.Close();
                        };

                        break;
                }

                form.StartPosition = FormStartPosition.CenterScreen;

                lbl_img.Text = null;
                lbl_img.TabIndex = 0;
                lbl_img.Size = new Size(58, 58);
                lbl_img.Location = new Point(12, 9);

                Label lbl_msg = new Label();
                lbl_msg.Text = Body;
                lbl_msg.TabIndex = 0;
                lbl_msg.Size = new Size(189, 58);
                lbl_msg.Location = new Point(76, 9);

                form.Controls.Add(lbl_img);
                form.Controls.Add(lbl_msg);
                form.Controls.Add(btn_aceptar);

                form.ShowDialog();
            }
        }

        /// <summary>
        ///     Valida la existencia en base de datos del codigo recomendado
        /// </summary>
        /// <param name="CodigoDimr">string</param>
        /// <returns>retorna un true al encontrar resultados</returns>
        /// Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// 1030/1061 DIMA
        private bool validaExisteCodigoRecomendatoDima(string CodigoDimr)
        {
            //1442 las validaciones en Base de Datos van a cambiar por cambios en el funcionamiento de codigo recomendado

            bool validaExiste = false;
            if (validarCodigoRecomendadoRegex(CodigoDimr))
            {
                List<string> DatosCliente = new List<string>();
                if (controlador.validarCodigoYCanal(txt_CodigoRecomendadoDima.Text, canalC))
                    DatosCliente = controlador.encontrarCteCodigoDimr(CodigoDimr);
                if (DatosCliente.Count >= 1) validaExiste = true;
                if (controlador.CodigoRecomendadoExistente(CodigoDimr, cbx_Cliente.Text)) validaExiste = true;
            }

            return validaExiste;
        }

        /// <summary>
        ///     Valida Formato de Codigo Recomendado
        /// </summary>
        /// <param name="CodigoDimr">string</param>
        /// <returns>retorna un true al match</returns>
        /// <author>Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ</author>
        /// 1030/1061 DIMA
        private bool validarCodigoRecomendadoRegex(string CodigoDimr)
        {
            // 1442
            Regex rgx = new Regex(@"^(MA0|VIU)[\d]{8,8}$");
            return rgx.IsMatch(CodigoDimr);
        }

        private bool validarCodigoRecomendado7y3Regex(string CodigoDimr)
        {
            Regex rgx = new Regex(@"^[\w]{5,5}$");
            if (rgx.IsMatch(CodigoDimr)) return true;

            return false;
        }

        #endregion

        #region "COMPONENTES VALIDACIONES"

        private void estatusComponentes()
        {
            if (cbx_Cliente.Text != "")
                obligatorioCliente = true;
            else
                obligatorioCliente = false;
            if (cbx_Canal.Text != "")
                obligatorioCanal = true;
            else
                obligatorioCanal = false;
            if (cbx_Agente.Text != "")
                obligatorioAgente = true;
            else
                obligatorioAgente = false;
            if (cbx_Almacen.Text != "")
                obligatorioAlmacen = true;
            else
                obligatorioAlmacen = false;
            if (txt_Correo.Text != "" || MuestraCorreo == "NO")
                obligatorioCorreo = true;
            else
                obligatorioCorreo = false;
            if (txt_Correo2.Text != "")
                obligatorioCorreo = true;
            else
                obligatorioCorreo = false;
            if (txt_TelParticular.Text != "")
                obligatorioParticular = true;
            else
                obligatorioParticular = false;
            if (txt_movil.Text != "")
                obligatorioMovil = true;
            else
                obligatorioMovil = false;

            if (txt_Nomina.Text != "")
                obligatorioNomina = true;
            else
                obligatorioNomina = false;
        }

        private void ValidacionComponentes(string componente)
        {
            ValidaCamposObligatorios2(componente);

            try
            {
                if (!obligatorio)
                {
                    if (controlador.ValidarClienteGenerico(Codigo) != "NO"
                        && obligatorioCliente && obligatorioAgente && obligatorioCanal && obligatorioAlmacen)
                    {
                        ValidaVenta();
                    }
                    else
                    {
                        if (mensajeBoton == "Instituciones"
                            && obligatorioCliente && obligatorioAgente && obligatorioCanal && obligatorioAlmacen &&
                            obligatorioCorreo && obligatorioParticular && obligatorioMovil && obligatorioNomina)
                            ValidaVenta();
                        else if (obligatorioCliente & obligatorioAgente && obligatorioCanal &&
                                 obligatorioAlmacen & obligatorioCorreo && obligatorioParticular && obligatorioMovil)
                            ValidaVenta();
                    }
                }

                dvg_detalleVenta.ReadOnly = true;
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }
        }

        private void ComponentesFocus()
        {
            if (string.IsNullOrEmpty(cbx_Cliente.Text))
            {
                cbx_Cliente.Focus();
                cbx_Cliente.Select();
            }
            else if (string.IsNullOrEmpty(cbx_Agente.Text))
            {
                cbx_Agente.Focus();
                cbx_Agente.Select();
            }
            else if (string.IsNullOrEmpty(cbx_Canal.Text))
            {
                cbx_Canal.Focus();
                cbx_Canal.Select();
            }
            else if (string.IsNullOrEmpty(cbx_Almacen.Text))
            {
                cbx_Almacen.Focus();
                cbx_Almacen.Select();
            }
            else if (string.IsNullOrEmpty(txt_Correo.Text) && txt_Correo.Enabled)
            {
                txt_Correo.Focus();
            }
            else if (string.IsNullOrEmpty(txt_Correo2.Text) && txt_Correo2.Enabled)
            {
                txt_Correo2.Focus();
                txt_Correo2.Select();
            }
            else if (string.IsNullOrEmpty(txt_TelParticular.Text) && txt_TelParticular.Enabled)
            {
                txt_TelParticular.Focus();
                txt_TelParticular.Select();
            }
            else if (string.IsNullOrEmpty(txt_movil.Text) && txt_movil.Enabled)
            {
                txt_movil.Focus();
                txt_movil.Select();
            }
            else if (string.IsNullOrEmpty(txt_Nomina.Text) && txt_Nomina.Visible)
            {
                txt_Nomina.Focus();
                txt_Nomina.Select();
            }
            else if (string.IsNullOrEmpty(txb_Ecommerce.Text) && txb_Ecommerce.Visible)
            {
                txb_Ecommerce.Focus();
                txb_Ecommerce.Select();
            }
            else if (string.IsNullOrEmpty(txt_FormaPago.Text) && txt_FormaPago.Visible)
            {
                txt_FormaPago.Focus();
                txt_FormaPago.Select();
            }
            else if (string.IsNullOrEmpty(cbx_AgenteServicio.Text) && cbx_AgenteServicio.Visible)
            {
                cbx_AgenteServicio.Focus();
                cbx_AgenteServicio.Select();
            }
            else if (string.IsNullOrEmpty(cbx_FormaEnvio.Text) && cbx_FormaEnvio.Visible)
            {
                cbx_FormaEnvio.Focus();
                cbx_FormaEnvio.Select();
            }
            else if (string.IsNullOrEmpty(txt_Pago.Text) && txt_Pago.Visible)
            {
                txt_Pago.Focus();
                txt_Pago.Select();
            }
            else if (string.IsNullOrEmpty(txt_Observaciones.Text) && txt_Observaciones.Visible)
            {
                txt_Observaciones.Focus();
                txt_Observaciones.Select();
            }
            else if (string.IsNullOrEmpty(txt_Comentario.Text) && txt_Comentario.Visible)
            {
                txt_Comentario.Focus();
                txt_Observaciones.Select();
            }
        }


        public void ActualizarComponentes()
        {
            lbl_FormaCo.Visible = false;
            txt_FormaCo.Visible = false;
            cbx_TelMovil.Visible = false;
            cbx_TelParticular.Visible = false;
            btn_InfoArt.Visible = false;
            lbl_Alerta.Visible = false;
            flowLayoutPanel1.Visible = false;
            btn_CampoExtra.Visible = false;
            txt_Nomina.Visible = false;
            lbl_Nomina.Visible = false;
            btn_Detalle.Visible = false;
            lbl_cliente.Visible = false;
            cbx_Cliente.Visible = false;
            txt_ClienteNombre.Visible = false;
            lbl_Agente.Visible = false;
            cbx_Agente.Visible = false;
            lbl_canal.Visible = false;
            cbx_Canal.Visible = false;
            lbl_condicion.Visible = false;
            cbx_Condicion.Visible = false;
            lbl_almacen.Visible = false;
            cbx_Almacen.Visible = false;
            lbl_correo.Visible = false;
            txt_Correo.Visible = false;
            txt_Correo2.Visible = false;
            lbl_correoE.Visible = false;
            lbl_TelPart.Visible = false;
            txt_TelParticular.Visible = false;
            lbl_TelMovil.Visible = false;
            txt_movil.Visible = false;
            lbl_Ecommerce.Visible = false;
            txb_Ecommerce.Visible = false;
            lbl_FormaPago.Visible = false;
            txt_FormaPago.Visible = false;
            panel_Correo.Visible = false;
            panel_telefonos.Visible = false;
            panel_ecommerce.Visible = false;
            chk_Mayoreo.Visible = false;
            chk_Custodia.Visible = false;
            chk_Iva.Visible = false;
            chk_Comentario.Visible = false;
            lbl_AgenteServicio.Visible = false;
            cbx_AgenteServicio.Visible = false;
            lbl_FormaEnvio.Visible = false;
            cbx_FormaEnvio.Visible = false;
            lbl_Pago.Visible = false;
            txt_Pago.Visible = false;
            lbl_Observaciones.Visible = false;
            txt_Observaciones.Visible = false;
            lbl_Comentario.Visible = false;
            txt_Comentario.Visible = false;
            gbx_VentaDetalle.Visible = false;
            gbx_DatosEntrega.Visible = false;
            btn_Anticipo.Visible = false;
            gbx_Anticipo.Visible = false;
            btn_Afectar.Visible = false;
            btn_eventosNotasCitA.Visible = false;
            pnlBtn_DatosEntrega.Visible = false;
        }

        public void modificaFormaBoton(string mensajeBotonValida)
        {
            switch (mensajeBotonValida)
            {
                case "Credito":

                    string alerta = controlador.AlertaValidacionHuella(Codigo);
                    if (alerta == "False")
                    {
                        lbl_Alerta.Visible = true;
                        flowLayoutPanel1.Visible = true;
                    }
                    else
                    {
                        lbl_Alerta.Visible = false;
                        flowLayoutPanel1.Visible = false;
                    }

                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "        " +
                           controllerExplorador.FechaActualServidor();
                    txt_Nomina.Visible = false;
                    lbl_Nomina.Visible = false;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    panel_ecommerce.Visible = false;
                    lbl_mayoreo.Visible = false;
                    gbx_VentaDetalle.Visible = true;
                    lbl_Observaciones.Visible = false;
                    txt_Observaciones.Visible = false;
                    gbx_DatosGenerales.Size = new Size(711, 190);
                    gbx_VentaDetalle.Size = new Size(925, 250);
                    btn_Detalle.Visible = true;
                    gbx_VentaDima.Visible = false;
                    btn_Detalle.Enabled = false;
                    dvg_detalleVenta.ReadOnly = true;
                    cbx_RedimirM.Visible = true;

                    /*GESSY 1030/1061 NO DIMA CREDITO*/
                    txt_CodigoRecomendadoDima.Visible = true;
                    chx_CodigoRecomendado.Visible = true;
                    lblCodigoRecomendado.Visible = false;
                    if (habilitarCodigoRecomendado())
                    {
                        txt_CodigoRecomendadoDima.ReadOnly = false;
                        chx_CodigoRecomendado.Checked = true;
                        chx_CodigoRecomendado.Enabled = true;
                    }
                    else
                    {
                        txt_CodigoRecomendadoDima.ReadOnly = true;
                        chx_CodigoRecomendado.Checked = false;
                        chx_CodigoRecomendado.Enabled = false;
                    }

                    break;

                case "Contado":
                    chx_Die.Visible = false;
                    panel1.Visible = false;
                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "        " +
                           controllerExplorador.FechaActualServidor();
                    txt_Nomina.Visible = false;
                    lbl_Nomina.Visible = false;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    panel_ecommerce.Visible = false;
                    lbl_mayoreo.Visible = false;
                    gbx_VentaDetalle.Visible = true;
                    lbl_Observaciones.Visible = false;
                    txt_Observaciones.Visible = false;
                    gbx_DatosGenerales.Size = new Size(711, 180);
                    gbx_VentaDetalle.Size = new Size(925, 250);
                    btn_Detalle.Visible = true;
                    gbx_VentaDima.Visible = false;
                    btn_Detalle.Enabled = false;
                    dvg_detalleVenta.ReadOnly = true;
                    btn_CampoExtra.Visible = false;
                    lbl_Alerta.Visible = false;
                    flowLayoutPanel1.Visible = false;
                    /*GESSY 1030/1061 DIMA OCULTAR SI NO ES EL CANAL PERTINENTE*/
                    txt_CodigoRecomendadoDima.Visible = false;
                    lblCodigoRecomendado.Visible = false;
                    chx_CodigoRecomendado.Visible = false;
                    if (ClaseEstatica.Usuario.Uen == 1)
                    {
                        cbx_RedimirM.Visible = false;

                        //-596AlmacenensVirtuales
                        if (controladorD.validarSucursalAlmacenVirtual())
                        {
                            panel_ecommerce.Visible = true;
                            lbl_Ecommerce.Visible = true;
                            txb_Ecommerce.Visible = true;
                            lbl_FormaPago.Visible = true;
                            txt_FormaPago.Visible = true;
                            lbl_FormaCo.Visible = true;
                            txt_FormaCo.Visible = true;
                            gbx_DatosGenerales.Size = new Size(711, 210);
                        }
                        else
                        {
                            panel_ecommerce.Visible = false;
                            lbl_Ecommerce.Visible = false;
                            txb_Ecommerce.Visible = false;
                            lbl_FormaPago.Visible = false;
                            txt_FormaPago.Visible = false;
                            lbl_FormaCo.Visible = false;
                            txt_FormaCo.Visible = false;
                        }
                    }
                    else
                    {
                        //-596AlmacenensVirtuales
                        if (controladorD.validarSucursalAlmacenVirtual())
                        {
                            panel_ecommerce.Visible = true;
                            lbl_Ecommerce.Visible = true;
                            txb_Ecommerce.Visible = true;
                            lbl_FormaPago.Visible = true;
                            txt_FormaPago.Visible = true;
                            lbl_FormaCo.Visible = true;
                            txt_FormaCo.Visible = true;
                            gbx_DatosGenerales.Size = new Size(711, 225);
                        }
                        else
                        {
                            panel_ecommerce.Visible = false;
                            lbl_Ecommerce.Visible = false;
                            txb_Ecommerce.Visible = false;
                            lbl_FormaPago.Visible = false;
                            txt_FormaPago.Visible = false;
                            lbl_FormaCo.Visible = false;
                            txt_FormaCo.Visible = false;
                            gbx_DatosGenerales.Size = new Size(711, 200);
                        }
                    }

                    string genericoC = "";
                    genericoC = controlador.ValidarClienteGenerico(Codigo);
                    if (genericoC != "NO")
                    {
                        if (ClaseEstatica.Usuario.Uen == 1)
                        {
                            cbx_RedimirM.Visible = false;

                            //-596AlmacenensVirtuales
                            if (controladorD.validarSucursalAlmacenVirtual())
                            {
                                panel_ecommerce.Visible = true;
                                lbl_Ecommerce.Visible = true;
                                txb_Ecommerce.Visible = true;
                                lbl_FormaPago.Visible = true;
                                txt_FormaPago.Visible = true;
                                lbl_FormaCo.Visible = true;
                                txt_FormaCo.Visible = true;
                                gbx_DatosGenerales.Size = new Size(711, 137);
                            }
                            else
                            {
                                panel_ecommerce.Visible = false;
                                lbl_Ecommerce.Visible = false;
                                txb_Ecommerce.Visible = false;
                                lbl_FormaPago.Visible = false;
                                txt_FormaPago.Visible = false;
                                lbl_FormaCo.Visible = false;
                                txt_FormaCo.Visible = false;
                                gbx_DatosGenerales.Size = new Size(711, 100);
                            }
                        }
                        else
                        {
                            //-596AlmacenensVirtuales
                            if (controladorD.validarSucursalAlmacenVirtual())
                            {
                                panel_ecommerce.Visible = true;
                                lbl_Ecommerce.Visible = true;
                                txb_Ecommerce.Visible = true;
                                lbl_FormaPago.Visible = true;
                                txt_FormaPago.Visible = true;
                                lbl_FormaCo.Visible = true;
                                txt_FormaCo.Visible = true;
                                gbx_DatosGenerales.Size = new Size(711, 160);
                            }
                            else
                            {
                                panel_ecommerce.Visible = false;
                                lbl_Ecommerce.Visible = false;
                                txb_Ecommerce.Visible = false;
                                lbl_FormaPago.Visible = false;
                                txt_FormaPago.Visible = false;
                                lbl_FormaCo.Visible = false;
                                txt_FormaCo.Visible = false;
                                gbx_DatosGenerales.Size = new Size(711, 130);
                            }
                        }

                        cbx_Cliente.Enabled = false;
                        cbx_Canal.Enabled = false;
                        lbl_TelPart.Visible = false;
                        txt_TelParticular.Visible = false;
                        lbl_TelMovil.Visible = false;
                        txt_movil.Visible = false;
                        panel_telefonos.Visible = false;
                        lbl_correo.Visible = false;
                        txt_Correo.Visible = false;
                        txt_Correo2.Visible = false;
                        lbl_correoE.Visible = false;
                        panel_Correo.Visible = false;
                        Size = new Size(1242, 709);
                    }

                    break;

                case "Dima":
                    chx_Die.Visible = false;
                    panel1.Visible = false;
                    string alertaD = controlador.AlertaValidacionHuella(Codigo);
                    if (alertaD == "False")
                    {
                        lbl_Alerta.Visible = true;
                        flowLayoutPanel1.Visible = true;
                    }
                    else
                    {
                        lbl_Alerta.Visible = false;
                        flowLayoutPanel1.Visible = false;
                    }

                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "        " +
                           controllerExplorador.FechaActualServidor();

                    txt_Nomina.Visible = false;
                    lbl_Nomina.Visible = false;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    panel_ecommerce.Visible = false;
                    lbl_mayoreo.Visible = false;
                    gbx_VentaDetalle.Visible = true;
                    btn_Detalle.Visible = true;
                    gbx_VentaDima.Visible = false;
                    btn_Detalle.Enabled = false;
                    dvg_detalleVenta.ReadOnly = true;
                    lbl_Observaciones.Visible = false;
                    txt_Observaciones.Visible = false;

                    /*GESSY 1030/1061 DIMA*/
                    txt_CodigoRecomendadoDima.Visible = true;
                    txt_CodigoRecomendadoDima.ReadOnly = false;
                    lblCodigoRecomendado.Visible = true;
                    if (canalC == 80)
                    {
                        chx_CodigoRecomendado.Visible = false;
                        txt_CodigoRecomendadoDima.Visible = false;
                        lblCodigoRecomendado.Visible = false;
                    }
                    else
                    {
                        chx_CodigoRecomendado.Visible = false;
                    }

                    if (habilitarCodigoRecomendado())
                    {
                        txt_CodigoRecomendadoDima.ReadOnly = false;
                        chx_CodigoRecomendado.Checked = true;
                        chx_CodigoRecomendado.Enabled = true;
                    }
                    else
                    {
                        txt_CodigoRecomendadoDima.ReadOnly = true;
                        chx_CodigoRecomendado.Checked = false;
                        chx_CodigoRecomendado.Enabled = false;
                    }

                    gbx_DatosGenerales.Size = new Size(711, 190);
                    gbx_VentaDetalle.Size = new Size(925, 250);
                    cbx_RedimirM.Visible = true;

                    break;

                case "Instituciones":
                    chx_Die.Visible = false;
                    panel1.Visible = false;
                    string alertaI = controlador.AlertaValidacionHuella(Codigo);
                    if (alertaI == "False")
                    {
                        lbl_Alerta.Visible = true;
                        flowLayoutPanel1.Visible = true;
                    }
                    else
                    {
                        lbl_Alerta.Visible = false;
                        flowLayoutPanel1.Visible = false;
                    }

                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "        " +
                           controllerExplorador.FechaActualServidor();

                    txt_Nomina.Visible = true;
                    lbl_Nomina.Visible = true;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    panel_ecommerce.Visible = false;
                    lbl_mayoreo.Visible = false;
                    btn_Detalle.Visible = true;
                    gbx_VentaDetalle.Visible = true;
                    gbx_VentaDima.Visible = false;
                    btn_Detalle.Enabled = false;
                    dvg_detalleVenta.ReadOnly = true;
                    lbl_Observaciones.Visible = false;
                    txt_Observaciones.Visible = false;
                    /*GESSY 1030/1061 DIMA OCULTAR SI NO ES EL CANAL PERTINENTE*/
                    txt_CodigoRecomendadoDima.Visible = false;
                    lblCodigoRecomendado.Visible = false;
                    chx_CodigoRecomendado.Visible = false;
                    gbx_DatosGenerales.Size = new Size(711, 200);
                    gbx_VentaDetalle.Size = new Size(925, 250);
                    cbx_RedimirM.Visible = false;
                    MostrarNomina();
                    break;

                case "Mayoreo":
                    chx_Die.Visible = false;
                    panel1.Visible = false;
                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "      " +
                           controllerExplorador.FechaActualServidor();
                    txt_Nomina.Visible = false;
                    lbl_Nomina.Visible = false;
                    cbx_RedimirM.Visible = false;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Alerta.Visible = false;
                    flowLayoutPanel1.Visible = false;
                    chk_Mayoreo.Visible = true;
                    chk_Custodia.Visible = true;
                    chk_Iva.Visible = true;
                    chk_Iva.Checked = true;
                    chk_Comentario.Visible = true;
                    lbl_mayoreo.Visible = true;
                    lbl_AgenteServicio.Visible = true;
                    cbx_AgenteServicio.Visible = true;
                    lbl_FormaEnvio.Visible = true;
                    cbx_FormaEnvio.Visible = true;
                    lbl_Pago.Visible = true;
                    txt_Pago.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    btn_Detalle.Visible = true;
                    gbx_VentaDetalle.Visible = true;
                    flp_promociones.Visible = false;
                    gbx_VentaDima.Visible = false;
                    gbx_VentaDetalle.Size = new Size(925, 253);
                    gbx_DatosGenerales.Size = new Size(711, 280);
                    cbx_Canal.Enabled = false;
                    btn_CampoExtra.Visible = false;
                    cbx_RedimirM.Visible = false;

                    //-596AlmacenensVirtuales
                    if (controladorD.validarSucursalAlmacenVirtual())
                    {
                        panel_ecommerce.Visible = true;
                        lbl_Ecommerce.Visible = true;
                        txb_Ecommerce.Visible = true;
                        lbl_FormaPago.Visible = true;
                        txt_FormaPago.Visible = true;
                        gbx_VentaDetalle.Size = new Size(925, 253);
                    }

                    /*GESSY 1030/1061 OCULTAR SI NO ES EL CANAL PERTINENTE*/
                    txt_CodigoRecomendadoDima.Visible = false;
                    lblCodigoRecomendado.Visible = false;
                    chx_CodigoRecomendado.Visible = false;

                    if (std.validarCheckIva()) chk_Iva.Enabled = true;

                    break;

                //-CreditoEmpresario
                case "Credito Empresario":

                    alerta = controlador.AlertaValidacionHuella(Codigo);
                    if (alerta == "False")
                    {
                        lbl_Alerta.Visible = true;
                        flowLayoutPanel1.Visible = true;
                    }
                    else
                    {
                        lbl_Alerta.Visible = false;
                        flowLayoutPanel1.Visible = false;
                    }

                    Text = " Venta de " + mensajeBotonValida + "       SPID:" + ClaseEstatica.SPID + "        " +
                           controllerExplorador.FechaActualServidor();
                    txt_Nomina.Visible = false;
                    lbl_Nomina.Visible = false;
                    lbl_cliente.Visible = true;
                    cbx_Cliente.Visible = true;
                    txt_ClienteNombre.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Agente.Visible = true;
                    lbl_canal.Visible = true;
                    cbx_Canal.Visible = true;
                    lbl_condicion.Visible = true;
                    cbx_Condicion.Visible = true;
                    lbl_almacen.Visible = true;
                    cbx_Almacen.Visible = true;
                    lbl_Observaciones.Visible = true;
                    txt_Observaciones.Visible = true;
                    activarObservaciones();
                    lbl_Comentario.Visible = true;
                    txt_Comentario.Visible = true;
                    panel_ecommerce.Visible = false;
                    lbl_mayoreo.Visible = false;
                    gbx_VentaDetalle.Visible = true;
                    lbl_Observaciones.Visible = false;
                    txt_Observaciones.Visible = false;
                    gbx_DatosGenerales.Size = new Size(738, 192);
                    gbx_VentaDetalle.Size = new Size(925, 250);
                    btn_Detalle.Visible = true;
                    gbx_VentaDima.Visible = false;
                    btn_Detalle.Enabled = false;
                    dvg_detalleVenta.ReadOnly = true;
                    cbx_RedimirM.Visible = true;

                    /*GESSY 1030/1061 OCULTAR SI NO ES EL CANAL PERTINENTE*/
                    txt_CodigoRecomendadoDima.Visible = false;
                    lblCodigoRecomendado.Visible = false;
                    chx_CodigoRecomendado.Visible = false;

                    break;

                default:
                    Console.WriteLine("Error");
                    break;
            }
        }

        /// <summary>
        ///     Metodo encargado de habilitar los campos de codigo recomendado
        /// </summary>
        /// <returns>Retorna true para habilitarlos</returns>
        private bool habilitarCodigoRecomendado()
        {
            bool respusta = true;
            if (controlador.clienteTieneFacturaConcluidaCanal3o7(Codigo, canalC) && canalC != 76) respusta = false;

            if (!string.IsNullOrEmpty(controlador.CteCodigoRecomendadorDima(Codigo, canalC))) respusta = false;

            return respusta;
        }

        private void activarObservaciones()
        {
            //-BotonMayoreo
            if (ClaseEstatica.Usuario.Sucursal != 98) btnObservacionesVM.Visible = false;
        }

        private void ValidaCamposObligatorios()
        {
            try
            {
                if (string.IsNullOrEmpty(cbx_Cliente.Text))
                {
                    mensajeValidacion = ", Cuenta del Cliente";
                    NumValidacion++;
                }
                else
                {
                    validarCliente();
                }

                if (string.IsNullOrEmpty(cbx_Agente.Text))
                {
                    mensajeValidacion += ", Agente";
                    NumValidacion++;
                }
                else
                {
                    ValidaAgente();
                }

                if (string.IsNullOrEmpty(cbx_Canal.Text))
                {
                    mensajeValidacion += ", Canal de Venta";
                    NumValidacion++;
                }
                else
                {
                    validarCanalVenta();
                }

                if (string.IsNullOrEmpty(cbx_Condicion.Text))
                {
                    mensajeValidacion += ", Condicion";
                    NumValidacion++;
                }

                if (string.IsNullOrEmpty(cbx_Almacen.Text))
                {
                    mensajeValidacion += ", Almacen";
                    NumValidacion++;
                }
                else
                {
                    ValidaAlmacen();
                }

                if (txt_Correo.Enabled && txt_Correo.Visible)
                    ValidacionInsertarCorreo();
                else
                    obligatorioCorreo = true;
                if (txt_TelParticular.Enabled && txt_TelParticular.Visible &&
                    string.IsNullOrEmpty(txt_TelParticular.Text))
                {
                    mensajeValidacion += ", Telefono Particular";
                    NumValidacion++;
                }
                else
                {
                    obligatorioParticular = true;
                }

                //-1030/1061 NO DIMA GESSY si esta check obligatorio
                if (chx_CodigoRecomendado.Checked && chx_CodigoRecomendado.Visible)
                    if (string.IsNullOrWhiteSpace(txt_CodigoRecomendadoDima.Text))
                    {
                        mensajeValidacion += ", Código Recomendado";
                        NumValidacion++;
                    }

                if (txt_movil.Enabled && txt_movil.Visible)
                {
                    if (string.IsNullOrEmpty(txt_movil.Text))
                    {
                        mensajeValidacion += ", Telefono Movil";
                        NumValidacion++;
                    }
                }
                else
                {
                    obligatorioMovil = true;
                }

                if (validaMensajeBoton == "Instituciones")
                {
                    if (string.IsNullOrEmpty(txt_Nomina.Text) && txt_Nomina.Visible)
                    {
                        mensajeValidacion += ", Nomina de Empleados";
                        NumValidacion++;
                    }
                    else
                    {
                        if (txt_Nomina.Visible) ValidaNomina();
                    }
                }

                if (NumValidacion == 20)
                {
                    obligatorio = true;
                    NumValidacion = 0;
                }
                else
                {
                    if (NumValidacion > 0)
                    {
                        obligatorio = true;
                        MessageBox.Show("Falta Agregar" + mensajeValidacion, "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        NumValidacion = 0;
                        ComponentesFocus();
                        mensajeValidacion = "";
                    }
                    else
                    {
                        obligatorio = false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCamposObligatorios", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void ValidaCamposObligatorios2(string componente)
        {
            try
            {
                if (componente == "cliente")
                {
                    if (string.IsNullOrEmpty(cbx_Cliente.Text))
                    {
                        mensajeValidacion = ", Cuenta del Cliente";
                        NumValidacion++;
                    }
                    else
                    {
                        validarCliente();
                    }
                }

                if (componente == "Agente")
                {
                    if (string.IsNullOrEmpty(cbx_Agente.Text))
                    {
                        mensajeValidacion += ", Agente";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidaAgente();
                    }
                }

                if (componente == "Agente Servicio")
                {
                    if (string.IsNullOrEmpty(cbx_AgenteServicio.Text))
                    {
                        mensajeValidacion += ", Agente Servicio";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidaAgenteServicio();
                    }
                }

                if (componente == "Canal")
                {
                    if (string.IsNullOrEmpty(cbx_Canal.Text))
                    {
                        mensajeValidacion += ", Canal de Venta";
                        NumValidacion++;
                    }
                    else
                    {
                        validarCanalVenta();
                    }
                }

                if (componente == "Condicion" && string.IsNullOrEmpty(cbx_Condicion.Text))
                {
                    mensajeValidacion += ", Condicion";
                    NumValidacion++;
                }

                if (componente == "Almacen")
                {
                    if (string.IsNullOrEmpty(cbx_Almacen.Text))
                    {
                        mensajeValidacion += ", Almacen";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidaAlmacen();
                    }
                }

                if (componente == "Correo")
                {
                    if (txt_Correo.Enabled)
                        ValidacionInsertarCorreo();
                    else
                        obligatorioCorreo = true;
                }

                if (componente == "Particular")
                {
                    if (txt_TelParticular.Enabled)
                    {
                        if (string.IsNullOrEmpty(txt_TelParticular.Text))
                        {
                            mensajeValidacion += ", Telefono Particular";
                            NumValidacion++;
                        }
                    }
                    else
                    {
                        obligatorioParticular = true;
                    }
                }

                if (componente == "Movil")
                {
                    if (txt_movil.Enabled)
                    {
                        if (string.IsNullOrEmpty(txt_movil.Text))
                        {
                            mensajeValidacion += ", Telefono Movil";
                            NumValidacion++;
                        }
                    }
                    else
                    {
                        obligatorioMovil = true;
                    }
                }

                if (componente == "Nomina")
                {
                    if (string.IsNullOrEmpty(txt_Nomina.Text) && txt_Nomina.Visible)
                    {
                        mensajeValidacion += ", Nomina de Empleados";
                        NumValidacion++;
                    }
                    else if (txt_Nomina.Visible)
                    {
                        ValidaNomina();
                    }
                }

                if (NumValidacion == 20)
                {
                    obligatorio = true;
                    NumValidacion = 0;
                }
                else if (NumValidacion > 0)
                {
                    obligatorio = true;
                    NumValidacion = 0;
                    ComponentesFocus();
                }
                else
                {
                    obligatorio = false;
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }
        }

        #endregion

        #region "VALIDACIONES DATOS GENERALES"

        public void ValidaVenta()
        {
            if (lbl_ID.Text == "")
            {
                string sTipo = cExtra.obtenerTipoCliente(cbx_Cliente.Text, canalC);
                ObtenIdVenta();

                if (lbl_ID.Text != "")
                {
                    btn_InfoArt.Visible = true;

                    if (validaMensajeBoton == "Dima") VentaDima();
                    if (Canal == 76 && controlador.ValidaFuncionNuevoCasa(idVenta) == "Nuevo" &&
                        controlador.validaVentaCanalAsociados(Codigo) == 0 &&
                        controlador.ArticulosValr(Codigo) == false && valedigital == 0)

                        if (Canal == 76 && controlador.ValidaFuncionNuevoCasa(idVenta) == "Nuevo" &&
                            controlador.validaVentaCanalAsociados(Codigo) == 0 &&
                            controlador.ArticulosValr(Codigo) == false && valedigital == 0)

                        {
                            DM0312_AgregarEvento evento = new DM0312_AgregarEvento();
                            evento.recibeSucursal = Convert.ToString(ClaseEstatica.Usuario.Sucursal);
                            evento.recibeEstatus = ValidaEstatus;
                            evento.recibeIdVenta = Convert.ToString(idVenta);
                            evento.ValidaCanalVenta = canalC;
                            evento.recibeMensaje = 1;
                            evento.validaUsuarioDima = true;
                            evento.recibeCliente = Cliente;
                            evento.iCanalVenta = Canal;
                            evento.recibeIdecommerce = txb_Ecommerce.Text;
                            evento.recibeMov = Movimiento;
                            evento.ShowDialog();
                            if (exit)
                            {
                                Dispose();
                                exit = false;
                                return;
                            }
                        }

                    ValidaExecCampoExtra(sTipo);
                    MessageBox.Show(
                        "Datos generales correctos, venta con condicion " + cbx_Condicion.Text +
                        " si es correcta puede iniciar con la carga de articulos si no cambiar la condicion",
                        "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //ACTUALIZARCUENTABANCARIA C02132545 0 99 VENTP00740 5
                    List<int> listaCanales = CDetalleVenta.obtenerCanalesStp();
                    if (listaCanales.Contains(Canal) && CDetalleVenta.validarCuentaClaveStd())
                        CDetalleVenta.EjecutarStp("ACTUALIZARCUENTABANCARIA " + Cliente + " " + idVenta + " " +
                                                  ClaseEstatica.Usuario.sucursal + " " + ClaseEstatica.Usuario.usuario +
                                                  " " + cbx_Agente.Text + " " + "PUNTOVENTAS");


                    //-PedidoSinDetalle
                    std.insertarIdVenta(int.Parse(lbl_ID.Text), 1);


                    List<AccesoUsuario> ListaAccesos =
                        AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
                    if (ListaAccesos.FirstOrDefault(x => x.campo == pnlBtn_DatosEntrega.Name) == null)
                        if (ClaseEstatica.iRecarga != 1)
                            pnlBtn_DatosEntrega.Visible = true;
                    //pnlBtn_DatosEntrega.Focus();
                    btn_eventosNotasCitA.Visible = true;

                    if (validaMensajeBoton == "Dima" || validaMensajeBoton == "Credito" ||
                        validaMensajeBoton == "Instituciones") btn_CampoExtra.Visible = true;

                    if (ListaAccesos.FirstOrDefault(x => x.campo == btn_Anticipo.Name) == null)
                        if (ClaseEstatica.iRecarga != 1)
                            btn_Anticipo.Visible = true;
                    BtnAdd.Enabled = true;
                    btnImportExcel.Enabled = true;
                    if (PuedeAfectar())
                    {
                        if (!CDetalleVenta.PuedeAfectar(ClaseEstatica.Usuario.usuario, "SINAFECTAR", "",
                                TipoMovimiento))
                            btn_Afectar.Visible = false;
                        else
                            btn_Afectar.Visible = true;
                    }
                    else
                    {
                        btn_situaciones.Visible = true;
                        btn_Anticipo.Visible = false;
                    }

                    if (gbx_VentaDima.Visible)
                        txt_DetalleInformacion.Text =
                            "Favor de ingresar los articulos que el cliente desea comprar, una vez ingresados pasar al apartado de venta dima";
                    else
                        txt_DetalleInformacion.Text =
                            "Favor de ingresar los articulos que el cliente desea comprar, una vez ingresados dar clic si lo necesita al boton Datos de Entrega o al de " +
                            btn_Anticipo.Text + " al terminar genere su " + TipoMovimiento;
                    //btn_DatosEntrega.Focus();
                    txt_ComentariosDatosEntrega.Text = "";
                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                    ListVentaDetalle.Add(model);
                    llenarGrid();
                    //this.Visible = true;
                    StartPosition = FormStartPosition.CenterScreen;
                    //ValidaTelefono();
                    if (contadorClick == 0) dvg_detalleVenta.Select();
                    contadorClick++;
                }
                else
                {
                    MessageBox.Show("Error al generar id de venta", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    Dispose();
                }
            }
            else
            {
                if (validaMensajeBoton == "Dima") VentaDima();
                List<AccesoUsuario> ListaAccesos =
                    AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
                if (ListaAccesos.FirstOrDefault(x => x.campo == pnlBtn_DatosEntrega.Name) == null)
                {
                    if (ClaseEstatica.iRecarga == 1)
                        pnlBtn_DatosEntrega.Visible = false;
                    else
                        pnlBtn_DatosEntrega.Visible = true;
                }

                //pnlBtn_DatosEntrega.Focus();
                if (contadorClick == 0) dvg_detalleVenta.Select();
                contadorClick++;
            }
        }

        public void ValidaAgenteServicio()
        {
            try
            {
                string agente = cbx_AgenteServicio.Text;
                string Resultado = "";
                int suc = controlador.GetSucursal(cbx_Almacen.Text);
                Resultado = controlador.ValidarAgente(agente, suc);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (agente == "")
                    {
                        cbx_AgenteServicio.Items.Clear();
                        LlenaAgenteTelefonico();
                        if (lbl_ID.Text != "" &&
                            (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                             Condicion != cbx_Condicion.Text || Alm != Almacen
                             || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                             Comentario != txt_Comentario.Text
                             || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text ||
                             AgenteTelefonico != cbx_AgenteServicio.Text))
                            ActualizarInfoIdVenta();
                        //cbx_Canal.Focus();
                        //obligatorioAgente = true;
                        NumValidacion = 0;
                    }
                    else
                    {
                        MessageBox.Show("El Agente Telefonico es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        //obligatorioAgente = false;
                        cbx_AgenteServicio.Focus();
                    }

                    cbx_AgenteServicio.Text = "";
                    NumValidacion = 20;
                    //obligatorioAgente = false;
                    //mensajeValidacion = ", Canal de Venta";
                    //cbx_Agente.Focus();
                }
                else
                {
                    cbx_AgenteServicio.Items.Clear();
                    LlenaAgenteTelefonico();
                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text
                                              || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text ||
                                              AgenteTelefonico != cbx_AgenteServicio.Text))
                        ActualizarInfoIdVenta();
                    //cbx_Canal.Focus();
                    //obligatorioAgente = true;
                    NumValidacion = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAgente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void CargaCliente()
        {
            try
            {
                datosEmpleado = new List<string>();
                datosEmpleado = controlador.LlenaDatosCliente(Codigo);
                if (datosEmpleado.Count > 0)
                {
                    cbx_Cliente.Items.Add(datosEmpleado[0]);
                    //cbx_Cliente.SelectedIndex = 0;
                    cbx_Cliente.Text = datosEmpleado[0];
                    txt_ClienteNombre.Text = datosEmpleado[1];
                    txt_Correo.Text = datosEmpleado[2].ToUpper();
                    txt_Correo2.Text = datosEmpleado[3].ToUpper();
                }

                // 1030/1061 DIMA GESSY Codigo Recomendado
                string sCodigo = controlador.CteCodigoRecomendadorDima(Codigo, canalC);
                if (!string.IsNullOrEmpty(sCodigo))
                {
                    txt_CodigoRecomendadoDima.ReadOnly = true;
                    txt_CodigoRecomendadoDima.Text = sCodigo;
                }
                else
                {
                    txt_CodigoRecomendadoDima.ReadOnly = false;
                }

                ValidaCorreo();
                ValidaTelefono();
                cxb_SinCorreo.Checked = false;
                cbx_TelParticular.Checked = false;
                cbx_TelMovil.Checked = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CargaCliente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaComboCanal()
        {
            try
            {
                if (Canal != 0)
                {
                    cbx_Canal.Items.Add(Canal);
                    cbx_Canal.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaComboCanal", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaListaCanalesCliente()
        {
            try
            {
                listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
                listaCanal = controlador.LlenaCanalesCliente(Codigo);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaListaCanalesCliente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaCanal()
        {
            try
            {
                LlenaListaCanalesCliente();
                DM0312_MPuntoDeVentaCanales var = listaCanal.Where(x => x.Canal == Convert.ToInt32(Canal))
                    .FirstOrDefault();
                if (var != null)
                    existe = true;
                else
                    existe = false;
                //LlenaListaCanalesCliente();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCanal", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void AgregaNuevoCanal()
        {
            try
            {
                bool Inserta = new bool();
                //if (obligatorioCanal == true)
                //{
                Inserta = controlador.AgregaNuevoCanal(Codigo, Canal);
                LlenaListaCanalesCliente();
                //}
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("AgregaNuevoCanal", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAlmacen()
        {
            try
            {
                if (Almacen != null)
                {
                    cbx_Almacen.Items.Add(Almacen);
                    cbx_Almacen.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAgente()
        {
            try
            {
                if (Agente != null)
                {
                    cbx_Agente.Items.Add(Agente);
                    cbx_Agente.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAgente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAgenteTelefonico()
        {
            try
            {
                if (AgenteTelefonico != null)
                {
                    cbx_AgenteServicio.Items.Add(AgenteTelefonico);
                    cbx_AgenteServicio.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAgenteTelefonico", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaFormaDeEnvio()
        {
            try
            {
                datosFormaEnvio = new List<string>();
                datosFormaEnvio = controlador.LlenaFormaDeEnvio();
                if (datosFormaEnvio.Count > 0)
                {
                    cbx_FormaEnvio.DataSource = null;
                    cbx_FormaEnvio.DataSource = datosFormaEnvio.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaFormaDeEnvio", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaFormaDeCobroLinea()
        {
            try
            {
                datosFormaCobroLinea = new List<string>();
                datosFormaCobroLinea = controlador.LlenaFormaDeCobro("");
                if (datosFormaCobroLinea.Count > 0)
                {
                    txt_FormaCo.DataSource = null;
                    txt_FormaCo.DataSource = datosFormaCobroLinea.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaFormaDeEnvio", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaCondicion(int Var)
        {
            try
            {
                datosCondicion = new List<string>();
                if (canalC == 76 || canalC == 80)
                {
                    if (canalC == 76)
                    {
                        if (!string.IsNullOrEmpty(sTipoDima))
                            datosCondicion = controlador.llenarCondicionesTipoDima(sTipoDima);
                        if (datosCondicion.Count <= 0) datosCondicion = controlador.llenarCondicionesDima();
                    }

                    if (canalC == 80) datosCondicion = controlador.obtenerCondicionesForaneas();
                }
                else
                {
                    datosCondicion = controlador.LlenaCondicion(ClaseEstatica.Usuario.usuario, Canal, Var);
                }

                if (datosCondicion.Count > 0 && valedigital == 0)
                {
                    cbx_Condicion.DataSource = null;
                    cbx_Condicion.DataSource = datosCondicion.ToArray();
                }
                else if (valedigital == 1)
                {
                    //-ValeDigital
                    datosCondicion.Clear();
                    datosCondicion.Add(valeDigitalDatos.condicion);
                    cbx_Condicion.DataSource = null;
                    cbx_Condicion.DataSource = datosCondicion.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void ConsultaAlmacen()
        {
            try
            {
                Almacen = controlador.LlenaAlmacen(ClaseEstatica.Usuario.sucursal);
                if (validaMensajeBoton == "Mayoreo") Almacen = "V00096";
                LlenaAlmacen();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaAlmacen", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ConsultaAgente()
        {
            try
            {
                LlenaAgente();
                cbx_Agente.Text = "";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaAgente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void ValidaTelefono()
        {
            try
            {
                MuestraTelefono = controlador.validaTelefono(Codigo, ClaseEstatica.Usuario.usuario);
                lbl_TelPart.Visible = true;
                txt_TelParticular.Visible = true;
                lbl_TelMovil.Visible = true;
                txt_movil.Visible = true;
                panel_telefonos.Visible = true;
                List<string> telefonos = new List<string>();
                telefonos = controlador.ValidacionTelefonos(Codigo);

                if (MuestraTelefono == 0)
                {
                    lbl_TelPart.Text = "Telefono Particular";
                    txt_TelParticular.Enabled = false;
                    txt_TelParticular.Text = telefonos[0];
                    lbl_TelMovil.Text = "Telefono Movil";
                    txt_movil.Text = telefonos[1];
                    txt_movil.Enabled = false;
                    obligatorioParticular = true;
                    obligatorioMovil = true;
                    cbx_TelMovil.Visible = false;
                    cbx_TelParticular.Visible = false;
                }

                if (MuestraTelefono == 0 && telefonos[0] == "")
                {
                    lbl_TelPart.Text = "*Telefono Particular";
                    txt_TelParticular.Enabled = true;
                    cbx_TelParticular.Visible = true;
                    cbx_TelMovil.Visible = false;
                    txt_TelParticular.Text = "";
                    lbl_TelMovil.Text = "Telefono Movil";
                    txt_movil.Text = telefonos[1];
                    txt_movil.Enabled = false;
                    obligatorioParticular = false;
                    obligatorioMovil = true;
                }

                if (MuestraTelefono == 0 && telefonos[1] == "")
                {
                    lbl_TelPart.Text = "Telefono Particular";
                    txt_TelParticular.Enabled = false;
                    txt_TelParticular.Text = telefonos[0];
                    lbl_TelMovil.Text = "*Telefono Movil";
                    cbx_TelParticular.Visible = false;
                    cbx_TelMovil.Visible = true;
                    txt_movil.Text = "";
                    txt_movil.Enabled = true;
                    obligatorioParticular = true;
                    obligatorioMovil = false;
                }

                if (MuestraTelefono == 0 && telefonos[0] == "" && telefonos[1] == "")
                {
                    lbl_TelPart.Text = "*Telefono Particular";
                    txt_TelParticular.Enabled = true;
                    txt_TelParticular.Text = "";
                    lbl_TelMovil.Text = "*Telefono Movil";
                    txt_movil.Text = "";
                    txt_movil.Enabled = true;
                    obligatorioParticular = false;
                    obligatorioMovil = false;
                    cbx_TelMovil.Visible = true;
                    cbx_TelParticular.Visible = true;
                }

                if (MuestraTelefono == 1)
                {
                    lbl_TelPart.Text = "*Telefono Particular";
                    txt_TelParticular.Text = "";
                    txt_TelParticular.Enabled = true;
                    lbl_TelMovil.Text = "Telefono Movil";
                    txt_movil.Text = telefonos[1];
                    txt_movil.Enabled = false;
                    obligatorioParticular = false;
                    obligatorioMovil = true;
                    cbx_TelParticular.Visible = true;
                    cbx_TelMovil.Visible = false;
                }

                if (MuestraTelefono == 1 && telefonos[1] == "")
                {
                    lbl_TelPart.Text = "*Telefono Particular";
                    txt_TelParticular.Text = "";
                    txt_TelParticular.Enabled = true;
                    lbl_TelMovil.Text = "*Telefono Movil";
                    txt_movil.Text = "";
                    txt_movil.Enabled = true;
                    obligatorioParticular = false;
                    obligatorioMovil = false;
                    cbx_TelMovil.Visible = true;
                    cbx_TelParticular.Visible = true;
                }

                if (MuestraTelefono == 2)
                {
                    txt_TelParticular.Enabled = false;
                    lbl_TelPart.Text = "Telefono Particular";
                    txt_TelParticular.Text = telefonos[0];
                    lbl_TelMovil.Text = "*Telefono Movil";
                    txt_movil.Enabled = true;
                    txt_movil.Text = "";
                    obligatorioParticular = true;
                    obligatorioMovil = false;
                    cbx_TelMovil.Visible = true;
                    cbx_TelParticular.Visible = false;
                }

                if (MuestraTelefono == 2 && telefonos[0] == "")
                {
                    txt_TelParticular.Enabled = true;
                    lbl_TelPart.Text = "*Telefono Particular";
                    txt_TelParticular.Text = "";
                    lbl_TelMovil.Text = "*Telefono Movil";
                    txt_movil.Enabled = true;
                    txt_movil.Text = "";
                    obligatorioParticular = false;
                    obligatorioMovil = false;
                    cbx_TelMovil.Visible = true;
                    cbx_TelParticular.Visible = true;
                }

                if (MuestraTelefono == 3)
                {
                    lbl_TelPart.Text = "*Telefono Particular";
                    cbx_TelParticular.Visible = true;
                    cbx_TelMovil.Visible = true;
                    txt_TelParticular.Enabled = true;
                    txt_TelParticular.Text = "";
                    lbl_TelMovil.Text = "*Telefono Movil";
                    txt_movil.Text = "";
                    txt_movil.Enabled = true;
                    obligatorioParticular = false;
                    obligatorioMovil = false;
                }

                if (listaCteGenericos.Contains(Codigo) ||
                    listaCatalogoCapturaTelefono.Contains(Canal))
                {
                    //PHONE
                    panel_telefonos.Visible = false;

                    //lbl_TelPart.Visible = false;
                    //lbl_TelMovil.Visible = false;

                    //txt_TelParticular.Visible = false;
                    //txt_movil.Visible = false;

                    cbx_TelMovil.Visible = false;
                    cbx_TelParticular.Visible = false;

                    obligatorioParticular = false;
                    obligatorioMovil = false;
                    //MAIL

                    txt_Correo.Visible = true;
                    txt_Correo2.Visible = true;

                    txt_Correo.Enabled = true;
                    txt_Correo2.Enabled = true;

                    cxb_SinCorreo.Visible = true;
                    cxb_SinCorreo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaTelefono", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void telefonocorrectoParticular(string telefono)
        {
            string Resultado = "";
            try
            {
                if (string.IsNullOrEmpty(telefono))
                {
                    MessageBox.Show("Debe ingresar un Telefono " + "Particular", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    txt_TelParticular.Focus();
                    obligatorioParticular = false;
                }
                else
                {
                    CapturaTelefono();

                    /*if (//ClaseEstatica.Usuario.Acceso.Substring(0, 5).ToUpper() == "VENTP" &&
                        /*telefono == "0000000000" &&#1#
                        listaCatalogoCapturaTelefono.Contains(Canal) &&
                        !listaCteGenericos.Contains(cbx_Cliente.Text)
                       ) {
                        MessageBox.Show("No se permite la captura de ceros. Si el cliente no cuenta con teléfono propio, proporcionar uno de recado.");
                        return;
                    }*/
                    Resultado = controlador.TelefonoCorrecto(telefono);
                    if (Resultado == "0")
                    {
                        NumValidacion = 0;
                        obligatorioParticular = true;
                    }
                    else
                    {
                        MessageBox.Show(Resultado, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txt_TelParticular.Text = "";
                        txt_TelParticular.Focus();
                        obligatorioParticular = false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("telefonocorrectoParticular", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void telefonocorrectoMovil(string telefono)
        {
            string Resultado = "";
            try
            {
                if (telefono == "")
                {
                    MessageBox.Show("Debe ingresar un Telefono " + "Movil", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    txt_movil.Focus();
                    obligatorioMovil = false;
                }
                else
                {
                    if ( //ClaseEstatica.Usuario.Acceso.Substring(0, 5).ToUpper() == "VENTP" && &&
                        telefono == "0000000000" &&
                        listaCatalogoCapturaTelefono.Contains(Canal) &&
                        !listaCteGenericos.Contains(cbx_Cliente.Text))
                    {
                        MessageBox.Show(
                            "No se permite la captura de ceros. Si el cliente no cuenta con teléfono propio, proporcionar uno de recado");
                        return;
                    }

                    Resultado = controlador.TelefonoCorrecto(telefono);
                    if (Resultado == "0")
                    {
                        //InsertaTelefono(telefono, "MOVIL");
                        NumValidacion = 0;
                        obligatorioMovil = true;
                    }
                    else
                    {
                        MessageBox.Show(Resultado, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txt_movil.Text = "";
                        txt_movil.Focus();
                        obligatorioMovil = false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("telefonocorrectoMovil", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void ClienteEsTitular()
        {
            //Gessy CA 41 1
            if (MessageBox.Show("¿El cliente es el TITULAR de la cuenta?", "Cliente Es Titular",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string ArgumentosPlugin = "SHM "
                                          + "True "
                                          + "\"NIPCOMPRA " + 0 + "\" "
                                          + "\"true " + ClaseEstatica.Usuario.usuario + " \" "
                                          + Cliente + " "
                                          + "1 "
                    ;
                controladorD.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
            }
            //Gessy 1707 14
            else
            {
                //Gessy CA 41 2
                controlador.InsertaTelefonos(Codigo, ClaseEstatica.Usuario.usuario, ClaseEstatica.Usuario.Sucursal,
                    txt_movil.Text, "MOVIL");
            }
        }


        public void InsertaTelefono(string tel, string tipo)
        {
            try
            {
                bool InsertaTelefono = new bool();
                bool InsertaCelular = new bool();
                if (tipo == "PARTICULAR")
                    InsertaTelefono = controlador.InsertaTelefonos(Codigo, ClaseEstatica.Usuario.usuario,
                        ClaseEstatica.Usuario.Sucursal, txt_TelParticular.Text, "PARTICULAR");

                //if (tipo == "MOVIL")
                //{

                //    InsertaCelular = controlador.InsertaTelefonos(Codigo, ClaseEstatica.Usuario.usuario, ClaseEstatica.Usuario.Sucursal, txt_movil.Text, "MOVIL");
                //}
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InsertaTelefono", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaNomina()
        {
            string nomina = txt_Nomina.Text;
            string Resultado = "";
            try
            {
                Resultado = controlador.ValidarNominaEmpleado(nomina);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (nomina == "")
                    {
                        MessageBox.Show("Debe ingresar una Nomina", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioNomina = false;
                    }
                    else
                    {
                        MessageBox.Show("La nomina es Incorrecta", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioNomina = false;
                    }

                    txt_Nomina.Text = "";
                    NumValidacion++;
                    txt_Nomina.Focus();
                }
                else
                {
                    string Rduplicado;
                    Rduplicado = controlador.ValidarNominaEmpleadoDuplicado(Resultado, Codigo);

                    Resultado = controlador.ValidarMostrarNomina(Codigo, 1);
                    if (Rduplicado == "NO")
                    {
                        if (Resultado == "NO")
                        {
                            controlador.InsertNomina(Codigo, txt_Nomina.Text, 1);
                            controlador.InsertNomina(Codigo, txt_Nomina.Text, 3);
                        }
                        else
                        {
                            controlador.InsertNomina(Codigo, txt_Nomina.Text, 2);
                            controlador.InsertNomina(Codigo, txt_Nomina.Text, 3);
                        }

                        obligatorioNomina = true;
                    }
                    else
                    {
                        List<string> nominasR = new List<string>();
                        nominasR = controlador.ListaNominas(txt_Nomina.Text, Codigo);
                        string cuentasN = "";
                        for (int cont = 0; cont < nominasR.Count; cont++) cuentasN = cuentasN + ", " + nominasR[cont];
                        MessageBox.Show("La nomina es Incorrecta, Ya es utilizada por: " + cuentasN, "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_Nomina.Text = "";
                        NumValidacion++;
                        txt_Nomina.Focus();
                        obligatorioNomina = false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaNomina", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void MostrarNomina()
        {
            try
            {
                string Resultado = "";
                string ResultadoV = "";

                Resultado = controlador.ValidarMostrarNomina(Codigo, 1);

                if (Resultado == "NO" || Resultado == "")
                {
                    Resultado = controlador.ValidarMostrarNomina(Codigo, 2);
                    if (Resultado == "NO" || Resultado == "")
                    {
                        txt_Nomina.Text = "";
                        txt_Nomina.Focus();
                        txt_Nomina.Enabled = true;
                    }
                    else
                    {
                        ResultadoV = controlador.ValidarNominaEmpleado(Resultado);
                        if (ResultadoV == "NO")
                        {
                            txt_Nomina.Text = "";
                            txt_Nomina.Focus();
                            txt_Nomina.Enabled = true;
                        }
                        else
                        {
                            string resulDuplicado;
                            resulDuplicado = controlador.ValidarNominaEmpleadoDuplicado(Resultado, Codigo);
                            if (resulDuplicado == "NO")
                            {
                                txt_Nomina.Text = ResultadoV;
                                txt_Nomina.Enabled = false;
                                nomina = Resultado;
                                controlador.InsertNomina(Codigo, txt_Nomina.Text, 2);
                            }
                            else
                            {
                                txt_Nomina.Text = "";
                                txt_Nomina.Focus();
                                txt_Nomina.Enabled = true;
                            }
                        }
                    }
                }
                else
                {
                    Resultado = controlador.ValidarNominaEmpleado(Resultado);
                    if (Resultado == "NO")
                    {
                        txt_Nomina.Text = "";
                        txt_Nomina.Focus();
                        txt_Nomina.Enabled = true;
                    }
                    else
                    {
                        string resulDuplicado;
                        resulDuplicado = controlador.ValidarNominaEmpleadoDuplicado(Resultado, Codigo);
                        if (resulDuplicado == "NO")
                        {
                            txt_Nomina.Text = Resultado;
                            txt_Nomina.Enabled = false;
                            nomina = Resultado;
                            controlador.InsertNomina(Codigo, txt_Nomina.Text, 3);
                        }
                        else
                        {
                            txt_Nomina.Text = "";
                            txt_Nomina.Focus();
                            txt_Nomina.Enabled = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MostrarNomina", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaCorreo()
        {
            try
            {
                MuestraCorreo = controlador.ValidaCorreo(Codigo, ClaseEstatica.Usuario.Usser);
                lbl_correo.Visible = true;
                txt_Correo.Visible = true;
                txt_Correo2.Visible = true;
                lbl_correoE.Visible = true;
                panel_Correo.Visible = true;
                List<string> ListaCorreo = new List<string>();
                if (MuestraCorreo == "NO")
                {
                    //lbl_correo.Visible = false;
                    if (string.IsNullOrEmpty(txt_Correo.Text))
                    {
                        ListaCorreo = controlador.InfoCorreoTemporal(Codigo);
                        txt_Correo.Text = ListaCorreo[0].ToUpper();
                    }

                    if (string.IsNullOrEmpty(txt_Correo2.Text)) txt_Correo2.Text = ListaCorreo[1].ToUpper();
                    txt_Correo.Enabled = false;
                    txt_Correo2.Enabled = false;
                    panel_Correo.Visible = true;
                    cxb_SinCorreo.Visible = false;
                    lbl_correo.Text = "Correo Electronico";
                    obligatorioCorreo = true;
                }
                else
                {
                    txt_Correo.Text = "";
                    txt_Correo2.Text = "";
                    txt_Correo.Enabled = true;
                    txt_Correo2.Enabled = true;
                    cxb_SinCorreo.Visible = true;
                    obligatorioCorreo = false;
                }

                string genericoC = "";
                genericoC = controlador.ValidarClienteGenerico(Codigo);
                if (genericoC != "NO")
                {
                    lbl_correo.Visible = false;
                    txt_Correo.Visible = false;
                    txt_Correo2.Visible = false;
                    lbl_correoE.Visible = false;
                    panel_Correo.Visible = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCorreo", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidacionInsertarCorreo()
        {
            try
            {
                correoCompleto = txt_Correo.Text + "@" + txt_Correo2.Text;
                bandera = 0;
                if (string.IsNullOrEmpty(txt_Correo.Text))
                {
                    MessageBox.Show("Debes ingresar una Cuenta de Correo", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    NumValidacion = 20;
                    obligatorio = true;
                    txt_Correo.Focus();
                    obligatorioCorreo = false;
                }
                else
                {
                    if (txt_Correo2.Text == "" && txt_Correo2.Focus())
                    {
                        if (validaDominio != 1)
                            MessageBox.Show("Debes ingresar un Dominio ejemplo: Hotmail.com", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        NumValidacion = 20;
                        obligatorio = true;
                        txt_Correo2.Focus();
                        obligatorioCorreo = false;
                    }
                    else
                    {
                        resultadoValidacion = controlador.ValidaCaracter(txt_Correo.Text, txt_Correo2.Text);

                        if (resultadoValidacion == "0")
                        {
                            resultadoGuardarCorreo =
                                controlador.GuardarCorreo(Codigo, txt_Correo.Text, txt_Correo2.Text);
                            if (resultadoGuardarCorreo == 0)
                            {
                                MessageBox.Show("Capture un Correo Valido", "Advertencia", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                                NumValidacion = 20;
                                obligatorio = true;
                                txt_Correo.Focus();
                                obligatorioCorreo = false;
                            }
                            else
                            {
                                uen = Canal == 7 || Canal == 6 ? 2 :
                                    Canal == 2 || Canal == 3 || Canal == 34 ? 1 :
                                    3;

                                obligatorioCorreo = true;
                            }
                        }
                        else
                        {
                            MessageBox.Show(resultadoValidacion, "Mensaje!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            NumValidacion = 20;
                            obligatorio = true;
                            txt_Correo.Focus();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }
        }

        private void GuardarCorreoC()
        {
            try
            {
                controlador.GuardarCorreoHist(Codigo, ClaseEstatica.Usuario.Usser, ClaseEstatica.Usuario.sucursal,
                    correoCompleto == "SINCORREO@SINCORREO.COM"
                        ? ClienteCon.getCorreoTemporalCliente(Cliente)
                        : correoCompleto);
                controlador.InsertaCorreo(idVenta, "VTAS", uen,
                    correoCompleto == "SINCORREO@SINCORREO.COM"
                        ? ClienteCon.getCorreoTemporalCliente(Cliente)
                        : correoCompleto);

                bandera = correoCompleto == "SINCORREO@SINCORREO.COM" ? 3 : bandera;

                controlador.HistorialCorreo(Codigo, TipoMovimiento, bandera, idVenta, "VTAS",
                    ClaseEstatica.Usuario.Usser, ClaseEstatica.Usuario.sucursal,
                    correoCompleto == "SINCORREO@SINCORREO.COM"
                        ? ClienteCon.getCorreoTemporalCliente(Cliente)
                        : correoCompleto);
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, e);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + e.Message, e);
            }
        }

        public void ValidaAgente()
        {
            try
            {
                string agente = cbx_Agente.Text;
                string Resultado = "";
                int suc = controlador.GetSucursal(cbx_Almacen.Text);
                Resultado = controlador.ValidarAgente(agente, suc);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (agente == "")
                    {
                        MessageBox.Show("Debe ingresar un Agente", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAgente = false;
                        cbx_Agente.Focus();
                    }
                    else
                    {
                        MessageBox.Show("El Agente es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAgente = false;
                        cbx_Agente.Focus();
                    }

                    cbx_Agente.Text = "";
                    NumValidacion = 20;
                    obligatorioAgente = false;
                    //mensajeValidacion = ", Canal de Venta";
                    //cbx_Agente.Focus();
                }
                else
                {
                    Agente = agente;
                    cbx_Agente.Items.Clear();
                    LlenaAgente();
                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text
                                              || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                        ActualizarInfoIdVenta();
                    //cbx_Canal.Focus();
                    obligatorioAgente = true;
                    NumValidacion = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAgente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaAlmacen()
        {
            try
            {
                Almacen = cbx_Almacen.Text;
                string Resultado = "";

                Resultado = controlador.ValidarAlmacen(Almacen);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (Almacen == "")
                    {
                        MessageBox.Show("Debe ingresar un Almacen", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAlmacen = false;
                    }
                    else
                    {
                        MessageBox.Show("El Almacen es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAlmacen = false;
                    }

                    cbx_Almacen.Text = "";
                    NumValidacion = 20;
                    cbx_Almacen.Focus();
                }
                else
                {
                    cbx_Almacen.Items.Clear();
                    LlenaAlmacen();

                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text
                                              || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                        ActualizarInfoIdVenta();
                    obligatorioAlmacen = true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAlmacen", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void validarCanalVenta()
        {
            try
            {
                string cliente = cbx_Cliente.Text;
                //canalC = Canal;
                if (cbx_Canal.Text == "")
                    Canal = 0;
                else
                    Canal = Convert.ToInt32(cbx_Canal.Text);
                string Resultado = "";
                Resultado = controlador.ValidarCanal(Canal);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (Canal == 0)
                    {
                        MessageBox.Show("Debe ingresar un canal correcto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cbx_Canal.Focus();
                        obligatorioCanal = false;
                    }
                    else
                    {
                        MessageBox.Show(
                            "El Canal: " + cbx_Canal.Text + " es incorrecto para la UEN: " + ClaseEstatica.Usuario.Uen,
                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cbx_Canal.Focus();
                        obligatorioCanal = false;
                    }

                    cbx_Canal.Text = "";
                    NumValidacion++;
                    //mensajeValidacion = ", Canal de Venta";
                }
                else
                {
                    if (cbx_Cliente.Text != "")
                    {
                        ValidaCanal();
                        if (existe != true) AgregaNuevoCanal();
                        cbx_Canal.Items.Clear();
                        if (cbx_Canal.Text == Convert.ToString(canalC))
                        {
                        }
                        else
                        {
                            Canal = Convert.ToInt32(cbx_Canal.Text);
                            cambiarCanal();
                        }

                        obligatorioCanal = true;
                    }
                    else
                    {
                        cbx_Canal.Text = "";
                        cbx_Cliente.Focus();
                        obligatorioCanal = false;
                    }

                    canalC = Canal;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarCanalVenta", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void ValidacionRefrecarCanal()
        {
            controlador.DeleteEventoValera(idVenta);
            if (cbx_Canal.Text == "76")
            {
                VentaDima();
                if (Canal == 76 && controlador.ValidaFuncionNuevoCasa(idVenta) == "Nuevo" &&
                    controlador.validaVentaCanalAsociados(Codigo) == 0 && controlador.ArticulosValr(Codigo) == false)
                {
                    DM0312_AgregarEvento evento = new DM0312_AgregarEvento();
                    evento.recibeSucursal = Convert.ToString(ClaseEstatica.Usuario.Sucursal);
                    evento.recibeEstatus = ValidaEstatus;
                    evento.recibeIdVenta = Convert.ToString(idVenta);
                    evento.recibeCliente = Cliente;
                    evento.ValidaCanalVenta = 76;
                    evento.recibeMensaje = 1;
                    evento.validaUsuarioDima = true;
                    evento.iCanalVenta = Canal;
                    evento.recibeIdecommerce = txb_Ecommerce.Text;
                    evento.recibeMov = Movimiento;
                    evento.ShowDialog();
                    if (exit)
                    {
                        Dispose();
                        exit = false;
                        return;
                    }
                }
            }

            if (cbx_Canal.Text == "76" || cbx_Canal.Text == "3" || cbx_Canal.Text == "7") ValidaExecCampoExtra();
        }

        private void validarCliente()
        {
            try
            {
                string cliente = Codigo;
                string Resultado = "";
                Resultado = controlador.ValidarCliente(Codigo);
                if (Resultado == "NO" || Resultado == "")
                {
                    MessageBox.Show("El Cliente es incorrecto", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    cbx_Cliente.Text = "";
                    txt_ClienteNombre.Text = "";
                    cbx_Canal.Text = "";
                    txt_TelParticular.Text = "";
                    txt_movil.Text = "";
                    NumValidacion++;
                    mensajeValidacion = ", Cuenta del Cliente";
                    cbx_Cliente.Focus();
                    obligatorioCliente = false;
                }
                else
                {
                    txt_ClienteNombre.Text = Resultado;
                    //Codigo = cbx_Cliente.Text;
                    cbx_Cliente.Items.Clear();
                    ValidaCanal();
                    NumValidacion = 0;
                    //ValidaTelefono();
                    if (existe != true) AgregaNuevoCanal();

                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text
                                              || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                        ActualizarInfoIdVenta();
                    //cbx_Agente.Focus();
                    obligatorioCliente = true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarCliente", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void cambiarCanal()
        {
            try
            {
                // GESSY 1030/1061 DIMA ocultar componentes
                txt_CodigoRecomendadoDima.Visible = false;
                lblCodigoRecomendado.Visible = false;
                chx_CodigoRecomendado.Visible = false;

                string validaCasa = string.Empty;
                validaCasa = controlador.validaCasa(Codigo, Canal);
                if (validaCasa == "Casa")
                    LlenaCondicion(1);
                else
                    LlenaCondicion(2);

                if (Canal == 2 || Canal == 6) //Contado y Apartado de cualquier uen
                {
                    TipoMovimiento = "Pedido";
                    validaMensajeBoton = "Contado";
                    txt_FormaPago.Text = "CONTADO";
                    //Si tiene Uen es dos es VUI POR LO TANTO DEBE SER AL CONTADO VUI SINO CONTADO MA
                    cbx_Condicion.Text = ClaseEstatica.Usuario.Uen == 2 ? "CONTADO VIU" : "CONTADO MA"; //"CONTADO MA";


                    modificaFormaBoton(validaMensajeBoton);
                }
                else if (Canal == 76 || Canal == 80 || Canal == 3 || Canal == 7 || Canal == 34 || Canal == 78 ||
                         Canal == 79) // Credito, Dima y empresarial //-CreditoEmpresario
                {
                    TipoMovimiento = "Solicitud Credito";
                    txt_FormaPago.Text = "MENSUAL";
                    if (Canal == 76 || Canal == 80)
                    {
                        validaMensajeBoton = "Dima";
                        txt_FormaPago.Text = "QUINCENAL";
                    }

                    if (Canal == 78) //-CreditoEmpresario
                    {
                        validaMensajeBoton = "Credito Empresario";
                        cbx_Condicion.Text = "12 M MA PP DIEM";
                    }

                    if (Canal == 3 || Canal == 7)
                    {
                        validaMensajeBoton = "Credito";
                        cbx_Condicion.Text = "12 M MA PP";

                        if (validaCasa == "Casa")
                            cbx_Condicion.Text = "12 M MA PP";
                        else
                            cbx_Condicion.Text = "12 M MA PP CN";
                    }

                    if (Canal == 34)
                    {
                        validaMensajeBoton = "Instituciones";
                        cbx_Condicion.Text = "12 M INST PP";
                        txt_FormaPago.Text = "QUINCENAL";
                    }

                    modificaFormaBoton(validaMensajeBoton);
                }
                else if (Canal == 11) // Mayoreo
                {
                    TipoMovimiento = "Pedido Mayoreo";
                    txt_FormaPago.Text = "MAYOREO";
                    cbx_Condicion.Text = "MAY 30-90 LOCAL";
                    modificaFormaBoton(validaMensajeBoton);
                }

                if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || canalC != EnviarA ||
                                          Condicion != cbx_Condicion.Text || Alm != Almacen
                                          || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text
                                          || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                    ActualizarInfoIdVenta();

                if (Canal == 76)
                    sTipoDima = controlador.obtenerTipoDima(Codigo);
                else
                    sTipoDima = string.Empty;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message, "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region "VENTA DIMA"

        public void VentaDima()
        {
            try
            {
                string[] Parametros =
                {
                    TipoMovimiento,
                    "",
                    "VTAS",
                    idVenta.ToString(),
                    Codigo,
                    ValidaEstatus,
                    Canal.ToString(),
                    "",
                    "",
                    "",
                    ""
                };

                if (controladorD.ShowNipVales(Parametros, valedigital))
                {
                    gbx_VentaDima.Visible = true;
                    gbx_VentaDetalle.Size = new Size(936, 419);
                    gbx_VentaDetalle.Select();
                }
                else
                {
                    gbx_VentaDima.Visible = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VentaDima", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void VentaDimaValidacion()
        {
            try
            {
                if (validaMensajeBoton == "Dima" && txt_vale.Visible)
                {
                    if ((txt_NIP.Text == "" || txt_vale.Text == "") && valedigital == 0)
                    {
                        MessageBox.Show("Debe ingresar un vale correcto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        vale = 0;
                        txt_vale.Focus();
                    }
                    else
                    {
                        if (btn_Afectar.Focused || btn_DatosEntrega.Focused || btn_Anticipo.Focused ||
                            btn_situaciones.Focused)
                        {
                            string msgPrecaucion = "";
                            bool valeValidacion = false;
                            string[] Parametros =
                            {
                                "",
                                "",
                                "VTAS",
                                Convert.ToString(idVenta),
                                Codigo
                            };
                            valeValidacion = CDetalleVenta.ValidarNipVale(ref msgPrecaucion, Parametros,
                                txt_vale.Text.Trim(), txt_NIP.Text.Trim(), valedigital);
                            if (valeValidacion)
                            {
                                vale = 1;
                            }
                            else
                            {
                                MessageBox.Show(msgPrecaucion, "Advertencia", MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                                vale = 0;
                            }
                        }
                        else
                        {
                            vale = 1;
                        }
                    }
                }
                else
                {
                    vale = 1;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("VentaDimaValidacion", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region "METODOS DE VENTA NUEVA"

        public void ObtenIdVenta()
        {
            try
            {
                if (chk_Custodia.Checked)
                {
                    custodia = "CUSTODIA";
                    imprimirComentario = "SI";
                }
                else
                {
                    custodia = "";
                }

                if (chk_Comentario.Checked)
                    imprimirComentario = "SI";
                else
                    imprimirComentario = "";

                Movimiento = TipoMovimiento;
                Cliente = Codigo;
                EnviarA = Canal;
                Alm = Almacen;
                Vendedor = Agente;
                Condicion = cbx_Condicion.Text;
                NoCtaPago = txt_Pago.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                FormaPago = txt_FormaPago.Text;
                FormaEnvio = cbx_FormaEnvio.Text;
                AgenteTelefonico = cbx_AgenteServicio.Text;
                pedComer = txb_Ecommerce.Text;
                monederoRedimir = cbx_RedimirM.Checked;
                comMayoreo = chk_Mayoreo.Checked;
                iva = chk_Iva.Checked;
                nomina = txt_Nomina.Text;


                //DesabilitarControles(false);
                if (validaMensajeBoton == "Mayoreo")
                    almacenOrigen = "V00096";
                else
                    almacenOrigen = controlador.AlmacenDeSucursal(ClaseEstatica.Usuario.sucursal);


                idVenta = controlador.IdVenta("MAVI", Movimiento, ClaseEstatica.Usuario.usuario, Cliente, EnviarA,
                    almacenOrigen, Vendedor, Condicion, ClaseEstatica.Usuario.sucursal,
                    ClaseEstatica.Usuario.Uen, NoCtaPago, Observacion, Comentario, Concepto, FormaPago, Referencia,
                    FormaEnvio, 1, AgenteTelefonico, pedComer, monederoRedimir, comMayoreo, custodia, iva,
                    imprimirComentario, nomina, txt_FormaCo.Text);

                lbl_ID.Text = Convert.ToString(idVenta);

                if (valedigital == 1) cargarPedidoValeDigital(valeDigitalDatos.tipo);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenIdVenta", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ActualizarInfoIdVenta()
        {
            try
            {
                bool Actualiza = new bool();

                if (chk_Custodia.Checked)
                    custodia = "CUSTODIA";
                else
                    custodia = "";

                if (chk_Comentario.Checked)
                    imprimirComentario = "SI";
                else
                    imprimirComentario = "";

                Movimiento = TipoMovimiento;
                Cliente = Codigo;
                EnviarA = Canal;
                Alm = Almacen;
                Vendedor = Agente;
                Condicion = cbx_Condicion.Text;
                NoCtaPago = txt_Pago.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                FormaPago = txt_FormaPago.Text;
                FormaEnvio = cbx_FormaEnvio.Text;
                AgenteTelefonico = cbx_AgenteServicio.Text;
                pedComer = txb_Ecommerce.Text;
                monederoRedimir = cbx_RedimirM.Checked;
                comMayoreo = chk_Mayoreo.Checked;
                iva = chk_Iva.Checked;
                nomina = txt_Nomina.Text;

                if (txtSubTotal.Text.Length > 0) dImporte = double.Parse(txtSubTotal.Text.Replace("$", ""));
                if (txtImpuestos.Text.Length > 0) dImpuestos = double.Parse(txtImpuestos.Text.Replace("$", ""));

                if (validaMensajeBoton == "Mayoreo")
                    almacenOrigen = "V00096";
                else
                    almacenOrigen = controlador.AlmacenDeSucursal(ClaseEstatica.Usuario.sucursal);
                if (idVenta != 0)
                    Actualiza = controlador.ActualizaIdVenta("MAVI", Movimiento, ClaseEstatica.Usuario.usuario, Cliente,
                        EnviarA, almacenOrigen, Vendedor, Condicion, ClaseEstatica.Usuario.sucursal,
                        ClaseEstatica.Usuario.Uen, NoCtaPago, Observacion, Comentario, Concepto, FormaPago, Referencia,
                        FormaEnvio, 2, idVenta, ValidaEstatus, AgenteTelefonico, pedComer, monederoRedimir,
                        comMayoreo, iva, custodia, imprimirComentario, nomina, txt_FormaCo.Text, dImporte, dImpuestos);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizarInfoIdVenta", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ActualizarVentaMDet()
        {
            try
            {
                CDetalleVenta.EliminarVentaDetalle(idVenta);
                //  List<DM0312_MVentaDetalle> detVenta = CDetalleVenta.ConsultaVentaDetalle(idVenta);
                //foreach (var listadetalleventa in detVenta)
                // {
                //       var listabuscar = ListVentaDetalle.Where(x => x.RenglonID == listadetalleventa.RenglonID).FirstOrDefault();
                //       if (listabuscar == null)
                //       {
                //           //CDetalleVenta.EliminarVentaDetalle(idVenta, listadetalleventa.RenglonID);
                //           CDetalleVenta.EliminarVentaDetalle(idVenta);
                //       }
                // }                
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void EliminarId()
        {
            try
            {
                bool Eliminar = new bool();

                // Registro Eliminacion Pedidos
                string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
                string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
                controlador.GuardarRegistroEliminado(myIP, idVenta);
                /////

                Eliminar = controlador.EliminarIdVenta(3, idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarId", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void EliminarVentaD()
        {
            ListVentaDetalle.RemoveAll(x => x.Articulo == null);
            try
            {
                if (ListVentaDetalle.Count > 1)
                {
                    DM0312_C_UsuarioDescuentoIncremento controller = new DM0312_C_UsuarioDescuentoIncremento();

                    int canal = Convert.ToInt32(cbx_Canal.Text);

                    DM0312_MVentaDetalle articulo = ListVentaDetalle.FirstOrDefault();

                    bool res = controller.InsertVentaD_(articulo, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text, 3);


                    IEnumerable<DM0312_MVentaDetalle> tiposerie = ListVentaDetalle.Where(x => x.Tipo == "Serie");

                    if (tiposerie.Count() == 0)
                        return;

                    foreach (DM0312_MVentaDetalle tipo in tiposerie)
                    {
                        DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();

                        controlador.DeleteSeriesLotes(tipo.Serie, idVenta, modeloVentaDetalle.Articulo);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarVentaD", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region MenuIncrementoDecremento

        private void UsrDescuento_Click(object sender, EventArgs e)
        {
            try
            {
                if (modeloVentaDetalle.Articulo == null)
                    return;

                if (modeloVentaDetalle.Precio <= 0)
                {
                    MessageBox.Show("No se puede aplicar un descuento a articulos con Precio menor o igual a 0",
                        "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DM0312_UsuarioDescuentoIncremento frm = new DM0312_UsuarioDescuentoIncremento();
                frm.model = modeloVentaDetalle;
                frm.canal = Convert.ToInt32(cbx_Canal.Text);
                frm.IdVenta = idVenta;
                frm.almacen = cbx_Almacen.Text;
                frm.agente = cbx_Agente.Text;
                frm.tipo = "UsrDescuento";
                frm.Text = "UsrDescuento";
                frm.TipoString = "Usuario Descuento";
                frm.ShowDialog();
                if (frm.Operacion)
                {
                    modeloVentaDetalle.TipoUsrDes_Incr = frm.tipo;
                    actualizaPrecioConDescuento(frm.precioActualizado);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("UsrDescuento", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void UsrIncremento_Click(object sender, EventArgs e)
        {
            if (modeloVentaDetalle.Articulo == null)
                return;

            DM0312_UsuarioDescuentoIncremento frm = new DM0312_UsuarioDescuentoIncremento();
            frm.model = modeloVentaDetalle;
            frm.canal = Convert.ToInt32(cbx_Canal.Text);
            frm.IdVenta = idVenta;
            frm.almacen = cbx_Almacen.Text;
            frm.agente = cbx_Agente.Text;
            frm.tipo = "UsrIncremento";
            frm.Text = "UsrIncremento";
            frm.TipoString = "Usuario Incremento";
            frm.ShowDialog();
            if (frm.Operacion)
            {
                modeloVentaDetalle.TipoUsrDes_Incr = frm.tipo;
                actualizaPrecioConDescuento(frm.precioActualizado);
                verificaGuardar = true;
            }
            else
            {
                verificaGuardar = false;
            }
        }

        private void actualizaPrecioConDescuento(double importe, DM0312_MVentaDetalle item = null)
        {
            try
            {
                if (item == null) item = modeloVentaDetalle;
                item.Precio = importe;

                item.PrecioS = importe.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + importe;

                item = actualizaMovGarantias(item);

                llenarGrid();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("actualizaPrecioConDescuento", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region ArticulosAfectar

        //Autor:Rodolfo Sanchez
        //Modulo:Punto de venta detalle
        //Desc: Insertar Articulos antes de afectar
        //Fecha:01/11/2017
        public bool guardarArticulos()
        {
            if (idVenta > 0) ActualizarVentaMDet();
            bool verifica = false;

            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();

            verifica = VerifyPrices();

            if (verifica) //si
            {
                ActualizarInfoIdVenta();

                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);

                if (ListVentaDetalle.Count == 0) //no
                {
                    MessageBox.Show("Sin articulos en el detalle", "Error!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return false;
                }

                int canal = Convert.ToInt32(cbx_Canal.Text);
                DM0312_C_UsuarioDescuentoIncremento controller = new DM0312_C_UsuarioDescuentoIncremento();
                int RenglonID = 1;
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle
                             .Where(x => !string.IsNullOrEmpty(x.Descripcion) || x.Cantidad > 0).ToList())
                {
                    item.RenglonID = RenglonID;

                    item.Renglon = 2048 * item.RenglonID;

                    if (item.Articulo.Contains("GARA")) //no
                        item.Tipo = "Servicio";

                    if (item.Juego != null) //no
                    {
                        DM0312_MVentaDetalle art = ListVentaDetalle
                            .Where(x => x.Articulo == item.Articulo_Ligado && item.bArtPromocion == false)
                            .FirstOrDefault();
                        if (art != null)
                            item.RenglonID = art.RenglonID;

                        item.Tipo = "C";
                    }

                    RenglonID++;

                    //if (item.Serie != string.Empty)//si
                    if (item.Serie != null) //si						   
                    {
                        bool res_ = controller.UpdateSeries(idVenta, item.Articulo, item.RenglonID);
                    }

                    string sPadres = string.Empty;
                    if (item.listaPadres != null)
                        sPadres = string.Join(",", item.listaPadres.Select(x => x.sArticulo).ToList());


                    //if (controller.ValidaRenglonID(idVenta, item.RenglonID, item.Renglon,item.Articulo))
                    if (controller.ValidaInsertaVenta(item.Articulo, idVenta, item.Renglon) && item.Tipo != "C" &&
                        item.bArtPromocion == false) //no
                    {
                        if (item.TipoUsrDes_Incr == "UsrDescuento")
                        {
                            controller.ActualizaDescuentoMavi(idVenta, item.Renglon, item.RenglonAnterior);

                            controller.ActualizaVentaD(idVenta, item.Renglon, item.RenglonID, item.Articulo,
                                item.Precio, item.Observaciones, item.Cantidad);
                        }
                        else
                        {
                            if (!controller.ValidaRenglonID(idVenta, item.RenglonID, item.Renglon))
                                controller.insertarVentaDFlujoPromo(item, idVenta, Convert.ToInt32(cbx_Canal.Text),
                                    cbx_Almacen.Text, cbx_Agente.Text, 1, item.idPromocion, item.Articulo_Ligado);
                            else
                                controller.ActualizaVentaD(idVenta, item.Renglon, item.RenglonID, item.Articulo,
                                    Math.Round(item.Precio, 2), item.Observaciones, item.Cantidad);
                        }
                    }
                    else
                    {
                        //-ModuloPromociones 
                        double precioActualizado = 0;
                        if (item.listaPadres == null) item.listaPadres = new List<clsModeloTipoPromocion>();
                        if (item.listaPadres.Count > 0 && !item.Articulo.Contains("GARA") &&
                            string.IsNullOrEmpty(item.Juego) && item.bArtPromocion)
                        {
                            if (!controller.ValidaInsertaVenta(item.Articulo, idVenta, item.Renglon))
                            {
                                if (controller.ValidaRenglonID(idVenta, item.RenglonID, item.Renglon))
                                {
                                    item.RenglonID = item.RenglonID + 1;
                                    item.Renglon = 2048 * item.RenglonID;
                                }

                                if (!controller.InsertVentaD_(item, idVenta, Convert.ToInt32(cbx_Canal.Text),
                                        cbx_Almacen.Text, cbx_Agente.Text, 1, item.idPromocion, sPadres,
                                        item.iIdTipoPromocion)) break;
                            }

                            controller.exec_spPropreAutorizarDescuento("CONTM00093", "afectadima", idVenta, item,
                                item.Precio);

                            if (controller.exec_SP_MAVIRM0850InsertaAutPrecioXUsr(idVenta, "CONTM00093", "CONTM00093",
                                    item)) //si
                            {
                                precioActualizado = item.Precio;
                                item.RenglonAnterior = item.Renglon;
                                item.TipoUsrDes_Incr = "UsrDescuento";
                                //modeloVentaDetalle.TipoUsrDes_Incr = "UsrDescuento";
                            }
                            else
                            {
                                break;
                            }

                            actualizaPrecioConDescuento(precioActualizado, item);
                        }
                        else
                        {
                            bool res = false;
                            controller.InsertVentaD_I(item.Renglon, item.RenglonID, idVenta);
                            if (item.listaPadres == null) item.listaPadres = new List<clsModeloTipoPromocion>();
                            if (item.listaPadres.Count > 0 && item.bArtPromocion && item.idPromocion != 0) //si
                            {
                                double vPorcDesc =
                                    clsControladorPromociones.ObtenerDescuento(item.idPromocion, item.Articulo);

                                item.Precio = controlador.GetPrice(item.Articulo, idVenta, item.Renglon,
                                    cbx_RedimirM.Checked, canalC, Condicion, ClaseEstatica.Usuario.sucursal,
                                    TipoMovimiento);
                                item.PrecioS = item.Precio.ToString("C", Thread.CurrentThread.CurrentCulture);

                                item.Total = item.Precio * item.Cantidad;
                                item.TotalS = item.Total.ToString("C", Thread.CurrentThread.CurrentCulture);

                                res = controller.InsertVentaD_(item, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text,
                                    1, item.idPromocion, sPadres, item.iIdTipoPromocion);

                                if (res) //si
                                {
                                    double vDesc = Math.Truncate(item.Precio * vPorcDesc) / 100;
                                    item.Precio = item.Precio - vDesc;
                                    item.PrecioS = item.Precio.ToString("C", Thread.CurrentThread.CurrentCulture);

                                    item.Total = item.Precio * item.Cantidad;
                                    item.TotalS = item.Total.ToString("C", Thread.CurrentThread.CurrentCulture);

                                    clsControladorPromociones.ActualizarPrecio(item, idVenta);
                                }
                            }
                            else
                            {
                                res = controller.InsertVentaD_(item, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text,
                                    1);
                            }

                            if (!res) //no
                            {
                                ListVentaDetalle.Add(model);
                                return false;
                            }
                        }
                    }
                }
            }

            if (!verifica)
                return false;

            ListVentaDetalle.Add(model);

            return true;
        }

        //Autor:Rodolfo Sanchez
        //Modulo:Punto de venta detalle
        //Desc: Verificar articulos antes de agregarlos
        //Fecha:07/11/2017
        private bool VerifyPrices()
        {
            List<string> Arts = new List<string>();

            IEnumerable<string> articulos = ListVentaDetalle.Where(x => x.Precio == 99999.99).Select(a => a.Articulo);

            if (articulos.Count() > 0)
            {
                string text = string.Empty;

                foreach (string i in articulos.ToList())
                    if (text.Length == 0)
                        text = i + ",";
                    else
                        text = text + i + ",";
                text = text.Substring(0, text.Length - 1);

                MessageBox.Show("Los articulos:" + text + " deben eliminarse o cambiar la condicion", "Error!!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        #endregion

        private void ValidaExecCampoExtra(string sTipoCliente = "")
        {
            int valida = controlador.ValidaCampoExtra(ClaseEstatica.Usuario.Usser, idVenta);
            if (valida == 1)
            {
                DM0312_CamposExtra campoExtra = new DM0312_CamposExtra();
                campoExtra.camposExtraRecibe.Mov = TipoMovimiento;
                campoExtra.camposExtraRecibe.IdVenta = Convert.ToInt32(idVenta);
                campoExtra.camposExtraRecibe.Cliente = cbx_Cliente.Text;
                campoExtra.camposExtraRecibe.Estatus = false;
                DM0312_CamposExtra.validaInsertUsuario = false;
                campoExtra.psAgente = cbx_Agente.Text;
                campoExtra.ShowDialog();
            }
            else
            {
                if (canalC == 3 || canalC == 7)
                    if (sTipoCliente == "Casa")
                        cExtra.insertarEvento(int.Parse(lbl_ID.Text), lbl_Estatus.Text, Agente, "VTA00015",
                            "Campos Extras");
            }
        }

        private void RefrescarFormaPago()
        {
            for (int i = flp_FormaPago.Controls.Count - 1; i >= 0; i--)
            {
                if (flp_FormaPago.Controls[i] is ComboBox)
                {
                    LastFormaPagoSelected.Remove(Convert.ToInt32(flp_FormaPago.Controls[i].Tag));
                    FormasPagoAgregadas.Remove(flp_FormaPago.Controls[i].Text);
                }

                flp_FormaPago.Controls.RemoveAt(i);
                AnticipoMontoTotal();
            }

            EfectivoSeleccionado();

            AgregarFormaPago();
        }

        private void llenarGrid()
        {
            string cambio;
            //oldValue = "";
            panel1.Visible = false;
            //dvg_detalleVenta.DataSource = null;
            //dvg_detalleVenta.Columns.Clear();
            dvg_detalleVenta.DataSource = ListVentaDetalle.ToList();


            DataGridViewButtonColumn ButtonEdit = new DataGridViewButtonColumn();
            ButtonEdit.Name = "Opcion";
            if (dvg_detalleVenta.Columns["Opcion"] == null) dvg_detalleVenta.Columns.Insert(0, ButtonEdit);

            if (ListVentaDetalle.Count() >= 1)
            {
                int index = ListVentaDetalle.Count() - 1;

                DataGridViewTextBoxCell cell = new DataGridViewTextBoxCell();
                //dvg_detalleVenta.Rows[index].Cells[0] = cell;
            }


            //dvg_detalleVenta tamaño columnas
            dvg_detalleVenta.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.None; // AutoSizeColumnsMode


            VerCosto();

            dvg_detalleVenta.Columns[5].Visible = verCosto;


            dvg_detalleVenta.Columns[9].Visible = false;

            //HeadersText
            dvg_detalleVenta.Columns[0].HeaderText = "";
            dvg_detalleVenta.Columns[0].ToolTipText = "Editar";

            //ReadOnly
            dvg_detalleVenta.Columns[6].ReadOnly = true;
            dvg_detalleVenta.Columns[4].ReadOnly = true;
            dvg_detalleVenta.Columns[3].ReadOnly = true;
            dvg_detalleVenta.ReadOnly = true;


            if (ListVentaDetalle.Count > 0)
            {
                total = Convert.ToDouble(ListVentaDetalle.Where(x => x.Juego == null).Sum(x => x.Total).ToString());

                double total_ = Math.Truncate(100 * total) / 100;

                total = total_;

                subtotal = Convert.ToDouble(
                    ListVentaDetalle.Where(x => x.Juego == null).Sum(x => x.SubTotal).ToString());

                double subtotal_ = Math.Truncate(100 * subtotal) / 100;

                subtotal = subtotal_;

                //saldo restante para anticipos
                saldoRestante = total;

                impuesto = total - subtotal;

                double impuesto_ = Math.Truncate(100 * impuesto) / 100;

                impuesto = impuesto_;

                txtSubTotal.Text =
                    subtotal.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + subtotal.ToString();

                txtTotal.Text = total.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + total.ToString();

                lbl_importeTotal.Text = "Importe total: " + total.ToString("C");

                txtImpuestos.Text =
                    impuesto.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + impuesto.ToString();

                int index_ = 0;

                int index = 0;

                if (ListVentaDetalle.Count > 1)
                    index_ = ListVentaDetalle.Count - 1;

                if (ListVentaDetalle.Count > 1)
                    index = ListVentaDetalle.Count - 2;

                //DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                modeloVentaDetalle = ListVentaDetalle[index];


                dvg_detalleVenta.Rows[index].Selected = true;
                dvg_detalleVenta.CurrentCell = dvg_detalleVenta.Rows[index].Cells[0];

                modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.SelectedRows[0].DataBoundItem;

                if (modeloVentaDetalle.bArtPromocion)
                {
                    //dvg_detalleVenta.Rows[index].DefaultCellStyle.BackColor = Color.Yellow;
                }

                llenarLabels(modeloVentaDetalle);

                dvg_detalleVenta.Rows[index].Cells[1].Selected = true;

                IEnumerable<DM0312_MVentaDetalle> validate = ListVentaDetalle.Where(a => a.Linea == null);

                if (validate.Count() == ListVentaDetalle.Count()) cbx_RedimirM.Visible = true;

                if (ListVentaDetalle.Where(z => z.Linea != null)
                    .Any(x => x.Linea.Contains("CREDILANA") || x.Linea.Contains("SEGUROS")))
                {
                    cbx_RedimirM.Checked = false;
                    cbx_RedimirM.Visible = false;
                }
                else
                {
                    cbx_RedimirM.Visible = true;
                }

                if (validaMensajeBoton == "Instituciones" || validaMensajeBoton == "Mayoreo")
                    cbx_RedimirM.Visible = false;

                if (validaMensajeBoton == "Contado")
                    if (ClaseEstatica.Usuario.Uen == 1)
                        cbx_RedimirM.Visible = false;

                if (ListVentaDetalle.Count >= 2)
                {
                    MenuVentaDetalle.Enabled = true;
                    btnGuardar.Enabled = true;
                }
                else
                {
                    btnGuardar.Enabled = false;
                    MenuVentaDetalle.Enabled = false;
                }

                cambio = ListVentaDetalle[0].Articulo;

                chx_Die.Visible = false;
                //-Die
                if (controlador.ValidarSucursalDie())
                    if (controlador.validarCanalVentaDie(Canal))
                        if (controlador.validarArticuloDie(cambio))
                        {
                            chx_Die.Visible = true;
                            gbx_DatosGenerales.Size = new Size(711, 250);
                        }

                panel1.Visible = false;
                //-- STP
                if (controlador.ValidarSucursalSTP())
                    if (controlador.validarCanalVentaSTP(Canal))
                        if (controlador.validarArticuloSTP(cambio))
                        {
                            tipoCuenta = shm.ObtenerInfoCLABE(Cliente);
                            panel1.Visible = true;
                            chkTransferencia.Checked = false;
                            chkTransferencia.Visible = true;
                            btnCuentaClabe.Visible = true;
                            gbx_DatosGenerales.Size = new Size(711, 250);

                            if (Canal == 80)
                            {
                                panel1.Visible = false;
                                chkTransferencia.Checked = false;
                            }
                        }

                double dMonedero = Convert.ToDouble(ListVentaDetalle.Where(x => x.dMontoMonedero != 0)
                    .Sum(x => x.dMontoMonedero).ToString());
                txtMonedero.Text = dMonedero.ToString("C", Thread.CurrentThread.CurrentCulture);
            }


            dvg_detalleVenta.Select();
        }

        private void llenarLabels(DM0312_MVentaDetalle model)
        {
            lblUnidad.Text = "Unidad:" + model.Unidad;
            lblDescr.Text = "Descripción:" + model.Descripcion;
        }

        //actualiza totales
        private void actualizaMov(string cambio, DataGridViewCellEventArgs ce, bool Disminuir, int iOldValue)
        {
            #region //-ModuloPromociones

            if (ce.ColumnIndex == 2 && !modeloVentaDetalle.bArtPromocion)
            {
                List<DM0312_MVentaDetalle> articulos = ListVentaDetalle
                    .Where(a => a.bArtPromocion && a.Articulo_Ligado == modeloVentaDetalle.Articulo).ToList();

                if (Disminuir)
                {
                    List<DM0312_MVentaDetalle> copia = ListVentaDetalle.ToList();
                    foreach (DM0312_MVentaDetalle item in copia.Where(x => x.listaPadres != null))
                        for (int i = 0; i < item.listaPadres.Count; i++)
                            if (item.listaPadres[i].sArticulo == modeloVentaDetalle.Articulo)
                                ListVentaDetalle.Remove(item);
                }

                ValidaPromocion(modeloVentaDetalle.Articulo, modeloVentaDetalle.Cantidad, modeloVentaDetalle.Precio,
                    modeloVentaDetalle.Renglon, articulos, true, false, Disminuir);
                AgregarArticulosPromo();
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                DM0312_MVentaDetalle modelVacio = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(modelVacio);
            }

            if (modeloVentaDetalle.bArtPromocion)
            {
                ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                int cantidadHijos = ListVentaDetalle.Where(x => x.idPromocion == modeloVentaDetalle.idPromocion)
                    .Sum(x => x.Cantidad);

                List<clsModeloPromocion> lsModeloPromocion =
                    clsControladorPromociones.ObtenerPromocion(modeloVentaDetalle.idPromocion);
                int vMaxHijos = lsModeloPromocion[0].ArticulosPermitidos;
                int vPzaMax = clsControladorPromociones.ObtenerPzaPromocion(modeloVentaDetalle.idPromocion);

                if (cantidadHijos > vPzaMax)
                {
                    MessageBox.Show("No se pueden agregar mas articulos de los que permite la promocion.",
                        "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    modeloVentaDetalle.Cantidad = iOldValue;
                }

                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(model);

                return;
            }

            modeloVentaDetalle.Precio = controlador.GetPrice(modeloVentaDetalle.Articulo, idVenta,
                modeloVentaDetalle.Renglon, cbx_RedimirM.Checked, canalC, Condicion, ClaseEstatica.Usuario.sucursal,
                TipoMovimiento);
            //controlador.GetPrice(modeloVentaDetalle.Articulo, idVenta, modeloVentaDetalle.Renglon, cbx_RedimirM.Checked);
            modeloVentaDetalle.PrecioS =
                modeloVentaDetalle.Precio.ToString("C",
                    Thread.CurrentThread.CurrentCulture); //"$" + modeloVentaDetalle.Precio;
            double cantidad = Convert.ToDouble(cambio);
            //saca valor del Iva
            double iva = modeloVentaDetalle.impuesto / 100 + 1;
            double subtotalParcial = cantidad * (modeloVentaDetalle.Precio / iva);
            double value = Math.Truncate(100 * subtotalParcial) / 100;
            modeloVentaDetalle.SubTotal = Convert.ToDouble(value);
            modeloVentaDetalle.Total = cantidad * modeloVentaDetalle.Precio;
            double total = Math.Truncate(100 * modeloVentaDetalle.Total) / 100;
            modeloVentaDetalle.TotalS = total.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + total;

            //-1670
            double dMontoMonedero = controlador.obtenerMontoMonedero(idVenta, modeloVentaDetalle.Articulo,
                modeloVentaDetalle.Precio, modeloVentaDetalle.Cantidad);
            modeloVentaDetalle.dMontoMonedero = dMontoMonedero;
            modeloVentaDetalle.sMontoMonedero = string.Format("{0:C}", dMontoMonedero);
            if (modeloVentaDetalle.Tipo == "Juego")
            {
                ListVentaDetalle.Where(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo).Select(e =>
                {
                    e.Cantidad = (int)cantidad * Convert.ToInt32(e.impuesto2);
                    return e;
                }).ToList();
                foreach (DM0312_MVentaDetalle item_ in ListVentaDetalle)
                {
                    double ivaP = item_.impuesto / 100 + 1;
                    double subtotalParcialP = item_.Cantidad * (item_.Precio / ivaP);
                    double valueP = Math.Truncate(100 * subtotalParcialP) / 100;
                    item_.SubTotal = Convert.ToDouble(valueP);
                    item_.Total = item_.Cantidad * item_.Precio;
                    double totalP = Math.Truncate(100 * item_.Total) / 100;
                    item_.TotalS = totalP.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + total;
                    ///////////////////////////////////////////////////////////////////////////////////
                }
            }

            #endregion

            llenarGrid();
            //EliminarArticulosRepetidosVentaDetalle();
            llenarGrid();
            //1832
            ValidarArticuloPequeno();
        }

        ///////////////////////////////////////////////////////CANDADOPOREDAD///////////////////////////////////////////////////////////////
        public bool CandadoEdad(string cliente)
        {
            DM0312_CVentanaEntrada controladorV = new DM0312_CVentanaEntrada();
            int anios = 0;
            anios = controlador.CandadoEdadAños("SEGURO DE VIDA");

            DateTime nacimiento = controladorV.FechaNacimientoCliente(cliente); //Fecha de nacimiento
            int edad = DateTime.Today.AddTicks(-nacimiento.Ticks).Year - 1;

            if (edad > anios && anios != 0)
            {
                MessageBox.Show("Cliente " + cliente + " no califica por edad", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return false;
            }

            return true;
        }

        private bool BuscarArticulos(string articulo, bool Editar, int cantidad = 1, bool Excel = false,
            bool BotonEditar = false, bool bPromo = false, DataGridViewCellEventArgs ce = null)
        {
            if (!Editar)
            {
                bool bVentaLinea = false;
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                    if (!string.IsNullOrEmpty(item.Linea))
                        if (CDetalleVenta.validarFamiliaLinea(item.Linea))
                            bVentaLinea = true;

                if (bVentaLinea)
                {
                    MessageBox.Show(
                        "No se puede agregar otro articulo, Cuando tienes un tipo Serie de la Linea MOTOCICLETAS",
                        "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    return false;
                }
            }

            DataTable tabla = new DataTable();
            //-Datalogic
            if (ClaseEstatica.iRecarga == 1)
            {
                tabla = controlador.BuscaArticulos_VentaDetalle(articulo.Trim(), Almacen, 3);
            }
            else
            {
                if (!string.IsNullOrEmpty(sTipoDima))
                    tabla = controlador.BuscaArticulos_VentaDetalle(articulo.Trim(), Almacen, 4, sTipoDima);
                else
                    tabla = controlador.BuscaArticulos_VentaDetalle(articulo.Trim(), Almacen, 1);
            }

            if (tabla.Rows.Count == 1)
            {
                //modelo vacio para agregar fila vacia
                DM0312_MVentaDetalle modelVacio = new DM0312_MVentaDetalle();

                //buscar si existe el articulo en la lista para no agregar otro igual
                List<DM0312_MVentaDetalle> ArtRep = ListVentaDetalle
                    .Where(x => x.Articulo == tabla.Rows[0].ItemArray[0].ToString() && !x.bArtPromocion).ToList();


                if (ArtRep.Count > 0)
                    if (controlador.ArticulosRepetidos(ArtRep, Editar))
                    {
                        ArtRep[0].Cantidad = ArtRep[0].Cantidad + 1;
                        if (ArtRep[0].Cantidad > ArtRep[0].Disponible)
                        {
                            ArtRep[0].Cantidad = ArtRep[0].Cantidad - 1;
                            MessageBox.Show("No se pueden agregar mas articulos de los que se tienen disponible",
                                "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }

                        ArtRep[0].Precio = controlador.GetPrice(ArtRep[0].Articulo, idVenta, ArtRep[0].Renglon,
                            cbx_RedimirM.Checked, canalC, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);
                        //controlador.GetPrice(modeloVentaDetalle.Articulo, idVenta, modeloVentaDetalle.Renglon, cbx_RedimirM.Checked);
                        ArtRep[0].PrecioS =
                            ArtRep[0].Precio
                                .ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + modeloVentaDetalle.Precio;
                        //saca valor del Iva
                        double iva = ArtRep[0].impuesto / 100 + 1;
                        double subtotalParcial = ArtRep[0].Cantidad * (ArtRep[0].Precio / iva);
                        double a = Math.Truncate(100 * subtotalParcial) / 100;
                        ArtRep[0].SubTotal = Convert.ToDouble(a);
                        ArtRep[0].Total = ArtRep[0].Cantidad * ArtRep[0].Precio;
                        double total = Math.Truncate(100 * ArtRep[0].Total) / 100;
                        ArtRep[0].TotalS = total.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + total;

                        #region

                        //-ModuloPromociones

                        if (string.IsNullOrEmpty(ArtRep[0].Articulo_Ligado) ||
                            ArtRep[0].Articulo_Ligado.Contains("GARA"))
                        {
                            List<DM0312_MVentaDetalle> articulos = ListVentaDetalle
                                .Where(b => b.bArtPromocion && b.Articulo_Ligado == ArtRep[0].Articulo).ToList();
                            ValidaPromocion(ArtRep[0].Articulo, ArtRep[0].Cantidad, ArtRep[0].Precio, ArtRep[0].Renglon,
                                articulos);
                            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                            AgregarArticulosPromo();
                            DM0312_MVentaDetalle modelVacioc = new DM0312_MVentaDetalle();
                            ListVentaDetalle.Add(modelVacioc);
                        }

                        #endregion

                        //MessageBox.Show("Articulo duplicado", "Error.!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        DM0312_MVentaDetalle last = ListVentaDetalle.Last();
                        ListVentaDetalle.Remove(last);
                        ListVentaDetalle.Add(new DM0312_MVentaDetalle());
                        llenarGrid();

                        //1832
                        ValidarArticuloPequeno();

                        return true;
                    }

                //llenado del modelo por el articulo nuevo
                DM0312_MVentaDetalle model_ = new DM0312_MVentaDetalle();
                //-Datalogic
                if (ClaseEstatica.iRecarga == 1)
                {
                    if (ListVentaDetalle.Count == 2) ListVentaDetalle.Clear();
                    model_.Articulo = tabla.Rows[0].ItemArray[1].ToString();
                    model_.Descripcion = tabla.Rows[0].ItemArray[2].ToString();
                    model_.Tipo = tabla.Rows[0].ItemArray[3].ToString();
                    model_.proveedor = tabla.Rows[0].ItemArray[4].ToString();
                    model_.Precio = int.Parse(tabla.Rows[0].ItemArray[5].ToString());
                    model_.Linea = tabla.Rows[0].ItemArray[4].ToString();
                    model_.Unidad = "RECARGA";
                    model_.impuesto = double.Parse(tabla.Rows[0].ItemArray[7].ToString());
                    model_.PrecioS = int.Parse(tabla.Rows[0].ItemArray[5].ToString())
                        .ToString("C", Thread.CurrentThread.CurrentCulture);
                }
                else
                {
                    foreach (DataRow row in tabla.Rows)
                    {
                        model_.Articulo = row["Codigo"].ToString();
                        model_.Descripcion = row["Nombre"].ToString();
                        model_.Linea = row["Linea"].ToString();
                        model_.Disponible = Convert.ToInt32(row["Disponible"].ToString());
                        model_.impuesto = Convert.ToDouble(row["Impuesto"].ToString());
                        model_.Tipo = row["Tipo"].ToString();
                        model_.Unidad = row["Unidad"].ToString();
                    }
                }

                if (model_.Linea.Contains("VALERA"))
                {
                    MessageBox.Show("Articulo Restringido", "Error.!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return false;
                }


                model_.PropreListaID = controlador.GetPropreListaID(idVenta, model_.Articulo, cbx_RedimirM.Checked);

                //eliminar modelo vacio de la lista antes de agregar el otro
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);


                //listas para calcular renglones 
                if (ListVentaDetalle.Count == 0)
                    model_.RenglonID = 1;
                else
                    model_.RenglonID = ListVentaDetalle.Count + 1;

                if (cantidad != 1)
                    model_.Cantidad = cantidad;
                else
                    model_.Cantidad = 1;

                model_.Renglon = 2048 * model_.RenglonID;

                if (!Editar)
                {
                    if (ValidaSegurosyCredilanas(true, model_, false))
                        if (ListVentaDetalle.Count > 0)
                        {
                            MessageBox.Show(
                                "No se puede agregar articulo es Linea Seguros o Credilana si ya existen otros articulos",
                                "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            //-Die
                            if (chx_Die.Visible)
                            {
                                chx_Die.Visible = false;
                                panel1.Visible = false;
                            }

                            return false;
                        }


                    if (CDetalleVenta.validarFamiliaLinea(model_.Linea))
                        if (ListVentaDetalle.Count > 0)
                        {
                            MessageBox.Show(
                                "No se puede agregar articulo es Linea MOTOCICLETAS si ya existen otros articulos",
                                "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;
                        }
                }

                if (Editar)
                {
                    if ((ListVentaDetalle.Count() > 1) & CDetalleVenta.validarFamiliaLinea(model_.Linea))
                    {
                        MessageBox.Show(
                            "No se puede agregar articulo es Linea MOTOCICLETAS si ya existen otros articulos",
                            "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return false;
                    }


                    if (ValidaSegurosyCredilanas(true, model_))
                        if (ListVentaDetalle.Count > 0)
                        {
                            MessageBox.Show(
                                "No se puede agregar articulo es Linea Seguros o Credilana si ya existen otros articulos",
                                "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;
                        }

                    DeleteInlist(BotonEditar);
                }


                /*costo*/
                double costo =
                    controlador.ExecspVerCosto(ClaseEstatica.Usuario.sucursal, model_.Articulo, model_.Unidad);

                double value_ = Math.Truncate(100 * costo) / 100;

                model_.Costo = costo;

                model_.Costo_ = value_.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value_;

                /*guarda modelo si es canal 34*/
                //if (canalC == 34)
                //{
                //    CUsuarioDes.InsertVentaD_(model_, idVenta, canalC, cbx_Almacen.Text, cbx_Agente.Text, 1);
                //}

                /*precio*/
                double precio = controlador.GetPrice(model_.Articulo, idVenta, model_.Renglon, cbx_RedimirM.Checked,
                    canalC, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);

                double descuent = controlador.obtenerDescuentoCategoria(idVenta, model_.Articulo);
                if (descuent > 0)
                    model_.Observaciones = descuent + "% de descuento x categoria.";
                else
                    model_.Observaciones = "";

                double value = Math.Truncate(100 * precio) / 100;

                model_.Precio = precio;

                model_.PrecioS = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value;

                /*totales*/
                Dictionary<double, double> item_ = new Dictionary<double, double>();

                item_ = actualizaMovPorModel(model_.Cantidad.ToString(), model_);

                model_.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());

                model_.Total = Convert.ToDouble(item_.Values.FirstOrDefault());

                model_.TotalS =
                    item_.Values.FirstOrDefault()
                        .ToString("C",
                            Thread.CurrentThread
                                .CurrentCulture); //"$" + Convert.ToDouble(item_.Values.FirstOrDefault());

                if (model_.Tipo == "Juego")
                {
                    ArmarPaquetes(model_, Excel);
                    return true;
                }

                //-1670
                double dMontoMonedero =
                    controlador.obtenerMontoMonedero(idVenta, model_.Articulo, model_.Precio, model_.Cantidad);
                model_.dMontoMonedero = dMontoMonedero;
                model_.sMontoMonedero = string.Format("{0:C}", dMontoMonedero);


                //Garantias               

                DM0312_MVentaDetalle Garantias = new DM0312_MVentaDetalle();
                if (valorModificado != 1) Garantias = controlador.GetGarantias(model_.Articulo, cbx_Canal.Text);

                if ((Garantias != null && valedigital == 0) ||
                    (valedigital == 1 && valeDigitalDatos.tipo == 3 && Garantias != null))
                {
                    //Diccionario con datos totalizados
                    Dictionary<double, double> item = new Dictionary<double, double>();
                    //modelo de garantias para agregar al Grid
                    DM0312_MVentaDetalle modeloGarantia = new DM0312_MVentaDetalle();
                    modeloGarantia = BuscaArticulosGarantia(Garantias.Articulo);

                    if (modeloGarantia != null)
                    {
                        modeloGarantia.Articulo_Ligado = model_.Articulo;

                        DM0312_PuntoDeVenta_Garantias frm = new DM0312_PuntoDeVenta_Garantias();
                        frm.garantias = modeloGarantia;
                        frm.ShowDialog();

                        if (frm.flag)
                        {
                            model_.Cantidad = frm.Cantidad;

                            item = actualizaMovPorModel(model_.Cantidad.ToString(), model_);

                            model_.SubTotal = Convert.ToDouble(item.Keys.FirstOrDefault());

                            model_.Total = Convert.ToDouble(item.Values.FirstOrDefault());

                            model_.TotalS = item.Values.FirstOrDefault()
                                .ToString("C",
                                    Thread.CurrentThread
                                        .CurrentCulture); // "$" + Convert.ToDouble(item.Values.FirstOrDefault());

                            if (frm.garantias.Cantidad > 0)
                            {
                                model_.Articulo_Ligado = frm.garantias.Articulo;

                                frm.garantias.RenglonID = model_.RenglonID + 1;


                                frm.garantias.PropreListaID = controlador.GetPropreListaID(idVenta,
                                    frm.garantias.Articulo, cbx_RedimirM.Checked);

                                frm.garantias.Renglon = 2048 * frm.garantias.RenglonID;

                                /*costo*/
                                double costog = controlador.ExecspVerCosto(ClaseEstatica.Usuario.sucursal,
                                    frm.garantias.Articulo, frm.garantias.Unidad);

                                double valueg = Math.Truncate(100 * costog) / 100;

                                frm.garantias.Costo = valueg;

                                frm.garantias.Costo_ =
                                    valueg.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + valueg;

                                bool gara = GarantiasAdd(frm.garantias.Articulo, frm.garantias.Cantidad);

                                //agregar Series al modelo
                                model_.Serie = llenarSeries(model_, true);

                                //se agrega modelo insertado
                                ListVentaDetalle.Add(model_);

                                if (!gara)
                                    //articulo con garantia
                                    ListVentaDetalle.Add(frm.garantias);
                            }
                            else
                            {
                                //agregar Series al modelo
                                model_.Serie = llenarSeries(model_, true);

                                ListVentaDetalle.Add(model_);
                            }
                        }
                        else
                        {
                            //agregar Series al modelo
                            model_.Serie = llenarSeries(model_, true);

                            //se agrega modelo insertado
                            ListVentaDetalle.Add(model_);
                        }
                    }
                    else
                    {
                        ListVentaDetalle.Add(model_);
                    }
                }
                else
                {
                    //agregar Series al modelo
                    model_.Serie = llenarSeries(model_, true);

                    //se agrega modelo insertado
                    ListVentaDetalle.Add(model_);
                }

                #region //-ModuloPromociones

                if (string.IsNullOrEmpty(model_.Articulo_Ligado) || model_.Articulo_Ligado.Contains("GARA"))
                {
                    ValidaPromocion(model_.Articulo, model_.Cantidad, model_.Precio, model_.Renglon);
                    AgregarArticulosPromo();
                }

                #endregion


                ////se agrega modelo desde el articulo encontrado
                //ListVentaDetalle.Add(model_);

                //se agrega fila vacia
                if (valedigital == 0 || (valedigital == 1 && valeDigitalDatos.tipo == 3)) //ValeDIgital
                {
                    ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                    ListVentaDetalle.Add(modelVacio);
                }

                ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                DM0312_MVentaDetalle modelvacio = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(modelvacio);

                //se llena grid con el articulo nuevo
                llenarGrid();

                //1832
                ValidarArticuloPequeno();

                return true;
            }

            if (!Excel)
                MessageBox.Show("No Existen Articulos con el Codigo:" + articulo, "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            return false;
        }

        private DM0312_MVentaDetalle BuscaArticulosGarantia(string articulo)
        {
            DataTable tabla = new DataTable();
            tabla = controlador.BuscaArticulos_VentaDetalle(articulo, Almacen, 2);

            if (tabla.Rows.Count == 1)
            {
                //modelo vacio para agregar fila vacia
                DM0312_MVentaDetalle modelVacio = new DM0312_MVentaDetalle();

                //buscar si existe el articulo en la lista para no agregar otro igual
                DM0312_MVentaDetalle model = ListVentaDetalle
                    .Where(x => x.Articulo == tabla.Rows[0].ItemArray[0].ToString()).FirstOrDefault();

                //llenado del modelo por el articulo nuevo
                DM0312_MVentaDetalle model_ = new DM0312_MVentaDetalle();
                model_.Articulo = tabla.Rows[0].ItemArray[0].ToString();
                model_.Descripcion = tabla.Rows[0].ItemArray[1].ToString();
                model_.Disponible = Convert.ToInt32(tabla.Rows[0].ItemArray[4].ToString());
                model_.impuesto = Convert.ToDouble(tabla.Rows[0].ItemArray[5].ToString());
                model_.Tipo = tabla.Rows[0].ItemArray[6].ToString();
                model_.Unidad = tabla.Rows[0].ItemArray[7].ToString();

                double precio = controlador.GetPrice(model_.Articulo, idVenta, model_.Renglon, cbx_RedimirM.Checked,
                    canalC, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);
                //controlador.GetPrice(model_.Articulo, idVenta, model_.Renglon, cbx_RedimirM.Checked);

                double value = Math.Truncate(100 * precio) / 100;

                model_.Precio = precio;

                model_.PrecioS = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value;

                return model_;
            }

            return null;
        }

        private Dictionary<double, double> actualizaMovPorModel(string cambio, DM0312_MVentaDetalle Item)
        {
            Dictionary<double, double> res = new Dictionary<double, double>();

            double cantidad = Convert.ToDouble(cambio);

            //saca valor del Iva
            double iva = Item.impuesto / 100 + 1;
            //////////////////////////////////////////////////////////////////////////////parche precios /////////////////////////////////////////////////////////////////////////
            //double precio = controlador.GetPrice(Item.Articulo, idVenta, Item.Renglon, cbx_RedimirM.Checked, canalC, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);
            //Item.Precio = precio;
            /////////////////////////////////////
            double subtotalParcial = cantidad * (Item.Precio / iva);

            if (mensajeBoton == "Instituciones")
            {
                double value = subtotalParcial;
                Item.SubTotal = Convert.ToDouble(value);

                double Total = cantidad * Item.Precio;
                Item.Total = Total;
                Item.TotalS = Total.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + Total;
            }
            else
            {
                double value = Math.Truncate(100 * subtotalParcial) / 100;
                Item.SubTotal = Convert.ToDouble(value);

                double Total = Math.Truncate(100 * (cantidad * Item.Precio)) / 100;
                Item.Total = Total;
                Item.TotalS = Total.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + Total;
            }

            //var value = Math.Truncate(100 * subtotalParcial) / 100;
            //var Total = Math.Truncate(100 * (cantidad * Item.Precio)) / 100;
            //var Total = (cantidad * Item.Precio);

            res.Add(Item.SubTotal, Item.Total);

            return res;
        }

        private bool AgregarGarantias()
        {
            List<DM0312_MVentaDetalle> articulos =
                ListVentaDetalle.Where(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo).ToList();

            if (articulos.Count > 0)
            {
                int sum = articulos.Sum(c => c.Cantidad);

                if (modeloVentaDetalle.Cantidad <= sum /*|| modeloVentaDetalle.Cantidad == sum*/)
                    return true;
                return false;
            }

            return false;
        }

        public bool ValidaMotosyCelular(bool op, DM0312_MVentaDetalle item)
        {
            if ((item.Linea == null) | (item.Tipo == null))
                return false;

            bool res = false;
            if (op)
            {
                if ((item.Linea == "MOTOCICLETAS") & (item.Tipo == "Serie"))
                    res = true;
                else if ((item.Linea.Contains("CELULARES") && item.Tipo == "Serie") | (item.Tipo == "Serie"))
                    res = true;
            }
            else
            {
                res = ListVentaDetalle.Any(x => x.Linea == "MOTOCICLETAS");
            }


            return res;
        }

        public bool ValidaSegurosyCredilanas(bool op, DM0312_MVentaDetalle item, bool editar = true)
        {
            if (editar)
            {
                if ((ListVentaDetalle.Count > 1) & ((item.Linea == "CREDILANA") | item.Linea.Contains("SEGUROS")))
                    return true;
                return false;
            }

            if ((ListVentaDetalle.Count >= 1) & ((item.Linea == "CREDILANA") | item.Linea.Contains("SEGUROS")))
                return true;


            if (item.Linea == null && item.Tipo == null)
                return false;

            bool res = false;

            if (op)
            {
                //if (item.Linea == "CREDILANA" & item.Tipo == "Servicio")
                //    res = true;
                //else if (item.Linea.Contains("SEGUROS") && item.Tipo == "Servicio")
                //    res = true;

                if (ListVentaDetalle.Where(z => (z.Linea != null) & (z.Tipo != null))
                    .Any(x => (x.Linea == "CREDILANA") & (x.Tipo == "Servicio")))
                    return true;
                if (ListVentaDetalle.Where(z => (z.Linea != null) & (z.Tipo != null))
                    .Any(x => x.Linea.Contains("SEGUROS") & (x.Tipo == "Servicio")))
                    return true;
            }
            else
            {
                if (ListVentaDetalle.Where(z => (z.Linea != null) & (z.Tipo != null))
                        .Any(x => x.Linea == "MOTOCICLETAS") ||
                    ListVentaDetalle.Any(x => x.Linea.Contains("SEGUROS"))) res = true;
            }

            return res;
        }

        private DM0312_MVentaDetalle AgregarJuegos(string articulo, string juego, string articuloligado,
            bool Excel = false)
        {
            DataTable tabla = new DataTable();
            tabla = controlador.BuscaArticulos_VentaDetalle(articulo, Almacen, 1);

            if (tabla.Rows.Count == 1)
            {
                //llenado del modelo por el articulo nuevo
                DM0312_MVentaDetalle model_ = new DM0312_MVentaDetalle();
                model_.Articulo = tabla.Rows[0].ItemArray[0].ToString();
                model_.Descripcion = tabla.Rows[0].ItemArray[1].ToString();
                model_.Linea = tabla.Rows[0].ItemArray[2].ToString();
                model_.Disponible = Convert.ToInt32(tabla.Rows[0].ItemArray[4].ToString());
                model_.impuesto = Convert.ToDouble(tabla.Rows[0].ItemArray[5].ToString());
                model_.Tipo = tabla.Rows[0].ItemArray[6].ToString();
                model_.Unidad = tabla.Rows[0].ItemArray[7].ToString();

                model_.PrecioS = "$" + 0;

                model_.Precio = 0;

                model_.PropreListaID = controlador.GetPropreListaID(idVenta, model_.Articulo, cbx_RedimirM.Checked);

                //eliminar modelo vacio de la lista antes de agregar el otro
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);

                //listas para calcular renglones 
                if (ListVentaDetalle.Count == 0)
                    model_.RenglonID = 1;
                else
                    model_.RenglonID = ListVentaDetalle.Count + 1;


                model_.Cantidad = controlador.CantidadPaquete(articulo, articuloligado);
                model_.impuesto2 = model_.Cantidad;
                model_.Renglon = 2048 * model_.RenglonID;

                model_.RenglonID = 1;

                Dictionary<double, double> item_ = new Dictionary<double, double>();

                item_ = actualizaMovPorModel(model_.Cantidad.ToString(), model_);

                model_.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());

                model_.Total = Convert.ToDouble(item_.Values.FirstOrDefault());

                model_.TotalS =
                    item_.Values.FirstOrDefault()
                        .ToString("C",
                            Thread.CurrentThread
                                .CurrentCulture); //"$" + Convert.ToDouble(item_.Values.FirstOrDefault());

                //Garantias
                DM0312_MVentaDetalle Garantias = new DM0312_MVentaDetalle();
                Garantias = controlador.GetGarantias(model_.Articulo, cbx_Canal.Text);

                if (Garantias != null)
                {
                    //Diccionario con datos totalizados
                    Dictionary<double, double> item = new Dictionary<double, double>();
                    //modelo de garantias para agregar al Grid
                    DM0312_MVentaDetalle modeloGarantia = new DM0312_MVentaDetalle();
                    modeloGarantia = BuscaArticulosGarantia(Garantias.Articulo);


                    if (modeloGarantia != null)
                    {
                        modeloGarantia.Articulo_Ligado = model_.Articulo;

                        DM0312_PuntoDeVenta_Garantias frm = new DM0312_PuntoDeVenta_Garantias();
                        frm.garantias = modeloGarantia;
                        frm.CantidadPaquetes = model_.Cantidad;
                        frm.flagPaquetes = true;
                        frm.ShowDialog();

                        if (frm.flag)
                        {
                            model_.Cantidad = frm.Cantidad;
                            model_.impuesto2 = model_.Cantidad;

                            item = actualizaMovPorModel(model_.Cantidad.ToString(), model_);

                            model_.SubTotal = Convert.ToDouble(item.Keys.FirstOrDefault());

                            model_.Total = Convert.ToDouble(item.Values.FirstOrDefault());

                            model_.TotalS = item.Values.FirstOrDefault()
                                .ToString("C",
                                    Thread.CurrentThread
                                        .CurrentCulture); //"$" + Convert.ToDouble(item.Values.FirstOrDefault());

                            if (frm.garantias.Cantidad > 0)
                            {
                                model_.Articulo_Ligado = frm.garantias.Articulo;


                                frm.garantias.RenglonID = model_.RenglonID + 1;


                                frm.garantias.PropreListaID = controlador.GetPropreListaID(idVenta,
                                    frm.garantias.Articulo, cbx_RedimirM.Checked);

                                frm.garantias.Renglon = 2048 * frm.garantias.RenglonID;

                                /*costo*/
                                double costog = controlador.ExecspVerCosto(ClaseEstatica.Usuario.sucursal,
                                    frm.garantias.Articulo, frm.garantias.Unidad);

                                double valueg = Math.Truncate(100 * costog) / 100;

                                frm.garantias.Costo = costog;

                                frm.garantias.Costo_ =
                                    valueg.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + valueg;


                                bool gara = GarantiasAdd(frm.garantias.Articulo, frm.garantias.Cantidad);

                                //agregar Series al modelo
                                model_.Serie = string.Empty; //llenarSeries(model_);

                                //se agrega modelo insertado
                                //ListVentaDetalle.Add(model_);

                                if (!gara)
                                {
                                    //articulo con garantia
                                    //frm.garantias.Juego = juego;
                                    frm.garantias.Articulo_Ligado = articuloligado;
                                    ListVentaDetalle.Add(frm.garantias);
                                }
                            }
                            else
                            {
                                ListVentaDetalle.Add(model_);
                            }
                        }
                        else
                        {
                            //agregar Series al modelo
                            model_.Serie = string.Empty; //llenarSeries(model_);
                        }
                    }
                    else
                    {
                        ListVentaDetalle.Add(model_);
                    }
                }
                else
                {
                    //agregar Series al modelo
                    model_.Serie = string.Empty; //llenarSeries(model_);
                }


                return model_;
            }

            if (!Excel)
                MessageBox.Show("No Exiten Articulos con ese Codigo", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

            return null;
        }

        public bool ArmarPaquetes(DM0312_MVentaDetalle item, bool excel)
        {
            bool res = false;
            //if (item.Linea.Contains("MOTOCICLETAS") & ListVentaDetalle.Count == 1)
            if ((item.Linea == "MOTOCICLETAS") & (ListVentaDetalle.Count == 1)) return false;

            //if (ListVentaDetalle.Where(l => l.Linea != null).Any(x => x.Linea.Contains("MOTOCICLETAS")))
            if (ListVentaDetalle.Where(l => l.Linea != null).Any(x => x.Linea == "MOTOCICLETAS")) return false;

            List<DM0312_MVentaDetalle> List = new List<DM0312_MVentaDetalle>();
            List = controlador.GetArtJuego(item.Articulo);

            if (List.Count == 0)
                return false;

            ListVentaDetalle.Add(item);

            foreach (DM0312_MVentaDetalle item_ in List)
            {
                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();

                model = AgregarJuegos(item_.Articulo, item_.Juego, item.Articulo, excel);

                if (model == null)
                {
                    res = true;
                    break;
                    //return false;
                }

                model.Juego = item_.Juego;
                model.Articulo_Ligado = item.Articulo;
                ListVentaDetalle.Add(model);
            }

            DM0312_MVentaDetalle modelEmpty = new DM0312_MVentaDetalle();
            ListVentaDetalle.Add(modelEmpty);

            llenarGrid();

            return res;
        }

        public void DeleteInlist(bool Editar = false)
        {
            List<DM0312_MVentaDetalle> item = new List<DM0312_MVentaDetalle>();

            int canal = 0;

            if (Editar)
                item = ListVentaDetalle.Where(x => x.Articulo_Ligado == oldValue).ToList();
            else
                item = ListVentaDetalle.Where(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo).ToList();

            foreach (DM0312_MVentaDetalle i in item)
            {
                if (i.Serie != null) controlador.DeleteSeriesLotes(i.Serie, idVenta, modeloVentaDetalle.Articulo);
                CUsuarioDes.InsertVentaD_(i, idVenta, Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text,
                    cbx_Agente.Text, 2);
            }

            if (cbx_Canal.Text != string.Empty)
                canal = Convert.ToInt32(cbx_Canal.Text);

            CUsuarioDes.InsertVentaD_(modeloVentaDetalle, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text, 2);

            if (Editar)
            {
                ListVentaDetalle.RemoveAll(x => x.Articulo_Ligado == oldValue);
                ListVentaDetalle.Remove(modeloVentaDetalle);
            }
            else
            {
                //ListVentaDetalle.RemoveAll(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo);
                //ListVentaDetalle.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);
                controlador.EliminarGarantiasRepetidas(modeloVentaDetalle, ref ListVentaDetalle);
            }

            llenarGrid();
        }

        private void agregarGarantiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (modeloVentaDetalle.Precio == 0.0 || modeloVentaDetalle.Articulo == null)
                return;

            if (modeloVentaDetalle.Articulo.Contains("GARA"))
                return;

            DM0312_MVentaDetalle Garantias = new DM0312_MVentaDetalle();
            Garantias = controlador.GetGarantias(modeloVentaDetalle.Articulo, cbx_Canal.Text);

            if (Garantias != null)
            {
                modeloVentaDetalle.Articulo_Ligado = Garantias.Articulo;

                DM0312_MVentaDetalle garan = ListVentaDetalle
                    .Where(x => x.Articulo == modeloVentaDetalle.Articulo_Ligado).FirstOrDefault();

                if (garan != null)
                {
                    List<DM0312_MVentaDetalle> articulos =
                        ListVentaDetalle.Where(a => a.Articulo_Ligado == garan.Articulo).ToList();

                    int sum = articulos.Sum(c => c.Cantidad);

                    int cant = garan.Cantidad + modeloVentaDetalle.Cantidad;

                    Dictionary<double, double> item_ = new Dictionary<double, double>();

                    if (cant <= sum)
                        garan.Cantidad = cant;

                    else
                        garan.Cantidad = sum;

                    item_ = actualizaMovPorModel(garan.Cantidad.ToString(), garan);

                    garan.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());

                    garan.Total = Convert.ToDouble(item_.Values.FirstOrDefault());

                    garan.TotalS =
                        item_.Values.FirstOrDefault()
                            .ToString("C",
                                Thread.CurrentThread
                                    .CurrentCulture); //"$" + Convert.ToDouble(item_.Values.FirstOrDefault());

                    llenarGrid();

                    return;
                }

                DM0312_MVentaDetalle modeloEmpty = new DM0312_MVentaDetalle();

                //Diccionario con datos totalizados
                Dictionary<double, double> item = new Dictionary<double, double>();
                //modelo de garantias para agregar al Grid
                DM0312_MVentaDetalle modeloGarantia = new DM0312_MVentaDetalle();
                modeloGarantia = BuscaArticulosGarantia(Garantias.Articulo);

                modeloGarantia.Articulo_Ligado = modeloVentaDetalle.Articulo;

                modeloVentaDetalle.Articulo_Ligado = modeloGarantia.Articulo;

                modeloGarantia.Cantidad = modeloVentaDetalle.Cantidad;

                modeloGarantia = actualizaMovGarantias(modeloGarantia);

                modeloGarantia.RenglonID = ListVentaDetalle.Count;

                modeloGarantia.PropreListaID =
                    controlador.GetPropreListaID(idVenta, modeloGarantia.Articulo, cbx_RedimirM.Checked);

                modeloGarantia.Renglon = 2048 * modeloGarantia.RenglonID;

                ListVentaDetalle.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);
                //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);

                ListVentaDetalle.Add(modeloVentaDetalle);
                ListVentaDetalle.Add(modeloGarantia);
                ListVentaDetalle.Add(modeloEmpty);

                llenarGrid();
            }
            else
            {
                MessageBox.Show("El articulo no tiene garantias", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DM0312_MVentaDetalle actualizaMovGarantias(DM0312_MVentaDetalle garantias)
        {
            double iva = garantias.impuesto / 100 + 1;
            double subtotalParcial = garantias.Cantidad * (garantias.Precio / iva);
            double value = Math.Truncate(100 * subtotalParcial) / 100;

            garantias.SubTotal = Convert.ToDouble(value);

            garantias.Total = garantias.Cantidad * garantias.Precio;

            garantias.TotalS =
                (garantias.Cantidad * garantias.Precio).ToString("C",
                    Thread.CurrentThread.CurrentCulture); //"$" + garantias.Cantidad * garantias.Precio;

            return garantias;
        }

        private void EditImagen(bool flag = true)
        {
            //-CambioImagenesResources
            img = Resources.edit;
        }

        #endregion


        #region "EVENTOS"

        private void btn_Datos_Click(object sender, EventArgs e)
        {
            FRM_HOJA_VERDE hoja = new FRM_HOJA_VERDE();
            hoja.ShowDialog();
        }

        private void btn_SidHv_Click(object sender, EventArgs e)
        {
            FRM_HOJA_VERDE hoja = new FRM_HOJA_VERDE();
            hoja.ShowDialog();
        }

        private void PuntoDeVenta_Scroll(object sender, ScrollEventArgs e)
        {
            gbx_menuPuntoVenta.Location = new Point(3, 73);
            flp_promociones.Location = new Point(1057, 73);
            Panel_UsuarioEstatus.Location = new Point(829, 7);
            if (pictureBox4.Visible) pictureBox4.Location = new Point(0, 4);

            if (pictureBox5.Visible) pictureBox5.Location = new Point(12, -14);

            if (pictureBox7.Visible) pictureBox7.Location = new Point(6, -11);
        }

        private void gbx_menuPuntoVenta_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_DatosGenerales_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_DatosEntrega_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_VentaDetalle_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_Anticipo_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_Afectar_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
            {
                if (verificaGuardar)
                {
                    if (MessageBox.Show("Seguro que desea salir?", "Confirmar", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        std.insertarIdVenta(idVenta, 2);
                        idVenta = 0;
                        Dispose();
                    }
                }
                else
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        std.insertarIdVenta(idVenta, 2);
                        if (ValorModificadoM == 1)
                        {
                            idVenta = 0;
                            Dispose();
                        }
                        else
                        {
                            //EliminarId();
                            //EliminarVentaD();
                            idVenta = 0;
                            Dispose();
                        }
                    }
                }
            }
            else
            {
                Dispose();
            }
        }

        private void btn_eventosNotasCitA_Click(object sender, EventArgs e)
        {
            refrescarCanalCliente();
            if (obligatorioCanal && obligatorioCliente)
                if (FlagEventosPuntoVenta)
                {
                    if (controlador.ValidarCliente(cbx_Cliente.Text) == "NO")
                    {
                        MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cbx_Cliente.Focus();
                    }
                    else
                    {
                        DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
                        //         DM0312_EventosNotasCitas.recibeCliente = Codigo;
                        DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(idVenta);
                        DM0312_EventosNotasCitas.recibeUsuario = ClaseEstatica.Usuario.Usser;
                        DM0312_EventosNotasCitas.recibeMov = TipoMovimiento;
                        DM0312_EventosNotasCitas.recibeEstatus = ValidaEstatus;
                        DM0312_EventosNotasCitas.recibeCliente = Cliente;
                        DM0312_EventosNotasCitas.recibeSucursal = ClaseEstatica.Usuario.sucursal.ToString();
                        eventNotaCita.ShowDialog();
                    }
                }
        }

        private void btn_InformacionCliente_Click(object sender, EventArgs e)
        {
            try
            {
                refrescarCanalCliente();
                if (obligatorioCanal && obligatorioCliente)
                {
                    if (cbx_Cliente.Text == "")
                    {
                        MessageBox.Show("Ingrese un Cliente", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (controlador.ValidarCliente(cbx_Cliente.Text) == "NO")
                        {
                            MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            cbx_Cliente.Focus();
                        }
                        else
                        {
                            InformacionCliente infoCliente = new InformacionCliente();
                            infoCliente.mensaje = cbx_Cliente.Text;
                            infoCliente.Show();
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void txt_Canal_SelectedIndexChanged(object sender, EventArgs e)
        {
            cambiarCanal();
        }

        private void txt_TelParticular_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                telefonocorrectoParticular(txt_TelParticular.Text);
                if (obligatorioParticular)
                {
                    componenteValidado = "Particular";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioParticular) ComponentesFocus();
            }

            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void txt_movil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter) || txt_movil.Text.Length == 10)
            {
                telefonocorrectoMovil(txt_movil.Text);
                if (obligatorioMovil)
                {
                    componenteValidado = "Movil";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioMovil) ComponentesFocus();
            }

            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void cbx_Cliente_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(1);
            //this.Visible = false;
            //catalogo.listaEmpleados = listaEmpleados;
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Cliente.Items.Clear();
            CargaCliente();

            ValidaCanal();
            if (existe != true) AgregaNuevoCanal();

            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                ActualizarInfoIdVenta();
            cbx_Cliente.Focus();
            SendKeys.Send("{tab}");
            //ComponentesFocus();
        }

        private void cbx_Agente_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(2);
            catalogo.suc = controlador.GetSucursal(cbx_Almacen.Text);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Agente.Items.Clear();
            LlenaAgente();
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                ActualizarInfoIdVenta();
            cbx_Agente.Focus();
            SendKeys.Send("{tab}");

            // ComponentesFocus();
        }

        private void cbx_Canal_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(3);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            //cbx_Canal.Text=canalC;
            if (Canal != canalC)
            {
                //-IntervencionDima
                if (Canal.Equals(76) && controladorEntrada.CheckInterv(cbx_Cliente.Text))
                {
                    MessageBox.Show(
                        "No es posible realizar la solicitud de credito, el cliente: " + Cliente +
                        " es Dima y tiene intervencion de cobranza", "", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }

                cbx_Canal.Text = Convert.ToString(Canal);
                mensajeValidacion = "";
                validarCanalVenta();
                if (idVenta != 0) ValidacionRefrecarCanal();
                if (obligatorioCanal)
                {
                    componenteValidado = "Canal";
                    ValidacionComponentes(componenteValidado);
                }
            }
            //cbx_Canal.Items.Clear();
            //LlenaComboCanal();
            //cbx_Canal.Items.Clear();
            //cbx_Canal.SelectedItem = -1;


            //txt_Observaciones.Focus();
            cbx_Canal.Focus();
            SendKeys.Send("{enter}");
            //ComponentesFocus();
        }

        private void cbx_Almacen_DropDown(object sender, EventArgs e)
        {
            //-ChecarEstatusPedido     
            if (idVenta > 0)
            {
                string estatusAct = controladorD.EstatusActual(idVenta);

                if (estatusAct != ValidaEstatus)
                {
                    MessageBox.Show("El movimiento ya ha sido afectado o esta en seguimiento por otro usuario.",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(4);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Almacen.Items.Clear();
            LlenaAlmacen();

            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                ActualizarInfoIdVenta();
            cbx_Almacen.Focus();
            SendKeys.Send("{tab}");
            //ComponentesFocus();
        }

        private void cbx_AgenteServicio_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(5);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_AgenteServicio.Items.Clear();
            LlenaAgenteTelefonico();
            cbx_AgenteServicio.Focus();
            SendKeys.Send("{tab}");
            //ComponentesFocus();
        }

        private void dvg_detalleVenta_Click(object sender, EventArgs e)
        {
            //dvg_detalleVenta.EndEdit();
            NumValidacion = 0;
            mensajeValidacion = "";
            DM0312_AgregarEvento.list.Clear();

            ValidaCamposObligatorios();
            if (obligatorio != true)
            {
                ValidaVenta();
                btn_Afectar.Focus();
                dvg_detalleVenta.Select();
            }

            //dvg_detalleVenta.ReadOnly = true;
            btn_Afectar.Focus();
            dvg_detalleVenta.Select();
        }

        private void cbx_Condicion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || canalC != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
            {
                ActualizarInfoIdVenta();
                RefeshPrice(cbx_RedimirM.Checked);

                List<DM0312_MVentaDetalle> copia = ListVentaDetalle.ToList();
                foreach (DM0312_MVentaDetalle item in copia.Where(x =>
                             x.idPromocion <= 0 && x.Precio < 99999.99 && x.Articulo != null))
                {
                    ValidaPromocion(item.Articulo, item.Cantidad, item.Precio, item.Renglon);
                    AgregarArticulosPromo();
                }

                llenarGrid();
            }
        }

        private void cbx_FormaEnvio_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text
                                      || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                ActualizarInfoIdVenta();
        }

        private void txt_Observaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                          Condicion != cbx_Condicion.Text || Alm != Almacen
                                          || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text
                                          || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                    ActualizarInfoIdVenta();
        }

        private void txt_Comentario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                          Condicion != cbx_Condicion.Text || Alm != Almacen
                                          || NoCtaPago != txt_Pago.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text
                                          || FormaPago != txt_FormaPago.Text || FormaEnvio != cbx_FormaEnvio.Text))
                    ActualizarInfoIdVenta();
        }

        private void dvg_detalleVenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            index = dvg_detalleVenta.CurrentRow.Index;
            if (e.KeyChar == Convert.ToChar(Keys.F1) && dvg_detalleVenta.CurrentCell.ColumnIndex == 0) return;
            //DM0312_CatalogoArticulos catalogo = new DM0312_CatalogoArticulos();
            //catalogo.Rcliente = Codigo;
            //catalogo.ShowDialog();
            //this.Visible = true;
            //this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void dvg_detalleVenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                DM0312_CatalogoArticulos catalogo = new DM0312_CatalogoArticulos();
                catalogo.Rcliente = Codigo;
                catalogo.ShowDialog();

                if ((catalogo.idArticulo == null) | (catalogo.idArticulo == string.Empty))
                    return;

                //BuscarArticulos(catalogo.idArticulo, false);
                if (!BuscarArticulos(catalogo.idArticulo, false))
                {
                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                    ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                    ListVentaDetalle.Add(model);
                }

                Visible = true;
                StartPosition = FormStartPosition.CenterScreen;

                llenarGrid();
            }
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.D)
            {
                btn_InfoArt_Click(null, null);
            }

            if (modeloVentaDetalle == null)
                return;

            //eliminar articulo
            if (e.KeyCode == Keys.Delete)
            {
                //-ChecarEstatusPedido                
                string estatusAct = controladorD.EstatusActual(idVenta);

                if (estatusAct != ValidaEstatus)
                {
                    MessageBox.Show("El movimiento ya ha sido afectado o esta en seguimiento por otro usuario.",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                List<DM0312_MVentaDetalle> borrart = ListVentaDetalle.Where(x => x.idPromocion > 0).ToList();
                if (borrart.Count > 0)
                {
                    DialogResult dialogResult_ =
                        MessageBox.Show("Se eliminaran Todos los Articulos de la venta, ¿Esta Seguro de eliminar?",
                            "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult_ == DialogResult.Yes)
                    {
                        ListVentaDetalle.Clear();
                        DM0312_MVentaDetalle newModelo = new DM0312_MVentaDetalle();
                        ListVentaDetalle.Add(newModelo);
                        llenarGrid();
                        return;
                    }

                    return;
                }

                if (modeloVentaDetalle.Descripcion != null)
                {
                    if (modeloVentaDetalle.Juego != null)
                    {
                        MessageBox.Show("No se puede eliminar un articulo que pertenece a un juego", "Precaución",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    //DialogResult dialogResult = MessageBox.Show("Esta Seguro de Eliminar el articulo:" + modeloVentaDetalle.Articulo, "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    //if (dialogResult == DialogResult.Yes)
                    //{
                    if (modeloVentaDetalle.Tipo == "Juego")
                    {
                        DeleteInlist();
                        return;
                    }


                    if (modeloVentaDetalle.Articulo.Contains("GARA"))
                    {
                        CUsuarioDes.InsertVentaD_(modeloVentaDetalle, idVenta, Convert.ToInt32(cbx_Canal.Text),
                            cbx_Almacen.Text, cbx_Agente.Text, 2);

                        //ListVentaDetalle.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);
                        ListVentaDetalle.Remove(modeloVentaDetalle);

                        //Se limpian los articulos ligados a la garantia eliminada.
                        //-CorreccionGarantias
                        foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                            if (item.Articulo_Ligado == modeloVentaDetalle.Articulo)
                                item.Articulo_Ligado = null;

                        //GarantiasList.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);
                    }
                    else
                    {
                        DM0312_MVentaDetalle ItemDelete = new DM0312_MVentaDetalle();

                        ItemDelete = ListVentaDetalle
                            .Where(x => x.Articulo == modeloVentaDetalle.Articulo_Ligado || x.idPromocion > 0)
                            .FirstOrDefault();

                        if (ItemDelete != null)
                            if (ItemDelete.Articulo == null)
                                ItemDelete = null;


                        if (ItemDelete != null)
                        {
                            DialogResult dialogResult_ = MessageBox.Show(
                                "El articulo tiene Garantia y/o regalo, si lo elimina se eliminaran las garantias y/o regalos, ¿Deseea eliminarlo?",
                                "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult_ == DialogResult.Yes)
                                //var garantias = ListVentaDetalle.Where(x => x.Articulo_Ligado == ItemDelete.Articulo).ToList();
                                //if (garantias.Count() >= 1)
                                //{
                                //    int cantidad = Convert.ToInt32(modeloVentaDetalle.Cantidad);
                                //    ItemDelete.Cantidad = ItemDelete.Cantidad - cantidad;
                                //    if (ItemDelete.Cantidad <= 0)
                                //    {
                                //        ItemDelete.Cantidad = 1;
                                //    }
                                //    CUsuarioDes.InsertVentaD_(ItemDelete, idVenta, Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, 4);
                                //    ListVentaDetalle.First(v => v.Articulo == ItemDelete.Articulo).Cantidad = ItemDelete.Cantidad;
                                //}
                                //else
                                //{
                                //    CUsuarioDes.InsertVentaD_(ItemDelete, idVenta, Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, 2);
                                //    ListVentaDetalle.RemoveAll(x => x.Articulo == ItemDelete.Articulo);
                                //}
                                //CUsuarioDes.InsertVentaD_(modeloVentaDetalle, idVenta, Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, 2);
                                //ListVentaDetalle.Remove(modeloVentaDetalle);
                                controlador.EliminarGarantiasRepetidas(modeloVentaDetalle, ref ListVentaDetalle, true);
                            //if (modeloVentaDetalle.Linea == "MOTOCICLETAS")
                            else
                                return;
                        }

                        string serie = string.Empty;

                        if (modeloVentaDetalle.Serie == null)
                            serie = string.Empty;
                        else
                            serie = modeloVentaDetalle.Serie;


                        if (serie != string.Empty)
                            controlador.DeleteSeriesLotes(modeloVentaDetalle.Serie, idVenta,
                                modeloVentaDetalle.Articulo);


                        CUsuarioDes.InsertVentaD_(modeloVentaDetalle, idVenta, Convert.ToInt32(cbx_Canal.Text),
                            cbx_Almacen.Text, cbx_Agente.Text, 2);
                        //ListVentaDetalle.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);

                        #region //-ModuloPromociones

                        string artPadre = modeloVentaDetalle.Articulo;
                        bool artPromo = modeloVentaDetalle.bArtPromocion;
                        ListVentaDetalle.Remove(modeloVentaDetalle);

                        if (ListVentaDetalle.Count > 0)
                        {
                            if (!artPromo)
                            {
                                List<int> listaPromocionesValidas =
                                    clsControladorPromociones.validarVentaAplicaPromocion(idVenta);
                                if (listaPromocionesValidas.Count <= 0)
                                {
                                    llenarGrid();
                                    return;
                                }

                                //Xml Promociones
                                XElement xmlPromociones = new XElement("Promocion",
                                    listaPromocionesValidas.Select(i => new XElement("IdPromocion", i)));

                                double dTotalVenta = ListVentaDetalle
                                    .Where(x => x.Articulo != null && x.idPromocion == 0 && x.Precio != 99999.99)
                                    .Sum(x => x.Precio * x.Cantidad);

                                if (clsControladorPromociones
                                        .obtenerIdPromocionesFacturaGlobal(dTotalVenta, 1, xmlPromociones.ToString())
                                        .Count <= 0) ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 1);
                                if (clsControladorPromociones
                                        .obtenerIdPromocionesFacturaGlobal(dTotalVenta, 2, xmlPromociones.ToString())
                                        .Count <= 0) ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 2);

                                XElement xmlDetalle = new XElement("Articulos",
                                    ListVentaDetalle.Where(x => x.idPromocion == 0)
                                        .Select(i => new XElement("Articulo", i.Articulo)));

                                List<clsModeloTipoPromocion> listaPromocionesPorArticuloPadreTres =
                                    clsControladorPromociones.obtenerIdPromocionesPorArticuloPadreDos(
                                        xmlDetalle.ToString(), 3, xmlPromociones.ToString());
                                if (listaPromocionesPorArticuloPadreTres.Count <= 0)
                                    ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 3);

                                List<clsModeloTipoPromocion> listaPromocionesPorArticuloPadreCuatro =
                                    clsControladorPromociones.obtenerIdPromocionesPorArticuloPadreDos(
                                        xmlDetalle.ToString(), 4, xmlPromociones.ToString());
                                if (listaPromocionesPorArticuloPadreCuatro.Count <= 0)
                                    ListVentaDetalle.RemoveAll(x => x.iIdTipoPromocion == 4);
                                List<DM0312_MVentaDetalle> a = ListVentaDetalle.Where(x => x.iIdTipoPromocion == 5)
                                    .ToList();

                                foreach (DM0312_MVentaDetalle item in a)
                                    if (item.listaPadres.Where(x => x.sArticulo == modeloVentaDetalle.Articulo).ToList()
                                            .Count > 0)
                                        ListVentaDetalle.Remove(item);
                            }
                            else
                            {
                                DM0312_MVentaDetalle Padre = ListVentaDetalle.FirstOrDefault(a =>
                                    a.Articulo == modeloVentaDetalle.Articulo_Ligado && !a.bArtPromocion);
                                List<DM0312_MVentaDetalle> articulos = ListVentaDetalle
                                    .Where(a => a.bArtPromocion && a.Articulo_Ligado == Padre.Articulo).ToList();
                                if (articulos.Count < 1)
                                {
                                    ValidaPromocion(Padre.Articulo, Padre.Cantidad, Padre.Precio, Padre.Renglon,
                                        articulos);
                                    AgregarArticulosPromo();

                                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                                    ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                                    ListVentaDetalle.Add(model);
                                }
                            }
                        }
                        else
                        {
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                            ListVentaDetalle.Add(model);
                        }

                        #endregion
                    }

                    //-Die
                    if (chx_Die.Visible)
                    {
                        chx_Die.Visible = false;
                        panel1.Visible = false;
                    }

                    llenarGrid();
                }
                else
                {
                    MessageBox.Show("No se puede Eliminar articulo", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
        }


        private void PuntoDeVenta_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Afectando)
            {
                MessageBox.Show("Favor de esperar a que termine el proceso actual", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }

            if (!CerrarVenta)
            {
                if (lbl_ID.Text != "")
                {
                    if (verificaGuardar)
                    {
                        if (MessageBox.Show("Seguro que desea salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            //-PedidoSinDetalle
                            std.insertarIdVenta(idVenta, 2);
                            idVenta = 0;
                            Dispose();
                        }
                    }
                    else
                    {
                        if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            //-PedidoSinDetalle
                            std.insertarIdVenta(idVenta, 2);
                            if (ValorModificadoM == 1)
                            {
                                idVenta = 0;
                                Dispose();
                            }
                            else
                            {
                                dvg_detalleVenta.CancelEdit();
                                //EliminarId();
                                //EliminarVentaD();
                                idVenta = 0;
                                ClaseEstatica.FormActivo = string.Empty;
                                Dispose();
                            }
                        }
                        else
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    Dispose();
                }
            }
        }

        /// <summary>
        ///     Permite enviar la interfaz  CampoExtra mediante la validacion si existe el registro, asi realizar
        ///     la carga de regitros para el Updade a la tabla MovCampoExtra
        ///     Developer : Victor Avila
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CamposExtras()
        {
            refrescarCanalCliente();
            if (obligatorioCanal && obligatorioCliente)
            {
                if (idVenta > 0)
                {
                    if (controlador.ValidarCliente(cbx_Cliente.Text) == "NO")
                    {
                        MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cbx_Cliente.Focus();
                    }

                    {
                        int valTemp = controlador.ValidaRegistroCampoExtra(idVenta);
                        if (valTemp > 0 || (TipoMovimiento == "Solicitud Credito" && ValidaEstatus == "SINAFECTAR"))
                        {
                            List<DM0312_MPuntoVentaCampoExtra> list = controlador.ActualizaCamposExtras(idVenta);
                            DM0312_CamposExtra campoExtra = new DM0312_CamposExtra();
                            campoExtra.camposExtraRecibe.Mov = TipoMovimiento;
                            campoExtra.camposExtraRecibe.IdVenta = Convert.ToInt32(idVenta);
                            campoExtra.camposExtraRecibe.Cliente = cbx_Cliente.Text;
                            campoExtra.camposExtraRecibe.TipoCalle = list.Where(x => x.CampoExtra == "SC_TIPO_CALLE")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.NomCalle = list.Where(x => x.CampoExtra == "SC_CALLE")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.NumExterior = list
                                .Where(x => x.CampoExtra == "SC_NUM_EXTERIOR").Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.NumInterior = list
                                .Where(x => x.CampoExtra == "SC_NUM_INTERIOR").Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.CodigoPostal = list.Where(x => x.CampoExtra == "SC_CP")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Colonia = list.Where(x => x.CampoExtra == "SC_COLONIA")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Cruce = list.Where(x => x.CampoExtra == "SC_CRUCES")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Telefono = list.Where(x => x.CampoExtra == "SC_TELEFONO")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.NumIdenti = list.Where(x => x.CampoExtra == "SC_TIPO_DOCTO")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Conyuge = list.Where(x => x.CampoExtra == "SC_CONYUGE")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Relacionado = list.Where(x => x.CampoExtra == "SC_RECOMENDADO")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Fecha = list.Where(x => x.CampoExtra == "SC_FECHANACIMIENTO")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.NumIdent = list.Where(x => x.CampoExtra == "SC_DOCTO")
                                .Select(x => x.Valor).FirstOrDefault();
                            campoExtra.camposExtraRecibe.Estatus = true;
                            campoExtra.psAgente = cbx_Agente.Text;
                            DM0312_CamposExtra.validaInsertUsuario = true;
                            campoExtra.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("No cuenta con registros  para Actualizar", "", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No cuenta con el id Venta", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CamposExtras();
        }

        //Metodo que valida las celdas insertadas para agregar y actualizar totalizadores
        private void dvg_detalleVenta_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            string cambio = string.Empty;
            try
            {
                if (e.ColumnIndex != 8)
                {
                    if (dvg_detalleVenta.SelectedCells[0].Value == null)
                    {
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    if (e.ColumnIndex == 1 && oldValue != "")
                    {
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    DM0312_MVentaDetalle artedit = ListVentaDetalle
                        .Where(x => x.Articulo == dvg_detalleVenta.SelectedCells[0].Value).FirstOrDefault();
                    if (artedit != null)
                    {
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    ;
                }
                else
                {
                    return;
                }


                cambio = dvg_detalleVenta.SelectedCells[0].Value.ToString().ToUpper();

                cambio = cambio.Replace("¡", "+");

                //-808
                if (e.ColumnIndex == 1)
                {
                    string sArticuloCb = controlador.buscarArticuloCB(cambio, 1);

                    if (!string.IsNullOrEmpty(sArticuloCb)) cambio = sArticuloCb;
                }


                //si el vale tiene mas de 0 pesos validamos que lo que se agregue no sea una credilana
                if (valeDigitalDatos.tipo == 3)
                    if (controlador.validarArticuloVale(cambio))
                    {
                        MessageBox.Show(
                            "No es posible añadir artículos financieros a un vale digital de monto fijo. Favor de solicitar un vale digital de depósiito",
                            "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                //CUsuarioDes.InsertVentaD_(modeloVentaDetalle, idVenta, Convert.ToInt32(cbx_Canal.Text), cbx_Almacen.Text, cbx_Agente.Text, 2);

                //Norberto Reyes C. 28/11/2019
                //-CorreccionGarantias

                #region Agregar Garantia A Un Articulo

                if (e.ColumnIndex == 1)
                    if (cambio.Contains("GARA"))
                    {
                        ligarGarantias(cambio, 1);
                        llenarGrid();
                        return;
                    }

                #endregion

                #region Cantidad

                if (e.ColumnIndex == 2)
                {
                    cambio = dvg_detalleVenta.SelectedCells[0].Value.ToString();

                    double cantidad = Convert.ToDouble(cambio);

                    if (cantidad < 0)
                    {
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    //seleccionado garantias
                    if (modeloVentaDetalle.Articulo.Contains("GARA"))
                    {
                        //Si reduce una garantia dejar las garantias ligadas al total de garantias me hice bolas
                        //-CorreccionGarantias
                        List<DM0312_MVentaDetalle> garantias = ListVentaDetalle
                            .Where(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo).ToList();

                        if (garantias.Count > int.Parse(cambio))
                            ListVentaDetalle[garantias.Count].Articulo_Ligado = null;
                        else
                            ligarGarantias(modeloVentaDetalle.Articulo, 2, int.Parse(cambio));

                        List<DM0312_MVentaDetalle> art = ListVentaDetalle
                            .Where(x => x.Articulo_Ligado == modeloVentaDetalle.Articulo).ToList();

                        if (art.Count() > 1)
                        {
                            int sum = art.Sum(x => x.Cantidad);

                            int oldvalue_ = Convert.ToInt32(oldValue);

                            if (oldvalue_ == cantidad) return;

                            if (sum < modeloVentaDetalle.Cantidad)
                            {
                                MessageBox.Show("La cantidad de garantia no debe exceder cantidad de articulos",
                                    "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                ResetOldValue(cambio, e.ColumnIndex);
                                return;
                            }
                        }

                        if (!AgregarGarantias())
                        {
                            MessageBox.Show("La cantidad de garantia no debe exceder cantidad de articulos", "Error!",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            ResetOldValue(cambio, e.ColumnIndex);
                            return;
                        }
                    }
                    else
                    {
                        DM0312_MVentaDetalle gara = ListVentaDetalle
                            .Where(x => x.Articulo == modeloVentaDetalle.Articulo_Ligado).FirstOrDefault();

                        bool res = checkCantidadGarantias(gara.Articulo, cantidad);

                        if (!res)
                        {
                            MessageBox.Show("La cantidad de garantia no debe exceder cantidad de articulos", "Error!",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            ResetOldValue(cambio, e.ColumnIndex);
                            return;
                        }
                    }

                    if (string.IsNullOrEmpty(oldValue)) oldValue = "0";

                    int cantidadAnterior = int.Parse(oldValue);

                    if (modeloVentaDetalle.Serie == null)
                        modeloVentaDetalle.Serie = string.Empty;

                    if ((modeloVentaDetalle.Tipo == "Serie") & (modeloVentaDetalle.Serie != string.Empty))
                    {
                        controlador.DeleteSeriesLotes(modeloVentaDetalle.Serie, idVenta, modeloVentaDetalle.Articulo);

                        modeloVentaDetalle.Serie = ControladorSerie.GetSerie(idVenta, modeloVentaDetalle.Articulo);
                    }

                    int anterior = Convert.ToInt32(oldValue);
                    actualizaMov(cambio, e, anterior > cantidad, cantidadAnterior);
                }

                #endregion //cantidad


                #region Articulos

                if (e.ColumnIndex == 1)
                {
                    //-Die
                    if (controlador.ValidarSucursalDie())
                        if (controlador.validarCanalVentaDie(Canal))
                            if (controlador.validarArticuloDie(cambio))
                            {
                                chx_Die.Visible = true;
                                gbx_DatosGenerales.Size = new Size(711, 250);
                            }

                    //-- STP
                    if (controlador.ValidarSucursalSTP())
                        if (controlador.validarCanalVentaSTP(Canal))
                            if (controlador.validarArticuloSTP(cambio))
                            {
                                tipoCuenta = shm.ObtenerInfoCLABE(Cliente);
                                panel1.Visible = true;
                                chkTransferencia.Checked = false;
                                chkTransferencia.Visible = true;
                                btnCuentaClabe.Visible = true;
                                gbx_DatosGenerales.Size = new Size(711, 250);

                                if (Canal == 80)
                                {
                                    panel1.Visible = false;
                                    chkTransferencia.Checked = false;
                                }
                            }

                    if (cambio != oldValue)
                        if (oldValue != "")
                            CUsuarioDes.InsertVentaD_E(oldValue, idVenta);

                    if (modeloVentaDetalle.Descripcion != null)
                    {
                        if (oldValue.Contains("GARA"))
                        {
                            MessageBox.Show("No se puede editar una Garantia", "Advertencia", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            ResetOldValue(cambio, e.ColumnIndex);
                            return;
                        }

                        if (modeloVentaDetalle.Juego != null)
                        {
                            MessageBox.Show("No se puede editar un articulo que pertenece a un juego", "Precaución",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ResetOldValue(cambio, e.ColumnIndex);
                            return;
                        }

                        if (modeloVentaDetalle.Juego != null)
                        {
                            MessageBox.Show("No se puede editar un articulo que pertenece a un juego", "Precaución",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ResetOldValue(cambio, e.ColumnIndex);
                            return;
                        }

                        if (controlador.LineaART(cambio) == "SEGUROS DE VIDA")
                            if (!CandadoEdad(Codigo))
                            {
                                dvg_detalleVenta.CancelEdit();
                                return;
                            }

                        if (!BuscarArticulos(cambio, true, 1, false, true))
                        {
                            ResetOldValue(cambio, e.ColumnIndex);
                            dvg_detalleVenta.CancelEdit();
                            //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDetalle.Add(model);
                            llenarGrid();
                            return;
                        }
                    }
                    else
                    {
                        if (controlador.LineaART(cambio) == "SEGUROS DE VIDA")
                            if (!CandadoEdad(Codigo))
                            {
                                dvg_detalleVenta.CancelEdit();
                                //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                                ListVentaDetalle.Add(model);
                                llenarGrid();
                                return;
                            }

                        if (!BuscarArticulos(cambio, false, 1, false, false, false, e))
                        {
                            dvg_detalleVenta.CancelEdit();
                            //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDetalle.Add(model);
                            llenarGrid();
                        }
                    }
                }

                #endregion Articulos


                #region Costos

                if (e.ColumnIndex == 5)
                {
                    double Costo = Convert.ToDouble(cambio);

                    if (Costo <= 0)
                    {
                        MessageBox.Show("El valor tiene que ser Mayor a 0", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    modeloVentaDetalle.Costo_ = Costo.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + Costo;

                    modeloVentaDetalle.Costo = Costo;

                    dvg_detalleVenta.CancelEdit();

                    llenarGrid();
                }

                #endregion //costos
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("La cadena de entrada no tiene el formato correcto."))
                {
                    MessageBox.Show("El valor tiene que ser Numerico", "Error!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    ResetOldValue(cambio, e.ColumnIndex);
                    return;
                }

                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                MessageBox.Show("dvg_detalleVenta_CellValueChanged " + ex.Message, "Error!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Metodo para Eliminar Arituclos Repetidos de la lista de Venta Detalle
        /// </summary>
        protected void EliminarArticulosRepetidosVentaDetalle()
        {
            try
            {
                ListVentaDetalle.RemoveAll(x => string.IsNullOrEmpty(x.Articulo)); // eliminamos modelos vacios
                ListVentaDetalle.ForEach(x => x.Articulo = x.Articulo?.ToUpper());
                List<DM0312_MVentaDetalle> agrupados = ListVentaDetalle.GroupBy(x => x.Articulo)
                    .Select(x => ReducirAgrupacionVentaDetalle(x.ToList()))
                    .ToList();
                oldValue = agrupados.Last()?.Articulo;
                ListVentaDetalle.Clear();
                ListVentaDetalle.AddRange(agrupados);
                ListVentaDetalle.Add(new DM0312_MVentaDetalle());
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary>
        ///     Actualizar item de la lista
        /// </summary>
        /// <param name="grupo">lista obtenida de la agrupacion por codigo</param>
        /// <returns></returns>
        protected DM0312_MVentaDetalle ReducirAgrupacionVentaDetalle(List<DM0312_MVentaDetalle> grupo)
        {
            try
            {
                grupo.ForEach(x => x.Cantidad = x.Cantidad == 0 ? +1 : x.Cantidad);
                DM0312_MVentaDetalle primero = grupo.FirstOrDefault();
                primero.Precio = controlador.GetPrice(primero.Articulo, idVenta, primero.Renglon, cbx_RedimirM.Checked,
                    canalC, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);
                primero.PrecioS = primero.Precio.ToString("C", Thread.CurrentThread.CurrentCulture);
                primero.Cantidad = grupo.Sum(x => x.Cantidad);
                double iva = primero.impuesto / 100 + 1;
                double subtotalParcial = primero.Cantidad * (primero.Precio / iva);
                double a = Math.Truncate(100 * subtotalParcial) / 100;
                primero.SubTotal = Convert.ToDouble(a);
                primero.Total = primero.Cantidad * primero.Precio;
                double total = Math.Truncate(100 * primero.Total) / 100;
                primero.TotalS = total.ToString("C", Thread.CurrentThread.CurrentCulture);
                return primero;
            }
            catch (Exception ex)
            {
                return new DM0312_MVentaDetalle();
            }
        }

        /// <summary>
        ///     metodo encargado de agregar y quitar garantias
        /// </summary>
        /// <param name="sArticulo">garantia que se agregara</param>
        /// <param name="iTipoCambio">1: agrega garantia, 2 agrega garantia a artiuculo cuando se aumenta el numero</param>
        /// //-CorreccionGarantias
        public void ligarGarantias(string sArticulo, int iTipoCambio, int iCambio = 0)
        {
            DM0312_MVentaDetalle Garantias = new DM0312_MVentaDetalle();
            bool bAgregoGarantia = false;
            bool bArticuloIncorrecto = false;
            if (iTipoCambio == 1)
            {
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);

                List<DM0312_MVentaDetalle> vGara = ListVentaDetalle.Where(x => x.Articulo == sArticulo).ToList();
                if (vGara.Count != 0)
                {
                    MessageBox.Show("Garantia repetida favor de verificar", "Punto De Venta", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                    ListVentaDetalle.Add(model);
                    llenarGrid();
                    return;
                }

                if (sArticulo.ToUpper().Contains("GARA"))
                {
                    Garantias = new DM0312_MVentaDetalle();
                    if (BuscarArticulos(sArticulo, false))
                    {
                        foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                            if (item.Articulo != null)
                                if (string.IsNullOrEmpty(item.Articulo_Ligado))
                                {
                                    Garantias = controlador.GetGarantias(item.Articulo, cbx_Canal.Text);
                                    if (Garantias != null)
                                        if (Garantias.Articulo == sArticulo)
                                        {
                                            item.Articulo_Ligado = Garantias.Articulo;
                                            bAgregoGarantia = true;
                                        }
                                }
                    }
                    else
                    {
                        bArticuloIncorrecto = true;
                        actualizarInformacionGrid(sArticulo);
                    }

                    if (!bAgregoGarantia)
                    {
                        if (!bArticuloIncorrecto)
                        {
                            MessageBox.Show(
                                "No se detecto ningun articulo al cual ligar la garantia " + sArticulo + ".",
                                "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            actualizarInformacionGrid(sArticulo);
                        }
                    }
                    else
                    {
                        ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                        DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                        ListVentaDetalle.Add(model);
                        llenarGrid();
                    }
                }
            }

            if (iTipoCambio == 2)
            {
                ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
                for (int i = 0; i < iCambio; i++)
                {
                    foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                        if (item.Articulo != null)
                            if (string.IsNullOrEmpty(item.Articulo_Ligado))
                            {
                                Garantias = controlador.GetGarantias(item.Articulo.ToUpper(), cbx_Canal.Text);
                                Garantias = controlador.GetGarantias(item.Articulo.ToUpper(), cbx_Canal.Text, 2,
                                    sArticulo);
                                if (Garantias != null)
                                    if (!bAgregoGarantia)
                                    {
                                        item.Articulo_Ligado = Garantias.Articulo;
                                        bool gara = GarantiasAdd(Garantias.Articulo, 0);
                                        bAgregoGarantia = true;
                                    }
                            }

                    bAgregoGarantia = false;
                }

                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                ListVentaDetalle.Add(model);
            }
        }

        public void actualizarInformacionGrid(string sArticulo)
        {
            dvg_detalleVenta.CancelEdit();
            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
            ListVentaDetalle.RemoveAll(x => x.Articulo == sArticulo);
            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
            ListVentaDetalle.Add(model);
            //Agrupamos lista ListVentaDetalle por codigo
            llenarGrid();
        }

        private void dvg_detalleVenta_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (CancelEvent)
                return;

            if (e.RowIndex == -1)
                return;

            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.Rows[e.RowIndex].DataBoundItem;

            ReadOnlyColumns(e.ColumnIndex, true);
        }

        private void dvg_detalleVenta_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (ClaseEstatica.iRecarga == 1)
            {
                try
                {
                    if (e.ColumnIndex == 2)
                    {
                        string format = e.FormattedValue.ToString();
                        int format_ = Convert.ToInt32(format);

                        if (format_ > 1)
                        {
                            MessageBox.Show("Solo se permite una recarga", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            dvg_detalleVenta.CancelEdit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message == "La cadena de entrada no tiene el formato correcto.")
                    {
                        MessageBox.Show("El valor debe ser Numérico", "Error!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        //e.Cancel = true;
                        //ResetOldValue(oldValue, e.ColumnIndex);
                        //dvg_detalleVenta.CancelEdit();
                        //return;
                    }
                    else
                    {
                        DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                        MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    e.Cancel = true;
                    dvg_detalleVenta.CancelEdit();
                    ResetOldValue(oldValue, e.ColumnIndex);
                }
            }
            else
            {
                if (btn_Regresar.Focused)
                {
                    dvg_detalleVenta.CancelEdit();
                    dvg_detalleVenta.EndEdit();
                    return;
                }

                if (modeloVentaDetalle != null)
                {
                    if (modeloVentaDetalle.Articulo == null) return;
                }
                else
                {
                    return;
                }


                try
                {
                    #region Validando Cantidad

                    if (e.ColumnIndex == 2)
                    {
                        string format = e.FormattedValue.ToString();

                        if (format == "")
                        {
                            MessageBox.Show("Debe poner un valor", "Error!", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            CancelEvent = true;
                            e.Cancel = true;
                            dvg_detalleVenta.CancelEdit();
                            ResetOldValue(oldValue, e.ColumnIndex);
                            return;
                        }

                        int format_ = Convert.ToInt32(format);

                        if (format_ <= 0)
                        {
                            MessageBox.Show("la cantidad debe ser mayor a 0", "Error!", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            CancelEvent = true;
                            e.Cancel = true;
                            dvg_detalleVenta.CancelEdit();
                            ResetOldValue(oldValue, e.ColumnIndex);
                            return;
                        }

                        if ((modeloVentaDetalle.Tipo == "Serie") & (modeloVentaDetalle.Linea == "MOTOCICLETAS") &
                            (format_ > 1))
                        {
                            MessageBox.Show(
                                "El Articulo es Motocicleta no se puede facturar mas de una pieza en un mismo movimiento",
                                "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            CancelEvent = true;
                            e.Cancel = true;
                            dvg_detalleVenta.CancelEdit();
                            ResetOldValue(oldValue, e.ColumnIndex);
                            return;
                        }

                        if (format_ > 1)
                        {
                            List<DM0312_MVentaDetalle> venta = ListVentaDetalle
                                .Where(x => x.Linea == "MOTOCICLETAS" || x.Linea == "CREDILANA").ToList();

                            if (venta != null)
                                if (venta.Count > 0)
                                {
                                    MessageBox.Show("No se puede vender mas de dos piezas en un mismo movimiento",
                                        "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    CancelEvent = true;
                                    e.Cancel = true;
                                    dvg_detalleVenta.CancelEdit();
                                    ResetOldValue(oldValue, e.ColumnIndex);
                                    return;
                                }

                            List<DM0312_MVentaDetalle> Detalle = new List<DM0312_MVentaDetalle>();

                            Detalle = ListVentaDetalle.Where(z => z.Linea != null && z.Linea.Contains("SEGUROS"))
                                .ToList();

                            if (Detalle != null)
                                if (Detalle.Count > 0)
                                {
                                    MessageBox.Show("No se puede vender mas de dos piezas en un mismo movimiento",
                                        "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    CancelEvent = true;
                                    e.Cancel = true;
                                    dvg_detalleVenta.CancelEdit();
                                    ResetOldValue(oldValue, e.ColumnIndex);
                                }
                        }
                    }

                    #endregion
                }
                catch (Exception ex)
                {
                    if (ex.Message == "La cadena de entrada no tiene el formato correcto.")
                    {
                        MessageBox.Show("El valor debe ser Numérico", "Error!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                    else
                    {
                        DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                        MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    e.Cancel = true;
                    dvg_detalleVenta.CancelEdit();
                    ResetOldValue(oldValue, e.ColumnIndex);
                }
            }
        }

        private void dvg_detalleVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            dvg_detalleVenta.BeginEdit(true);
            dvg_detalleVenta.EndEdit();

            modeloVentaDetalle = new DM0312_MVentaDetalle();
            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.Rows[e.RowIndex].DataBoundItem;

            ReadOnlyColumns(e.ColumnIndex);
        }

        private void dvg_detalleVenta_SelectionChanged(object sender, EventArgs e)
        {
            int column = dvg_detalleVenta.CurrentCell.ColumnIndex;

            int row = dvg_detalleVenta.CurrentCell.RowIndex;

            int index = dvg_detalleVenta.CurrentRow.Index;

            if (index < 0)
                return;

            modeloVentaDetalle = new DM0312_MVentaDetalle();

            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.CurrentRow.DataBoundItem;

            llenarLabels(modeloVentaDetalle);

            if (column == 1)
            {
                if (modeloVentaDetalle.Descripcion == null)
                {
                    dvg_detalleVenta_CellClick(dvg_detalleVenta, new DataGridViewCellEventArgs(column, row));

                    SendKeys.Send("{F2}");
                }
            }
            else
            {
                dvg_detalleVenta.EndEdit();
            }

            Parallel.Invoke(() => LimpiarListaVentaDetalle());
        }

        private void LimpiarListaVentaDetalle()
        {
            ListVentaDetalle.RemoveAll(x => string.IsNullOrEmpty(x.Descripcion) || x.Cantidad == 0);
            ListVentaDetalle.Add(new DM0312_MVentaDetalle());
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ValidaCamposObligatorios();
            if (obligatorio != true)
                using (DM0312_CatalogoArticulos frmCatalogoArticulos = new DM0312_CatalogoArticulos())
                {
                    frmCatalogoArticulos.Rcliente = Codigo;
                    frmCatalogoArticulos.sTipoDima = sTipoDima;
                    frmCatalogoArticulos.ShowDialog();

                    if ((frmCatalogoArticulos.idArticulo == null) | (frmCatalogoArticulos.idArticulo == string.Empty))
                        return;

                    #region

                    //-ModuloPromociones

                    //Elimina los articulos de la promocion.
                    ListVentaDetalle.RemoveAll(x =>
                        x.Articulo_Ligado == modeloVentaDetalle.Articulo && x.bArtPromocion);

                    #endregion

                    //si el vale tiene mas de 0 pesos validamos que lo que se agregue no sea una credilana
                    if (valeDigitalDatos.tipo == 3)
                        if (!string.IsNullOrEmpty(frmCatalogoArticulos.idArticulo))
                            if (controlador.validarArticuloVale(frmCatalogoArticulos.idArticulo))
                            {
                                MessageBox.Show(
                                    "No es posible añadir artículos financieros a un vale digital de monto fijo. Favor de solicitar un vale digital de depósiito",
                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }

                    BuscarArticulos(frmCatalogoArticulos.idArticulo, false);
                    ListVentaDetalle.RemoveAll(x => x.Articulo == null);
                    ListVentaDetalle.Add(new DM0312_MVentaDetalle());
                }

            btn_Afectar.Focus();
        }

        private void cbx_Cliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";

                if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                {
                    Codigo = cbx_Cliente.Text.ToUpper();
                    if (cbx_Canal.Text == "34") MostrarNomina();
                    CargaCliente();
                    validarCliente();
                    ValidacionRefrecarCanal();
                    estatusComponentes();
                }

                if (obligatorioCliente)
                {
                    componenteValidado = "cliente";
                    ValidacionComponentes(componenteValidado);
                    obligatorioCliente = true;
                }

                if (obligatorioCliente)
                {
                    ComponentesFocus();
                    obligatorioCliente = true;
                    cbx_Cliente.Text = cbx_Cliente.Text.ToUpper();
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        public void refrescarCanalCliente()
        {
            if (Convert.ToString(canalC) != cbx_Canal.Text)
            {
                validarCanalVenta();
                if (idVenta != 0) ValidacionRefrecarCanal();
            }

            if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
            {
                ValidacionRefrecarCanal();
                Codigo = cbx_Cliente.Text.ToUpper();
                CargaCliente();
                validarCliente();
                estatusComponentes();
            }
        }

        private void cbx_Canal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (cbx_Canal.Text != Convert.ToString(Canal))
                {
                    //-IntervencionDima
                    if (cbx_Canal.Text.Equals("76") && controladorEntrada.CheckInterv(cbx_Cliente.Text))
                    {
                        cbx_Canal.Text = ClaseEstatica.Usuario.Uen.Equals(2) ? "7" : "3";
                        MessageBox.Show(
                            "No es posible realizar la solicitud de credito, el cliente: " + Cliente +
                            " es Dima y tiene intervencion de cobranza", "", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return;
                    }

                    if (cbx_Canal.Text == "34") MostrarNomina();
                    mensajeValidacion = "";
                    validarCanalVenta();
                    if (idVenta != 0) ValidacionRefrecarCanal();
                    if (obligatorioCanal)
                    {
                        componenteValidado = "Canal";
                        ValidacionComponentes(componenteValidado);
                    }
                }
                else
                {
                    ComponentesFocus();
                }


                if (obligatorioCanal) ComponentesFocus();
            }

            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        private void dvg_detalleVenta_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            //dvg_detalleVenta[e.ColumnIndex, e.RowIndex].ReadOnly = false;
            if (e.ColumnIndex == 1 && oldValue != "") dvg_detalleVenta[e.ColumnIndex, e.RowIndex].ReadOnly = true;

            oldValue = "";

            if (dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value != null)
                oldValue = dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value.ToString();
        }

        private void cbx_Agente_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                ValidaAgente();
                ////LlenaAgente();
                //if (obligatorioAgente == true)
                //{
                componenteValidado = "Agente";
                ValidacionComponentes(componenteValidado);
                //}
                if (obligatorioAgente) ComponentesFocus();
                if (cbx_Agente.Text == cbx_AgenteServicio.Text && cbx_AgenteServicio.Text != "")
                {
                    MessageBox.Show("El Agente de la venta es incorrecto no puede ser igual al agente Telefonico");
                    cbx_Agente.Text = "";
                    cbx_Agente.Focus();
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void cbx_Condicion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cbx_Almacen.Focus();
        }

        private void cbx_Almacen_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                ValidaAlmacen();
                if (obligatorioAlmacen)
                {
                    componenteValidado = "Almacen";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioAlmacen) ComponentesFocus();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void cbx_Cliente_Validating(object sender, CancelEventArgs e)
        {
            mensajeValidacion = "";
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false)
            {
                if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                {
                    Codigo = cbx_Cliente.Text.ToUpper();
                    CargaCliente();
                    validarCliente();
                    cbx_Cliente.Text = Codigo;
                    ValidacionRefrecarCanal();
                    estatusComponentes();
                }
                else if (obligatorioCliente && lbl_ID.Text == "")
                {
                    componenteValidado = "cliente";
                    ValidacionComponentes(componenteValidado);
                    obligatorioCliente = true;
                    cbx_Cliente.Text = cbx_Cliente.Text.ToUpper();
                }


                //mensajeValidacion = "";

                //if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                //{
                //    Codigo = cbx_Cliente.Text.ToUpper();
                //    CargaCliente();
                //    validarCliente();
                //    ValidacionRefrecarCanal();
                //    estatusComponentes();
                //}
                //if (obligatorioCliente == true)
                //{
                //    componenteValidado = "cliente";
                //    ValidacionComponentes(componenteValidado);
                //    obligatorioCliente = true;
                //}
                //if (obligatorioCliente == true)
                //{
                //    ComponentesFocus();
                //    obligatorioCliente = true;
                //    cbx_Cliente.Text = cbx_Cliente.Text.ToUpper();
                //}
            }
        }

        private void cbx_Canal_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false)
            {
                if (cbx_Cliente.Focused == false)
                {
                    if (cbx_Canal.Text != Convert.ToString(Canal) || obligatorioCanal == false)
                    {
                        mensajeValidacion = "";
                        //Canal = Convert.ToInt32(cbx_Canal.Text);
                        validarCanalVenta();
                        if (idVenta != 0) ValidacionRefrecarCanal();
                        txt_FormaPago.Text = "";
                    }

                    if (obligatorioCanal && lbl_ID.Text == "")
                    {
                        componenteValidado = "Canal";
                        ValidacionComponentes(componenteValidado);
                        obligatorioCanal = true;
                    }
                }
                else
                {
                    if (cbx_Canal.Text != "")
                    {
                        if (cbx_Canal.Text != Convert.ToString(Canal) || obligatorioCanal == false)
                        {
                            mensajeValidacion = "";
                            //Canal = Convert.ToInt32(cbx_Canal.Text);
                            validarCanalVenta();
                            txt_FormaPago.Text = "";
                        }

                        if (obligatorioCanal && lbl_ID.Text == "")
                        {
                            componenteValidado = "Canal";
                            ValidacionComponentes(componenteValidado);
                            obligatorioCanal = true;
                        }

                        cbx_Cliente.Focus();
                    }
                }
            }
        }

        private void cbx_Agente_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false)
            {
                mensajeValidacion = "";
                ValidaAgente();
                if (obligatorioAgente && lbl_ID.Text == "")
                {
                    componenteValidado = "Agente";
                    ValidacionComponentes(componenteValidado);
                }

                if (cbx_Agente.Text == cbx_AgenteServicio.Text && cbx_AgenteServicio.Text != "")
                {
                    MessageBox.Show("El Agente de la venta es incorrecto no puede ser igual al agente Telefonico",
                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cbx_Agente.Text = "";
                    cbx_Agente.Focus();
                }
            }
        }

        private void cbx_Almacen_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false && cbx_Condicion.Focused == false)
            {
                mensajeValidacion = "";
                ValidaAlmacen();
                if (obligatorioAlmacen && lbl_ID.Text == "")
                {
                    componenteValidado = "Almacen";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void ResetOldValue(string cambio, int columnindex)
        {
            dvg_detalleVenta.CancelEdit();


            string name = dvg_detalleVenta.Columns[columnindex].Name;

            //var i = ListVentaDetalle.Where(x => x.GetType().GetProperty(name).GetValue(x, null).ToString() == cambio).FirstOrDefault();

            Type tipo = modeloVentaDetalle.GetType().GetProperty(name).PropertyType;

            modeloVentaDetalle.GetType().GetProperty(name)
                .SetValue(modeloVentaDetalle, Convert.ChangeType(oldValue, tipo));


            ListVentaDetalle.RemoveAll(x => x.Descripcion == null);
            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
            ListVentaDetalle.Add(model);
            //llenarGrid();
        }

        private void cbx_RedimirM_CheckedChanged(object sender, EventArgs e)
        {
            int diasV = controladorEntrada.DiasVencidosDIMA(Codigo);
            int diasC = Convert.ToInt32(controlador.DiasV());
            if (Canal == 76 && CDetalleVenta.SMStablaConversionSegurosValor() == "1")
            {
                if (diasV > diasC)
                {
                    if (cbx_RedimirM.Checked)
                    {
                        MessageBox.Show(
                            "No es posible redimir puntos, el cliente " + Codigo + " excede DV permitidos en canal 76",
                            "!Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cbx_RedimirM.Checked = false;
                    }
                }
                else
                {
                    RefeshPrice(cbx_RedimirM.Checked);
                    if (cbx_RedimirM.Checked)
                    {
                        btn_Anticipo.Visible = false;
                        gbx_Anticipo.Visible = false;
                    }
                    else
                    {
                        List<AccesoUsuario> ListaAccesos =
                            AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
                        if (ListaAccesos.FirstOrDefault(x => x.campo == btn_Anticipo.Name) == null)
                            btn_Anticipo.Visible = true;
                    }

                    RemoverAnticipos();
                }
            }
            else
            {
                RefeshPrice(cbx_RedimirM.Checked);
                if (cbx_RedimirM.Checked)
                {
                    btn_Anticipo.Visible = false;
                    gbx_Anticipo.Visible = false;
                }
                else
                {
                    List<AccesoUsuario> ListaAccesos =
                        AccesosDeUsuario.AccesosUsuario.Where(x => x.nombreForma == Name).ToList();
                    if (ListaAccesos.FirstOrDefault(x => x.campo == btn_Anticipo.Name) == null)
                        btn_Anticipo.Visible = true;
                }

                RemoverAnticipos();
            }
        }

        private void RefeshPrice(bool Checked)
        {
            if (cbx_Canal.Text == string.Empty)
                return;
            if (mensajeBoton != "Mayoreo")
                foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                    if (item.Precio != 0)
                    {
                        int canal = Convert.ToInt32(cbx_Canal.Text);

                        double precio = controlador.GetPrice(item.Articulo, idVenta, item.Renglon, cbx_RedimirM.Checked,
                            canal, Condicion, ClaseEstatica.Usuario.sucursal, TipoMovimiento);


                        //controlador.GetPrice(item.Articulo, idVenta, item.Renglon, Checked);
                        if (mensajeBoton == "Instituciones")
                        {
                            double value = precio;
                            item.PrecioS = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value;

                            item.Precio = value;
                        }
                        else
                        {
                            double value = Math.Truncate(100 * precio) / 100;
                            item.PrecioS = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value;

                            item.Precio = value;
                        }

                        double descuent = controlador.obtenerDescuentoCategoria(idVenta, item.Articulo);

                        if (descuent > 0)
                            item.Observaciones = descuent + "% de descuento x categoria.";
                        else
                            item.Observaciones = "";

                        Dictionary<double, double> item_ = new Dictionary<double, double>();

                        item_ = actualizaMovPorModel(item.Cantidad.ToString(), item);

                        item.SubTotal = Convert.ToDouble(item_.Keys.FirstOrDefault());

                        item.Total = Convert.ToDouble(item_.Values.FirstOrDefault());

                        item.TotalS = item_.Values.FirstOrDefault()
                            .ToString("C",
                                Thread.CurrentThread
                                    .CurrentCulture); //"$" + Convert.ToDouble(item_.Values.FirstOrDefault()).ToString();

                        //-1670
                        double dMontoMonedero =
                            controlador.obtenerMontoMonedero(idVenta, item.Articulo, item.Precio, item.Cantidad);
                        item.dMontoMonedero = dMontoMonedero;
                        item.sMontoMonedero = dMontoMonedero.ToString();
                        item.sMontoMonedero = string.Format("{0:C}", dMontoMonedero);
                    }

            llenarGrid();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(lbl_ID.Text);
        }

        private void txt_Nomina_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                ValidaNomina();

                if (obligatorioNomina && lbl_ID.Text == "")
                {
                    componenteValidado = "Nomina";
                    ValidacionComponentes(componenteValidado);
                }

                ComponentesFocus();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_Nomina_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_eventosNotasCitA.Focused == false &&
                btn_InformacionCliente.Focused == false && btn_ayuda.Focused == false &&
                btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false && cbx_Canal.Focused == false)
            {
                mensajeValidacion = "";
                ValidaNomina();
                if (obligatorioNomina && lbl_ID.Text == "")
                {
                    componenteValidado = "Nomina";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void txt_TelParticular_Click(object sender, EventArgs e)
        {
            txt_Comentarios.Text =
                "CAPTURAR EL TELEFONO PARTICULAR DEL CLIENTE CON TODO Y LADA SI NO CUENTA CON UN NUMERO DE TELEFONO CAPTURAR 10 VECES EL NUMERO 0";
        }

        private void txt_movil_Click(object sender, EventArgs e)
        {
            txt_Comentarios.Text =
                "CAPTURAR EL TELEFONO MOVIL DEL CLIENTE CON TODO Y LADA SI NO CUENTA CON UN NUMERO DE TELEFONO CAPTURAR 10 VECES EL NUMERO 0";
        }

        private void txt_Correo_Validating(object sender, CancelEventArgs e)
        {
            if (cxb_SinCorreo.Focused == false && btn_Regresar.Focused == false &&
                btn_eventosNotasCitA.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false &&
                txt_Correo2.Focused == false && cbx_Condicion.Focused == false)
            {
                if (txt_Correo2.Focused) validaDominio = 1;
                ValidacionInsertarCorreo();

                if (obligatorioCorreo && lbl_ID.Text == "")
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }
            }

            correoTypeEvent();
        }

        private void txt_Correo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                ValidacionInsertarCorreo();
                if (obligatorioCorreo)
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioCorreo) ComponentesFocus();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;

            correoTypeEvent();
        }

        private void correoTypeEvent()
        {
            if (txt_Correo.Text.ToUpper() == "SINCORREO" && txt_Correo2.Text.ToUpper() == "SINCORREO.COM")
                cxb_SinCorreo.Checked = true;
        }

        private void txt_Correo2_Validating(object sender, CancelEventArgs e)
        {
            if (cxb_SinCorreo.Focused == false && btn_Regresar.Focused == false &&
                btn_eventosNotasCitA.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false &&
                txt_Correo.Focused == false && cbx_Condicion.Focused == false)
            {
                ValidacionInsertarCorreo();
                if (obligatorioCorreo && lbl_ID.Text == "")
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }
            }

            correoTypeEvent();
        }

        private void txt_Correo2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                ValidacionInsertarCorreo();
                if (obligatorioCorreo)
                {
                    componenteValidado = "Correo";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioCorreo) ComponentesFocus();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.')
                e.Handled = false;
            else
                e.Handled = true;

            correoTypeEvent();
        }

        private void txt_TelParticular_Validating(object sender, CancelEventArgs e)
        {
            if (cbx_TelMovil.Focused == false && cbx_TelParticular.Focused == false && btn_Regresar.Focused == false &&
                btn_eventosNotasCitA.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false &&
                cbx_Condicion.Focused == false)
            {
                telefonocorrectoParticular(txt_TelParticular.Text);

                if (obligatorioParticular && lbl_ID.Text == "")
                {
                    componenteValidado = "Particular";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void txt_movil_Validating(object sender, CancelEventArgs e)
        {
            if (cbx_TelParticular.Focused == false && cbx_TelMovil.Focused == false && btn_Regresar.Focused == false &&
                btn_eventosNotasCitA.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && btn_CampoExtra.Focused == false && cbx_Cliente.Focused == false &&
                cbx_Condicion.Focused == false)
            {
                telefonocorrectoMovil(txt_movil.Text);
                if (obligatorioMovil && lbl_ID.Text == "")
                {
                    componenteValidado = "Movil";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void txt_NIP_Click(object sender, EventArgs e)
        {
        }

        #endregion

        #region Promociones

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DM0312_MostrarPosiciones posicion = new DM0312_MostrarPosiciones();
            ((PictureBox)posicion.Controls["ptb_Imagen"]).Image = pictureBox1.Image;
            posicion.Width = pictureBox1.Image.Width;
            posicion.Height = pictureBox1.Image.Height;
            posicion.Size = new Size(posicion.Width, posicion.Height);
            posicion.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DM0312_MostrarPosiciones posicion = new DM0312_MostrarPosiciones();
            ((PictureBox)posicion.Controls["ptb_Imagen"]).Image = pictureBox2.Image;
            posicion.Width = pictureBox2.Image.Width;
            posicion.Height = pictureBox2.Image.Height;
            posicion.Size = new Size(posicion.Width, posicion.Height);
            posicion.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DM0312_MostrarPosiciones posicion = new DM0312_MostrarPosiciones();
            ((PictureBox)posicion.Controls["ptb_Imagen"]).Image = pictureBox3.Image;
            posicion.Width = pictureBox3.Image.Width;
            posicion.Height = pictureBox3.Image.Height;
            posicion.Size = new Size(posicion.Width, posicion.Height);
            posicion.ShowDialog();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            DM0312_MostrarPosiciones posicion = new DM0312_MostrarPosiciones();
            ((PictureBox)posicion.Controls["ptb_Imagen"]).Image = pictureBox6.Image;
            posicion.Width = pictureBox6.Image.Width;
            posicion.Height = pictureBox6.Image.Height;
            posicion.Size = new Size(posicion.Width, posicion.Height);
            posicion.ShowDialog();
        }

        #endregion


        #region Comentarios

        private void cbx_Cliente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Cliente = ListaPuntoVenta.Where(x => x.Campo.Equals("Cliente")).FirstOrDefault();
            if (Cliente != null) txt_Comentarios.Text = Cliente.Comentario;
        }

        private void cbx_Agente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Agente = ListaPuntoVenta.Where(x => x.Campo.Equals("Agente")).FirstOrDefault();
            if (Agente != null) txt_Comentarios.Text = Agente.Comentario;
        }

        private void cbx_Canal_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Canal = ListaPuntoVenta.Where(x => x.Campo.Equals("Canal")).FirstOrDefault();
            if (Canal != null) txt_Comentarios.Text = Canal.Comentario;
        }

        private void cbx_Condicion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Condicion =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Condicion")).FirstOrDefault();
            if (Condicion != null) txt_Comentarios.Text = Condicion.Comentario;
        }

        private void cbx_Almacen_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Almacen = ListaPuntoVenta.Where(x => x.Campo.Equals("Almacen")).FirstOrDefault();
            if (Almacen != null) txt_Comentarios.Text = Almacen.Comentario;
        }

        private void txt_Correo_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Correo = ListaPuntoVenta.Where(x => x.Campo.Equals("Correo")).FirstOrDefault();
            if (Correo != null) txt_Comentarios.Text = Correo.Comentario;
        }

        private void btn_InfoArt_Click(object sender, EventArgs e)
        {
            refrescarCanalCliente();
            if (obligatorioCanal && obligatorioCliente)
            {
                if (dvg_detalleVenta.Rows.Count > 1)
                {
                    if (modeloVentaDetalle.Articulo != null)
                    {
                        DM0312_DetalleInformacionArticulo.ArticuloSeleccionado = modeloVentaDetalle.Articulo;
                        DM0312_DetalleInformacionArticulo infoArt = new DM0312_DetalleInformacionArticulo();
                        if (modeloVentaDetalle.Tipo == "Juego")
                        {
                            infoArt.EsPaquete = true;
                            infoArt.DetallesPaquete =
                                ListVentaDetalle.Where
                                    (x => x.Articulo_Ligado == modeloVentaDetalle.Articulo && x.Juego != null).Select
                                (x => new ArticulosDetalleVenta
                                {
                                    Articulo = x.Articulo
                                }).ToList();
                        }

                        TopMost = false;
                        infoArt.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("No hay Articulos", "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void txt_Correo2_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta CorreoD =
                ListaPuntoVenta.Where(x => x.Campo.Equals("CorreoDominio")).FirstOrDefault();
            if (CorreoD != null) txt_Comentarios.Text = CorreoD.Comentario;
            if (string.IsNullOrEmpty(txt_Correo.Text)) txt_Correo.Focus();
            correoTypeEvent();
        }

        private void txb_Ecommerce_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Ecommerce =
                ListaPuntoVenta.Where(x => x.Campo.Equals("IdCommerce")).FirstOrDefault();
            if (Ecommerce != null) txt_Comentarios.Text = Ecommerce.Comentario;
        }

        private void txt_FormaPago_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta FormaPago =
                ListaPuntoVenta.Where(x => x.Campo.Equals("FormaPago")).FirstOrDefault();
            if (FormaPago != null) txt_Comentarios.Text = FormaPago.Comentario;
        }

        private void chk_Mayoreo_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta checkMay =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Com Mayoreo")).FirstOrDefault();
            if (checkMay != null) txt_Comentarios.Text = checkMay.Comentario;
        }

        private void chk_Custodia_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta checkCustodia =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Custodia")).FirstOrDefault();
            if (checkCustodia != null) txt_Comentarios.Text = checkCustodia.Comentario;
        }

        private void chk_Iva_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta checkIva =
                ListaPuntoVenta.Where(x => x.Campo.Equals("DesglosarIva")).FirstOrDefault();
            if (checkIva != null) txt_Comentarios.Text = checkIva.Comentario;
        }

        private void chk_Comentario_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Comentarios =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Imprimir Comentario")).FirstOrDefault();
            if (Comentarios != null) txt_Comentarios.Text = Comentarios.Comentario;
        }

        private void cbx_AgenteServicio_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta AgenteServicio =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Agente Servicio")).FirstOrDefault();
            if (AgenteServicio != null) txt_Comentarios.Text = AgenteServicio.Comentario;
        }

        private void cbx_FormaEnvio_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta FormaEnvio =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Forma de Envio")).FirstOrDefault();
            if (FormaEnvio != null) txt_Comentarios.Text = FormaEnvio.Comentario;
        }

        private void txt_Pago_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta ctaPago =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Cuenta de Pago")).FirstOrDefault();
            if (ctaPago != null) txt_Comentarios.Text = ctaPago.Comentario;
        }

        private void txt_Observaciones_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Observaciones =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Observaciones")).FirstOrDefault();
            if (Observaciones != null) txt_Comentarios.Text = Observaciones.Comentario;
        }

        private void txt_Comentario_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Comentarios =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Comentarios")).FirstOrDefault();
            if (Comentarios != null) txt_Comentarios.Text = Comentarios.Comentario;
        }

        private void chkDomicilioCliente_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDomicilioCliente.Checked)
            {
                clsDatosEntregaCliente vDatosCliente = CDetalleVenta.obtenerDatosCliente(cbx_Cliente.Text);
                if (vDatosCliente != null)
                {
                    txt_direccionEntrega.Text = vDatosCliente.sDireccion;
                    txt_NumE.Text = vDatosCliente.sNumeroExt;
                    txt_NumI.Text = vDatosCliente.sNumeroInt;
                    cb_colonia.Text = vDatosCliente.sColonia;
                    txt_CPEntrega.Text = vDatosCliente.sCodigoPostal;
                    txt_PoblacionEntrega.Text = vDatosCliente.sPoblacion;
                    txt_EstadoEntrega.Text = vDatosCliente.sEstado;
                    txt_EntreCallesEntrega.Text = vDatosCliente.sEntreCalles;
                }
            }

            if (!chkDomicilioCliente.Checked)
            {
                txt_direccionEntrega.Text = string.Empty;
                txt_NumE.Text = string.Empty;
                txt_NumI.Text = string.Empty;
                cb_colonia.Text = string.Empty;
                txt_CPEntrega.Text = string.Empty;
                txt_PoblacionEntrega.Text = string.Empty;
                txt_EstadoEntrega.Text = string.Empty;
                txt_EntreCallesEntrega.Text = string.Empty;
            }
        }

        private void btnObservacionesVM_Click(object sender, EventArgs e)
        {
            frmObservaciones observaciones = new frmObservaciones();
            observaciones.sObservacion = txt_Observaciones.Text;
            observaciones.ShowDialog();
            txt_Observaciones.Text = observaciones.sObservacion;
        }

        private void cbx_RedimirM_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta RedimirMonedero =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Redimir Monedero")).FirstOrDefault();
            if (RedimirMonedero != null) txt_Comentarios.Text = RedimirMonedero.Comentario;
        }

        private void chkTransferencia_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTransferencia.Checked)
            {
                if (chx_Die.Checked) chx_Die.Checked = false;

                if (idVenta != 0)
                {
                    if (!string.IsNullOrEmpty(tipoCuenta.sTipo))
                    {
                        txtBanco.Text = tipoCuenta.sBanco;

                        if (tipoCuenta.sTipo != "Cuenta CLABE")
                            txtCuentaClabe.Text = "****-****-****-" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                        else
                            txtCuentaClabe.Text = "****-****-****-**" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                    }
                    else
                    {
                        //Mandar llamar shm
                        if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                        {
                            Process System = new Process();
                            System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                            System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                            System.StartInfo.Verb = "runas";
                            System.StartInfo.Arguments = "ACTUALIZARCUENTABANCARIA " + Cliente + " " + idVenta + " " +
                                                         ClaseEstatica.Usuario.usuario;
                            System.StartInfo.UseShellExecute = false;
                            System.Start();
                            System.WaitForExit();

                            tipoCuenta = shm.ObtenerInfoCLABE(Cliente);
                            if (string.IsNullOrEmpty(tipoCuenta.sTipo))
                            {
                                chkTransferencia.Checked = false;
                                return;
                            }

                            txtBanco.Text = tipoCuenta.sBanco;

                            if (tipoCuenta.sTipo != "Cuenta CLABE")
                                txtCuentaClabe.Text = "****-****-****-" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                            else
                                txtCuentaClabe.Text =
                                    "****-****-****-**" + shm.ObtenerUltimosDigitos(tipoCuenta.sCLABE);
                        }
                    }

                    controlador.acutalizarTransferenciaStp(chkTransferencia.Checked, idVenta);
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chkTransferencia.Checked = false;
                }
            }
            else
            {
                txtCuentaClabe.Text = string.Empty;
                txtBanco.Text = string.Empty;

                if (idVenta != 0)
                {
                    controlador.acutalizarTransferenciaStp(chkTransferencia.Checked, idVenta);
                }
                else
                {
                    MessageBox.Show("No existe id de venta, llenar los datos obligatorios", "Error!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    chkTransferencia.Checked = false;
                }
            }

            camposBanco(chkTransferencia.Checked);
        }

        public string FormatearTarjeta(string SinGuiones)
        {
            int tamaño = SinGuiones.Length;
            string cadenaNueva = "";
            int divisiones = tamaño / 4;
            int resto = tamaño % 4;
            int contador = 1;
            int posicionInicial = 0;
            const int salto = 4;
            while (contador <= divisiones)
            {
                cadenaNueva = contador == 5
                    ? cadenaNueva + SinGuiones.Substring(posicionInicial, salto)
                    : cadenaNueva + SinGuiones.Substring(posicionInicial, salto) + "-";
                posicionInicial += salto;
                contador++;
            }

            cadenaNueva = cadenaNueva + SinGuiones.Substring(posicionInicial, resto);

            return cadenaNueva;
        }

        /// <summary>
        ///     Metodo encargado de mostrar u ocultar los componentes stp
        /// </summary>
        /// <param name="bEstatus">Estatus que obtendran los componentes</param>
        public void camposBanco(bool bEstatus)
        {
            lblBanco.Visible = bEstatus;
            lblCuentaClabe.Visible = bEstatus;
            txtBanco.Visible = bEstatus;
            txtCuentaClabe.Visible = bEstatus;
        }

        private void txt_movil_Leave(object sender, EventArgs e)
        {
            int numV = controladorD.SucursalRDP(ClaseEstatica.Usuario.sucursal);
            if (txt_movil.Text.Length == 10)
            {
                string sTel = txt_movil.Text.Length == 10 ? txt_movil.Text : "0000000000";
                if (numV == 1)
                {
                    string ArgumentosPlugin = @"SHM.exe N SHM\ " + "\"" + string.Concat("VALIDACIONTELXSMS", "|",
                        cbx_Cliente.Text, "|", idVenta, "|", "DetalleVenta", "|",
                        sTel, "|", ClaseEstatica.Usuario.usuario, "|", ClaseEstatica.Usuario.sucursal) + "\"" + " N N";

                    controladorD.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                }
                else
                {
                    if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                    {
                        string ArgumentosPlugin = "VALIDACIONTELXSMS" + " " + cbx_Cliente.Text + " " + idVenta + " " +
                                                  "DetalleVenta" + " " + sTel + ClaseEstatica.Usuario +
                                                  ClaseEstatica.Usuario.sucursal;
                        controladorD.EjecutarPlugins(ArgumentosPlugin, "SHM.exe",
                            ConfigurationManager.AppSettings["CarpetaSHM"]);
                    }
                }
            }
        }

        /// <summary>
        ///     validacion para el Campo de Codigo Recomendado
        /// </summary>
        /// Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// 1030/1061 DIMA
        private void txt_CodigoRecomendadoDima_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (Canal == 76)
                {
                    txt_CodigoRecomendadoDimaUPPERCASE();

                    if (validarCodigoRecomendadoRegex(txt_CodigoRecomendadoDima.Text) &&
                        !txt_CodigoRecomendadoDima.ReadOnly)
                    {
                        if (validaExisteCodigoRecomendatoDima(txt_CodigoRecomendadoDima.Text) &&
                            !txt_CodigoRecomendadoDima.ReadOnly)
                        {
                            DM0312_CPuntoDeVenta Controlador = new DM0312_CPuntoDeVenta();

                            txt_CodigoRecomendadoDima.ReadOnly = true;

                            Controlador.obtenerDatosDimaRecomendador(txt_CodigoRecomendadoDima.Text, Canal);

                            customMessageCodigoRecomendado(
                                Controlador.obtenerDatosDimaRecomendador(txt_CodigoRecomendadoDima.Text, Canal),
                                "Cliente Recomendador", "check");
                        }
                        else
                        {
                            customMessageCodigoRecomendado("Código recomendado incorrecto/inexistente.", "Advertencia",
                                "alert");
                        }
                    }
                    else if (txt_CodigoRecomendadoDima.Text.Length == 11 && //Canal 76
                             !validarCodigoRecomendadoRegex(txt_CodigoRecomendadoDima.Text))
                    {
                        customMessageCodigoRecomendado("Código recomendado incorrecto", "Advertencia", "alert");
                        txt_CodigoRecomendadoDima.ReadOnly = false;
                        txt_CodigoRecomendadoDima.Enabled = true;
                    }
                }

                if (Canal == 3 || canalC == 7)
                {
                    if (validarCodigoRecomendado7y3Regex(txt_CodigoRecomendadoDima.Text) &&
                        !txt_CodigoRecomendadoDima.ReadOnly)
                    {
                        DM0312_CPuntoDeVenta Controlador = new DM0312_CPuntoDeVenta();


                        string validaCodigoMenudeo =
                            controlador.validaCodigoMenudeoUEN(txt_CodigoRecomendadoDima.Text, canalC);

                        if (validaCodigoMenudeo != "OK")
                        {
                            MessageBox.Show(validaCodigoMenudeo, "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            return;
                        }


                        validaCodigoMenudeo =
                            controlador.validaCodigoMenudeo(txt_CodigoRecomendadoDima.Text, cbx_Cliente.Text);

                        if (validaCodigoMenudeo != "OK")
                        {
                            MessageBox.Show(validaCodigoMenudeo, "Advertencia!", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                            return;
                        }


                        List<string> DatosCliente =
                            Controlador.encontrarCteCodigoMenudeo(txt_CodigoRecomendadoDima.Text, cbx_Cliente.Text);

                        if (DatosCliente.Count > 0)
                        {
                            txt_CodigoRecomendadoDima.ReadOnly = true;
                            customMessageCodigoRecomendado(DatosCliente[0] + "\r\n" + DatosCliente[1],
                                "Cliente Recomendador", "check");
                        }
                    }
                    else if (txt_CodigoRecomendadoDima.Text.Length >= 5 &&
                             !validarCodigoRecomendado7y3Regex(txt_CodigoRecomendadoDima.Text))
                    {
                        customMessageCodigoRecomendado("Código recomendado incorrecto", "Advertencia", "alert");
                        txt_CodigoRecomendadoDima.ReadOnly = false;
                        txt_CodigoRecomendadoDima.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //en caso de tronar lo primero es mandar a llamar el manejador de errores de el     	punto de venta y registrar el error en Base de Datos
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                //TODO WIP(Agregar la barra de Estatus de ser posible esto solo a las vistas)    
                //Se arroja el mensaje a el usuario de la Exepcion extraordinaria
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        private bool validaExisteCodigoRecomendatoMenudeo(string CodigoDimr)
        {
            bool validar = false;
            if (validarCodigoRecomendado7y3Regex(txt_CodigoRecomendadoDima.Text))
            {
                List<string> DatosCliente = controlador.encontrarCteCodigoMenudeo(CodigoDimr, cbx_Cliente.ValueMember);

                if (DatosCliente.Count >= 1) validar = true;
            }

            return validar;
        }

        private void txt_CodigoRecomendadoDimaUPPERCASE()
        {
            if (Regex.IsMatch(txt_CodigoRecomendadoDima.Text, "[^A-Z0-9a-z]"))
            {
                txt_CodigoRecomendadoDima.Text =
                    txt_CodigoRecomendadoDima.Text.Remove(txt_CodigoRecomendadoDima.Text.Length - 1);
                txt_CodigoRecomendadoDima.Text = txt_CodigoRecomendadoDima.Text.ToUpper();
            }
        }

        /// <summary>
        ///     revisa el estado del check y cambio los estatus de el campo CodigoRecomendado
        /// </summary>
        /// Developer:Getsemani Avila Quezada ༼ つ ◕_◕ ༽つ
        /// 1030/1061 DIMA
        private void chx_CodigoRecomendado_CheckedChanged(object sender, EventArgs e)
        {
            if (chx_CodigoRecomendado.Checked)
            {
                txt_CodigoRecomendadoDima.Enabled = true;
                txt_CodigoRecomendadoDima.ReadOnly = false;
            }
            else
            {
                txt_CodigoRecomendadoDima.Enabled = false;
                txt_CodigoRecomendadoDima.ReadOnly = true;
            }
        }

        //private void dvg_detalleVenta_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //}

        private void btn_MostrarAbonos_Click(object sender, EventArgs e)
        {
            if (ListVentaDetalle.Where(a => a.Articulo != null).Select(a => a.Articulo).Count() < 1)
            {
                MessageBox.Show("Sin articulos en el detalle", "Mensaje", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (std.obtenerEstatuMovimiento(idVenta) != lbl_Estatus.Text)
                MessageBox.Show("El estatus del moviemiento no corresponde al original.", "Punto De Venta",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (Canal == 3 || canalC == 7)
                if (controladorEntrada.validaVentasFinalesInternet(Codigo) == "NO")
                    if (std.realizarValidacion())
                    {
                        string TipoCredito = controllerExplorador.TipoCredito(Codigo);

                        int iSuc = std.obtenerSucursal(Codigo);

                        if (std.validarMx(TipoCredito))
                            if (iSuc != ClaseEstatica.Usuario.sucursal)
                                if (!std.validarSucursalVentaEnLinea())
                                {
                                    MessageBox.Show(
                                        "No es posible realizar la reactivación de movimientos en las sucursales no correspondientes.",
                                        "Mensaje!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                    }


            int candadoEdadM = 0;
            foreach (DM0312_MVentaDetalle item in ListVentaDetalle)
                if (item.Linea == "SEGUROS DE VIDA")
                    candadoEdadM = 1;

            if (Canal == 3 || Canal == 7)
                if (candadoEdadM == 0)
                    if (!CandadoEdadCondicion(Codigo))
                        return;

            if (ClaseEstatica.Usuario.sucursal == 90 || ClaseEstatica.Usuario.sucursal == 41)
                if (TipoMovimiento == "Pedido")
                    if (txb_Ecommerce.Text == "")
                    {
                        MessageBox.Show("Campo Ped.Ecommerce debe ser obligatorio", "Advertencia!",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


            //////////TipoDima///////////////////
            if (Canal == 76 || Canal == 80)
            {
                //if (controlador.validaCasa(Codigo, Canal) == "Nuevo")
                //{
                //    controlador.UpdateTipoDima(Codigo);
                //}

                //-TipoDima ↓ 2019-05-25
                if (controlador.ValorTipoDIMA(Codigo) == "")
                    controlador.UpdateTipoDima(Codigo, Canal == 76 ? "Normal" : "Dima Ranch");
                if (Canal == 76)
                {
                    string sMotos = controlador.obtenerMontos(cbx_Condicion.Text);

                    if (!string.IsNullOrEmpty(sMotos))
                    {
                        double dMontoMinimo = double.Parse(sMotos.Split('|')[0]);
                        double dMontoMaximo = double.Parse(sMotos.Split('|')[1]);
                        double dTotalVenta = double.Parse(txtTotal.Text.Replace("$", ""));

                        if (!(dTotalVenta >= dMontoMinimo && dTotalVenta <= dMontoMaximo))
                        {
                            MessageBox.Show(
                                "La condición de pago " + cbx_Condicion.Text + " solo permite ventas de $" +
                                dMontoMinimo + " a $" + dMontoMaximo + "\n" +
                                "Favor de seleccionar otra condición de pago.", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
            }

            Abono Abono = new Abono
            {
                idVenta = idVenta,
                IdCliente = cbx_Cliente.Text,
                IDSucursal = ClaseEstatica.Usuario.sucursal,
                CanalVenta = int.Parse(cbx_Canal.Text),
                Condicion = cbx_Condicion.Text,
                Uen = ClaseEstatica.Usuario.Uen,
                Movimiento = controladorEntrada.validaVentasFinalesInternet(Codigo),
                TipoCliente = cExtra.obtenerTipoCliente(cbx_Cliente.Text, canalC),
                ImportePagoNormal = total,
                Articulos = new List<AbonoDetalle>()
            };

            DataTable preciosArticulosSelpSucursal, preciosArticulosSelp = new DataTable();
            preciosArticulosSelpSucursal = controlador.ObtenerPrecioPPArticulos(cbx_Condicion.Text,
                Abono.TipoCliente ?? "", ClaseEstatica.Usuario.Sucursal, ClaseEstatica.Usuario.Uen,
                string.Join(",", ListVentaDetalle.Where(a => a.Articulo != null).Select(a => "'" + a.Articulo + "'")));
            preciosArticulosSelp = controlador.ObtenerPrecioPPArticulos(cbx_Condicion.Text, Abono.TipoCliente ?? "", 0,
                ClaseEstatica.Usuario.Uen,
                string.Join(",", ListVentaDetalle.Where(a => a.Articulo != null).Select(a => "'" + a.Articulo + "'")));

            foreach (DM0312_MVentaDetalle detalleVenta in ListVentaDetalle)
                if (detalleVenta.Articulo != null)
                {
                    bool existe = false;
                    foreach (DataRow row in preciosArticulosSelpSucursal.Rows)
                        if (detalleVenta.Articulo == row["ARTICULO"].ToString())
                        {
                            existe = true;
                            Abono.Articulos.Add(new AbonoDetalle
                            {
                                Articulo = detalleVenta.Articulo,
                                Cantidad = detalleVenta.Cantidad,
                                PagoNormal = detalleVenta.Precio,
                                PagoNormalSELP = double.Parse(row["PrecioTN"].ToString()),
                                PagoInmediadoSELP = double.Parse(row["PrecioTP"].ToString())
                            });
                            break;
                        }

                    if (!existe)
                        foreach (DataRow row in preciosArticulosSelp.Rows)
                            if (detalleVenta.Articulo == row["ARTICULO"].ToString())
                            {
                                existe = true;
                                Abono.Articulos.Add(new AbonoDetalle
                                {
                                    Articulo = detalleVenta.Articulo,
                                    Cantidad = detalleVenta.Cantidad,
                                    PagoNormal = detalleVenta.Precio,
                                    PagoNormalSELP = double.Parse(row["PrecioTN"].ToString()),
                                    PagoInmediadoSELP = double.Parse(row["PrecioTP"].ToString())
                                });
                                break;
                            }

                    if (!existe)
                        Abono.Articulos.Add(new AbonoDetalle
                        {
                            Articulo = detalleVenta.Articulo,
                            Cantidad = detalleVenta.Cantidad,
                            PagoNormal = detalleVenta.Precio,
                            PagoNormalSELP = 99999.99,
                            PagoInmediadoSELP = 99999.99
                        });
                }

            CalcularAbono calcularAbono = new CalcularAbono(Abono);
            calcularAbono.ShowDialog();
        }

        private void txt_Nomina_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Nomina = ListaPuntoVenta.Where(x => x.Campo.Equals("Nomina de Empleado"))
                .FirstOrDefault();
            if (Nomina != null) txt_Comentarios.Text = Nomina.Comentario;
        }

        private void txt_direccionEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Direccion =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Direccion de Entrega")).FirstOrDefault();
            if (Direccion != null) txt_ComentariosDatosEntrega.Text = Direccion.Comentario;
        }

        private void txt_CPEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta CodigoPostal =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Codigo Postal")).FirstOrDefault();
            if (CodigoPostal != null) txt_ComentariosDatosEntrega.Text = CodigoPostal.Comentario;
        }

        private void txt_PoblacionEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta PoblacionEntrega =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Poblacion de Entrega")).FirstOrDefault();
            if (PoblacionEntrega != null) txt_ComentariosDatosEntrega.Text = PoblacionEntrega.Comentario;
        }

        private void txt_EstadoEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta EstadoEntrega =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Estado de Entrega")).FirstOrDefault();
            if (EstadoEntrega != null) txt_ComentariosDatosEntrega.Text = EstadoEntrega.Comentario;
        }

        private void txt_EntreCallesEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta calles = ListaPuntoVenta.Where(x => x.Campo.Equals("calles de Entrega"))
                .FirstOrDefault();
            if (calles != null) txt_ComentariosDatosEntrega.Text = calles.Comentario;
        }

        private void txt_TelParticularEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta TelParticular =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Tel Particular de Entrega")).FirstOrDefault();
            if (TelParticular != null) txt_ComentariosDatosEntrega.Text = TelParticular.Comentario;
            txt_ComentariosDatosEntrega.Text =
                "Capturar el telefono Particular con todo y lada si no cuenta con un numero de telefono capturar 10 veces el numero 0";
        }

        private void txt_MovilEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta TelMovil =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Tel Movil de Entrega")).FirstOrDefault();
            if (TelMovil != null) txt_ComentariosDatosEntrega.Text = TelMovil.Comentario;
            txt_ComentariosDatosEntrega.Text =
                "Capturar el telefono Movil con todo y lada si no cuenta con un numero de telefono capturar 10 veces el numero 0";
        }

        private void txt_ReferenciaEntrega_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta ReferenciaEntrega =
                ListaPuntoVenta.Where(x => x.Campo.Equals("Referencia de Entrega")).FirstOrDefault();
            if (ReferenciaEntrega != null) txt_ComentariosDatosEntrega.Text = ReferenciaEntrega.Comentario;
        }

        #endregion

        #region ImportarExcel

        private void LeerExcel()
        {
            try
            {
                List<DM0312_MVentaDetalle> DatosExcel = new List<DM0312_MVentaDetalle>();
                List<string> ArticulosConError = new List<string>();

                OpenFileDialog fichero = new OpenFileDialog();
                fichero.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
                if (fichero.ShowDialog() == DialogResult.OK)
                {
                    //libro excel
                    DatosExcel = OpenExcel(fichero.FileName);

                    fichero.Dispose();

                    if (DatosExcel.Count == 0)
                    {
                        MessageBox.Show("Sin articulos por Agregar", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                        return;
                    }

                    foreach (DM0312_MVentaDetalle i in DatosExcel)
                    {
                        Console.WriteLine(i.Articulo);
                        if (i.Cantidad <= 0)
                            i.Cantidad = 1;

                        if (controlador.LineaART(i.Articulo) == "SEGUROS DE VIDA")
                            if (!CandadoEdad(Codigo))
                            {
                                ArticulosConError.Add(i.Articulo);
                                return;
                            }

                        if (!BuscarArticulos(i.Articulo, false, i.Cantidad, true))
                            ArticulosConError.Add(i.Articulo);
                    }

                    if (ArticulosConError.Count > 0)
                        MessageBox.Show("Algunos articulos tienen Error y no pudieron ser agregados", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private List<DM0312_MVentaDetalle> OpenExcel(string filename)
        {
            List<DM0312_MVentaDetalle> DatosExcel = new List<DM0312_MVentaDetalle>();

            Application objectExcel = new Application();

            Workbook theWorkbook = objectExcel.Workbooks.Open(filename, 0, true, 5, "", "", true, XlPlatform.xlWindows,
                "\t", false, false, 0, true);

            Sheets sheets = theWorkbook.Worksheets;
            Worksheet worksheet = (Worksheet)sheets.get_Item(1);

            Range range = worksheet.UsedRange;

            int RowsCount = range.Rows.Count;

            //recorre rows
            for (int r = 2; r <= RowsCount; r++)
            {
                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                if (range.Cells[r, 1].Value != null)
                {
                    model.Articulo = (range.Cells[r, 1] as Range).Value.ToString();

                    if (range.Cells[r, 2].Value != null)
                    {
                        Type type = range.Cells[r, 2].Value.GetType();

                        if (type.Name.Contains("String"))
                            model.Cantidad = 1;
                        else
                            model.Cantidad = (int)(range.Cells[r, 2] as Range).Value;
                    }
                    else
                    {
                        model.Cantidad = 1;
                    }

                    DatosExcel.Add(model);
                }
            }

            objectExcel.Quit();

            return DatosExcel;
        }


        private void btnImportExcel_Click(object sender, EventArgs e)
        {
            ValidaCamposObligatorios();
            if (obligatorio != true)
            {
                //if (!frmLoading.Visible)
                //{
                //    frmLoading.Show(this);
                //    DesabilitarControles(false);
                //}
                dvg_detalleVenta.Visible = false;

                /*await Task.Run(() =>*/
                LeerExcel();

                dvg_detalleVenta.Visible = true;
                //if (frmLoading.Visible)
                //{
                //    frmLoading.Hide();
                //    DesabilitarControles(true);
                //}
            }

            btn_Afectar.Focus();
        }

        #endregion

        #region SeriesDespuesCambiarAlmacen

        private void DeleteSeriesNewAlmacen()
        {
            foreach (DM0312_MVentaDetalle i in ListVentaDetalle)
                if (i.Articulo != null)
                {
                    controlador.DeleteSeriesLotes(i.Serie, idVenta, i.Articulo);
                    i.Serie = ControladorSerie.GetSerie(idVenta, i.Articulo);
                }

            llenarGrid();
        }

        private void cbx_Almacen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListVentaDetalle.Count >= 2)
            {
                string value = cbx_Almacen.SelectedItem.ToString();

                if (value != Alm) DeleteSeriesNewAlmacen();
            }
        }

        //llena serie
        public string llenarSeries(DM0312_MVentaDetalle item, bool SinSerie = false)
        {
            if (SinSerie)
                return string.Empty;

            if (item.Tipo != "Serie") return string.Empty;

            int sucOrigen = controlador.GetSucursal(almacenOrigen.Trim());

            int almacenActual = controlador.GetSucursal(Alm);

            if (sucOrigen != almacenActual)
            {
                MessageBox.Show("No puede agregar series, si no esta seleccionado su Almacen Origen", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return string.Empty;
            }

            if (!ValidaMotosyCelular(true, item)) return string.Empty;

            //if (item.Linea == "MOTOCICLETAS")
            //{

            //    DM0312_DetalleLoginMotos loginMotos = new DM0312_DetalleLoginMotos();
            //    loginMotos.ShowDialog();

            //    if (!DM0312_DetalleLoginMotos.LoginCorrecto & DM0312_DetalleLoginMotos.Regresar)
            //    {
            //        MessageBox.Show("No puede asignar series si no se Autentifica", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        return string.Empty;
            //    }
            //}


            DM0312_DetalleSerieArticulo.ArticuloSeleccionado = item.Articulo;
            DM0312_DetalleSerieArticulo.DescripcionArticulo = item.Descripcion;
            DM0312_DetalleSerieArticulo.IDVenta = idVenta;
            DM0312_DetalleSerieArticulo.AlmacenArticulo = Almacen;
            DM0312_DetalleSerieArticulo.SucursalOrigen = ClaseEstatica.Usuario.sucursal;
            DM0312_DetalleSerieArticulo.MovConcluido = false;
            DM0312_DetalleSerieArticulo.cantidadArticulo = item.Cantidad;
            DM0312_DetalleSerieArticulo.RenglonID = item.RenglonID;

            ClaseEstatica.SeriesArticulos = ControladorSerie.ObtenerSeriesArticulos(DM0312_DetalleSerieArticulo.IDVenta,
                DM0312_DetalleSerieArticulo.ArticuloSeleccionado);

            DM0312_DetalleSerieArticulo SerieForm = new DM0312_DetalleSerieArticulo();

            SerieForm.ShowDialog();

            item.Serie = ControladorSerie.GetSerie(idVenta, item.Articulo);


            return item.Serie;
        }

        #endregion
    }
}