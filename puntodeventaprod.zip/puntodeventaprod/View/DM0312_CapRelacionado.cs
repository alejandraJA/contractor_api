﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_CapRelacionado : Form
    {
        private readonly DM0312_CCapRelacionado controller;

        private List<string> DataClient = new List<string>();

        private readonly int Height_ = 347;

        private readonly int HeightInicial = 150;

        public DM0312_CapRelacionado()
        {
            InitializeComponent();

            controller = new DM0312_CCapRelacionado();
        }

        public string cliente { get; set; }

        ~DM0312_CapRelacionado()
        {
            GC.Collect();
        }

        private void DM0312_CapRelacionado_Load(object sender, EventArgs e)
        {
            //HeightInicial = 120;
            Height = HeightInicial;
            toolTip1.SetToolTip(cmbClienteRel, "INSERTAR CLIENTE A RELACIONAR CON: " + cliente);
            toolTip1.SetToolTip(BtnDatosRel,
                "SELECCIONAR PARA VER LA INFORMACION IMPORTANTE DEL CLIENTE A RELACIONAR CON: " + cliente);
            toolTip1.SetToolTip(label1, "CLIENTE A RELACIONAR CON: " + cliente);
            toolTip1.SetToolTip(txtCuenta, "NUMERO DE CUENTA DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(label2, "NUMERO DE CUENTA DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(txtNombre, "NOMBRE DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(label3, "NOMBRE DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(TxtDireccion, "DIRECCION DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(label4, "DIRECCION DEL CLIENTE RELACIONADO");
            toolTip1.SetToolTip(cmb_Parentesco,
                "TIPO DE PARENTESCO QUE TIENE EL CLIENTE RELACIONADO CON EL CLIENTE CON CUETA: " + cliente);
            toolTip1.SetToolTip(label5,
                "TIPO DE PARENTESCO QUE TIENE EL CLIENTE RELACIONADO CON EL CLIENTE CON CUETA: " + cliente);
            toolTip1.SetToolTip(cmb_Aval, "SELECCIONAR SI SE QUIERE RELACIONAR COMO AVAL O NO");
            toolTip1.SetToolTip(label6, "SELECCIONAR SI SE QUIERE RELACIONAR COMO AVAL O NO");

            toolTip1.SetToolTip(BtnRegresar_ClRel, "SELECCIONAR PARA CANCELAR LA CAPTURA DE UN CLIENTE RELACIONADO");
            toolTip1.SetToolTip(BtnGuardar_ClRel,
                "SELECCIONAR PARA GUARDAR UN CLIENTE RELACIONADO A LA CUENTA: " + cliente);

            txt_ComentarioAyuda.Text = "ASISTENTE PARA CAPTURAR UN CLIENTE RELACIONADO A LA CUENTA: " + cliente;
        }

        #region MetodosRelacionado

        private void llamarCatalogoClientes()
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(1);
            catalogo.ShowDialog();

            if (catalogo.codigo != string.Empty)
            {
                cmbClienteRel.Text = catalogo.codigo;
                cmbClienteRel.Focus();
                SendKeys.Send("{tab}");
                //BtnDatosRel.Focus();
                //BtnDatosRel.Select();
            }
            else
            {
                cmbClienteRel.Focus();
                SendKeys.Send("{enter}");
                cmbClienteRel.Select();
            }
        }

        #endregion

        private void DM0312_CapRelacionado_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.Control && e.KeyCode == Keys.G) GuardarRelacionado();
        }

        private void cmbClienteRel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txtCuenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) txtNombre.Select();
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) TxtDireccion.Select();
        }

        private void TxtDireccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cmb_Parentesco.Select();
        }

        #region MetodosClienteRelacionar

        private void llenarDatosCliente()
        {
            txtCuenta.Text = DataClient[0];
            txtCuenta.ReadOnly = true;

            txtNombre.Text = DataClient[1];
            txtNombre.ReadOnly = true;

            TxtDireccion.Text = DataClient[2];
            TxtDireccion.ReadOnly = true;

            cmb_Parentesco.DataSource = controller.CteExpressParent();

            List<string> Aval = new List<string>();

            Aval.Add("Si");
            Aval.Add("No");

            cmb_Aval.DataSource = Aval;
        }

        private void GuardarRelacionado()
        {
            try
            {
                if ((cmb_Parentesco.Text == string.Empty) & (cmb_Aval.Text == string.Empty))
                    return;

                //if (cmb_Aval.Text == string.Empty)
                //    return;

                string rest = controller.ExecRelacionado(DataClient[0], cliente, cmb_Parentesco.Text, cmb_Aval.Text);

                if (rest == "Se relaciono la Cuenta correctamente")
                {
                    MessageBox.Show(rest, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    if (cmb_Aval.Text == "Si")
                    {
                        int res = controller.ExecRecomienda(DataClient[0], cliente);
                    }

                    Close();
                }
                else
                {
                    MessageBox.Show(rest, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_CapRelacionado", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region EventosForm

        public void VerInfRelacionado()
        {
            string cuenta = cmbClienteRel.Text;

            if (cuenta == string.Empty)
            {
                MessageBox.Show("Debe ingresar un cliente", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataClient = controller.GetDataCliente(cuenta);

            if (DataClient.Count == 0)
            {
                MessageBox.Show("Cliente Incorrecto", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            gb_buscar.Visible = false;

            gb_relacionar.Visible = true;

            //this.Height = (this.Height - 104);

            Height = Height_;

            Refresh();

            llenarDatosCliente();
        }

        //EventosRelacionado
        private void BtnDatosRel_Click(object sender, EventArgs e)
        {
            VerInfRelacionado();
        }

        //EventosRelacionado
        private void cmbClienteRel_DropDown(object sender, EventArgs e)
        {
            llamarCatalogoClientes();
        }

        //EventoClenteRelacionado
        private void BtnRegresar_ClRel_Click(object sender, EventArgs e)
        {
            gb_buscar.Visible = true;

            gb_relacionar.Visible = false;

            //this.Height = (this.Height - 253);

            Height = HeightInicial;

            Refresh();
        }

        //EventoClenteRelacionado
        private void BtnGuardar_ClRel_Click(object sender, EventArgs e)
        {
            GuardarRelacionado();
        }

        #endregion
    }
}