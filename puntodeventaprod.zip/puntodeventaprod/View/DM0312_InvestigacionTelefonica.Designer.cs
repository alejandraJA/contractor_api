﻿namespace PuntoVenta
{
    partial class InvestigacionTelefonica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvestigacionTelefonica));
            this.Contacto = new System.Windows.Forms.GroupBox();
            this.txtCol_con = new System.Windows.Forms.TextBox();
            this.txtCony_con = new System.Windows.Forms.TextBox();
            this.txtTel_con = new System.Windows.Forms.TextBox();
            this.txtDirec_con = new System.Windows.Forms.TextBox();
            this.txtNombre_con = new System.Windows.Forms.TextBox();
            this.txtContac_con = new System.Windows.Forms.TextBox();
            this.txtMuni_con = new System.Windows.Forms.TextBox();
            this.txtCuenta_con = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAgente = new System.Windows.Forms.TextBox();
            this.txtNombreAgente = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtFyH_ = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Ayuda = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelPersonal = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCualesPro = new System.Windows.Forms.TextBox();
            this.cmbViveAlguien = new System.Windows.Forms.ComboBox();
            this.cmbVivede = new System.Windows.Forms.ComboBox();
            this.cmbParentesco = new System.Windows.Forms.ComboBox();
            this.cmbProblemasPago = new System.Windows.Forms.ComboBox();
            this.txtClienteDedica = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txttiempoCono = new System.Windows.Forms.TextBox();
            this.txtviveen = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtConyugeDedica = new System.Windows.Forms.TextBox();
            this.txtQuienes = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panelLaboral = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtComenta_lab = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtPuestoInf_lab = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtNomInfor_lab = new System.Windows.Forms.TextBox();
            this.cmbComprobabes_lab = new System.Windows.Forms.ComboBox();
            this.txtPlanesEmpresa_lab = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtAntiguedad_lab = new System.Windows.Forms.TextBox();
            this.txtObservaciones_lab = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtIngresos_Lab = new System.Windows.Forms.TextBox();
            this.txtDepartamento_lab = new System.Windows.Forms.TextBox();
            this.txtDom_lab = new System.Windows.Forms.TextBox();
            this.txtFormaReco_lab = new System.Windows.Forms.TextBox();
            this.txtDomPer_lab = new System.Windows.Forms.TextBox();
            this.txtPuesto_lab = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panelBeneficiarioFinal = new System.Windows.Forms.GroupBox();
            this.lbl_leyendaResponsiva = new System.Windows.Forms.Label();
            this.lbl_observacionesBeneficiarioFinal = new System.Windows.Forms.Label();
            this.lbl_tratoRecibidoTienda = new System.Windows.Forms.Label();
            this.lbl_dondeHaraPagos = new System.Windows.Forms.Label();
            this.lbl_domicilioActual = new System.Windows.Forms.Label();
            this.lbl_productoOPrestamo = new System.Windows.Forms.Label();
            this.lbl_parentescoBeneficiarioFinal = new System.Windows.Forms.Label();
            this.lbl_dondeConoceDistribuidor = new System.Windows.Forms.Label();
            this.lbl_canjeoValeConNIP = new System.Windows.Forms.Label();
            this.lbl_quienTecleoNIPEnTienda = new System.Windows.Forms.Label();
            this.lbl_paraQuienFueLaCompra = new System.Windows.Forms.Label();
            this.lbl_nombreBeneficiarioFinal = new System.Windows.Forms.Label();
            this.txt_domicilioActual = new System.Windows.Forms.TextBox();
            this.cb_dondeHaraPagos = new System.Windows.Forms.ComboBox();
            this.txt_quienTecleoNIPEnTienda = new System.Windows.Forms.TextBox();
            this.txt_observacionesBeneficiarioFinal = new System.Windows.Forms.TextBox();
            this.cb_canjeoValeConNIP = new System.Windows.Forms.ComboBox();
            this.cb_parentescoBeneficiarioFinal = new System.Windows.Forms.ComboBox();
            this.txt_productoOPrestamo = new System.Windows.Forms.TextBox();
            this.txt_dondeConoceDistribuidor = new System.Windows.Forms.TextBox();
            this.txt_atencionEnTienda = new System.Windows.Forms.TextBox();
            this.txt_paraQuienFueLaCompra = new System.Windows.Forms.TextBox();
            this.txt_nombreBeneficiarioFinal = new System.Windows.Forms.TextBox();
            this.Contacto.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelPersonal.SuspendLayout();
            this.panelLaboral.SuspendLayout();
            this.panelBeneficiarioFinal.SuspendLayout();
            this.SuspendLayout();
            // 
            // Contacto
            // 
            this.Contacto.Controls.Add(this.txtCol_con);
            this.Contacto.Controls.Add(this.txtCony_con);
            this.Contacto.Controls.Add(this.txtTel_con);
            this.Contacto.Controls.Add(this.txtDirec_con);
            this.Contacto.Controls.Add(this.txtNombre_con);
            this.Contacto.Controls.Add(this.txtContac_con);
            this.Contacto.Controls.Add(this.txtMuni_con);
            this.Contacto.Controls.Add(this.txtCuenta_con);
            this.Contacto.Controls.Add(this.label15);
            this.Contacto.Controls.Add(this.label14);
            this.Contacto.Controls.Add(this.label13);
            this.Contacto.Controls.Add(this.label12);
            this.Contacto.Controls.Add(this.label9);
            this.Contacto.Controls.Add(this.label8);
            this.Contacto.Controls.Add(this.label7);
            this.Contacto.Controls.Add(this.label1);
            this.Contacto.Location = new System.Drawing.Point(3, 3);
            this.Contacto.Name = "Contacto";
            this.Contacto.Size = new System.Drawing.Size(820, 148);
            this.Contacto.TabIndex = 0;
            this.Contacto.TabStop = false;
            this.Contacto.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // txtCol_con
            // 
            this.txtCol_con.BackColor = System.Drawing.Color.White;
            this.txtCol_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtCol_con.Location = new System.Drawing.Point(448, 112);
            this.txtCol_con.Name = "txtCol_con";
            this.txtCol_con.ReadOnly = true;
            this.txtCol_con.Size = new System.Drawing.Size(366, 22);
            this.txtCol_con.TabIndex = 8;
            // 
            // txtCony_con
            // 
            this.txtCony_con.BackColor = System.Drawing.Color.White;
            this.txtCony_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtCony_con.Location = new System.Drawing.Point(449, 32);
            this.txtCony_con.Name = "txtCony_con";
            this.txtCony_con.ReadOnly = true;
            this.txtCony_con.Size = new System.Drawing.Size(362, 22);
            this.txtCony_con.TabIndex = 3;
            // 
            // txtTel_con
            // 
            this.txtTel_con.BackColor = System.Drawing.Color.White;
            this.txtTel_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtTel_con.Location = new System.Drawing.Point(274, 71);
            this.txtTel_con.Name = "txtTel_con";
            this.txtTel_con.ReadOnly = true;
            this.txtTel_con.Size = new System.Drawing.Size(142, 22);
            this.txtTel_con.TabIndex = 5;
            // 
            // txtDirec_con
            // 
            this.txtDirec_con.BackColor = System.Drawing.Color.White;
            this.txtDirec_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtDirec_con.Location = new System.Drawing.Point(36, 110);
            this.txtDirec_con.Name = "txtDirec_con";
            this.txtDirec_con.ReadOnly = true;
            this.txtDirec_con.Size = new System.Drawing.Size(380, 22);
            this.txtDirec_con.TabIndex = 6;
            // 
            // txtNombre_con
            // 
            this.txtNombre_con.BackColor = System.Drawing.Color.White;
            this.txtNombre_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtNombre_con.Location = new System.Drawing.Point(162, 32);
            this.txtNombre_con.Name = "txtNombre_con";
            this.txtNombre_con.ReadOnly = true;
            this.txtNombre_con.Size = new System.Drawing.Size(254, 22);
            this.txtNombre_con.TabIndex = 2;
            // 
            // txtContac_con
            // 
            this.txtContac_con.BackColor = System.Drawing.Color.White;
            this.txtContac_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtContac_con.Location = new System.Drawing.Point(36, 71);
            this.txtContac_con.Name = "txtContac_con";
            this.txtContac_con.ReadOnly = true;
            this.txtContac_con.Size = new System.Drawing.Size(206, 22);
            this.txtContac_con.TabIndex = 4;
            // 
            // txtMuni_con
            // 
            this.txtMuni_con.BackColor = System.Drawing.Color.White;
            this.txtMuni_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtMuni_con.Location = new System.Drawing.Point(449, 71);
            this.txtMuni_con.Name = "txtMuni_con";
            this.txtMuni_con.ReadOnly = true;
            this.txtMuni_con.Size = new System.Drawing.Size(362, 22);
            this.txtMuni_con.TabIndex = 7;
            // 
            // txtCuenta_con
            // 
            this.txtCuenta_con.BackColor = System.Drawing.Color.White;
            this.txtCuenta_con.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtCuenta_con.Location = new System.Drawing.Point(36, 32);
            this.txtCuenta_con.Name = "txtCuenta_con";
            this.txtCuenta_con.ReadOnly = true;
            this.txtCuenta_con.Size = new System.Drawing.Size(100, 22);
            this.txtCuenta_con.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label15.Location = new System.Drawing.Point(446, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 15);
            this.label15.TabIndex = 14;
            this.label15.Text = "Cónyuge ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label14.Location = new System.Drawing.Point(33, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 15);
            this.label14.TabIndex = 13;
            this.label14.Text = "Dirección ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label13.Location = new System.Drawing.Point(446, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 15);
            this.label13.TabIndex = 12;
            this.label13.Text = "Municipio ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label12.Location = new System.Drawing.Point(159, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 15);
            this.label12.TabIndex = 11;
            this.label12.Text = "Nombre ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label9.Location = new System.Drawing.Point(33, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Contacto ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label8.Location = new System.Drawing.Point(271, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Teléfono ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label7.Location = new System.Drawing.Point(446, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Colonia ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label1.Location = new System.Drawing.Point(33, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cuenta ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label3.Location = new System.Drawing.Point(526, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Fecha y Hora ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label5.Location = new System.Drawing.Point(193, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Nombre ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label10.Location = new System.Drawing.Point(33, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Agente ";
            // 
            // txtAgente
            // 
            this.txtAgente.BackColor = System.Drawing.Color.White;
            this.txtAgente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtAgente.Location = new System.Drawing.Point(36, 32);
            this.txtAgente.Name = "txtAgente";
            this.txtAgente.ReadOnly = true;
            this.txtAgente.Size = new System.Drawing.Size(134, 22);
            this.txtAgente.TabIndex = 21;
            // 
            // txtNombreAgente
            // 
            this.txtNombreAgente.BackColor = System.Drawing.Color.White;
            this.txtNombreAgente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtNombreAgente.Location = new System.Drawing.Point(196, 32);
            this.txtNombreAgente.Name = "txtNombreAgente";
            this.txtNombreAgente.ReadOnly = true;
            this.txtNombreAgente.Size = new System.Drawing.Size(305, 22);
            this.txtNombreAgente.TabIndex = 22;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtFyH_);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtAgente);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtNombreAgente);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(3, 1047);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(820, 73);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox3_Paint);
            // 
            // txtFyH_
            // 
            this.txtFyH_.BackColor = System.Drawing.Color.White;
            this.txtFyH_.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtFyH_.Location = new System.Drawing.Point(529, 32);
            this.txtFyH_.Name = "txtFyH_";
            this.txtFyH_.ReadOnly = true;
            this.txtFyH_.Size = new System.Drawing.Size(183, 22);
            this.txtFyH_.TabIndex = 23;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_Regresar.Image = ((System.Drawing.Image) (resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(0, 16);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(71, 73);
            this.btn_Regresar.TabIndex = 26;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Ayuda
            // 
            this.btn_Ayuda.BackColor = System.Drawing.Color.White;
            this.btn_Ayuda.FlatAppearance.BorderSize = 0;
            this.btn_Ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_Ayuda.Image = ((System.Drawing.Image) (resources.GetObject("btn_Ayuda.Image")));
            this.btn_Ayuda.Location = new System.Drawing.Point(0, 177);
            this.btn_Ayuda.Name = "btn_Ayuda";
            this.btn_Ayuda.Size = new System.Drawing.Size(69, 63);
            this.btn_Ayuda.TabIndex = 28;
            this.btn_Ayuda.Text = "Ayuda";
            this.btn_Ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Ayuda.UseVisualStyleBackColor = false;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btn_Guardar.Image = ((System.Drawing.Image) (resources.GetObject("btn_Guardar.Image")));
            this.btn_Guardar.Location = new System.Drawing.Point(0, 99);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(69, 72);
            this.btn_Guardar.TabIndex = 27;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_Regresar);
            this.groupBox4.Controls.Add(this.btn_Ayuda);
            this.groupBox4.Controls.Add(this.btn_Guardar);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(76, 733);
            this.groupBox4.TabIndex = 40;
            this.groupBox4.TabStop = false;
            this.groupBox4.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox4_Paint);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.Contacto);
            this.flowLayoutPanel1.Controls.Add(this.panelPersonal);
            this.flowLayoutPanel1.Controls.Add(this.panelLaboral);
            this.flowLayoutPanel1.Controls.Add(this.panelBeneficiarioFinal);
            this.flowLayoutPanel1.Controls.Add(this.groupBox3);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(76, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(858, 733);
            this.flowLayoutPanel1.TabIndex = 21;
            // 
            // panelPersonal
            // 
            this.panelPersonal.Controls.Add(this.label11);
            this.panelPersonal.Controls.Add(this.txtCualesPro);
            this.panelPersonal.Controls.Add(this.cmbViveAlguien);
            this.panelPersonal.Controls.Add(this.cmbVivede);
            this.panelPersonal.Controls.Add(this.cmbParentesco);
            this.panelPersonal.Controls.Add(this.cmbProblemasPago);
            this.panelPersonal.Controls.Add(this.txtClienteDedica);
            this.panelPersonal.Controls.Add(this.label4);
            this.panelPersonal.Controls.Add(this.txttiempoCono);
            this.panelPersonal.Controls.Add(this.txtviveen);
            this.panelPersonal.Controls.Add(this.label6);
            this.panelPersonal.Controls.Add(this.txtConyugeDedica);
            this.panelPersonal.Controls.Add(this.txtQuienes);
            this.panelPersonal.Controls.Add(this.txtNombre);
            this.panelPersonal.Controls.Add(this.label2);
            this.panelPersonal.Controls.Add(this.label16);
            this.panelPersonal.Controls.Add(this.label17);
            this.panelPersonal.Controls.Add(this.label18);
            this.panelPersonal.Controls.Add(this.label19);
            this.panelPersonal.Controls.Add(this.label20);
            this.panelPersonal.Controls.Add(this.label22);
            this.panelPersonal.Controls.Add(this.label23);
            this.panelPersonal.Location = new System.Drawing.Point(3, 157);
            this.panelPersonal.Name = "panelPersonal";
            this.panelPersonal.Size = new System.Drawing.Size(820, 234);
            this.panelPersonal.TabIndex = 24;
            this.panelPersonal.TabStop = false;
            this.panelPersonal.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label11.Location = new System.Drawing.Point(479, 172);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 15);
            this.label11.TabIndex = 18;
            this.label11.Text = "Observaciones";
            // 
            // txtCualesPro
            // 
            this.txtCualesPro.BackColor = System.Drawing.Color.White;
            this.txtCualesPro.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtCualesPro.Location = new System.Drawing.Point(481, 190);
            this.txtCualesPro.MaxLength = 40;
            this.txtCualesPro.Name = "txtCualesPro";
            this.txtCualesPro.Size = new System.Drawing.Size(330, 22);
            this.txtCualesPro.TabIndex = 19;
            // 
            // cmbViveAlguien
            // 
            this.cmbViveAlguien.BackColor = System.Drawing.Color.White;
            this.cmbViveAlguien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbViveAlguien.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cmbViveAlguien.FormattingEnabled = true;
            this.cmbViveAlguien.Location = new System.Drawing.Point(36, 138);
            this.cmbViveAlguien.Name = "cmbViveAlguien";
            this.cmbViveAlguien.Size = new System.Drawing.Size(167, 23);
            this.cmbViveAlguien.TabIndex = 6;
            // 
            // cmbVivede
            // 
            this.cmbVivede.BackColor = System.Drawing.Color.White;
            this.cmbVivede.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVivede.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cmbVivede.FormattingEnabled = true;
            this.cmbVivede.Location = new System.Drawing.Point(350, 86);
            this.cmbVivede.Name = "cmbVivede";
            this.cmbVivede.Size = new System.Drawing.Size(170, 23);
            this.cmbVivede.TabIndex = 4;
            // 
            // cmbParentesco
            // 
            this.cmbParentesco.BackColor = System.Drawing.Color.White;
            this.cmbParentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParentesco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cmbParentesco.FormattingEnabled = true;
            this.cmbParentesco.Location = new System.Drawing.Point(550, 32);
            this.cmbParentesco.Name = "cmbParentesco";
            this.cmbParentesco.Size = new System.Drawing.Size(162, 23);
            this.cmbParentesco.TabIndex = 2;
            // 
            // cmbProblemasPago
            // 
            this.cmbProblemasPago.BackColor = System.Drawing.Color.White;
            this.cmbProblemasPago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProblemasPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cmbProblemasPago.FormattingEnabled = true;
            this.cmbProblemasPago.Location = new System.Drawing.Point(283, 190);
            this.cmbProblemasPago.Name = "cmbProblemasPago";
            this.cmbProblemasPago.Size = new System.Drawing.Size(176, 23);
            this.cmbProblemasPago.TabIndex = 5;
            // 
            // txtClienteDedica
            // 
            this.txtClienteDedica.BackColor = System.Drawing.Color.White;
            this.txtClienteDedica.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtClienteDedica.Location = new System.Drawing.Point(538, 138);
            this.txtClienteDedica.MaxLength = 35;
            this.txtClienteDedica.Name = "txtClienteDedica";
            this.txtClienteDedica.Size = new System.Drawing.Size(273, 22);
            this.txtClienteDedica.TabIndex = 8;
            this.txtClienteDedica.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClienteDedica_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label4.Location = new System.Drawing.Point(33, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Conyugues se dedica a ";
            // 
            // txttiempoCono
            // 
            this.txttiempoCono.BackColor = System.Drawing.Color.White;
            this.txttiempoCono.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txttiempoCono.Location = new System.Drawing.Point(350, 33);
            this.txttiempoCono.MaxLength = 20;
            this.txttiempoCono.Name = "txttiempoCono";
            this.txttiempoCono.Size = new System.Drawing.Size(170, 22);
            this.txttiempoCono.TabIndex = 1;
            // 
            // txtviveen
            // 
            this.txtviveen.BackColor = System.Drawing.Color.White;
            this.txtviveen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtviveen.Location = new System.Drawing.Point(36, 86);
            this.txtviveen.MaxLength = 40;
            this.txtviveen.Name = "txtviveen";
            this.txtviveen.Size = new System.Drawing.Size(291, 22);
            this.txtviveen.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label6.Location = new System.Drawing.Point(280, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Problemas de Pago o Legales";
            // 
            // txtConyugeDedica
            // 
            this.txtConyugeDedica.BackColor = System.Drawing.Color.White;
            this.txtConyugeDedica.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtConyugeDedica.Location = new System.Drawing.Point(36, 190);
            this.txtConyugeDedica.MaxLength = 35;
            this.txtConyugeDedica.Name = "txtConyugeDedica";
            this.txtConyugeDedica.Size = new System.Drawing.Size(236, 22);
            this.txtConyugeDedica.TabIndex = 9;
            this.txtConyugeDedica.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtConyugeDedica_KeyPress);
            // 
            // txtQuienes
            // 
            this.txtQuienes.BackColor = System.Drawing.Color.White;
            this.txtQuienes.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtQuienes.Location = new System.Drawing.Point(228, 138);
            this.txtQuienes.MaxLength = 50;
            this.txtQuienes.Name = "txtQuienes";
            this.txtQuienes.Size = new System.Drawing.Size(292, 22);
            this.txtQuienes.TabIndex = 7;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.White;
            this.txtNombre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtNombre.Location = new System.Drawing.Point(36, 33);
            this.txtNombre.MaxLength = 70;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(291, 22);
            this.txtNombre.TabIndex = 0;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label2.Location = new System.Drawing.Point(535, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cliente se dedica  a ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label16.Location = new System.Drawing.Point(547, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 15);
            this.label16.TabIndex = 14;
            this.label16.Text = "Parentesco ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label17.Location = new System.Drawing.Point(349, 72);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 15);
            this.label17.TabIndex = 13;
            this.label17.Text = "Sabe que vive de ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label18.Location = new System.Drawing.Point(225, 120);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 15);
            this.label18.TabIndex = 12;
            this.label18.Text = "Quienes  ?";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label19.Location = new System.Drawing.Point(347, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(124, 15);
            this.label19.TabIndex = 11;
            this.label19.Text = "Tiempo de Conocerle ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label20.Location = new System.Drawing.Point(33, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 15);
            this.label20.TabIndex = 8;
            this.label20.Text = "Sabe que vive en ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label22.Location = new System.Drawing.Point(33, 120);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(154, 15);
            this.label22.TabIndex = 6;
            this.label22.Text = "Vive alguien más con ellos ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label23.Location = new System.Drawing.Point(33, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "Nombre ";
            // 
            // panelLaboral
            // 
            this.panelLaboral.Controls.Add(this.label36);
            this.panelLaboral.Controls.Add(this.txtComenta_lab);
            this.panelLaboral.Controls.Add(this.label33);
            this.panelLaboral.Controls.Add(this.txtPuestoInf_lab);
            this.panelLaboral.Controls.Add(this.label26);
            this.panelLaboral.Controls.Add(this.txtNomInfor_lab);
            this.panelLaboral.Controls.Add(this.cmbComprobabes_lab);
            this.panelLaboral.Controls.Add(this.txtPlanesEmpresa_lab);
            this.panelLaboral.Controls.Add(this.label24);
            this.panelLaboral.Controls.Add(this.txtAntiguedad_lab);
            this.panelLaboral.Controls.Add(this.txtObservaciones_lab);
            this.panelLaboral.Controls.Add(this.label25);
            this.panelLaboral.Controls.Add(this.txtIngresos_Lab);
            this.panelLaboral.Controls.Add(this.txtDepartamento_lab);
            this.panelLaboral.Controls.Add(this.txtDom_lab);
            this.panelLaboral.Controls.Add(this.txtFormaReco_lab);
            this.panelLaboral.Controls.Add(this.txtDomPer_lab);
            this.panelLaboral.Controls.Add(this.txtPuesto_lab);
            this.panelLaboral.Controls.Add(this.label27);
            this.panelLaboral.Controls.Add(this.label28);
            this.panelLaboral.Controls.Add(this.label29);
            this.panelLaboral.Controls.Add(this.label30);
            this.panelLaboral.Controls.Add(this.label31);
            this.panelLaboral.Controls.Add(this.label32);
            this.panelLaboral.Controls.Add(this.label34);
            this.panelLaboral.Controls.Add(this.label35);
            this.panelLaboral.Location = new System.Drawing.Point(3, 397);
            this.panelLaboral.Name = "panelLaboral";
            this.panelLaboral.Size = new System.Drawing.Size(820, 326);
            this.panelLaboral.TabIndex = 25;
            this.panelLaboral.TabStop = false;
            this.panelLaboral.Visible = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label36.Location = new System.Drawing.Point(32, 277);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(81, 15);
            this.label36.TabIndex = 26;
            this.label36.Text = "Comentarios:";
            // 
            // txtComenta_lab
            // 
            this.txtComenta_lab.BackColor = System.Drawing.Color.White;
            this.txtComenta_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtComenta_lab.Location = new System.Drawing.Point(35, 293);
            this.txtComenta_lab.MaxLength = 250;
            this.txtComenta_lab.Name = "txtComenta_lab";
            this.txtComenta_lab.Size = new System.Drawing.Size(485, 22);
            this.txtComenta_lab.TabIndex = 22;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.White;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label33.Location = new System.Drawing.Point(605, 225);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(130, 15);
            this.label33.TabIndex = 24;
            this.label33.Text = "Puesto del Informante:";
            // 
            // txtPuestoInf_lab
            // 
            this.txtPuestoInf_lab.BackColor = System.Drawing.Color.White;
            this.txtPuestoInf_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtPuestoInf_lab.Location = new System.Drawing.Point(607, 241);
            this.txtPuestoInf_lab.MaxLength = 20;
            this.txtPuestoInf_lab.Name = "txtPuestoInf_lab";
            this.txtPuestoInf_lab.Size = new System.Drawing.Size(207, 22);
            this.txtPuestoInf_lab.TabIndex = 21;
            this.txtPuestoInf_lab.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPuestoInf_lab_KeyPress);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label26.Location = new System.Drawing.Point(323, 225);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(136, 15);
            this.label26.TabIndex = 22;
            this.label26.Text = "Nombre del Informante:";
            // 
            // txtNomInfor_lab
            // 
            this.txtNomInfor_lab.BackColor = System.Drawing.Color.White;
            this.txtNomInfor_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtNomInfor_lab.Location = new System.Drawing.Point(326, 241);
            this.txtNomInfor_lab.MaxLength = 30;
            this.txtNomInfor_lab.Name = "txtNomInfor_lab";
            this.txtNomInfor_lab.Size = new System.Drawing.Size(273, 22);
            this.txtNomInfor_lab.TabIndex = 20;
            this.txtNomInfor_lab.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomInfor_lab_KeyPress);
            // 
            // cmbComprobabes_lab
            // 
            this.cmbComprobabes_lab.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbComprobabes_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cmbComprobabes_lab.FormattingEnabled = true;
            this.cmbComprobabes_lab.Location = new System.Drawing.Point(499, 84);
            this.cmbComprobabes_lab.Name = "cmbComprobabes_lab";
            this.cmbComprobabes_lab.Size = new System.Drawing.Size(149, 23);
            this.cmbComprobabes_lab.TabIndex = 15;
            // 
            // txtPlanesEmpresa_lab
            // 
            this.txtPlanesEmpresa_lab.BackColor = System.Drawing.Color.White;
            this.txtPlanesEmpresa_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtPlanesEmpresa_lab.Location = new System.Drawing.Point(35, 188);
            this.txtPlanesEmpresa_lab.MaxLength = 20;
            this.txtPlanesEmpresa_lab.Name = "txtPlanesEmpresa_lab";
            this.txtPlanesEmpresa_lab.Size = new System.Drawing.Size(274, 22);
            this.txtPlanesEmpresa_lab.TabIndex = 18;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label24.Location = new System.Drawing.Point(323, 118);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 15);
            this.label24.TabIndex = 10;
            this.label24.Text = "Observaciones ";
            // 
            // txtAntiguedad_lab
            // 
            this.txtAntiguedad_lab.BackColor = System.Drawing.Color.White;
            this.txtAntiguedad_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtAntiguedad_lab.Location = new System.Drawing.Point(499, 29);
            this.txtAntiguedad_lab.MaxLength = 10;
            this.txtAntiguedad_lab.Name = "txtAntiguedad_lab";
            this.txtAntiguedad_lab.Size = new System.Drawing.Size(149, 22);
            this.txtAntiguedad_lab.TabIndex = 12;
            // 
            // txtObservaciones_lab
            // 
            this.txtObservaciones_lab.BackColor = System.Drawing.Color.White;
            this.txtObservaciones_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtObservaciones_lab.Location = new System.Drawing.Point(326, 134);
            this.txtObservaciones_lab.MaxLength = 40;
            this.txtObservaciones_lab.Name = "txtObservaciones_lab";
            this.txtObservaciones_lab.Size = new System.Drawing.Size(485, 22);
            this.txtObservaciones_lab.TabIndex = 17;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label25.Location = new System.Drawing.Point(33, 225);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(134, 15);
            this.label25.TabIndex = 3;
            this.label25.Text = "Forma Recomendacion:";
            // 
            // txtIngresos_Lab
            // 
            this.txtIngresos_Lab.BackColor = System.Drawing.Color.White;
            this.txtIngresos_Lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtIngresos_Lab.Location = new System.Drawing.Point(326, 83);
            this.txtIngresos_Lab.MaxLength = 10;
            this.txtIngresos_Lab.Name = "txtIngresos_Lab";
            this.txtIngresos_Lab.Size = new System.Drawing.Size(149, 22);
            this.txtIngresos_Lab.TabIndex = 14;
            // 
            // txtDepartamento_lab
            // 
            this.txtDepartamento_lab.BackColor = System.Drawing.Color.White;
            this.txtDepartamento_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtDepartamento_lab.Location = new System.Drawing.Point(327, 30);
            this.txtDepartamento_lab.MaxLength = 20;
            this.txtDepartamento_lab.Name = "txtDepartamento_lab";
            this.txtDepartamento_lab.Size = new System.Drawing.Size(151, 22);
            this.txtDepartamento_lab.TabIndex = 11;
            // 
            // txtDom_lab
            // 
            this.txtDom_lab.BackColor = System.Drawing.Color.White;
            this.txtDom_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtDom_lab.Location = new System.Drawing.Point(36, 83);
            this.txtDom_lab.MaxLength = 40;
            this.txtDom_lab.Name = "txtDom_lab";
            this.txtDom_lab.Size = new System.Drawing.Size(273, 22);
            this.txtDom_lab.TabIndex = 13;
            // 
            // txtFormaReco_lab
            // 
            this.txtFormaReco_lab.BackColor = System.Drawing.Color.White;
            this.txtFormaReco_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtFormaReco_lab.Location = new System.Drawing.Point(36, 241);
            this.txtFormaReco_lab.MaxLength = 20;
            this.txtFormaReco_lab.Name = "txtFormaReco_lab";
            this.txtFormaReco_lab.Size = new System.Drawing.Size(273, 22);
            this.txtFormaReco_lab.TabIndex = 19;
            this.txtFormaReco_lab.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFormaReco_lab_KeyPress);
            // 
            // txtDomPer_lab
            // 
            this.txtDomPer_lab.BackColor = System.Drawing.Color.White;
            this.txtDomPer_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtDomPer_lab.Location = new System.Drawing.Point(36, 134);
            this.txtDomPer_lab.MaxLength = 40;
            this.txtDomPer_lab.Name = "txtDomPer_lab";
            this.txtDomPer_lab.Size = new System.Drawing.Size(273, 22);
            this.txtDomPer_lab.TabIndex = 16;
            // 
            // txtPuesto_lab
            // 
            this.txtPuesto_lab.BackColor = System.Drawing.Color.White;
            this.txtPuesto_lab.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txtPuesto_lab.Location = new System.Drawing.Point(36, 30);
            this.txtPuesto_lab.MaxLength = 20;
            this.txtPuesto_lab.Name = "txtPuesto_lab";
            this.txtPuesto_lab.Size = new System.Drawing.Size(273, 22);
            this.txtPuesto_lab.TabIndex = 10;
            this.txtPuesto_lab.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPuesto_lab_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label27.Location = new System.Drawing.Point(32, 171);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(98, 15);
            this.label27.TabIndex = 1;
            this.label27.Text = "Planes Empresa:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.White;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label28.Location = new System.Drawing.Point(496, 13);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 15);
            this.label28.TabIndex = 14;
            this.label28.Text = "Antiguedad";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.White;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label29.Location = new System.Drawing.Point(324, 67);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 15);
            this.label29.TabIndex = 13;
            this.label29.Text = "Ingresos Mensuales:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.White;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label30.Location = new System.Drawing.Point(33, 118);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(116, 15);
            this.label30.TabIndex = 12;
            this.label30.Text = "Domicilio Personal:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.White;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label31.Location = new System.Drawing.Point(324, 13);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(87, 15);
            this.label31.TabIndex = 11;
            this.label31.Text = "Departamento:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.White;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label32.Location = new System.Drawing.Point(33, 67);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(64, 15);
            this.label32.TabIndex = 8;
            this.label32.Text = "Domicilio:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label34.Location = new System.Drawing.Point(496, 67);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(88, 15);
            this.label34.TabIndex = 6;
            this.label34.Text = "Comprobables:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label35.Location = new System.Drawing.Point(33, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 15);
            this.label35.TabIndex = 0;
            this.label35.Text = "Puesto:";
            // 
            // panelBeneficiarioFinal
            // 
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_leyendaResponsiva);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_observacionesBeneficiarioFinal);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_tratoRecibidoTienda);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_dondeHaraPagos);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_domicilioActual);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_productoOPrestamo);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_parentescoBeneficiarioFinal);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_dondeConoceDistribuidor);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_canjeoValeConNIP);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_quienTecleoNIPEnTienda);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_paraQuienFueLaCompra);
            this.panelBeneficiarioFinal.Controls.Add(this.lbl_nombreBeneficiarioFinal);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_domicilioActual);
            this.panelBeneficiarioFinal.Controls.Add(this.cb_dondeHaraPagos);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_quienTecleoNIPEnTienda);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_observacionesBeneficiarioFinal);
            this.panelBeneficiarioFinal.Controls.Add(this.cb_canjeoValeConNIP);
            this.panelBeneficiarioFinal.Controls.Add(this.cb_parentescoBeneficiarioFinal);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_productoOPrestamo);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_dondeConoceDistribuidor);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_atencionEnTienda);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_paraQuienFueLaCompra);
            this.panelBeneficiarioFinal.Controls.Add(this.txt_nombreBeneficiarioFinal);
            this.panelBeneficiarioFinal.Location = new System.Drawing.Point(3, 729);
            this.panelBeneficiarioFinal.Name = "panelBeneficiarioFinal";
            this.panelBeneficiarioFinal.Size = new System.Drawing.Size(820, 312);
            this.panelBeneficiarioFinal.TabIndex = 25;
            this.panelBeneficiarioFinal.TabStop = false;
            this.panelBeneficiarioFinal.Visible = false;
            // 
            // lbl_leyendaResponsiva
            // 
            this.lbl_leyendaResponsiva.AutoSize = true;
            this.lbl_leyendaResponsiva.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_leyendaResponsiva.Location = new System.Drawing.Point(95, 268);
            this.lbl_leyendaResponsiva.Name = "lbl_leyendaResponsiva";
            this.lbl_leyendaResponsiva.Size = new System.Drawing.Size(640, 30);
            this.lbl_leyendaResponsiva.TabIndex = 39;
            this.lbl_leyendaResponsiva.Text = "CERTIFICO QUE LOS DATOS DE LA PRESENTE SON VERDADEDOS, PUES HAN SIDO VERIFICADOS " + "POR MI \r\nY ME RESPONSABILIZO DE CUALQUIER FALSEDAD QUE PUDIERA ENCONTRARSE EN EL" + "LOS";
            this.lbl_leyendaResponsiva.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_observacionesBeneficiarioFinal
            // 
            this.lbl_observacionesBeneficiarioFinal.AutoSize = true;
            this.lbl_observacionesBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_observacionesBeneficiarioFinal.Location = new System.Drawing.Point(481, 172);
            this.lbl_observacionesBeneficiarioFinal.Name = "lbl_observacionesBeneficiarioFinal";
            this.lbl_observacionesBeneficiarioFinal.Size = new System.Drawing.Size(87, 15);
            this.lbl_observacionesBeneficiarioFinal.TabIndex = 38;
            this.lbl_observacionesBeneficiarioFinal.Text = "Observaciones";
            // 
            // lbl_tratoRecibidoTienda
            // 
            this.lbl_tratoRecibidoTienda.AutoSize = true;
            this.lbl_tratoRecibidoTienda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_tratoRecibidoTienda.Location = new System.Drawing.Point(36, 172);
            this.lbl_tratoRecibidoTienda.Name = "lbl_tratoRecibidoTienda";
            this.lbl_tratoRecibidoTienda.Size = new System.Drawing.Size(242, 15);
            this.lbl_tratoRecibidoTienda.TabIndex = 37;
            this.lbl_tratoRecibidoTienda.Text = "¿Cómo fue el trato que recibió en la tienda?";
            // 
            // lbl_dondeHaraPagos
            // 
            this.lbl_dondeHaraPagos.AutoSize = true;
            this.lbl_dondeHaraPagos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_dondeHaraPagos.Location = new System.Drawing.Point(584, 119);
            this.lbl_dondeHaraPagos.Name = "lbl_dondeHaraPagos";
            this.lbl_dondeHaraPagos.Size = new System.Drawing.Size(139, 15);
            this.lbl_dondeHaraPagos.TabIndex = 36;
            this.lbl_dondeHaraPagos.Text = "¿Dónde hará sus pagos?";
            // 
            // lbl_domicilioActual
            // 
            this.lbl_domicilioActual.AutoSize = true;
            this.lbl_domicilioActual.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_domicilioActual.Location = new System.Drawing.Point(285, 172);
            this.lbl_domicilioActual.Name = "lbl_domicilioActual";
            this.lbl_domicilioActual.Size = new System.Drawing.Size(172, 15);
            this.lbl_domicilioActual.TabIndex = 34;
            this.lbl_domicilioActual.Text = "¿Cual es su Domicilio Actual?";
            // 
            // lbl_productoOPrestamo
            // 
            this.lbl_productoOPrestamo.AutoSize = true;
            this.lbl_productoOPrestamo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_productoOPrestamo.Location = new System.Drawing.Point(349, 16);
            this.lbl_productoOPrestamo.Name = "lbl_productoOPrestamo";
            this.lbl_productoOPrestamo.Size = new System.Drawing.Size(266, 15);
            this.lbl_productoOPrestamo.TabIndex = 33;
            this.lbl_productoOPrestamo.Text = "¿Qué producto o préstamo adquirió con su vale?";
            // 
            // lbl_parentescoBeneficiarioFinal
            // 
            this.lbl_parentescoBeneficiarioFinal.AutoSize = true;
            this.lbl_parentescoBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_parentescoBeneficiarioFinal.Location = new System.Drawing.Point(641, 15);
            this.lbl_parentescoBeneficiarioFinal.Name = "lbl_parentescoBeneficiarioFinal";
            this.lbl_parentescoBeneficiarioFinal.Size = new System.Drawing.Size(68, 15);
            this.lbl_parentescoBeneficiarioFinal.TabIndex = 32;
            this.lbl_parentescoBeneficiarioFinal.Text = "Parentesco";
            // 
            // lbl_dondeConoceDistribuidor
            // 
            this.lbl_dondeConoceDistribuidor.AutoSize = true;
            this.lbl_dondeConoceDistribuidor.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_dondeConoceDistribuidor.Location = new System.Drawing.Point(36, 68);
            this.lbl_dondeConoceDistribuidor.Name = "lbl_dondeConoceDistribuidor";
            this.lbl_dondeConoceDistribuidor.Size = new System.Drawing.Size(203, 15);
            this.lbl_dondeConoceDistribuidor.TabIndex = 31;
            this.lbl_dondeConoceDistribuidor.Text = "¿De donde conoce a su distribuidor?";
            // 
            // lbl_canjeoValeConNIP
            // 
            this.lbl_canjeoValeConNIP.AutoSize = true;
            this.lbl_canjeoValeConNIP.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_canjeoValeConNIP.Location = new System.Drawing.Point(347, 68);
            this.lbl_canjeoValeConNIP.Name = "lbl_canjeoValeConNIP";
            this.lbl_canjeoValeConNIP.Size = new System.Drawing.Size(279, 15);
            this.lbl_canjeoValeConNIP.TabIndex = 30;
            this.lbl_canjeoValeConNIP.Text = "¿Para canjear su vale hizo uso de su NIP de venta?";
            // 
            // lbl_quienTecleoNIPEnTienda
            // 
            this.lbl_quienTecleoNIPEnTienda.AutoSize = true;
            this.lbl_quienTecleoNIPEnTienda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_quienTecleoNIPEnTienda.Location = new System.Drawing.Point(36, 120);
            this.lbl_quienTecleoNIPEnTienda.Name = "lbl_quienTecleoNIPEnTienda";
            this.lbl_quienTecleoNIPEnTienda.Size = new System.Drawing.Size(191, 15);
            this.lbl_quienTecleoNIPEnTienda.TabIndex = 29;
            this.lbl_quienTecleoNIPEnTienda.Text = "¿Quién tecleo el NIP en la tienda?";
            // 
            // lbl_paraQuienFueLaCompra
            // 
            this.lbl_paraQuienFueLaCompra.AutoSize = true;
            this.lbl_paraQuienFueLaCompra.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_paraQuienFueLaCompra.Location = new System.Drawing.Point(250, 120);
            this.lbl_paraQuienFueLaCompra.Name = "lbl_paraQuienFueLaCompra";
            this.lbl_paraQuienFueLaCompra.Size = new System.Drawing.Size(315, 15);
            this.lbl_paraQuienFueLaCompra.TabIndex = 28;
            this.lbl_paraQuienFueLaCompra.Text = "¿La compra realizada fue para usted o para alguien más?";
            // 
            // lbl_nombreBeneficiarioFinal
            // 
            this.lbl_nombreBeneficiarioFinal.AutoSize = true;
            this.lbl_nombreBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lbl_nombreBeneficiarioFinal.Location = new System.Drawing.Point(36, 15);
            this.lbl_nombreBeneficiarioFinal.Name = "lbl_nombreBeneficiarioFinal";
            this.lbl_nombreBeneficiarioFinal.Size = new System.Drawing.Size(152, 15);
            this.lbl_nombreBeneficiarioFinal.TabIndex = 27;
            this.lbl_nombreBeneficiarioFinal.Text = "Nombre Beneficiario Final";
            // 
            // txt_domicilioActual
            // 
            this.txt_domicilioActual.BackColor = System.Drawing.Color.White;
            this.txt_domicilioActual.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_domicilioActual.Location = new System.Drawing.Point(285, 190);
            this.txt_domicilioActual.MaxLength = 70;
            this.txt_domicilioActual.Name = "txt_domicilioActual";
            this.txt_domicilioActual.Size = new System.Drawing.Size(186, 22);
            this.txt_domicilioActual.TabIndex = 22;
            // 
            // cb_dondeHaraPagos
            // 
            this.cb_dondeHaraPagos.BackColor = System.Drawing.Color.White;
            this.cb_dondeHaraPagos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_dondeHaraPagos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cb_dondeHaraPagos.FormattingEnabled = true;
            this.cb_dondeHaraPagos.Location = new System.Drawing.Point(584, 137);
            this.cb_dondeHaraPagos.Name = "cb_dondeHaraPagos";
            this.cb_dondeHaraPagos.Size = new System.Drawing.Size(151, 23);
            this.cb_dondeHaraPagos.TabIndex = 21;
            // 
            // txt_quienTecleoNIPEnTienda
            // 
            this.txt_quienTecleoNIPEnTienda.BackColor = System.Drawing.Color.White;
            this.txt_quienTecleoNIPEnTienda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_quienTecleoNIPEnTienda.Location = new System.Drawing.Point(36, 138);
            this.txt_quienTecleoNIPEnTienda.MaxLength = 30;
            this.txt_quienTecleoNIPEnTienda.Name = "txt_quienTecleoNIPEnTienda";
            this.txt_quienTecleoNIPEnTienda.Size = new System.Drawing.Size(191, 22);
            this.txt_quienTecleoNIPEnTienda.TabIndex = 20;
            this.txt_quienTecleoNIPEnTienda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // txt_observacionesBeneficiarioFinal
            // 
            this.txt_observacionesBeneficiarioFinal.BackColor = System.Drawing.Color.White;
            this.txt_observacionesBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_observacionesBeneficiarioFinal.Location = new System.Drawing.Point(481, 190);
            this.txt_observacionesBeneficiarioFinal.MaxLength = 200;
            this.txt_observacionesBeneficiarioFinal.Multiline = true;
            this.txt_observacionesBeneficiarioFinal.Name = "txt_observacionesBeneficiarioFinal";
            this.txt_observacionesBeneficiarioFinal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_observacionesBeneficiarioFinal.Size = new System.Drawing.Size(330, 53);
            this.txt_observacionesBeneficiarioFinal.TabIndex = 19;
            // 
            // cb_canjeoValeConNIP
            // 
            this.cb_canjeoValeConNIP.BackColor = System.Drawing.Color.White;
            this.cb_canjeoValeConNIP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_canjeoValeConNIP.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cb_canjeoValeConNIP.FormattingEnabled = true;
            this.cb_canjeoValeConNIP.Location = new System.Drawing.Point(349, 86);
            this.cb_canjeoValeConNIP.Name = "cb_canjeoValeConNIP";
            this.cb_canjeoValeConNIP.Size = new System.Drawing.Size(126, 23);
            this.cb_canjeoValeConNIP.TabIndex = 4;
            // 
            // cb_parentescoBeneficiarioFinal
            // 
            this.cb_parentescoBeneficiarioFinal.BackColor = System.Drawing.Color.White;
            this.cb_parentescoBeneficiarioFinal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_parentescoBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.cb_parentescoBeneficiarioFinal.FormattingEnabled = true;
            this.cb_parentescoBeneficiarioFinal.Location = new System.Drawing.Point(644, 33);
            this.cb_parentescoBeneficiarioFinal.Name = "cb_parentescoBeneficiarioFinal";
            this.cb_parentescoBeneficiarioFinal.Size = new System.Drawing.Size(162, 23);
            this.cb_parentescoBeneficiarioFinal.TabIndex = 2;
            // 
            // txt_productoOPrestamo
            // 
            this.txt_productoOPrestamo.BackColor = System.Drawing.Color.White;
            this.txt_productoOPrestamo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_productoOPrestamo.Location = new System.Drawing.Point(350, 33);
            this.txt_productoOPrestamo.MaxLength = 30;
            this.txt_productoOPrestamo.Name = "txt_productoOPrestamo";
            this.txt_productoOPrestamo.Size = new System.Drawing.Size(268, 22);
            this.txt_productoOPrestamo.TabIndex = 1;
            this.txt_productoOPrestamo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // txt_dondeConoceDistribuidor
            // 
            this.txt_dondeConoceDistribuidor.BackColor = System.Drawing.Color.White;
            this.txt_dondeConoceDistribuidor.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_dondeConoceDistribuidor.Location = new System.Drawing.Point(36, 86);
            this.txt_dondeConoceDistribuidor.MaxLength = 50;
            this.txt_dondeConoceDistribuidor.Name = "txt_dondeConoceDistribuidor";
            this.txt_dondeConoceDistribuidor.Size = new System.Drawing.Size(291, 22);
            this.txt_dondeConoceDistribuidor.TabIndex = 3;
            this.txt_dondeConoceDistribuidor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // txt_atencionEnTienda
            // 
            this.txt_atencionEnTienda.BackColor = System.Drawing.Color.White;
            this.txt_atencionEnTienda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_atencionEnTienda.Location = new System.Drawing.Point(36, 190);
            this.txt_atencionEnTienda.MaxLength = 40;
            this.txt_atencionEnTienda.Name = "txt_atencionEnTienda";
            this.txt_atencionEnTienda.Size = new System.Drawing.Size(236, 22);
            this.txt_atencionEnTienda.TabIndex = 9;
            this.txt_atencionEnTienda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // txt_paraQuienFueLaCompra
            // 
            this.txt_paraQuienFueLaCompra.BackColor = System.Drawing.Color.White;
            this.txt_paraQuienFueLaCompra.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_paraQuienFueLaCompra.Location = new System.Drawing.Point(262, 137);
            this.txt_paraQuienFueLaCompra.MaxLength = 50;
            this.txt_paraQuienFueLaCompra.Name = "txt_paraQuienFueLaCompra";
            this.txt_paraQuienFueLaCompra.Size = new System.Drawing.Size(279, 22);
            this.txt_paraQuienFueLaCompra.TabIndex = 7;
            this.txt_paraQuienFueLaCompra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // txt_nombreBeneficiarioFinal
            // 
            this.txt_nombreBeneficiarioFinal.BackColor = System.Drawing.Color.White;
            this.txt_nombreBeneficiarioFinal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.txt_nombreBeneficiarioFinal.Location = new System.Drawing.Point(36, 33);
            this.txt_nombreBeneficiarioFinal.MaxLength = 70;
            this.txt_nombreBeneficiarioFinal.Name = "txt_nombreBeneficiarioFinal";
            this.txt_nombreBeneficiarioFinal.Size = new System.Drawing.Size(291, 22);
            this.txt_nombreBeneficiarioFinal.TabIndex = 0;
            this.txt_nombreBeneficiarioFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.formularioBeneficiarioFinalLetras_KeyPress);
            // 
            // InvestigacionTelefonica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(934, 733);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.groupBox4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "InvestigacionTelefonica";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Investigacion Telefonica";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InvestigacionTelefonica_FormClosing);
            this.Load += new System.EventHandler(this.InvestigacionTelefonica_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.InvestigacionTelefonica_Scroll);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InvestigacionTelefonica_KeyDown_1);
            this.Contacto.ResumeLayout(false);
            this.Contacto.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelPersonal.ResumeLayout(false);
            this.panelPersonal.PerformLayout();
            this.panelLaboral.ResumeLayout(false);
            this.panelLaboral.PerformLayout();
            this.panelBeneficiarioFinal.ResumeLayout(false);
            this.panelBeneficiarioFinal.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lbl_leyendaResponsiva;

        private System.Windows.Forms.Label lbl_tratoRecibidoTienda;
        private System.Windows.Forms.Label lbl_observacionesBeneficiarioFinal;

        private System.Windows.Forms.Label lbl_dondeHaraPagos;
        private System.Windows.Forms.Label lbl_paraQuienFueLaCompra;

        private System.Windows.Forms.Label lbl_nombreBeneficiarioFinal;
        private System.Windows.Forms.Label lbl_domicilioActual;
        private System.Windows.Forms.Label lbl_quienTecleoNIPEnTienda;
        private System.Windows.Forms.Label lbl_canjeoValeConNIP;
        private System.Windows.Forms.Label lbl_dondeConoceDistribuidor;
        private System.Windows.Forms.Label lbl_parentescoBeneficiarioFinal;
        private System.Windows.Forms.Label lbl_productoOPrestamo;

        #endregion
        
        
        private System.Windows.Forms.GroupBox panelBeneficiarioFinal;
        private System.Windows.Forms.TextBox txt_atencionEnTienda;
        private System.Windows.Forms.TextBox txt_nombreBeneficiarioFinal;
        private System.Windows.Forms.TextBox txt_domicilioActual;
        private System.Windows.Forms.ComboBox cb_dondeHaraPagos;
        private System.Windows.Forms.ComboBox cb_canjeoValeConNIP;
        private System.Windows.Forms.ComboBox cb_parentescoBeneficiarioFinal;
        private System.Windows.Forms.TextBox txt_quienTecleoNIPEnTienda;
        private System.Windows.Forms.TextBox txt_paraQuienFueLaCompra;
        private System.Windows.Forms.TextBox txt_dondeConoceDistribuidor;
        private System.Windows.Forms.TextBox txt_productoOPrestamo;
        private System.Windows.Forms.TextBox txt_observacionesBeneficiarioFinal;

        private System.Windows.Forms.GroupBox Contacto;
        private System.Windows.Forms.TextBox txtCol_con;
        private System.Windows.Forms.TextBox txtCony_con;
        private System.Windows.Forms.TextBox txtTel_con;
        private System.Windows.Forms.TextBox txtDirec_con;
        private System.Windows.Forms.TextBox txtNombre_con;
        private System.Windows.Forms.TextBox txtContac_con;
        private System.Windows.Forms.TextBox txtMuni_con;
        private System.Windows.Forms.TextBox txtCuenta_con;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAgente;
        private System.Windows.Forms.TextBox txtNombreAgente;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtFyH_;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Ayuda;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox panelPersonal;
        private System.Windows.Forms.ComboBox cmbProblemasPago;
        private System.Windows.Forms.TextBox txtClienteDedica;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttiempoCono;
        private System.Windows.Forms.TextBox txtviveen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtConyugeDedica;
        private System.Windows.Forms.TextBox txtQuienes;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox panelLaboral;
        private System.Windows.Forms.TextBox txtPlanesEmpresa_lab;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtAntiguedad_lab;
        private System.Windows.Forms.TextBox txtObservaciones_lab;
        private System.Windows.Forms.TextBox txtIngresos_Lab;
        private System.Windows.Forms.TextBox txtDepartamento_lab;
        private System.Windows.Forms.TextBox txtDom_lab;
        private System.Windows.Forms.TextBox txtDomPer_lab;
        private System.Windows.Forms.TextBox txtPuesto_lab;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cmbComprobabes_lab;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtNomInfor_lab;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtFormaReco_lab;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtPuestoInf_lab;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtComenta_lab;
        private System.Windows.Forms.ComboBox cmbParentesco;
        private System.Windows.Forms.ComboBox cmbVivede;
        private System.Windows.Forms.ComboBox cmbViveAlguien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCualesPro;
    }
}