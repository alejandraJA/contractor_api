﻿namespace PuntoVenta
{
    partial class PuntoDeVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PuntoDeVenta));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dvg_detalleVenta = new System.Windows.Forms.DataGridView();
            this.MenuVentaDetalle = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.UsrIncremento = new System.Windows.Forms.ToolStripMenuItem();
            this.UsrDescuento = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarGarantiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.gbx_menuPuntoVenta = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btn_eventosNotasCitA = new System.Windows.Forms.Button();
            this.btn_InformacionCliente = new System.Windows.Forms.Button();
            this.btn_InfoArt = new System.Windows.Forms.Button();
            this.btnCuentaClabe = new System.Windows.Forms.Button();
            this.btn_Selp = new System.Windows.Forms.Button();
            this.btn_CampoExtra = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.cxm_CopiarID = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_Estatus = new System.Windows.Forms.Label();
            this.gbx_Anticipo = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_cambio = new System.Windows.Forms.Label();
            this.lbl_rec_ceros = new System.Windows.Forms.Label();
            this.Tb_efectivoRecibido = new System.Windows.Forms.TextBox();
            this.lbl_recibido = new System.Windows.Forms.Label();
            this.lbl_importeTotal = new System.Windows.Forms.Label();
            this.flp_FormaPago = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_agregarFormaPago = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.txt_anticipototal = new System.Windows.Forms.TextBox();
            this.gbx_VentaDetalle = new System.Windows.Forms.FlowLayoutPanel();
            this.lblUnidad = new System.Windows.Forms.Label();
            this.lblDescr = new System.Windows.Forms.Label();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_subT = new System.Windows.Forms.Label();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.lbl_Impuestos = new System.Windows.Forms.Label();
            this.txtImpuestos = new System.Windows.Forms.TextBox();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblMonedero = new System.Windows.Forms.Label();
            this.txtMonedero = new System.Windows.Forms.TextBox();
            this.gbx_VentaDima = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_VentaD = new System.Windows.Forms.GroupBox();
            this.txt_vale = new System.Windows.Forms.TextBox();
            this.txt_NIP = new System.Windows.Forms.TextBox();
            this.lbl_ValeVenta = new System.Windows.Forms.Label();
            this.lbl_nip = new System.Windows.Forms.Label();
            this.gbx_DatosGenerales = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_cliente = new System.Windows.Forms.Label();
            this.cbx_Cliente = new System.Windows.Forms.ComboBox();
            this.txt_ClienteNombre = new System.Windows.Forms.TextBox();
            this.lbl_Agente = new System.Windows.Forms.Label();
            this.cbx_Agente = new System.Windows.Forms.ComboBox();
            this.lbl_canal = new System.Windows.Forms.Label();
            this.cbx_Canal = new System.Windows.Forms.ComboBox();
            this.lbl_condicion = new System.Windows.Forms.Label();
            this.cbx_Condicion = new System.Windows.Forms.ComboBox();
            this.lbl_almacen = new System.Windows.Forms.Label();
            this.cbx_Almacen = new System.Windows.Forms.ComboBox();
            this.lbl_correo = new System.Windows.Forms.Label();
            this.txt_Correo = new System.Windows.Forms.TextBox();
            this.lbl_correoE = new System.Windows.Forms.Label();
            this.txt_Correo2 = new System.Windows.Forms.ComboBox();
            this.panel_Correo = new System.Windows.Forms.FlowLayoutPanel();
            this.cxb_SinCorreo = new System.Windows.Forms.CheckBox();
            this.lbl_TelPart = new System.Windows.Forms.Label();
            this.txt_TelParticular = new System.Windows.Forms.TextBox();
            this.cbx_TelParticular = new System.Windows.Forms.CheckBox();
            this.lbl_TelMovil = new System.Windows.Forms.Label();
            this.txt_movil = new System.Windows.Forms.TextBox();
            this.cbx_TelMovil = new System.Windows.Forms.CheckBox();
            this.panel_telefonos = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Ecommerce = new System.Windows.Forms.Label();
            this.txb_Ecommerce = new System.Windows.Forms.TextBox();
            this.lbl_FormaPago = new System.Windows.Forms.Label();
            this.txt_FormaPago = new System.Windows.Forms.TextBox();
            this.panel_ecommerce = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_FormaCo = new System.Windows.Forms.Label();
            this.txt_FormaCo = new System.Windows.Forms.ComboBox();
            this.chk_Mayoreo = new System.Windows.Forms.CheckBox();
            this.chk_Custodia = new System.Windows.Forms.CheckBox();
            this.chk_Iva = new System.Windows.Forms.CheckBox();
            this.chk_Comentario = new System.Windows.Forms.CheckBox();
            this.lbl_mayoreo = new System.Windows.Forms.Label();
            this.lbl_AgenteServicio = new System.Windows.Forms.Label();
            this.cbx_AgenteServicio = new System.Windows.Forms.ComboBox();
            this.lbl_FormaEnvio = new System.Windows.Forms.Label();
            this.cbx_FormaEnvio = new System.Windows.Forms.ComboBox();
            this.lbl_Pago = new System.Windows.Forms.Label();
            this.txt_Pago = new System.Windows.Forms.TextBox();
            this.lbl_Observaciones = new System.Windows.Forms.Label();
            this.txt_Observaciones = new System.Windows.Forms.TextBox();
            this.btnObservacionesVM = new System.Windows.Forms.Button();
            this.lbl_Comentario = new System.Windows.Forms.Label();
            this.txt_Comentario = new System.Windows.Forms.TextBox();
            this.cbx_RedimirM = new System.Windows.Forms.CheckBox();
            this.lbl_Nomina = new System.Windows.Forms.Label();
            this.txt_Nomina = new System.Windows.Forms.TextBox();
            this.chx_Die = new System.Windows.Forms.CheckBox();
            this.chx_CodigoRecomendado = new System.Windows.Forms.CheckBox();
            this.lblCodigoRecomendado = new System.Windows.Forms.Label();
            this.txt_CodigoRecomendadoDima = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkTransferencia = new System.Windows.Forms.CheckBox();
            this.lblBanco = new System.Windows.Forms.Label();
            this.txtBanco = new System.Windows.Forms.TextBox();
            this.lblCuentaClabe = new System.Windows.Forms.Label();
            this.txtCuentaClabe = new System.Windows.Forms.TextBox();
            this.lbl_MonederoARedimir = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Alerta = new System.Windows.Forms.Label();
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.panel_Detalle = new System.Windows.Forms.Panel();
            this.btn_MostrarAbonos = new System.Windows.Forms.Button();
            this.panelMontoVale = new System.Windows.Forms.Panel();
            this.lb_montovale = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnImportExcel = new System.Windows.Forms.Button();
            this.txt_DetalleInformacion = new System.Windows.Forms.TextBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.btn_Detalle = new System.Windows.Forms.Button();
            this.pnlBtn_DatosEntrega = new System.Windows.Forms.Panel();
            this.chkDomicilioCliente = new System.Windows.Forms.CheckBox();
            this.btn_DatosEntrega = new System.Windows.Forms.Button();
            this.txt_ComentariosDatosEntrega = new System.Windows.Forms.TextBox();
            this.gbx_DatosEntrega = new System.Windows.Forms.GroupBox();
            this.gb_CamposEntrega = new System.Windows.Forms.GroupBox();
            this.txt_NumI = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_NumE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_colonia = new System.Windows.Forms.ComboBox();
            this.txt_MovilEntrega = new System.Windows.Forms.TextBox();
            this.txt_TelParticularEntrega = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_EntreCallesEntrega = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.lbl_poblacion = new System.Windows.Forms.Label();
            this.lbl_colonia = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_EstadoEntrega = new System.Windows.Forms.TextBox();
            this.txt_PoblacionEntrega = new System.Windows.Forms.TextBox();
            this.txt_CPEntrega = new System.Windows.Forms.TextBox();
            this.txt_ReferenciaEntrega = new System.Windows.Forms.TextBox();
            this.txt_direccionEntrega = new System.Windows.Forms.TextBox();
            this.btn_nuevaEntrega = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.dgv_datosEntrega = new System.Windows.Forms.DataGridView();
            this.btn_Anticipo = new System.Windows.Forms.Button();
            this.btn_Afectar = new System.Windows.Forms.Button();
            this.btn_situaciones = new System.Windows.Forms.Button();
            this.Panel_UsuarioEstatus = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.flp_promociones = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_Promo = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).BeginInit();
            this.MenuVentaDetalle.SuspendLayout();
            this.gbx_menuPuntoVenta.SuspendLayout();
            this.cxm_CopiarID.SuspendLayout();
            this.gbx_Anticipo.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbx_VentaDetalle.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.gbx_VentaDima.SuspendLayout();
            this.gbx_VentaD.SuspendLayout();
            this.gbx_DatosGenerales.SuspendLayout();
            this.panel_Correo.SuspendLayout();
            this.panel_ecommerce.SuspendLayout();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelContactos.SuspendLayout();
            this.panel_Detalle.SuspendLayout();
            this.panelMontoVale.SuspendLayout();
            this.pnlBtn_DatosEntrega.SuspendLayout();
            this.gbx_DatosEntrega.SuspendLayout();
            this.gb_CamposEntrega.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datosEntrega)).BeginInit();
            this.Panel_UsuarioEstatus.SuspendLayout();
            this.flp_promociones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // dvg_detalleVenta
            // 
            this.dvg_detalleVenta.AllowUserToResizeColumns = false;
            this.dvg_detalleVenta.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dvg_detalleVenta.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dvg_detalleVenta.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dvg_detalleVenta.BackgroundColor = System.Drawing.Color.Snow;
            this.dvg_detalleVenta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dvg_detalleVenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dvg_detalleVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg_detalleVenta.ContextMenuStrip = this.MenuVentaDetalle;
            this.dvg_detalleVenta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dvg_detalleVenta.EnableHeadersVisualStyles = false;
            this.dvg_detalleVenta.Location = new System.Drawing.Point(3, 36);
            this.dvg_detalleVenta.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.dvg_detalleVenta.MultiSelect = false;
            this.dvg_detalleVenta.Name = "dvg_detalleVenta";
            this.dvg_detalleVenta.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            this.dvg_detalleVenta.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dvg_detalleVenta.Size = new System.Drawing.Size(920, 170);
            this.dvg_detalleVenta.TabIndex = 39;
            this.toolTip1.SetToolTip(this.dvg_detalleVenta, "Dar clic para poder insertar articulos");
            this.dvg_detalleVenta.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dvg_detalleVenta_CellBeginEdit);
            this.dvg_detalleVenta.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellClick);
            this.dvg_detalleVenta.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellDoubleClick);
            this.dvg_detalleVenta.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dvg_detalleVenta_CellFormatting);
            this.dvg_detalleVenta.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dvg_detalleVenta_CellPainting);
            this.dvg_detalleVenta.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dvg_detalleVenta_CellValidating);
            this.dvg_detalleVenta.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_detalleVenta_CellValueChanged);
            this.dvg_detalleVenta.SelectionChanged += new System.EventHandler(this.dvg_detalleVenta_SelectionChanged);
            this.dvg_detalleVenta.Click += new System.EventHandler(this.dvg_detalleVenta_Click);
            this.dvg_detalleVenta.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dvg_detalleVenta_KeyDown);
            this.dvg_detalleVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dvg_detalleVenta_KeyPress);
            // 
            // MenuVentaDetalle
            // 
            this.MenuVentaDetalle.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UsrIncremento,
            this.UsrDescuento,
            this.agregarGarantiasToolStripMenuItem});
            this.MenuVentaDetalle.Name = "MenuVentaDetalle";
            this.MenuVentaDetalle.Size = new System.Drawing.Size(179, 70);
            // 
            // UsrIncremento
            // 
            this.UsrIncremento.Name = "UsrIncremento";
            this.UsrIncremento.Size = new System.Drawing.Size(178, 22);
            this.UsrIncremento.Text = "Usuario Incremento";
            this.UsrIncremento.Click += new System.EventHandler(this.UsrIncremento_Click);
            // 
            // UsrDescuento
            // 
            this.UsrDescuento.Name = "UsrDescuento";
            this.UsrDescuento.Size = new System.Drawing.Size(178, 22);
            this.UsrDescuento.Text = "Usuario Descuento";
            this.UsrDescuento.Click += new System.EventHandler(this.UsrDescuento_Click);
            // 
            // agregarGarantiasToolStripMenuItem
            // 
            this.agregarGarantiasToolStripMenuItem.Name = "agregarGarantiasToolStripMenuItem";
            this.agregarGarantiasToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.agregarGarantiasToolStripMenuItem.Text = "Agregar Garantias";
            this.agregarGarantiasToolStripMenuItem.Click += new System.EventHandler(this.agregarGarantiasToolStripMenuItem_Click);
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.White;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(314, 260);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(515, 60);
            this.txt_ComentarioAyuda.TabIndex = 80;
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Usuario.Location = new System.Drawing.Point(1, 26);
            this.lbl_Usuario.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(136, 22);
            this.lbl_Usuario.TabIndex = 96;
            this.lbl_Usuario.Text = "Usuario";
            // 
            // gbx_menuPuntoVenta
            // 
            this.gbx_menuPuntoVenta.AutoScroll = true;
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_Regresar);
            this.gbx_menuPuntoVenta.Controls.Add(this.btnGuardar);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_eventosNotasCitA);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_InformacionCliente);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_InfoArt);
            this.gbx_menuPuntoVenta.Controls.Add(this.btnCuentaClabe);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_Selp);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_CampoExtra);
            this.gbx_menuPuntoVenta.Controls.Add(this.btn_ayuda);
            this.gbx_menuPuntoVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_menuPuntoVenta.Location = new System.Drawing.Point(3, 73);
            this.gbx_menuPuntoVenta.Name = "gbx_menuPuntoVenta";
            this.gbx_menuPuntoVenta.Size = new System.Drawing.Size(106, 579);
            this.gbx_menuPuntoVenta.TabIndex = 98;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.CausesValidation = false;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(79, 72);
            this.btn_Regresar.TabIndex = 25;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGuardar.Location = new System.Drawing.Point(3, 81);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(79, 75);
            this.btnGuardar.TabIndex = 36;
            this.btnGuardar.Text = "Guardar ";
            this.btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btn_eventosNotasCitA
            // 
            this.btn_eventosNotasCitA.BackColor = System.Drawing.Color.White;
            this.btn_eventosNotasCitA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_eventosNotasCitA.FlatAppearance.BorderSize = 0;
            this.btn_eventosNotasCitA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eventosNotasCitA.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eventosNotasCitA.Image = ((System.Drawing.Image)(resources.GetObject("btn_eventosNotasCitA.Image")));
            this.btn_eventosNotasCitA.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_eventosNotasCitA.Location = new System.Drawing.Point(3, 162);
            this.btn_eventosNotasCitA.Name = "btn_eventosNotasCitA";
            this.btn_eventosNotasCitA.Size = new System.Drawing.Size(79, 105);
            this.btn_eventosNotasCitA.TabIndex = 28;
            this.btn_eventosNotasCitA.Text = "Evento, Notas y Citas (Crtl+E)";
            this.btn_eventosNotasCitA.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_eventosNotasCitA.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_eventosNotasCitA.UseVisualStyleBackColor = false;
            this.btn_eventosNotasCitA.Click += new System.EventHandler(this.btn_eventosNotasCitA_Click);
            // 
            // btn_InformacionCliente
            // 
            this.btn_InformacionCliente.BackColor = System.Drawing.Color.White;
            this.btn_InformacionCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_InformacionCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_InformacionCliente.FlatAppearance.BorderSize = 0;
            this.btn_InformacionCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InformacionCliente.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InformacionCliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_InformacionCliente.Image")));
            this.btn_InformacionCliente.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_InformacionCliente.Location = new System.Drawing.Point(3, 273);
            this.btn_InformacionCliente.Name = "btn_InformacionCliente";
            this.btn_InformacionCliente.Size = new System.Drawing.Size(79, 85);
            this.btn_InformacionCliente.TabIndex = 29;
            this.btn_InformacionCliente.Text = "Informacion del Cliente (Crtl+I)";
            this.btn_InformacionCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InformacionCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InformacionCliente.UseVisualStyleBackColor = false;
            this.btn_InformacionCliente.Click += new System.EventHandler(this.btn_InformacionCliente_Click);
            // 
            // btn_InfoArt
            // 
            this.btn_InfoArt.BackColor = System.Drawing.Color.White;
            this.btn_InfoArt.FlatAppearance.BorderSize = 0;
            this.btn_InfoArt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InfoArt.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InfoArt.Image = ((System.Drawing.Image)(resources.GetObject("btn_InfoArt.Image")));
            this.btn_InfoArt.Location = new System.Drawing.Point(3, 364);
            this.btn_InfoArt.Name = "btn_InfoArt";
            this.btn_InfoArt.Size = new System.Drawing.Size(79, 89);
            this.btn_InfoArt.TabIndex = 37;
            this.btn_InfoArt.Text = "Información del artículo (Crtl+D)";
            this.btn_InfoArt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_InfoArt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_InfoArt.UseVisualStyleBackColor = false;
            this.btn_InfoArt.Click += new System.EventHandler(this.btn_InfoArt_Click);
            // 
            // btnCuentaClabe
            // 
            this.btnCuentaClabe.FlatAppearance.BorderSize = 0;
            this.btnCuentaClabe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuentaClabe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuentaClabe.Image = global::PuntoVenta.Properties.Resources.debit_card;
            this.btnCuentaClabe.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCuentaClabe.Location = new System.Drawing.Point(3, 459);
            this.btnCuentaClabe.Name = "btnCuentaClabe";
            this.btnCuentaClabe.Size = new System.Drawing.Size(77, 83);
            this.btnCuentaClabe.TabIndex = 115;
            this.btnCuentaClabe.Text = "Actualizar Cuenta Clabe";
            this.btnCuentaClabe.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCuentaClabe.UseVisualStyleBackColor = true;
            this.btnCuentaClabe.Click += new System.EventHandler(this.btnCuentaClabe_Click);
            // 
            // btn_Selp
            // 
            this.btn_Selp.FlatAppearance.BorderSize = 0;
            this.btn_Selp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Selp.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Selp.Image = ((System.Drawing.Image)(resources.GetObject("btn_Selp.Image")));
            this.btn_Selp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Selp.Location = new System.Drawing.Point(3, 548);
            this.btn_Selp.Name = "btn_Selp";
            this.btn_Selp.Size = new System.Drawing.Size(77, 83);
            this.btn_Selp.TabIndex = 114;
            this.btn_Selp.Text = "SELP (Crtl+S)";
            this.btn_Selp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Selp.UseVisualStyleBackColor = true;
            this.btn_Selp.Click += new System.EventHandler(this.btn_Selp_Click);
            // 
            // btn_CampoExtra
            // 
            this.btn_CampoExtra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_CampoExtra.FlatAppearance.BorderSize = 0;
            this.btn_CampoExtra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CampoExtra.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CampoExtra.Image = ((System.Drawing.Image)(resources.GetObject("btn_CampoExtra.Image")));
            this.btn_CampoExtra.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CampoExtra.Location = new System.Drawing.Point(3, 637);
            this.btn_CampoExtra.Name = "btn_CampoExtra";
            this.btn_CampoExtra.Size = new System.Drawing.Size(79, 95);
            this.btn_CampoExtra.TabIndex = 35;
            this.btn_CampoExtra.Text = "Campos Extra (Ctrl+F8)";
            this.btn_CampoExtra.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CampoExtra.UseVisualStyleBackColor = true;
            this.btn_CampoExtra.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(3, 738);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(79, 60);
            this.btn_ayuda.TabIndex = 32;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // lbl_ID
            // 
            this.lbl_ID.ContextMenuStrip = this.cxm_CopiarID;
            this.lbl_ID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(266, 28);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(114, 22);
            this.lbl_ID.TabIndex = 102;
            // 
            // cxm_CopiarID
            // 
            this.cxm_CopiarID.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem});
            this.cxm_CopiarID.Name = "cxm_CopiarID";
            this.cxm_CopiarID.Size = new System.Drawing.Size(110, 26);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copiarToolStripMenuItem.Image")));
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // lbl_Estatus
            // 
            this.lbl_Estatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estatus.Location = new System.Drawing.Point(143, 28);
            this.lbl_Estatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.lbl_Estatus.Name = "lbl_Estatus";
            this.lbl_Estatus.Size = new System.Drawing.Size(117, 22);
            this.lbl_Estatus.TabIndex = 103;
            this.lbl_Estatus.Text = "ESTATUS";
            // 
            // gbx_Anticipo
            // 
            this.gbx_Anticipo.Controls.Add(this.groupBox2);
            this.gbx_Anticipo.Location = new System.Drawing.Point(3, 1480);
            this.gbx_Anticipo.Name = "gbx_Anticipo";
            this.gbx_Anticipo.Size = new System.Drawing.Size(936, 147);
            this.gbx_Anticipo.TabIndex = 105;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.lbl_cambio);
            this.groupBox2.Controls.Add(this.lbl_rec_ceros);
            this.groupBox2.Controls.Add(this.Tb_efectivoRecibido);
            this.groupBox2.Controls.Add(this.lbl_recibido);
            this.groupBox2.Controls.Add(this.lbl_importeTotal);
            this.groupBox2.Controls.Add(this.flp_FormaPago);
            this.groupBox2.Controls.Add(this.btn_agregarFormaPago);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.txt_anticipototal);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(920, 139);
            this.groupBox2.TabIndex = 89;
            this.groupBox2.TabStop = false;
            // 
            // lbl_cambio
            // 
            this.lbl_cambio.AutoSize = true;
            this.lbl_cambio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_cambio.Location = new System.Drawing.Point(646, 116);
            this.lbl_cambio.Name = "lbl_cambio";
            this.lbl_cambio.Size = new System.Drawing.Size(89, 15);
            this.lbl_cambio.TabIndex = 112;
            this.lbl_cambio.Text = "Cambio: $ 0.00";
            // 
            // lbl_rec_ceros
            // 
            this.lbl_rec_ceros.AutoSize = true;
            this.lbl_rec_ceros.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_rec_ceros.Location = new System.Drawing.Point(613, 116);
            this.lbl_rec_ceros.Name = "lbl_rec_ceros";
            this.lbl_rec_ceros.Size = new System.Drawing.Size(24, 15);
            this.lbl_rec_ceros.TabIndex = 111;
            this.lbl_rec_ceros.Text = ".00";
            // 
            // Tb_efectivoRecibido
            // 
            this.Tb_efectivoRecibido.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.Tb_efectivoRecibido.Location = new System.Drawing.Point(531, 113);
            this.Tb_efectivoRecibido.MaxLength = 10;
            this.Tb_efectivoRecibido.Name = "Tb_efectivoRecibido";
            this.Tb_efectivoRecibido.Size = new System.Drawing.Size(76, 22);
            this.Tb_efectivoRecibido.TabIndex = 110;
            this.Tb_efectivoRecibido.Text = "0";
            this.Tb_efectivoRecibido.Enter += new System.EventHandler(this.Tb_efectivoRecibido_Enter);
            this.Tb_efectivoRecibido.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Tb_efectivoRecibido_KeyDown);
            this.Tb_efectivoRecibido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_MovilEntrega_KeyPress);
            this.Tb_efectivoRecibido.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Tb_efectivoRecibido_KeyUp);
            this.Tb_efectivoRecibido.Leave += new System.EventHandler(this.Tb_efectivoRecibido_Leave);
            // 
            // lbl_recibido
            // 
            this.lbl_recibido.AutoSize = true;
            this.lbl_recibido.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_recibido.Location = new System.Drawing.Point(471, 116);
            this.lbl_recibido.Name = "lbl_recibido";
            this.lbl_recibido.Size = new System.Drawing.Size(54, 15);
            this.lbl_recibido.TabIndex = 109;
            this.lbl_recibido.Text = "Recibido";
            // 
            // lbl_importeTotal
            // 
            this.lbl_importeTotal.AutoSize = true;
            this.lbl_importeTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_importeTotal.Location = new System.Drawing.Point(18, 114);
            this.lbl_importeTotal.Name = "lbl_importeTotal";
            this.lbl_importeTotal.Size = new System.Drawing.Size(83, 15);
            this.lbl_importeTotal.TabIndex = 69;
            this.lbl_importeTotal.Text = "Importe total :";
            // 
            // flp_FormaPago
            // 
            this.flp_FormaPago.AutoScroll = true;
            this.flp_FormaPago.Location = new System.Drawing.Point(19, 10);
            this.flp_FormaPago.Name = "flp_FormaPago";
            this.flp_FormaPago.Size = new System.Drawing.Size(708, 82);
            this.flp_FormaPago.TabIndex = 68;
            // 
            // btn_agregarFormaPago
            // 
            this.btn_agregarFormaPago.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_agregarFormaPago.BackColor = System.Drawing.Color.White;
            this.btn_agregarFormaPago.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_agregarFormaPago.FlatAppearance.BorderSize = 0;
            this.btn_agregarFormaPago.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_agregarFormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarFormaPago.ForeColor = System.Drawing.Color.Black;
            this.btn_agregarFormaPago.Image = ((System.Drawing.Image)(resources.GetObject("btn_agregarFormaPago.Image")));
            this.btn_agregarFormaPago.Location = new System.Drawing.Point(733, 10);
            this.btn_agregarFormaPago.Name = "btn_agregarFormaPago";
            this.btn_agregarFormaPago.Size = new System.Drawing.Size(181, 44);
            this.btn_agregarFormaPago.TabIndex = 61;
            this.btn_agregarFormaPago.Text = "Agregar Forma de Pago";
            this.btn_agregarFormaPago.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_agregarFormaPago.UseVisualStyleBackColor = false;
            this.btn_agregarFormaPago.Click += new System.EventHandler(this.btn_agregarFormaPago_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(186, 114);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 15);
            this.label39.TabIndex = 57;
            this.label39.Text = "Monto total :";
            // 
            // txt_anticipototal
            // 
            this.txt_anticipototal.BackColor = System.Drawing.Color.White;
            this.txt_anticipototal.Enabled = false;
            this.txt_anticipototal.Location = new System.Drawing.Point(267, 109);
            this.txt_anticipototal.Name = "txt_anticipototal";
            this.txt_anticipototal.Size = new System.Drawing.Size(63, 20);
            this.txt_anticipototal.TabIndex = 58;
            // 
            // gbx_VentaDetalle
            // 
            this.gbx_VentaDetalle.Controls.Add(this.lblUnidad);
            this.gbx_VentaDetalle.Controls.Add(this.lblDescr);
            this.gbx_VentaDetalle.Controls.Add(this.dvg_detalleVenta);
            this.gbx_VentaDetalle.Controls.Add(this.flowLayoutPanel5);
            this.gbx_VentaDetalle.Controls.Add(this.gbx_VentaDima);
            this.gbx_VentaDetalle.Location = new System.Drawing.Point(3, 565);
            this.gbx_VentaDetalle.Name = "gbx_VentaDetalle";
            this.gbx_VentaDetalle.Size = new System.Drawing.Size(936, 428);
            this.gbx_VentaDetalle.TabIndex = 100;
            // 
            // lblUnidad
            // 
            this.lblUnidad.AutoSize = true;
            this.lblUnidad.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnidad.Location = new System.Drawing.Point(3, 10);
            this.lblUnidad.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lblUnidad.Name = "lblUnidad";
            this.lblUnidad.Size = new System.Drawing.Size(56, 19);
            this.lblUnidad.TabIndex = 46;
            this.lblUnidad.Text = "Unidad";
            // 
            // lblDescr
            // 
            this.lblDescr.AutoSize = true;
            this.lblDescr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescr.Location = new System.Drawing.Point(72, 10);
            this.lblDescr.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lblDescr.Name = "lblDescr";
            this.lblDescr.Size = new System.Drawing.Size(88, 19);
            this.lblDescr.TabIndex = 47;
            this.lblDescr.Text = "Descripcion";
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this.lbl_subT);
            this.flowLayoutPanel5.Controls.Add(this.txtSubTotal);
            this.flowLayoutPanel5.Controls.Add(this.lbl_Impuestos);
            this.flowLayoutPanel5.Controls.Add(this.txtImpuestos);
            this.flowLayoutPanel5.Controls.Add(this.lbl_Total);
            this.flowLayoutPanel5.Controls.Add(this.txtTotal);
            this.flowLayoutPanel5.Controls.Add(this.lblMonedero);
            this.flowLayoutPanel5.Controls.Add(this.txtMonedero);
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 219);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(920, 47);
            this.flowLayoutPanel5.TabIndex = 54;
            // 
            // lbl_subT
            // 
            this.lbl_subT.AutoSize = true;
            this.lbl_subT.BackColor = System.Drawing.Color.White;
            this.lbl_subT.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subT.Location = new System.Drawing.Point(3, 10);
            this.lbl_subT.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_subT.Name = "lbl_subT";
            this.lbl_subT.Size = new System.Drawing.Size(62, 15);
            this.lbl_subT.TabIndex = 51;
            this.lbl_subT.Text = "Sub Total:";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.BackColor = System.Drawing.Color.White;
            this.txtSubTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubTotal.Location = new System.Drawing.Point(71, 10);
            this.txtSubTotal.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(92, 22);
            this.txtSubTotal.TabIndex = 61;
            // 
            // lbl_Impuestos
            // 
            this.lbl_Impuestos.AutoSize = true;
            this.lbl_Impuestos.BackColor = System.Drawing.Color.White;
            this.lbl_Impuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Impuestos.Location = new System.Drawing.Point(169, 10);
            this.lbl_Impuestos.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Impuestos.Name = "lbl_Impuestos";
            this.lbl_Impuestos.Size = new System.Drawing.Size(65, 15);
            this.lbl_Impuestos.TabIndex = 49;
            this.lbl_Impuestos.Text = "Impuestos ";
            // 
            // txtImpuestos
            // 
            this.txtImpuestos.BackColor = System.Drawing.Color.White;
            this.txtImpuestos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImpuestos.Location = new System.Drawing.Point(240, 10);
            this.txtImpuestos.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txtImpuestos.Name = "txtImpuestos";
            this.txtImpuestos.ReadOnly = true;
            this.txtImpuestos.Size = new System.Drawing.Size(126, 22);
            this.txtImpuestos.TabIndex = 60;
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(372, 0);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.lbl_Total.Size = new System.Drawing.Size(34, 25);
            this.lbl_Total.TabIndex = 56;
            this.lbl_Total.Text = "Total";
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.White;
            this.txtTotal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(412, 10);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(111, 22);
            this.txtTotal.TabIndex = 50;
            this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);
            // 
            // lblMonedero
            // 
            this.lblMonedero.AutoSize = true;
            this.lblMonedero.BackColor = System.Drawing.Color.White;
            this.lblMonedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonedero.Location = new System.Drawing.Point(529, 10);
            this.lblMonedero.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lblMonedero.Name = "lblMonedero";
            this.lblMonedero.Size = new System.Drawing.Size(64, 15);
            this.lblMonedero.TabIndex = 58;
            this.lblMonedero.Text = "Monedero ";
            // 
            // txtMonedero
            // 
            this.txtMonedero.BackColor = System.Drawing.Color.White;
            this.txtMonedero.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonedero.Location = new System.Drawing.Point(599, 10);
            this.txtMonedero.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txtMonedero.Name = "txtMonedero";
            this.txtMonedero.ReadOnly = true;
            this.txtMonedero.Size = new System.Drawing.Size(114, 22);
            this.txtMonedero.TabIndex = 59;
            // 
            // gbx_VentaDima
            // 
            this.gbx_VentaDima.Controls.Add(this.gbx_VentaD);
            this.gbx_VentaDima.Location = new System.Drawing.Point(3, 272);
            this.gbx_VentaDima.Name = "gbx_VentaDima";
            this.gbx_VentaDima.Size = new System.Drawing.Size(371, 172);
            this.gbx_VentaDima.TabIndex = 56;
            // 
            // gbx_VentaD
            // 
            this.gbx_VentaD.BackColor = System.Drawing.Color.White;
            this.gbx_VentaD.Controls.Add(this.txt_vale);
            this.gbx_VentaD.Controls.Add(this.txt_NIP);
            this.gbx_VentaD.Controls.Add(this.lbl_ValeVenta);
            this.gbx_VentaD.Controls.Add(this.lbl_nip);
            this.gbx_VentaD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_VentaD.Location = new System.Drawing.Point(3, 3);
            this.gbx_VentaD.Name = "gbx_VentaD";
            this.gbx_VentaD.Size = new System.Drawing.Size(360, 161);
            this.gbx_VentaD.TabIndex = 45;
            this.gbx_VentaD.TabStop = false;
            this.gbx_VentaD.Text = "Venta Dima";
            // 
            // txt_vale
            // 
            this.txt_vale.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vale.Location = new System.Drawing.Point(60, 45);
            this.txt_vale.MaxLength = 50;
            this.txt_vale.Name = "txt_vale";
            this.txt_vale.Size = new System.Drawing.Size(166, 22);
            this.txt_vale.TabIndex = 109;
            this.txt_vale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_vale_KeyPress);
            // 
            // txt_NIP
            // 
            this.txt_NIP.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NIP.Location = new System.Drawing.Point(60, 89);
            this.txt_NIP.MaxLength = 50;
            this.txt_NIP.Name = "txt_NIP";
            this.txt_NIP.PasswordChar = '*';
            this.txt_NIP.Size = new System.Drawing.Size(164, 22);
            this.txt_NIP.TabIndex = 108;
            this.txt_NIP.UseSystemPasswordChar = true;
            // 
            // lbl_ValeVenta
            // 
            this.lbl_ValeVenta.AutoSize = true;
            this.lbl_ValeVenta.Location = new System.Drawing.Point(57, 27);
            this.lbl_ValeVenta.Name = "lbl_ValeVenta";
            this.lbl_ValeVenta.Size = new System.Drawing.Size(81, 15);
            this.lbl_ValeVenta.TabIndex = 107;
            this.lbl_ValeVenta.Text = "Vale de venta:";
            // 
            // lbl_nip
            // 
            this.lbl_nip.AutoSize = true;
            this.lbl_nip.Location = new System.Drawing.Point(57, 70);
            this.lbl_nip.Name = "lbl_nip";
            this.lbl_nip.Size = new System.Drawing.Size(76, 15);
            this.lbl_nip.TabIndex = 106;
            this.lbl_nip.Text = "Nip de venta:";
            // 
            // gbx_DatosGenerales
            // 
            this.gbx_DatosGenerales.CausesValidation = false;
            this.gbx_DatosGenerales.Controls.Add(this.lbl_cliente);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Cliente);
            this.gbx_DatosGenerales.Controls.Add(this.txt_ClienteNombre);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Agente);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Agente);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_canal);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Canal);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_condicion);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Condicion);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_almacen);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_Almacen);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_correo);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Correo);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_correoE);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Correo2);
            this.gbx_DatosGenerales.Controls.Add(this.panel_Correo);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_TelPart);
            this.gbx_DatosGenerales.Controls.Add(this.txt_TelParticular);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_TelParticular);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_TelMovil);
            this.gbx_DatosGenerales.Controls.Add(this.txt_movil);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_TelMovil);
            this.gbx_DatosGenerales.Controls.Add(this.panel_telefonos);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Ecommerce);
            this.gbx_DatosGenerales.Controls.Add(this.txb_Ecommerce);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_FormaPago);
            this.gbx_DatosGenerales.Controls.Add(this.txt_FormaPago);
            this.gbx_DatosGenerales.Controls.Add(this.panel_ecommerce);
            this.gbx_DatosGenerales.Controls.Add(this.chk_Mayoreo);
            this.gbx_DatosGenerales.Controls.Add(this.chk_Custodia);
            this.gbx_DatosGenerales.Controls.Add(this.chk_Iva);
            this.gbx_DatosGenerales.Controls.Add(this.chk_Comentario);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_mayoreo);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_AgenteServicio);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_AgenteServicio);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_FormaEnvio);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_FormaEnvio);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Pago);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Pago);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Observaciones);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Observaciones);
            this.gbx_DatosGenerales.Controls.Add(this.btnObservacionesVM);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Comentario);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Comentario);
            this.gbx_DatosGenerales.Controls.Add(this.cbx_RedimirM);
            this.gbx_DatosGenerales.Controls.Add(this.lbl_Nomina);
            this.gbx_DatosGenerales.Controls.Add(this.txt_Nomina);
            this.gbx_DatosGenerales.Controls.Add(this.chx_Die);
            this.gbx_DatosGenerales.Controls.Add(this.chx_CodigoRecomendado);
            this.gbx_DatosGenerales.Controls.Add(this.lblCodigoRecomendado);
            this.gbx_DatosGenerales.Controls.Add(this.txt_CodigoRecomendadoDima);
            this.gbx_DatosGenerales.Controls.Add(this.panel1);
            this.gbx_DatosGenerales.Location = new System.Drawing.Point(3, 31);
            this.gbx_DatosGenerales.Name = "gbx_DatosGenerales";
            this.gbx_DatosGenerales.Size = new System.Drawing.Size(717, 439);
            this.gbx_DatosGenerales.TabIndex = 108;
            // 
            // lbl_cliente
            // 
            this.lbl_cliente.AutoSize = true;
            this.lbl_cliente.BackColor = System.Drawing.Color.White;
            this.lbl_cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cliente.Location = new System.Drawing.Point(3, 10);
            this.lbl_cliente.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_cliente.Name = "lbl_cliente";
            this.lbl_cliente.Size = new System.Drawing.Size(57, 15);
            this.lbl_cliente.TabIndex = 1;
            this.lbl_cliente.Text = "*Cliente ";
            // 
            // cbx_Cliente
            // 
            this.cbx_Cliente.BackColor = System.Drawing.Color.White;
            this.cbx_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Cliente.FormattingEnabled = true;
            this.cbx_Cliente.Location = new System.Drawing.Point(66, 3);
            this.cbx_Cliente.MaxLength = 9;
            this.cbx_Cliente.Name = "cbx_Cliente";
            this.cbx_Cliente.Size = new System.Drawing.Size(133, 21);
            this.cbx_Cliente.TabIndex = 1;
            this.cbx_Cliente.DropDown += new System.EventHandler(this.cbx_Cliente_DropDown);
            this.cbx_Cliente.SelectedIndexChanged += new System.EventHandler(this.txt_Canal_SelectedIndexChanged);
            this.cbx_Cliente.Click += new System.EventHandler(this.cbx_Cliente_Click);
            this.cbx_Cliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Cliente_KeyPress);
            this.cbx_Cliente.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_Cliente_Validating);
            // 
            // txt_ClienteNombre
            // 
            this.txt_ClienteNombre.BackColor = System.Drawing.Color.White;
            this.txt_ClienteNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_ClienteNombre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ClienteNombre.Location = new System.Drawing.Point(212, 3);
            this.txt_ClienteNombre.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.txt_ClienteNombre.Name = "txt_ClienteNombre";
            this.txt_ClienteNombre.ReadOnly = true;
            this.txt_ClienteNombre.Size = new System.Drawing.Size(293, 22);
            this.txt_ClienteNombre.TabIndex = 2;
            // 
            // lbl_Agente
            // 
            this.lbl_Agente.AutoSize = true;
            this.lbl_Agente.BackColor = System.Drawing.Color.White;
            this.lbl_Agente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Agente.Location = new System.Drawing.Point(518, 7);
            this.lbl_Agente.Margin = new System.Windows.Forms.Padding(10, 7, 3, 0);
            this.lbl_Agente.Name = "lbl_Agente";
            this.lbl_Agente.Size = new System.Drawing.Size(56, 15);
            this.lbl_Agente.TabIndex = 2;
            this.lbl_Agente.Text = "*Agente ";
            // 
            // cbx_Agente
            // 
            this.cbx_Agente.BackColor = System.Drawing.Color.White;
            this.cbx_Agente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Agente.FormattingEnabled = true;
            this.cbx_Agente.Location = new System.Drawing.Point(580, 10);
            this.cbx_Agente.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Agente.MaxLength = 8;
            this.cbx_Agente.Name = "cbx_Agente";
            this.cbx_Agente.Size = new System.Drawing.Size(115, 21);
            this.cbx_Agente.TabIndex = 3;
            this.cbx_Agente.DropDown += new System.EventHandler(this.cbx_Agente_DropDown);
            this.cbx_Agente.Click += new System.EventHandler(this.cbx_Agente_Click);
            this.cbx_Agente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Agente_KeyPress);
            this.cbx_Agente.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_Agente_Validating);
            // 
            // lbl_canal
            // 
            this.lbl_canal.AutoSize = true;
            this.lbl_canal.BackColor = System.Drawing.Color.White;
            this.lbl_canal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_canal.Location = new System.Drawing.Point(3, 44);
            this.lbl_canal.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_canal.Name = "lbl_canal";
            this.lbl_canal.Size = new System.Drawing.Size(46, 15);
            this.lbl_canal.TabIndex = 3;
            this.lbl_canal.Text = "*Canal";
            // 
            // cbx_Canal
            // 
            this.cbx_Canal.BackColor = System.Drawing.Color.White;
            this.cbx_Canal.DropDownHeight = 1;
            this.cbx_Canal.DropDownWidth = 1;
            this.cbx_Canal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Canal.FormattingEnabled = true;
            this.cbx_Canal.IntegralHeight = false;
            this.cbx_Canal.Location = new System.Drawing.Point(66, 44);
            this.cbx_Canal.Margin = new System.Windows.Forms.Padding(14, 10, 3, 3);
            this.cbx_Canal.MaxLength = 2;
            this.cbx_Canal.Name = "cbx_Canal";
            this.cbx_Canal.Size = new System.Drawing.Size(133, 21);
            this.cbx_Canal.TabIndex = 4;
            this.cbx_Canal.DropDown += new System.EventHandler(this.cbx_Canal_DropDown);
            this.cbx_Canal.SelectedIndexChanged += new System.EventHandler(this.txt_Canal_SelectedIndexChanged);
            this.cbx_Canal.Click += new System.EventHandler(this.cbx_Canal_Click);
            this.cbx_Canal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Canal_KeyPress);
            this.cbx_Canal.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_Canal_Validating);
            // 
            // lbl_condicion
            // 
            this.lbl_condicion.AutoSize = true;
            this.lbl_condicion.BackColor = System.Drawing.Color.White;
            this.lbl_condicion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_condicion.Location = new System.Drawing.Point(212, 44);
            this.lbl_condicion.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_condicion.Name = "lbl_condicion";
            this.lbl_condicion.Size = new System.Drawing.Size(69, 15);
            this.lbl_condicion.TabIndex = 11;
            this.lbl_condicion.Text = "*Condición";
            // 
            // cbx_Condicion
            // 
            this.cbx_Condicion.BackColor = System.Drawing.Color.White;
            this.cbx_Condicion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Condicion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Condicion.FormattingEnabled = true;
            this.cbx_Condicion.Location = new System.Drawing.Point(287, 44);
            this.cbx_Condicion.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Condicion.Name = "cbx_Condicion";
            this.cbx_Condicion.Size = new System.Drawing.Size(219, 21);
            this.cbx_Condicion.TabIndex = 5;
            this.cbx_Condicion.SelectedIndexChanged += new System.EventHandler(this.cbx_Condicion_SelectedIndexChanged);
            this.cbx_Condicion.Click += new System.EventHandler(this.cbx_Condicion_Click);
            this.cbx_Condicion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Condicion_KeyPress);
            // 
            // lbl_almacen
            // 
            this.lbl_almacen.AutoSize = true;
            this.lbl_almacen.BackColor = System.Drawing.Color.White;
            this.lbl_almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_almacen.Location = new System.Drawing.Point(519, 44);
            this.lbl_almacen.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_almacen.Name = "lbl_almacen";
            this.lbl_almacen.Size = new System.Drawing.Size(62, 15);
            this.lbl_almacen.TabIndex = 7;
            this.lbl_almacen.Text = "*Almacen";
            // 
            // cbx_Almacen
            // 
            this.cbx_Almacen.BackColor = System.Drawing.Color.White;
            this.cbx_Almacen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_Almacen.FormattingEnabled = true;
            this.cbx_Almacen.Location = new System.Drawing.Point(587, 44);
            this.cbx_Almacen.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_Almacen.Name = "cbx_Almacen";
            this.cbx_Almacen.Size = new System.Drawing.Size(106, 21);
            this.cbx_Almacen.TabIndex = 6;
            this.cbx_Almacen.DropDown += new System.EventHandler(this.cbx_Almacen_DropDown);
            this.cbx_Almacen.SelectedIndexChanged += new System.EventHandler(this.cbx_Almacen_SelectedIndexChanged);
            this.cbx_Almacen.Click += new System.EventHandler(this.cbx_Almacen_Click);
            this.cbx_Almacen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Almacen_KeyPress);
            this.cbx_Almacen.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_Almacen_Validating);
            // 
            // lbl_correo
            // 
            this.lbl_correo.AutoSize = true;
            this.lbl_correo.BackColor = System.Drawing.Color.White;
            this.lbl_correo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_correo.Location = new System.Drawing.Point(3, 78);
            this.lbl_correo.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_correo.Name = "lbl_correo";
            this.lbl_correo.Size = new System.Drawing.Size(118, 15);
            this.lbl_correo.TabIndex = 9;
            this.lbl_correo.Text = "*Correo Electronico";
            // 
            // txt_Correo
            // 
            this.txt_Correo.BackColor = System.Drawing.Color.White;
            this.txt_Correo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Correo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Correo.Location = new System.Drawing.Point(131, 78);
            this.txt_Correo.Margin = new System.Windows.Forms.Padding(7, 10, 3, 3);
            this.txt_Correo.Name = "txt_Correo";
            this.txt_Correo.Size = new System.Drawing.Size(171, 22);
            this.txt_Correo.TabIndex = 7;
            this.txt_Correo.Click += new System.EventHandler(this.txt_Correo_Click);
            this.txt_Correo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Correo_KeyPress);
            this.txt_Correo.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Correo_Validating);
            // 
            // lbl_correoE
            // 
            this.lbl_correoE.AutoSize = true;
            this.lbl_correoE.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_correoE.Location = new System.Drawing.Point(308, 78);
            this.lbl_correoE.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_correoE.Name = "lbl_correoE";
            this.lbl_correoE.Size = new System.Drawing.Size(19, 15);
            this.lbl_correoE.TabIndex = 61;
            this.lbl_correoE.Text = "@";
            // 
            // txt_Correo2
            // 
            this.txt_Correo2.BackColor = System.Drawing.Color.White;
            this.txt_Correo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Correo2.FormattingEnabled = true;
            this.txt_Correo2.Items.AddRange(new object[] {
            "HOTMAIL.COM",
            "LIVE.COM",
            "GMAIL.COM",
            "YAHOO.COM",
            "SINCORREO.COM"});
            this.txt_Correo2.Location = new System.Drawing.Point(333, 78);
            this.txt_Correo2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_Correo2.Name = "txt_Correo2";
            this.txt_Correo2.Size = new System.Drawing.Size(173, 21);
            this.txt_Correo2.TabIndex = 8;
            this.txt_Correo2.Click += new System.EventHandler(this.txt_Correo2_Click);
            this.txt_Correo2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Correo2_KeyPress);
            this.txt_Correo2.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Correo2_Validating);
            // 
            // panel_Correo
            // 
            this.panel_Correo.Controls.Add(this.cxb_SinCorreo);
            this.panel_Correo.Location = new System.Drawing.Point(512, 75);
            this.panel_Correo.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.panel_Correo.Name = "panel_Correo";
            this.panel_Correo.Size = new System.Drawing.Size(180, 22);
            this.panel_Correo.TabIndex = 50;
            // 
            // cxb_SinCorreo
            // 
            this.cxb_SinCorreo.AutoSize = true;
            this.cxb_SinCorreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxb_SinCorreo.Location = new System.Drawing.Point(12, 5);
            this.cxb_SinCorreo.Margin = new System.Windows.Forms.Padding(12, 5, 3, 3);
            this.cxb_SinCorreo.Name = "cxb_SinCorreo";
            this.cxb_SinCorreo.Size = new System.Drawing.Size(87, 19);
            this.cxb_SinCorreo.TabIndex = 0;
            this.cxb_SinCorreo.Text = "Sin Correo";
            this.cxb_SinCorreo.UseVisualStyleBackColor = true;
            this.cxb_SinCorreo.CheckedChanged += new System.EventHandler(this.cxb_SinCorreo_CheckedChanged);
            // 
            // lbl_TelPart
            // 
            this.lbl_TelPart.AutoSize = true;
            this.lbl_TelPart.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TelPart.Location = new System.Drawing.Point(3, 113);
            this.lbl_TelPart.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_TelPart.Name = "lbl_TelPart";
            this.lbl_TelPart.Size = new System.Drawing.Size(120, 15);
            this.lbl_TelPart.TabIndex = 43;
            this.lbl_TelPart.Text = "*Telefono Particular";
            // 
            // txt_TelParticular
            // 
            this.txt_TelParticular.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelParticular.Location = new System.Drawing.Point(129, 113);
            this.txt_TelParticular.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_TelParticular.MaxLength = 10;
            this.txt_TelParticular.Name = "txt_TelParticular";
            this.txt_TelParticular.Size = new System.Drawing.Size(121, 21);
            this.txt_TelParticular.TabIndex = 9;
            this.txt_TelParticular.Click += new System.EventHandler(this.txt_TelParticular_Click);
            this.txt_TelParticular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_TelParticular_KeyPress);
            this.txt_TelParticular.Validating += new System.ComponentModel.CancelEventHandler(this.txt_TelParticular_Validating);
            // 
            // cbx_TelParticular
            // 
            this.cbx_TelParticular.AutoSize = true;
            this.cbx_TelParticular.Location = new System.Drawing.Point(256, 116);
            this.cbx_TelParticular.Margin = new System.Windows.Forms.Padding(3, 13, 3, 3);
            this.cbx_TelParticular.Name = "cbx_TelParticular";
            this.cbx_TelParticular.Size = new System.Drawing.Size(15, 14);
            this.cbx_TelParticular.TabIndex = 65;
            this.cbx_TelParticular.UseVisualStyleBackColor = true;
            this.cbx_TelParticular.CheckedChanged += new System.EventHandler(this.cbx_TelParticular_CheckedChanged);
            // 
            // lbl_TelMovil
            // 
            this.lbl_TelMovil.AutoSize = true;
            this.lbl_TelMovil.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TelMovil.Location = new System.Drawing.Point(284, 113);
            this.lbl_TelMovil.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_TelMovil.Name = "lbl_TelMovil";
            this.lbl_TelMovil.Size = new System.Drawing.Size(92, 15);
            this.lbl_TelMovil.TabIndex = 45;
            this.lbl_TelMovil.Text = "*Telefono Movil";
            // 
            // txt_movil
            // 
            this.txt_movil.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_movil.Location = new System.Drawing.Point(389, 113);
            this.txt_movil.Margin = new System.Windows.Forms.Padding(10, 10, 3, 3);
            this.txt_movil.MaxLength = 10;
            this.txt_movil.Name = "txt_movil";
            this.txt_movil.Size = new System.Drawing.Size(127, 21);
            this.txt_movil.TabIndex = 10;
            this.txt_movil.Click += new System.EventHandler(this.txt_movil_Click);
            this.txt_movil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_movil_KeyPress);
            this.txt_movil.Leave += new System.EventHandler(this.txt_movil_Leave);
            this.txt_movil.Validating += new System.ComponentModel.CancelEventHandler(this.txt_movil_Validating);
            // 
            // cbx_TelMovil
            // 
            this.cbx_TelMovil.AutoSize = true;
            this.cbx_TelMovil.Location = new System.Drawing.Point(522, 116);
            this.cbx_TelMovil.Margin = new System.Windows.Forms.Padding(3, 13, 3, 3);
            this.cbx_TelMovil.Name = "cbx_TelMovil";
            this.cbx_TelMovil.Size = new System.Drawing.Size(15, 14);
            this.cbx_TelMovil.TabIndex = 66;
            this.cbx_TelMovil.UseVisualStyleBackColor = true;
            this.cbx_TelMovil.CheckedChanged += new System.EventHandler(this.cbx_TelMovil_CheckedChanged);
            // 
            // panel_telefonos
            // 
            this.panel_telefonos.Location = new System.Drawing.Point(543, 106);
            this.panel_telefonos.Name = "panel_telefonos";
            this.panel_telefonos.Size = new System.Drawing.Size(153, 22);
            this.panel_telefonos.TabIndex = 51;
            // 
            // lbl_Ecommerce
            // 
            this.lbl_Ecommerce.AutoSize = true;
            this.lbl_Ecommerce.BackColor = System.Drawing.Color.White;
            this.lbl_Ecommerce.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ecommerce.Location = new System.Drawing.Point(3, 147);
            this.lbl_Ecommerce.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Ecommerce.Name = "lbl_Ecommerce";
            this.lbl_Ecommerce.Size = new System.Drawing.Size(103, 15);
            this.lbl_Ecommerce.TabIndex = 55;
            this.lbl_Ecommerce.Text = "*Ped. Ecommerce";
            // 
            // txb_Ecommerce
            // 
            this.txb_Ecommerce.BackColor = System.Drawing.Color.White;
            this.txb_Ecommerce.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_Ecommerce.Location = new System.Drawing.Point(119, 147);
            this.txb_Ecommerce.Margin = new System.Windows.Forms.Padding(10, 10, 3, 3);
            this.txb_Ecommerce.MaxLength = 25;
            this.txb_Ecommerce.Name = "txb_Ecommerce";
            this.txb_Ecommerce.Size = new System.Drawing.Size(138, 22);
            this.txb_Ecommerce.TabIndex = 11;
            this.txb_Ecommerce.Click += new System.EventHandler(this.txb_Ecommerce_Click);
            this.txb_Ecommerce.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_Ecommerce_KeyPress);
            this.txb_Ecommerce.Validating += new System.ComponentModel.CancelEventHandler(this.txb_Ecommerce_Validating);
            // 
            // lbl_FormaPago
            // 
            this.lbl_FormaPago.AutoSize = true;
            this.lbl_FormaPago.BackColor = System.Drawing.Color.White;
            this.lbl_FormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FormaPago.Location = new System.Drawing.Point(263, 147);
            this.lbl_FormaPago.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_FormaPago.Name = "lbl_FormaPago";
            this.lbl_FormaPago.Size = new System.Drawing.Size(72, 15);
            this.lbl_FormaPago.TabIndex = 56;
            this.lbl_FormaPago.Text = "Forma Pago";
            // 
            // txt_FormaPago
            // 
            this.txt_FormaPago.BackColor = System.Drawing.Color.White;
            this.txt_FormaPago.Enabled = false;
            this.txt_FormaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaPago.Location = new System.Drawing.Point(339, 147);
            this.txt_FormaPago.Margin = new System.Windows.Forms.Padding(1, 10, 3, 3);
            this.txt_FormaPago.Name = "txt_FormaPago";
            this.txt_FormaPago.Size = new System.Drawing.Size(123, 22);
            this.txt_FormaPago.TabIndex = 12;
            this.txt_FormaPago.Click += new System.EventHandler(this.txt_FormaPago_Click);
            this.txt_FormaPago.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_FormaPago_KeyPress);
            // 
            // panel_ecommerce
            // 
            this.panel_ecommerce.Controls.Add(this.lbl_FormaCo);
            this.panel_ecommerce.Controls.Add(this.txt_FormaCo);
            this.panel_ecommerce.Location = new System.Drawing.Point(468, 147);
            this.panel_ecommerce.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.panel_ecommerce.Name = "panel_ecommerce";
            this.panel_ecommerce.Size = new System.Drawing.Size(235, 22);
            this.panel_ecommerce.TabIndex = 52;
            // 
            // lbl_FormaCo
            // 
            this.lbl_FormaCo.AutoSize = true;
            this.lbl_FormaCo.BackColor = System.Drawing.Color.White;
            this.lbl_FormaCo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FormaCo.Location = new System.Drawing.Point(3, 3);
            this.lbl_FormaCo.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_FormaCo.Name = "lbl_FormaCo";
            this.lbl_FormaCo.Size = new System.Drawing.Size(78, 15);
            this.lbl_FormaCo.TabIndex = 67;
            this.lbl_FormaCo.Text = "Forma Cobro";
            // 
            // txt_FormaCo
            // 
            this.txt_FormaCo.BackColor = System.Drawing.Color.White;
            this.txt_FormaCo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_FormaCo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaCo.FormattingEnabled = true;
            this.txt_FormaCo.Location = new System.Drawing.Point(87, 1);
            this.txt_FormaCo.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.txt_FormaCo.Name = "txt_FormaCo";
            this.txt_FormaCo.Size = new System.Drawing.Size(145, 21);
            this.txt_FormaCo.TabIndex = 18;
            this.txt_FormaCo.SelectedIndexChanged += new System.EventHandler(this.txt_FormaCo_SelectedIndexChanged);
            // 
            // chk_Mayoreo
            // 
            this.chk_Mayoreo.AutoSize = true;
            this.chk_Mayoreo.BackColor = System.Drawing.Color.White;
            this.chk_Mayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Mayoreo.Location = new System.Drawing.Point(3, 182);
            this.chk_Mayoreo.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.chk_Mayoreo.Name = "chk_Mayoreo";
            this.chk_Mayoreo.Size = new System.Drawing.Size(101, 19);
            this.chk_Mayoreo.TabIndex = 13;
            this.chk_Mayoreo.Text = "Com Mayoreo";
            this.chk_Mayoreo.UseVisualStyleBackColor = false;
            this.chk_Mayoreo.Click += new System.EventHandler(this.chk_Mayoreo_Click);
            // 
            // chk_Custodia
            // 
            this.chk_Custodia.AutoSize = true;
            this.chk_Custodia.BackColor = System.Drawing.Color.White;
            this.chk_Custodia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Custodia.Location = new System.Drawing.Point(152, 182);
            this.chk_Custodia.Margin = new System.Windows.Forms.Padding(45, 10, 3, 3);
            this.chk_Custodia.Name = "chk_Custodia";
            this.chk_Custodia.Size = new System.Drawing.Size(74, 19);
            this.chk_Custodia.TabIndex = 14;
            this.chk_Custodia.Text = "Custodia";
            this.chk_Custodia.UseVisualStyleBackColor = false;
            this.chk_Custodia.Click += new System.EventHandler(this.chk_Custodia_Click);
            // 
            // chk_Iva
            // 
            this.chk_Iva.AutoSize = true;
            this.chk_Iva.BackColor = System.Drawing.Color.White;
            this.chk_Iva.Enabled = false;
            this.chk_Iva.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Iva.Location = new System.Drawing.Point(274, 182);
            this.chk_Iva.Margin = new System.Windows.Forms.Padding(45, 10, 3, 3);
            this.chk_Iva.Name = "chk_Iva";
            this.chk_Iva.Size = new System.Drawing.Size(100, 19);
            this.chk_Iva.TabIndex = 15;
            this.chk_Iva.Text = "Desglosar Iva";
            this.chk_Iva.UseVisualStyleBackColor = false;
            this.chk_Iva.Click += new System.EventHandler(this.chk_Iva_Click);
            // 
            // chk_Comentario
            // 
            this.chk_Comentario.AutoSize = true;
            this.chk_Comentario.BackColor = System.Drawing.Color.White;
            this.chk_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Comentario.Location = new System.Drawing.Point(422, 182);
            this.chk_Comentario.Margin = new System.Windows.Forms.Padding(45, 10, 3, 3);
            this.chk_Comentario.Name = "chk_Comentario";
            this.chk_Comentario.Size = new System.Drawing.Size(143, 19);
            this.chk_Comentario.TabIndex = 16;
            this.chk_Comentario.Text = "Imprimir Comentario";
            this.chk_Comentario.UseVisualStyleBackColor = false;
            this.chk_Comentario.Click += new System.EventHandler(this.chk_Comentario_Click);
            // 
            // lbl_mayoreo
            // 
            this.lbl_mayoreo.AutoSize = true;
            this.lbl_mayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mayoreo.ForeColor = System.Drawing.SystemColors.Window;
            this.lbl_mayoreo.Location = new System.Drawing.Point(571, 172);
            this.lbl_mayoreo.Name = "lbl_mayoreo";
            this.lbl_mayoreo.Size = new System.Drawing.Size(125, 15);
            this.lbl_mayoreo.TabIndex = 49;
            this.lbl_mayoreo.Text = "Telefono Particularjjj";
            // 
            // lbl_AgenteServicio
            // 
            this.lbl_AgenteServicio.AutoSize = true;
            this.lbl_AgenteServicio.BackColor = System.Drawing.Color.White;
            this.lbl_AgenteServicio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AgenteServicio.Location = new System.Drawing.Point(3, 214);
            this.lbl_AgenteServicio.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_AgenteServicio.Name = "lbl_AgenteServicio";
            this.lbl_AgenteServicio.Size = new System.Drawing.Size(105, 15);
            this.lbl_AgenteServicio.TabIndex = 8;
            this.lbl_AgenteServicio.Text = "Agente Telefonico";
            // 
            // cbx_AgenteServicio
            // 
            this.cbx_AgenteServicio.BackColor = System.Drawing.Color.White;
            this.cbx_AgenteServicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_AgenteServicio.FormattingEnabled = true;
            this.cbx_AgenteServicio.Location = new System.Drawing.Point(114, 214);
            this.cbx_AgenteServicio.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_AgenteServicio.Name = "cbx_AgenteServicio";
            this.cbx_AgenteServicio.Size = new System.Drawing.Size(136, 21);
            this.cbx_AgenteServicio.TabIndex = 17;
            this.cbx_AgenteServicio.DropDown += new System.EventHandler(this.cbx_AgenteServicio_DropDown);
            this.cbx_AgenteServicio.Click += new System.EventHandler(this.cbx_AgenteServicio_Click);
            this.cbx_AgenteServicio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_AgenteServicio_KeyPress);
            this.cbx_AgenteServicio.Validating += new System.ComponentModel.CancelEventHandler(this.cbx_AgenteServicio_Validating);
            // 
            // lbl_FormaEnvio
            // 
            this.lbl_FormaEnvio.AutoSize = true;
            this.lbl_FormaEnvio.BackColor = System.Drawing.Color.White;
            this.lbl_FormaEnvio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FormaEnvio.Location = new System.Drawing.Point(263, 214);
            this.lbl_FormaEnvio.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_FormaEnvio.Name = "lbl_FormaEnvio";
            this.lbl_FormaEnvio.Size = new System.Drawing.Size(74, 15);
            this.lbl_FormaEnvio.TabIndex = 9;
            this.lbl_FormaEnvio.Text = "Forma Envio";
            // 
            // cbx_FormaEnvio
            // 
            this.cbx_FormaEnvio.BackColor = System.Drawing.Color.White;
            this.cbx_FormaEnvio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_FormaEnvio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_FormaEnvio.FormattingEnabled = true;
            this.cbx_FormaEnvio.Location = new System.Drawing.Point(343, 214);
            this.cbx_FormaEnvio.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.cbx_FormaEnvio.Name = "cbx_FormaEnvio";
            this.cbx_FormaEnvio.Size = new System.Drawing.Size(149, 21);
            this.cbx_FormaEnvio.TabIndex = 18;
            this.cbx_FormaEnvio.SelectedIndexChanged += new System.EventHandler(this.cbx_FormaEnvio_SelectedIndexChanged);
            this.cbx_FormaEnvio.Click += new System.EventHandler(this.cbx_FormaEnvio_Click);
            // 
            // lbl_Pago
            // 
            this.lbl_Pago.AutoSize = true;
            this.lbl_Pago.BackColor = System.Drawing.Color.White;
            this.lbl_Pago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pago.Location = new System.Drawing.Point(505, 214);
            this.lbl_Pago.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.lbl_Pago.Name = "lbl_Pago";
            this.lbl_Pago.Size = new System.Drawing.Size(56, 15);
            this.lbl_Pago.TabIndex = 10;
            this.lbl_Pago.Text = "Cta Pago";
            // 
            // txt_Pago
            // 
            this.txt_Pago.BackColor = System.Drawing.Color.White;
            this.txt_Pago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Pago.Location = new System.Drawing.Point(567, 214);
            this.txt_Pago.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_Pago.MaxLength = 25;
            this.txt_Pago.Name = "txt_Pago";
            this.txt_Pago.Size = new System.Drawing.Size(98, 22);
            this.txt_Pago.TabIndex = 19;
            this.txt_Pago.Click += new System.EventHandler(this.txt_Pago_Click);
            this.txt_Pago.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Pago_KeyPress);
            this.txt_Pago.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Pago_Validating);
            // 
            // lbl_Observaciones
            // 
            this.lbl_Observaciones.AutoSize = true;
            this.lbl_Observaciones.BackColor = System.Drawing.Color.White;
            this.lbl_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Observaciones.Location = new System.Drawing.Point(3, 249);
            this.lbl_Observaciones.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Observaciones.Name = "lbl_Observaciones";
            this.lbl_Observaciones.Size = new System.Drawing.Size(87, 15);
            this.lbl_Observaciones.TabIndex = 16;
            this.lbl_Observaciones.Text = "Observaciones";
            // 
            // txt_Observaciones
            // 
            this.txt_Observaciones.BackColor = System.Drawing.Color.White;
            this.txt_Observaciones.Location = new System.Drawing.Point(96, 249);
            this.txt_Observaciones.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.txt_Observaciones.MaxLength = 250;
            this.txt_Observaciones.Name = "txt_Observaciones";
            this.txt_Observaciones.Size = new System.Drawing.Size(569, 20);
            this.txt_Observaciones.TabIndex = 20;
            this.txt_Observaciones.Click += new System.EventHandler(this.txt_Observaciones_Click);
            this.txt_Observaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Observaciones_KeyPress);
            // 
            // btnObservacionesVM
            // 
            this.btnObservacionesVM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnObservacionesVM.Image = ((System.Drawing.Image)(resources.GetObject("btnObservacionesVM.Image")));
            this.btnObservacionesVM.Location = new System.Drawing.Point(669, 250);
            this.btnObservacionesVM.Margin = new System.Windows.Forms.Padding(1, 11, 3, 3);
            this.btnObservacionesVM.Name = "btnObservacionesVM";
            this.btnObservacionesVM.Size = new System.Drawing.Size(20, 20);
            this.btnObservacionesVM.TabIndex = 70;
            this.btnObservacionesVM.UseVisualStyleBackColor = true;
            this.btnObservacionesVM.Click += new System.EventHandler(this.btnObservacionesVM_Click);
            // 
            // lbl_Comentario
            // 
            this.lbl_Comentario.AutoSize = true;
            this.lbl_Comentario.BackColor = System.Drawing.Color.White;
            this.lbl_Comentario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Comentario.Location = new System.Drawing.Point(3, 283);
            this.lbl_Comentario.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lbl_Comentario.Name = "lbl_Comentario";
            this.lbl_Comentario.Size = new System.Drawing.Size(77, 15);
            this.lbl_Comentario.TabIndex = 17;
            this.lbl_Comentario.Text = "Comentarios";
            // 
            // txt_Comentario
            // 
            this.txt_Comentario.BackColor = System.Drawing.Color.White;
            this.txt_Comentario.Location = new System.Drawing.Point(95, 283);
            this.txt_Comentario.Margin = new System.Windows.Forms.Padding(12, 10, 3, 3);
            this.txt_Comentario.MaxLength = 250;
            this.txt_Comentario.Name = "txt_Comentario";
            this.txt_Comentario.Size = new System.Drawing.Size(597, 20);
            this.txt_Comentario.TabIndex = 21;
            this.txt_Comentario.Click += new System.EventHandler(this.txt_Comentario_Click);
            this.txt_Comentario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Comentario_KeyPress);
            // 
            // cbx_RedimirM
            // 
            this.cbx_RedimirM.AutoSize = true;
            this.cbx_RedimirM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_RedimirM.Location = new System.Drawing.Point(3, 311);
            this.cbx_RedimirM.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.cbx_RedimirM.Name = "cbx_RedimirM";
            this.cbx_RedimirM.Size = new System.Drawing.Size(128, 19);
            this.cbx_RedimirM.TabIndex = 22;
            this.cbx_RedimirM.Text = "Redimir Monedero";
            this.cbx_RedimirM.UseVisualStyleBackColor = true;
            this.cbx_RedimirM.CheckedChanged += new System.EventHandler(this.cbx_RedimirM_CheckedChanged);
            this.cbx_RedimirM.Click += new System.EventHandler(this.cbx_RedimirM_Click);
            // 
            // lbl_Nomina
            // 
            this.lbl_Nomina.AutoSize = true;
            this.lbl_Nomina.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nomina.Location = new System.Drawing.Point(137, 306);
            this.lbl_Nomina.Name = "lbl_Nomina";
            this.lbl_Nomina.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lbl_Nomina.Size = new System.Drawing.Size(49, 21);
            this.lbl_Nomina.TabIndex = 64;
            this.lbl_Nomina.Text = "Nomina";
            // 
            // txt_Nomina
            // 
            this.txt_Nomina.BackColor = System.Drawing.Color.White;
            this.txt_Nomina.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Nomina.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nomina.Location = new System.Drawing.Point(192, 308);
            this.txt_Nomina.Margin = new System.Windows.Forms.Padding(3, 2, 0, 3);
            this.txt_Nomina.MaxLength = 7;
            this.txt_Nomina.Name = "txt_Nomina";
            this.txt_Nomina.Size = new System.Drawing.Size(110, 22);
            this.txt_Nomina.TabIndex = 23;
            this.txt_Nomina.Click += new System.EventHandler(this.txt_Nomina_Click);
            this.txt_Nomina.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Nomina_KeyPress);
            this.txt_Nomina.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Nomina_Validating);
            // 
            // chx_Die
            // 
            this.chx_Die.AutoSize = true;
            this.chx_Die.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chx_Die.Location = new System.Drawing.Point(309, 311);
            this.chx_Die.Margin = new System.Windows.Forms.Padding(7, 5, 3, 3);
            this.chx_Die.Name = "chx_Die";
            this.chx_Die.Size = new System.Drawing.Size(126, 19);
            this.chx_Die.TabIndex = 68;
            this.chx_Die.Text = "Deposito en Banco";
            this.chx_Die.UseVisualStyleBackColor = true;
            this.chx_Die.CheckedChanged += new System.EventHandler(this.chx_Die_CheckedChanged);
            // 
            // chx_CodigoRecomendado
            // 
            this.chx_CodigoRecomendado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chx_CodigoRecomendado.Location = new System.Drawing.Point(441, 309);
            this.chx_CodigoRecomendado.Name = "chx_CodigoRecomendado";
            this.chx_CodigoRecomendado.Size = new System.Drawing.Size(142, 21);
            this.chx_CodigoRecomendado.TabIndex = 79;
            this.chx_CodigoRecomendado.Text = "Código Recomendado";
            this.chx_CodigoRecomendado.UseVisualStyleBackColor = true;
            this.chx_CodigoRecomendado.Visible = false;
            this.chx_CodigoRecomendado.CheckedChanged += new System.EventHandler(this.chx_CodigoRecomendado_CheckedChanged);
            // 
            // lblCodigoRecomendado
            // 
            this.lblCodigoRecomendado.AutoSize = true;
            this.lblCodigoRecomendado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoRecomendado.Location = new System.Drawing.Point(3, 333);
            this.lblCodigoRecomendado.Name = "lblCodigoRecomendado";
            this.lblCodigoRecomendado.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblCodigoRecomendado.Size = new System.Drawing.Size(128, 21);
            this.lblCodigoRecomendado.TabIndex = 80;
            this.lblCodigoRecomendado.Text = "Código Recomendador";
            this.lblCodigoRecomendado.Visible = false;
            // 
            // txt_CodigoRecomendadoDima
            // 
            this.txt_CodigoRecomendadoDima.Enabled = false;
            this.txt_CodigoRecomendadoDima.Location = new System.Drawing.Point(137, 336);
            this.txt_CodigoRecomendadoDima.MaxLength = 11;
            this.txt_CodigoRecomendadoDima.Name = "txt_CodigoRecomendadoDima";
            this.txt_CodigoRecomendadoDima.ReadOnly = true;
            this.txt_CodigoRecomendadoDima.Size = new System.Drawing.Size(125, 20);
            this.txt_CodigoRecomendadoDima.TabIndex = 78;
            this.txt_CodigoRecomendadoDima.Visible = false;
            this.txt_CodigoRecomendadoDima.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_CodigoRecomendadoDima_KeyUp);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkTransferencia);
            this.panel1.Controls.Add(this.lblBanco);
            this.panel1.Controls.Add(this.txtBanco);
            this.panel1.Controls.Add(this.lblCuentaClabe);
            this.panel1.Controls.Add(this.txtCuentaClabe);
            this.panel1.Location = new System.Drawing.Point(3, 362);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(692, 42);
            this.panel1.TabIndex = 81;
            // 
            // chkTransferencia
            // 
            this.chkTransferencia.AutoSize = true;
            this.chkTransferencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.chkTransferencia.Location = new System.Drawing.Point(4, 4);
            this.chkTransferencia.Name = "chkTransferencia";
            this.chkTransferencia.Size = new System.Drawing.Size(156, 19);
            this.chkTransferencia.TabIndex = 86;
            this.chkTransferencia.Text = "Transferencia Bancaria";
            this.chkTransferencia.UseVisualStyleBackColor = true;
            this.chkTransferencia.Visible = false;
            this.chkTransferencia.CheckedChanged += new System.EventHandler(this.chkTransferencia_CheckedChanged);
            // 
            // lblBanco
            // 
            this.lblBanco.AutoSize = true;
            this.lblBanco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanco.Location = new System.Drawing.Point(166, -1);
            this.lblBanco.Name = "lblBanco";
            this.lblBanco.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblBanco.Size = new System.Drawing.Size(41, 21);
            this.lblBanco.TabIndex = 88;
            this.lblBanco.Text = "Banco";
            this.lblBanco.Visible = false;
            // 
            // txtBanco
            // 
            this.txtBanco.BackColor = System.Drawing.Color.White;
            this.txtBanco.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBanco.Enabled = false;
            this.txtBanco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBanco.Location = new System.Drawing.Point(213, 0);
            this.txtBanco.Margin = new System.Windows.Forms.Padding(3, 2, 0, 3);
            this.txtBanco.MaxLength = 7;
            this.txtBanco.Name = "txtBanco";
            this.txtBanco.Size = new System.Drawing.Size(110, 22);
            this.txtBanco.TabIndex = 87;
            this.txtBanco.Visible = false;
            // 
            // lblCuentaClabe
            // 
            this.lblCuentaClabe.AutoSize = true;
            this.lblCuentaClabe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuentaClabe.Location = new System.Drawing.Point(335, -2);
            this.lblCuentaClabe.Name = "lblCuentaClabe";
            this.lblCuentaClabe.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblCuentaClabe.Size = new System.Drawing.Size(129, 21);
            this.lblCuentaClabe.TabIndex = 90;
            this.lblCuentaClabe.Text = "Cuenta Clabe / Tarjeta";
            this.lblCuentaClabe.Visible = false;
            // 
            // txtCuentaClabe
            // 
            this.txtCuentaClabe.BackColor = System.Drawing.Color.White;
            this.txtCuentaClabe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCuentaClabe.Enabled = false;
            this.txtCuentaClabe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaClabe.Location = new System.Drawing.Point(477, 1);
            this.txtCuentaClabe.Margin = new System.Windows.Forms.Padding(3, 2, 0, 3);
            this.txtCuentaClabe.MaxLength = 20;
            this.txtCuentaClabe.Name = "txtCuentaClabe";
            this.txtCuentaClabe.Size = new System.Drawing.Size(204, 22);
            this.txtCuentaClabe.TabIndex = 89;
            this.txtCuentaClabe.Visible = false;
            // 
            // lbl_MonederoARedimir
            // 
            this.lbl_MonederoARedimir.Location = new System.Drawing.Point(0, 0);
            this.lbl_MonederoARedimir.Name = "lbl_MonederoARedimir";
            this.lbl_MonederoARedimir.Size = new System.Drawing.Size(100, 23);
            this.lbl_MonederoARedimir.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lbl_Alerta);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(717, 22);
            this.flowLayoutPanel1.TabIndex = 52;
            // 
            // lbl_Alerta
            // 
            this.lbl_Alerta.AutoSize = true;
            this.lbl_Alerta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Alerta.ForeColor = System.Drawing.Color.Maroon;
            this.lbl_Alerta.Location = new System.Drawing.Point(3, 5);
            this.lbl_Alerta.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.lbl_Alerta.Name = "lbl_Alerta";
            this.lbl_Alerta.Size = new System.Drawing.Size(40, 15);
            this.lbl_Alerta.TabIndex = 0;
            this.lbl_Alerta.Text = "label7";
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.CausesValidation = false;
            this.panelContactos.Controls.Add(this.flowLayoutPanel1);
            this.panelContactos.Controls.Add(this.gbx_DatosGenerales);
            this.panelContactos.Controls.Add(this.panel_Detalle);
            this.panelContactos.Controls.Add(this.gbx_VentaDetalle);
            this.panelContactos.Controls.Add(this.pnlBtn_DatosEntrega);
            this.panelContactos.Controls.Add(this.gbx_DatosEntrega);
            this.panelContactos.Controls.Add(this.btn_Anticipo);
            this.panelContactos.Controls.Add(this.gbx_Anticipo);
            this.panelContactos.Controls.Add(this.btn_Afectar);
            this.panelContactos.Controls.Add(this.btn_situaciones);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(109, 56);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(942, 1733);
            this.panelContactos.TabIndex = 101;
            // 
            // panel_Detalle
            // 
            this.panel_Detalle.Controls.Add(this.btn_MostrarAbonos);
            this.panel_Detalle.Controls.Add(this.panelMontoVale);
            this.panel_Detalle.Controls.Add(this.btnImportExcel);
            this.panel_Detalle.Controls.Add(this.txt_DetalleInformacion);
            this.panel_Detalle.Controls.Add(this.BtnAdd);
            this.panel_Detalle.Controls.Add(this.btn_Detalle);
            this.panel_Detalle.Location = new System.Drawing.Point(3, 476);
            this.panel_Detalle.Name = "panel_Detalle";
            this.panel_Detalle.Size = new System.Drawing.Size(936, 83);
            this.panel_Detalle.TabIndex = 109;
            // 
            // btn_MostrarAbonos
            // 
            this.btn_MostrarAbonos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_MostrarAbonos.BackColor = System.Drawing.Color.White;
            this.btn_MostrarAbonos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_MostrarAbonos.FlatAppearance.BorderSize = 0;
            this.btn_MostrarAbonos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MostrarAbonos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MostrarAbonos.Image = ((System.Drawing.Image)(resources.GetObject("btn_MostrarAbonos.Image")));
            this.btn_MostrarAbonos.Location = new System.Drawing.Point(827, 29);
            this.btn_MostrarAbonos.Name = "btn_MostrarAbonos";
            this.btn_MostrarAbonos.Size = new System.Drawing.Size(108, 51);
            this.btn_MostrarAbonos.TabIndex = 109;
            this.btn_MostrarAbonos.Text = "Mostrar Abonos";
            this.btn_MostrarAbonos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_MostrarAbonos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_MostrarAbonos.UseVisualStyleBackColor = false;
            this.btn_MostrarAbonos.Visible = false;
            this.btn_MostrarAbonos.Click += new System.EventHandler(this.btn_MostrarAbonos_Click);
            // 
            // panelMontoVale
            // 
            this.panelMontoVale.Controls.Add(this.lb_montovale);
            this.panelMontoVale.Controls.Add(this.label8);
            this.panelMontoVale.Location = new System.Drawing.Point(694, 9);
            this.panelMontoVale.Name = "panelMontoVale";
            this.panelMontoVale.Size = new System.Drawing.Size(157, 20);
            this.panelMontoVale.TabIndex = 108;
            this.panelMontoVale.Visible = false;
            // 
            // lb_montovale
            // 
            this.lb_montovale.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_montovale.AutoSize = true;
            this.lb_montovale.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lb_montovale.Location = new System.Drawing.Point(73, 3);
            this.lb_montovale.Name = "lb_montovale";
            this.lb_montovale.Size = new System.Drawing.Size(38, 15);
            this.lb_montovale.TabIndex = 108;
            this.lb_montovale.Text = "$0.00";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(3, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 15);
            this.label8.TabIndex = 107;
            this.label8.Text = "Monto Vale:";
            // 
            // btnImportExcel
            // 
            this.btnImportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnImportExcel.BackColor = System.Drawing.Color.White;
            this.btnImportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImportExcel.FlatAppearance.BorderSize = 0;
            this.btnImportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportExcel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnImportExcel.Image")));
            this.btnImportExcel.Location = new System.Drawing.Point(541, 29);
            this.btnImportExcel.Name = "btnImportExcel";
            this.btnImportExcel.Size = new System.Drawing.Size(155, 51);
            this.btnImportExcel.TabIndex = 106;
            this.btnImportExcel.Text = "Importar de Excel";
            this.btnImportExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImportExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnImportExcel.UseVisualStyleBackColor = false;
            this.btnImportExcel.Click += new System.EventHandler(this.btnImportExcel_Click);
            // 
            // txt_DetalleInformacion
            // 
            this.txt_DetalleInformacion.BackColor = System.Drawing.Color.White;
            this.txt_DetalleInformacion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_DetalleInformacion.Enabled = false;
            this.txt_DetalleInformacion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DetalleInformacion.Location = new System.Drawing.Point(110, 3);
            this.txt_DetalleInformacion.Multiline = true;
            this.txt_DetalleInformacion.Name = "txt_DetalleInformacion";
            this.txt_DetalleInformacion.Size = new System.Drawing.Size(425, 68);
            this.txt_DetalleInformacion.TabIndex = 105;
            // 
            // BtnAdd
            // 
            this.BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnAdd.BackColor = System.Drawing.Color.White;
            this.BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAdd.FlatAppearance.BorderSize = 0;
            this.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAdd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.Image = ((System.Drawing.Image)(resources.GetObject("BtnAdd.Image")));
            this.BtnAdd.Location = new System.Drawing.Point(702, 29);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(120, 51);
            this.BtnAdd.TabIndex = 99;
            this.BtnAdd.Text = "Agregar";
            this.BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // btn_Detalle
            // 
            this.btn_Detalle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Detalle.BackColor = System.Drawing.Color.White;
            this.btn_Detalle.FlatAppearance.BorderSize = 0;
            this.btn_Detalle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Detalle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Detalle.Image = ((System.Drawing.Image)(resources.GetObject("btn_Detalle.Image")));
            this.btn_Detalle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Detalle.Location = new System.Drawing.Point(3, 29);
            this.btn_Detalle.Name = "btn_Detalle";
            this.btn_Detalle.Size = new System.Drawing.Size(96, 51);
            this.btn_Detalle.TabIndex = 98;
            this.btn_Detalle.Text = "Detalle";
            this.btn_Detalle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Detalle.UseVisualStyleBackColor = false;
            // 
            // pnlBtn_DatosEntrega
            // 
            this.pnlBtn_DatosEntrega.Controls.Add(this.chkDomicilioCliente);
            this.pnlBtn_DatosEntrega.Controls.Add(this.btn_DatosEntrega);
            this.pnlBtn_DatosEntrega.Controls.Add(this.txt_ComentariosDatosEntrega);
            this.pnlBtn_DatosEntrega.Location = new System.Drawing.Point(3, 999);
            this.pnlBtn_DatosEntrega.Name = "pnlBtn_DatosEntrega";
            this.pnlBtn_DatosEntrega.Size = new System.Drawing.Size(786, 66);
            this.pnlBtn_DatosEntrega.TabIndex = 110;
            // 
            // chkDomicilioCliente
            // 
            this.chkDomicilioCliente.AutoSize = true;
            this.chkDomicilioCliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.chkDomicilioCliente.Location = new System.Drawing.Point(178, 30);
            this.chkDomicilioCliente.Name = "chkDomicilioCliente";
            this.chkDomicilioCliente.Size = new System.Drawing.Size(182, 19);
            this.chkDomicilioCliente.TabIndex = 122;
            this.chkDomicilioCliente.Text = "Domicilio Actual Del Cliente";
            this.chkDomicilioCliente.UseVisualStyleBackColor = true;
            this.chkDomicilioCliente.Visible = false;
            this.chkDomicilioCliente.CheckedChanged += new System.EventHandler(this.chkDomicilioCliente_CheckedChanged);
            // 
            // btn_DatosEntrega
            // 
            this.btn_DatosEntrega.BackColor = System.Drawing.Color.White;
            this.btn_DatosEntrega.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_DatosEntrega.FlatAppearance.BorderSize = 0;
            this.btn_DatosEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DatosEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatosEntrega.Image = ((System.Drawing.Image)(resources.GetObject("btn_DatosEntrega.Image")));
            this.btn_DatosEntrega.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DatosEntrega.Location = new System.Drawing.Point(3, 17);
            this.btn_DatosEntrega.Margin = new System.Windows.Forms.Padding(9, 11, 3, 3);
            this.btn_DatosEntrega.Name = "btn_DatosEntrega";
            this.btn_DatosEntrega.Size = new System.Drawing.Size(158, 43);
            this.btn_DatosEntrega.TabIndex = 102;
            this.btn_DatosEntrega.Text = "Datos de Entrega";
            this.btn_DatosEntrega.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DatosEntrega.UseVisualStyleBackColor = false;
            this.btn_DatosEntrega.Click += new System.EventHandler(this.DatosEntregaClick);
            // 
            // txt_ComentariosDatosEntrega
            // 
            this.txt_ComentariosDatosEntrega.BackColor = System.Drawing.Color.White;
            this.txt_ComentariosDatosEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentariosDatosEntrega.Enabled = false;
            this.txt_ComentariosDatosEntrega.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ComentariosDatosEntrega.Location = new System.Drawing.Point(184, 17);
            this.txt_ComentariosDatosEntrega.Multiline = true;
            this.txt_ComentariosDatosEntrega.Name = "txt_ComentariosDatosEntrega";
            this.txt_ComentariosDatosEntrega.Size = new System.Drawing.Size(586, 43);
            this.txt_ComentariosDatosEntrega.TabIndex = 106;
            // 
            // gbx_DatosEntrega
            // 
            this.gbx_DatosEntrega.Controls.Add(this.gb_CamposEntrega);
            this.gbx_DatosEntrega.Controls.Add(this.btn_nuevaEntrega);
            this.gbx_DatosEntrega.Controls.Add(this.btn_guardar);
            this.gbx_DatosEntrega.Controls.Add(this.dgv_datosEntrega);
            this.gbx_DatosEntrega.Location = new System.Drawing.Point(3, 1071);
            this.gbx_DatosEntrega.Name = "gbx_DatosEntrega";
            this.gbx_DatosEntrega.Size = new System.Drawing.Size(923, 357);
            this.gbx_DatosEntrega.TabIndex = 111;
            this.gbx_DatosEntrega.TabStop = false;
            this.gbx_DatosEntrega.Visible = false;
            // 
            // gb_CamposEntrega
            // 
            this.gb_CamposEntrega.Controls.Add(this.txt_NumI);
            this.gb_CamposEntrega.Controls.Add(this.label1);
            this.gb_CamposEntrega.Controls.Add(this.txt_NumE);
            this.gb_CamposEntrega.Controls.Add(this.label7);
            this.gb_CamposEntrega.Controls.Add(this.cb_colonia);
            this.gb_CamposEntrega.Controls.Add(this.txt_MovilEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_TelParticularEntrega);
            this.gb_CamposEntrega.Controls.Add(this.label5);
            this.gb_CamposEntrega.Controls.Add(this.label4);
            this.gb_CamposEntrega.Controls.Add(this.txt_EntreCallesEntrega);
            this.gb_CamposEntrega.Controls.Add(this.label33);
            this.gb_CamposEntrega.Controls.Add(this.lbl_poblacion);
            this.gb_CamposEntrega.Controls.Add(this.lbl_colonia);
            this.gb_CamposEntrega.Controls.Add(this.label2);
            this.gb_CamposEntrega.Controls.Add(this.lbl_direccion);
            this.gb_CamposEntrega.Controls.Add(this.label3);
            this.gb_CamposEntrega.Controls.Add(this.label6);
            this.gb_CamposEntrega.Controls.Add(this.txt_EstadoEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_PoblacionEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_CPEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_ReferenciaEntrega);
            this.gb_CamposEntrega.Controls.Add(this.txt_direccionEntrega);
            this.gb_CamposEntrega.Location = new System.Drawing.Point(7, 148);
            this.gb_CamposEntrega.Name = "gb_CamposEntrega";
            this.gb_CamposEntrega.Size = new System.Drawing.Size(763, 201);
            this.gb_CamposEntrega.TabIndex = 108;
            this.gb_CamposEntrega.TabStop = false;
            // 
            // txt_NumI
            // 
            this.txt_NumI.BackColor = System.Drawing.Color.White;
            this.txt_NumI.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumI.Location = new System.Drawing.Point(700, 21);
            this.txt_NumI.MaxLength = 5;
            this.txt_NumI.Name = "txt_NumI";
            this.txt_NumI.Size = new System.Drawing.Size(55, 22);
            this.txt_NumI.TabIndex = 146;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(648, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 15);
            this.label1.TabIndex = 145;
            this.label1.Text = "NumInt";
            // 
            // txt_NumE
            // 
            this.txt_NumE.BackColor = System.Drawing.Color.White;
            this.txt_NumE.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumE.Location = new System.Drawing.Point(580, 21);
            this.txt_NumE.MaxLength = 5;
            this.txt_NumE.Name = "txt_NumE";
            this.txt_NumE.Size = new System.Drawing.Size(56, 22);
            this.txt_NumE.TabIndex = 144;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(519, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 15);
            this.label7.TabIndex = 143;
            this.label7.Text = "*NumExt";
            // 
            // cb_colonia
            // 
            this.cb_colonia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cb_colonia.FormattingEnabled = true;
            this.cb_colonia.Location = new System.Drawing.Point(129, 49);
            this.cb_colonia.Name = "cb_colonia";
            this.cb_colonia.Size = new System.Drawing.Size(268, 21);
            this.cb_colonia.TabIndex = 110;
            this.cb_colonia.Click += new System.EventHandler(this.cb_colonia_Click);
            this.cb_colonia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cb_colonia_KeyPress);
            // 
            // txt_MovilEntrega
            // 
            this.txt_MovilEntrega.BackColor = System.Drawing.Color.White;
            this.txt_MovilEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MovilEntrega.Location = new System.Drawing.Point(514, 135);
            this.txt_MovilEntrega.MaxLength = 10;
            this.txt_MovilEntrega.Name = "txt_MovilEntrega";
            this.txt_MovilEntrega.Size = new System.Drawing.Size(234, 22);
            this.txt_MovilEntrega.TabIndex = 116;
            this.txt_MovilEntrega.Click += new System.EventHandler(this.txt_MovilEntrega_Click);
            this.txt_MovilEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_MovilEntrega_KeyPress);
            // 
            // txt_TelParticularEntrega
            // 
            this.txt_TelParticularEntrega.BackColor = System.Drawing.Color.White;
            this.txt_TelParticularEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelParticularEntrega.Location = new System.Drawing.Point(129, 135);
            this.txt_TelParticularEntrega.MaxLength = 10;
            this.txt_TelParticularEntrega.Name = "txt_TelParticularEntrega";
            this.txt_TelParticularEntrega.Size = new System.Drawing.Size(268, 22);
            this.txt_TelParticularEntrega.TabIndex = 115;
            this.txt_TelParticularEntrega.Click += new System.EventHandler(this.txt_TelParticularEntrega_Click);
            this.txt_TelParticularEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_TelParticularEntrega_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(416, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 15);
            this.label5.TabIndex = 125;
            this.label5.Text = "*Telefono Movil";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 15);
            this.label4.TabIndex = 124;
            this.label4.Text = "*Telefono Particular";
            // 
            // txt_EntreCallesEntrega
            // 
            this.txt_EntreCallesEntrega.BackColor = System.Drawing.Color.White;
            this.txt_EntreCallesEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EntreCallesEntrega.Location = new System.Drawing.Point(129, 104);
            this.txt_EntreCallesEntrega.MaxLength = 100;
            this.txt_EntreCallesEntrega.Name = "txt_EntreCallesEntrega";
            this.txt_EntreCallesEntrega.Size = new System.Drawing.Size(619, 22);
            this.txt_EntreCallesEntrega.TabIndex = 114;
            this.txt_EntreCallesEntrega.Click += new System.EventHandler(this.txt_EntreCallesEntrega_Click);
            this.txt_EntreCallesEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EntreCallesEntrega_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(9, 172);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 15);
            this.label33.TabIndex = 123;
            this.label33.Text = "Referencia";
            // 
            // lbl_poblacion
            // 
            this.lbl_poblacion.AutoSize = true;
            this.lbl_poblacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_poblacion.Location = new System.Drawing.Point(8, 83);
            this.lbl_poblacion.Name = "lbl_poblacion";
            this.lbl_poblacion.Size = new System.Drawing.Size(67, 15);
            this.lbl_poblacion.TabIndex = 122;
            this.lbl_poblacion.Text = "*Poblacion";
            // 
            // lbl_colonia
            // 
            this.lbl_colonia.AutoSize = true;
            this.lbl_colonia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_colonia.Location = new System.Drawing.Point(12, 52);
            this.lbl_colonia.Name = "lbl_colonia";
            this.lbl_colonia.Size = new System.Drawing.Size(56, 15);
            this.lbl_colonia.TabIndex = 121;
            this.lbl_colonia.Text = "*Colonia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Azure;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(473, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 120;
            this.label2.Text = "*CP";
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(9, 25);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(68, 15);
            this.lbl_direccion.TabIndex = 119;
            this.lbl_direccion.Text = "*Direccion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Azure;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(460, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 118;
            this.label3.Text = "*Estado";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 117;
            this.label6.Text = "Entre Calles";
            // 
            // txt_EstadoEntrega
            // 
            this.txt_EstadoEntrega.BackColor = System.Drawing.Color.White;
            this.txt_EstadoEntrega.Enabled = false;
            this.txt_EstadoEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EstadoEntrega.Location = new System.Drawing.Point(515, 76);
            this.txt_EstadoEntrega.MaxLength = 30;
            this.txt_EstadoEntrega.Name = "txt_EstadoEntrega";
            this.txt_EstadoEntrega.Size = new System.Drawing.Size(233, 22);
            this.txt_EstadoEntrega.TabIndex = 113;
            this.txt_EstadoEntrega.Click += new System.EventHandler(this.txt_EstadoEntrega_Click);
            // 
            // txt_PoblacionEntrega
            // 
            this.txt_PoblacionEntrega.BackColor = System.Drawing.Color.White;
            this.txt_PoblacionEntrega.Enabled = false;
            this.txt_PoblacionEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PoblacionEntrega.Location = new System.Drawing.Point(129, 76);
            this.txt_PoblacionEntrega.MaxLength = 50;
            this.txt_PoblacionEntrega.Name = "txt_PoblacionEntrega";
            this.txt_PoblacionEntrega.Size = new System.Drawing.Size(268, 22);
            this.txt_PoblacionEntrega.TabIndex = 112;
            this.txt_PoblacionEntrega.Click += new System.EventHandler(this.txt_PoblacionEntrega_Click);
            // 
            // txt_CPEntrega
            // 
            this.txt_CPEntrega.BackColor = System.Drawing.Color.White;
            this.txt_CPEntrega.Enabled = false;
            this.txt_CPEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CPEntrega.Location = new System.Drawing.Point(515, 50);
            this.txt_CPEntrega.MaxLength = 5;
            this.txt_CPEntrega.Name = "txt_CPEntrega";
            this.txt_CPEntrega.Size = new System.Drawing.Size(147, 22);
            this.txt_CPEntrega.TabIndex = 111;
            this.txt_CPEntrega.Click += new System.EventHandler(this.txt_CPEntrega_Click);
            // 
            // txt_ReferenciaEntrega
            // 
            this.txt_ReferenciaEntrega.BackColor = System.Drawing.Color.White;
            this.txt_ReferenciaEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ReferenciaEntrega.Location = new System.Drawing.Point(129, 169);
            this.txt_ReferenciaEntrega.MaxLength = 50;
            this.txt_ReferenciaEntrega.Name = "txt_ReferenciaEntrega";
            this.txt_ReferenciaEntrega.Size = new System.Drawing.Size(619, 22);
            this.txt_ReferenciaEntrega.TabIndex = 117;
            this.txt_ReferenciaEntrega.Click += new System.EventHandler(this.txt_ReferenciaEntrega_Click);
            this.txt_ReferenciaEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ReferenciaEntrega_KeyPress);
            // 
            // txt_direccionEntrega
            // 
            this.txt_direccionEntrega.BackColor = System.Drawing.Color.White;
            this.txt_direccionEntrega.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccionEntrega.Location = new System.Drawing.Point(129, 21);
            this.txt_direccionEntrega.MaxLength = 100;
            this.txt_direccionEntrega.Name = "txt_direccionEntrega";
            this.txt_direccionEntrega.Size = new System.Drawing.Size(380, 22);
            this.txt_direccionEntrega.TabIndex = 109;
            this.txt_direccionEntrega.Click += new System.EventHandler(this.txt_direccionEntrega_Click);
            this.txt_direccionEntrega.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_direccionEntrega_KeyPress);
            // 
            // btn_nuevaEntrega
            // 
            this.btn_nuevaEntrega.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_nuevaEntrega.FlatAppearance.BorderSize = 0;
            this.btn_nuevaEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nuevaEntrega.Image = ((System.Drawing.Image)(resources.GetObject("btn_nuevaEntrega.Image")));
            this.btn_nuevaEntrega.Location = new System.Drawing.Point(694, 12);
            this.btn_nuevaEntrega.Name = "btn_nuevaEntrega";
            this.btn_nuevaEntrega.Size = new System.Drawing.Size(81, 56);
            this.btn_nuevaEntrega.TabIndex = 107;
            this.btn_nuevaEntrega.Text = "Nuevo";
            this.btn_nuevaEntrega.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_nuevaEntrega.UseVisualStyleBackColor = true;
            this.btn_nuevaEntrega.Click += new System.EventHandler(this.btn_nuevaEntrega_Click);
            // 
            // btn_guardar
            // 
            this.btn_guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_guardar.FlatAppearance.BorderSize = 0;
            this.btn_guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_guardar.Image = ((System.Drawing.Image)(resources.GetObject("btn_guardar.Image")));
            this.btn_guardar.Location = new System.Drawing.Point(695, 78);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(80, 56);
            this.btn_guardar.TabIndex = 103;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // dgv_datosEntrega
            // 
            this.dgv_datosEntrega.AllowUserToAddRows = false;
            this.dgv_datosEntrega.AllowUserToDeleteRows = false;
            this.dgv_datosEntrega.AllowUserToResizeColumns = false;
            this.dgv_datosEntrega.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_datosEntrega.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_datosEntrega.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_datosEntrega.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_datosEntrega.BackgroundColor = System.Drawing.Color.White;
            this.dgv_datosEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_datosEntrega.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_datosEntrega.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_datosEntrega.EnableHeadersVisualStyles = false;
            this.dgv_datosEntrega.Location = new System.Drawing.Point(10, 15);
            this.dgv_datosEntrega.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.dgv_datosEntrega.MultiSelect = false;
            this.dgv_datosEntrega.Name = "dgv_datosEntrega";
            this.dgv_datosEntrega.ReadOnly = true;
            this.dgv_datosEntrega.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_datosEntrega.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_datosEntrega.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_datosEntrega.Size = new System.Drawing.Size(629, 127);
            this.dgv_datosEntrega.TabIndex = 102;
            this.dgv_datosEntrega.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_datosEntrega_CellClick);
            this.dgv_datosEntrega.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_datosEntrega_CellContentClick);
            this.dgv_datosEntrega.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_datosEntrega_ColumnHeaderMouseClick);
            // 
            // btn_Anticipo
            // 
            this.btn_Anticipo.BackColor = System.Drawing.Color.White;
            this.btn_Anticipo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Anticipo.FlatAppearance.BorderSize = 0;
            this.btn_Anticipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Anticipo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Anticipo.Image = ((System.Drawing.Image)(resources.GetObject("btn_Anticipo.Image")));
            this.btn_Anticipo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Anticipo.Location = new System.Drawing.Point(7, 1434);
            this.btn_Anticipo.Margin = new System.Windows.Forms.Padding(7, 3, 3, 3);
            this.btn_Anticipo.Name = "btn_Anticipo";
            this.btn_Anticipo.Size = new System.Drawing.Size(101, 40);
            this.btn_Anticipo.TabIndex = 104;
            this.btn_Anticipo.Text = "Anticipo";
            this.btn_Anticipo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Anticipo.UseVisualStyleBackColor = false;
            this.btn_Anticipo.Click += new System.EventHandler(this.btn_Anticipo_Click);
            // 
            // btn_Afectar
            // 
            this.btn_Afectar.BackColor = System.Drawing.Color.White;
            this.btn_Afectar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Afectar.FlatAppearance.BorderSize = 0;
            this.btn_Afectar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Afectar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Afectar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Afectar.Image")));
            this.btn_Afectar.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_Afectar.Location = new System.Drawing.Point(3, 1633);
            this.btn_Afectar.Name = "btn_Afectar";
            this.btn_Afectar.Size = new System.Drawing.Size(213, 43);
            this.btn_Afectar.TabIndex = 107;
            this.btn_Afectar.Text = "Generar Movimiento (Crtl+F)";
            this.btn_Afectar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Afectar.UseVisualStyleBackColor = false;
            this.btn_Afectar.Click += new System.EventHandler(this.btn_Afectar_Click);
            // 
            // btn_situaciones
            // 
            this.btn_situaciones.BackColor = System.Drawing.Color.White;
            this.btn_situaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_situaciones.FlatAppearance.BorderSize = 0;
            this.btn_situaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_situaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_situaciones.Image = ((System.Drawing.Image)(resources.GetObject("btn_situaciones.Image")));
            this.btn_situaciones.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_situaciones.Location = new System.Drawing.Point(3, 1682);
            this.btn_situaciones.Name = "btn_situaciones";
            this.btn_situaciones.Size = new System.Drawing.Size(123, 48);
            this.btn_situaciones.TabIndex = 112;
            this.btn_situaciones.Text = "Situaciones";
            this.btn_situaciones.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_situaciones.UseVisualStyleBackColor = false;
            this.btn_situaciones.Visible = false;
            this.btn_situaciones.Click += new System.EventHandler(this.btn_situaciones_Click);
            // 
            // Panel_UsuarioEstatus
            // 
            this.Panel_UsuarioEstatus.Controls.Add(this.textBox1);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_Usuario);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_Estatus);
            this.Panel_UsuarioEstatus.Controls.Add(this.lbl_ID);
            this.Panel_UsuarioEstatus.Location = new System.Drawing.Point(814, 1);
            this.Panel_UsuarioEstatus.Name = "Panel_UsuarioEstatus";
            this.Panel_UsuarioEstatus.Size = new System.Drawing.Size(391, 49);
            this.Panel_UsuarioEstatus.TabIndex = 105;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(382, 20);
            this.textBox1.TabIndex = 114;
            this.textBox1.Text = "LOS CAMPOS CON * ES OBLIGATORIO LA CAPTURA DE DATOS";
            // 
            // flp_promociones
            // 
            this.flp_promociones.Controls.Add(this.pictureBox1);
            this.flp_promociones.Controls.Add(this.lbl_Promo);
            this.flp_promociones.Controls.Add(this.pictureBox2);
            this.flp_promociones.Controls.Add(this.pictureBox3);
            this.flp_promociones.Controls.Add(this.pictureBox6);
            this.flp_promociones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flp_promociones.Location = new System.Drawing.Point(1057, 73);
            this.flp_promociones.Name = "flp_promociones";
            this.flp_promociones.Size = new System.Drawing.Size(129, 399);
            this.flp_promociones.TabIndex = 106;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 87);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lbl_Promo
            // 
            this.lbl_Promo.AutoSize = true;
            this.lbl_Promo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Promo.Location = new System.Drawing.Point(3, 93);
            this.lbl_Promo.Name = "lbl_Promo";
            this.lbl_Promo.Size = new System.Drawing.Size(119, 16);
            this.lbl_Promo.TabIndex = 107;
            this.lbl_Promo.Text = "PROMOCIONES";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(3, 112);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(119, 87);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(3, 205);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(119, 87);
            this.pictureBox3.TabIndex = 106;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(3, 298);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(119, 87);
            this.pictureBox6.TabIndex = 107;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(118, 1);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(686, 49);
            this.txt_Comentarios.TabIndex = 104;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(6, -11);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(94, 67);
            this.pictureBox7.TabIndex = 116;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(12, -14);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(88, 70);
            this.pictureBox5.TabIndex = 115;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(0, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(112, 60);
            this.pictureBox4.TabIndex = 114;
            this.pictureBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button1.Location = new System.Drawing.Point(110, 32767);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 46);
            this.button1.TabIndex = 108;
            this.button1.Text = "Guardar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // PuntoDeVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1216, 643);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.flp_promociones);
            this.Controls.Add(this.Panel_UsuarioEstatus);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.panelContactos);
            this.Controls.Add(this.gbx_menuPuntoVenta);
            this.Controls.Add(this.txt_ComentarioAyuda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "PuntoDeVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PuntoDeVenta";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PuntoDeVenta_FormClosing);
            this.Load += new System.EventHandler(this.PuntoDeVenta_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.PuntoDeVenta_Scroll);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PuntoDeVenta_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).EndInit();
            this.MenuVentaDetalle.ResumeLayout(false);
            this.gbx_menuPuntoVenta.ResumeLayout(false);
            this.cxm_CopiarID.ResumeLayout(false);
            this.gbx_Anticipo.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbx_VentaDetalle.ResumeLayout(false);
            this.gbx_VentaDetalle.PerformLayout();
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.gbx_VentaDima.ResumeLayout(false);
            this.gbx_VentaD.ResumeLayout(false);
            this.gbx_VentaD.PerformLayout();
            this.gbx_DatosGenerales.ResumeLayout(false);
            this.gbx_DatosGenerales.PerformLayout();
            this.panel_Correo.ResumeLayout(false);
            this.panel_Correo.PerformLayout();
            this.panel_ecommerce.ResumeLayout(false);
            this.panel_ecommerce.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panelContactos.ResumeLayout(false);
            this.panel_Detalle.ResumeLayout(false);
            this.panel_Detalle.PerformLayout();
            this.panelMontoVale.ResumeLayout(false);
            this.panelMontoVale.PerformLayout();
            this.pnlBtn_DatosEntrega.ResumeLayout(false);
            this.pnlBtn_DatosEntrega.PerformLayout();
            this.gbx_DatosEntrega.ResumeLayout(false);
            this.gb_CamposEntrega.ResumeLayout(false);
            this.gb_CamposEntrega.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datosEntrega)).EndInit();
            this.Panel_UsuarioEstatus.ResumeLayout(false);
            this.Panel_UsuarioEstatus.PerformLayout();
            this.flp_promociones.ResumeLayout(false);
            this.flp_promociones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Label lbl_MonederoARedimir;

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Button btn_InformacionCliente;
        private System.Windows.Forms.Button btn_eventosNotasCitA;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.FlowLayoutPanel gbx_menuPuntoVenta;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lbl_Estatus;
        private System.Windows.Forms.Button btn_CampoExtra;
        private System.Windows.Forms.Button btn_Afectar;
        private System.Windows.Forms.FlowLayoutPanel gbx_Anticipo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_agregarFormaPago;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txt_anticipototal;
        private System.Windows.Forms.Button btn_Anticipo;
        private System.Windows.Forms.Button btn_DatosEntrega;
        private System.Windows.Forms.FlowLayoutPanel gbx_VentaDetalle;
        private System.Windows.Forms.Label lblUnidad;
        private System.Windows.Forms.Label lblDescr;
        private System.Windows.Forms.DataGridView dvg_detalleVenta;
        private System.Windows.Forms.FlowLayoutPanel gbx_DatosGenerales;
        private System.Windows.Forms.Label lbl_cliente;
        private System.Windows.Forms.ComboBox cbx_Cliente;
        private System.Windows.Forms.TextBox txt_ClienteNombre;
        private System.Windows.Forms.Label lbl_Agente;
        private System.Windows.Forms.ComboBox cbx_Agente;
        private System.Windows.Forms.Label lbl_canal;
        private System.Windows.Forms.ComboBox cbx_Canal;
        private System.Windows.Forms.Label lbl_condicion;
        private System.Windows.Forms.ComboBox cbx_Condicion;
        private System.Windows.Forms.Label lbl_almacen;
        private System.Windows.Forms.ComboBox cbx_Almacen;
        private System.Windows.Forms.Label lbl_correo;
        private System.Windows.Forms.TextBox txt_Correo;
        private System.Windows.Forms.FlowLayoutPanel panel_Correo;
        private System.Windows.Forms.Label lbl_TelPart;
        private System.Windows.Forms.TextBox txt_TelParticular;
        private System.Windows.Forms.Label lbl_TelMovil;
        private System.Windows.Forms.TextBox txt_movil;
        private System.Windows.Forms.FlowLayoutPanel panel_telefonos;
        private System.Windows.Forms.Label lbl_Ecommerce;
        private System.Windows.Forms.TextBox txb_Ecommerce;
        private System.Windows.Forms.Label lbl_FormaPago;
        private System.Windows.Forms.TextBox txt_FormaPago;
        private System.Windows.Forms.FlowLayoutPanel panel_ecommerce;
        private System.Windows.Forms.CheckBox chk_Mayoreo;
        private System.Windows.Forms.CheckBox chk_Custodia;
        private System.Windows.Forms.CheckBox chk_Iva;
        private System.Windows.Forms.CheckBox chk_Comentario;
        private System.Windows.Forms.Label lbl_mayoreo;
        private System.Windows.Forms.Label lbl_AgenteServicio;
        private System.Windows.Forms.ComboBox cbx_AgenteServicio;
        private System.Windows.Forms.Label lbl_FormaEnvio;
        private System.Windows.Forms.ComboBox cbx_FormaEnvio;
        private System.Windows.Forms.Label lbl_Pago;
        private System.Windows.Forms.TextBox txt_Pago;
        private System.Windows.Forms.Label lbl_Observaciones;
        private System.Windows.Forms.TextBox txt_Observaciones;
        private System.Windows.Forms.Label lbl_Comentario;
        private System.Windows.Forms.TextBox txt_Comentario;
        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        private System.Windows.Forms.Panel panel_Detalle;
        private System.Windows.Forms.Button btn_Detalle;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Label lbl_correoE;
        private System.Windows.Forms.ComboBox txt_Correo2;
        private System.Windows.Forms.CheckBox cbx_RedimirM;
        private System.Windows.Forms.ContextMenuStrip cxm_CopiarID;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.Panel pnlBtn_DatosEntrega;
        private System.Windows.Forms.GroupBox gbx_DatosEntrega;
        private System.Windows.Forms.GroupBox gb_CamposEntrega;
        private System.Windows.Forms.ComboBox cb_colonia;
        private System.Windows.Forms.TextBox txt_MovilEntrega;
        private System.Windows.Forms.TextBox txt_TelParticularEntrega;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_EntreCallesEntrega;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lbl_poblacion;
        private System.Windows.Forms.Label lbl_colonia;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_EstadoEntrega;
        private System.Windows.Forms.TextBox txt_PoblacionEntrega;
        private System.Windows.Forms.TextBox txt_CPEntrega;
        private System.Windows.Forms.TextBox txt_ReferenciaEntrega;
        private System.Windows.Forms.TextBox txt_direccionEntrega;
        private System.Windows.Forms.Button btn_nuevaEntrega;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.DataGridView dgv_datosEntrega;
        private System.Windows.Forms.Label lbl_Nomina;
        private System.Windows.Forms.TextBox txt_Nomina;
        private System.Windows.Forms.TextBox txt_DetalleInformacion;
        private System.Windows.Forms.TextBox txt_ComentariosDatosEntrega;
        private System.Windows.Forms.FlowLayoutPanel Panel_UsuarioEstatus;
        private System.Windows.Forms.ContextMenuStrip MenuVentaDetalle;
        private System.Windows.Forms.ToolStripMenuItem UsrIncremento;
        private System.Windows.Forms.ToolStripMenuItem UsrDescuento;
        private System.Windows.Forms.ToolStripMenuItem agregarGarantiasToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel flp_FormaPago;
        private System.Windows.Forms.Label lbl_importeTotal;
        private System.Windows.Forms.Button btn_situaciones;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.FlowLayoutPanel flp_promociones;
        private System.Windows.Forms.Label lbl_Promo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnImportExcel;
        private System.Windows.Forms.Label lbl_cambio;
        private System.Windows.Forms.Label lbl_rec_ceros;
        private System.Windows.Forms.TextBox Tb_efectivoRecibido;
        private System.Windows.Forms.Label lbl_recibido;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btn_InfoArt;
        private System.Windows.Forms.CheckBox cxb_SinCorreo;
        private System.Windows.Forms.Button btn_Selp;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lbl_Alerta;
        private System.Windows.Forms.CheckBox cbx_TelParticular;
        private System.Windows.Forms.CheckBox cbx_TelMovil;
        private System.Windows.Forms.Label lbl_FormaCo;
        private System.Windows.Forms.ComboBox txt_FormaCo;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox txt_NumI;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_NumE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chx_Die;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelMontoVale;
        private System.Windows.Forms.Label lb_montovale;
        private System.Windows.Forms.CheckBox chkDomicilioCliente;
        private System.Windows.Forms.Button btnObservacionesVM;
        private System.Windows.Forms.CheckBox chx_CodigoRecomendado;
        private System.Windows.Forms.Label lblCodigoRecomendado;
        private System.Windows.Forms.TextBox txt_CodigoRecomendadoDima;
        private System.Windows.Forms.Label lbl_subT;
        private System.Windows.Forms.Label lbl_Impuestos;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.FlowLayoutPanel gbx_VentaDima;
        private System.Windows.Forms.GroupBox gbx_VentaD;
        private System.Windows.Forms.TextBox txt_vale;
        private System.Windows.Forms.TextBox txt_NIP;
        private System.Windows.Forms.Label lbl_ValeVenta;
        private System.Windows.Forms.Label lbl_nip;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lblMonedero;
        private System.Windows.Forms.TextBox txtMonedero;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.TextBox txtImpuestos;
        private System.Windows.Forms.Button btn_MostrarAbonos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkTransferencia;
        private System.Windows.Forms.Label lblCuentaClabe;
        private System.Windows.Forms.TextBox txtCuentaClabe;
        private System.Windows.Forms.Label lblBanco;
        private System.Windows.Forms.TextBox txtBanco;
        private System.Windows.Forms.Button btnCuentaClabe;
    }
}