﻿using System;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta
{
    public partial class TiempoTotal : Form
    {
        private DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public string recibeCliente;
        public int recibeId;
        public string recibeMovimiento;
        private readonly DM0312_C_TiempoTotal TiempoTota = new DM0312_C_TiempoTotal();

        public TiempoTotal()
        {
            InitializeComponent();
        }

        ~TiempoTotal()
        {
            GC.Collect();
        }

        private void btn_regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void TiempoTotal_Load(object sender, EventArgs e)
        {
            lbl_Cliente.Text = recibeCliente;
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            DatosTiempoTotal();
            txt_Comentarios.Text = "MUESTRA EL TIEMPO TOTAL TRANSCURRIDO DE LA VENTA";

            if (ClaseEstatica.Usuario.color == "Azul")
                dvg_TiempoTotal.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dvg_TiempoTotal.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dvg_TiempoTotal.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dvg_TiempoTotal.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        public async void DatosTiempoTotal()
        {
            try
            {
                frmLoading = new DM0312_Loading_();
                frmLoading.Show(this);
                //DesabilitarControles(false);
                btn_Regresar.Enabled = false;
                btn_ayuda.Enabled = false;
                DataTable dataSet = new DataTable();
                dataSet = await Task.Run(() => TiempoTota.DatosTiempoTotal(recibeMovimiento, recibeId));

                frmLoading.Hide();
                //DesabilitarControles(true);
                btn_Regresar.Enabled = true;
                btn_ayuda.Enabled = true;
                dvg_TiempoTotal.DataSource = null;
                dataSet.Columns["MOV"].ColumnName = "Movimiento";
                dataSet.Columns["MovID"].ColumnName = "IDMovimiento";
                dataSet.Columns["TIEMPO"].ColumnName = "FechaOrigen";
                dvg_TiempoTotal.DataSource = dataSet;
            }
            catch (Exception e)
            {
                DM0312_ErrorLog.RegistraError("DatosTiempoTotal", "DM0312_TiempoTotal", e);
                MessageBox.Show(e.Message);
            }
        }


        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void TiempoTotal_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        private void TiempoTotal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }
    }
}