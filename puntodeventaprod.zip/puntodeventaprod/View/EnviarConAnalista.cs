﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class EnviarConAnalista : Form
    {
        public EnviarConAnalista(DM0312_MExploradorVenta Venta)
        {
            InitializeComponent();
            ventaM = Venta;
        }

        ~EnviarConAnalista()
        {
            GC.Collect();
        }

        private void EnviarConAnalista_Load(object Sender, EventArgs e)
        {
            InitializeComponentValues();
        }

        #region atributos

        private static readonly EventoController EventoC = new EventoController();
        private static readonly sqlHelper sqlH = new sqlHelper();
        private static DM0312_MExploradorVenta ventaM = new DM0312_MExploradorVenta();

        private readonly DM0312_C_ExploradorVenta CE = new DM0312_C_ExploradorVenta();

        private class cbValue
        {
            public string Value { get; set; }
            public string Index { get; set; }
        }

        #endregion

        #region Triggers

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            guardar();
            Dispose();
            Close();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            cerrarVentana();
        }

        private void EnviarConAnalista_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) cerrarVentana();

            if (e.Control && e.KeyCode == Keys.G) guardar();
        }

        #endregion


        #region Methods

        private void guardar()
        {
            if (EventoC.InsertaEvento(getModeloEventoNuevo()))
                MessageBox.Show("Analista Asignado Correctamente", "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
        }

        private ModelAgregaEvento getModeloEventoNuevo()
        {
            ModelAgregaEvento eventoNuevo = new ModelAgregaEvento();
            try
            {
                eventoNuevo.agente = ventaM.Agente;
                eventoNuevo.clave = "MEN05326";
                eventoNuevo.modulo = "VTAS";
                eventoNuevo.idVenta = ventaM.ID;

                eventoNuevo.fecha = sqlH.getFechaActualServidor().ToString("yyyy/MM/dd HH:mm");
                cbValue analista = (cbValue)cbx_Analista.SelectedItem;

                eventoNuevo.evento = analista.Index;
                eventoNuevo.sucursal = ClaseEstatica.iSucural;
                eventoNuevo.usuario = ClaseEstatica.Usuario.usuario;
                eventoNuevo.tipo = "COMENTARIO";
                eventoNuevo.estuatus = ventaM.Estatus;
                eventoNuevo.situacion = ventaM.Situacion;
                eventoNuevo.citaCliente = 0;
                eventoNuevo.citaaval = 0;
                eventoNuevo.citaFecha = sqlH.getFechaActualServidor();
                eventoNuevo.citaHora = " ";
                eventoNuevo.TipoEvento = "EVENTO";
                eventoNuevo.mov = ventaM.Mov;
                eventoNuevo.cliente = ventaM.Cliente;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }

            return eventoNuevo;
        }

        private void cerrarVentana()
        {
            if (MessageBox.Show(
                    "Se perderan los avances asunto vacio¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Dispose();
                Close();
            }
        }

        private void InitializeComponentValues()
        {
            cbx_AnalistaFill();

            lbl_Movimiento.Text = "Movimiento: " + ventaM.MovId + " " + ventaM.Mov;
            lbl_Mov.Text = ventaM.Mov;
            lbl_Cliente.Text = ventaM.Cliente + " - " + ventaM.Nombre;
        }

        private void cbx_AnalistaFill()
        {
            List<cbValue> CBValues = new List<cbValue>();
            List<AnalistaCreditoModel> analistList = CE.listaAnalistas();

            analistList.ForEach(delegate(AnalistaCreditoModel analista)
            {
                CBValues.Add(new cbValue { Index = analista.usuario, Value = analista.analista });
            });

            cbx_Analista.DataSource = CBValues;
            cbx_Analista.DisplayMember = "Value";
            cbx_Analista.ValueMember = "Index";
        }

        #endregion
    }
}