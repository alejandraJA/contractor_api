﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_VentaEntrada : Form
    {
        public static DM0312_DevolucionAdj dev = new DM0312_DevolucionAdj();
        public static DM0312_Adjudicaciones adj = new DM0312_Adjudicaciones();
        public static DM0312_CVentanaEntrada controlador;
        public static List<DM0312_MVentanaEntrada> listaModelo = new List<DM0312_MVentanaEntrada>();
        public static List<string> datosValera = new List<string>();
        public static List<string> datosMov = new List<string>();
        public static List<DM0312_MPuntoDeVentaCliente> listaEmpleados = new List<DM0312_MPuntoDeVentaCliente>();
        public static DM0312_CPuntoDeVenta controladorP = new DM0312_CPuntoDeVenta();
        public static DM0312_C_ExploradorVenta controladorE = new DM0312_C_ExploradorVenta();

        //-TarjetaDepartamental
        private bool bBusquedaTarjeta;
        private int Canal, Est, Suc, Uen;

        //-ValidacionTelefonoNip
        private readonly CDetalleVenta controladorD = new CDetalleVenta();
        private readonly DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
        public string enviaMensajeBoton;
        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        private readonly Funciones funciones = new Funciones();
        public List<string> ListaControles;

        //-CerradoIntelisis
        private readonly DM0312_C_Login loginC = new DM0312_C_Login();
        public string recibeMensaje;
        private MValeDigital valeDigitalDatos = new MValeDigital();
        public string validaMensaje, Cte, Categoria, Emp, Usuario, estatus;

        public DM0312_VentaEntrada()
        {
            InitializeComponent();
            controlador = new DM0312_CVentanaEntrada();

            ListaControles = new List<string>();
        }

        ~DM0312_VentaEntrada()
        {
            GC.Collect();
        }

        private void VentanaEntrada_Load(object sender, EventArgs e)
        {
            //EjecutaClientes();
            cbx_PublicoG.Visible = false;
            gbx_Valera.Visible = false;
            btn_SolValera.Visible = false;
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR");
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            toolTip1.SetToolTip(btn_Venta, "SELECCIONAR PARA REALIZAR UNA VENTA");
            toolTip1.SetToolTip(btn_Devolucion,
                "SELECCIONAR PARA REALIZAR UNA DEVOLUCION DE VENTA, SE TIENE QUE TENER EL MOV Y MOVID DEL MOVIMIENTO A DEVOLVER");
            toolTip1.SetToolTip(btn_Adjudicacion,
                "SELECCIONAR PARA REALIZAR UNA ADJUDICACION, SE TIENE QUE TENER EL MOV Y MOVID DEL MOVIMIENTO A ADJUDICAR ");
            toolTip1.SetToolTip(label1, "MOVIMIENTO");
            toolTip1.SetToolTip(txt_Mov, "SELECCIONAR EL MOVIMIENTO QUE SE VA A DEVOLVER O ADJUDICAR");
            toolTip1.SetToolTip(label2, "MOVID");
            toolTip1.SetToolTip(txt_MovId, "INGRESAR EL MOVID DEL MOVIMIENTO A DEVOLVER O ADJUDICAR");
            toolTip1.SetToolTip(btn_IrVenta,
                "SELECCIONAR UNA VEZ SE TENGA EL MOVMIENTO Y MOVID A DEVOLVER O ADJUDICAR");
            toolTip1.SetToolTip(btn_Contado, "SELECCIONAR PARA REALIZAR UNA VENTA DE CONTADO");
            toolTip1.SetToolTip(btn_Dima, "SELECCIONAR PARA REALIZAR UNA VENTA A UN CLIENTE DIMA");
            toolTip1.SetToolTip(btn_Credito, "SELECCIONAR PARA REALIZAR UNA VENTA DE CREDITO");
            toolTip1.SetToolTip(btn_Instituciones, "SELECCIONAR PARA REALIZAR UNA VENTA DE EMPLEADO");
            toolTip1.SetToolTip(btn_Mayoreo, "SELECCIONAR PARA REALIZAR UNA VENTA DE MAYOREO");
            toolTip1.SetToolTip(btn_SolValera, "SELECCIONAR PARA GENERAR UNA SOLICITUD DE VALERA");
            toolTip1.SetToolTip(cbx_PublicoG,
                "SELECCIONAR SI SE QUIERE HACER UNA VENTA DE CONTADO Y CON UNA CUENTA GENERICA");
            toolTip1.SetToolTip(txt_Valera, "SELECCIONAR LA CUENTA DE VALERA QUE SE QUIERE GENERAR");
            toolTip1.SetToolTip(txt_cuenta, "AGREGAR EL NUMERO DE CUENTA DEL CLIENTE AL QUE SE LE VA A VENDER");
            toolTip1.SetToolTip(txtNombre,
                "AGREGAR EL NOMBRE DEL CLIENTE AL QUE SE LE VA A VENDER, COMENZANDO POR APELLIDOS");
            toolTip1.SetToolTip(txtDireccion,
                "AGREGAR LA DIRECCION DEL CLIENTE A BUSCAR, PUEDE INGRESAR TANTO COLONIA COMO NUMERO EXTERIOR");
            toolTip1.SetToolTip(txtTelefono, "AGREGAR EL TELEFONO COMPLETO DEL CLIENTE CON TODO Y LADA");
            toolTip1.SetToolTip(btnBuscar, "SELECCIONAR PARA HACER LA BUSQUEDA DEL CLIENTE");
            toolTip1.SetToolTip(txt_CodigoPostal, "AGREGAR EL CODIGO POSTAL DEL CLIENTE A BUSCAR");
            toolTip1.SetToolTip(btn_Ir, "SELECCIONAR PARA DAR DE ALTA UN CLIENTE NUEVO");

            estatus = "SINAFECTAR";
            /////////////////////////////////////////////VALIDACION DE ACCESOS POR USUARIO //////////////////////////////////////////////////
            gbx_AdjMov.Visible = false;
            btn_Contado.Visible = false;
            btn_Dima.Visible = false;
            btn_Instituciones.Visible = false;
            btn_Mayoreo.Visible = false;
            panel_TipoVenta.Visible = false;
            gbx_explorador.Visible = false;
            dgv_VentanaEntrada.Visible = false;
            panel_Buscador.Visible = false;
            btn_Ir.Visible = false;
            txt_TituloEntrada.Text = "Selecciona el tipo de movimiento que se desea realizar";
            Size = new Size(960, 270);
            if (controlador.AccesoVenta(ClaseEstatica.Usuario.usuario, 1) == "SI")
                btn_Venta.Visible = true;
            else
                btn_Venta.Visible = false;

            if (controlador.AccesoVenta(ClaseEstatica.Usuario.usuario, 2) == "SI")
                btn_Devolucion.Visible = true;
            else
                btn_Devolucion.Visible = false;

            if (controlador.AccesoVenta(ClaseEstatica.Usuario.usuario, 3) == "SI")
                btn_Adjudicacion.Visible = true;
            else
                btn_Adjudicacion.Visible = false;
            MovimientosIniciar();
            Text = "Venta Entrada SPID:" + ClaseEstatica.SPID;

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_VentanaEntrada.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_VentanaEntrada.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_VentanaEntrada.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_VentanaEntrada.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-DataLogic
            btnRecarga.Visible = false;
            btnPagoServicio.Visible = false;

            //Permisos por sucursal
            if (controlador.AccesoDatalogic())
            {
                btnPagoServicio.Visible = true;
                btnRecarga.Visible = true;
            }

            btnPromocionesVencidas.Visible = false;

            if (controlador.botonDimaForaneo()) btnDimaForaneo.Visible = true;
        }

        private void btn_IrVenta_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_Mov.Text == "" && txt_MovId.Text == "")
                {
                    MessageBox.Show("Debe ingresar el Movimiento y su ID correspondiente", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_Mov.Text == "")
                {
                    MessageBox.Show("Debe ingresar un Movimiento", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else if (txt_MovId.Text == "")
                {
                    MessageBox.Show("Debe ingresar el ID correspondiente a la " + txt_Mov.Text, "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MovId.Text = "";
                }
                else
                {
                    string movID = txt_MovId.Text;
                    string Resultado = "";
                    string ResultadoRef = "";
                    string ResultadoRefAdj = "";
                    string mov = txt_Mov.Text;
                    string referencia = mov + " " + movID;
                    Resultado = DevolucionMov.ValidarAdjudicacionMov(mov, movID);
                    ResultadoRef = DevolucionMov.ValidarReferenciaDev(mov, movID, 1);
                    ResultadoRefAdj = DevolucionMov.ValidarReferenciaAdj(referencia);

                    if (Resultado == "NO" || Resultado == "")
                    {
                        MessageBox.Show("El MovID es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        txt_MovId.Text = "";
                    }
                    else
                    {
                        if (enviaMensajeBoton == "Devolucion")
                        {
                            if (ResultadoRef == "NO")
                            {
                                //-CandadoEmbarque
                                if (mov == "Factura" || mov == "Factura VIU" || mov == "Factura Mayoreo" ||
                                    mov == "Sol Dev Mayoreo")
                                {
                                    DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
                                    string[] sDatosEmbarque = DevolucionMov.validarEstatusEmbarque(movID).Split('|');
                                    if (sDatosEmbarque.Length > 0)
                                        if (sDatosEmbarque[0] == "SINAFECTAR" || sDatosEmbarque[0] == "PENDIENTE")
                                        {
                                            MessageBox.Show(
                                                "La factura se encuentra en el embarque ID:" + sDatosEmbarque[1] +
                                                ", en estatus sin afectar o pendiente, no se puede realizar la cancelación",
                                                "Precaucion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            return;
                                        }
                                }

                                dev = new DM0312_DevolucionAdj();
                                dev.mensajeBoton = enviaMensajeBoton;
                                dev.ValidaEstatus = estatus;
                                dev.Mov = mov;
                                dev.MovID = movID;
                                Visible = false;
                                dev.ShowDialog();
                                if (!dev.CerrarVenta)
                                {
                                    Visible = true;
                                    StartPosition = FormStartPosition.CenterScreen;
                                }
                                else
                                {
                                    Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show(
                                    "La " + mov + " " + movID + " no puede ser devuelta por que ya tiene devoluciones",
                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                txt_MovId.Text = "";
                            }
                        }
                        else if (enviaMensajeBoton == "Adjudicacion")
                        {
                            string resultadod;
                            resultadod = DevolucionMov.ValidarAdjudicacionMovD(mov, movID);
                            if (resultadod == "NO")
                            {
                                MessageBox.Show("El MovID es incorrecto, No se puede adjudicar facturas de contado",
                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                txt_MovId.Text = "";
                            }
                            else
                            {
                                if (ResultadoRefAdj == "NO")
                                {
                                    adj = new DM0312_Adjudicaciones();
                                    adj.mensajeBoton = enviaMensajeBoton;
                                    adj.ValidaEstatus = estatus;
                                    adj.Mov = mov;
                                    adj.MovID = movID;
                                    Visible = false;
                                    adj.ShowDialog();
                                    if (!adj.CerrarVenta)
                                    {
                                        Visible = true;
                                        StartPosition = FormStartPosition.CenterScreen;
                                    }
                                    else
                                    {
                                        Close();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(
                                        "La " + mov + " " + movID +
                                        " no puede ser Adjudicada por que ya tiene procesos en tramite", "Advertencia",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    txt_MovId.Text = "";
                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("btn_IrVenta", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Mayoreo_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            gbx_Valera.Visible = false;
            btn_Ir.Text = "Cliente Nuevo Mayoreo";
            btn_Ir.Visible = true;
            enviaMensajeBoton = "Mayoreo";
            StartPosition = FormStartPosition.CenterScreen;
            txt_TituloEntrada.Text =
                "Ingresa el cliente a buscar en caso de no existir selecciona el boton Venta Nueva Mayoreo ";
            dgv_VentanaEntrada.DataSource = null;
            gbx_explorador.Visible = true;
            btn_Mayoreo.Location = new Point(195, 3);
            Size = new Size(960, 445);
            panel_TipoVenta.Size = new Size(95, 88);
            //this.Location = new Point(233, 100);
            Location = new Point(Location.X, 100);

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.LightBlue;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_Mayoreo.Enabled = false;
            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario
            Canal = 11;
            txt_cuenta.Focus();
            txt_cuenta.Select();
        }

        private void dgv_VentanaEntrada_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
                Cte = dgv_VentanaEntrada.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
            else
                Cte = "";
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void txt_MovId_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txt_Mov.Text == "" && txt_MovId.Text == "")
                {
                    MessageBox.Show("Debe ingresar el Movimiento y su ID correspondiente", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_Mov.Text == "")
                {
                    MessageBox.Show("Debe ingresar un Movimiento", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else if (txt_MovId.Text == "")
                {
                    MessageBox.Show("Debe ingresar el ID correspondiente a la " + txt_Mov.Text, "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_MovId.Text = "";
                }
                else
                {
                    string movID = txt_MovId.Text;
                    string Resultado = "";
                    string ResultadoRef = "";
                    string ResultadoRefAdj = "";
                    string mov = txt_Mov.Text;
                    string referencia = mov + " " + movID;
                    Resultado = DevolucionMov.ValidarAdjudicacionMov(mov, movID);
                    ResultadoRef = DevolucionMov.ValidarReferenciaDev(mov, movID, 1);
                    ResultadoRefAdj = DevolucionMov.ValidarReferenciaAdj(referencia);

                    if (Resultado == "NO" || Resultado == "")
                    {
                        MessageBox.Show("El MovID es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        txt_MovId.Text = "";
                    }
                    else
                    {
                        if (enviaMensajeBoton == "Devolucion")
                        {
                            if (ResultadoRef == "NO")
                            {
                                //-CandadoEmbarque
                                if (mov == "Factura" || mov == "Factura VIU" || mov == "Factura Mayoreo" ||
                                    mov == "Sol Dev Mayoreo")
                                {
                                    DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
                                    string[] sDatosEmbarque = DevolucionMov.validarEstatusEmbarque(movID).Split('|');
                                    if (sDatosEmbarque.Length > 0)
                                        if (sDatosEmbarque[0] == "SINAFECTAR" || sDatosEmbarque[0] == "PENDIENTE")
                                        {
                                            MessageBox.Show(
                                                "La factura se encuentra en el embarque ID:" + sDatosEmbarque[1] +
                                                ", en estatus sin afectar o pendiente, no se puede realizar la cancelación",
                                                "Precaucion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            return;
                                        }
                                }

                                dev = new DM0312_DevolucionAdj();
                                dev.mensajeBoton = enviaMensajeBoton;
                                dev.ValidaEstatus = estatus;
                                dev.Mov = mov;
                                dev.MovID = movID;
                                Visible = false;
                                dev.ShowDialog();
                                if (!dev.CerrarVenta)
                                {
                                    Visible = true;
                                    StartPosition = FormStartPosition.CenterScreen;
                                }
                                else
                                {
                                    Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show(
                                    "La " + mov + " " + movID + " no puede ser devuelta por que ya tiene devoluciones",
                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                txt_MovId.Text = "";
                            }
                        }
                        else if (enviaMensajeBoton == "Adjudicacion")
                        {
                            string resultadod;
                            resultadod = DevolucionMov.ValidarAdjudicacionMovD(mov, movID);
                            if (resultadod == "NO")
                            {
                                MessageBox.Show("El MovID es incorrecto, No se puede adjudicar facturas de contado",
                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                txt_MovId.Text = "";
                            }
                            else
                            {
                                if (ResultadoRefAdj == "NO")
                                {
                                    adj = new DM0312_Adjudicaciones();
                                    adj.mensajeBoton = enviaMensajeBoton;
                                    adj.ValidaEstatus = estatus;
                                    adj.Mov = mov;
                                    adj.MovID = movID;
                                    Visible = false;
                                    adj.ShowDialog();
                                    if (!adj.CerrarVenta)
                                    {
                                        Visible = true;
                                        StartPosition = FormStartPosition.CenterScreen;
                                    }
                                    else
                                    {
                                        Close();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(
                                        "La " + mov + " " + movID +
                                        " no puede ser Adjudicada por que ya tiene procesos en tramite", "Advertencia",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    txt_MovId.Text = "";
                                }
                            }
                        }
                    }
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private async void txt_cuenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
                if (e.KeyChar == Convert.ToChar(Keys.Enter))
                {
                    //-CerradoIntelisis
                    loginC.checkSession();

                    if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" ||
                        txt_cuenta.Text != "" || txt_CodigoPostal.Text != "")
                    {
                        frmLoading.Show(this);
                        DesabilitarControles(false);
                        await Task.Run(() => Consultar());
                        frmLoading.Hide();
                        DesabilitarControles(true);
                        MostrarInf();
                        int cont = 0;
                        string rfcC = "";
                        if (listaModelo.Count == 1)
                            if (txt_cuenta.Text != "")
                            {
                                Cte = txt_cuenta.Text;

                                if (enviaMensajeBoton == "Valera")
                                {
                                    //-IntervencionDima
                                    if (!IntervencionDima(Cte)) return;

                                    rfcC = controlador.ValidarRFC(Cte);
                                    string beneficiarioF = "";
                                    string nombre = controlador.NombreCliente(Cte);
                                    beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);
                                    if (Cte.Contains("C"))
                                    {
                                        if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                        {
                                            if (beneficiarioF != "NO")
                                            {
                                                if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                                {
                                                    MessageBox.Show(
                                                        "Es beneficiario final con saldo activo " + beneficiarioF,
                                                        "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Information);
                                                    return;
                                                }

                                                string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                                if (dias != "NO")
                                                {
                                                    int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                    if (Convert.ToInt32(dias) < diasV)
                                                    {
                                                        MessageBox.Show(
                                                            "Es beneficiario final con saldo activo " + beneficiarioF,
                                                            "Advertencia", MessageBoxButtons.OK,
                                                            MessageBoxIcon.Information);
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            string personal = controlador.ValidarRFCPersonal(rfcC);
                                            if (personal != "NO")
                                            {
                                                if (rfcC == "")
                                                    MessageBox.Show(
                                                        "El cliente " + Cte +
                                                        " no cuenta con RFC comunicate con credito", "Advertencia",
                                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                else
                                                    MessageBox.Show(
                                                        "El empleado " + personal +
                                                        " es activo no puede realizar movimientos de canal 76",
                                                        "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Information);
                                                return;
                                            }
                                        }
                                    }

                                    DM0312_SolicitudValera SolValera = new DM0312_SolicitudValera(Cte, 76);
                                    SolValera.Canal = 76;
                                    SolValera.mensajeBoton = enviaMensajeBoton;
                                    SolValera.ValidaEstatus = estatus;
                                    SolValera.valera = txt_Valera.Text;

                                    Visible = false;
                                    SolValera.ShowDialog();
                                    if (!SolValera.CerrarVenta)
                                    {
                                        Visible = true;
                                        StartPosition = FormStartPosition.CenterScreen;
                                    }
                                    else
                                    {
                                        Close();
                                    }
                                }
                                else
                                {
                                    if (enviaMensajeBoton == "Contado")
                                        if (controladorP.ClienteConP(Cte))
                                        {
                                            CambioClet();
                                            cont = 1;
                                        }

                                    if (enviaMensajeBoton == "Credito")
                                    {
                                        rfcC = controlador.ValidarRFC(Cte);
                                        string beneficiarioF = "";
                                        string nombre = controlador.NombreCliente(Cte);
                                        beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);
                                        if (Cte.Contains("C"))
                                        {
                                            if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                            {
                                                if (beneficiarioF != "NO")
                                                {
                                                    if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                                    {
                                                        MessageBox.Show(
                                                            "Es beneficiario final con saldo activo " + beneficiarioF,
                                                            "Advertencia", MessageBoxButtons.OK,
                                                            MessageBoxIcon.Information);
                                                        return;
                                                    }

                                                    string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                                    if (dias != "NO")
                                                    {
                                                        int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                        if (Convert.ToInt32(dias) < diasV)
                                                        {
                                                            MessageBox.Show(
                                                                "Es beneficiario final con saldo activo " +
                                                                beneficiarioF, "Advertencia", MessageBoxButtons.OK,
                                                                MessageBoxIcon.Information);
                                                            return;
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                string personal = controlador.ValidarRFCPersonal(rfcC);
                                                if (personal != "NO")
                                                {
                                                    if (rfcC == "")
                                                        MessageBox.Show(
                                                            "El cliente " + Cte +
                                                            " no cuenta con RFC comunicate con credito", "Advertencia",
                                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    else
                                                        MessageBox.Show(
                                                            "El empleado " + personal +
                                                            " es activo no puede realizar movimientos de credito",
                                                            "Advertencia", MessageBoxButtons.OK,
                                                            MessageBoxIcon.Information);
                                                    return;
                                                }
                                            }
                                        }

                                        if (!CandadoEdad(Cte)) return;

                                        string tipoS = controlador.TipoSuc();
                                        int diasUltimaCompra = 0;
                                        if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                                        {
                                            int diasVencidos = 0;
                                            //if (controlador.SaldoP(Cte) == "SI")
                                            /*GESSY 1182 */
                                            if (controlador.validaDocumentosPendientes(Cte) == "SI")
                                            {
                                                MessageBox.Show(
                                                    "No puede realizar ventas en esta sucursal, Cliente: " + Cte +
                                                    " con saldo pendiente", "Advertencia", MessageBoxButtons.OK,
                                                    MessageBoxIcon.Information);
                                                return;
                                            }

                                            diasVencidos = controlador.DiasVencidos(Cte);
                                            DateTime ultimacompra = controlador.FechaUltimaCompra(Cte);
                                            DateTime fechaactual = controladorE.FechaActualServidor();
                                            TimeSpan ts = fechaactual - ultimacompra;
                                            diasUltimaCompra = ts.Days;


                                            if (controlador.ReglasTelemarketing(diasVencidos, diasUltimaCompra,
                                                    tipoS) != "SI")
                                            {
                                                MessageBox.Show("No puede realizar ventas en esta sucursal",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }
                                        }
                                    }

                                    //-ClienteAfiliador
                                    if (enviaMensajeBoton == "Dima")
                                    {
                                        rfcC = controlador.ValidarRFC(Cte);
                                        string beneficiarioF = "";
                                        string nombre = controlador.NombreCliente(Cte);
                                        beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);
                                        if (controlador.clienteAfiliador(Cte) == "NO")
                                            if (Cte.Contains("C"))
                                            {
                                                if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                                {
                                                    if (beneficiarioF != "NO")
                                                    {
                                                        if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                                        {
                                                            MessageBox.Show(
                                                                "Es beneficiario final con saldo activo " +
                                                                beneficiarioF, "Advertencia", MessageBoxButtons.OK,
                                                                MessageBoxIcon.Information);
                                                            return;
                                                        }

                                                        string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                                        if (dias != "NO")
                                                        {
                                                            int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                            if (Convert.ToInt32(dias) < diasV)
                                                            {
                                                                MessageBox.Show(
                                                                    "Es beneficiario final con saldo activo " +
                                                                    beneficiarioF, "Advertencia", MessageBoxButtons.OK,
                                                                    MessageBoxIcon.Information);
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    string personal = controlador.ValidarRFCPersonal(rfcC);
                                                    if (personal != "NO")
                                                    {
                                                        if (rfcC == "")
                                                            MessageBox.Show(
                                                                "El cliente " + Cte +
                                                                " no cuenta con RFC comunicate con credito",
                                                                "Advertencia", MessageBoxButtons.OK,
                                                                MessageBoxIcon.Information);
                                                        else
                                                            MessageBox.Show(
                                                                "El empleado " + personal +
                                                                " es activo no puede realizar movimientos de canal 76",
                                                                "Advertencia", MessageBoxButtons.OK,
                                                                MessageBoxIcon.Information);
                                                        return;
                                                    }
                                                }
                                            }

                                        if (!IntervencionDima(Cte)) return;

                                        string tipoS = controlador.TipoSuc();
                                        int diasUltimaCompra = 0;
                                        if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                                        {
                                            int diasVencidos = 0;
                                            //if (controlador.SaldoP(Cte) == "SI")
                                            /*GESSY 1182 */
                                            if (controlador.validaDocumentosPendientes(Cte) == "SI")
                                            {
                                                MessageBox.Show(
                                                    "No puede realizar ventas en esta sucursal, Cliente: " + Cte +
                                                    " con saldo pendiente", "Advertencia", MessageBoxButtons.OK,
                                                    MessageBoxIcon.Information);
                                                return;
                                            }

                                            diasVencidos = controlador.DiasVencidos(Cte);
                                            DateTime ultimacompra = controlador.FechaUltimaCompra(Cte);
                                            DateTime fechaactual = controladorE.FechaActualServidor();
                                            TimeSpan ts = fechaactual - ultimacompra;
                                            diasUltimaCompra = ts.Days;


                                            if (controlador.ReglasTelemarketing(diasVencidos, diasUltimaCompra,
                                                    tipoS) != "SI")
                                            {
                                                MessageBox.Show("No puede realizar ventas en esta sucursal",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }
                                        }
                                    }

                                    //-624-BloqueoCuentasGenericas
                                    if (!puedeVenderCuentaGenerica())
                                    {
                                        MessageBox.Show("No puede realizar movimientos a esa cuenta", "Punto De Venta",
                                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        return;
                                    }

                                    //-BloqueoVentaCruzadaSuc501
                                    if (Canal == 3)
                                        if (!string.IsNullOrEmpty(Cte))
                                        {
                                            bool bPuedeComprar = validarVentaCruzada(Cte, Canal);

                                            if (!bPuedeComprar) return;
                                        }

                                    //Validar si la venta de creditazzo tiene parametros para vender
                                    if (Canal == 80)
                                    {
                                        bool puedeVender = true;
                                        switch (controlador.validarVentaCreditazzo(Cte))
                                        {
                                            case 0:
                                                MessageBox.Show("Este cliente no es apto para vender este dia.",
                                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                puedeVender = false;
                                                return;
                                            case 3:
                                                MessageBox.Show("No existe configuracion para el cliente",
                                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                puedeVender = false;
                                                return;
                                        }

                                        if (!puedeVender) return;
                                    }

                                    PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                                    PuntoDeVenta.Canal = Canal;
                                    puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                                    puntoDeVenta.ValidaEstatus = estatus;
                                    puntoDeVenta.FlagEventosPuntoVenta = true;
                                    controlador.GuardarDomicilioActualCasa(Cte);
                                    Hide();
                                    puntoDeVenta.ShowDialog();
                                    if (!puntoDeVenta.CerrarVenta)
                                    {
                                        Show();
                                        StartPosition = FormStartPosition.CenterScreen;
                                    }
                                    else
                                    {
                                        Close();
                                    }

                                    if (cont == 1)
                                    {
                                        Visible = true;
                                        Consultar();
                                        MostrarInf();
                                        panel_Buscador.Visible = true;
                                        dgv_VentanaEntrada.Visible = true;
                                        panel_Buscador.Location = new Point(15, 350);
                                        txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " +
                                                                 enviaMensajeBoton;
                                        dgv_VentanaEntrada.Select();
                                        cont = 0;
                                    }
                                }
                            }
                    }
                    else
                    {
                        MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_cuenta.Text = "";
                        txt_cuenta.Focus();
                    }
                }

                if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                    e.KeyChar == '#')
                    e.Handled = false;
                else
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscadorCuenta", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void txtNombre_Click(object sender, EventArgs e)
        {
            txt_TituloEntrada.Text = "Inserte el nombre del cliente empezando por apellidos";
        }

        private void btn_SolValera_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Valera";
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btnDimaForaneo.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = false;
            btn_Ir.Visible = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btnDimaForaneo.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.LightBlue;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            gbx_Valera.Visible = true;
            Size = new Size(1026, 750);
            if (!panel_Buscador.Visible)
            {
                Location = new Point(Location.X, 100);
                //this.Location = new Point(233, 130);
                Size = new Size(1026, 750);
            }

            LlenarValera();
            txt_cuenta.Focus();
            txt_TituloEntrada.Text =
                "Ingresa el Codigo de valera que quiere generar, una vez ingresado capture el cliente";

            if (ClaseEstatica.Usuario.Uen == 1) Canal = 76;
            btn_Ir.Text = "Cliente Nuevo Dima";
        }

        public void LlenarValera()
        {
            try
            {
                datosValera = new List<string>();
                datosValera = controlador.LlenaValera();
                if (datosValera.Count > 0)
                {
                    txt_Valera.DataSource = null;
                    txt_Valera.DataSource = datosValera.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarConcepto", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_Valera_SelectedIndexChanged(object sender, EventArgs e)
        {
            gbx_explorador.Visible = true;
            if (panel_Buscador.Visible)
                Size = new Size(918, 680);
            else
                Size = new Size(918, 480);
        }

        private void gbx_Valera_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void DM0312_VentaEntrada_LocationChanged(object sender, EventArgs e)
        {
            frmLoading.MoveLoader();
        }

        private void dgv_VentanaEntrada_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(listaModelo);
            funciones.OrderGridview(dgv_VentanaEntrada, e.ColumnIndex, TempObjects,
                listaModelo.GetType().GetGenericArguments().Single());
            dgv_VentanaEntrada.Columns[4].Visible = false;
            dgv_VentanaEntrada.Columns[5].Visible = false;
        }


        //-TarjetaDepartamental
        private void txt_cuenta_TextChanged(object sender, EventArgs e)
        {
            string sTexto = txt_cuenta.Text;
            if (txt_cuenta.Text.Length > 0)
            {
                if (sTexto[0].ToString() == "C")
                    txt_cuenta.MaxLength = 9;
                else
                    txt_cuenta.MaxLength = 16;
            }
        }

        public void CambioClet()
        {
            int validaPermisos = 0;
            validaPermisos = controlador.permisoCambiar(Cte);
            //Valida si hay movimiento del usuario para cambiarlo
            if (validaPermisos == 1)
            {
                List<string> cambios = new List<string>();


                frmLoading.Show(this);
                DesabilitarControles(false);
                cambios = controlador.cambiaCliente(Cte, 8, ClaseEstatica.Usuario.Usser);
                frmLoading.Hide();
                DesabilitarControles(true);


                if (int.Parse(cambios[1]) == 1 && cambios.Count > 0)
                {
                    //MessageBox.Show(cambios[0].ToString(), "Cliente");
                    if (cambios[2] != "")
                        Cte = cambios[2];
                    else
                        MessageBox.Show(cambios[0], "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                //Fin de validacion movimiento del usuario para cambiarlo
            }
            else
            {
                MessageBox.Show("Usuario sin permiso en este canal para asignar cuenta", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgv_VentanaEntrada_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //-CerradoIntelisis
            loginC.checkSession();

            string rfcC = "";
            int cont = 0;
            if (e.RowIndex >= 0)
            {
                if (Cte != null && Cte != "")
                {
                    if (enviaMensajeBoton == "Valera")
                    {
                        //-IntervencionDima
                        if (!IntervencionDima(Cte)) return;

                        rfcC = controlador.ValidarRFC(Cte);
                        string beneficiarioF = "";
                        string nombre = controlador.NombreCliente(Cte);
                        beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);
                        if (Cte.Contains("C"))
                        {
                            if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                            {
                                if (beneficiarioF != "NO")
                                {
                                    if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                    {
                                        MessageBox.Show("Es beneficiario final con saldo activo " + beneficiarioF,
                                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }

                                    string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                    if (dias != "NO")
                                    {
                                        int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                        if (Convert.ToInt32(dias) < diasV)
                                        {
                                            MessageBox.Show("Es beneficiario final con saldo activo " + beneficiarioF,
                                                "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            return;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                string personal = controlador.ValidarRFCPersonal(rfcC);
                                if (personal != "NO")
                                {
                                    if (rfcC == "")
                                        MessageBox.Show(
                                            "El cliente " + Cte + " no cuenta con RFC comunicate con credito",
                                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    else
                                        MessageBox.Show(
                                            "El empleado " + personal +
                                            " es activo no puede realizar movimientos de canal 76", "Advertencia",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                        }


                        DM0312_SolicitudValera SolValera = new DM0312_SolicitudValera(Cte, 76);
                        SolValera.Canal = 76;
                        SolValera.mensajeBoton = enviaMensajeBoton;
                        SolValera.ValidaEstatus = estatus;
                        SolValera.valera = txt_Valera.Text;

                        Visible = false;
                        SolValera.ShowDialog();
                        if (!SolValera.CerrarVenta)
                        {
                            Visible = true;
                            StartPosition = FormStartPosition.CenterScreen;
                        }
                        else
                        {
                            Close();
                        }
                    }
                    else
                    {
                        if (enviaMensajeBoton == "Contado")
                            if (controladorP.ClienteConP(Cte))
                            {
                                CambioClet();
                                cont = 1;
                            }

                        if (enviaMensajeBoton == "Credito")
                        {
                            rfcC = controlador.ValidarRFC(Cte);
                            string beneficiarioF = "";
                            string nombre = controlador.NombreCliente(Cte);
                            beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);

                            if (Cte.Contains("C"))
                            {
                                if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                {
                                    if (beneficiarioF != "NO")
                                        if (controladorP.validaCasa(Cte, Canal) != "Casa")
                                        {
                                            if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                            {
                                                MessageBox.Show(
                                                    "Es beneficiario final con saldo activo " + beneficiarioF,
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }

                                            string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                            if (dias != "NO")
                                            {
                                                int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                if (Convert.ToInt32(dias) < diasV)
                                                {
                                                    MessageBox.Show(
                                                        "Es beneficiario final con saldo activo " + beneficiarioF,
                                                        "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Information);
                                                    return;
                                                }
                                            }
                                        }
                                }
                                else
                                {
                                    string personal = controlador.ValidarRFCPersonal(rfcC);
                                    if (personal != "NO")
                                    {
                                        MessageBox.Show(
                                            "El empleado " + personal +
                                            " es activo no puede realizar movimientos de credito", "Advertencia",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }
                                }
                            }

                            string tipoS = controlador.TipoSuc();
                            int diasUltimaCompra = 0;
                            if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                            {
                                int diasVencidos = 0;
                                //if (controlador.SaldoP(Cte) == "SI")
                                /*GESSY 1182 */
                                if (controlador.validaDocumentosPendientes(Cte) == "SI")
                                {
                                    MessageBox.Show(
                                        "No puede realizar ventas en esta sucursal, Cliente: " + Cte +
                                        " con saldo pendiente", "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                                    return;
                                }

                                diasVencidos = controlador.DiasVencidos(Cte);
                                DateTime ultimacompra = controlador.FechaUltimaCompra(Cte);
                                DateTime fechaactual = controladorE.FechaActualServidor();
                                TimeSpan ts = fechaactual - ultimacompra;
                                diasUltimaCompra = ts.Days;


                                if (controlador.ReglasTelemarketing(diasVencidos, diasUltimaCompra, tipoS) != "SI")
                                {
                                    MessageBox.Show("No puede realizar ventas en esta sucursal", "Advertencia",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }

                            if (!CandadoEdad(Cte)) return;
                        }

                        if (enviaMensajeBoton == "Dima")
                        {
                            rfcC = controlador.ValidarRFC(Cte);
                            string beneficiarioF = "";
                            string nombre = controlador.NombreCliente(Cte);
                            beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);

                            //-ClienteAfiliador
                            if (controlador.clienteAfiliador(Cte) == "NO")
                                if (Cte.Contains("C"))
                                {
                                    if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                    {
                                        if (beneficiarioF != "NO")
                                        {
                                            if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                            {
                                                MessageBox.Show(
                                                    "Es beneficiario final con saldo activo " + beneficiarioF,
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }

                                            string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                            if (dias != "NO")
                                            {
                                                int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                if (Convert.ToInt32(dias) < diasV)
                                                {
                                                    MessageBox.Show(
                                                        "Es beneficiario final con saldo activo " + beneficiarioF,
                                                        "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Information);
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        string personal = controlador.ValidarRFCPersonal(rfcC);
                                        if (personal != "NO")
                                        {
                                            if (rfcC == "")
                                                MessageBox.Show(
                                                    "El cliente " + Cte + " no cuenta con RFC comunicate con credito",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            else
                                                MessageBox.Show(
                                                    "El empleado " + personal +
                                                    " es activo no puede realizar movimientos de canal 76",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            return;
                                        }
                                    }
                                }

                            if (!IntervencionDima(Cte)) return;
                            string tipoS = controlador.TipoSuc();
                            int diasUltimaCompra = 0;
                            if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                            {
                                int diasVencidos = 0;
                                //if (controlador.SaldoP(Cte) == "SI")
                                /*GESSY 1182 */
                                if (controlador.validaDocumentosPendientes(Cte) == "SI")
                                {
                                    MessageBox.Show(
                                        "No puede realizar ventas en esta sucursal, Cliente: " + Cte +
                                        " con saldo pendiente", "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                                    return;
                                }

                                diasVencidos = controlador.DiasVencidos(Cte);
                                DateTime ultimacompra = controlador.FechaUltimaCompra(Cte);
                                DateTime fechaactual = controladorE.FechaActualServidor();
                                TimeSpan ts = fechaactual - ultimacompra;
                                diasUltimaCompra = ts.Days;


                                if (controlador.ReglasTelemarketing(diasVencidos, diasUltimaCompra, tipoS) != "SI")
                                {
                                    MessageBox.Show("No puede realizar ventas en esta sucursal", "Advertencia",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                        }

                        //-624-BloqueoCuentasGenericas
                        if (!puedeVenderCuentaGenerica())
                        {
                            MessageBox.Show("No puede realizar movimientos a esa cuenta", "Punto De Venta",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        //-BloqueoVentaCruzadaSuc501
                        if (Canal == 3)
                            if (!string.IsNullOrEmpty(Cte))
                            {
                                bool bPuedeComprar = validarVentaCruzada(Cte, Canal);

                                if (!bPuedeComprar) return;
                            }


                        //-CreditoEmpresario
                        if (enviaMensajeBoton == "Credito Empresario")
                        {
                            rfcC = controlador.ValidarRFC(Cte);
                            string beneficiarioF = "";
                            string nombre = controlador.NombreCliente(Cte);
                            beneficiarioF = controlador.ValidarRFCBeneficiario(rfcC, nombre);

                            if (Cte.Contains("C"))
                            {
                                if (controlador.validaVentasFinales(Cte, Canal) == "NO")
                                {
                                    if (beneficiarioF != "NO")
                                        if (controladorP.validaCasa(Cte, Canal) != "Casa")
                                        {
                                            if (controlador.ValidarFacturaSaldo(beneficiarioF) == "SI")
                                            {
                                                MessageBox.Show(
                                                    "Es beneficiario final con saldo activo " + beneficiarioF,
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }

                                            string dias = controlador.DiasDelUltimoPago(beneficiarioF);
                                            if (dias != "NO")
                                            {
                                                int diasV = controlador.DiasDeCREDICDiasTranscurrir();
                                                if (Convert.ToInt32(dias) < diasV)
                                                {
                                                    MessageBox.Show(
                                                        "Es beneficiario final con saldo activo " + beneficiarioF,
                                                        "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Information);
                                                    return;
                                                }
                                            }
                                        }
                                }
                                else
                                {
                                    string personal = controlador.ValidarRFCPersonal(rfcC);
                                    if (personal != "NO")
                                    {
                                        MessageBox.Show(
                                            "El empleado " + personal +
                                            " es activo no puede realizar movimientos de credito", "Advertencia",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }
                                }
                            }


                            if (!CandadoEdad(Cte)) return;

                            string tipoS = controlador.TipoSuc();
                            int diasUltimaCompra = 0;
                            if (tipoS == "telemarketing" || tipoS == "TELEMARKETING")
                            {
                                int diasVencidos = 0;
                                //if (controlador.SaldoP(Cte) == "SI")
                                /*GESSY 1182 */
                                if (controlador.validaDocumentosPendientes(Cte) == "SI")
                                {
                                    MessageBox.Show(
                                        "No puede realizar ventas en esta sucursal, Cliente: " + Cte +
                                        " con saldo pendiente", "Advertencia", MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                                    return;
                                }

                                diasVencidos = controlador.DiasVencidos(Cte);
                                DateTime ultimacompra = controlador.FechaUltimaCompra(Cte);
                                DateTime fechaactual = controladorE.FechaActualServidor();
                                TimeSpan ts = fechaactual - ultimacompra;
                                diasUltimaCompra = ts.Days;


                                if (controlador.ReglasTelemarketing(diasVencidos, diasUltimaCompra, tipoS) != "SI")
                                {
                                    MessageBox.Show("No puede realizar ventas en esta sucursal", "Advertencia",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                        }

                        //-CreditoEmpresario
                        if (Canal == 80)
                        {
                            bool puedeVender = true;
                            switch (controlador.validarVentaCreditazzo(Cte))
                            {
                                case 0:
                                    MessageBox.Show("Este cliente no es apto para vender este dia.", "Punto De Venta",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    puedeVender = false;
                                    return;
                                case 3:
                                    MessageBox.Show("No existe configuracion para el cliente", "Punto De Venta",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    puedeVender = false;
                                    return;
                            }

                            if (!puedeVender) return;
                        }

                        PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                        PuntoDeVenta.Canal = Canal;
                        puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                        puntoDeVenta.ValidaEstatus = estatus;
                        puntoDeVenta.FlagEventosPuntoVenta = true;
                        controlador.GuardarDomicilioActualCasa(Cte);
                        Hide();
                        puntoDeVenta.ShowDialog();
                        if (!puntoDeVenta.CerrarVenta)
                        {
                            Show();
                            StartPosition = FormStartPosition.CenterScreen;
                        }
                        else
                        {
                            Close();
                        }

                        if (cont == 1)
                        {
                            Visible = true;
                            Consultar();
                            MostrarInf();
                            panel_Buscador.Visible = true;
                            dgv_VentanaEntrada.Visible = true;
                            panel_Buscador.Location = new Point(15, 350);
                            txt_TituloEntrada.Text =
                                "De doble click al cliente a realizar venta de " + enviaMensajeBoton;
                            dgv_VentanaEntrada.Select();
                            cont = 0;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un cliente", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
        }

        //-ValeDigital
        private void btnValDigital_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            //-Datalogic
            ClaseEstatica.iRecarga = 0;

            using (DM0312_EscanearValeDigital EscanearValeDigital = new DM0312_EscanearValeDigital())
            {
                Hide();
                EscanearValeDigital.StartPosition = FormStartPosition.CenterScreen;

                if (EscanearValeDigital.ShowDialog(this) == DialogResult.Cancel)
                {
                    Show();
                }
                else
                {
                    //-Se deben de obtener datos del vale, entre ellos el cliente
                    valeDigitalDatos = ValeDigitalController.getDatosValeSp(EscanearValeDigital.vale);

                    Cte = valeDigitalDatos.cliente;
                    enviaMensajeBoton = "DIMA";
                    Canal = valeDigitalDatos.canal;

                    PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                    PuntoDeVenta.Canal = Canal;
                    puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                    puntoDeVenta.ValidaEstatus = estatus;
                    puntoDeVenta.valedigital = 1;
                    puntoDeVenta.codigoValeDigital = EscanearValeDigital.vale;
                    puntoDeVenta.FlagEventosPuntoVenta = true;
                    controlador.GuardarDomicilioActualCasa(Cte);
                    Hide();
                    puntoDeVenta.ShowDialog();
                    if (!puntoDeVenta.CerrarVenta)
                    {
                        Show();
                        StartPosition = FormStartPosition.CenterScreen;
                    }
                    else
                    {
                        Close();
                    }
                }
            }
        }

        private void btnPagoServicio_Click(object sender, EventArgs e)
        {
            try
            {
                if (controlador.validarCajaAbierta(ClaseEstatica.Usuario.sRefCtaCajero,
                        ClaseEstatica.Usuario.sRefCtaDinero) == 1)
                {
                    Process pTicket = new Process();
                    pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                    pTicket.StartInfo.FileName =
                        ClaseEstatica.plugInPath + "moduloRecargas\\pagoServicios\\pagoServicios.exe";
                    pTicket.StartInfo.Verb = "runas";
                    pTicket.StartInfo.Arguments = ClaseEstatica.Usuario.Usser + " " + ClaseEstatica.iSucural;
                    pTicket.StartInfo.UseShellExecute = false;
                    pTicket.Start();
                    pTicket.WaitForExit();
                }
                else
                {
                    MessageBox.Show("La Caja Se Encuentra Cerrada", "Modulo Pago De Servicios", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error En El Modulo De Recargas: " + ex.Message, "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnRecarga_Click(object sender, EventArgs e)
        {
            if (controlador.validarCajaAbierta(ClaseEstatica.Usuario.sRefCtaCajero,
                    ClaseEstatica.Usuario.sRefCtaDinero) == 1)
            {
                ClaseEstatica.iRecarga = 1;
                cbx_PublicoG.Visible = true;
                gbx_Valera.Visible = false;
                enviaMensajeBoton = "Contado";
                btn_Contado.Enabled = true;
                btnRecarga.Enabled = false;
                btn_Dima.Enabled = true;
                btn_CEmp.Enabled = true;
                btn_Credito.Enabled = true;
                btn_Instituciones.Enabled = true;
                btn_Mayoreo.Enabled = true;
                btn_SolValera.Enabled = true;
                btnReimprimir.Visible = true;

                btnRecarga.BackColor = Color.LightBlue;
                btn_Contado.BackColor = Color.White;
                btn_CEmp.BackColor = Color.White;
                btn_Dima.BackColor = Color.White;
                btn_Credito.BackColor = Color.White;
                btn_Instituciones.BackColor = Color.White;
                btn_Mayoreo.BackColor = Color.White;
                btn_SolValera.BackColor = Color.White;

                btn_Venta.Enabled = false;
                btn_Devolucion.Enabled = true;
                btn_Adjudicacion.Enabled = true;

                btn_Ir.Visible = true;
                if (btn_Contado.Text == "Contado")
                {
                    btn_Ir.Text = "Cliente Nuevo Contado";
                    gbx_explorador.Visible = true;
                    //this.Location = new Point(233, 100);
                    if (!panel_Buscador.Visible)
                    {
                        Size = new Size(960, 480);
                        Location = new Point(Location.X, 100);
                        panel_Buscador.Visible = false;
                    }

                    if (ClaseEstatica.Usuario.Uen == 1)
                        Canal = 2;
                    else if (ClaseEstatica.Usuario.Uen == 2) Canal = 6;
                    txt_cuenta.Focus();
                    txt_TituloEntrada.Text =
                        "Ingresa el cliente a buscar en caso de no existir selecciona el boton Cliente Nuevo Contado, para realizar una venta rapida seleccionar el check de Venta Publico General ";
                    cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral(ClaseEstatica.iRecarga);
                }
            }
            else
            {
                MessageBox.Show("La Caja Se Encuentra Cerrada", "Modulo Recargas", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void btnReimprimir_Click(object sender, EventArgs e)
        {
            try
            {
                Process pTicket = new Process();
                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath +
                                             "moduloRecargas\\reimprimirYReporte\\reimprimirYReporte.exe";
                pTicket.StartInfo.Verb = "runas";
                pTicket.StartInfo.Arguments = ClaseEstatica.iSucural + " " + ClaseEstatica.Usuario.usuario;
                pTicket.StartInfo.UseShellExecute = false;
                pTicket.Start();
                pTicket.WaitForExit();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error En El Modulo De Recargas: " + ex.Message, "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        public bool CandadoEdad(string cliente)
        {
            int anios = 0;
            anios = controladorP.CandadoEdadAños("LIMITE DE EDAD");

            DateTime nacimiento = controlador.FechaNacimientoCliente(cliente); //Fecha de nacimiento
            int edad = DateTime.Today.AddTicks(-nacimiento.Ticks).Year - 1;

            if (edad > anios && anios != 0)
            {
                MessageBox.Show("Cliente " + cliente + " no califica por edad", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return false;
            }

            return true;
        }

        //-ValidacionTelefonoNip
        private void btnTelNip_Click(object sender, EventArgs e)
        {
            string Cliente = "";

            if (dgv_VentanaEntrada.Rows != null && dgv_VentanaEntrada.Rows.Count > 0)
            {
                Cliente = dgv_VentanaEntrada.CurrentRow.Cells[0].Value.ToString();
            }
            else
            {
                Cliente = txt_cuenta.Text;

                if (Cliente.Length >= 9)
                {
                    if (!controlador.checkCliente(Cliente))
                    {
                        MessageBox.Show("No existe la cuenta.", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca una cuenta valida.", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }
            }

            string idventa = controlador.getIdVenta(Cliente);

            if (!string.IsNullOrEmpty(idventa))
            {
                if (controlador.LineaCredito(Cliente))
                {
                    int numV = controladorD.SucursalRDP(ClaseEstatica.Usuario.sucursal);
                    if (numV == 1)
                    {
                        string ArgumentosPlugin = "SHM "
                                                  + "True "
                                                  + "\"NIPCOMPRA " + idventa + "\" "
                                                  + "\"true " + ClaseEstatica.Usuario.usuario + " \" "
                                                  + Cliente + " "
                                                  + "1 "
                            ;
                        controladorD.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
                    }
                    else
                    {
                        if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                        {
                            string ArgumentosPlugin = " NIPCOMPRA " + idventa + " " + Cliente + " " + "True True" +
                                                      " " + ClaseEstatica.Usuario.usuario;
                            controladorD.EjecutarPlugins(ArgumentosPlugin, "SHM.exe",
                                ConfigurationManager.AppSettings["CarpetaSHM"]);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("El cliente no cuenta con una linea de credito.", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("El cliente no tiene movimientos", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        //-IntervencionDima
        public bool IntervencionDima(string cliente)
        {
            bool checkI = false;
            checkI = controlador.CheckInterv(cliente);

            if (checkI)
            {
                MessageBox.Show(
                    "No es posible realizar la solicitud de credito, el cliente: " + cliente +
                    " es Dima y tiene intervencion de cobranza", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            return true;
        }


        private void DM0312_VentaEntrada_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        private void cbx_PublicoG_CheckedChanged(object sender, EventArgs e)
        {
            //-CerradoIntelisis
            loginC.checkSession();

            if (cbx_PublicoG.Checked)
            {
                Cte = ClaseEstatica.iRecarga > 0 ? "C99999997" : "C99999996";
                if (ClaseEstatica.Usuario.Uen == 1)
                    Canal = 2;
                else
                    Canal = 6;
                PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                PuntoDeVenta.Canal = Canal;
                puntoDeVenta.mensajeBoton = "Contado";
                puntoDeVenta.ValidaEstatus = estatus;
                puntoDeVenta.FlagEventosPuntoVenta = true;
                Hide();
                puntoDeVenta.ShowDialog();
                cbx_PublicoG.Checked = false;
                if (!puntoDeVenta.CerrarVenta)
                {
                    Show();
                    StartPosition = FormStartPosition.CenterScreen;
                }
                else
                {
                    Close();
                }
            }
        }

        private async void txt_CodigoPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
                if (e.KeyChar == Convert.ToChar(Keys.Enter))
                {
                    //-CerradoIntelisis
                    loginC.checkSession();

                    if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" ||
                        txt_cuenta.Text != "" || txt_CodigoPostal.Text != "")
                    {
                        frmLoading.Show(this);
                        DesabilitarControles(false);
                        await Task.Run(() => Consultar());
                        frmLoading.Hide();
                        DesabilitarControles(true);
                        MostrarInf();
                    }
                    else
                    {
                        MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_cuenta.Text = "";
                        txt_cuenta.Focus();
                    }
                }

                if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                    e.KeyChar == '#')
                    e.Handled = false;
                else
                    e.Handled = true;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("BuscadorCuenta", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void dgv_VentanaEntrada_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridViewCell cell = dgv_VentanaEntrada.Rows[e.RowIndex].Cells[e.ColumnIndex];
            if (enviaMensajeBoton == "Contado")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA VENTA DE CONTADO";
            if (enviaMensajeBoton == "Credito")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA VENTA DE CREDITO";
            if (enviaMensajeBoton == "Dima")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA VENTA DIMA";
            if (enviaMensajeBoton == "Instituciones")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA VENTA DE EMPLEADO";
            if (enviaMensajeBoton == "Mayoreo")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA VENTA MAYOREO";
            if (enviaMensajeBoton == "Valera")
                cell.ToolTipText =
                    "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA GENERACION DE VALERA";
            if (enviaMensajeBoton == "Devolucion")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA DEVOLUCION";
            if (enviaMensajeBoton == "Adjudicacion")
                cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN CLIENTE Y CONTINUAR CON LA ADJUDICACION";
        }

        //-CreditoEmpresario
        private void Btn_CEmp_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Credito Empresario";
            btn_Ir.Visible = true;
            gbx_Valera.Visible = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btnDimaForaneo.Enabled = true;
            btn_Credito.Enabled = true;
            btn_CEmp.Enabled = false;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btnDimaForaneo.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_CEmp.BackColor = Color.LightBlue;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;

            //-ValidacionTelefonoNip
            btnTelNip.Visible = true;
            btnTelNip.Enabled = true;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;
            if (btn_CEmp.Text == "Credito Empresario")
            {
                btn_Ir.Text = "Cliente Nuevo Credito Empresario";
                gbx_explorador.Visible = true;
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1026, 450);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    StartPosition = FormStartPosition.CenterScreen;
                    panel_Buscador.Visible = false;
                }

                txt_cuenta.Focus();
                if (ClaseEstatica.Usuario.Uen == 1) Canal = 78;
                if (ClaseEstatica.Usuario.Uen == 2) Canal = 79;
                //else if (ClaseEstatica.Usuario.Uen == 2) //Don't have Viu
                //Canal = 78;


                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Venta Nueva Credito Empresario";
            }
        }

        //-BloqueoVentaCruzadaSuc501
        /// <summary>
        ///     Metodo encargado de la logica de la venta a ventas cruzadas
        /// </summary>
        /// <param name="sCliente">cliente el cual se validara</param>
        /// <returns>retorna true si puede comprar de lo contrario false</returns>
        public bool validarVentaCruzada(string sCliente, int iCanalVenta)
        {
            bool bPuedeComprar = false;
            bool bTieneMovimientosFinalesConcluidos = false;
            int iDiasFaltantes = 0;
            List<int> listaSucursales = new List<int>();
            modeloSucursalesVentaCruzadas modeloSucConfiguradas = new modeloSucursalesVentaCruzadas();

            listaSucursales = controlador.obtenerSucursalesCliente(Cte);
            DM0312_C_CampoExtra cextra = new DM0312_C_CampoExtra();
            string sTipoCliente = cextra.obtenerTipoCliente(sCliente, iCanalVenta);
            if (sTipoCliente == "Casa") return true;

            if (listaSucursales.Count > 0)
            {
                modeloSucConfiguradas = controlador.obtenerSucursalesConfiguradas();

                if (!listaSucursales.Contains(modeloSucConfiguradas.iSucursal) ||
                    ClaseEstatica.Usuario.sucursal == modeloSucConfiguradas.iSucursal)
                {
                    bPuedeComprar = true;
                }
                else
                {
                    //validar movimientos finales
                    bTieneMovimientosFinalesConcluidos =
                        controlador.validarMovimientosFinales(sCliente, modeloSucConfiguradas.iSucursal);

                    if (bTieneMovimientosFinalesConcluidos)
                    {
                        bPuedeComprar = true;
                    }
                    else
                    {
                        DateTime dt = new DateTime();
                        DateTime dtFechaAcual = new DateTime();

                        dt = controlador.obtenerFechaPrimerCompra(sCliente, modeloSucConfiguradas.iSucursal);
                        dtFechaAcual = controlador.obtenerFechaActual();

                        TimeSpan tmSpan = dtFechaAcual - dt;

                        int iDias = tmSpan.Days;

                        if (iDias > modeloSucConfiguradas.iDias)
                            bPuedeComprar = true;
                        else
                            iDiasFaltantes = modeloSucConfiguradas.iDias - iDias;
                    }
                }
            }
            else
            {
                bPuedeComprar = true;
            }

            if (!bPuedeComprar)
                MessageBox.Show(
                    "Cliente con movimientos de Venta Cruzada. Esperar " + iDiasFaltantes +
                    " días para realizar compra", "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return bPuedeComprar;
        }

        /// <summary>
        ///     Metodo encargado de validar si el acceso del usuario puede realizar ventas a las cuentas genericas
        /// </summary>
        /// <returns>retorna true si puede realizar ventas a la cuenta seleccionada</returns>
        public bool puedeVenderCuentaGenerica()
        {
            bool bPuedeVender = true;
            List<string> sListaCuentas = controlador.obtenerInformacionStd();

            foreach (string item in sListaCuentas)
            {
                string[] sInformacion = item.Split('|');
                if (sInformacion[0] == txt_cuenta.Text)
                {
                    string[] sAgente = sInformacion[1].Split(',');
                    foreach (string agente in sAgente)
                        if (agente.Trim() == ClaseEstatica.Usuario.Acceso)
                            bPuedeVender = false;
                }
            }


            return bPuedeVender;
        }

        #region "Metodos"

        public void MovimientosIniciar()
        {
            //-CreditoEmpresario
            switch (ClaseEstatica.Usuario.Uen)
            {
                case 1:
                    btn_CEmp.Visible = true;
                    break;
            }

            if (btn_Venta.Visible && btn_Devolucion.Visible == false && btn_Adjudicacion.Visible == false)
            {
                txt_MovId.Text = "";
                btn_Venta.Enabled = false;
                btn_Devolucion.Enabled = true;
                btn_Adjudicacion.Enabled = true;
                btn_Contado.Enabled = true;
                btn_Dima.Enabled = true;
                btn_Credito.Enabled = true;
                btn_Instituciones.Enabled = true;
                btn_Mayoreo.Enabled = true;
                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                btn_Ir.Visible = false;
                gbx_AdjMov.Visible = false;
                panel_TipoVenta.Visible = true;
                btn_Contado.Visible = true;
                btn_Dima.Visible = true;
                btn_Instituciones.Visible = true;
                btn_Credito.Visible = true;
                btn_Mayoreo.Visible = true;
                Control.ControlCollection vista = Controls;
                UsuarioAcceso.AplicarVistas(vista, Name);
                Size = new Size(918, 300);
                //this.Location = new Point(233, 155);
                Location = new Point(Location.X, 155);
                panel_Buscador.Visible = false;
                gbx_explorador.Visible = false;

                if (ClaseEstatica.Usuario.Uen == 3)
                {
                    btn_Ir.Visible = true;
                    btn_Mayoreo.Visible = true;
                    btn_Mayoreo.Enabled = false;
                    btn_Ir.Text = "Cliente Nuevo Mayoreo";
                    enviaMensajeBoton = "Mayoreo";
                    StartPosition = FormStartPosition.CenterScreen;
                    txt_TituloEntrada.Text =
                        "Ingresa el cliente a buscar en caso de no existir selecciona el boton Venta Nueva Mayoreo ";
                    dgv_VentanaEntrada.DataSource = null;
                    gbx_explorador.Visible = true;
                    gbx_explorador.Location = new Point(13, 250);
                    btn_Mayoreo.Location = new Point(195, 3);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    Size = new Size(918, 410);
                    btn_Venta.Enabled = false;
                    btn_Devolucion.Enabled = true;
                    btn_Adjudicacion.Enabled = true;
                    //panel_TipoVenta.Size = new Size(110, 88);
                    //panel_TipoVenta.Location = new Point(247, 150);
                    Canal = 11;
                }
                else if (ClaseEstatica.Usuario.Uen == 2)
                {
                    btn_Ir.Text = "Venta Nueva";
                    txt_TituloEntrada.Text = "Elige el tipo de Venta";
                    btn_Contado.Text = "Contado";
                    btn_Dima.Text = "Dima";
                    btn_Instituciones.Text = "Instituciones";
                    btn_Dima.Visible = false;
                    btn_Instituciones.Visible = false;
                    btn_Credito.Text = "Credito Menudeo";
                    Size = new Size(918, 320);
                    StartPosition = FormStartPosition.CenterScreen;
                    dgv_VentanaEntrada.DataSource = null;
                }
                else if (ClaseEstatica.Usuario.Uen == 1)
                {
                    btn_Ir.Text = "Venta Nueva";
                    txt_TituloEntrada.Text = "Elige el tipo de Venta";
                    btn_Contado.Text = "Contado";
                    btn_Dima.Text = "Dima";
                    btn_Instituciones.Text = "Instituciones";
                    btn_Credito.Text = "Credito Menudeo";
                    Size = new Size(918, 320);
                    StartPosition = FormStartPosition.CenterScreen;
                    dgv_VentanaEntrada.DataSource = null;
                    btn_SolValera.Visible = true;

                    if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                    {
                        btn_Dima.Visible = false;
                        btn_Instituciones.Visible = false;
                        btn_Mayoreo.Visible = false;
                        btn_SolValera.Visible = false;
                    }

                    if (ClaseEstatica.Usuario.sucursal == 30)
                    {
                        btn_Contado.Visible = false;
                        btn_Dima.Visible = true;
                        btn_Mayoreo.Visible = false;
                        btn_SolValera.Visible = true;
                    }
                }
            }
            else
            {
                if (btn_Venta.Visible == false && btn_Devolucion.Visible && btn_Adjudicacion.Visible == false)
                {
                    gbx_Valera.Visible = false;
                    enviaMensajeBoton = "Devolucion";
                    LlenarMov();
                    panelMovimientos.Location = new Point(330, 11);

                    if (ClaseEstatica.Usuario.Uen == 1)
                        txt_Mov.Text = "Factura";
                    else if (ClaseEstatica.Usuario.Uen == 2)
                        txt_Mov.Text = "Factura VIU";
                    else if (ClaseEstatica.Usuario.Uen == 3) txt_Mov.Text = "Factura Mayoreo";

                    //txt_Mov.Enabled = false;
                    btn_Venta.Enabled = true;
                    btn_Devolucion.Enabled = false;
                    btn_Adjudicacion.Enabled = true;
                    btn_SolValera.Enabled = true;

                    btn_Contado.Enabled = true;
                    btn_Dima.Enabled = true;
                    btn_Credito.Enabled = true;
                    btn_Instituciones.Enabled = true;
                    btn_Mayoreo.Enabled = true;


                    btn_Ir.Visible = false;
                    panel_TipoVenta.Visible = false;
                    gbx_explorador.Visible = false;
                    panel_Buscador.Visible = false;
                    if (btn_Devolucion.Text == "Devolución")
                    {
                        btn_IrVenta.Text = "Devolver";
                        txt_TituloEntrada.Text =
                            "Ingresa el Movimiento y su ID correcto y selecciona el boton Devolver";
                        StartPosition = FormStartPosition.CenterScreen;
                        gbx_AdjMov.Visible = true;
                        dgv_VentanaEntrada.DataSource = null;
                        Size = new Size(918, 300);
                        //this.Location = new Point(233, 155);
                        Location = new Point(Location.X, 155);
                    }
                }
                else
                {
                    if (btn_Venta.Visible == false && btn_Devolucion.Visible == false && btn_Adjudicacion.Visible)
                    {
                        LlenarMovAdj();
                        panelMovimientos.Location = new Point(330, 11);
                        gbx_Valera.Visible = false;
                        btn_SolValera.Enabled = true;
                        enviaMensajeBoton = "Adjudicacion";
                        btn_Ir.Visible = false;
                        panel_TipoVenta.Visible = false;
                        gbx_explorador.Visible = false;
                        panel_Buscador.Visible = false;
                        btn_Venta.Enabled = true;
                        btn_Devolucion.Enabled = true;
                        btn_Adjudicacion.Enabled = false;
                        btn_Contado.Enabled = true;
                        btn_Dima.Enabled = true;
                        btn_Credito.Enabled = true;
                        btn_Instituciones.Enabled = true;
                        btn_Mayoreo.Enabled = true;
                        if (btn_Adjudicacion.Text == "Adjudicacion")
                        {
                            btn_IrVenta.Text = "Adjudicar";
                            txt_TituloEntrada.Text =
                                "Ingresa el Movimiento y su ID correcto y selecciona el boton Adjudicar";
                            StartPosition = FormStartPosition.CenterScreen;
                            gbx_AdjMov.Visible = true;
                            dgv_VentanaEntrada.DataSource = null;
                            Size = new Size(918, 300);
                            //this.Location = new Point(233, 155);
                            Location = new Point(Location.X, 155);
                            if (ClaseEstatica.Usuario.Uen == 1)
                                txt_Mov.Text = "Factura";
                            else if (ClaseEstatica.Usuario.Uen == 2)
                                txt_Mov.Text = "Factura VIU";
                            else
                                txt_Mov.Text = "Factura";
                        }
                    }
                    else
                    {
                        if (btn_Venta.Visible == false && btn_Devolucion.Visible && btn_Adjudicacion.Visible)
                        {
                            panelMovimientos.Location = new Point(240, 11);
                        }
                        else
                        {
                            if (btn_Venta.Visible && btn_Devolucion.Visible && btn_Adjudicacion.Visible == false)
                            {
                                panelMovimientos.Location = new Point(240, 11);
                            }
                            else
                            {
                                if (btn_Venta.Visible && btn_Devolucion.Visible == false && btn_Adjudicacion.Visible)
                                    panelMovimientos.Location = new Point(240, 11);
                            }
                        }
                    }
                }
            }
        }

        public async void EjecutaClientes()
        {
            //frmLoading = new DM0312_Loading_();
            listaEmpleados = new List<DM0312_MPuntoDeVentaCliente>();
            listaEmpleados = await Task.Run(() => controladorP.TodosClientes());
        }

        public async void EjecutaExe()
        {
            try
            {
                //TABLA CONVERSION

                if (enviaMensajeBoton == "Valera" && controlador.TablastdValeras(txt_Valera.Text) == "SI")
                {
                    DialogResult dialogResult =
                        MessageBox.Show(
                            "Este tipo de crédito solo podrá afiliar a clientes DIMA y no contara con una linea de crédito ¿Desea continuar?",
                            "Tipo cliente", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.No) return;
                }

                if (Canal > 0)
                {
                    obtenCategoria();
                    if (Uen == ClaseEstatica.Usuario.Uen)
                    {
                        //-CreditoEmpresario
                        if (Categoria == "INSTITUCIONES" || Categoria == "CREDITO_MENUDEO" || Categoria == "CONTADO" ||
                            Categoria == "MAYOREO" || Categoria == "ASOCIADOS" || Categoria == "CREDILANA_EMPRESARIO")
                        {
                            string ruta = string.Empty;
                            obtieneIdClienteNuevo();
                            Est = ClaseEstatica.WorkStation;
                            Emp = ClaseEstatica.Usuario.grupoEmpresa;
                            Suc = ClaseEstatica.Usuario.sucursal;
                            Usuario = ClaseEstatica.Usuario.usuario;
                            Process appy = new Process();
                            ruta = ClaseEstatica.plugInPath + "\\ClienteExpress\\ClienteExpress.exe";
                            appy.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                            appy.StartInfo.FileName = ruta;
                            appy.StartInfo.Verb = "runas";
                            if (enviaMensajeBoton == "Valera" && txt_Valera.Text == "VALR00001")
                                appy.StartInfo.Arguments = Canal + " " + Categoria + " " + Est + " " + Emp + " " + Suc +
                                                           " " + Usuario + " " + Cte + " " + "RedDima";
                            else
                                appy.StartInfo.Arguments = Canal + " " + Categoria + " " + Est + " " + Emp + " " + Suc +
                                                           " " + Usuario + " " + Cte + " ";
                            appy.StartInfo.UseShellExecute = false;
                            //Ejecuta el programa
                            if (File.Exists(appy.StartInfo.FileName))
                            {
                                appy.Start();
                                appy.WaitForExit();
                                //Si el usuario es nuevo y la venta es de contado o un apartado tiene que cambiar de prospecto a cliente
                                //por lo que se genera el siguiente punto                           

                                if (Canal == 6 || Canal == 5 || Canal == 2 || Canal == 1 || Canal == 11)
                                {
                                    //Valida si el usuario pertenece al grupo de ventas ya que tienen cierta restriccion al cambiar a los usuario de prospectos a clientes
                                    int validaPermisos = 0;

                                    if (Usuario.Contains("VENTP"))
                                    {
                                        string crediExpressContado = "";
                                        crediExpressContado = controlador.ClienteExpressCred(Cte);
                                        if (crediExpressContado == "SI")
                                        {
                                            int validaPermisosUsuario = 0;
                                            validaPermisosUsuario = controlador.permisosCanal(Cte);
                                            // Valida si el usuario de ventas puede cambiar dichos canales de venta
                                            if (validaPermisosUsuario > 0)
                                            {
                                                validaPermisos = controlador.permisoCambiar(Cte);
                                                //Valida si hay movimiento del usuario para cambiarlo
                                                if (validaPermisos == 1)
                                                {
                                                    List<string> cambios = new List<string>();


                                                    frmLoading.Show(this);
                                                    DesabilitarControles(false);
                                                    cambios = await Task.Run(() =>
                                                        controlador.cambiaCliente(Cte, 8, Usuario));
                                                    frmLoading.Hide();
                                                    DesabilitarControles(true);


                                                    if (int.Parse(cambios[1]) == 1 && cambios.Count > 0)
                                                    {
                                                        //MessageBox.Show(cambios[0].ToString(), "Cliente");
                                                        if (cambios[2] != "")
                                                        {
                                                            Cte = cambios[2];
                                                            controlador.GuardarDomicilioActual(Cte);
                                                            PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                                                            PuntoDeVenta.Canal = Canal;
                                                            puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                                                            puntoDeVenta.categoria = Categoria;
                                                            puntoDeVenta.ValidaEstatus = estatus;
                                                            txt_cuenta.Text = Cte;
                                                            Visible = false;
                                                            puntoDeVenta.ShowDialog();
                                                            Visible = true;
                                                            Consultar();
                                                            MostrarInf();
                                                            panel_Buscador.Visible = true;
                                                            dgv_VentanaEntrada.Visible = true;
                                                            panel_Buscador.Location = new Point(15, 350);
                                                            txt_TituloEntrada.Text =
                                                                "De doble click al cliente a realizar venta de " +
                                                                enviaMensajeBoton;
                                                            dgv_VentanaEntrada.Select();
                                                            StartPosition = FormStartPosition.CenterScreen;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show(cambios[0], "Advertencia", MessageBoxButtons.OK,
                                                            MessageBoxIcon.Warning);
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente",
                                                        "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                }
                                                //Fin de validacion movimiento del usuario para cambiarlo
                                            }
                                            else
                                            {
                                                MessageBox.Show("Usuario sin permiso en este canal para asignar cuenta",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            }
                                            //Fin de validacion de permisos de canal
                                        }
                                        else
                                        {
                                            txt_cuenta.Focus();
                                        }
                                    }
                                    else
                                    {
                                        string crediExpressC = "";
                                        crediExpressC = controlador.ClienteExpressCred(Cte);
                                        if (crediExpressC == "SI")
                                        {
                                            validaPermisos = controlador.permisoCambiar(Cte);
                                            //Valida si hay movimiento del usuario para cambiarlo
                                            if (validaPermisos == 1)
                                            {
                                                List<string> cambios = new List<string>();
                                                frmLoading.Show(this);
                                                DesabilitarControles(false);
                                                cambios = await Task.Run(() =>
                                                    controlador.cambiaCliente(Cte, 8, Usuario));
                                                frmLoading.Hide();
                                                DesabilitarControles(true);
                                                if (int.Parse(cambios[1]) == 1)
                                                {
                                                    if (cambios[2] != "")
                                                    {
                                                        Cte = cambios[2];
                                                        PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                                                        PuntoDeVenta.Canal = Canal;
                                                        puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                                                        puntoDeVenta.categoria = Categoria;
                                                        puntoDeVenta.ValidaEstatus = estatus;
                                                        txt_cuenta.Text = Cte;
                                                        Visible = false;
                                                        puntoDeVenta.ShowDialog();
                                                        Visible = true;
                                                        Consultar();
                                                        MostrarInf();
                                                        panel_Buscador.Visible = true;
                                                        dgv_VentanaEntrada.Visible = true;
                                                        panel_Buscador.Location = new Point(15, 350);
                                                        txt_TituloEntrada.Text =
                                                            "De doble click al cliente a realizar venta de " +
                                                            enviaMensajeBoton;
                                                        dgv_VentanaEntrada.Select();
                                                        StartPosition = FormStartPosition.CenterScreen;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show(cambios[0], "Advertencia", MessageBoxButtons.OK,
                                                        MessageBoxIcon.Warning);
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente",
                                                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            }
                                        }
                                        else
                                        {
                                            txt_cuenta.Focus();
                                        }
                                        //Fin de validacion
                                    }
                                }

                                if (Canal == 3 || Canal == 76 || Canal == 7 || Canal == 34 || Canal == 78 ||
                                    Canal == 79 || Canal == 80) //-CreditoEmpresario
                                {
                                    string crediExpress = "";
                                    crediExpress = controlador.ClienteExpressCred(Cte);
                                    if (crediExpress == "SI")
                                    {
                                        if (enviaMensajeBoton == "Valera")
                                        {
                                            DM0312_SolicitudValera SolValera = new DM0312_SolicitudValera(Cte, 76);
                                            SolValera.Canal = 76;
                                            SolValera.mensajeBoton = enviaMensajeBoton;
                                            SolValera.ValidaEstatus = estatus;
                                            SolValera.valera = txt_Valera.Text;
                                            Visible = false;
                                            SolValera.ShowDialog();
                                            Visible = true;
                                            txt_cuenta.Text = Cte;
                                            Consultar();
                                            MostrarInf();
                                            panel_Buscador.Visible = true;
                                            dgv_VentanaEntrada.Visible = true;
                                            panel_Buscador.Location = new Point(15, 350);
                                            txt_TituloEntrada.Text =
                                                "Ingresa el Codigo de valera que quiere generar, una vez ingresado capture el cliente";
                                            txt_Valera.Focus();
                                            StartPosition = FormStartPosition.CenterScreen;
                                        }
                                        else
                                        {
                                            PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
                                            PuntoDeVenta.Canal = Canal;
                                            puntoDeVenta.mensajeBoton = enviaMensajeBoton;
                                            puntoDeVenta.categoria = Categoria;
                                            puntoDeVenta.ValidaEstatus = estatus;
                                            txt_cuenta.Text = Cte;
                                            Visible = false;
                                            puntoDeVenta.ShowDialog();
                                            Visible = true;
                                            Consultar();
                                            MostrarInf();
                                            panel_Buscador.Visible = true;
                                            dgv_VentanaEntrada.Visible = true;
                                            panel_Buscador.Location = new Point(15, 350);
                                            txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " +
                                                                     enviaMensajeBoton;
                                            dgv_VentanaEntrada.Select();
                                            StartPosition = FormStartPosition.CenterScreen;
                                        }
                                    }
                                    else
                                    {
                                        txt_cuenta.Focus();
                                    }
                                }

                                //Fin de cambio de prospecto a cliente
                            }

                            //Fin de ejecucion
                            appy.Dispose();
                        }
                        else
                        {
                            MessageBox.Show("Es necesario elegir una categoria valida", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Es necesario elegir una categoria valida", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EjecutaExe", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        //public async void EjecutaExe2()
        //{
        //    try
        //    {
        //        if (Canal > 0)
        //        {
        //            obtenCategoria();
        //            if (Uen == ClaseEstatica.Usuario.Uen)
        //            {
        //                if (Categoria == "INSTITUCIONES" || Categoria == "CREDITO_MENUDEO" || Categoria == "CONTADO" || Categoria == "MAYOREO" || Categoria == "ASOCIADOS")
        //                {
        //                    string ruta = string.Empty;
        //                    obtieneIdClienteNuevo();
        //                    Est = ClaseEstatica.WorkStation;
        //                    Emp = ClaseEstatica.Usuario.grupoEmpresa;
        //                    Suc = ClaseEstatica.Usuario.sucursal;
        //                    Usuario = ClaseEstatica.Usuario.usuario;
        //                    System.Diagnostics.Process appy = new System.Diagnostics.Process();
        //                    ruta = ClaseEstatica.plugInPath + "\\ClienteExpress\\ClienteExpress.exe";
        //                    appy.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
        //                    appy.StartInfo.FileName = ruta;
        //                    appy.StartInfo.Verb = "runas";
        //                    appy.StartInfo.Arguments = Canal + " " + Categoria + " " + Est + " " + Emp + " " + Suc + " " + Usuario + " " + Cte;
        //                    appy.StartInfo.UseShellExecute = false;
        //                    //Ejecuta el programa
        //                    if (System.IO.File.Exists(appy.StartInfo.FileName))
        //                    {
        //                        appy.Start();
        //                        appy.WaitForExit();
        //                        //Si el usuario es nuevo y la venta es de contado o un apartado tiene que cambiar de prospecto a cliente
        //                        //por lo que se genera el siguiente punto                           

        //                        if (Canal == 6 || Canal == 5 || Canal == 2 || Canal == 1 || Canal == 11)
        //                        {
        //                            //Valida si el usuario pertenece al grupo de ventas ya que tienen cierta restriccion al cambiar a los usuario de prospectos a clientes
        //                            int validaPermisos = 0;

        //                            if (Usuario.Contains("VENTP"))
        //                            {
        //                                string crediExpressContado = "";
        //                                crediExpressContado = controlador.ClienteExpressCred(Cte);
        //                                if (crediExpressContado == "SI")
        //                                {
        //                                    int validaPermisosUsuario = 0;
        //                                    validaPermisosUsuario = controlador.permisosCanal(Cte);
        //                                    // Valida si el usuario de ventas puede cambiar dichos canales de venta
        //                                    if (validaPermisosUsuario > 0)
        //                                    {
        //                                        validaPermisos = controlador.permisoCambiar(Cte);
        //                                        //Valida si hay movimiento del usuario para cambiarlo
        //                                        if (validaPermisos == 1)
        //                                        {
        //                                            List<string> cambios = new List<string>();


        //                                            frmLoading.Show(this);
        //                                            DesabilitarControles(false);
        //                                            cambios = await Task.Run(() => controlador.cambiaCliente(Cte, 8, Usuario));
        //                                            frmLoading.Hide();
        //                                            DesabilitarControles(true);


        //                                            if (int.Parse(cambios[1].ToString()) == 1 && cambios.Count > 0)
        //                                            {
        //                                                //MessageBox.Show(cambios[0].ToString(), "Cliente");
        //                                                if (cambios[2].ToString() != "")
        //                                                {
        //                                                    Cte = cambios[2].ToString();
        //                                                    controlador.GuardarDomicilioActual(Cte);
        //                                                    PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
        //                                                    PuntoDeVenta.Canal = Canal;
        //                                                    puntoDeVenta.mensajeBoton = enviaMensajeBoton;
        //                                                    puntoDeVenta.ValidaEstatus = estatus;
        //                                                    txt_cuenta.Text = Cte;
        //                                                    this.Visible = false;
        //                                                    puntoDeVenta.ShowDialog();
        //                                                    this.Visible = true;
        //                                                    Consultar();
        //                                                    MostrarInf();
        //                                                    panel_Buscador.Visible = true;
        //                                                    dgv_VentanaEntrada.Visible = true;
        //                                                    panel_Buscador.Location = new Point(15, 350);
        //                                                    txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " + enviaMensajeBoton;
        //                                                    dgv_VentanaEntrada.Select();
        //                                                    this.StartPosition = FormStartPosition.CenterScreen;
        //                                                }

        //                                            }
        //                                            else
        //                                            {
        //                                                MessageBox.Show(cambios[0].ToString(), "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                                            }

        //                                        }
        //                                        else
        //                                        {
        //                                            MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                                        }
        //                                        //Fin de validacion movimiento del usuario para cambiarlo

        //                                    }
        //                                    else
        //                                    {
        //                                        MessageBox.Show("Usuario sin permiso en este canal para asignar cuenta", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                                    }
        //                                    //Fin de validacion de permisos de canal
        //                                }
        //                                else
        //                                {
        //                                    txt_cuenta.Focus();
        //                                }
        //                            }
        //                            else
        //                            {
        //                                string crediExpressC = "";
        //                                crediExpressC = controlador.ClienteExpressCred(Cte);
        //                                if (crediExpressC == "SI")
        //                                {
        //                                    validaPermisos = controlador.permisoCambiar(Cte);
        //                                    //Valida si hay movimiento del usuario para cambiarlo
        //                                    if (validaPermisos == 1)
        //                                    {
        //                                        List<string> cambios = new List<string>();
        //                                        frmLoading.Show(this);
        //                                        DesabilitarControles(false);
        //                                        cambios = await Task.Run(() => controlador.cambiaCliente(Cte, 8, Usuario));
        //                                        frmLoading.Hide();
        //                                        DesabilitarControles(true);
        //                                        if (int.Parse(cambios[1].ToString()) == 1)
        //                                        {
        //                                            if (cambios[2].ToString() != "")
        //                                            {
        //                                                Cte = cambios[2].ToString();
        //                                                PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
        //                                                PuntoDeVenta.Canal = Canal;
        //                                                puntoDeVenta.mensajeBoton = enviaMensajeBoton;
        //                                                puntoDeVenta.ValidaEstatus = estatus;
        //                                                txt_cuenta.Text = Cte;
        //                                                this.Visible = false;
        //                                                puntoDeVenta.ShowDialog();
        //                                                this.Visible = true;
        //                                                Consultar();
        //                                                MostrarInf();
        //                                                panel_Buscador.Visible = true;
        //                                                dgv_VentanaEntrada.Visible = true;
        //                                                panel_Buscador.Location = new Point(15, 350);
        //                                                txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " + enviaMensajeBoton;
        //                                                dgv_VentanaEntrada.Select();
        //                                                this.StartPosition = FormStartPosition.CenterScreen;
        //                                            }
        //                                        }
        //                                        else
        //                                        {
        //                                            MessageBox.Show(cambios[0].ToString(), "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                                        }

        //                                    }
        //                                    else
        //                                    {
        //                                        MessageBox.Show("No se Puede Cambiar el Prospecto a Cliente", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                                    }
        //                                }
        //                                else
        //                                {
        //                                    txt_cuenta.Focus();
        //                                }
        //                            //Fin de validacion
        //                        }
        //                        }
        //                        if (Canal == 3 || Canal == 76 || Canal == 7 || Canal == 34)
        //                        {

        //                            string crediExpress = "";
        //                            crediExpress = controlador.ClienteExpressCred(Cte);
        //                            if (crediExpress == "SI")
        //                            {
        //                                if (enviaMensajeBoton == "Valera")
        //                                {
        //                                    DM0312_SolicitudValera SolValera = new DM0312_SolicitudValera(Cte, 76);
        //                                    SolValera.Canal = 76;
        //                                    SolValera.mensajeBoton = enviaMensajeBoton;
        //                                    SolValera.ValidaEstatus = estatus;
        //                                    SolValera.valera = txt_Valera.Text;
        //                                    this.Visible = false;
        //                                    SolValera.ShowDialog();
        //                                    this.Visible = true;
        //                                    txt_cuenta.Text = Cte;
        //                                    Consultar();
        //                                    MostrarInf();
        //                                    panel_Buscador.Visible = true;
        //                                    dgv_VentanaEntrada.Visible = true;
        //                                    panel_Buscador.Location = new Point(15, 350);
        //                                    txt_TituloEntrada.Text = "Ingresa el Codigo de valera que quiere generar, una vez ingresado capture el cliente";
        //                                    txt_Valera.Focus();
        //                                    this.StartPosition = FormStartPosition.CenterScreen;
        //                                }
        //                                else
        //                                {
        //                                    PuntoDeVenta puntoDeVenta = new PuntoDeVenta(Cte, Canal);
        //                                    PuntoDeVenta.Canal = Canal;
        //                                    puntoDeVenta.mensajeBoton = enviaMensajeBoton;
        //                                    puntoDeVenta.ValidaEstatus = estatus;
        //                                    txt_cuenta.Text = Cte;
        //                                    this.Visible = false;
        //                                    puntoDeVenta.ShowDialog();
        //                                    this.Visible = true;
        //                                    Consultar();
        //                                    MostrarInf();
        //                                    panel_Buscador.Visible = true;
        //                                    dgv_VentanaEntrada.Visible = true;
        //                                    panel_Buscador.Location = new Point(15, 350);
        //                                    txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " + enviaMensajeBoton;
        //                                    dgv_VentanaEntrada.Select();
        //                                    this.StartPosition = FormStartPosition.CenterScreen;
        //                                }
        //                            }
        //                            else
        //                            {
        //                                txt_cuenta.Focus();
        //                            }
        //                        }

        //                        //Fin de cambio de prospecto a cliente
        //                    }
        //                    //Fin de ejecucion
        //                    appy.Dispose();
        //                }
        //                else
        //                {
        //                    MessageBox.Show("Es necesario elegir una categoria valida", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                }
        //            }
        //            else
        //            {
        //                MessageBox.Show("Es necesario elegir una categoria valida", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        DM0312_ErrorLog.RegistraError("EjecutaExe", "DM0312_VentanaEntrada", ex);
        //        System.Windows.Forms.MessageBox.Show(ex.Message);
        //    }
        //}

        public void obtieneIdClienteNuevo()
        {
            Cte = string.Empty;
            Cte = controlador.ConsultaIdClienteNuevo(ClaseEstatica.Usuario.grupoEmpresa);
        }

        public void LlenarMov()
        {
            try
            {
                datosMov = new List<string>();
                datosMov = controlador.LlenaMovDev();
                if (datosMov.Count > 0)
                {
                    txt_Mov.DataSource = null;
                    txt_Mov.DataSource = datosMov.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarMov", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenarMovAdj()
        {
            try
            {
                txt_Mov.DataSource = null;
                txt_Mov.Items.Add("Factura");
                txt_Mov.Items.Add("Factura VIU");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarMovAdj", "DM0312_ArticulosAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void obtenCategoria()
        {
            try
            {
                List<DM0312_MVentanaEntrada> listacanal = new List<DM0312_MVentanaEntrada>();

                listacanal = controlador.ConsultaCanal(Canal);
                foreach (DM0312_MVentanaEntrada prop in listacanal)
                {
                    Categoria = prop.Categoria;
                    Categoria = Categoria.Replace(" ", "_");
                    Uen = prop.Uen;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("obtenCategoria", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        //-Old Code
        /*
                public void Consultar()
                {
                    try
                    {
                        string cuenta = string.Empty;
                        string cliente = string.Empty;
                        string direccion = string.Empty;
                        string telefono = string.Empty;
                        string CodigoPostal = string.Empty;
                        cuenta = txt_cuenta.Text;
                        cuenta = cuenta.Replace("*", "");
                        cliente = txtNombre.Text;
                        cliente = cliente.Replace("*", "");
                        direccion = txtDireccion.Text;
                        direccion = direccion.Replace("*", "");
                        telefono = txtTelefono.Text;
                        telefono = telefono.Replace("*", "");
                        CodigoPostal = txt_CodigoPostal.Text;
                        CodigoPostal = CodigoPostal.Replace("*", "");

                        listaModelo = controlador.ConsultaClientes(cuenta, cliente, direccion, telefono, CodigoPostal);

                    }
                    catch (Exception ex)
                    {
                        DM0312_ErrorLog.RegistraError("Consultar", "DM0312_VentanaEntrada", ex);
                        MessageBox.Show(ex.Message);
                    }

                }
        */


        public void Consultar()
        {
            try
            {
                string cuenta = string.Empty;
                string cliente = string.Empty;
                string direccion = string.Empty;
                string telefono = string.Empty;
                string CodigoPostal = string.Empty;
                cuenta = txt_cuenta.Text;
                cuenta = cuenta.Replace("*", "");
                cliente = txtNombre.Text;
                cliente = cliente.Replace("*", "");
                direccion = txtDireccion.Text;
                direccion = direccion.Replace("*", "");
                telefono = txtTelefono.Text;
                telefono = telefono.Replace("*", "");
                CodigoPostal = txt_CodigoPostal.Text;
                CodigoPostal = CodigoPostal.Replace("*", "");

                //-TarjetaDepartamental
                if (!string.IsNullOrEmpty(cuenta))
                {
                    //-TarjetaDepartamental
                    if (cuenta[0].ToString() == "C" || cuenta[0].ToString() == "P")
                    {
                        listaModelo = controlador.ConsultaClientes(cuenta, cliente, direccion, telefono, CodigoPostal);
                    }
                    else
                    {
                        bBusquedaTarjeta = true;
                        string scuenta = controlador.obtenerClienteCTE(cuenta);
                        string aEstatus = controlador.obtenerEstatusCliente(scuenta);

                        if (aEstatus == "BAJA")
                        {
                            MessageBox.Show("Cliente Dado De Baja", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return;
                        }

                        if (string.IsNullOrEmpty(scuenta))
                        {
                            MessageBox.Show("Tarjeta no asignada", "Punto De Venta", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            return;
                        }

                        listaModelo = controlador.ConsultaClientes(scuenta, cliente, direccion, telefono, CodigoPostal);
                        if (listaModelo.Count > 0)
                            Invoke((MethodInvoker)delegate { txt_cuenta.Text = scuenta; });
                    }
                }
                else
                {
                    bBusquedaTarjeta = false;
                    listaModelo = controlador.ConsultaClientes(cuenta, cliente, direccion, telefono, CodigoPostal);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Consultar", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void MostrarInf()
        {
            try
            {
                if (listaModelo.Count == 0)
                {
                    dgv_VentanaEntrada.DataSource = null;

                    if (txt_cuenta.Text != "" && txt_cuenta.Text.Length >= 9)
                    {
                        if (controlador.ClienteBaja(txt_cuenta.Text) == "SI")
                        {
                            MessageBox.Show("Cliente incorrecto, el cliente " + txt_cuenta.Text + " esta dado de baja",
                                "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            //-TarjetaDepartamental
                            if (!bBusquedaTarjeta)
                                MessageBox.Show("Cliente incorrecto", "Informacion", MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                            bBusquedaTarjeta = false;
                            txt_cuenta.Text = "";
                            txt_cuenta.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cliente incorrecto", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }

                    Size = new Size(918, 440);
                    if (txt_Valera.Visible) Size = new Size(918, 480);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    panel_Buscador.Visible = false;
                }
                else
                {
                    dgv_VentanaEntrada.DataSource = null;
                    List<DM0312_MVentanaEntrada> objetos = listaModelo.Take(2000).ToList();
                    dgv_VentanaEntrada.DataSource = objetos.ToList();
                    dgv_VentanaEntrada.Columns[1].Width = 250;
                    dgv_VentanaEntrada.Columns[2].Width = 250;
                    dgv_VentanaEntrada.Columns[4].Visible = false;
                    dgv_VentanaEntrada.Columns[5].Visible = false;
                    Size = new Size(918, 620);
                    if (txt_Valera.Visible) Size = new Size(918, 680);
                    //this.Location = new Point(233, 50);
                    Location = new Point(Location.X, 50);
                    panel_Buscador.Location = new Point(15, 350);
                    panel_Buscador.Visible = true;
                    dgv_VentanaEntrada.Visible = true;
                    txt_TituloEntrada.Text = "De doble click al cliente a realizar venta de " + enviaMensajeBoton;
                    dgv_VentanaEntrada.Select();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("MostrarInf", "DM0312_VentanaEntrada", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region "Eventos"

        private void btn_Devolucion_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Visible = false;
            gbx_Valera.Visible = false;
            enviaMensajeBoton = "Devolucion";
            LlenarMov();

            if (ClaseEstatica.Usuario.Uen == 1)
                txt_Mov.Text = "Factura";
            else if (ClaseEstatica.Usuario.Uen == 2)
                txt_Mov.Text = "Factura VIU";
            else if (ClaseEstatica.Usuario.Uen == 3) txt_Mov.Text = "Factura Mayoreo";


            //color
            btn_Venta.BackColor = Color.White;
            btn_Devolucion.BackColor = Color.LightBlue;
            btn_Adjudicacion.BackColor = Color.White;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;

            //


            //txt_Mov.Enabled = false;
            btn_Venta.Enabled = true;
            btn_Devolucion.Enabled = false;
            btn_Adjudicacion.Enabled = true;
            btn_SolValera.Enabled = true;

            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;


            btn_Ir.Visible = false;
            panel_TipoVenta.Visible = false;
            gbx_explorador.Visible = false;
            panel_Buscador.Visible = false;
            if (btn_Devolucion.Text == "Devolución")
            {
                btn_IrVenta.Text = "Devolver";
                txt_TituloEntrada.Text = "Ingresa el Movimiento y su ID correcto y selecciona el boton Devolver";
                StartPosition = FormStartPosition.CenterScreen;
                gbx_AdjMov.Visible = true;
                dgv_VentanaEntrada.DataSource = null;
                Size = new Size(960, 300);
                //this.Location = new Point(233, 155);
                Location = new Point(Location.X, 155);
            }

            txt_MovId.Focus();
            txt_MovId.Select();
        }

        private void btn_Adjudicacion_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Visible = false;
            LlenarMovAdj();
            gbx_Valera.Visible = false;
            btn_SolValera.Enabled = true;
            enviaMensajeBoton = "Adjudicacion";
            btn_Ir.Visible = false;
            panel_TipoVenta.Visible = false;
            gbx_explorador.Visible = false;
            panel_Buscador.Visible = false;
            btn_Venta.Enabled = true;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;

            //color
            btn_Venta.BackColor = Color.White;
            btn_Devolucion.BackColor = Color.White;
            btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;

            //


            if (btn_Adjudicacion.Text == "Adjudicacion")
            {
                btn_IrVenta.Text = "Adjudicar";
                txt_TituloEntrada.Text = "Ingresa el Movimiento y su ID correcto y selecciona el boton Adjudicar";
                StartPosition = FormStartPosition.CenterScreen;
                gbx_AdjMov.Visible = true;
                dgv_VentanaEntrada.DataSource = null;
                Size = new Size(960, 300);
                //this.Location = new Point(233, 155);
                Location = new Point(Location.X, 155);
                if (ClaseEstatica.Usuario.Uen == 1)
                    txt_Mov.Text = "Factura";
                else if (ClaseEstatica.Usuario.Uen == 2)
                    txt_Mov.Text = "Factura VIU";
                else
                    txt_Mov.Text = "Factura";
            }
        }

        private void btn_Venta_Click(object sender, EventArgs e)
        {
            txt_MovId.Text = "";
            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            btn_Ir.Visible = false;
            gbx_AdjMov.Visible = false;
            panel_TipoVenta.Visible = true;
            btn_Contado.Visible = true;
            btn_Dima.Visible = true;
            btn_Instituciones.Visible = true;
            btn_Credito.Visible = true;
            btn_Mayoreo.Visible = true;
            //Control.ControlCollection vista = this.Controls;
            //UsuarioAcceso.AplicarVistas(vista,this.Name);
            Size = new Size(900, 350);
            //this.Location = new Point(233, 155);
            Location = new Point(Location.X, 155);
            panel_Buscador.Visible = false;
            gbx_explorador.Visible = false;

            //color
            btn_Venta.BackColor = Color.LightBlue;
            btn_Devolucion.BackColor = Color.White;
            btn_Adjudicacion.BackColor = Color.White;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;

            //            

            if (ClaseEstatica.Usuario.Uen == 3)
            {
                btn_Ir.Visible = true;
                btn_Mayoreo.Visible = true;
                btn_Mayoreo.Enabled = false;
                btn_Contado.Visible = false;
                btn_Dima.Visible = false;
                btn_Credito.Visible = false;
                btn_Instituciones.Visible = false;
                btn_SolValera.Visible = false;
                btn_Ir.Text = "Cliente Nuevo Mayoreo";
                enviaMensajeBoton = "Mayoreo";
                StartPosition = FormStartPosition.CenterScreen;
                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Venta Nueva Mayoreo ";
                dgv_VentanaEntrada.DataSource = null;
                gbx_explorador.Visible = true;
                gbx_explorador.Location = new Point(13, 250);
                btn_Mayoreo.Location = new Point(195, 3);
                Location = new Point(Location.X, 100);
                Size = new Size(960, 435);
                btn_Venta.Enabled = false;
                btn_Devolucion.Enabled = true;
                btn_Adjudicacion.Enabled = true;
                Canal = 11;
                txt_cuenta.Focus();
                txt_cuenta.Select();
            }
            else if (ClaseEstatica.Usuario.Uen == 2)
            {
                btn_Ir.Text = "Venta Nueva";
                txt_TituloEntrada.Text = "Elige el tipo de Venta";
                btn_Contado.Text = "Contado";
                btn_Dima.Text = "Dima";
                btn_Instituciones.Text = "Instituciones";
                btn_Dima.Visible = false;
                btn_Instituciones.Visible = false;
                btn_Credito.Text = "Credito Menudeo";
                Size = new Size(960, 320);
                StartPosition = FormStartPosition.CenterScreen;
                dgv_VentanaEntrada.DataSource = null;
                btn_Mayoreo.Visible = false;
                btn_SolValera.Visible = false;
            }
            else if (ClaseEstatica.Usuario.Uen == 1)
            {
                btn_Ir.Text = "Venta Nueva";
                txt_TituloEntrada.Text = "Elige el tipo de Venta";
                btn_Contado.Text = "Contado";
                btn_Dima.Text = "Dima";
                btn_Instituciones.Text = "Instituciones";
                btn_Credito.Text = "Credito Menudeo";
                Size = new Size(1180, 320);
                StartPosition = FormStartPosition.CenterScreen;
                dgv_VentanaEntrada.DataSource = null;
                btn_SolValera.Visible = true;
                btn_Mayoreo.Visible = false;

                if (ClaseEstatica.Usuario.sucursal == 41 || ClaseEstatica.Usuario.sucursal == 90)
                {
                    btn_Dima.Visible = false;
                    btn_Instituciones.Visible = false;
                    btn_Mayoreo.Visible = false;
                    btn_SolValera.Visible = false;
                }

                if (ClaseEstatica.Usuario.sucursal == 30)
                {
                    btn_Contado.Visible = false;
                    btn_Dima.Visible = true;
                    btn_Mayoreo.Visible = false;
                    btn_SolValera.Visible = true;
                }
            }
        }

        private void btn_Contado_Click(object sender, EventArgs e)
        {
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = true;
            gbx_Valera.Visible = false;
            enviaMensajeBoton = "Contado";
            btn_Contado.Enabled = false;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.LightBlue;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;

            btn_Ir.Visible = true;
            if (btn_Contado.Text == "Contado")
            {
                btn_Ir.Text = "Cliente Nuevo Contado";
                gbx_explorador.Visible = true;
                //this.Location = new Point(233, 100);
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1015, 500);
                    Location = new Point(Location.X, 100);
                    panel_Buscador.Visible = false;
                }

                if (ClaseEstatica.Usuario.Uen == 1)
                    Canal = 2;
                else if (ClaseEstatica.Usuario.Uen == 2) Canal = 6;
                txt_cuenta.Focus();
                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Cliente Nuevo Contado, para realizar una venta rapida seleccionar el check de Venta Publico General ";
            }

            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
        }

        private void btn_Dima_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Dima";
            btn_Ir.Visible = true;
            gbx_Valera.Visible = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = false;
            btnDimaForaneo.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.LightBlue;
            btnDimaForaneo.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;

            if (btn_Dima.Text == "Dima")
            {
                btn_Ir.Text = "Cliente Nuevo Dima";
                gbx_explorador.Visible = true;
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1026, 450);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    StartPosition = FormStartPosition.CenterScreen;
                    panel_Buscador.Visible = false;
                }

                txt_cuenta.Focus();
                if (ClaseEstatica.Usuario.Uen == 1) Canal = 76;
                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Cliente Nuevo Dima ";
            }
        }

        private void btn_Instituciones_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Instituciones";
            btn_Ir.Visible = true;
            gbx_Valera.Visible = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btnDimaForaneo.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = false;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario


            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btnDimaForaneo.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.LightBlue;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;
            if (btn_Instituciones.Text == "Instituciones")
            {
                btn_Ir.Text = "Cliente Nuevo Instituciones";
                gbx_explorador.Visible = true;
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1026, 450);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    StartPosition = FormStartPosition.CenterScreen;
                    panel_Buscador.Visible = false;
                }

                txt_cuenta.Focus();

                if (ClaseEstatica.Usuario.Uen == 1)
                    Canal = 34;
                else if (ClaseEstatica.Usuario.Uen == 2) Canal = 34;
                txt_TituloEntrada.Text = "Ingresa la nomina del empleado para venta Instituciones ";
            }
        }

        private void btn_Credito_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Credito";
            btn_Ir.Visible = true;
            gbx_Valera.Visible = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btnDimaForaneo.Enabled = true;
            btn_Credito.Enabled = false;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btnDimaForaneo.BackColor = Color.White;
            btn_Credito.BackColor = Color.LightBlue;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = true;
            btnTelNip.Enabled = true;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;
            if (btn_Credito.Text == "Credito Menudeo")
            {
                btn_Ir.Text = "Cliente Nuevo Credito";
                gbx_explorador.Visible = true;
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1026, 450);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    StartPosition = FormStartPosition.CenterScreen;
                    panel_Buscador.Visible = false;
                }

                txt_cuenta.Focus();
                if (ClaseEstatica.Usuario.Uen == 1)
                    Canal = 3;
                else if (ClaseEstatica.Usuario.Uen == 2) Canal = 7;
                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Venta Nueva Credito Menudeo";
            }
        }

        private void btn_Ir_Click(object sender, EventArgs e)
        {
            EjecutaExe();
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void gbx_explorador_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void gbx_AdjMov_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void dgv_VentanaEntrada_DoubleClick(object sender, EventArgs e)
        {
        }

        private async void btnBuscar_Click(object sender, EventArgs e)
        {
            //-CerradoIntelisis
            loginC.checkSession();

            if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" || txt_cuenta.Text != "")
            {
                DM0312_Loading_ frmLoading = new DM0312_Loading_();
                frmLoading.Show(this);
                DesabilitarControles(false);
                await Task.Run(() => Consultar());
                frmLoading.Hide();
                DesabilitarControles(true);
                MostrarInf();
            }
            else
            {
                MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private async void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //-CerradoIntelisis
                loginC.checkSession();

                if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" ||
                    txt_cuenta.Text != "" || txt_CodigoPostal.Text != "")
                {
                    DM0312_Loading_ frmLoading = new DM0312_Loading_();
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                    await Task.Run(() => Consultar());
                    frmLoading.Hide();
                    DesabilitarControles(true);
                    MostrarInf();
                }
                else
                {
                    MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void DesabilitarControles(bool estado)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in Controls)
                    if (!item.Enabled)
                        ListaControles.Add(item.Name);
                    else
                        item.Enabled = estado;
            }
            else
            {
                foreach (Control item in Controls)
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
            }
        }

        private async void txtDireccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //-CerradoIntelisis
                loginC.checkSession();

                if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" ||
                    txt_cuenta.Text != "" || txt_CodigoPostal.Text != "")
                {
                    DM0312_Loading_ frmLoading = new DM0312_Loading_();
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                    await Task.Run(() => Consultar());
                    frmLoading.Hide();
                    DesabilitarControles(true);
                    MostrarInf();
                }
                else
                {
                    MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private async void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //-CerradoIntelisis
                loginC.checkSession();

                if (txtNombre.Text != "" || txtDireccion.Text != "" || txtTelefono.Text != "" ||
                    txt_cuenta.Text != "" || txt_CodigoPostal.Text != "")
                {
                    DM0312_Loading_ frmLoading = new DM0312_Loading_();
                    frmLoading.Show(this);
                    DesabilitarControles(false);
                    await Task.Run(() => Consultar());
                    frmLoading.Hide();
                    DesabilitarControles(true);
                    MostrarInf();
                }
                else
                {
                    MessageBox.Show("Debe ingresar un nombre, dirección o teléfono valido", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
            //if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            //{
            //    e.Handled = true;
            //    return;
            //}
        }

        #endregion

        #region //-ModuloPromociones

        private void btnPromocionesVencidas_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            gbx_Valera.Visible = false;
            gbx_explorador.Visible = false;
            gbPromociones.Visible = true;
            enviaMensajeBoton = "Contado";
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario
            btnPromocionesVencidas.Enabled = false; //-ModuloPromociones

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario
            btnPromocionesVencidas.BackColor = Color.LightBlue; //-ModuloPromociones

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;

            btn_Ir.Visible = true;

            txt_TituloEntrada.Text = "Selecciona el tipo de captura e ingresa un identificador para continuar.";
            Size = new Size(1135, 480);
            panel_Buscador.Visible = false;
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            bool tipoCaptura = cbTipoCapturaPromocion.SelectedItem != null;
            bool Id = !string.IsNullOrEmpty(txtId.Text.Trim());

            if (tipoCaptura)
            {
                if (Id)
                {
                    bool continuar = false;
                    clsControladorPromociones clsControladorPromociones = new clsControladorPromociones();
                    if (cbTipoCapturaPromocion.SelectedItem.ToString() == "Refacturación")
                        continuar = clsControladorPromociones.VerificarPromocionVencida(txtId.Text.Trim());

                    if (cbTipoCapturaPromocion.SelectedItem.ToString() == "Disminución de pretenciones")
                        continuar = clsControladorPromociones.VerificarDisminucionPretenciones(txtId.Text.Trim());

                    if (continuar)
                    {
                        clsControladorPromociones.GetCLienteCanal(txtId.Text.Trim(), out string Cliente, out int Canal);
                        PuntoDeVenta venta = new PuntoDeVenta(Cliente, Canal, txtId.Text.Trim());
                        venta.Refacturacion = cbTipoCapturaPromocion.SelectedItem.ToString() == "Refacturación";
                        venta.mensajeBoton = enviaMensajeBoton;
                        venta.ValidaEstatus = estatus;
                        venta.FlagEventosPuntoVenta = true;
                        venta.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show(
                            "La campaña de promoción aplicada al movimiento no está vencida. Favor de capturar por la ruta establecida");
                    }
                }
                else
                {
                    MessageBox.Show("Selecciona un Id", "Campos faltantes", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un tipo de captura", "Campos faltantes", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void btnDimaForaneo_Click(object sender, EventArgs e)
        {
            cbx_PublicoG.Text = controlador.CambiarTextoVentaPublicoGeneral();
            valeDigitalDatos = new MValeDigital();
            cbx_PublicoG.Visible = false;
            enviaMensajeBoton = "Dima";
            btn_Ir.Visible = true;
            gbx_Valera.Visible = false;
            btn_Contado.Enabled = true;
            btn_Dima.Enabled = true;
            btnDimaForaneo.Enabled = false;
            btn_Credito.Enabled = true;
            btn_Instituciones.Enabled = true;
            btn_Mayoreo.Enabled = true;
            btn_SolValera.Enabled = true;
            btn_CEmp.Enabled = true; //-CreditoEmpresario

            //color
            //btn_Venta.BackColor = Color.White;
            //btn_Devolucion.BackColor = Color.White;
            //btn_Adjudicacion.BackColor = Color.LightBlue;
            btn_Contado.BackColor = Color.White;
            btn_Dima.BackColor = Color.White;
            btnDimaForaneo.BackColor = Color.LightBlue;
            btn_Credito.BackColor = Color.White;
            btn_Instituciones.BackColor = Color.White;
            btn_Mayoreo.BackColor = Color.White;
            btn_SolValera.BackColor = Color.White;
            btn_CEmp.BackColor = Color.White; //-CreditoEmpresario

            //-ValidacionTelefonoNip
            btnTelNip.Visible = false;
            btnTelNip.Enabled = false;

            //-Datalogic
            btnRecarga.Enabled = true;
            btnReimprimir.Visible = false;
            ClaseEstatica.iRecarga = 0;
            btnRecarga.BackColor = Color.White;

            btn_Venta.Enabled = false;
            btn_Devolucion.Enabled = true;
            btn_Adjudicacion.Enabled = true;

            if (btn_Dima.Text == "Dima")
            {
                btn_Ir.Text = "Cliente Nuevo Dima";
                gbx_explorador.Visible = true;
                if (!panel_Buscador.Visible)
                {
                    Size = new Size(1026, 450);
                    //this.Location = new Point(233, 100);
                    Location = new Point(Location.X, 100);
                    StartPosition = FormStartPosition.CenterScreen;
                    panel_Buscador.Visible = false;
                }

                txt_cuenta.Focus();
                if (ClaseEstatica.Usuario.Uen == 1) Canal = 80;
                txt_TituloEntrada.Text =
                    "Ingresa el cliente a buscar en caso de no existir selecciona el boton Cliente Nuevo Dima ";
            }
        }

        #endregion
    }
}