﻿namespace PuntoVenta.View
{
    partial class frmLineaCredito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLineaCredito));
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.lblTipoDima = new System.Windows.Forms.Label();
            this.cmbTipoDima = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtImporteFactura = new System.Windows.Forms.TextBox();
            this.txtImporteCredilana = new System.Windows.Forms.TextBox();
            this.lblCanalVenta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancelar.BackgroundImage")));
            this.btnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Location = new System.Drawing.Point(12, 74);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(47, 44);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAceptar.BackgroundImage")));
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Location = new System.Drawing.Point(12, 12);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(47, 44);
            this.btnAceptar.TabIndex = 5;
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click_1);
            // 
            // lblTipoDima
            // 
            this.lblTipoDima.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTipoDima.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoDima.Location = new System.Drawing.Point(100, 14);
            this.lblTipoDima.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lblTipoDima.Name = "lblTipoDima";
            this.lblTipoDima.Padding = new System.Windows.Forms.Padding(3);
            this.lblTipoDima.Size = new System.Drawing.Size(82, 22);
            this.lblTipoDima.TabIndex = 18;
            this.lblTipoDima.Text = "Tipo Dima";
            // 
            // cmbTipoDima
            // 
            this.cmbTipoDima.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoDima.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoDima.FormattingEnabled = true;
            this.cmbTipoDima.Location = new System.Drawing.Point(103, 44);
            this.cmbTipoDima.Name = "cmbTipoDima";
            this.cmbTipoDima.Size = new System.Drawing.Size(273, 24);
            this.cmbTipoDima.TabIndex = 19;
            this.cmbTipoDima.SelectedValueChanged += new System.EventHandler(this.cmbTipoDima_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(100, 107);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(3);
            this.label1.Size = new System.Drawing.Size(113, 22);
            this.label1.TabIndex = 21;
            this.label1.Text = "Importe Facturas";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(263, 107);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(3);
            this.label2.Size = new System.Drawing.Size(113, 22);
            this.label2.TabIndex = 22;
            this.label2.Text = "Importe Credilana";
            // 
            // txtImporteFactura
            // 
            this.txtImporteFactura.Location = new System.Drawing.Point(103, 137);
            this.txtImporteFactura.MaxLength = 8;
            this.txtImporteFactura.Name = "txtImporteFactura";
            this.txtImporteFactura.Size = new System.Drawing.Size(110, 20);
            this.txtImporteFactura.TabIndex = 24;
            this.txtImporteFactura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtImporteFactura_KeyPress);
            // 
            // txtImporteCredilana
            // 
            this.txtImporteCredilana.Enabled = false;
            this.txtImporteCredilana.Location = new System.Drawing.Point(266, 135);
            this.txtImporteCredilana.Name = "txtImporteCredilana";
            this.txtImporteCredilana.Size = new System.Drawing.Size(110, 20);
            this.txtImporteCredilana.TabIndex = 23;
            // 
            // lblCanalVenta
            // 
            this.lblCanalVenta.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblCanalVenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCanalVenta.Location = new System.Drawing.Point(9, 202);
            this.lblCanalVenta.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.lblCanalVenta.Name = "lblCanalVenta";
            this.lblCanalVenta.Padding = new System.Windows.Forms.Padding(3);
            this.lblCanalVenta.Size = new System.Drawing.Size(385, 22);
            this.lblCanalVenta.TabIndex = 25;
            // 
            // frmLineaCredito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(410, 238);
            this.Controls.Add(this.lblCanalVenta);
            this.Controls.Add(this.txtImporteFactura);
            this.Controls.Add(this.txtImporteCredilana);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbTipoDima);
            this.Controls.Add(this.lblTipoDima);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Name = "frmLineaCredito";
            this.Text = "Linea Crédito";
            this.Load += new System.EventHandler(this.frmLineaCredito_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Label lblTipoDima;
        private System.Windows.Forms.ComboBox cmbTipoDima;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtImporteFactura;
        private System.Windows.Forms.TextBox txtImporteCredilana;
        private System.Windows.Forms.Label lblCanalVenta;
    }
}