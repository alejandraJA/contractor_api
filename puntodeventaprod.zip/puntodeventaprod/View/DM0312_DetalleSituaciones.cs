﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class Dm0312DetalleSituaciones : Form
    {
        public static int IdVenta;
        public static string Estatus;
        public static string Mov;
        public static string MovId;
        public static List<MSituaciones> Situaciones = new List<MSituaciones>();
        private readonly CSituaciones _controladorSituaciones = new CSituaciones();
        private readonly CDetalleVenta _controladorVta = new CDetalleVenta();
        public int ContSit;

        private readonly EventoController _eventoc = new EventoController();
        private readonly Funciones _funciones = new Funciones();
        public int PaginadoActual;
        public string RecibeMov;
        public string RecibeSituacion;
        public bool ValidaSituacion;
        private readonly List<DM0312_MExploradorVenta> _ventasSeleccionadas = new List<DM0312_MExploradorVenta>();

        public Dm0312DetalleSituaciones(List<DM0312_MExploradorVenta> ventasSeleccionadas = null)
        {
            InitializeComponent();
            MaximizeBox = false;
            MinimizeBox = false;
            if (_ventasSeleccionadas == null) return;
            _ventasSeleccionadas = ventasSeleccionadas;
            PaginadoActual = ventasSeleccionadas != null && ventasSeleccionadas.Count - 1 >= 0
                ? ventasSeleccionadas.Count - 1
                : 0;
        }

        ~Dm0312DetalleSituaciones()
        {
            GC.Collect();
        }

        private static string GetTipoUsuario()
        {
            return ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        }

        /// <summary>
        ///     Realiza el cambio de situacion
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        private void Aceptar_Click(object sender, EventArgs e)
        {
            int sucursal = Convert.ToInt32(_ventasSeleccionadas[PaginadoActual].Sucursal);
            bool videoLlamada = _eventoc.validarVideoLlamada();
            if ((sucursal == 504 || sucursal == 505) && Mov == "Analisis Credito" && videoLlamada)
            {
                List<MClaveEvento> eventos = _eventoc.ValidaEvento(IdVenta);

                string argumentosPlugin = IdVenta + " " + ClaseEstatica.Usuario.usuario;


                if (eventos[0].MEN00144 == "SI" && eventos[0].MEN00125 == "NO" &&
                    eventos[0].MEN00133 == "NO" && eventos[0].MEN00134 == "NO")
                {
                    if (eventos[0].MEN00119 == "SI" && eventos[0].MEN00120 == "SI" &&
                        eventos[0].MEN00121 == "SI")
                    {
                        CambiarSituacion();
                        ValidaSituacion = true;
                        Close();
                    }
                    else
                    {
                        //llama el formulario y dependiendo el resultado del formulario Cambia la situacion
                        if (_funciones.FileExist(ClaseEstatica.plugInPath + "ValidacionVideoLlamada" + "\\" +
                                                 @"autenticacionVideoLlamada.exe"))
                        {
                            string rInvestigacion = _controladorVta.EjecutarPluginsVideoLlamada(argumentosPlugin,
                                ClaseEstatica.plugInPath + "ValidacionVideoLlamada" + "\\");


                            if (!new[] { "MEN00121", "MEN00133", "MEN00134", "MEN00125" }.Contains(
                                    rInvestigacion)) return;
                            string tipoUsuario = GetTipoUsuario();

                            // GESSY 1286 acceso Normal para Credito
                            if (tipoUsuario != "CREDI" && tipoUsuario != "VENTP" && tipoUsuario != "VENTR") return;
                            //mostrarEventosNotasCitasView();
                            AgregarEvento();
                            ValidaSituacion = true;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(@"No se encuentra el plugins instalado", @"Error!", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    CambiarSituacion();
                    Close();
                }
            }
            else
            {
                CambiarSituacion();
                Close();
            }
        }

        private void CambiarSituacion()
        {
            CDetalleVenta cDetalleVenta = new CDetalleVenta();
            if (_ventasSeleccionadas[PaginadoActual].Situacion.Equals("Evaluacion Envio - Almacen") &&
                !ClaseEstatica.Usuario.Grupo.Equals("ALMACEN"))
            {
                MessageBox.Show(@"Para pasar esta situacion, es necesario la Herramienta Costeo Fletes");
                return;
            }

            //-Dineralia
            if (cb_situacion.Text == @"Aceptado" && _ventasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                _ventasSeleccionadas[PaginadoActual].EnviarA == "77" &&
                _ventasSeleccionadas[PaginadoActual].Estatus == "PENDIENTE")
                //aqui valido que la tabla de la validacion esta bien
                if (!_controladorSituaciones.validacionDineralia(_ventasSeleccionadas[PaginadoActual].ID,
                        _ventasSeleccionadas[PaginadoActual].Cliente))
                {
                    MessageBox.Show(
                        @"El movimiento " + _ventasSeleccionadas[PaginadoActual].Mov +
                        @" no se encuentra validado, favor de revisar", @"Dineralia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

            if (_controladorSituaciones.validarSituacion(cb_situacion.Text))
                if (_controladorSituaciones.validarArticulo(_ventasSeleccionadas[PaginadoActual].ID))
                {
                    DM0312_CPuntoDeVenta pv = new DM0312_CPuntoDeVenta();
                    DM0312_CPuntoDeVenta cpv = new DM0312_CPuntoDeVenta();
                    string sCategoriaVenta =
                        pv.obtenerCategoriaVenta(int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));

                    if (_ventasSeleccionadas[PaginadoActual].Mov == "Analisis Credito" &&
                        sCategoriaVenta == "CREDITO MENUDEO")
                    {
                        PuntoDeVenta puntoDeVenta = new PuntoDeVenta(_ventasSeleccionadas[PaginadoActual].Cliente,
                            int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));
                        if (_ventasSeleccionadas[PaginadoActual].TipoCliente == "Casa")
                            if (!puntoDeVenta.validarMops(_ventasSeleccionadas[PaginadoActual].Cliente,
                                    int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA),
                                    _ventasSeleccionadas[PaginadoActual].Condicion,
                                    _ventasSeleccionadas[PaginadoActual].TipoCliente,
                                    _ventasSeleccionadas[PaginadoActual].Importe))
                            {
                                bool bUsuarioFacultado = _controladorSituaciones.validarUsuario();
                                if (!bUsuarioFacultado)
                                {
                                    MessageBox.Show(
                                        @"No cuenta con facultad para autorizar" + Environment.NewLine +
                                        @"importes que exceden la Política," + Environment.NewLine +
                                        @"Notifique a su Jefe...", @"Atencion!!!", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                    return;
                                }

                                string ultimoEvento =
                                    cpv.obtenerUltimoEvento(_ventasSeleccionadas[PaginadoActual].ID);
                                int iDocumentos =
                                    cpv.obtenerDocumentos(_ventasSeleccionadas[PaginadoActual].Condicion);
                                string ultimoEventoFacultado =
                                    cpv.ultimoEventoUsuarioActivo(_ventasSeleccionadas[PaginadoActual].ID);
                                _controladorSituaciones.insertarUsuarioFacultado(_ventasSeleccionadas[PaginadoActual],
                                    iDocumentos, ultimoEvento, ultimoEventoFacultado);
                            }

                        if (_ventasSeleccionadas[PaginadoActual].TipoCliente == "Nuevo")
                        {
                            string sTipoCreditoCliente =
                                _controladorSituaciones.obtenerTipoPolitica(
                                    _ventasSeleccionadas[PaginadoActual].Cliente);
                            int iDocumentos = cpv.obtenerDocumentos(_ventasSeleccionadas[PaginadoActual].Condicion);
                            double dMontoPolitica = _controladorSituaciones.obtenerMontoPolitica(sTipoCreditoCliente,
                                iDocumentos, int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));
                            double dImporteVenta =
                                _controladorSituaciones.obtenerImporteVenta(_ventasSeleccionadas[PaginadoActual].ID);

                            if (dImporteVenta > dMontoPolitica)
                            {
                                bool bUsuarioFacultado = _controladorSituaciones.validarUsuario();
                                if (!bUsuarioFacultado)
                                {
                                    MessageBox.Show(
                                        @"No cuenta con facultad para autorizar" + Environment.NewLine +
                                        @"importes que exceden la Política," + Environment.NewLine +
                                        @"Notifique a su Jefe...", @"Atencion!!!", MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                                    return;
                                }

                                string ultimoEvento =
                                    cpv.obtenerUltimoEvento(_ventasSeleccionadas[PaginadoActual].ID);
                                string ultimoEventoFacultado =
                                    cpv.ultimoEventoUsuarioActivo(_ventasSeleccionadas[PaginadoActual].ID);
                                _controladorSituaciones.insertarUsuarioFacultado(_ventasSeleccionadas[PaginadoActual],
                                    iDocumentos, ultimoEvento, ultimoEventoFacultado);
                            }
                        }
                    }
                }


            if (ContSit == 1)
            {
                string beneficiario = cDetalleVenta.BeneficiarioFinal(IdVenta);
                if (_controladorSituaciones.ClienteVenta(IdVenta).Contains("P") || beneficiario.Contains("P"))
                {
                    if (_controladorSituaciones.ListaSituacionesProspecto(cb_situacion.Text) != "NO")
                    {
                        if (beneficiario.Contains("P"))
                        {
                            MessageBox.Show(
                                $@"No puede agregar situacion de {cb_situacion.Text} hasta no otorgar numero de cuenta F al beneficiario final del cliente. ",
                                @"Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            if (_controladorSituaciones.ClienteVenta(IdVenta).Contains("P"))
                                MessageBox.Show(
                                    $@"No puede agregar situacion de {cb_situacion.Text} hasta no otorgar numero de cuenta. ",
                                    @"Advertencia!!", MessageBoxButtons.OK,
                                    MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        //ControladorSituaciones.CambiarSituacion(cb_situacion.Text);
                        //-TipoDima ↓ 2019-05-25
                        _controladorSituaciones.CambiarSituacion(cb_situacion.Text,
                            _ventasSeleccionadas[PaginadoActual].Mov,
                            int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));
                        _ventasSeleccionadas[PaginadoActual].Situacion = cb_situacion.Text;
                        ValidaSituacion = true;
                        Close();
                    }
                }
                else
                {
                    //ControladorSituaciones.CambiarSituacion(cb_situacion.Text);
                    //-TipoDima ↓ 2019-05-25
                    _controladorSituaciones.CambiarSituacion(cb_situacion.Text,
                        _ventasSeleccionadas[PaginadoActual].Mov,
                        int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));
                    _ventasSeleccionadas[PaginadoActual].Situacion = cb_situacion.Text;
                    ValidaSituacion = true;
                    Close();
                }
            }
            else
            {
                //ControladorSituaciones.CambiarSituacion(cb_situacion.Text);
                //-TipoDima ↓ 2019-05-25
                _controladorSituaciones.CambiarSituacion(cb_situacion.Text, _ventasSeleccionadas[PaginadoActual].Mov,
                    int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA));
                _ventasSeleccionadas[PaginadoActual].Situacion = cb_situacion.Text;
                ValidaSituacion = true;
                Close();
            }
        }

        /// <summary>
        ///     Load de situaciones
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 23/08/17
        private void DM0312_Situaciones_Load(object sender, EventArgs e)
        {
            CDetalleVenta detalle = new CDetalleVenta();
            if (ValidaSituacion && RecibeMov != "Solicitud Credito")
            {
                lbl_fechaSeguimiento.Text = detalle.ObtenerFechaSQL()
                    .ToString("dd-MM-yy hh:mm tt", CultureInfo.InvariantCulture);
                lbl_usuario.Text = ClaseEstatica.Usuario.usuario;
                List<MSituaciones> model = CSituaciones.ObtenerSituaciones();

                MSituaciones clave = model.FirstOrDefault(x => x.Situacion.Contains(RecibeSituacion));
                if (clave != null)
                {
                    cb_situacion.DataSource = model;
                    cb_situacion.ValueMember = "ID";
                    cb_situacion.DisplayMember = "Situacion";
                    cb_situacion.Text = RecibeSituacion;
                }
                else
                {
                    MessageBox.Show(@"Situación No Válida", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Dispose();
                }
            }
            else
            {
                cb_situacion.DataSource = Situaciones;
                cb_situacion.ValueMember = "ID";
                cb_situacion.DisplayMember = "Situacion";
                if (cb_situacion.Items.Count > 1) cb_situacion.SelectedIndex = cb_situacion.SelectedIndex + 1;

                lbl_fechaSeguimiento.Text = detalle.ObtenerFechaSQL()
                    .ToString("dd-MM-yy hh:mm tt", CultureInfo.InvariantCulture);
                Text = $@"Situación - {Mov} {MovId}";
                lbl_usuario.Text = ClaseEstatica.Usuario.usuario;
            }

            txt_Comentarios.Text = @"ASISTENTE PARA CAMBIAR LA SITUACION DE LA VENTA";
            toolTip1.SetToolTip(Aceptar, "SELECCIONAR SI SE DESEA CAMBIAR LA SITUACION");
            toolTip1.SetToolTip(btn_Cancelar, "CANCELAR EL CAMBIO DE SITUACION");
            toolTip1.SetToolTip(btn_retroceder,
                "SELECCIONAR PARA MANDAR LLAMAR LA SITUACION QUE SE TENIA ANTES DEL CAMBIO");
            toolTip1.SetToolTip(label1, "LISTADO DE LAS POSIBLES SITUACIONES A CAMBIAR DEPENDIENDO EL MOVIMIENTO");
        }

        /// <summary>
        ///     Cierra formulario o dialogo en su defecto...
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        private void Btn_Cancelar_Click(object sender, EventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_AgregarEvento")
                {
                    forma.Show();
                    break;
                }

            Close();
        }

        /// <summary>
        ///     Mueve una situacion atras del combobox
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 24/08/17
        private void Btn_retroceder_Click(object sender, EventArgs e)
        {
            if (cb_situacion.SelectedIndex > 0) cb_situacion.SelectedIndex = cb_situacion.SelectedIndex - 1;
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleSituaciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_AgregarEvento")
                    {
                        forma.Show();
                        break;
                    }

                Close();
            }

            if (e.Control && e.KeyCode == Keys.G) CambiarSituacion();
        }

        private void AgregarEvento()
        {
            DM0312_AgregarEvento.list.Clear();
            DM0312_AgregarEvento.recibeTexto = "";
            DM0312_AgregarEvento agregEvent = new DM0312_AgregarEvento();
            agregEvent.recibeMensaje = 1;
            agregEvent.recibeIdVenta = Convert.ToString(_ventasSeleccionadas[PaginadoActual].ID);
            agregEvent.recibeUsuario = ClaseEstatica.Usuario.Usser;
            agregEvent.recibeSucursal = Convert.ToString(_ventasSeleccionadas[PaginadoActual].Suc);
            agregEvent.recibeEstatus = _ventasSeleccionadas[PaginadoActual].Estatus;
            agregEvent.recibeMov = _ventasSeleccionadas[PaginadoActual].Mov;
            agregEvent.recibeMovId = _ventasSeleccionadas[PaginadoActual].MovId;
            agregEvent.recibeSituacion = _ventasSeleccionadas[PaginadoActual].Situacion;
            agregEvent.recibeCliente = _ventasSeleccionadas[PaginadoActual].Cliente;
            agregEvent.iCanalVenta = int.Parse(_ventasSeleccionadas[PaginadoActual].EnviarA);
            agregEvent.recibeIdecommerce = _ventasSeleccionadas[PaginadoActual].IDEcommerce;
            agregEvent.ShowDialog();
        }

        private void txt_Comentarios_TextChanged(object sender, EventArgs e)
        {
        }
    }
}