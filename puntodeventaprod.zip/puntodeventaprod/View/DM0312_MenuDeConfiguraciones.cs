﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class DM0312_MenuDeConfiguraciones : Form
    {
        public DM0312_MenuDeConfiguraciones()
        {
            InitializeComponent();
        }

        ~DM0312_MenuDeConfiguraciones()
        {
            GC.Collect();
        }

        #region "Handles"

        private void btn_ConfiguracionComp_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "DM0312_PermisosConfiguracion")
                .SingleOrDefault();
            if (existe != null)
            {
                existe.WindowState = FormWindowState.Normal;
                existe.BringToFront();
            }
            else
            {
                DM0312_PermisosConfiguracion form = new DM0312_PermisosConfiguracion();
                form.StartPosition = FormStartPosition.CenterParent;
                form.MaximizeBox = false;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.ShowDialog();
            }
        }

        private void btn_ConfiguracionComent_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "DM0312_ComentariosVenta")
                .SingleOrDefault();
            if (existe != null)
            {
                existe.WindowState = FormWindowState.Normal;
                existe.BringToFront();
            }
            else
            {
                DM0312_ComentariosVenta form = new DM0312_ComentariosVenta();
                form.StartPosition = FormStartPosition.CenterParent;
                form.MaximizeBox = false;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.ShowDialog();
            }
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    DM0312_Promociones promocion = new DM0312_Promociones();
        //    promocion.ShowDialog();
        //}

        #endregion
    }
}