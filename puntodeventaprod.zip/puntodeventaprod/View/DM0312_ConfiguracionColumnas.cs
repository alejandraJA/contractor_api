﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta
{
    public partial class ConfiguracionColumnas : Form
    {
        private readonly ConfigColumnas CColumnas = new ConfigColumnas();

        public ConfiguracionColumnas()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        ~ConfiguracionColumnas()
        {
            GC.Collect();
        }

        private void chk_Rosa_CheckedChanged(object sender, EventArgs e)
        {
            //if (chk_Rosa.Checked)
            //{
            //    chk_Azul.Checked = false;
            //    chk_Verde.Checked = false;
            //    chk_gris.Checked = false;
            //}
        }

        private void chk_Azul_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Azul.Checked)
            {
                chk_Verde.Checked = false;
                chk_gris.Checked = false;
                //chk_Rosa.Checked = false;
            }
        }

        private void chk_Verde_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Verde.Checked)
            {
                chk_Azul.Checked = false;
                chk_gris.Checked = false;
                //chk_Rosa.Checked = false;
            }
        }

        private void chk_gris_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_gris.Checked)
            {
                chk_Azul.Checked = false;
                chk_Verde.Checked = false;
                //chk_Rosa.Checked = false;
            }
        }

        #region "Handlers"

        private void ConfiguracionColumnas_Load(object sender, EventArgs e)
        {
            string color;
            //btn_UpPosition.Visible = false;
            //btnDownPosition.Visible = false;
            color = CColumnas.TipoColor(ClaseEstatica.Usuario.Acceso);
            if (color == "Azul")
            {
                chk_Azul.Checked = true;
            }
            else if (color == "Rosa")
            {
                //chk_Rosa.Checked = true;
            }
            else if (color == "Verde")
            {
                chk_Verde.Checked = true;
            }
            else if (color == "Gris")
            {
                chk_gris.Checked = true;
            }

            txt_Comentarios.Text =
                "HERRAMIENTA DONDE SE PODRA CONFIGURAR LAS COLUMNAS DEL TABLERO PRINCIPAL, LOS CAMPOS QUE SE ENCUENTRAN EN LA TABLA DE COLUMNAS EN USO SON LAS QUE EL USUARIO PODRA MANIPULAR DE IGUAL FORMA SE PODRA MODIFICAR EL ORDEN EN EL QUE SE MUESTRE CADA COLUMNA";
            toolTip1.SetToolTip(Aceptar, "SELECCIONAR SI YA CONFIGURO DE MANERA CORRECTO EL TABLERO DEL EXPLORADOR");
            toolTip1.SetToolTip(btn_Agregar, "AGREGAR LA COLUMNA SELECCIONADA");
            toolTip1.SetToolTip(btn_Quitar, "QUITAR LA COLUMNA SELECCIONADA");
            toolTip1.SetToolTip(btn_UpPosition, "CAMBIAR POSICION DEL CAMPO HACIA ARRIBA");
            toolTip1.SetToolTip(btnDownPosition, "CAMBIAR POSICION DEL CAMPO HACIA ABAJO");
            data_GridColumnaUso.Rows.Clear();
            data_GridColumnas.Rows.Clear();

            List<AccesoColumnas> PosicionColumna = ConfigColumnas.AccesoColumnas.OrderBy(x => x.Orden).ToList();

            foreach (AccesoColumnas Columna in PosicionColumna)
                if (Columna.Estatus)
                    data_GridColumnaUso.Rows.Add(Columna.NombreColumna);
                else
                    data_GridColumnas.Rows.Add(Columna.NombreColumna);

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                data_GridColumnas.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                data_GridColumnaUso.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                data_GridColumnas.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                data_GridColumnaUso.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                data_GridColumnas.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                data_GridColumnaUso.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                data_GridColumnas.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                data_GridColumnaUso.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }

        /// <summary>
        ///     Guarda los estados de la tabla
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 04/08/17
        public void GuardarC()
        {
            if (data_GridColumnaUso.Rows.Count == 0)
            {
                MessageBox.Show("Debe existir al menos una columna", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            CColumnas.GetDatagridEstatus(data_GridColumnaUso);
            List<AccesoColumnas> PosicionColumna = ConfigColumnas.AccesoColumnas.OrderBy(x => x.Orden).ToList();
            foreach (AccesoColumnas AColumna in PosicionColumna)
                if (CColumnas.UsuarioConfigurado(AColumna.NombreColumna) != "")
                    CColumnas.updateColumnas(ClaseEstatica.Usuario.Usser, AColumna.NombreColumna, AColumna.Orden,
                        AColumna.Estatus);
                else
                    CColumnas.InsertColumnas(AColumna.NombreColumna, AColumna.Orden, AColumna.Estatus);
            //if (!AColumna.UpdateConfig)
            //{
            //    BulkInsert = true;
            //    break;
            //}
            ////if (BulkInsert)
            ////{
            ////    if (CColumnas.UsuarioConfigurado() != "")
            ////    {
            ////        CColumnas.BulkUpdateDataTable();
            ////    }
            ////    else
            ////    {
            ////        CColumnas.BulkInsertDataTable();
            ////    }

            ////}
            //else
            //{
            //    CColumnas.BulkUpdateDataTable();
            //}
            Close();
        }

        private void Aceptar_Click(object sender, EventArgs e)
        {
            GuardarC();

            if (chk_Azul.Checked)
            {
                ClaseEstatica.Usuario.color = "Azul";
                CColumnas.ActualizarColor(ClaseEstatica.Usuario.color, ClaseEstatica.Usuario.Acceso, 1);
                CColumnas.ActualizarColor("Rosa", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Verde", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Gris", ClaseEstatica.Usuario.Acceso, 2);
            }
            //else
            //    if (chk_Rosa.Checked)
            //    {
            //        ClaseEstatica.Usuario.color = "Rosa";
            //        CColumnas.ActualizarColor(ClaseEstatica.Usuario.color, ClaseEstatica.Usuario.Acceso, 1);
            //        CColumnas.ActualizarColor("Azul", ClaseEstatica.Usuario.Acceso, 2);
            //        CColumnas.ActualizarColor("Verde", ClaseEstatica.Usuario.Acceso, 2);
            //        CColumnas.ActualizarColor("Gris", ClaseEstatica.Usuario.Acceso, 2);
            //    }
            else if (chk_Verde.Checked)
            {
                ClaseEstatica.Usuario.color = "Verde";
                CColumnas.ActualizarColor(ClaseEstatica.Usuario.color, ClaseEstatica.Usuario.Acceso, 1);
                CColumnas.ActualizarColor("Rosa", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Azul", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Gris", ClaseEstatica.Usuario.Acceso, 2);
            }
            else if (chk_gris.Checked)
            {
                ClaseEstatica.Usuario.color = "Gris";
                CColumnas.ActualizarColor(ClaseEstatica.Usuario.color, ClaseEstatica.Usuario.Acceso, 1);
                CColumnas.ActualizarColor("Rosa", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Verde", ClaseEstatica.Usuario.Acceso, 2);
                CColumnas.ActualizarColor("Azul", ClaseEstatica.Usuario.Acceso, 2);
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void gbx_Eventos_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        /// <summary>
        ///     Quita una columna de columnas en uso
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 04/08/17
        private void btn_Quitar_Click_2(object sender, EventArgs e)
        {
            if (data_GridColumnaUso.Rows.Count > 0)
            {
                data_GridColumnas.Rows.Add(
                    Convert.ToString(data_GridColumnaUso[0, data_GridColumnaUso.CurrentRow.Index].Value));
                data_GridColumnaUso.Rows.RemoveAt(data_GridColumnaUso.CurrentRow.Index);
            }
        }

        /// <summary>
        ///     Agrega una columna a columnas en uso
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 04/08/17
        private void btn_Agregar_Click_1(object sender, EventArgs e)
        {
            if (data_GridColumnas.Rows.Count > 0)
            {
                data_GridColumnaUso.Rows.Add(
                    Convert.ToString(data_GridColumnas[0, data_GridColumnas.CurrentRow.Index].Value));
                data_GridColumnas.Rows.RemoveAt(data_GridColumnas.CurrentRow.Index);
            }
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void ConfiguracionColumnas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.Control && e.KeyCode == Keys.G) GuardarC();
        }

        /// <summary>
        ///     Mueve la fila seleccionada hacia arriba
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        private void btn_UpPosition_Click(object sender, EventArgs e)
        {
            if (data_GridColumnaUso.Rows.Count > 0)
            {
                int rowCount = data_GridColumnaUso.Rows.Count;
                int index = data_GridColumnaUso.SelectedCells[0].OwningRow.Index;

                if (index == 0) return;
                DataGridViewRowCollection rows = data_GridColumnaUso.Rows;

                // remove the previous row and add it behind the selected row.
                DataGridViewRow prevRow = rows[index - 1];
                rows.Remove(prevRow);
                prevRow.Frozen = false;
                rows.Insert(index, prevRow);
                data_GridColumnaUso.ClearSelection();
                data_GridColumnaUso.Rows[index - 1].Selected = true;
                data_GridColumnaUso.FirstDisplayedScrollingRowIndex = index - 1;
            }
        }

        /// <summary>
        ///     Mueve la fila seleccionada hacia abajo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 02/12/17
        private void btnDownPosition_Click(object sender, EventArgs e)
        {
            if (data_GridColumnaUso.Rows.Count > 0)
            {
                int rowCount = data_GridColumnaUso.Rows.Count;
                int index = data_GridColumnaUso.SelectedCells[0].OwningRow.Index;

                if (index == rowCount - 1) // include the header row
                    return;
                DataGridViewRowCollection rows = data_GridColumnaUso.Rows;

                // remove the next row and add it in front of the selected row.
                DataGridViewRow nextRow = rows[index + 1];
                rows.Remove(nextRow);
                nextRow.Frozen = false;
                rows.Insert(index, nextRow);
                data_GridColumnaUso.ClearSelection();
                data_GridColumnaUso.Rows[index + 1].Selected = true;
                data_GridColumnaUso.FirstDisplayedScrollingRowIndex = index + 1;
            }
        }

        #endregion
    }
}