﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using Conversiones;
using fnPassword;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_Redime : Form
    {
        public int Canal;

        private readonly DM0312_CPuntoDeVenta controladorv = new DM0312_CPuntoDeVenta();
        private readonly DM0312_CVentanaEntrada controladorve = new DM0312_CVentanaEntrada();

        private readonly DM0312_C_Redime controller = new DM0312_C_Redime();

        private readonly Conv conversion = new Conv();

        private readonly CDetalleVenta CtrlVentaDetalle = new CDetalleVenta();

        public bool Ejecuta = false;

        public int EnviarA = 0;

        private readonly Funciones funciones = new Funciones();

        //public int Sucursal { get; set; }

        public double GenSaldo;

        public bool IsCancel;

        private List<string> lista = new List<string>();

        public string Monedero;

        public bool origen = true;

        public double RedSaldo;

        public string Serie = string.Empty;

        public DM0312_Redime()
        {
            InitializeComponent();
        }

        public int idVenta { get; set; }

        public string cliente { get; set; }

        public int iUen { get; set; }

        public bool bGeneroMonedero { get; set; }

        public bool bRedimio { get; set; }

        ~DM0312_Redime()
        {
            InitializeComponent();
        }

        private void DM0312_Redime_Load(object sender, EventArgs e)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("es-MX");

            txtPwd.CharacterCasing = CharacterCasing.Upper;
            txtUser.CharacterCasing = CharacterCasing.Upper;

            txtGenSaldo.Enabled = false;
            txtRediSaldo.Enabled = false;

            //////pruebas*************
            ////cliente = "C00736868";
            ////EnviarA = 76;
            /////********************/

            BringToFront();

            Canal = controller.GetCanalVenta(idVenta);

            if (EnviarA == 76)
            {
                //dima
                int diasV = controladorve.DiasVencidosDIMA(cliente);
                int diasC = Convert.ToInt32(controladorv.DiasV());
                if (Canal == 3)
                {
                    if (diasV > diasC)
                    {
                        rbtn_Normal.Checked = true;
                        return;
                    }

                    rbtn_Virtual.Checked = true;
                    Load_dima();
                }
                else
                {
                    rbtn_Virtual.Checked = true;
                    Load_dima();
                }
            }
            else
            {
                //redime normal
                Load_();
            }
        }


        private bool GenerarOrRedimir(string cuenta, double importe)
        {
            if (controller.InsertInTarjetaSerieMovMAVI(idVenta, cuenta, ClaseEstatica.Usuario.sucursal, importe))
            {
                if (origen)
                {
                    if (controller.RedimirMonedero(idVenta))
                    {
                        bRedimio = true;
                        return true;
                    }
                }
                else
                {
                    if (controller.GenerarMonedero(idVenta))
                    {
                        bGeneroMonedero = true;
                        return true;
                    }
                }

                MessageBox.Show("Error al generar monedero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                bGeneroMonedero = false;
                return false;
            }

            MessageBox.Show("Error al insertar tarjeta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            bGeneroMonedero = false;
            return false;
        }

        private void txtRediNoMone_Validating(object sender, CancelEventArgs e)
        {
            if (!rbtn_Virtual.Focused && !btnCancelar.Focused)
            {
                if (rbtn_Normal.Checked)
                {
                    if (!controller.validarMonedero(txtRediNoMone.Text, 0))
                    {
                        if (txtRediNoMone.Text == "")
                        {
                            MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            txtRediNoMone.Text = "";
                        }
                        else
                        {
                            if (txtRediNoMone.Text.Trim().Length < 8)
                            {
                                MessageBox.Show("El numero: " + txtRediNoMone.Text + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtRediNoMone.Text = "";
                            }
                            else
                            {
                                MessageBox.Show(
                                    "El numero: " + txtRediNoMone.Text.Substring(0, 8) + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtRediNoMone.Text = "";
                            }
                        }

                        txtRediNoMone.Focus();
                    }
                    else
                    {
                        if (txtRediNoMone.Text.Trim().Length < 8)
                        {
                            txtRediSaldo.Text = "$0.00";
                        }
                        else
                        {
                            string cuenta = txtRediNoMone.Text.Substring(0, 8);
                            RedSaldo = controller.GetSaldo(cuenta);
                            RedSaldo = Math.Truncate(100.0 * RedSaldo) / 100.0;
                            txtRediSaldo.Text = RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture);
                            if (cuenta != string.Empty) txtRediImporte.Focus();
                        }
                    }
                }
                else
                {
                    if (rbtn_Virtual.Checked)
                    {
                        if (txtRediNoMone.Text.Trim().Length < 8)
                        {
                            txtRediSaldo.Text = "$0.00";
                        }
                        else
                        {
                            string cuenta = txtRediNoMone.Text.Substring(0, 8);

                            RedSaldo = controller.GetSaldo(cuenta);

                            RedSaldo = Math.Truncate(100 * RedSaldo) / 100;

                            txtRediSaldo.Text =
                                RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + RedSaldo;

                            if (cuenta != string.Empty)
                                txtRediImporte.Focus();
                        }
                    }

                    else
                    {
                        if (!controller.validarMonedero(txtRediNoMone.Text, 0))
                        {
                            if (txtRediNoMone.Text == "")
                            {
                                MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                if (txtRediNoMone.Text.Trim().Length < 8)
                                {
                                    MessageBox.Show("El numero: " + txtRediNoMone.Text + " no es un monedero correcto",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    txtRediNoMone.Text = "";
                                }
                                else
                                {
                                    MessageBox.Show(
                                        "El numero: " + txtRediNoMone.Text.Substring(0, 8) +
                                        " no es un monedero correcto", "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Hand);
                                    txtRediNoMone.Text = "";
                                }
                            }

                            txtRediNoMone.Focus();
                        }
                        else
                        {
                            if (txtRediNoMone.Text.Trim().Length < 8)
                            {
                                txtRediSaldo.Text = "$0.00";
                            }
                            else
                            {
                                string cuenta = txtRediNoMone.Text.Substring(0, 8);
                                RedSaldo = controller.GetSaldo(cuenta);
                                RedSaldo = Math.Truncate(100.0 * RedSaldo) / 100.0;
                                txtRediSaldo.Text = RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture);
                                if (cuenta != string.Empty) txtRediImporte.Focus();
                            }
                        }
                    }
                }
            }
            //if (txtRediNoMone.Text.Trim().Length < 8)
            //{
            //    txtRediSaldo.Text = "$0.00";
            //}
            //else
            //{
            //    string cuenta = txtRediNoMone.Text.Substring(0, 8);

            //    RedSaldo = controller.GetSaldo(cuenta);

            //    RedSaldo = Math.Truncate(100 * RedSaldo) / 100;

            //    txtRediSaldo.Text = RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture);//"$" + RedSaldo;

            //    if (cuenta != string.Empty)
            //        txtRediImporte.Focus();

            //}
        }

        private void txtGenNoMone_Validating(object sender, CancelEventArgs e)
        {
            if (txtGenNoMone.Visible)
            {
                if (rbtn_Normal.Checked)
                {
                    if (controller.validarMonedero(txtGenNoMone.Text, 0))
                    {
                        GetSaldo();
                    }
                    else
                    {
                        if (txtGenNoMone.Text == "")
                        {
                            MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            txtGenNoMone.Text = "";
                        }
                        else
                        {
                            if (txtGenNoMone.Text.Trim().Length < 8)
                            {
                                MessageBox.Show("El numero: " + txtGenNoMone.Text + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtGenNoMone.Text = "";
                            }
                            else
                            {
                                MessageBox.Show(
                                    "El numero: " + txtGenNoMone.Text.Substring(0, 8) + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtGenNoMone.Text = "";
                            }
                        }

                        txtGenNoMone.Focus();
                    }
                }
                else if (!rbtn_Normal.Checked && !rbtn_Virtual.Checked)
                {
                    if (txtGenNoMone.ReadOnly)
                    {
                        GetSaldo();
                    }
                    else if (controller.validarMonedero(txtGenNoMone.Text, 0))
                    {
                        GetSaldo();
                    }
                    else
                    {
                        if (txtGenNoMone.Text == "")
                        {
                            MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            if (txtGenNoMone.Text.Trim().Length < 8)
                                MessageBox.Show("El numero: " + txtGenNoMone.Text + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            else
                                MessageBox.Show(
                                    "El numero: " + txtGenNoMone.Text.Substring(0, 8) + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }

                        txtGenNoMone.Focus();
                    }
                }
                else
                {
                    GetSaldo();
                }
            }
        }

        private void DM0312_Redime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                if (btnCancelar.Visible)
                    Close();
            if (e.Control && e.KeyCode == Keys.G)
                if (btnAceptar.Visible)
                {
                    if (!validarUsuario())
                        return;

                    if (EnviarA == 76)
                    {
                        //dima
                        double importe =
                            conversion.ConvertFormatMoney(txtRediImporte
                                .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                        double saldo =
                            conversion.ConvertFormatMoney(txtRediSaldo
                                .Text); //Convert.ToDouble(txtRediSaldo.Text.Replace("$", ""));

                        if (importe <= 0)
                        {
                            MessageBox.Show("El importe tiene que ser mayor a 0", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            return;
                        }

                        if (importe > saldo)
                        {
                            MessageBox.Show("El importe no puede ser mayor al saldo", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            return;
                        }

                        Enviar76AVenta();
                    }
                    else
                    {
                        //normales
                        if (!OperacionesMonedero())
                            return;
                    }

                    Close();
                }
        }

        private void txtUser_Validating(object sender, CancelEventArgs e)
        {
            //validadUsuarioMone();
        }

        private void txtUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
                if (validadUsuarioMone())
                    txtPwd.Focus();
        }

        public bool validadUsuarioMone()
        {
            if (CtrlVentaDetalle.SMStablaConversionSegurosValor() == "1")
            {
                lista = controller.ValidaUsrMone(txtUser.Text);
                if (txtUser.Text == "")
                {
                    MessageBox.Show("Debe ingresar un Usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUser.Focus();
                    return false;
                }

                if (lista[0] == "NO")
                {
                    MessageBox.Show("Usuario Incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUser.Text = "";
                    txtPwd.Text = "";
                    txtUser.Focus();
                    return false;
                }

                txtPwd.Focus();
            }

            return true;
        }

        private void txtPwd_Validating(object sender, CancelEventArgs e)
        {
            //validadContraMone();
        }

        public bool validadContraMone()
        {
            if (CtrlVentaDetalle.SMStablaConversionSegurosValor() == "1")
            {
                if (txtUser.Text == "")
                {
                    MessageBox.Show("Ingresa el Usuario para poder ingresar la contraseña", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUser.Focus();
                    txtUser.Text = "";
                    return false;
                }

                if (txtPwd.Text == "")
                {
                    MessageBox.Show("Ingresa una contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPwd.Focus();
                    return false;
                }

                int valor = 0;
                valor = controller.ValidaContraMenu(idVenta, lista[0],
                    Intelisis.getHash(txtPwd.Text.ToUpper(), "P") /*CDetalleVenta.MD5Hash(txtPwd.Text.ToUpper())*/);
                if (valor != 0)
                {
                    MessageBox.Show("Contraseña incorrecta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPwd.Text = "";
                    txtPwd.Focus();
                    return false;
                }
            }

            return true;
        }

        private void txtPwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                //validadContraMone();
            }
        }

        #region metodos

        public void Load_()
        {
            groupBoxDimaTipo.Visible = false;

            int i = controller.MostrarUsrValido(idVenta);

            if (i == 0 && controller.CondicionEjecutar(idVenta) == false)
            {
                groupBoxAutoriza.Visible = true;
            }
            else
            {
                groupBoxAutoriza.Visible = false;
                Height = 200;
            }

            if (origen)
            {
                //redime
                //Monedero = controller.GetMonedero(cliente);
                Height = 290;
                groupBoxGenera.Visible = false;
            }
            else
            {
                //genera
                if (Canal != 76 && controller.CondicionEjecutar(idVenta) == false)
                {
                    groupBoxRedime.Visible = false;
                    btnCancelar.Visible = false;
                    Height = 270;
                }
                else
                {
                    groupBoxRedime.Visible = false;

                    //this.Height = 270;

                    if (Canal == 76)
                        //dima
                        btnCancelar.Visible = false;
                    else
                        btnCancelar.Visible = false;

                    string serie = controller.GetSerieMonedero(idVenta);

                    if (serie != string.Empty)
                    {
                        txtGenNoMone.Text = serie;
                        txtGenNoMone.ReadOnly = true;

                        string cuenta = txtGenNoMone.Text.Substring(0, 8);

                        GenSaldo = controller.GetSaldo(cuenta);

                        GenSaldo = Math.Truncate(100 * GenSaldo) / 100;

                        txtGenSaldo.Text =
                            GenSaldo.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + GenSaldo;

                        btnAceptar_Click(null, null);

                        btnAceptar.Select();
                    }
                }
            }
        }

        public void Load_dima()
        {
            txtRediImporte.Text = "$0.0";

            //cambio erika
            if (controller.MostrarUsrValido(idVenta) == 1 /* || controller.CondicionEjecutar(idVenta)*/)
            {
                groupBoxAutoriza.Visible = false;
                int Height = this.Height;
                Height = Height - 73;
                this.Height = Height;
            }
            else
            {
                groupBoxAutoriza.Visible = true;
            }


            groupBoxGenera.Visible = false;
            groupBoxRedime.Text = "Dima Redime Puntos";

            //kikaaaaaaa
            if (Canal != 76 /* && controller.CondicionEjecutar(idVenta)==false*/)
            {
                if (rbtn_Virtual.Checked)
                {
                    txtRediNoMone.Text = controller.GetMonederoVirtual(cliente, iUen);
                    txtRediNoMone.Enabled = false;
                    if (txtRediNoMone.Text.Length == 0)
                    {
                        MessageBox.Show("El cliente:" + cliente + " no tiene monedero virtual", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }

                    txtRediSaldo.Text = controller.GetSaldo(txtRediNoMone.Text)
                        .ToString("C",
                            Thread.CurrentThread
                                .CurrentCulture); //"$" + controller.GetSaldo(txtRediNoMone.Text).ToString();
                    txtRediImporte.Focus();
                    txtRediImporte.SelectionStart = 0;
                    txtRediImporte.SelectionLength = txtRediImporte.Text.Length;
                }

                if (rbtn_Normal.Checked)
                {
                    limpiar();
                    txtRediNoMone.Enabled = true;
                    txtRediNoMone.Focus();
                    txtRediSaldo.Text = "$0.0";
                }
            }
            else
            {
                groupBoxDimaTipo.Visible = false;

                txtRediNoMone.Text = controller.GetMonederoVirtual(cliente, iUen);
                txtRediNoMone.Enabled = false;
                if (txtRediNoMone.Text.Length == 0)
                {
                    MessageBox.Show("El cliente:" + cliente + " no tiene monedero virtual", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                txtRediSaldo.Text = controller.GetSaldo(txtRediNoMone.Text)
                    .ToString("C",
                        Thread.CurrentThread
                            .CurrentCulture); //"$" + controller.GetSaldo(txtRediNoMone.Text).ToString();
                txtRediImporte.Focus();
            }
        }

        public bool validarUsuario()
        {
            if (!groupBoxAutoriza.Visible)
                return true;

            if (txtUser.Text.Length == 0 && txtPwd.Text.Length == 0)
            {
                MessageBox.Show("Debe capturar usuario y contraseña", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Stop);
                return false;
            }

            {
                if (txtUser.Text.Length == 0)
                {
                    MessageBox.Show("Debe capturar un Usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (txtPwd.Text.Length == 0)
                {
                    MessageBox.Show("Debe capturar una contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (!validadUsuarioMone())
                {
                    return false;
                }

                if (!validadContraMone()) return false;
            }


            return true;
        }

        public bool OperacionesMonedero()
        {
            double importe = 0;

            string cuenta = string.Empty;

            if (origen)
            {
                if (txtRediImporte.Text.Length == 1)
                {
                    MessageBox.Show("Debe capturar un importe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                importe = conversion.ConvertFormatMoney(txtRediImporte
                    .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));

                if (txtRediNoMone.Text.Length < 8)
                {
                    MessageBox.Show("Debe capturar un Monedero Valido", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return false;
                }

                cuenta = txtRediNoMone.Text.Substring(0, 8);
            }
            else
            {
                if (txtGenNoMone.Text.Length < 8)
                {
                    MessageBox.Show("Debe capturar un Monedero Valido", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return false;
                }

                cuenta = txtGenNoMone.Text.Substring(0, 8);
            }


            //if (!validarUsuario())
            //    return false;

            //Ejecuta = controller.CondicionEjecutar(idVenta);

            if (controller.CondicionEjecutar(idVenta))
            {
                //guardar
                //string cuenta = string.Empty;

                //string saldo = txtGenSaldo.Text.Replace("$", "");

                if (Canal != 76)
                {
                    double saldo_d = conversion.ConvertFormatMoney(txtGenSaldo.Text); //Convert.ToDouble(saldo);

                    if (saldo_d <= 0.0)
                        if (origen)
                        {
                            MessageBox.Show("Debe capturar un Monedero con saldo disponible", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                }

                //if (txtGenNoMone.Text.Length < 8)
                //{
                //    MessageBox.Show("Debe capturar un Monedero Valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return false;
                //}

                //cuenta = txtGenNoMone.Text.Substring(0, 8);

                return GenerarOrRedimir(cuenta, importe);

                //if (controller.InsertInTarjetaSerieMovMAVI(idVenta, cuenta, ClaseEstatica.Usuario.sucursal, importe))
                //{
                //    if (origen)
                //    {
                //        if (controller.RedimirMonedero(idVenta))
                //        {
                //            MessageBox.Show("Se Redimio monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                //            return true;
                //        }
                //    }
                //    else
                //    {
                //        if (controller.GenerarMonedero(idVenta))
                //        {
                //            MessageBox.Show("Se genero monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                //            return true;
                //        }
                //    }
                //    MessageBox.Show("Error al generar monedero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //    return false;
                //}
                //MessageBox.Show("Error al insertar tarjeta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //return false;
            }
            //if (txtGenNoMone.Text.Length < 8)
            //{
            //    MessageBox.Show("Debe capturar un Monedero Valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return false;
            //}

            //string cuenta = txtGenNoMone.Text.Substring(0, 8);

            if (controller.validarCanal76(idVenta))
            {
                //valida usuario y password
                if (controller.AutorizaMonedero(idVenta, txtUser.Text, txtPwd.Text))
                {
                    MessageBox.Show("Autorizacion Correcta", "Salida diversa", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return GenerarOrRedimir(cuenta, importe);

                    //if (controller.InsertInTarjetaSerieMovMAVI(idVenta, cuenta, ClaseEstatica.Usuario.sucursal, importe))
                    //{
                    //    if (origen)
                    //    {
                    //        if (controller.RedimirMonedero(idVenta))
                    //        {
                    //            MessageBox.Show("Se Redimio monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                    //            return true;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        if (controller.GenerarMonedero(idVenta))
                    //        {
                    //            MessageBox.Show("Se genero monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                    //            return true;
                    //        }
                    //    }
                    //    MessageBox.Show("Error al generar monedero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //    return false;
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Error al insertar tarjeta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //    return false;
                    //}

                    //if (origen)
                    //{
                    //    if (controller.RedimirMonedero(idVenta))
                    //    {
                    //        MessageBox.Show("Se Redimio monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                    //        return true;
                    //    }
                    //}
                    //else
                    //{
                    //    if (controller.GenerarMonedero(idVenta))
                    //    {
                    //        MessageBox.Show("Se genero monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
                    //        return true;
                    //    }
                    //}

                    //MessageBox.Show("Error al generar monedero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //return false;
                }

                return false;
            }

            return GenerarOrRedimir(cuenta, importe);
            //if (controller.InsertInTarjetaSerieMovMAVI(idVenta, cuenta, ClaseEstatica.Usuario.sucursal, importe))
            //{
            //    if (origen)
            //    {
            //        if (controller.RedimirMonedero(idVenta))
            //        {
            //            MessageBox.Show("Se Redimio monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
            //            return true;
            //        }
            //    }
            //    else
            //    {
            //        if (controller.GenerarMonedero(idVenta))
            //        {
            //            MessageBox.Show("Se genero monedero", "Exito", MessageBoxButtons.OK, MessageBoxIcon.None);
            //            return true;
            //        }
            //    }
            //    MessageBox.Show("Error al generar monedero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    return false;
            //}
            //else
            //{
            //    MessageBox.Show("Error al insertar tarjeta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    return false;
            //}

            return true;
        }

        public void limpiar()
        {
            txtRediNoMone.Text = string.Empty;
            txtRediImporte.Text = string.Empty;
            txtRediSaldo.Text = string.Empty;

            txtUser.Text = string.Empty;
            txtPwd.Text = string.Empty;

            txtRediImporte.Text = "$0.0";
        }

        public bool Enviar76AVenta()
        {
            if (controller.ValidarUsuarios(idVenta, true))
            {
                if (controller.TablaNumD())
                    //SHM7
                    llamadaPlugInSHMRutaTicket();
                //return true;
                else
                    //SHMllamado
                    llamadaPlugInSHM();
                //return true;
                IsCancel = controller.ValidaTablasSHM(idVenta, Serie);

                return true;
            } //guardar

            string serie = txtRediNoMone.Text.Substring(0, 8);

            double importe =
                conversion.ConvertFormatMoney(txtRediImporte
                    .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));

            IsCancel = controller.RegistraRedencion(idVenta, serie, importe);

            return true;
        }

        private void llamadaPlugInSHM()
        {
            Serie = txtRediNoMone.Text.Substring(0, 8);
            try
            {
                //double importe = Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                //Process System = new Process();
                //System.StartInfo.WorkingDirectory = "C:\\AppsMavi\\SHM\\";
                //System.StartInfo.FileName = "C:\\AppsMavi\\SHM\\" + @"SHM.exe";
                //System.StartInfo.Verb = "runas";
                //System.StartInfo.UseShellExecute = false;
                //System.StartInfo.Arguments = "VALIDADIMA" + " " + cliente + " " + "DIMA" + " " + idVenta + " " + "MAVI" + " " + Serie + " " + importe.ToString() + " " + ClaseEstatica.Usuario.sucursal + " " + "VTAS";
                //System.Start();
                //System.WaitForExit();

                if (funciones.FileExist(ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe"))
                {
                    double importe =
                        conversion.ConvertFormatMoney(txtRediImporte
                            .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                    Process System = new Process();
                    System.StartInfo.WorkingDirectory = ConfigurationManager.AppSettings["CarpetaSHM"];
                    System.StartInfo.FileName = ConfigurationManager.AppSettings["CarpetaSHM"] + @"SHM.exe";
                    System.StartInfo.Verb = "runas";
                    System.StartInfo.Arguments = "VALIDADIMA" + " " + cliente + " " + "DIMA" + " " + idVenta + " " +
                                                 "MAVI" + " " + Serie + " " + importe + " " +
                                                 ClaseEstatica.Usuario.sucursal + " " + "VTAS";
                    System.StartInfo.UseShellExecute = false;
                    System.Start();
                    //-Revision de Procesos
                    //System.WaitForExit();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llamadaPlugInSHM", "DM0312_Redime.cs", ex);
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void llamadaPlugInSHMRutaTicket()
        {
            Serie = txtRediNoMone.Text.Substring(0, 8);

            CDetalleVenta detalle = new CDetalleVenta();

            try
            {
                string importe =
                    conversion.ConvertFormatMoney(txtRediImporte.Text)
                        .ToString(); //txtRediImporte.Text.Replace("$", "");

                //Process System = new Process();
                //System.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                //System.StartInfo.FileName = ClaseEstatica.plugInPath + @"RutaTicket.exe";
                //System.StartInfo.Verb = "runas";
                //System.StartInfo.Arguments = "SHM7 " + "VALIDADIMA " + cliente + " " + "DIMA" + " " + idVenta + "_" + "MAVI" + "_" + Serie + "_" + importe + "_" + ClaseEstatica.Usuario.sucursal + "_" + "VTAS" + " " + ClaseEstatica.Usuario.sucursal;
                //System.StartInfo.UseShellExecute = false;
                //System.Start();
                //System.WaitForExit();


                string ArgumentosPlugin = "SHM7 "
                                          + "VALIDADIMA "
                                          + cliente
                                          + " "
                                          + "DIMA"
                                          + " "
                                          + idVenta
                                          + "_"
                                          + "MAVI"
                                          + "_"
                                          + Serie
                                          + "_"
                                          + importe
                                          + "_"
                                          + ClaseEstatica.Usuario.sucursal
                                          + "_"
                                          + "VTAS"
                                          + " "
                                          + ClaseEstatica.Usuario.sucursal;

                //System.StartInfo.Arguments = "VALIDADIMA" + " " + cliente + " " + "DIMA" + " " + idVenta + " " + "MAVI" + " " + Serie + " " + importe.ToString() + " " + ClaseEstatica.Usuario.sucursal + " " + "VTAS";
                detalle.EjecutarPlugins(ArgumentosPlugin, "RutaTicket.exe");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("llamadaPlugInSHMRutaTicket", "DM0312_Redime.cs", ex);
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GetSaldo()
        {
            if (txtGenNoMone.Text.Trim().Length < 8)
            {
                txtGenSaldo.Text = "$0.0";
                return;
            }

            string cuenta = txtGenNoMone.Text.Substring(0, 8);

            GenSaldo = controller.GetSaldo(cuenta);

            GenSaldo = Math.Truncate(100 * GenSaldo) / 100;

            txtGenSaldo.Text = GenSaldo.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + GenSaldo;

            if (groupBoxAutoriza.Visible)
                txtUser.Focus();
            else
                btnAceptar.Focus();
        }

        #endregion

        #region EventosForm

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //Aceptar Redime

            if (!validarUsuario())
                return;
            if (txtRediImporte.Visible)
            {
                double importe =
                    conversion.ConvertFormatMoney(txtRediImporte
                        .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                if (importe <= 0)
                {
                    MessageBox.Show("Para continuar con la redencion el importe tiene que ser mayor a 0", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                    txtRediImporte.Focus();
                }

                double importeMon = controller.importeMon(idVenta);
                if (importe > controller.importeMon(idVenta))
                {
                    MessageBox.Show(
                        "Para continuar con la redencion el importe de redencion tiene que ser menor al importe de la venta que es: " +
                        controller.importeMon(idVenta), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                    txtRediImporte.Focus();
                }
            }

            if (EnviarA == 76)
            {
                //dima
                double importe =
                    conversion.ConvertFormatMoney(txtRediImporte
                        .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                double saldo =
                    conversion.ConvertFormatMoney(txtRediSaldo
                        .Text); //Convert.ToDouble(txtRediSaldo.Text.Replace("$", ""));

                if (importe <= 0)
                {
                    MessageBox.Show("El importe tiene que ser mayor a 0", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }

                if (importe > saldo)
                {
                    MessageBox.Show("El importe no puede ser mayor al saldo", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }

                Enviar76AVenta();
            }
            else
            {
                //normales
                if (origen)
                {
                    double importe =
                        conversion.ConvertFormatMoney(txtRediImporte
                            .Text); //Convert.ToDouble(txtRediImporte.Text.Replace("$", ""));
                    double saldo =
                        conversion.ConvertFormatMoney(txtRediSaldo
                            .Text); //Convert.ToDouble(txtRediSaldo.Text.Replace("$", ""));

                    if (txtRediSaldo.Text == "$0.00")
                    {
                        MessageBox.Show("No puedes redimir con un monedero que no tiene saldo", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (importe > saldo)
                    {
                        MessageBox.Show("El importe no puede ser mayor al saldo", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        return;
                    }
                }

                if (!OperacionesMonedero()) return;
            }


            if (origen)
                if (txtRediSaldo.Text == "$0.00")
                {
                    MessageBox.Show("No puedes redimir con un monedero que no tiene saldo", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            Close();
        }

        private void txtGenNoMone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == (char)Keys.Enter)
            {
                if (rbtn_Normal.Checked)
                {
                    if (controller.validarMonedero(txtGenNoMone.Text, 0))
                    {
                        GetSaldo();
                    }
                    else
                    {
                        if (txtGenNoMone.Text == "")
                        {
                            MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            txtGenNoMone.Text = "";
                        }
                        else
                        {
                            if (txtGenNoMone.Text.Trim().Length < 8)
                            {
                                MessageBox.Show("El numero: " + txtGenNoMone.Text + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtGenNoMone.Text = "";
                            }
                            else
                            {
                                MessageBox.Show(
                                    "El numero: " + txtGenNoMone.Text.Substring(0, 8) + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtGenNoMone.Text = "";
                            }
                        }

                        txtGenNoMone.Focus();
                    }
                }
                else if (!rbtn_Normal.Checked && !rbtn_Virtual.Checked)
                {
                    if (txtGenNoMone.ReadOnly)
                    {
                        GetSaldo();
                    }
                    else if (controller.validarMonedero(txtGenNoMone.Text, 0))
                    {
                        GetSaldo();
                    }
                    else
                    {
                        if (txtGenNoMone.Text == "")
                        {
                            MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            if (txtGenNoMone.Text.Trim().Length < 8)
                                MessageBox.Show("El numero: " + txtGenNoMone.Text + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            else
                                MessageBox.Show(
                                    "El numero: " + txtGenNoMone.Text.Substring(0, 8) + " no es un monedero correcto",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }

                        txtGenNoMone.Focus();
                    }
                }
                else
                {
                    GetSaldo();
                }
            }
        }

        private void txtRediNoMone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == (char)Keys.Enter)
                if (!rbtn_Virtual.Focused && !btnCancelar.Focused)
                {
                    if (rbtn_Normal.Checked)
                    {
                        if (!controller.validarMonedero(txtRediNoMone.Text, 0))
                        {
                            if (txtRediNoMone.Text == "")
                            {
                                MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                txtRediNoMone.Text = "";
                            }
                            else
                            {
                                if (txtRediNoMone.Text.Trim().Length < 8)
                                {
                                    MessageBox.Show("El numero: " + txtRediNoMone.Text + " no es un monedero correcto",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    txtRediNoMone.Text = "";
                                }
                                else
                                {
                                    MessageBox.Show(
                                        "El numero: " + txtRediNoMone.Text.Substring(0, 8) +
                                        " no es un monedero correcto", "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Hand);
                                    txtRediNoMone.Text = "";
                                }
                            }

                            txtRediNoMone.Focus();
                        }
                        else
                        {
                            if (txtRediNoMone.Text.Trim().Length < 8)
                            {
                                txtRediSaldo.Text = "$0.00";
                            }
                            else
                            {
                                string cuenta = txtRediNoMone.Text.Substring(0, 8);
                                RedSaldo = controller.GetSaldo(cuenta);
                                RedSaldo = Math.Truncate(100.0 * RedSaldo) / 100.0;
                                txtRediSaldo.Text = RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture);
                                if (cuenta != string.Empty) txtRediImporte.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (rbtn_Virtual.Checked)
                        {
                            if (txtRediNoMone.Text.Trim().Length < 8)
                            {
                                txtRediSaldo.Text = "$0.00";
                            }
                            else
                            {
                                string cuenta = txtRediNoMone.Text.Substring(0, 8);

                                RedSaldo = controller.GetSaldo(cuenta);

                                RedSaldo = Math.Truncate(100 * RedSaldo) / 100;

                                txtRediSaldo.Text =
                                    RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + RedSaldo;

                                if (cuenta != string.Empty)
                                    txtRediImporte.Focus();
                            }
                        }

                        else
                        {
                            if (!controller.validarMonedero(txtRediNoMone.Text, 0))
                            {
                                if (txtRediNoMone.Text == "")
                                {
                                    MessageBox.Show("Campo vacio, favor de insertar un numero de serie", "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    if (txtRediNoMone.Text.Trim().Length < 8)
                                        MessageBox.Show(
                                            "El numero: " + txtRediNoMone.Text + " no es un monedero correcto", "Error",
                                            MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    else
                                        MessageBox.Show(
                                            "El numero: " + txtRediNoMone.Text.Substring(0, 8) +
                                            " no es un monedero correcto", "Error", MessageBoxButtons.OK,
                                            MessageBoxIcon.Hand);
                                }

                                txtRediNoMone.Focus();
                            }
                            else
                            {
                                if (txtRediNoMone.Text.Trim().Length < 8)
                                {
                                    txtRediSaldo.Text = "$0.00";
                                }
                                else
                                {
                                    string cuenta = txtRediNoMone.Text.Substring(0, 8);
                                    RedSaldo = controller.GetSaldo(cuenta);
                                    RedSaldo = Math.Truncate(100.0 * RedSaldo) / 100.0;
                                    txtRediSaldo.Text = RedSaldo.ToString("C", Thread.CurrentThread.CurrentCulture);
                                    if (cuenta != string.Empty) txtRediImporte.Focus();
                                }
                            }
                        }
                    }
                }
        }

        private void rbtn_Normal_CheckedChanged(object sender, EventArgs e)
        {
            Load_dima();
        }

        private void rbtn_Virtual_CheckedChanged(object sender, EventArgs e)
        {
            int diasV = controladorve.DiasVencidosDIMA(cliente);
            int diasC = Convert.ToInt32(controladorv.DiasV());
            if (Canal == 3)
            {
                if (diasV > diasC && rbtn_Normal.Checked == false)
                {
                    MessageBox.Show(
                        "No es posible redimir puntos, el cliente " + cliente + " excede DV permitidos en canal 76",
                        "!Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    rbtn_Normal.Checked = true;
                    return;
                }

                Load_dima();
            }
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DM0312_Redime_FormClosing(object sender, FormClosingEventArgs e)
        {
            //IsCancel = true;
        }

        private void txtRediImporte_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtRediImporte.Text.Contains("."))
            {
                if (e.KeyChar.ToString() == ".")
                {
                    e.Handled = true;
                    return;
                }
            }
            else
            {
                if ((e.KeyChar.ToString() == ".") & (txtRediImporte.Text.Length == 0))
                {
                    e.Handled = true;
                    return;
                }
            }

            if (char.IsDigit(e.KeyChar) || e.KeyChar.ToString() == ".")
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }


        private void txtRediImporte_Enter(object sender, EventArgs e)
        {
            txtRediImporte.Text =
                conversion.ConvertFormatMoney(txtRediImporte.Text).ToString(); //txtRediImporte.Text.Replace("$", "");

            txtRediImporte.SelectionStart = 0;

            txtRediImporte.SelectionLength = txtRediImporte.Text.Length;
        }

        private void txtRediImporte_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRediImporte.Text.Trim()))
            {
                //txtRediImporte.Text = txtRediImporte.Text.Replace("$", "");

                double importe =
                    conversion.ConvertFormatMoney(txtRediImporte.Text); //Convert.ToDouble(txtRediImporte.Text);

                double value = Math.Truncate(100 * importe) / 100;

                txtRediImporte.Text = value.ToString("C", Thread.CurrentThread.CurrentCulture); //"$" + value;
            }
            else
            {
                txtRediImporte.Text = "$0.0";
            }
        }

        private void txtRediImporte_Click(object sender, EventArgs e)
        {
            txtRediImporte.SelectionStart = 0;

            txtRediImporte.SelectionLength = txtRediImporte.Text.Length;
        }

        private void txtGenNoMone_Leave(object sender, EventArgs e)
        {
            GetSaldo();
        }

        private void txtRediNoMone_Leave(object sender, EventArgs e)
        {
            GetSaldo();
        }

        #endregion
    }
}