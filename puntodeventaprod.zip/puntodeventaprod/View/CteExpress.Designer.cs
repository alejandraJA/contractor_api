﻿namespace PuntoVenta
{
    partial class CteExpress
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CteExpress));
            this.grbox1 = new System.Windows.Forms.GroupBox();
            this.grboxCte = new System.Windows.Forms.GroupBox();
            this.lblMail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblFormatoFech = new System.Windows.Forms.Label();
            this.mskFechaNac = new System.Windows.Forms.MaskedTextBox();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.lblEd = new System.Windows.Forms.Label();
            this.dtpFechNac = new System.Windows.Forms.DateTimePicker();
            this.txtRfc = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtApePat = new System.Windows.Forms.TextBox();
            this.txtApeMat = new System.Windows.Forms.TextBox();
            this.txtCanal = new System.Windows.Forms.TextBox();
            this.lblrfc = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblFechNac = new System.Windows.Forms.Label();
            this.lblSex = new System.Windows.Forms.Label();
            this.cmbSex = new System.Windows.Forms.ComboBox();
            this.lblApePat = new System.Windows.Forms.Label();
            this.lblApMat = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblReg = new System.Windows.Forms.Label();
            this.cmbRegimen = new System.Windows.Forms.ComboBox();
            this.grBoxDomAnt = new System.Windows.Forms.GroupBox();
            this.txtMesDirAnt = new System.Windows.Forms.TextBox();
            this.txtYearDomA = new System.Windows.Forms.TextBox();
            this.txtEntreCAnt = new System.Windows.Forms.TextBox();
            this.lblDirCteAnt = new System.Windows.Forms.Label();
            this.lblMesAntCteA = new System.Windows.Forms.Label();
            this.txtDirAnt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblYearAntCteA = new System.Windows.Forms.Label();
            this.txtNumExtAnt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNumIntAnt = new System.Windows.Forms.TextBox();
            this.txtPaisCteAnt = new System.Windows.Forms.TextBox();
            this.lblTipoCalleAnt = new System.Windows.Forms.Label();
            this.lblPaisCteAnt = new System.Windows.Forms.Label();
            this.cmbTipoCalleAnt = new System.Windows.Forms.ComboBox();
            this.txtEstCteAnt = new System.Windows.Forms.TextBox();
            this.lblEntCAnt = new System.Windows.Forms.Label();
            this.lblEstCteAnt = new System.Windows.Forms.Label();
            this.lblColAnt = new System.Windows.Forms.Label();
            this.txtPobCteAnt = new System.Windows.Forms.TextBox();
            this.txtColCteAnt = new System.Windows.Forms.TextBox();
            this.lblPobCteAnt = new System.Windows.Forms.Label();
            this.btnBuscarAnt = new System.Windows.Forms.Button();
            this.txtDelCteAnt = new System.Windows.Forms.TextBox();
            this.lblCpCteAnt = new System.Windows.Forms.Label();
            this.lblDelCteAnt = new System.Windows.Forms.Label();
            this.txtCpCteAnt = new System.Windows.Forms.TextBox();
            this.grBoxDirCte = new System.Windows.Forms.GroupBox();
            this.txtCtrlMes = new System.Windows.Forms.TextBox();
            this.txtCtrlYear = new System.Windows.Forms.TextBox();
            this.cmbKeLiveEnC = new System.Windows.Forms.ComboBox();
            this.lblKeViveEnC = new System.Windows.Forms.Label();
            this.cmbLiveCon = new System.Windows.Forms.ComboBox();
            this.lblLiveCon = new System.Windows.Forms.Label();
            this.lblEdoC = new System.Windows.Forms.Label();
            this.txtEntreC = new System.Windows.Forms.TextBox();
            this.cmbEdoCivil = new System.Windows.Forms.ComboBox();
            this.lblDom = new System.Windows.Forms.Label();
            this.lblMesAntCte = new System.Windows.Forms.Label();
            this.txtDir = new System.Windows.Forms.TextBox();
            this.lblNumEx = new System.Windows.Forms.Label();
            this.lblYearAntCte = new System.Windows.Forms.Label();
            this.txtNumExt = new System.Windows.Forms.TextBox();
            this.cmbViveCalCte = new System.Windows.Forms.ComboBox();
            this.lblNumInt = new System.Windows.Forms.Label();
            this.lblViveCalCte = new System.Windows.Forms.Label();
            this.txtNumInt = new System.Windows.Forms.TextBox();
            this.txtPaisCte = new System.Windows.Forms.TextBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.lblPaisCte = new System.Windows.Forms.Label();
            this.cmbTipoCalle = new System.Windows.Forms.ComboBox();
            this.txtEstCte = new System.Windows.Forms.TextBox();
            this.lblEntC = new System.Windows.Forms.Label();
            this.lblEstCte = new System.Windows.Forms.Label();
            this.lblCol = new System.Windows.Forms.Label();
            this.txtPobCte = new System.Windows.Forms.TextBox();
            this.txtColCte = new System.Windows.Forms.TextBox();
            this.lblPobCte = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtDelCte = new System.Windows.Forms.TextBox();
            this.lblCpCte = new System.Windows.Forms.Label();
            this.lblDelCte = new System.Windows.Forms.Label();
            this.txtCpCte = new System.Windows.Forms.TextBox();
            this.grboxCaps = new System.Windows.Forms.GroupBox();
            this.lblSpid = new System.Windows.Forms.Label();
            this.btnGoogle = new System.Windows.Forms.Button();
            this.btnImp = new System.Windows.Forms.Button();
            this.btnTelefonos = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnDatNomi = new System.Windows.Forms.Button();
            this.btnCapRefCte = new System.Windows.Forms.Button();
            this.btnCapEmpCte = new System.Windows.Forms.Button();
            this.lblCon = new System.Windows.Forms.Label();
            this.btnCapDatCte = new System.Windows.Forms.Button();
            this.grboxEmpleoCte = new System.Windows.Forms.GroupBox();
            this.grboxDirEmpA = new System.Windows.Forms.GroupBox();
            this.txtEmpAnt = new System.Windows.Forms.TextBox();
            this.lblEmpAnt = new System.Windows.Forms.Label();
            this.txtEntCalleEa = new System.Windows.Forms.TextBox();
            this.lblDirAntE = new System.Windows.Forms.Label();
            this.txtDirAntE = new System.Windows.Forms.TextBox();
            this.lblExtEmpA = new System.Windows.Forms.Label();
            this.txtExtEmpA = new System.Windows.Forms.TextBox();
            this.lblIntEmpA = new System.Windows.Forms.Label();
            this.txtIntEmpA = new System.Windows.Forms.TextBox();
            this.txtPaisEmpA = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPaisEmpA = new System.Windows.Forms.Label();
            this.cmbTipCalleEmpA = new System.Windows.Forms.ComboBox();
            this.txtEstEmpA = new System.Windows.Forms.TextBox();
            this.lblEntCalleEa = new System.Windows.Forms.Label();
            this.lblEstEmpA = new System.Windows.Forms.Label();
            this.lblColEmpA = new System.Windows.Forms.Label();
            this.txtPobEmpA = new System.Windows.Forms.TextBox();
            this.txtColEmpA = new System.Windows.Forms.TextBox();
            this.lblPobEmpA = new System.Windows.Forms.Label();
            this.btnBusColA = new System.Windows.Forms.Button();
            this.txtDelEmpA = new System.Windows.Forms.TextBox();
            this.lblCpEmpA = new System.Windows.Forms.Label();
            this.lblDelEmpA = new System.Windows.Forms.Label();
            this.txtCpEmpA = new System.Windows.Forms.TextBox();
            this.grboxDirEmpleo = new System.Windows.Forms.GroupBox();
            this.txtEntCalleE = new System.Windows.Forms.TextBox();
            this.lblDirEmp = new System.Windows.Forms.Label();
            this.txtDirEmp = new System.Windows.Forms.TextBox();
            this.lblNumExEmp = new System.Windows.Forms.Label();
            this.txtNumExtEmp = new System.Windows.Forms.TextBox();
            this.lblNumIntEmp = new System.Windows.Forms.Label();
            this.txtNumIntEmp = new System.Windows.Forms.TextBox();
            this.txtPaisEmp = new System.Windows.Forms.TextBox();
            this.lblTipCalleE = new System.Windows.Forms.Label();
            this.lblPaisE = new System.Windows.Forms.Label();
            this.cmbTipCalleE = new System.Windows.Forms.ComboBox();
            this.txtEstEmp = new System.Windows.Forms.TextBox();
            this.lblEntCalleE = new System.Windows.Forms.Label();
            this.lblEstEmp = new System.Windows.Forms.Label();
            this.lblColEmp = new System.Windows.Forms.Label();
            this.txtPobEmp = new System.Windows.Forms.TextBox();
            this.txtColEmp = new System.Windows.Forms.TextBox();
            this.lblPobEmp = new System.Windows.Forms.Label();
            this.btnBusColE = new System.Windows.Forms.Button();
            this.txtDelEmp = new System.Windows.Forms.TextBox();
            this.lblCpEmp = new System.Windows.Forms.Label();
            this.lblDelEmp = new System.Windows.Forms.Label();
            this.txtCpEmp = new System.Windows.Forms.TextBox();
            this.grbEmpCte = new System.Windows.Forms.GroupBox();
            this.lblTipEMp = new System.Windows.Forms.Label();
            this.cmbTipEmp = new System.Windows.Forms.ComboBox();
            this.txtMesEmp = new System.Windows.Forms.TextBox();
            this.txtYearEmp = new System.Windows.Forms.TextBox();
            this.chboxComprob = new System.Windows.Forms.CheckBox();
            this.cmbPerIngreso = new System.Windows.Forms.ComboBox();
            this.lblPerIngreso = new System.Windows.Forms.Label();
            this.txtIngreso = new System.Windows.Forms.TextBox();
            this.lblIngresos = new System.Windows.Forms.Label();
            this.txtPstoJefe = new System.Windows.Forms.TextBox();
            this.lblPstoJefInme = new System.Windows.Forms.Label();
            this.txtJefe = new System.Windows.Forms.TextBox();
            this.lblJefe = new System.Windows.Forms.Label();
            this.lblMesEmp = new System.Windows.Forms.Label();
            this.lblYearEmp = new System.Windows.Forms.Label();
            this.txtDepEmpCte = new System.Windows.Forms.TextBox();
            this.lblDepEmpCte = new System.Windows.Forms.Label();
            this.lblFunEmpCte = new System.Windows.Forms.Label();
            this.txtFunEmpCte = new System.Windows.Forms.TextBox();
            this.txtEmpCte = new System.Windows.Forms.TextBox();
            this.lblEmpCte = new System.Windows.Forms.Label();
            this.grbRef = new System.Windows.Forms.GroupBox();
            this.grbBusCte = new System.Windows.Forms.GroupBox();
            this.txtTipdesc = new System.Windows.Forms.TextBox();
            this.lblTipDesc = new System.Windows.Forms.Label();
            this.lblTipoCte = new System.Windows.Forms.Label();
            this.cmbTipoCred = new System.Windows.Forms.ComboBox();
            this.chbPresent = new System.Windows.Forms.CheckBox();
            this.cmbParent = new System.Windows.Forms.ComboBox();
            this.lblParen = new System.Windows.Forms.Label();
            this.txtDirRe = new System.Windows.Forms.TextBox();
            this.lblDirRe = new System.Windows.Forms.Label();
            this.txtNomR = new System.Windows.Forms.TextBox();
            this.lblNomR = new System.Windows.Forms.Label();
            this.btnBuscCte = new System.Windows.Forms.Button();
            this.txtRecPor = new System.Windows.Forms.TextBox();
            this.lblBuscte = new System.Windows.Forms.Label();
            this.grbDatComBan = new System.Windows.Forms.GroupBox();
            this.txtTarjBan3 = new System.Windows.Forms.TextBox();
            this.lblTarjBan3 = new System.Windows.Forms.Label();
            this.txtEmiBan3 = new System.Windows.Forms.TextBox();
            this.lblEmiBan3 = new System.Windows.Forms.Label();
            this.txtTarjBan2 = new System.Windows.Forms.TextBox();
            this.lblTarjBan2 = new System.Windows.Forms.Label();
            this.txtTarjBan1 = new System.Windows.Forms.TextBox();
            this.lblTarjBan1 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblTarjCom2 = new System.Windows.Forms.Label();
            this.txtTarjCom1 = new System.Windows.Forms.TextBox();
            this.lblTarjCom1 = new System.Windows.Forms.Label();
            this.txtEmiBan2 = new System.Windows.Forms.TextBox();
            this.lblEmiBan2 = new System.Windows.Forms.Label();
            this.txtEmiBan1 = new System.Windows.Forms.TextBox();
            this.lblEmiBan1 = new System.Windows.Forms.Label();
            this.txtEmiCom2 = new System.Windows.Forms.TextBox();
            this.lblEmiCom2 = new System.Windows.Forms.Label();
            this.txtEmiCom1 = new System.Windows.Forms.TextBox();
            this.lblEmiCom1 = new System.Windows.Forms.Label();
            this.grbDatNominales = new System.Windows.Forms.GroupBox();
            this.grbNomi = new System.Windows.Forms.GroupBox();
            this.txtMpioN = new System.Windows.Forms.TextBox();
            this.lblMpioN = new System.Windows.Forms.Label();
            this.txtCargoN = new System.Windows.Forms.TextBox();
            this.lblCargoN = new System.Windows.Forms.Label();
            this.txtCveInst = new System.Windows.Forms.TextBox();
            this.lblCveInst = new System.Windows.Forms.Label();
            this.txtRfcInst = new System.Windows.Forms.TextBox();
            this.lblRfcInst = new System.Windows.Forms.Label();
            this.lblPuestoN = new System.Windows.Forms.Label();
            this.txtPuestoN = new System.Windows.Forms.TextBox();
            this.txtConfNomina = new System.Windows.Forms.TextBox();
            this.lblConfNom = new System.Windows.Forms.Label();
            this.txtNomina = new System.Windows.Forms.TextBox();
            this.lblNomina = new System.Windows.Forms.Label();
            this.grbTelefono = new System.Windows.Forms.GroupBox();
            this.grbTiempo = new System.Windows.Forms.GroupBox();
            this.txtTiempo = new System.Windows.Forms.TextBox();
            this.grbTel = new System.Windows.Forms.GroupBox();
            this.lblOpcion = new System.Windows.Forms.Label();
            this.lblAnuncio = new System.Windows.Forms.Label();
            this.btnAgrTel = new System.Windows.Forms.Button();
            this.dgvTelefono = new System.Windows.Forms.DataGridView();
            this.Borrar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.TipoTel = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.LadaTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TelefonoTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbContactos = new System.Windows.Forms.GroupBox();
            this.grbCont = new System.Windows.Forms.GroupBox();
            this.dgvCto = new System.Windows.Forms.DataGridView();
            this.Tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parentesco = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ApePat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ApeMat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CnlVent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FechaN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EdoC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ViveEnCal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ViveCon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CalidadCon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EsCasa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NoCuenta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rfcCto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Editar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Eliminar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnAgregarCto = new System.Windows.Forms.Button();
            this.grbRefComBan = new System.Windows.Forms.GroupBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.grbDimR2 = new System.Windows.Forms.GroupBox();
            this.lblCuentaDimr = new System.Windows.Forms.Label();
            this.txtCuentaDimr = new System.Windows.Forms.TextBox();
            this.btnBuscarDimR = new System.Windows.Forms.Button();
            this.lblNomDimR = new System.Windows.Forms.Label();
            this.txtNomDimR = new System.Windows.Forms.TextBox();
            this.lblDirecDimr = new System.Windows.Forms.Label();
            this.txtDirecDimR = new System.Windows.Forms.TextBox();
            this.btnBorrarDimR = new System.Windows.Forms.Button();
            this.grbDimR = new System.Windows.Forms.GroupBox();
            this.grbox1.SuspendLayout();
            this.grboxCte.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.grBoxDomAnt.SuspendLayout();
            this.grBoxDirCte.SuspendLayout();
            this.grboxCaps.SuspendLayout();
            this.grboxEmpleoCte.SuspendLayout();
            this.grboxDirEmpA.SuspendLayout();
            this.grboxDirEmpleo.SuspendLayout();
            this.grbEmpCte.SuspendLayout();
            this.grbRef.SuspendLayout();
            this.grbBusCte.SuspendLayout();
            this.grbDatComBan.SuspendLayout();
            this.grbDatNominales.SuspendLayout();
            this.grbNomi.SuspendLayout();
            this.grbTelefono.SuspendLayout();
            this.grbTiempo.SuspendLayout();
            this.grbTel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTelefono)).BeginInit();
            this.grbContactos.SuspendLayout();
            this.grbCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCto)).BeginInit();
            this.grbRefComBan.SuspendLayout();
            this.grbDimR2.SuspendLayout();
            this.grbDimR.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbox1
            // 
            this.grbox1.AutoSize = true;
            this.grbox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbox1.BackColor = System.Drawing.Color.LightBlue;
            this.grbox1.Controls.Add(this.grboxCte);
            this.grbox1.Controls.Add(this.grBoxDomAnt);
            this.grbox1.Controls.Add(this.grBoxDirCte);
            this.grbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbox1.Location = new System.Drawing.Point(184, 321);
            this.grbox1.Name = "grbox1";
            this.grbox1.Size = new System.Drawing.Size(887, 660);
            this.grbox1.TabIndex = 1;
            this.grbox1.TabStop = false;
            this.grbox1.Text = "Datos Generales Cliente";
            this.grbox1.SizeChanged += new System.EventHandler(this.grbox1_SizeChanged);
            // 
            // grboxCte
            // 
            this.grboxCte.BackColor = System.Drawing.SystemColors.Control;
            this.grboxCte.Controls.Add(this.lblMail);
            this.grboxCte.Controls.Add(this.txtEmail);
            this.grboxCte.Controls.Add(this.lblFormatoFech);
            this.grboxCte.Controls.Add(this.mskFechaNac);
            this.grboxCte.Controls.Add(this.toolStripContainer1);
            this.grboxCte.Controls.Add(this.txtEdad);
            this.grboxCte.Controls.Add(this.lblEd);
            this.grboxCte.Controls.Add(this.dtpFechNac);
            this.grboxCte.Controls.Add(this.txtRfc);
            this.grboxCte.Controls.Add(this.txtNom);
            this.grboxCte.Controls.Add(this.txtApePat);
            this.grboxCte.Controls.Add(this.txtApeMat);
            this.grboxCte.Controls.Add(this.txtCanal);
            this.grboxCte.Controls.Add(this.lblrfc);
            this.grboxCte.Controls.Add(this.lblNom);
            this.grboxCte.Controls.Add(this.lblFechNac);
            this.grboxCte.Controls.Add(this.lblSex);
            this.grboxCte.Controls.Add(this.cmbSex);
            this.grboxCte.Controls.Add(this.lblApePat);
            this.grboxCte.Controls.Add(this.lblApMat);
            this.grboxCte.Controls.Add(this.label1);
            this.grboxCte.Controls.Add(this.lblReg);
            this.grboxCte.Controls.Add(this.cmbRegimen);
            this.grboxCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grboxCte.Location = new System.Drawing.Point(6, 18);
            this.grboxCte.Name = "grboxCte";
            this.grboxCte.Size = new System.Drawing.Size(875, 153);
            this.grboxCte.TabIndex = 0;
            this.grboxCte.TabStop = false;
            // 
            // lblMail
            // 
            this.lblMail.AutoSize = true;
            this.lblMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMail.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMail.Location = new System.Drawing.Point(490, 114);
            this.lblMail.Name = "lblMail";
            this.lblMail.Size = new System.Drawing.Size(42, 15);
            this.lblMail.TabIndex = 21;
            this.lblMail.Text = "Email:";
            this.lblMail.Visible = false;
            // 
            // txtEmail
            // 
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmail.Location = new System.Drawing.Point(537, 111);
            this.txtEmail.MaxLength = 200;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(299, 21);
            this.txtEmail.TabIndex = 22;
            this.txtEmail.Visible = false;
            // 
            // lblFormatoFech
            // 
            this.lblFormatoFech.AutoSize = true;
            this.lblFormatoFech.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormatoFech.ForeColor = System.Drawing.Color.DarkRed;
            this.lblFormatoFech.Location = new System.Drawing.Point(141, 99);
            this.lblFormatoFech.Name = "lblFormatoFech";
            this.lblFormatoFech.Size = new System.Drawing.Size(79, 13);
            this.lblFormatoFech.TabIndex = 15;
            this.lblFormatoFech.Text = "DD/MM/AAAA";
            // 
            // mskFechaNac
            // 
            this.mskFechaNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskFechaNac.Location = new System.Drawing.Point(140, 114);
            this.mskFechaNac.Mask = "00/00/0000";
            this.mskFechaNac.Name = "mskFechaNac";
            this.mskFechaNac.Size = new System.Drawing.Size(104, 21);
            this.mskFechaNac.TabIndex = 16;
            this.mskFechaNac.LostFocus += new System.EventHandler(this.mskFechaNac_LostFocus);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(81, 150);
            this.toolStripContainer1.Location = new System.Drawing.Point(887, 29);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(81, 175);
            this.toolStripContainer1.TabIndex = 20;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // txtEdad
            // 
            this.txtEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEdad.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEdad.Location = new System.Drawing.Point(705, 28);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.ReadOnly = true;
            this.txtEdad.Size = new System.Drawing.Size(100, 21);
            this.txtEdad.TabIndex = 5;
            // 
            // lblEd
            // 
            this.lblEd.AutoSize = true;
            this.lblEd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEd.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEd.Location = new System.Drawing.Point(664, 32);
            this.lblEd.Name = "lblEd";
            this.lblEd.Size = new System.Drawing.Size(39, 15);
            this.lblEd.TabIndex = 4;
            this.lblEd.Text = "Edad:";
            // 
            // dtpFechNac
            // 
            this.dtpFechNac.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.dtpFechNac.CalendarTitleForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpFechNac.CustomFormat = "dd-MM-yyyy";
            this.dtpFechNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechNac.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFechNac.Location = new System.Drawing.Point(141, 114);
            this.dtpFechNac.Name = "dtpFechNac";
            this.dtpFechNac.Size = new System.Drawing.Size(136, 21);
            this.dtpFechNac.TabIndex = 15;
            this.dtpFechNac.Value = new System.DateTime(2015, 2, 12, 0, 0, 0, 0);
            this.dtpFechNac.CloseUp += new System.EventHandler(this.dtpFechNac_CloseUp);
            this.dtpFechNac.ValueChanged += new System.EventHandler(this.dtpFechNac_ValueChanged);
            this.dtpFechNac.LostFocus += new System.EventHandler(this.dtpFechNac_LostFocus);
            // 
            // txtRfc
            // 
            this.txtRfc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRfc.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRfc.Location = new System.Drawing.Point(328, 114);
            this.txtRfc.MaxLength = 100;
            this.txtRfc.Name = "txtRfc";
            this.txtRfc.Size = new System.Drawing.Size(142, 21);
            this.txtRfc.TabIndex = 18;
            // 
            // txtNom
            // 
            this.txtNom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNom.Location = new System.Drawing.Point(691, 70);
            this.txtNom.MaxLength = 250;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(170, 21);
            this.txtNom.TabIndex = 11;
            this.txtNom.TextChanged += new System.EventHandler(this.txtNom_TextChanged);
            // 
            // txtApePat
            // 
            this.txtApePat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApePat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApePat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtApePat.Location = new System.Drawing.Point(118, 69);
            this.txtApePat.MaxLength = 100;
            this.txtApePat.Name = "txtApePat";
            this.txtApePat.Size = new System.Drawing.Size(170, 21);
            this.txtApePat.TabIndex = 7;
            this.txtApePat.TextChanged += new System.EventHandler(this.txtApePat_TextChanged);
            // 
            // txtApeMat
            // 
            this.txtApeMat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApeMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApeMat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtApeMat.Location = new System.Drawing.Point(406, 70);
            this.txtApeMat.MaxLength = 100;
            this.txtApeMat.Name = "txtApeMat";
            this.txtApeMat.Size = new System.Drawing.Size(170, 21);
            this.txtApeMat.TabIndex = 9;
            this.txtApeMat.TextChanged += new System.EventHandler(this.txtApeMat_TextChanged);
            // 
            // txtCanal
            // 
            this.txtCanal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCanal.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCanal.Location = new System.Drawing.Point(428, 29);
            this.txtCanal.Name = "txtCanal";
            this.txtCanal.ReadOnly = true;
            this.txtCanal.Size = new System.Drawing.Size(100, 21);
            this.txtCanal.TabIndex = 3;
            this.txtCanal.TextChanged += new System.EventHandler(this.txtCanal_TextChanged);
            // 
            // lblrfc
            // 
            this.lblrfc.AutoSize = true;
            this.lblrfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrfc.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblrfc.Location = new System.Drawing.Point(287, 117);
            this.lblrfc.Name = "lblrfc";
            this.lblrfc.Size = new System.Drawing.Size(39, 15);
            this.lblrfc.TabIndex = 17;
            this.lblrfc.Text = "*RFC:";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNom.Location = new System.Drawing.Point(588, 73);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(101, 15);
            this.lblNom.TabIndex = 10;
            this.lblNom.Text = "*Nombre Cliente:";
            // 
            // lblFechNac
            // 
            this.lblFechNac.AutoSize = true;
            this.lblFechNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechNac.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblFechNac.Location = new System.Drawing.Point(12, 117);
            this.lblFechNac.Name = "lblFechNac";
            this.lblFechNac.Size = new System.Drawing.Size(127, 15);
            this.lblFechNac.TabIndex = 14;
            this.lblFechNac.Text = "Fecha de Nacimiento:";
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSex.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblSex.Location = new System.Drawing.Point(605, 112);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(43, 15);
            this.lblSex.TabIndex = 12;
            this.lblSex.Text = "*Sexo:";
            // 
            // cmbSex
            // 
            this.cmbSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSex.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbSex.FormattingEnabled = true;
            this.cmbSex.Location = new System.Drawing.Point(649, 106);
            this.cmbSex.Name = "cmbSex";
            this.cmbSex.Size = new System.Drawing.Size(135, 23);
            this.cmbSex.TabIndex = 13;
            this.cmbSex.SelectedIndexChanged += new System.EventHandler(this.cmbSex_SelectedIndexChanged);
            // 
            // lblApePat
            // 
            this.lblApePat.AutoSize = true;
            this.lblApePat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApePat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblApePat.Location = new System.Drawing.Point(11, 72);
            this.lblApePat.Name = "lblApePat";
            this.lblApePat.Size = new System.Drawing.Size(105, 15);
            this.lblApePat.TabIndex = 6;
            this.lblApePat.Text = "*Apellido Paterno:";
            // 
            // lblApMat
            // 
            this.lblApMat.AutoSize = true;
            this.lblApMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApMat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblApMat.Location = new System.Drawing.Point(297, 72);
            this.lblApMat.Name = "lblApMat";
            this.lblApMat.Size = new System.Drawing.Size(108, 15);
            this.lblApMat.TabIndex = 8;
            this.lblApMat.Text = "*Apellido Materno:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(344, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "*Canal Venta:";
            // 
            // lblReg
            // 
            this.lblReg.AutoSize = true;
            this.lblReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReg.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblReg.Location = new System.Drawing.Point(12, 31);
            this.lblReg.Name = "lblReg";
            this.lblReg.Size = new System.Drawing.Size(66, 15);
            this.lblReg.TabIndex = 0;
            this.lblReg.Text = "*Regimen:";
            // 
            // cmbRegimen
            // 
            this.cmbRegimen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegimen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRegimen.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbRegimen.FormattingEnabled = true;
            this.cmbRegimen.Location = new System.Drawing.Point(80, 28);
            this.cmbRegimen.Name = "cmbRegimen";
            this.cmbRegimen.Size = new System.Drawing.Size(159, 23);
            this.cmbRegimen.TabIndex = 1;
            this.cmbRegimen.SelectedIndexChanged += new System.EventHandler(this.cmbRegimen_SelectedIndexChanged);
            // 
            // grBoxDomAnt
            // 
            this.grBoxDomAnt.BackColor = System.Drawing.SystemColors.Control;
            this.grBoxDomAnt.Controls.Add(this.txtMesDirAnt);
            this.grBoxDomAnt.Controls.Add(this.txtYearDomA);
            this.grBoxDomAnt.Controls.Add(this.txtEntreCAnt);
            this.grBoxDomAnt.Controls.Add(this.lblDirCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblMesAntCteA);
            this.grBoxDomAnt.Controls.Add(this.txtDirAnt);
            this.grBoxDomAnt.Controls.Add(this.label4);
            this.grBoxDomAnt.Controls.Add(this.lblYearAntCteA);
            this.grBoxDomAnt.Controls.Add(this.txtNumExtAnt);
            this.grBoxDomAnt.Controls.Add(this.label6);
            this.grBoxDomAnt.Controls.Add(this.txtNumIntAnt);
            this.grBoxDomAnt.Controls.Add(this.txtPaisCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblTipoCalleAnt);
            this.grBoxDomAnt.Controls.Add(this.lblPaisCteAnt);
            this.grBoxDomAnt.Controls.Add(this.cmbTipoCalleAnt);
            this.grBoxDomAnt.Controls.Add(this.txtEstCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblEntCAnt);
            this.grBoxDomAnt.Controls.Add(this.lblEstCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblColAnt);
            this.grBoxDomAnt.Controls.Add(this.txtPobCteAnt);
            this.grBoxDomAnt.Controls.Add(this.txtColCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblPobCteAnt);
            this.grBoxDomAnt.Controls.Add(this.btnBuscarAnt);
            this.grBoxDomAnt.Controls.Add(this.txtDelCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblCpCteAnt);
            this.grBoxDomAnt.Controls.Add(this.lblDelCteAnt);
            this.grBoxDomAnt.Controls.Add(this.txtCpCteAnt);
            this.grBoxDomAnt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.grBoxDomAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grBoxDomAnt.Location = new System.Drawing.Point(6, 427);
            this.grBoxDomAnt.Name = "grBoxDomAnt";
            this.grBoxDomAnt.Size = new System.Drawing.Size(874, 212);
            this.grBoxDomAnt.TabIndex = 2;
            this.grBoxDomAnt.TabStop = false;
            this.grBoxDomAnt.Text = "Domicilio Anterior";
            // 
            // txtMesDirAnt
            // 
            this.txtMesDirAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMesDirAnt.Location = new System.Drawing.Point(695, 68);
            this.txtMesDirAnt.MaxLength = 10;
            this.txtMesDirAnt.Name = "txtMesDirAnt";
            this.txtMesDirAnt.Size = new System.Drawing.Size(52, 21);
            this.txtMesDirAnt.TabIndex = 38;
            this.txtMesDirAnt.TextChanged += new System.EventHandler(this.txtMesDirAnt_TextChanged);
            this.txtMesDirAnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMesDirAnt_KeyPress);
            // 
            // txtYearDomA
            // 
            this.txtYearDomA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYearDomA.Location = new System.Drawing.Point(508, 68);
            this.txtYearDomA.MaxLength = 10;
            this.txtYearDomA.Name = "txtYearDomA";
            this.txtYearDomA.Size = new System.Drawing.Size(53, 21);
            this.txtYearDomA.TabIndex = 37;
            this.txtYearDomA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtYearDomA_KeyPress);
            // 
            // txtEntreCAnt
            // 
            this.txtEntreCAnt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEntreCAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntreCAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEntreCAnt.Location = new System.Drawing.Point(87, 68);
            this.txtEntreCAnt.MaxLength = 100;
            this.txtEntreCAnt.Name = "txtEntreCAnt";
            this.txtEntreCAnt.Size = new System.Drawing.Size(288, 21);
            this.txtEntreCAnt.TabIndex = 9;
            // 
            // lblDirCteAnt
            // 
            this.lblDirCteAnt.AutoSize = true;
            this.lblDirCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDirCteAnt.Location = new System.Drawing.Point(10, 30);
            this.lblDirCteAnt.Name = "lblDirCteAnt";
            this.lblDirCteAnt.Size = new System.Drawing.Size(67, 15);
            this.lblDirCteAnt.TabIndex = 0;
            this.lblDirCteAnt.Text = "*Direccion:";
            // 
            // lblMesAntCteA
            // 
            this.lblMesAntCteA.AutoSize = true;
            this.lblMesAntCteA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesAntCteA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMesAntCteA.Location = new System.Drawing.Point(576, 71);
            this.lblMesAntCteA.Name = "lblMesAntCteA";
            this.lblMesAntCteA.Size = new System.Drawing.Size(117, 15);
            this.lblMesAntCteA.TabIndex = 12;
            this.lblMesAntCteA.Text = "*Meses Antigüedad:";
            // 
            // txtDirAnt
            // 
            this.txtDirAnt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDirAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDirAnt.Location = new System.Drawing.Point(88, 27);
            this.txtDirAnt.MaxLength = 100;
            this.txtDirAnt.Name = "txtDirAnt";
            this.txtDirAnt.Size = new System.Drawing.Size(299, 21);
            this.txtDirAnt.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Location = new System.Drawing.Point(400, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Num Ext:";
            // 
            // lblYearAntCteA
            // 
            this.lblYearAntCteA.AutoSize = true;
            this.lblYearAntCteA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYearAntCteA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblYearAntCteA.Location = new System.Drawing.Point(384, 71);
            this.lblYearAntCteA.Name = "lblYearAntCteA";
            this.lblYearAntCteA.Size = new System.Drawing.Size(119, 15);
            this.lblYearAntCteA.TabIndex = 10;
            this.lblYearAntCteA.Text = "Años de Antigüedad:";
            // 
            // txtNumExtAnt
            // 
            this.txtNumExtAnt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumExtAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumExtAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumExtAnt.Location = new System.Drawing.Point(464, 27);
            this.txtNumExtAnt.MaxLength = 10;
            this.txtNumExtAnt.Name = "txtNumExtAnt";
            this.txtNumExtAnt.Size = new System.Drawing.Size(45, 21);
            this.txtNumExtAnt.TabIndex = 3;
            this.txtNumExtAnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumExt_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(529, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Num Int:";
            // 
            // txtNumIntAnt
            // 
            this.txtNumIntAnt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumIntAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumIntAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumIntAnt.Location = new System.Drawing.Point(584, 27);
            this.txtNumIntAnt.MaxLength = 10;
            this.txtNumIntAnt.Name = "txtNumIntAnt";
            this.txtNumIntAnt.Size = new System.Drawing.Size(45, 21);
            this.txtNumIntAnt.TabIndex = 5;
            // 
            // txtPaisCteAnt
            // 
            this.txtPaisCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtPaisCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaisCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPaisCteAnt.Location = new System.Drawing.Point(289, 167);
            this.txtPaisCteAnt.Name = "txtPaisCteAnt";
            this.txtPaisCteAnt.ReadOnly = true;
            this.txtPaisCteAnt.Size = new System.Drawing.Size(206, 21);
            this.txtPaisCteAnt.TabIndex = 26;
            // 
            // lblTipoCalleAnt
            // 
            this.lblTipoCalleAnt.AutoSize = true;
            this.lblTipoCalleAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoCalleAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTipoCalleAnt.Location = new System.Drawing.Point(646, 30);
            this.lblTipoCalleAnt.Name = "lblTipoCalleAnt";
            this.lblTipoCalleAnt.Size = new System.Drawing.Size(70, 15);
            this.lblTipoCalleAnt.TabIndex = 6;
            this.lblTipoCalleAnt.Text = "*Tipo Calle:";
            // 
            // lblPaisCteAnt
            // 
            this.lblPaisCteAnt.AutoSize = true;
            this.lblPaisCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPaisCteAnt.Location = new System.Drawing.Point(249, 170);
            this.lblPaisCteAnt.Name = "lblPaisCteAnt";
            this.lblPaisCteAnt.Size = new System.Drawing.Size(39, 15);
            this.lblPaisCteAnt.TabIndex = 25;
            this.lblPaisCteAnt.Text = "*País:";
            // 
            // cmbTipoCalleAnt
            // 
            this.cmbTipoCalleAnt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoCalleAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoCalleAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbTipoCalleAnt.FormattingEnabled = true;
            this.cmbTipoCalleAnt.Location = new System.Drawing.Point(718, 27);
            this.cmbTipoCalleAnt.Name = "cmbTipoCalleAnt";
            this.cmbTipoCalleAnt.Size = new System.Drawing.Size(152, 23);
            this.cmbTipoCalleAnt.TabIndex = 7;
            this.cmbTipoCalleAnt.SelectedIndexChanged += new System.EventHandler(this.cmbTipoCalleAnt_SelectedIndexChanged);
            // 
            // txtEstCteAnt
            // 
            this.txtEstCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtEstCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEstCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEstCteAnt.Location = new System.Drawing.Point(64, 167);
            this.txtEstCteAnt.Name = "txtEstCteAnt";
            this.txtEstCteAnt.ReadOnly = true;
            this.txtEstCteAnt.Size = new System.Drawing.Size(152, 21);
            this.txtEstCteAnt.TabIndex = 24;
            // 
            // lblEntCAnt
            // 
            this.lblEntCAnt.AutoSize = true;
            this.lblEntCAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntCAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEntCAnt.Location = new System.Drawing.Point(10, 71);
            this.lblEntCAnt.Name = "lblEntCAnt";
            this.lblEntCAnt.Size = new System.Drawing.Size(76, 15);
            this.lblEntCAnt.TabIndex = 8;
            this.lblEntCAnt.Text = "Entre Calles:";
            // 
            // lblEstCteAnt
            // 
            this.lblEstCteAnt.AutoSize = true;
            this.lblEstCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEstCteAnt.Location = new System.Drawing.Point(10, 170);
            this.lblEstCteAnt.Name = "lblEstCteAnt";
            this.lblEstCteAnt.Size = new System.Drawing.Size(53, 15);
            this.lblEstCteAnt.TabIndex = 23;
            this.lblEstCteAnt.Text = "*Estado:";
            // 
            // lblColAnt
            // 
            this.lblColAnt.AutoSize = true;
            this.lblColAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblColAnt.Location = new System.Drawing.Point(10, 104);
            this.lblColAnt.Name = "lblColAnt";
            this.lblColAnt.Size = new System.Drawing.Size(57, 15);
            this.lblColAnt.TabIndex = 14;
            this.lblColAnt.Text = "*Colonia:";
            // 
            // txtPobCteAnt
            // 
            this.txtPobCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtPobCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPobCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPobCteAnt.Location = new System.Drawing.Point(623, 136);
            this.txtPobCteAnt.Name = "txtPobCteAnt";
            this.txtPobCteAnt.ReadOnly = true;
            this.txtPobCteAnt.Size = new System.Drawing.Size(194, 21);
            this.txtPobCteAnt.TabIndex = 22;
            // 
            // txtColCteAnt
            // 
            this.txtColCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtColCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtColCteAnt.Location = new System.Drawing.Point(72, 102);
            this.txtColCteAnt.Name = "txtColCteAnt";
            this.txtColCteAnt.ReadOnly = true;
            this.txtColCteAnt.Size = new System.Drawing.Size(230, 21);
            this.txtColCteAnt.TabIndex = 15;
            // 
            // lblPobCteAnt
            // 
            this.lblPobCteAnt.AutoSize = true;
            this.lblPobCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPobCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPobCteAnt.Location = new System.Drawing.Point(552, 139);
            this.lblPobCteAnt.Name = "lblPobCteAnt";
            this.lblPobCteAnt.Size = new System.Drawing.Size(70, 15);
            this.lblPobCteAnt.TabIndex = 21;
            this.lblPobCteAnt.Text = "*Población:";
            // 
            // btnBuscarAnt
            // 
            this.btnBuscarAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBuscarAnt.Location = new System.Drawing.Point(328, 100);
            this.btnBuscarAnt.Name = "btnBuscarAnt";
            this.btnBuscarAnt.Size = new System.Drawing.Size(111, 23);
            this.btnBuscarAnt.TabIndex = 16;
            this.btnBuscarAnt.Text = "Buscar Colonia";
            this.btnBuscarAnt.UseVisualStyleBackColor = true;
            this.btnBuscarAnt.Click += new System.EventHandler(this.btnBuscarAnt_Click);
            // 
            // txtDelCteAnt
            // 
            this.txtDelCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtDelCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDelCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDelCteAnt.Location = new System.Drawing.Point(325, 136);
            this.txtDelCteAnt.Name = "txtDelCteAnt";
            this.txtDelCteAnt.ReadOnly = true;
            this.txtDelCteAnt.Size = new System.Drawing.Size(208, 21);
            this.txtDelCteAnt.TabIndex = 20;
            // 
            // lblCpCteAnt
            // 
            this.lblCpCteAnt.AutoSize = true;
            this.lblCpCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCpCteAnt.Location = new System.Drawing.Point(11, 139);
            this.lblCpCteAnt.Name = "lblCpCteAnt";
            this.lblCpCteAnt.Size = new System.Drawing.Size(91, 15);
            this.lblCpCteAnt.TabIndex = 17;
            this.lblCpCteAnt.Text = "*Código Postal:";
            // 
            // lblDelCteAnt
            // 
            this.lblDelCteAnt.AutoSize = true;
            this.lblDelCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDelCteAnt.Location = new System.Drawing.Point(244, 139);
            this.lblDelCteAnt.Name = "lblDelCteAnt";
            this.lblDelCteAnt.Size = new System.Drawing.Size(78, 15);
            this.lblDelCteAnt.TabIndex = 19;
            this.lblDelCteAnt.Text = "*Delegación:";
            // 
            // txtCpCteAnt
            // 
            this.txtCpCteAnt.BackColor = System.Drawing.SystemColors.Control;
            this.txtCpCteAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpCteAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCpCteAnt.Location = new System.Drawing.Point(103, 136);
            this.txtCpCteAnt.Name = "txtCpCteAnt";
            this.txtCpCteAnt.ReadOnly = true;
            this.txtCpCteAnt.Size = new System.Drawing.Size(119, 21);
            this.txtCpCteAnt.TabIndex = 18;
            // 
            // grBoxDirCte
            // 
            this.grBoxDirCte.BackColor = System.Drawing.SystemColors.Control;
            this.grBoxDirCte.Controls.Add(this.txtCtrlMes);
            this.grBoxDirCte.Controls.Add(this.txtCtrlYear);
            this.grBoxDirCte.Controls.Add(this.cmbKeLiveEnC);
            this.grBoxDirCte.Controls.Add(this.lblKeViveEnC);
            this.grBoxDirCte.Controls.Add(this.cmbLiveCon);
            this.grBoxDirCte.Controls.Add(this.lblLiveCon);
            this.grBoxDirCte.Controls.Add(this.lblEdoC);
            this.grBoxDirCte.Controls.Add(this.txtEntreC);
            this.grBoxDirCte.Controls.Add(this.cmbEdoCivil);
            this.grBoxDirCte.Controls.Add(this.lblDom);
            this.grBoxDirCte.Controls.Add(this.lblMesAntCte);
            this.grBoxDirCte.Controls.Add(this.txtDir);
            this.grBoxDirCte.Controls.Add(this.lblNumEx);
            this.grBoxDirCte.Controls.Add(this.lblYearAntCte);
            this.grBoxDirCte.Controls.Add(this.txtNumExt);
            this.grBoxDirCte.Controls.Add(this.cmbViveCalCte);
            this.grBoxDirCte.Controls.Add(this.lblNumInt);
            this.grBoxDirCte.Controls.Add(this.lblViveCalCte);
            this.grBoxDirCte.Controls.Add(this.txtNumInt);
            this.grBoxDirCte.Controls.Add(this.txtPaisCte);
            this.grBoxDirCte.Controls.Add(this.lblTipo);
            this.grBoxDirCte.Controls.Add(this.lblPaisCte);
            this.grBoxDirCte.Controls.Add(this.cmbTipoCalle);
            this.grBoxDirCte.Controls.Add(this.txtEstCte);
            this.grBoxDirCte.Controls.Add(this.lblEntC);
            this.grBoxDirCte.Controls.Add(this.lblEstCte);
            this.grBoxDirCte.Controls.Add(this.lblCol);
            this.grBoxDirCte.Controls.Add(this.txtPobCte);
            this.grBoxDirCte.Controls.Add(this.txtColCte);
            this.grBoxDirCte.Controls.Add(this.lblPobCte);
            this.grBoxDirCte.Controls.Add(this.btnBuscar);
            this.grBoxDirCte.Controls.Add(this.txtDelCte);
            this.grBoxDirCte.Controls.Add(this.lblCpCte);
            this.grBoxDirCte.Controls.Add(this.lblDelCte);
            this.grBoxDirCte.Controls.Add(this.txtCpCte);
            this.grBoxDirCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grBoxDirCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grBoxDirCte.Location = new System.Drawing.Point(6, 175);
            this.grBoxDirCte.Name = "grBoxDirCte";
            this.grBoxDirCte.Size = new System.Drawing.Size(874, 246);
            this.grBoxDirCte.TabIndex = 1;
            this.grBoxDirCte.TabStop = false;
            this.grBoxDirCte.Text = "Direccion Actual";
            // 
            // txtCtrlMes
            // 
            this.txtCtrlMes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCtrlMes.Location = new System.Drawing.Point(759, 77);
            this.txtCtrlMes.MaxLength = 10;
            this.txtCtrlMes.Name = "txtCtrlMes";
            this.txtCtrlMes.Size = new System.Drawing.Size(63, 21);
            this.txtCtrlMes.TabIndex = 13;
            this.txtCtrlMes.TextChanged += new System.EventHandler(this.txtCtrlMes_TextChanged);
            this.txtCtrlMes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCtrlMes_KeyPress);
            // 
            // txtCtrlYear
            // 
            this.txtCtrlYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCtrlYear.Location = new System.Drawing.Point(542, 77);
            this.txtCtrlYear.MaxLength = 10;
            this.txtCtrlYear.Name = "txtCtrlYear";
            this.txtCtrlYear.Size = new System.Drawing.Size(67, 21);
            this.txtCtrlYear.TabIndex = 11;
            this.txtCtrlYear.TextChanged += new System.EventHandler(this.txtCtrlYear_TextChanged);
            this.txtCtrlYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCtrlYear_KeyPress);
            // 
            // cmbKeLiveEnC
            // 
            this.cmbKeLiveEnC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKeLiveEnC.Enabled = false;
            this.cmbKeLiveEnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbKeLiveEnC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbKeLiveEnC.FormattingEnabled = true;
            this.cmbKeLiveEnC.Location = new System.Drawing.Point(670, 213);
            this.cmbKeLiveEnC.Name = "cmbKeLiveEnC";
            this.cmbKeLiveEnC.Size = new System.Drawing.Size(152, 23);
            this.cmbKeLiveEnC.TabIndex = 32;
            this.cmbKeLiveEnC.SelectedIndexChanged += new System.EventHandler(this.cmbKeLiveEnC_SelectedIndexChanged);
            // 
            // lblKeViveEnC
            // 
            this.lblKeViveEnC.AutoSize = true;
            this.lblKeViveEnC.Enabled = false;
            this.lblKeViveEnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKeViveEnC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblKeViveEnC.Location = new System.Drawing.Point(530, 216);
            this.lblKeViveEnC.Name = "lblKeViveEnC";
            this.lblKeViveEnC.Size = new System.Drawing.Size(137, 15);
            this.lblKeViveEnC.TabIndex = 31;
            this.lblKeViveEnC.Text = "Que Vive en Calidad de:";
            // 
            // cmbLiveCon
            // 
            this.cmbLiveCon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLiveCon.Enabled = false;
            this.cmbLiveCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLiveCon.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbLiveCon.FormattingEnabled = true;
            this.cmbLiveCon.Location = new System.Drawing.Point(313, 213);
            this.cmbLiveCon.Name = "cmbLiveCon";
            this.cmbLiveCon.Size = new System.Drawing.Size(141, 23);
            this.cmbLiveCon.TabIndex = 30;
            this.cmbLiveCon.SelectedIndexChanged += new System.EventHandler(this.cmbLiveCon_SelectedIndexChanged);
            // 
            // lblLiveCon
            // 
            this.lblLiveCon.AutoSize = true;
            this.lblLiveCon.Enabled = false;
            this.lblLiveCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLiveCon.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblLiveCon.Location = new System.Drawing.Point(252, 216);
            this.lblLiveCon.Name = "lblLiveCon";
            this.lblLiveCon.Size = new System.Drawing.Size(57, 15);
            this.lblLiveCon.TabIndex = 29;
            this.lblLiveCon.Text = "Vive Con:";
            // 
            // lblEdoC
            // 
            this.lblEdoC.AutoSize = true;
            this.lblEdoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdoC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEdoC.Location = new System.Drawing.Point(8, 216);
            this.lblEdoC.Name = "lblEdoC";
            this.lblEdoC.Size = new System.Drawing.Size(78, 15);
            this.lblEdoC.TabIndex = 19;
            this.lblEdoC.Text = "*Estado Civil:";
            // 
            // txtEntreC
            // 
            this.txtEntreC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEntreC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntreC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEntreC.Location = new System.Drawing.Point(85, 77);
            this.txtEntreC.MaxLength = 250;
            this.txtEntreC.Name = "txtEntreC";
            this.txtEntreC.Size = new System.Drawing.Size(288, 21);
            this.txtEntreC.TabIndex = 9;
            // 
            // cmbEdoCivil
            // 
            this.cmbEdoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEdoCivil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEdoCivil.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbEdoCivil.FormattingEnabled = true;
            this.cmbEdoCivil.Location = new System.Drawing.Point(87, 213);
            this.cmbEdoCivil.Name = "cmbEdoCivil";
            this.cmbEdoCivil.Size = new System.Drawing.Size(121, 23);
            this.cmbEdoCivil.TabIndex = 20;
            this.cmbEdoCivil.SelectedIndexChanged += new System.EventHandler(this.cmbEdoCivil_SelectedIndexChanged);
            // 
            // lblDom
            // 
            this.lblDom.AutoSize = true;
            this.lblDom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDom.Location = new System.Drawing.Point(8, 39);
            this.lblDom.Name = "lblDom";
            this.lblDom.Size = new System.Drawing.Size(67, 15);
            this.lblDom.TabIndex = 0;
            this.lblDom.Text = "*Direccion:";
            // 
            // lblMesAntCte
            // 
            this.lblMesAntCte.AutoSize = true;
            this.lblMesAntCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesAntCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMesAntCte.Location = new System.Drawing.Point(641, 80);
            this.lblMesAntCte.Name = "lblMesAntCte";
            this.lblMesAntCte.Size = new System.Drawing.Size(117, 15);
            this.lblMesAntCte.TabIndex = 12;
            this.lblMesAntCte.Text = "*Meses Antigüedad:";
            // 
            // txtDir
            // 
            this.txtDir.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDir.Location = new System.Drawing.Point(81, 36);
            this.txtDir.MaxLength = 200;
            this.txtDir.Name = "txtDir";
            this.txtDir.Size = new System.Drawing.Size(299, 21);
            this.txtDir.TabIndex = 1;
            // 
            // lblNumEx
            // 
            this.lblNumEx.AutoSize = true;
            this.lblNumEx.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumEx.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNumEx.Location = new System.Drawing.Point(398, 39);
            this.lblNumEx.Name = "lblNumEx";
            this.lblNumEx.Size = new System.Drawing.Size(57, 15);
            this.lblNumEx.TabIndex = 2;
            this.lblNumEx.Text = "Num Ext:";
            // 
            // lblYearAntCte
            // 
            this.lblYearAntCte.AutoSize = true;
            this.lblYearAntCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYearAntCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblYearAntCte.Location = new System.Drawing.Point(419, 80);
            this.lblYearAntCte.Name = "lblYearAntCte";
            this.lblYearAntCte.Size = new System.Drawing.Size(119, 15);
            this.lblYearAntCte.TabIndex = 10;
            this.lblYearAntCte.Text = "Años de Antigüedad:";
            // 
            // txtNumExt
            // 
            this.txtNumExt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumExt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumExt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumExt.Location = new System.Drawing.Point(462, 36);
            this.txtNumExt.MaxLength = 10;
            this.txtNumExt.Name = "txtNumExt";
            this.txtNumExt.Size = new System.Drawing.Size(45, 21);
            this.txtNumExt.TabIndex = 3;
            this.txtNumExt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumExt_KeyPress);
            // 
            // cmbViveCalCte
            // 
            this.cmbViveCalCte.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbViveCalCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbViveCalCte.ForeColor = System.Drawing.SystemColors.Highlight;
            this.cmbViveCalCte.FormattingEnabled = true;
            this.cmbViveCalCte.Location = new System.Drawing.Point(662, 176);
            this.cmbViveCalCte.Name = "cmbViveCalCte";
            this.cmbViveCalCte.Size = new System.Drawing.Size(152, 23);
            this.cmbViveCalCte.TabIndex = 28;
            this.cmbViveCalCte.SelectedIndexChanged += new System.EventHandler(this.cmbViveCalCte_SelectedIndexChanged);
            // 
            // lblNumInt
            // 
            this.lblNumInt.AutoSize = true;
            this.lblNumInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumInt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNumInt.Location = new System.Drawing.Point(527, 39);
            this.lblNumInt.Name = "lblNumInt";
            this.lblNumInt.Size = new System.Drawing.Size(53, 15);
            this.lblNumInt.TabIndex = 4;
            this.lblNumInt.Text = "Num Int:";
            // 
            // lblViveCalCte
            // 
            this.lblViveCalCte.AutoSize = true;
            this.lblViveCalCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViveCalCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblViveCalCte.Location = new System.Drawing.Point(560, 179);
            this.lblViveCalCte.Name = "lblViveCalCte";
            this.lblViveCalCte.Size = new System.Drawing.Size(100, 15);
            this.lblViveCalCte.TabIndex = 27;
            this.lblViveCalCte.Text = "*Vive en calidad :";
            // 
            // txtNumInt
            // 
            this.txtNumInt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumInt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumInt.Location = new System.Drawing.Point(582, 36);
            this.txtNumInt.MaxLength = 10;
            this.txtNumInt.Name = "txtNumInt";
            this.txtNumInt.Size = new System.Drawing.Size(45, 21);
            this.txtNumInt.TabIndex = 5;
            // 
            // txtPaisCte
            // 
            this.txtPaisCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtPaisCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaisCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPaisCte.Location = new System.Drawing.Point(283, 176);
            this.txtPaisCte.Name = "txtPaisCte";
            this.txtPaisCte.ReadOnly = true;
            this.txtPaisCte.Size = new System.Drawing.Size(206, 21);
            this.txtPaisCte.TabIndex = 26;
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTipo.Location = new System.Drawing.Point(644, 39);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(70, 15);
            this.lblTipo.TabIndex = 6;
            this.lblTipo.Text = "*Tipo Calle:";
            // 
            // lblPaisCte
            // 
            this.lblPaisCte.AutoSize = true;
            this.lblPaisCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPaisCte.Location = new System.Drawing.Point(243, 179);
            this.lblPaisCte.Name = "lblPaisCte";
            this.lblPaisCte.Size = new System.Drawing.Size(39, 15);
            this.lblPaisCte.TabIndex = 25;
            this.lblPaisCte.Text = "*País:";
            // 
            // cmbTipoCalle
            // 
            this.cmbTipoCalle.BackColor = System.Drawing.SystemColors.Window;
            this.cmbTipoCalle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoCalle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoCalle.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbTipoCalle.FormattingEnabled = true;
            this.cmbTipoCalle.Location = new System.Drawing.Point(716, 36);
            this.cmbTipoCalle.Name = "cmbTipoCalle";
            this.cmbTipoCalle.Size = new System.Drawing.Size(152, 23);
            this.cmbTipoCalle.TabIndex = 7;
            this.cmbTipoCalle.SelectedIndexChanged += new System.EventHandler(this.cmbTipoCalle_SelectedIndexChanged);
            // 
            // txtEstCte
            // 
            this.txtEstCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtEstCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEstCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEstCte.Location = new System.Drawing.Point(63, 176);
            this.txtEstCte.Name = "txtEstCte";
            this.txtEstCte.ReadOnly = true;
            this.txtEstCte.Size = new System.Drawing.Size(152, 21);
            this.txtEstCte.TabIndex = 24;
            // 
            // lblEntC
            // 
            this.lblEntC.AutoSize = true;
            this.lblEntC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEntC.Location = new System.Drawing.Point(8, 80);
            this.lblEntC.Name = "lblEntC";
            this.lblEntC.Size = new System.Drawing.Size(76, 15);
            this.lblEntC.TabIndex = 8;
            this.lblEntC.Text = "Entre Calles:";
            // 
            // lblEstCte
            // 
            this.lblEstCte.AutoSize = true;
            this.lblEstCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEstCte.Location = new System.Drawing.Point(8, 179);
            this.lblEstCte.Name = "lblEstCte";
            this.lblEstCte.Size = new System.Drawing.Size(53, 15);
            this.lblEstCte.TabIndex = 23;
            this.lblEstCte.Text = "*Estado:";
            // 
            // lblCol
            // 
            this.lblCol.AutoSize = true;
            this.lblCol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCol.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCol.Location = new System.Drawing.Point(8, 113);
            this.lblCol.Name = "lblCol";
            this.lblCol.Size = new System.Drawing.Size(57, 15);
            this.lblCol.TabIndex = 14;
            this.lblCol.Text = "*Colonia:";
            // 
            // txtPobCte
            // 
            this.txtPobCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtPobCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPobCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPobCte.Location = new System.Drawing.Point(623, 145);
            this.txtPobCte.Name = "txtPobCte";
            this.txtPobCte.ReadOnly = true;
            this.txtPobCte.Size = new System.Drawing.Size(194, 21);
            this.txtPobCte.TabIndex = 22;
            // 
            // txtColCte
            // 
            this.txtColCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtColCte.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtColCte.Location = new System.Drawing.Point(70, 111);
            this.txtColCte.Name = "txtColCte";
            this.txtColCte.ReadOnly = true;
            this.txtColCte.Size = new System.Drawing.Size(230, 21);
            this.txtColCte.TabIndex = 15;
            // 
            // lblPobCte
            // 
            this.lblPobCte.AutoSize = true;
            this.lblPobCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPobCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPobCte.Location = new System.Drawing.Point(550, 148);
            this.lblPobCte.Name = "lblPobCte";
            this.lblPobCte.Size = new System.Drawing.Size(70, 15);
            this.lblPobCte.TabIndex = 21;
            this.lblPobCte.Text = "*Población:";
            // 
            // btnBuscar
            // 
            this.btnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBuscar.Location = new System.Drawing.Point(326, 109);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(111, 23);
            this.btnBuscar.TabIndex = 16;
            this.btnBuscar.Text = "Buscar Colonia";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txtDelCte
            // 
            this.txtDelCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtDelCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDelCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDelCte.Location = new System.Drawing.Point(323, 145);
            this.txtDelCte.Name = "txtDelCte";
            this.txtDelCte.ReadOnly = true;
            this.txtDelCte.Size = new System.Drawing.Size(208, 21);
            this.txtDelCte.TabIndex = 20;
            // 
            // lblCpCte
            // 
            this.lblCpCte.AutoSize = true;
            this.lblCpCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCpCte.Location = new System.Drawing.Point(9, 148);
            this.lblCpCte.Name = "lblCpCte";
            this.lblCpCte.Size = new System.Drawing.Size(91, 15);
            this.lblCpCte.TabIndex = 17;
            this.lblCpCte.Text = "*Código Postal:";
            // 
            // lblDelCte
            // 
            this.lblDelCte.AutoSize = true;
            this.lblDelCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDelCte.Location = new System.Drawing.Point(242, 148);
            this.lblDelCte.Name = "lblDelCte";
            this.lblDelCte.Size = new System.Drawing.Size(78, 15);
            this.lblDelCte.TabIndex = 19;
            this.lblDelCte.Text = "*Delegación:";
            // 
            // txtCpCte
            // 
            this.txtCpCte.BackColor = System.Drawing.SystemColors.Control;
            this.txtCpCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCpCte.Location = new System.Drawing.Point(103, 145);
            this.txtCpCte.Name = "txtCpCte";
            this.txtCpCte.ReadOnly = true;
            this.txtCpCte.Size = new System.Drawing.Size(119, 21);
            this.txtCpCte.TabIndex = 18;
            // 
            // grboxCaps
            // 
            this.grboxCaps.BackColor = System.Drawing.SystemColors.Control;
            this.grboxCaps.Controls.Add(this.lblSpid);
            this.grboxCaps.Controls.Add(this.btnGoogle);
            this.grboxCaps.Controls.Add(this.btnImp);
            this.grboxCaps.Controls.Add(this.btnTelefonos);
            this.grboxCaps.Controls.Add(this.btnSalir);
            this.grboxCaps.Controls.Add(this.btnAceptar);
            this.grboxCaps.Controls.Add(this.btnDatNomi);
            this.grboxCaps.Controls.Add(this.btnCapRefCte);
            this.grboxCaps.Controls.Add(this.btnCapEmpCte);
            this.grboxCaps.Controls.Add(this.lblCon);
            this.grboxCaps.Controls.Add(this.btnCapDatCte);
            this.grboxCaps.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grboxCaps.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grboxCaps.Location = new System.Drawing.Point(8, 10);
            this.grboxCaps.Name = "grboxCaps";
            this.grboxCaps.Size = new System.Drawing.Size(164, 674);
            this.grboxCaps.TabIndex = 7;
            this.grboxCaps.TabStop = false;
            this.grboxCaps.Text = "Capturas";
            // 
            // lblSpid
            // 
            this.lblSpid.AutoSize = true;
            this.lblSpid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpid.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblSpid.Location = new System.Drawing.Point(104, 650);
            this.lblSpid.Name = "lblSpid";
            this.lblSpid.Size = new System.Drawing.Size(38, 15);
            this.lblSpid.TabIndex = 11;
            this.lblSpid.Text = "Spid: ";
            // 
            // btnGoogle
            // 
            this.btnGoogle.BackColor = System.Drawing.SystemColors.Control;
            this.btnGoogle.FlatAppearance.BorderSize = 0;
            this.btnGoogle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGoogle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoogle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGoogle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGoogle.Location = new System.Drawing.Point(6, 131);
            this.btnGoogle.Margin = new System.Windows.Forms.Padding(2);
            this.btnGoogle.Name = "btnGoogle";
            this.btnGoogle.Size = new System.Drawing.Size(149, 42);
            this.btnGoogle.TabIndex = 10;
            this.btnGoogle.Text = "Google Maps";
            this.btnGoogle.UseVisualStyleBackColor = false;
            this.btnGoogle.Click += new System.EventHandler(this.btnGoogle_Click);
            // 
            // btnImp
            // 
            this.btnImp.BackColor = System.Drawing.SystemColors.Control;
            this.btnImp.FlatAppearance.BorderSize = 0;
            this.btnImp.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnImp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnImp.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImp.Location = new System.Drawing.Point(7, 78);
            this.btnImp.Margin = new System.Windows.Forms.Padding(2);
            this.btnImp.Name = "btnImp";
            this.btnImp.Size = new System.Drawing.Size(149, 42);
            this.btnImp.TabIndex = 9;
            this.btnImp.Text = "Imprimir Formato";
            this.btnImp.UseVisualStyleBackColor = false;
            this.btnImp.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTelefonos
            // 
            this.btnTelefonos.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTelefonos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnTelefonos.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnTelefonos.Location = new System.Drawing.Point(6, 430);
            this.btnTelefonos.Name = "btnTelefonos";
            this.btnTelefonos.Size = new System.Drawing.Size(150, 45);
            this.btnTelefonos.TabIndex = 8;
            this.btnTelefonos.Text = "Editar Telefonos";
            this.btnTelefonos.UseVisualStyleBackColor = false;
            this.btnTelefonos.Click += new System.EventHandler(this.btnTelefonos_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.SystemColors.Control;
            this.btnSalir.FlatAppearance.BorderSize = 0;
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalir.Location = new System.Drawing.Point(6, 489);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(149, 42);
            this.btnSalir.TabIndex = 7;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackColor = System.Drawing.SystemColors.Control;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAceptar.Location = new System.Drawing.Point(7, 27);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(2);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(149, 42);
            this.btnAceptar.TabIndex = 0;
            this.btnAceptar.Text = "Guardar Captura";
            this.btnAceptar.UseVisualStyleBackColor = false;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnDatNomi
            // 
            this.btnDatNomi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDatNomi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDatNomi.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnDatNomi.Location = new System.Drawing.Point(6, 310);
            this.btnDatNomi.Name = "btnDatNomi";
            this.btnDatNomi.Size = new System.Drawing.Size(150, 45);
            this.btnDatNomi.TabIndex = 4;
            this.btnDatNomi.Text = "Editar Datos Nominales";
            this.btnDatNomi.UseVisualStyleBackColor = false;
            this.btnDatNomi.Click += new System.EventHandler(this.btnDatNomi_Click);
            // 
            // btnCapRefCte
            // 
            this.btnCapRefCte.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCapRefCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCapRefCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnCapRefCte.Location = new System.Drawing.Point(6, 370);
            this.btnCapRefCte.Name = "btnCapRefCte";
            this.btnCapRefCte.Size = new System.Drawing.Size(150, 45);
            this.btnCapRefCte.TabIndex = 3;
            this.btnCapRefCte.Text = "Editar Refencias Comerciales";
            this.btnCapRefCte.UseVisualStyleBackColor = false;
            this.btnCapRefCte.Click += new System.EventHandler(this.btnCapRefCte_Click);
            // 
            // btnCapEmpCte
            // 
            this.btnCapEmpCte.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCapEmpCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCapEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnCapEmpCte.Location = new System.Drawing.Point(6, 250);
            this.btnCapEmpCte.Name = "btnCapEmpCte";
            this.btnCapEmpCte.Size = new System.Drawing.Size(150, 45);
            this.btnCapEmpCte.TabIndex = 2;
            this.btnCapEmpCte.Text = "Editar Empleo";
            this.btnCapEmpCte.UseVisualStyleBackColor = false;
            this.btnCapEmpCte.Click += new System.EventHandler(this.btnCapEmpCte_Click);
            // 
            // lblCon
            // 
            this.lblCon.AutoSize = true;
            this.lblCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCon.Location = new System.Drawing.Point(25, 603);
            this.lblCon.Name = "lblCon";
            this.lblCon.Size = new System.Drawing.Size(0, 24);
            this.lblCon.TabIndex = 5;
            // 
            // btnCapDatCte
            // 
            this.btnCapDatCte.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCapDatCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCapDatCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnCapDatCte.Location = new System.Drawing.Point(6, 190);
            this.btnCapDatCte.Name = "btnCapDatCte";
            this.btnCapDatCte.Size = new System.Drawing.Size(150, 45);
            this.btnCapDatCte.TabIndex = 1;
            this.btnCapDatCte.Text = "Editar Datos Gral Cliente";
            this.btnCapDatCte.UseVisualStyleBackColor = false;
            this.btnCapDatCte.Click += new System.EventHandler(this.btnCapDatCte_Click);
            // 
            // grboxEmpleoCte
            // 
            this.grboxEmpleoCte.AutoSize = true;
            this.grboxEmpleoCte.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grboxEmpleoCte.BackColor = System.Drawing.Color.LightBlue;
            this.grboxEmpleoCte.Controls.Add(this.grboxDirEmpA);
            this.grboxEmpleoCte.Controls.Add(this.grboxDirEmpleo);
            this.grboxEmpleoCte.Controls.Add(this.grbEmpCte);
            this.grboxEmpleoCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grboxEmpleoCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grboxEmpleoCte.Location = new System.Drawing.Point(185, 995);
            this.grboxEmpleoCte.Name = "grboxEmpleoCte";
            this.grboxEmpleoCte.Size = new System.Drawing.Size(887, 599);
            this.grboxEmpleoCte.TabIndex = 2;
            this.grboxEmpleoCte.TabStop = false;
            this.grboxEmpleoCte.Text = "Empleo Cliente";
            // 
            // grboxDirEmpA
            // 
            this.grboxDirEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.grboxDirEmpA.Controls.Add(this.txtEmpAnt);
            this.grboxDirEmpA.Controls.Add(this.lblEmpAnt);
            this.grboxDirEmpA.Controls.Add(this.txtEntCalleEa);
            this.grboxDirEmpA.Controls.Add(this.lblDirAntE);
            this.grboxDirEmpA.Controls.Add(this.txtDirAntE);
            this.grboxDirEmpA.Controls.Add(this.lblExtEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtExtEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblIntEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtIntEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtPaisEmpA);
            this.grboxDirEmpA.Controls.Add(this.label7);
            this.grboxDirEmpA.Controls.Add(this.lblPaisEmpA);
            this.grboxDirEmpA.Controls.Add(this.cmbTipCalleEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtEstEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblEntCalleEa);
            this.grboxDirEmpA.Controls.Add(this.lblEstEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblColEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtPobEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtColEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblPobEmpA);
            this.grboxDirEmpA.Controls.Add(this.btnBusColA);
            this.grboxDirEmpA.Controls.Add(this.txtDelEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblCpEmpA);
            this.grboxDirEmpA.Controls.Add(this.lblDelEmpA);
            this.grboxDirEmpA.Controls.Add(this.txtCpEmpA);
            this.grboxDirEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grboxDirEmpA.Location = new System.Drawing.Point(6, 409);
            this.grboxDirEmpA.Name = "grboxDirEmpA";
            this.grboxDirEmpA.Size = new System.Drawing.Size(874, 169);
            this.grboxDirEmpA.TabIndex = 2;
            this.grboxDirEmpA.TabStop = false;
            this.grboxDirEmpA.Text = "Direccion Empleo Anterior";
            // 
            // txtEmpAnt
            // 
            this.txtEmpAnt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmpAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmpAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmpAnt.Location = new System.Drawing.Point(73, 25);
            this.txtEmpAnt.MaxLength = 100;
            this.txtEmpAnt.Name = "txtEmpAnt";
            this.txtEmpAnt.Size = new System.Drawing.Size(347, 21);
            this.txtEmpAnt.TabIndex = 1;
            // 
            // lblEmpAnt
            // 
            this.lblEmpAnt.AutoSize = true;
            this.lblEmpAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpAnt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmpAnt.Location = new System.Drawing.Point(5, 28);
            this.lblEmpAnt.Name = "lblEmpAnt";
            this.lblEmpAnt.Size = new System.Drawing.Size(60, 15);
            this.lblEmpAnt.TabIndex = 0;
            this.lblEmpAnt.Text = "Empresa:";
            // 
            // txtEntCalleEa
            // 
            this.txtEntCalleEa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEntCalleEa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntCalleEa.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEntCalleEa.Location = new System.Drawing.Point(577, 63);
            this.txtEntCalleEa.MaxLength = 150;
            this.txtEntCalleEa.Name = "txtEntCalleEa";
            this.txtEntCalleEa.Size = new System.Drawing.Size(288, 21);
            this.txtEntCalleEa.TabIndex = 11;
            // 
            // lblDirAntE
            // 
            this.lblDirAntE.AutoSize = true;
            this.lblDirAntE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirAntE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDirAntE.Location = new System.Drawing.Point(423, 28);
            this.lblDirAntE.Name = "lblDirAntE";
            this.lblDirAntE.Size = new System.Drawing.Size(62, 15);
            this.lblDirAntE.TabIndex = 2;
            this.lblDirAntE.Text = "Direccion:";
            // 
            // txtDirAntE
            // 
            this.txtDirAntE.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDirAntE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirAntE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDirAntE.Location = new System.Drawing.Point(493, 25);
            this.txtDirAntE.MaxLength = 150;
            this.txtDirAntE.Name = "txtDirAntE";
            this.txtDirAntE.Size = new System.Drawing.Size(372, 21);
            this.txtDirAntE.TabIndex = 3;
            // 
            // lblExtEmpA
            // 
            this.lblExtEmpA.AutoSize = true;
            this.lblExtEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblExtEmpA.Location = new System.Drawing.Point(10, 66);
            this.lblExtEmpA.Name = "lblExtEmpA";
            this.lblExtEmpA.Size = new System.Drawing.Size(57, 15);
            this.lblExtEmpA.TabIndex = 4;
            this.lblExtEmpA.Text = "Num Ext:";
            // 
            // txtExtEmpA
            // 
            this.txtExtEmpA.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtExtEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtExtEmpA.Location = new System.Drawing.Point(74, 63);
            this.txtExtEmpA.MaxLength = 10;
            this.txtExtEmpA.Name = "txtExtEmpA";
            this.txtExtEmpA.Size = new System.Drawing.Size(45, 21);
            this.txtExtEmpA.TabIndex = 5;
            // 
            // lblIntEmpA
            // 
            this.lblIntEmpA.AutoSize = true;
            this.lblIntEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblIntEmpA.Location = new System.Drawing.Point(139, 66);
            this.lblIntEmpA.Name = "lblIntEmpA";
            this.lblIntEmpA.Size = new System.Drawing.Size(53, 15);
            this.lblIntEmpA.TabIndex = 6;
            this.lblIntEmpA.Text = "Num Int:";
            // 
            // txtIntEmpA
            // 
            this.txtIntEmpA.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtIntEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIntEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtIntEmpA.Location = new System.Drawing.Point(194, 63);
            this.txtIntEmpA.MaxLength = 10;
            this.txtIntEmpA.Name = "txtIntEmpA";
            this.txtIntEmpA.Size = new System.Drawing.Size(45, 21);
            this.txtIntEmpA.TabIndex = 7;
            // 
            // txtPaisEmpA
            // 
            this.txtPaisEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtPaisEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaisEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPaisEmpA.Location = new System.Drawing.Point(757, 135);
            this.txtPaisEmpA.Name = "txtPaisEmpA";
            this.txtPaisEmpA.ReadOnly = true;
            this.txtPaisEmpA.Size = new System.Drawing.Size(112, 21);
            this.txtPaisEmpA.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(261, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 8;
            this.label7.Text = "Tipo Calle:";
            // 
            // lblPaisEmpA
            // 
            this.lblPaisEmpA.AutoSize = true;
            this.lblPaisEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPaisEmpA.Location = new System.Drawing.Point(714, 138);
            this.lblPaisEmpA.Name = "lblPaisEmpA";
            this.lblPaisEmpA.Size = new System.Drawing.Size(34, 15);
            this.lblPaisEmpA.TabIndex = 23;
            this.lblPaisEmpA.Text = "País:";
            // 
            // cmbTipCalleEmpA
            // 
            this.cmbTipCalleEmpA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipCalleEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipCalleEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbTipCalleEmpA.FormattingEnabled = true;
            this.cmbTipCalleEmpA.Location = new System.Drawing.Point(333, 63);
            this.cmbTipCalleEmpA.Name = "cmbTipCalleEmpA";
            this.cmbTipCalleEmpA.Size = new System.Drawing.Size(152, 23);
            this.cmbTipCalleEmpA.TabIndex = 9;
            this.cmbTipCalleEmpA.SelectedIndexChanged += new System.EventHandler(this.cmbTipCalleEmpA_SelectedIndexChanged);
            // 
            // txtEstEmpA
            // 
            this.txtEstEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtEstEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEstEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEstEmpA.Location = new System.Drawing.Point(346, 135);
            this.txtEstEmpA.Name = "txtEstEmpA";
            this.txtEstEmpA.ReadOnly = true;
            this.txtEstEmpA.Size = new System.Drawing.Size(152, 21);
            this.txtEstEmpA.TabIndex = 20;
            // 
            // lblEntCalleEa
            // 
            this.lblEntCalleEa.AutoSize = true;
            this.lblEntCalleEa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntCalleEa.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEntCalleEa.Location = new System.Drawing.Point(500, 66);
            this.lblEntCalleEa.Name = "lblEntCalleEa";
            this.lblEntCalleEa.Size = new System.Drawing.Size(76, 15);
            this.lblEntCalleEa.TabIndex = 10;
            this.lblEntCalleEa.Text = "Entre Calles:";
            // 
            // lblEstEmpA
            // 
            this.lblEstEmpA.AutoSize = true;
            this.lblEstEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEstEmpA.Location = new System.Drawing.Point(289, 138);
            this.lblEstEmpA.Name = "lblEstEmpA";
            this.lblEstEmpA.Size = new System.Drawing.Size(48, 15);
            this.lblEstEmpA.TabIndex = 19;
            this.lblEstEmpA.Text = "Estado:";
            // 
            // lblColEmpA
            // 
            this.lblColEmpA.AutoSize = true;
            this.lblColEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblColEmpA.Location = new System.Drawing.Point(8, 102);
            this.lblColEmpA.Name = "lblColEmpA";
            this.lblColEmpA.Size = new System.Drawing.Size(52, 15);
            this.lblColEmpA.TabIndex = 12;
            this.lblColEmpA.Text = "Colonia:";
            // 
            // txtPobEmpA
            // 
            this.txtPobEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtPobEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPobEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPobEmpA.Location = new System.Drawing.Point(81, 135);
            this.txtPobEmpA.Name = "txtPobEmpA";
            this.txtPobEmpA.ReadOnly = true;
            this.txtPobEmpA.Size = new System.Drawing.Size(194, 21);
            this.txtPobEmpA.TabIndex = 18;
            // 
            // txtColEmpA
            // 
            this.txtColEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtColEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtColEmpA.Location = new System.Drawing.Point(70, 100);
            this.txtColEmpA.Name = "txtColEmpA";
            this.txtColEmpA.ReadOnly = true;
            this.txtColEmpA.Size = new System.Drawing.Size(230, 21);
            this.txtColEmpA.TabIndex = 13;
            // 
            // lblPobEmpA
            // 
            this.lblPobEmpA.AutoSize = true;
            this.lblPobEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPobEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPobEmpA.Location = new System.Drawing.Point(8, 138);
            this.lblPobEmpA.Name = "lblPobEmpA";
            this.lblPobEmpA.Size = new System.Drawing.Size(65, 15);
            this.lblPobEmpA.TabIndex = 17;
            this.lblPobEmpA.Text = "Población:";
            // 
            // btnBusColA
            // 
            this.btnBusColA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBusColA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBusColA.Location = new System.Drawing.Point(343, 99);
            this.btnBusColA.Name = "btnBusColA";
            this.btnBusColA.Size = new System.Drawing.Size(111, 23);
            this.btnBusColA.TabIndex = 14;
            this.btnBusColA.Text = "Buscar Colonia";
            this.btnBusColA.UseVisualStyleBackColor = true;
            this.btnBusColA.Click += new System.EventHandler(this.btnBusColA_Click);
            // 
            // txtDelEmpA
            // 
            this.txtDelEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtDelEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDelEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDelEmpA.Location = new System.Drawing.Point(597, 101);
            this.txtDelEmpA.Name = "txtDelEmpA";
            this.txtDelEmpA.ReadOnly = true;
            this.txtDelEmpA.Size = new System.Drawing.Size(270, 21);
            this.txtDelEmpA.TabIndex = 16;
            // 
            // lblCpEmpA
            // 
            this.lblCpEmpA.AutoSize = true;
            this.lblCpEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCpEmpA.Location = new System.Drawing.Point(513, 138);
            this.lblCpEmpA.Name = "lblCpEmpA";
            this.lblCpEmpA.Size = new System.Drawing.Size(86, 15);
            this.lblCpEmpA.TabIndex = 21;
            this.lblCpEmpA.Text = "Código Postal:";
            // 
            // lblDelEmpA
            // 
            this.lblDelEmpA.AutoSize = true;
            this.lblDelEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDelEmpA.Location = new System.Drawing.Point(516, 104);
            this.lblDelEmpA.Name = "lblDelEmpA";
            this.lblDelEmpA.Size = new System.Drawing.Size(73, 15);
            this.lblDelEmpA.TabIndex = 15;
            this.lblDelEmpA.Text = "Delegación:";
            // 
            // txtCpEmpA
            // 
            this.txtCpEmpA.BackColor = System.Drawing.SystemColors.Control;
            this.txtCpEmpA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpEmpA.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCpEmpA.Location = new System.Drawing.Point(607, 135);
            this.txtCpEmpA.Name = "txtCpEmpA";
            this.txtCpEmpA.ReadOnly = true;
            this.txtCpEmpA.Size = new System.Drawing.Size(101, 21);
            this.txtCpEmpA.TabIndex = 22;
            // 
            // grboxDirEmpleo
            // 
            this.grboxDirEmpleo.BackColor = System.Drawing.SystemColors.Control;
            this.grboxDirEmpleo.Controls.Add(this.txtEntCalleE);
            this.grboxDirEmpleo.Controls.Add(this.lblDirEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtDirEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblNumExEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtNumExtEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblNumIntEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtNumIntEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtPaisEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblTipCalleE);
            this.grboxDirEmpleo.Controls.Add(this.lblPaisE);
            this.grboxDirEmpleo.Controls.Add(this.cmbTipCalleE);
            this.grboxDirEmpleo.Controls.Add(this.txtEstEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblEntCalleE);
            this.grboxDirEmpleo.Controls.Add(this.lblEstEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblColEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtPobEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtColEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblPobEmp);
            this.grboxDirEmpleo.Controls.Add(this.btnBusColE);
            this.grboxDirEmpleo.Controls.Add(this.txtDelEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblCpEmp);
            this.grboxDirEmpleo.Controls.Add(this.lblDelEmp);
            this.grboxDirEmpleo.Controls.Add(this.txtCpEmp);
            this.grboxDirEmpleo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grboxDirEmpleo.Location = new System.Drawing.Point(6, 233);
            this.grboxDirEmpleo.Name = "grboxDirEmpleo";
            this.grboxDirEmpleo.Size = new System.Drawing.Size(874, 169);
            this.grboxDirEmpleo.TabIndex = 1;
            this.grboxDirEmpleo.TabStop = false;
            this.grboxDirEmpleo.Text = "Direccion Empleo";
            // 
            // txtEntCalleE
            // 
            this.txtEntCalleE.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEntCalleE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntCalleE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEntCalleE.Location = new System.Drawing.Point(84, 65);
            this.txtEntCalleE.MaxLength = 150;
            this.txtEntCalleE.Name = "txtEntCalleE";
            this.txtEntCalleE.Size = new System.Drawing.Size(288, 21);
            this.txtEntCalleE.TabIndex = 9;
            // 
            // lblDirEmp
            // 
            this.lblDirEmp.AutoSize = true;
            this.lblDirEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDirEmp.Location = new System.Drawing.Point(7, 27);
            this.lblDirEmp.Name = "lblDirEmp";
            this.lblDirEmp.Size = new System.Drawing.Size(62, 15);
            this.lblDirEmp.TabIndex = 0;
            this.lblDirEmp.Text = "Direccion:";
            // 
            // txtDirEmp
            // 
            this.txtDirEmp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDirEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDirEmp.Location = new System.Drawing.Point(85, 24);
            this.txtDirEmp.MaxLength = 150;
            this.txtDirEmp.Name = "txtDirEmp";
            this.txtDirEmp.Size = new System.Drawing.Size(299, 21);
            this.txtDirEmp.TabIndex = 1;
            // 
            // lblNumExEmp
            // 
            this.lblNumExEmp.AutoSize = true;
            this.lblNumExEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumExEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNumExEmp.Location = new System.Drawing.Point(397, 27);
            this.lblNumExEmp.Name = "lblNumExEmp";
            this.lblNumExEmp.Size = new System.Drawing.Size(57, 15);
            this.lblNumExEmp.TabIndex = 2;
            this.lblNumExEmp.Text = "Num Ext:";
            // 
            // txtNumExtEmp
            // 
            this.txtNumExtEmp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumExtEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumExtEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumExtEmp.Location = new System.Drawing.Point(461, 24);
            this.txtNumExtEmp.MaxLength = 10;
            this.txtNumExtEmp.Name = "txtNumExtEmp";
            this.txtNumExtEmp.Size = new System.Drawing.Size(45, 21);
            this.txtNumExtEmp.TabIndex = 3;
            // 
            // lblNumIntEmp
            // 
            this.lblNumIntEmp.AutoSize = true;
            this.lblNumIntEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumIntEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNumIntEmp.Location = new System.Drawing.Point(526, 27);
            this.lblNumIntEmp.Name = "lblNumIntEmp";
            this.lblNumIntEmp.Size = new System.Drawing.Size(53, 15);
            this.lblNumIntEmp.TabIndex = 4;
            this.lblNumIntEmp.Text = "Num Int:";
            // 
            // txtNumIntEmp
            // 
            this.txtNumIntEmp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNumIntEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumIntEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumIntEmp.Location = new System.Drawing.Point(581, 24);
            this.txtNumIntEmp.MaxLength = 10;
            this.txtNumIntEmp.Name = "txtNumIntEmp";
            this.txtNumIntEmp.Size = new System.Drawing.Size(45, 21);
            this.txtNumIntEmp.TabIndex = 5;
            // 
            // txtPaisEmp
            // 
            this.txtPaisEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtPaisEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaisEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPaisEmp.Location = new System.Drawing.Point(283, 132);
            this.txtPaisEmp.Name = "txtPaisEmp";
            this.txtPaisEmp.ReadOnly = true;
            this.txtPaisEmp.Size = new System.Drawing.Size(206, 21);
            this.txtPaisEmp.TabIndex = 22;
            // 
            // lblTipCalleE
            // 
            this.lblTipCalleE.AutoSize = true;
            this.lblTipCalleE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipCalleE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTipCalleE.Location = new System.Drawing.Point(643, 27);
            this.lblTipCalleE.Name = "lblTipCalleE";
            this.lblTipCalleE.Size = new System.Drawing.Size(65, 15);
            this.lblTipCalleE.TabIndex = 6;
            this.lblTipCalleE.Text = "Tipo Calle:";
            // 
            // lblPaisE
            // 
            this.lblPaisE.AutoSize = true;
            this.lblPaisE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPaisE.Location = new System.Drawing.Point(240, 135);
            this.lblPaisE.Name = "lblPaisE";
            this.lblPaisE.Size = new System.Drawing.Size(34, 15);
            this.lblPaisE.TabIndex = 21;
            this.lblPaisE.Text = "País:";
            // 
            // cmbTipCalleE
            // 
            this.cmbTipCalleE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipCalleE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipCalleE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbTipCalleE.FormattingEnabled = true;
            this.cmbTipCalleE.Location = new System.Drawing.Point(715, 24);
            this.cmbTipCalleE.Name = "cmbTipCalleE";
            this.cmbTipCalleE.Size = new System.Drawing.Size(152, 23);
            this.cmbTipCalleE.TabIndex = 7;
            // 
            // txtEstEmp
            // 
            this.txtEstEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtEstEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEstEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEstEmp.Location = new System.Drawing.Point(62, 132);
            this.txtEstEmp.Name = "txtEstEmp";
            this.txtEstEmp.ReadOnly = true;
            this.txtEstEmp.Size = new System.Drawing.Size(152, 21);
            this.txtEstEmp.TabIndex = 20;
            // 
            // lblEntCalleE
            // 
            this.lblEntCalleE.AutoSize = true;
            this.lblEntCalleE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntCalleE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEntCalleE.Location = new System.Drawing.Point(7, 68);
            this.lblEntCalleE.Name = "lblEntCalleE";
            this.lblEntCalleE.Size = new System.Drawing.Size(76, 15);
            this.lblEntCalleE.TabIndex = 8;
            this.lblEntCalleE.Text = "Entre Calles:";
            // 
            // lblEstEmp
            // 
            this.lblEstEmp.AutoSize = true;
            this.lblEstEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEstEmp.Location = new System.Drawing.Point(5, 135);
            this.lblEstEmp.Name = "lblEstEmp";
            this.lblEstEmp.Size = new System.Drawing.Size(48, 15);
            this.lblEstEmp.TabIndex = 19;
            this.lblEstEmp.Text = "Estado:";
            // 
            // lblColEmp
            // 
            this.lblColEmp.AutoSize = true;
            this.lblColEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblColEmp.Location = new System.Drawing.Point(411, 67);
            this.lblColEmp.Name = "lblColEmp";
            this.lblColEmp.Size = new System.Drawing.Size(52, 15);
            this.lblColEmp.TabIndex = 10;
            this.lblColEmp.Text = "Colonia:";
            // 
            // txtPobEmp
            // 
            this.txtPobEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtPobEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPobEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPobEmp.Location = new System.Drawing.Point(620, 101);
            this.txtPobEmp.Name = "txtPobEmp";
            this.txtPobEmp.ReadOnly = true;
            this.txtPobEmp.Size = new System.Drawing.Size(194, 21);
            this.txtPobEmp.TabIndex = 18;
            // 
            // txtColEmp
            // 
            this.txtColEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtColEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtColEmp.Location = new System.Drawing.Point(473, 65);
            this.txtColEmp.Name = "txtColEmp";
            this.txtColEmp.ReadOnly = true;
            this.txtColEmp.Size = new System.Drawing.Size(230, 21);
            this.txtColEmp.TabIndex = 11;
            // 
            // lblPobEmp
            // 
            this.lblPobEmp.AutoSize = true;
            this.lblPobEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPobEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPobEmp.Location = new System.Drawing.Point(547, 104);
            this.lblPobEmp.Name = "lblPobEmp";
            this.lblPobEmp.Size = new System.Drawing.Size(65, 15);
            this.lblPobEmp.TabIndex = 17;
            this.lblPobEmp.Text = "Población:";
            // 
            // btnBusColE
            // 
            this.btnBusColE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBusColE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBusColE.Location = new System.Drawing.Point(729, 63);
            this.btnBusColE.Name = "btnBusColE";
            this.btnBusColE.Size = new System.Drawing.Size(111, 23);
            this.btnBusColE.TabIndex = 12;
            this.btnBusColE.Text = "Buscar Colonia";
            this.btnBusColE.UseVisualStyleBackColor = true;
            this.btnBusColE.Click += new System.EventHandler(this.btnBusColE_Click);
            // 
            // txtDelEmp
            // 
            this.txtDelEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtDelEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDelEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDelEmp.Location = new System.Drawing.Point(320, 101);
            this.txtDelEmp.Name = "txtDelEmp";
            this.txtDelEmp.ReadOnly = true;
            this.txtDelEmp.Size = new System.Drawing.Size(208, 21);
            this.txtDelEmp.TabIndex = 16;
            // 
            // lblCpEmp
            // 
            this.lblCpEmp.AutoSize = true;
            this.lblCpEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCpEmp.Location = new System.Drawing.Point(6, 104);
            this.lblCpEmp.Name = "lblCpEmp";
            this.lblCpEmp.Size = new System.Drawing.Size(86, 15);
            this.lblCpEmp.TabIndex = 13;
            this.lblCpEmp.Text = "Código Postal:";
            // 
            // lblDelEmp
            // 
            this.lblDelEmp.AutoSize = true;
            this.lblDelEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDelEmp.Location = new System.Drawing.Point(239, 104);
            this.lblDelEmp.Name = "lblDelEmp";
            this.lblDelEmp.Size = new System.Drawing.Size(73, 15);
            this.lblDelEmp.TabIndex = 15;
            this.lblDelEmp.Text = "Delegación:";
            // 
            // txtCpEmp
            // 
            this.txtCpEmp.BackColor = System.Drawing.SystemColors.Control;
            this.txtCpEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCpEmp.Location = new System.Drawing.Point(100, 101);
            this.txtCpEmp.Name = "txtCpEmp";
            this.txtCpEmp.ReadOnly = true;
            this.txtCpEmp.Size = new System.Drawing.Size(119, 21);
            this.txtCpEmp.TabIndex = 14;
            // 
            // grbEmpCte
            // 
            this.grbEmpCte.BackColor = System.Drawing.SystemColors.Control;
            this.grbEmpCte.Controls.Add(this.lblTipEMp);
            this.grbEmpCte.Controls.Add(this.cmbTipEmp);
            this.grbEmpCte.Controls.Add(this.txtMesEmp);
            this.grbEmpCte.Controls.Add(this.txtYearEmp);
            this.grbEmpCte.Controls.Add(this.chboxComprob);
            this.grbEmpCte.Controls.Add(this.cmbPerIngreso);
            this.grbEmpCte.Controls.Add(this.lblPerIngreso);
            this.grbEmpCte.Controls.Add(this.txtIngreso);
            this.grbEmpCte.Controls.Add(this.lblIngresos);
            this.grbEmpCte.Controls.Add(this.txtPstoJefe);
            this.grbEmpCte.Controls.Add(this.lblPstoJefInme);
            this.grbEmpCte.Controls.Add(this.txtJefe);
            this.grbEmpCte.Controls.Add(this.lblJefe);
            this.grbEmpCte.Controls.Add(this.lblMesEmp);
            this.grbEmpCte.Controls.Add(this.lblYearEmp);
            this.grbEmpCte.Controls.Add(this.txtDepEmpCte);
            this.grbEmpCte.Controls.Add(this.lblDepEmpCte);
            this.grbEmpCte.Controls.Add(this.lblFunEmpCte);
            this.grbEmpCte.Controls.Add(this.txtFunEmpCte);
            this.grbEmpCte.Controls.Add(this.txtEmpCte);
            this.grbEmpCte.Controls.Add(this.lblEmpCte);
            this.grbEmpCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbEmpCte.Location = new System.Drawing.Point(6, 15);
            this.grbEmpCte.Name = "grbEmpCte";
            this.grbEmpCte.Size = new System.Drawing.Size(875, 212);
            this.grbEmpCte.TabIndex = 0;
            this.grbEmpCte.TabStop = false;
            // 
            // lblTipEMp
            // 
            this.lblTipEMp.AutoSize = true;
            this.lblTipEMp.Location = new System.Drawing.Point(16, 23);
            this.lblTipEMp.Name = "lblTipEMp";
            this.lblTipEMp.Size = new System.Drawing.Size(83, 15);
            this.lblTipEMp.TabIndex = 20;
            this.lblTipEMp.Text = "Tipo Empleo :";
            this.lblTipEMp.Click += new System.EventHandler(this.lblTipEMp_Click);
            // 
            // cmbTipEmp
            // 
            this.cmbTipEmp.FormattingEnabled = true;
            this.cmbTipEmp.Location = new System.Drawing.Point(103, 20);
            this.cmbTipEmp.Name = "cmbTipEmp";
            this.cmbTipEmp.Size = new System.Drawing.Size(171, 23);
            this.cmbTipEmp.TabIndex = 19;
            this.cmbTipEmp.SelectedIndexChanged += new System.EventHandler(this.cmbTipEmp_SelectedIndexChanged);
            // 
            // txtMesEmp
            // 
            this.txtMesEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMesEmp.Location = new System.Drawing.Point(812, 102);
            this.txtMesEmp.MaxLength = 10;
            this.txtMesEmp.Name = "txtMesEmp";
            this.txtMesEmp.Size = new System.Drawing.Size(52, 21);
            this.txtMesEmp.TabIndex = 9;
            this.txtMesEmp.TextChanged += new System.EventHandler(this.txtMesEmp_TextChanged);
            this.txtMesEmp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMesEmp_KeyPress);
            // 
            // txtYearEmp
            // 
            this.txtYearEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYearEmp.Location = new System.Drawing.Point(597, 102);
            this.txtYearEmp.MaxLength = 10;
            this.txtYearEmp.Name = "txtYearEmp";
            this.txtYearEmp.Size = new System.Drawing.Size(53, 21);
            this.txtYearEmp.TabIndex = 7;
            this.txtYearEmp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtYearEmp_KeyPress);
            // 
            // chboxComprob
            // 
            this.chboxComprob.AutoSize = true;
            this.chboxComprob.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chboxComprob.Location = new System.Drawing.Point(475, 174);
            this.chboxComprob.Name = "chboxComprob";
            this.chboxComprob.Size = new System.Drawing.Size(107, 19);
            this.chboxComprob.TabIndex = 18;
            this.chboxComprob.Text = "Comprobables";
            this.chboxComprob.UseVisualStyleBackColor = true;
            // 
            // cmbPerIngreso
            // 
            this.cmbPerIngreso.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbPerIngreso.FormattingEnabled = true;
            this.cmbPerIngreso.Location = new System.Drawing.Point(289, 172);
            this.cmbPerIngreso.Name = "cmbPerIngreso";
            this.cmbPerIngreso.Size = new System.Drawing.Size(121, 23);
            this.cmbPerIngreso.TabIndex = 17;
            // 
            // lblPerIngreso
            // 
            this.lblPerIngreso.AutoSize = true;
            this.lblPerIngreso.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPerIngreso.Location = new System.Drawing.Point(186, 177);
            this.lblPerIngreso.Name = "lblPerIngreso";
            this.lblPerIngreso.Size = new System.Drawing.Size(102, 15);
            this.lblPerIngreso.TabIndex = 16;
            this.lblPerIngreso.Text = "*Periodo Ingreso:";
            // 
            // txtIngreso
            // 
            this.txtIngreso.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtIngreso.Location = new System.Drawing.Point(72, 172);
            this.txtIngreso.MaxLength = 15;
            this.txtIngreso.Name = "txtIngreso";
            this.txtIngreso.Size = new System.Drawing.Size(89, 21);
            this.txtIngreso.TabIndex = 15;
            this.txtIngreso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIngreso_KeyPess);
            this.txtIngreso.LostFocus += new System.EventHandler(this.txtIngreso_LostFocus);
            // 
            // lblIngresos
            // 
            this.lblIngresos.AutoSize = true;
            this.lblIngresos.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblIngresos.Location = new System.Drawing.Point(13, 175);
            this.lblIngresos.Name = "lblIngresos";
            this.lblIngresos.Size = new System.Drawing.Size(62, 15);
            this.lblIngresos.TabIndex = 14;
            this.lblIngresos.Text = "*Ingresos:";
            // 
            // txtPstoJefe
            // 
            this.txtPstoJefe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPstoJefe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPstoJefe.Location = new System.Drawing.Point(603, 140);
            this.txtPstoJefe.MaxLength = 100;
            this.txtPstoJefe.Name = "txtPstoJefe";
            this.txtPstoJefe.Size = new System.Drawing.Size(262, 21);
            this.txtPstoJefe.TabIndex = 13;
            // 
            // lblPstoJefInme
            // 
            this.lblPstoJefInme.AutoSize = true;
            this.lblPstoJefInme.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPstoJefInme.Location = new System.Drawing.Point(469, 143);
            this.lblPstoJefInme.Name = "lblPstoJefInme";
            this.lblPstoJefInme.Size = new System.Drawing.Size(132, 15);
            this.lblPstoJefInme.TabIndex = 12;
            this.lblPstoJefInme.Text = "Puesto Jefe Inmediato:";
            this.lblPstoJefInme.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtJefe
            // 
            this.txtJefe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtJefe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtJefe.Location = new System.Drawing.Point(103, 140);
            this.txtJefe.MaxLength = 100;
            this.txtJefe.Name = "txtJefe";
            this.txtJefe.Size = new System.Drawing.Size(355, 21);
            this.txtJefe.TabIndex = 11;
            // 
            // lblJefe
            // 
            this.lblJefe.AutoSize = true;
            this.lblJefe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblJefe.Location = new System.Drawing.Point(9, 142);
            this.lblJefe.Name = "lblJefe";
            this.lblJefe.Size = new System.Drawing.Size(91, 15);
            this.lblJefe.TabIndex = 10;
            this.lblJefe.Text = "Jefe Inmediato:";
            // 
            // lblMesEmp
            // 
            this.lblMesEmp.AutoSize = true;
            this.lblMesEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMesEmp.Location = new System.Drawing.Point(692, 103);
            this.lblMesEmp.Name = "lblMesEmp";
            this.lblMesEmp.Size = new System.Drawing.Size(117, 15);
            this.lblMesEmp.TabIndex = 8;
            this.lblMesEmp.Text = "*Meses Antigüedad:";
            // 
            // lblYearEmp
            // 
            this.lblYearEmp.AutoSize = true;
            this.lblYearEmp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblYearEmp.Location = new System.Drawing.Point(488, 105);
            this.lblYearEmp.Name = "lblYearEmp";
            this.lblYearEmp.Size = new System.Drawing.Size(102, 15);
            this.lblYearEmp.TabIndex = 6;
            this.lblYearEmp.Text = "Años Antigüedad:";
            // 
            // txtDepEmpCte
            // 
            this.txtDepEmpCte.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDepEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDepEmpCte.Location = new System.Drawing.Point(103, 102);
            this.txtDepEmpCte.MaxLength = 100;
            this.txtDepEmpCte.Name = "txtDepEmpCte";
            this.txtDepEmpCte.Size = new System.Drawing.Size(324, 21);
            this.txtDepEmpCte.TabIndex = 5;
            // 
            // lblDepEmpCte
            // 
            this.lblDepEmpCte.AutoSize = true;
            this.lblDepEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDepEmpCte.Location = new System.Drawing.Point(12, 105);
            this.lblDepEmpCte.Name = "lblDepEmpCte";
            this.lblDepEmpCte.Size = new System.Drawing.Size(89, 15);
            this.lblDepEmpCte.TabIndex = 4;
            this.lblDepEmpCte.Text = "Departamento:";
            // 
            // lblFunEmpCte
            // 
            this.lblFunEmpCte.AutoSize = true;
            this.lblFunEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblFunEmpCte.Location = new System.Drawing.Point(455, 22);
            this.lblFunEmpCte.Name = "lblFunEmpCte";
            this.lblFunEmpCte.Size = new System.Drawing.Size(67, 15);
            this.lblFunEmpCte.TabIndex = 2;
            this.lblFunEmpCte.Text = "Funciones:";
            // 
            // txtFunEmpCte
            // 
            this.txtFunEmpCte.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFunEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtFunEmpCte.Location = new System.Drawing.Point(524, 17);
            this.txtFunEmpCte.MaxLength = 200;
            this.txtFunEmpCte.Multiline = true;
            this.txtFunEmpCte.Name = "txtFunEmpCte";
            this.txtFunEmpCte.Size = new System.Drawing.Size(344, 69);
            this.txtFunEmpCte.TabIndex = 3;
            // 
            // txtEmpCte
            // 
            this.txtEmpCte.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmpCte.Location = new System.Drawing.Point(84, 55);
            this.txtEmpCte.MaxLength = 100;
            this.txtEmpCte.Name = "txtEmpCte";
            this.txtEmpCte.Size = new System.Drawing.Size(347, 21);
            this.txtEmpCte.TabIndex = 1;
            // 
            // lblEmpCte
            // 
            this.lblEmpCte.AutoSize = true;
            this.lblEmpCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmpCte.Location = new System.Drawing.Point(16, 58);
            this.lblEmpCte.Name = "lblEmpCte";
            this.lblEmpCte.Size = new System.Drawing.Size(65, 15);
            this.lblEmpCte.TabIndex = 0;
            this.lblEmpCte.Text = "*Empresa:";
            // 
            // grbRef
            // 
            this.grbRef.AutoSize = true;
            this.grbRef.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbRef.BackColor = System.Drawing.Color.LightBlue;
            this.grbRef.Controls.Add(this.grbBusCte);
            this.grbRef.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbRef.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbRef.Location = new System.Drawing.Point(184, 161);
            this.grbRef.Name = "grbRef";
            this.grbRef.Size = new System.Drawing.Size(887, 158);
            this.grbRef.TabIndex = 0;
            this.grbRef.TabStop = false;
            this.grbRef.Text = "Relacionado Por:";
            // 
            // grbBusCte
            // 
            this.grbBusCte.BackColor = System.Drawing.SystemColors.Control;
            this.grbBusCte.Controls.Add(this.txtTipdesc);
            this.grbBusCte.Controls.Add(this.lblTipDesc);
            this.grbBusCte.Controls.Add(this.lblTipoCte);
            this.grbBusCte.Controls.Add(this.cmbTipoCred);
            this.grbBusCte.Controls.Add(this.chbPresent);
            this.grbBusCte.Controls.Add(this.cmbParent);
            this.grbBusCte.Controls.Add(this.lblParen);
            this.grbBusCte.Controls.Add(this.txtDirRe);
            this.grbBusCte.Controls.Add(this.lblDirRe);
            this.grbBusCte.Controls.Add(this.txtNomR);
            this.grbBusCte.Controls.Add(this.lblNomR);
            this.grbBusCte.Controls.Add(this.btnBuscCte);
            this.grbBusCte.Controls.Add(this.txtRecPor);
            this.grbBusCte.Controls.Add(this.lblBuscte);
            this.grbBusCte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.grbBusCte.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grbBusCte.Location = new System.Drawing.Point(6, 17);
            this.grbBusCte.Name = "grbBusCte";
            this.grbBusCte.Size = new System.Drawing.Size(875, 120);
            this.grbBusCte.TabIndex = 0;
            this.grbBusCte.TabStop = false;
            // 
            // txtTipdesc
            // 
            this.txtTipdesc.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTipdesc.Location = new System.Drawing.Point(122, 93);
            this.txtTipdesc.MaxLength = 250;
            this.txtTipdesc.Multiline = true;
            this.txtTipdesc.Name = "txtTipdesc";
            this.txtTipdesc.ReadOnly = true;
            this.txtTipdesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTipdesc.Size = new System.Drawing.Size(739, 21);
            this.txtTipdesc.TabIndex = 15;
            // 
            // lblTipDesc
            // 
            this.lblTipDesc.AutoSize = true;
            this.lblTipDesc.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTipDesc.Location = new System.Drawing.Point(6, 96);
            this.lblTipDesc.Name = "lblTipDesc";
            this.lblTipDesc.Size = new System.Drawing.Size(117, 15);
            this.lblTipDesc.TabIndex = 14;
            this.lblTipDesc.Text = "Mensaje al Usuario:";
            // 
            // lblTipoCte
            // 
            this.lblTipoCte.AutoSize = true;
            this.lblTipoCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTipoCte.Location = new System.Drawing.Point(585, 68);
            this.lblTipoCte.Name = "lblTipoCte";
            this.lblTipoCte.Size = new System.Drawing.Size(91, 15);
            this.lblTipoCte.TabIndex = 13;
            this.lblTipoCte.Text = "Tipo de credito:";
            // 
            // cmbTipoCred
            // 
            this.cmbTipoCred.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoCred.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbTipoCred.FormattingEnabled = true;
            this.cmbTipoCred.Location = new System.Drawing.Point(678, 65);
            this.cmbTipoCred.Name = "cmbTipoCred";
            this.cmbTipoCred.Size = new System.Drawing.Size(183, 23);
            this.cmbTipoCred.TabIndex = 12;
            this.cmbTipoCred.SelectedIndexChanged += new System.EventHandler(this.cmbTipoCred_SelectedIndexChanged);
            this.cmbTipoCred.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTipoCred_KeyPress);
            // 
            // chbPresent
            // 
            this.chbPresent.AutoSize = true;
            this.chbPresent.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chbPresent.Location = new System.Drawing.Point(9, 69);
            this.chbPresent.Name = "chbPresent";
            this.chbPresent.Size = new System.Drawing.Size(445, 19);
            this.chbPresent.TabIndex = 9;
            this.chbPresent.Text = "Si Relacionante es Huésped o no quiere fungir como Aval, Dar click en check";
            this.chbPresent.UseVisualStyleBackColor = true;
            this.chbPresent.CheckedChanged += new System.EventHandler(this.chbPresent_CheckedChanged);
            // 
            // cmbParent
            // 
            this.cmbParent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParent.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbParent.FormattingEnabled = true;
            this.cmbParent.Location = new System.Drawing.Point(81, 39);
            this.cmbParent.Name = "cmbParent";
            this.cmbParent.Size = new System.Drawing.Size(183, 23);
            this.cmbParent.TabIndex = 6;
            this.cmbParent.SelectedIndexChanged += new System.EventHandler(this.cmbParent_SelectedIndexChanged);
            // 
            // lblParen
            // 
            this.lblParen.AutoSize = true;
            this.lblParen.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblParen.Location = new System.Drawing.Point(4, 42);
            this.lblParen.Name = "lblParen";
            this.lblParen.Size = new System.Drawing.Size(72, 15);
            this.lblParen.TabIndex = 5;
            this.lblParen.Text = "Parentesco:";
            // 
            // txtDirRe
            // 
            this.txtDirRe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDirRe.Location = new System.Drawing.Point(485, 39);
            this.txtDirRe.MaxLength = 250;
            this.txtDirRe.Name = "txtDirRe";
            this.txtDirRe.Size = new System.Drawing.Size(380, 21);
            this.txtDirRe.TabIndex = 8;
            // 
            // lblDirRe
            // 
            this.lblDirRe.AutoSize = true;
            this.lblDirRe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDirRe.Location = new System.Drawing.Point(307, 42);
            this.lblDirRe.Name = "lblDirRe";
            this.lblDirRe.Size = new System.Drawing.Size(175, 15);
            this.lblDirRe.TabIndex = 7;
            this.lblDirRe.Text = "Direccion del que recomienda:";
            // 
            // txtNomR
            // 
            this.txtNomR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNomR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNomR.Location = new System.Drawing.Point(550, 13);
            this.txtNomR.Name = "txtNomR";
            this.txtNomR.ReadOnly = true;
            this.txtNomR.Size = new System.Drawing.Size(315, 21);
            this.txtNomR.TabIndex = 4;
            // 
            // lblNomR
            // 
            this.lblNomR.AutoSize = true;
            this.lblNomR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNomR.Location = new System.Drawing.Point(490, 16);
            this.lblNomR.Name = "lblNomR";
            this.lblNomR.Size = new System.Drawing.Size(55, 15);
            this.lblNomR.TabIndex = 3;
            this.lblNomR.Text = "Nombre:";
            // 
            // btnBuscCte
            // 
            this.btnBuscCte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBuscCte.Location = new System.Drawing.Point(376, 13);
            this.btnBuscCte.Name = "btnBuscCte";
            this.btnBuscCte.Size = new System.Drawing.Size(84, 23);
            this.btnBuscCte.TabIndex = 2;
            this.btnBuscCte.Text = "Buscar Cte";
            this.btnBuscCte.UseVisualStyleBackColor = true;
            this.btnBuscCte.Click += new System.EventHandler(this.btnBuscCte_Click);
            // 
            // txtRecPor
            // 
            this.txtRecPor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRecPor.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRecPor.Location = new System.Drawing.Point(120, 13);
            this.txtRecPor.Name = "txtRecPor";
            this.txtRecPor.ReadOnly = true;
            this.txtRecPor.Size = new System.Drawing.Size(230, 21);
            this.txtRecPor.TabIndex = 1;
            this.txtRecPor.TextChanged += new System.EventHandler(this.txtRecPor_TextChanged);
            // 
            // lblBuscte
            // 
            this.lblBuscte.AutoSize = true;
            this.lblBuscte.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblBuscte.Location = new System.Drawing.Point(4, 13);
            this.lblBuscte.Name = "lblBuscte";
            this.lblBuscte.Size = new System.Drawing.Size(113, 15);
            this.lblBuscte.TabIndex = 0;
            this.lblBuscte.Text = "Recomendado por:";
            // 
            // grbDatComBan
            // 
            this.grbDatComBan.BackColor = System.Drawing.SystemColors.Control;
            this.grbDatComBan.Controls.Add(this.txtTarjBan3);
            this.grbDatComBan.Controls.Add(this.lblTarjBan3);
            this.grbDatComBan.Controls.Add(this.txtEmiBan3);
            this.grbDatComBan.Controls.Add(this.lblEmiBan3);
            this.grbDatComBan.Controls.Add(this.txtTarjBan2);
            this.grbDatComBan.Controls.Add(this.lblTarjBan2);
            this.grbDatComBan.Controls.Add(this.txtTarjBan1);
            this.grbDatComBan.Controls.Add(this.lblTarjBan1);
            this.grbDatComBan.Controls.Add(this.textBox7);
            this.grbDatComBan.Controls.Add(this.lblTarjCom2);
            this.grbDatComBan.Controls.Add(this.txtTarjCom1);
            this.grbDatComBan.Controls.Add(this.lblTarjCom1);
            this.grbDatComBan.Controls.Add(this.txtEmiBan2);
            this.grbDatComBan.Controls.Add(this.lblEmiBan2);
            this.grbDatComBan.Controls.Add(this.txtEmiBan1);
            this.grbDatComBan.Controls.Add(this.lblEmiBan1);
            this.grbDatComBan.Controls.Add(this.txtEmiCom2);
            this.grbDatComBan.Controls.Add(this.lblEmiCom2);
            this.grbDatComBan.Controls.Add(this.txtEmiCom1);
            this.grbDatComBan.Controls.Add(this.lblEmiCom1);
            this.grbDatComBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDatComBan.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbDatComBan.Location = new System.Drawing.Point(6, 17);
            this.grbDatComBan.Name = "grbDatComBan";
            this.grbDatComBan.Size = new System.Drawing.Size(874, 152);
            this.grbDatComBan.TabIndex = 0;
            this.grbDatComBan.TabStop = false;
            // 
            // txtTarjBan3
            // 
            this.txtTarjBan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTarjBan3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTarjBan3.Location = new System.Drawing.Point(705, 100);
            this.txtTarjBan3.MaxLength = 50;
            this.txtTarjBan3.Name = "txtTarjBan3";
            this.txtTarjBan3.Size = new System.Drawing.Size(158, 21);
            this.txtTarjBan3.TabIndex = 19;
            // 
            // lblTarjBan3
            // 
            this.lblTarjBan3.AutoSize = true;
            this.lblTarjBan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjBan3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTarjBan3.Location = new System.Drawing.Point(712, 82);
            this.lblTarjBan3.Name = "lblTarjBan3";
            this.lblTarjBan3.Size = new System.Drawing.Size(121, 15);
            this.lblTarjBan3.TabIndex = 18;
            this.lblTarjBan3.Text = "N.Tarjeta bancaria 3:";
            // 
            // txtEmiBan3
            // 
            this.txtEmiBan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmiBan3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmiBan3.Location = new System.Drawing.Point(705, 54);
            this.txtEmiBan3.MaxLength = 50;
            this.txtEmiBan3.Name = "txtEmiBan3";
            this.txtEmiBan3.Size = new System.Drawing.Size(158, 21);
            this.txtEmiBan3.TabIndex = 17;
            // 
            // lblEmiBan3
            // 
            this.lblEmiBan3.AutoSize = true;
            this.lblEmiBan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmiBan3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmiBan3.Location = new System.Drawing.Point(712, 36);
            this.lblEmiBan3.Name = "lblEmiBan3";
            this.lblEmiBan3.Size = new System.Drawing.Size(110, 15);
            this.lblEmiBan3.TabIndex = 16;
            this.lblEmiBan3.Text = "Emisor bancario 3:";
            // 
            // txtTarjBan2
            // 
            this.txtTarjBan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTarjBan2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTarjBan2.Location = new System.Drawing.Point(532, 100);
            this.txtTarjBan2.MaxLength = 50;
            this.txtTarjBan2.Name = "txtTarjBan2";
            this.txtTarjBan2.Size = new System.Drawing.Size(158, 21);
            this.txtTarjBan2.TabIndex = 15;
            // 
            // lblTarjBan2
            // 
            this.lblTarjBan2.AutoSize = true;
            this.lblTarjBan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjBan2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTarjBan2.Location = new System.Drawing.Point(539, 82);
            this.lblTarjBan2.Name = "lblTarjBan2";
            this.lblTarjBan2.Size = new System.Drawing.Size(121, 15);
            this.lblTarjBan2.TabIndex = 14;
            this.lblTarjBan2.Text = "N.Tarjeta bancaria 2:";
            // 
            // txtTarjBan1
            // 
            this.txtTarjBan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTarjBan1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTarjBan1.Location = new System.Drawing.Point(355, 100);
            this.txtTarjBan1.MaxLength = 50;
            this.txtTarjBan1.Name = "txtTarjBan1";
            this.txtTarjBan1.Size = new System.Drawing.Size(158, 21);
            this.txtTarjBan1.TabIndex = 11;
            // 
            // lblTarjBan1
            // 
            this.lblTarjBan1.AutoSize = true;
            this.lblTarjBan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjBan1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTarjBan1.Location = new System.Drawing.Point(360, 82);
            this.lblTarjBan1.Name = "lblTarjBan1";
            this.lblTarjBan1.Size = new System.Drawing.Size(121, 15);
            this.lblTarjBan1.TabIndex = 10;
            this.lblTarjBan1.Text = "N.Tarjeta bancaria 1:";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox7.Location = new System.Drawing.Point(181, 100);
            this.textBox7.MaxLength = 50;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(158, 21);
            this.textBox7.TabIndex = 7;
            // 
            // lblTarjCom2
            // 
            this.lblTarjCom2.AutoSize = true;
            this.lblTarjCom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjCom2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTarjCom2.Location = new System.Drawing.Point(186, 82);
            this.lblTarjCom2.Name = "lblTarjCom2";
            this.lblTarjCom2.Size = new System.Drawing.Size(127, 15);
            this.lblTarjCom2.TabIndex = 6;
            this.lblTarjCom2.Text = "N.Tarjeta comercial 2:";
            // 
            // txtTarjCom1
            // 
            this.txtTarjCom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTarjCom1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTarjCom1.Location = new System.Drawing.Point(9, 100);
            this.txtTarjCom1.MaxLength = 50;
            this.txtTarjCom1.Name = "txtTarjCom1";
            this.txtTarjCom1.Size = new System.Drawing.Size(158, 21);
            this.txtTarjCom1.TabIndex = 3;
            // 
            // lblTarjCom1
            // 
            this.lblTarjCom1.AutoSize = true;
            this.lblTarjCom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjCom1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTarjCom1.Location = new System.Drawing.Point(10, 82);
            this.lblTarjCom1.Name = "lblTarjCom1";
            this.lblTarjCom1.Size = new System.Drawing.Size(127, 15);
            this.lblTarjCom1.TabIndex = 2;
            this.lblTarjCom1.Text = "N.Tarjeta comercial 1:";
            // 
            // txtEmiBan2
            // 
            this.txtEmiBan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmiBan2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmiBan2.Location = new System.Drawing.Point(532, 54);
            this.txtEmiBan2.MaxLength = 50;
            this.txtEmiBan2.Name = "txtEmiBan2";
            this.txtEmiBan2.Size = new System.Drawing.Size(158, 21);
            this.txtEmiBan2.TabIndex = 13;
            // 
            // lblEmiBan2
            // 
            this.lblEmiBan2.AutoSize = true;
            this.lblEmiBan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmiBan2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmiBan2.Location = new System.Drawing.Point(539, 36);
            this.lblEmiBan2.Name = "lblEmiBan2";
            this.lblEmiBan2.Size = new System.Drawing.Size(110, 15);
            this.lblEmiBan2.TabIndex = 12;
            this.lblEmiBan2.Text = "Emisor bancario 2:";
            // 
            // txtEmiBan1
            // 
            this.txtEmiBan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmiBan1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmiBan1.Location = new System.Drawing.Point(355, 54);
            this.txtEmiBan1.MaxLength = 50;
            this.txtEmiBan1.Name = "txtEmiBan1";
            this.txtEmiBan1.Size = new System.Drawing.Size(158, 21);
            this.txtEmiBan1.TabIndex = 9;
            // 
            // lblEmiBan1
            // 
            this.lblEmiBan1.AutoSize = true;
            this.lblEmiBan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmiBan1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmiBan1.Location = new System.Drawing.Point(360, 36);
            this.lblEmiBan1.Name = "lblEmiBan1";
            this.lblEmiBan1.Size = new System.Drawing.Size(110, 15);
            this.lblEmiBan1.TabIndex = 8;
            this.lblEmiBan1.Text = "Emisor bancario 1:";
            // 
            // txtEmiCom2
            // 
            this.txtEmiCom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmiCom2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmiCom2.Location = new System.Drawing.Point(181, 54);
            this.txtEmiCom2.MaxLength = 50;
            this.txtEmiCom2.Name = "txtEmiCom2";
            this.txtEmiCom2.Size = new System.Drawing.Size(158, 21);
            this.txtEmiCom2.TabIndex = 5;
            // 
            // lblEmiCom2
            // 
            this.lblEmiCom2.AutoSize = true;
            this.lblEmiCom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmiCom2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmiCom2.Location = new System.Drawing.Point(186, 36);
            this.lblEmiCom2.Name = "lblEmiCom2";
            this.lblEmiCom2.Size = new System.Drawing.Size(118, 15);
            this.lblEmiCom2.TabIndex = 4;
            this.lblEmiCom2.Text = "Emisor Comercial 2:";
            // 
            // txtEmiCom1
            // 
            this.txtEmiCom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmiCom1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEmiCom1.Location = new System.Drawing.Point(9, 54);
            this.txtEmiCom1.MaxLength = 50;
            this.txtEmiCom1.Name = "txtEmiCom1";
            this.txtEmiCom1.Size = new System.Drawing.Size(158, 21);
            this.txtEmiCom1.TabIndex = 1;
            // 
            // lblEmiCom1
            // 
            this.lblEmiCom1.AutoSize = true;
            this.lblEmiCom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmiCom1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmiCom1.Location = new System.Drawing.Point(10, 36);
            this.lblEmiCom1.Name = "lblEmiCom1";
            this.lblEmiCom1.Size = new System.Drawing.Size(118, 15);
            this.lblEmiCom1.TabIndex = 0;
            this.lblEmiCom1.Text = "Emisor Comercial 1:";
            // 
            // grbDatNominales
            // 
            this.grbDatNominales.BackColor = System.Drawing.Color.LightBlue;
            this.grbDatNominales.Controls.Add(this.grbNomi);
            this.grbDatNominales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDatNominales.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbDatNominales.Location = new System.Drawing.Point(186, 1982);
            this.grbDatNominales.Name = "grbDatNominales";
            this.grbDatNominales.Size = new System.Drawing.Size(887, 161);
            this.grbDatNominales.TabIndex = 4;
            this.grbDatNominales.TabStop = false;
            this.grbDatNominales.Text = "Datos Nominales";
            // 
            // grbNomi
            // 
            this.grbNomi.BackColor = System.Drawing.SystemColors.Control;
            this.grbNomi.Controls.Add(this.txtMpioN);
            this.grbNomi.Controls.Add(this.lblMpioN);
            this.grbNomi.Controls.Add(this.txtCargoN);
            this.grbNomi.Controls.Add(this.lblCargoN);
            this.grbNomi.Controls.Add(this.txtCveInst);
            this.grbNomi.Controls.Add(this.lblCveInst);
            this.grbNomi.Controls.Add(this.txtRfcInst);
            this.grbNomi.Controls.Add(this.lblRfcInst);
            this.grbNomi.Controls.Add(this.lblPuestoN);
            this.grbNomi.Controls.Add(this.txtPuestoN);
            this.grbNomi.Controls.Add(this.txtConfNomina);
            this.grbNomi.Controls.Add(this.lblConfNom);
            this.grbNomi.Controls.Add(this.txtNomina);
            this.grbNomi.Controls.Add(this.lblNomina);
            this.grbNomi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.grbNomi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grbNomi.Location = new System.Drawing.Point(6, 18);
            this.grbNomi.Name = "grbNomi";
            this.grbNomi.Size = new System.Drawing.Size(874, 131);
            this.grbNomi.TabIndex = 0;
            this.grbNomi.TabStop = false;
            // 
            // txtMpioN
            // 
            this.txtMpioN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMpioN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMpioN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtMpioN.Location = new System.Drawing.Point(450, 83);
            this.txtMpioN.MaxLength = 100;
            this.txtMpioN.Name = "txtMpioN";
            this.txtMpioN.Size = new System.Drawing.Size(297, 21);
            this.txtMpioN.TabIndex = 13;
            // 
            // lblMpioN
            // 
            this.lblMpioN.AutoSize = true;
            this.lblMpioN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMpioN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMpioN.Location = new System.Drawing.Point(377, 86);
            this.lblMpioN.Name = "lblMpioN";
            this.lblMpioN.Size = new System.Drawing.Size(67, 15);
            this.lblMpioN.TabIndex = 12;
            this.lblMpioN.Text = "Municipio :";
            // 
            // txtCargoN
            // 
            this.txtCargoN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCargoN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargoN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCargoN.Location = new System.Drawing.Point(56, 83);
            this.txtCargoN.MaxLength = 100;
            this.txtCargoN.Name = "txtCargoN";
            this.txtCargoN.Size = new System.Drawing.Size(294, 21);
            this.txtCargoN.TabIndex = 11;
            // 
            // lblCargoN
            // 
            this.lblCargoN.AutoSize = true;
            this.lblCargoN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargoN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCargoN.Location = new System.Drawing.Point(4, 86);
            this.lblCargoN.Name = "lblCargoN";
            this.lblCargoN.Size = new System.Drawing.Size(46, 15);
            this.lblCargoN.TabIndex = 10;
            this.lblCargoN.Text = "Cargo :";
            // 
            // txtCveInst
            // 
            this.txtCveInst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCveInst.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCveInst.Location = new System.Drawing.Point(510, 48);
            this.txtCveInst.MaxLength = 100;
            this.txtCveInst.Name = "txtCveInst";
            this.txtCveInst.Size = new System.Drawing.Size(355, 21);
            this.txtCveInst.TabIndex = 9;
            // 
            // lblCveInst
            // 
            this.lblCveInst.AutoSize = true;
            this.lblCveInst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCveInst.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCveInst.Location = new System.Drawing.Point(375, 51);
            this.lblCveInst.Name = "lblCveInst";
            this.lblCveInst.Size = new System.Drawing.Size(131, 15);
            this.lblCveInst.TabIndex = 8;
            this.lblCveInst.Text = "Clave de la Institucion :";
            // 
            // txtRfcInst
            // 
            this.txtRfcInst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRfcInst.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRfcInst.Location = new System.Drawing.Point(136, 48);
            this.txtRfcInst.Name = "txtRfcInst";
            this.txtRfcInst.ReadOnly = true;
            this.txtRfcInst.Size = new System.Drawing.Size(225, 21);
            this.txtRfcInst.TabIndex = 7;
            // 
            // lblRfcInst
            // 
            this.lblRfcInst.AutoSize = true;
            this.lblRfcInst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRfcInst.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblRfcInst.Location = new System.Drawing.Point(5, 51);
            this.lblRfcInst.Name = "lblRfcInst";
            this.lblRfcInst.Size = new System.Drawing.Size(125, 15);
            this.lblRfcInst.TabIndex = 6;
            this.lblRfcInst.Text = "RFC de la Institucion :";
            // 
            // lblPuestoN
            // 
            this.lblPuestoN.AutoSize = true;
            this.lblPuestoN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPuestoN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPuestoN.Location = new System.Drawing.Point(531, 17);
            this.lblPuestoN.Name = "lblPuestoN";
            this.lblPuestoN.Size = new System.Drawing.Size(51, 15);
            this.lblPuestoN.TabIndex = 4;
            this.lblPuestoN.Text = "Puesto :";
            // 
            // txtPuestoN
            // 
            this.txtPuestoN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPuestoN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPuestoN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtPuestoN.Location = new System.Drawing.Point(588, 14);
            this.txtPuestoN.MaxLength = 100;
            this.txtPuestoN.Name = "txtPuestoN";
            this.txtPuestoN.Size = new System.Drawing.Size(277, 21);
            this.txtPuestoN.TabIndex = 5;
            // 
            // txtConfNomina
            // 
            this.txtConfNomina.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfNomina.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtConfNomina.Location = new System.Drawing.Point(349, 14);
            this.txtConfNomina.MaxLength = 50;
            this.txtConfNomina.Name = "txtConfNomina";
            this.txtConfNomina.Size = new System.Drawing.Size(169, 21);
            this.txtConfNomina.TabIndex = 3;
            this.txtConfNomina.UseSystemPasswordChar = true;
            // 
            // lblConfNom
            // 
            this.lblConfNom.AutoSize = true;
            this.lblConfNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfNom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblConfNom.Location = new System.Drawing.Point(232, 17);
            this.lblConfNom.Name = "lblConfNom";
            this.lblConfNom.Size = new System.Drawing.Size(111, 15);
            this.lblConfNom.TabIndex = 2;
            this.lblConfNom.Text = "Confirmar Nómina:";
            // 
            // txtNomina
            // 
            this.txtNomina.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomina.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNomina.Location = new System.Drawing.Point(64, 14);
            this.txtNomina.MaxLength = 50;
            this.txtNomina.Name = "txtNomina";
            this.txtNomina.Size = new System.Drawing.Size(158, 21);
            this.txtNomina.TabIndex = 1;
            // 
            // lblNomina
            // 
            this.lblNomina.AutoSize = true;
            this.lblNomina.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomina.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNomina.Location = new System.Drawing.Point(4, 17);
            this.lblNomina.Name = "lblNomina";
            this.lblNomina.Size = new System.Drawing.Size(54, 15);
            this.lblNomina.TabIndex = 0;
            this.lblNomina.Text = "Nómina:";
            // 
            // grbTelefono
            // 
            this.grbTelefono.AutoSize = true;
            this.grbTelefono.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbTelefono.BackColor = System.Drawing.Color.LightBlue;
            this.grbTelefono.Controls.Add(this.grbTiempo);
            this.grbTelefono.Controls.Add(this.grbTel);
            this.grbTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.grbTelefono.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbTelefono.Location = new System.Drawing.Point(188, 2350);
            this.grbTelefono.Name = "grbTelefono";
            this.grbTelefono.Size = new System.Drawing.Size(521, 328);
            this.grbTelefono.TabIndex = 6;
            this.grbTelefono.TabStop = false;
            // 
            // grbTiempo
            // 
            this.grbTiempo.BackColor = System.Drawing.SystemColors.Control;
            this.grbTiempo.Controls.Add(this.txtTiempo);
            this.grbTiempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTiempo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbTiempo.Location = new System.Drawing.Point(6, 228);
            this.grbTiempo.Name = "grbTiempo";
            this.grbTiempo.Size = new System.Drawing.Size(509, 79);
            this.grbTiempo.TabIndex = 1;
            this.grbTiempo.TabStop = false;
            this.grbTiempo.Text = "*Tiempo Sugerido para Visita Domicilaria";
            // 
            // txtTiempo
            // 
            this.txtTiempo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTiempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTiempo.Location = new System.Drawing.Point(12, 35);
            this.txtTiempo.MaxLength = 150;
            this.txtTiempo.Name = "txtTiempo";
            this.txtTiempo.Size = new System.Drawing.Size(486, 21);
            this.txtTiempo.TabIndex = 0;
            // 
            // grbTel
            // 
            this.grbTel.BackColor = System.Drawing.SystemColors.Control;
            this.grbTel.Controls.Add(this.lblOpcion);
            this.grbTel.Controls.Add(this.lblAnuncio);
            this.grbTel.Controls.Add(this.btnAgrTel);
            this.grbTel.Controls.Add(this.dgvTelefono);
            this.grbTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbTel.Location = new System.Drawing.Point(6, 15);
            this.grbTel.Name = "grbTel";
            this.grbTel.Size = new System.Drawing.Size(509, 208);
            this.grbTel.TabIndex = 0;
            this.grbTel.TabStop = false;
            this.grbTel.Text = "Telefonos";
            // 
            // lblOpcion
            // 
            this.lblOpcion.AutoSize = true;
            this.lblOpcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpcion.ForeColor = System.Drawing.Color.Maroon;
            this.lblOpcion.Location = new System.Drawing.Point(120, 45);
            this.lblOpcion.Name = "lblOpcion";
            this.lblOpcion.Size = new System.Drawing.Size(368, 15);
            this.lblOpcion.TabIndex = 3;
            this.lblOpcion.Text = "*Si no cuenta con numero telefonico, puede capturar 10 veces el 0";
            // 
            // lblAnuncio
            // 
            this.lblAnuncio.AutoSize = true;
            this.lblAnuncio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnuncio.ForeColor = System.Drawing.Color.Maroon;
            this.lblAnuncio.Location = new System.Drawing.Point(120, 22);
            this.lblAnuncio.Name = "lblAnuncio";
            this.lblAnuncio.Size = new System.Drawing.Size(389, 15);
            this.lblAnuncio.TabIndex = 2;
            this.lblAnuncio.Text = "*Captura Obligatoria de 2 telefonos,(Al menos un Movil y un Particular)";
            // 
            // btnAgrTel
            // 
            this.btnAgrTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgrTel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnAgrTel.Location = new System.Drawing.Point(14, 13);
            this.btnAgrTel.Name = "btnAgrTel";
            this.btnAgrTel.Size = new System.Drawing.Size(101, 46);
            this.btnAgrTel.TabIndex = 0;
            this.btnAgrTel.Text = "Agregar Telefono";
            this.btnAgrTel.UseVisualStyleBackColor = true;
            this.btnAgrTel.Click += new System.EventHandler(this.btnAgrTel_Click);
            // 
            // dgvTelefono
            // 
            this.dgvTelefono.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTelefono.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTelefono.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTelefono.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Borrar,
            this.TipoTel,
            this.LadaTel,
            this.TelefonoTel});
            this.dgvTelefono.Location = new System.Drawing.Point(6, 65);
            this.dgvTelefono.Name = "dgvTelefono";
            this.dgvTelefono.Size = new System.Drawing.Size(457, 127);
            this.dgvTelefono.TabIndex = 1;
            this.dgvTelefono.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTelefono_CellClick);
            this.dgvTelefono.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTelefono_CellEndEdit);
            this.dgvTelefono.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgvTelefono_CellValidating);
            this.dgvTelefono.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvTelefono_EditingControlShowing);
            this.dgvTelefono.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvTelefono_KeyDown);
            // 
            // Borrar
            // 
            this.Borrar.HeaderText = "";
            this.Borrar.Name = "Borrar";
            this.Borrar.Text = "Borrar";
            this.Borrar.UseColumnTextForButtonValue = true;
            // 
            // TipoTel
            // 
            this.TipoTel.HeaderText = "Tipo";
            this.TipoTel.Name = "TipoTel";
            // 
            // LadaTel
            // 
            dataGridViewCellStyle2.NullValue = null;
            this.LadaTel.DefaultCellStyle = dataGridViewCellStyle2;
            this.LadaTel.HeaderText = "Lada";
            this.LadaTel.MaxInputLength = 3;
            this.LadaTel.Name = "LadaTel";
            // 
            // TelefonoTel
            // 
            this.TelefonoTel.HeaderText = "Telefono";
            this.TelefonoTel.MaxInputLength = 8;
            this.TelefonoTel.Name = "TelefonoTel";
            // 
            // grbContactos
            // 
            this.grbContactos.BackColor = System.Drawing.Color.LightBlue;
            this.grbContactos.Controls.Add(this.grbCont);
            this.grbContactos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbContactos.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbContactos.Location = new System.Drawing.Point(186, 1611);
            this.grbContactos.Name = "grbContactos";
            this.grbContactos.Size = new System.Drawing.Size(887, 356);
            this.grbContactos.TabIndex = 3;
            this.grbContactos.TabStop = false;
            this.grbContactos.Text = "Contactos";
            // 
            // grbCont
            // 
            this.grbCont.BackColor = System.Drawing.SystemColors.Control;
            this.grbCont.Controls.Add(this.dgvCto);
            this.grbCont.Controls.Add(this.btnAgregarCto);
            this.grbCont.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.grbCont.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grbCont.Location = new System.Drawing.Point(6, 16);
            this.grbCont.Name = "grbCont";
            this.grbCont.Size = new System.Drawing.Size(874, 328);
            this.grbCont.TabIndex = 0;
            this.grbCont.TabStop = false;
            // 
            // dgvCto
            // 
            this.dgvCto.AllowUserToAddRows = false;
            this.dgvCto.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCto.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvCto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCto.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Tipo,
            this.Parentesco,
            this.ApePat,
            this.ApeMat,
            this.Nombre,
            this.CnlVent,
            this.Lada,
            this.Telefono,
            this.FechaN,
            this.Sexo,
            this.EdoC,
            this.ViveEnCal,
            this.ViveCon,
            this.CalidadCon,
            this.idCto,
            this.EsCasa,
            this.NoCuenta,
            this.rfcCto,
            this.Editar,
            this.Eliminar});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCto.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvCto.Location = new System.Drawing.Point(9, 84);
            this.dgvCto.Name = "dgvCto";
            this.dgvCto.ReadOnly = true;
            this.dgvCto.Size = new System.Drawing.Size(843, 193);
            this.dgvCto.TabIndex = 1;
            this.dgvCto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCto_CellContentClick);
            // 
            // Tipo
            // 
            this.Tipo.HeaderText = "Tipo";
            this.Tipo.Name = "Tipo";
            this.Tipo.ReadOnly = true;
            // 
            // Parentesco
            // 
            this.Parentesco.HeaderText = "Parentesco";
            this.Parentesco.Name = "Parentesco";
            this.Parentesco.ReadOnly = true;
            // 
            // ApePat
            // 
            this.ApePat.HeaderText = "Apellido Paterno";
            this.ApePat.Name = "ApePat";
            this.ApePat.ReadOnly = true;
            // 
            // ApeMat
            // 
            this.ApeMat.HeaderText = "Apellido Materno";
            this.ApeMat.Name = "ApeMat";
            this.ApeMat.ReadOnly = true;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // CnlVent
            // 
            this.CnlVent.HeaderText = "Canal Venta";
            this.CnlVent.Name = "CnlVent";
            this.CnlVent.ReadOnly = true;
            // 
            // Lada
            // 
            this.Lada.HeaderText = "Lada";
            this.Lada.Name = "Lada";
            this.Lada.ReadOnly = true;
            this.Lada.Visible = false;
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            this.Telefono.ReadOnly = true;
            this.Telefono.Visible = false;
            // 
            // FechaN
            // 
            this.FechaN.HeaderText = "Fecha Nacimiento";
            this.FechaN.Name = "FechaN";
            this.FechaN.ReadOnly = true;
            this.FechaN.Visible = false;
            // 
            // Sexo
            // 
            this.Sexo.HeaderText = "Sexo";
            this.Sexo.Name = "Sexo";
            this.Sexo.ReadOnly = true;
            this.Sexo.Visible = false;
            // 
            // EdoC
            // 
            this.EdoC.HeaderText = "Estado Civil";
            this.EdoC.Name = "EdoC";
            this.EdoC.ReadOnly = true;
            this.EdoC.Visible = false;
            // 
            // ViveEnCal
            // 
            this.ViveEnCal.HeaderText = "Vive en calidad de ";
            this.ViveEnCal.Name = "ViveEnCal";
            this.ViveEnCal.ReadOnly = true;
            this.ViveEnCal.Visible = false;
            // 
            // ViveCon
            // 
            this.ViveCon.HeaderText = "Vive Con";
            this.ViveCon.Name = "ViveCon";
            this.ViveCon.ReadOnly = true;
            this.ViveCon.Visible = false;
            // 
            // CalidadCon
            // 
            this.CalidadCon.HeaderText = "Que Vive en Calidad";
            this.CalidadCon.Name = "CalidadCon";
            this.CalidadCon.ReadOnly = true;
            this.CalidadCon.Visible = false;
            // 
            // idCto
            // 
            this.idCto.HeaderText = "ID";
            this.idCto.Name = "idCto";
            this.idCto.ReadOnly = true;
            this.idCto.Visible = false;
            // 
            // EsCasa
            // 
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.NullValue = null;
            this.EsCasa.DefaultCellStyle = dataGridViewCellStyle4;
            this.EsCasa.HeaderText = "EsCasa";
            this.EsCasa.Name = "EsCasa";
            this.EsCasa.ReadOnly = true;
            this.EsCasa.Visible = false;
            // 
            // NoCuenta
            // 
            this.NoCuenta.HeaderText = "NoCuenta";
            this.NoCuenta.Name = "NoCuenta";
            this.NoCuenta.ReadOnly = true;
            this.NoCuenta.Visible = false;
            // 
            // rfcCto
            // 
            this.rfcCto.HeaderText = "rcfCto";
            this.rfcCto.Name = "rfcCto";
            this.rfcCto.ReadOnly = true;
            this.rfcCto.Visible = false;
            // 
            // Editar
            // 
            this.Editar.HeaderText = "";
            this.Editar.Name = "Editar";
            this.Editar.ReadOnly = true;
            this.Editar.Text = "Editar Cto";
            this.Editar.UseColumnTextForButtonValue = true;
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "";
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.ReadOnly = true;
            this.Eliminar.Text = "Eliminar";
            this.Eliminar.UseColumnTextForButtonValue = true;
            // 
            // btnAgregarCto
            // 
            this.btnAgregarCto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarCto.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnAgregarCto.Location = new System.Drawing.Point(29, 32);
            this.btnAgregarCto.Name = "btnAgregarCto";
            this.btnAgregarCto.Size = new System.Drawing.Size(101, 46);
            this.btnAgregarCto.TabIndex = 0;
            this.btnAgregarCto.Text = "Agregar Contacto";
            this.btnAgregarCto.UseVisualStyleBackColor = true;
            this.btnAgregarCto.Click += new System.EventHandler(this.btnAgregarCto_Click);
            // 
            // grbRefComBan
            // 
            this.grbRefComBan.BackColor = System.Drawing.Color.LightBlue;
            this.grbRefComBan.Controls.Add(this.grbDatComBan);
            this.grbRefComBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.grbRefComBan.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbRefComBan.Location = new System.Drawing.Point(187, 2158);
            this.grbRefComBan.Name = "grbRefComBan";
            this.grbRefComBan.Size = new System.Drawing.Size(887, 177);
            this.grbRefComBan.TabIndex = 5;
            this.grbRefComBan.TabStop = false;
            this.grbRefComBan.Text = "Referencias Comerciales y Bancarios";
            this.grbRefComBan.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // grbDimR2
            // 
            this.grbDimR2.BackColor = System.Drawing.SystemColors.Control;
            this.grbDimR2.Controls.Add(this.btnBorrarDimR);
            this.grbDimR2.Controls.Add(this.txtDirecDimR);
            this.grbDimR2.Controls.Add(this.lblDirecDimr);
            this.grbDimR2.Controls.Add(this.txtNomDimR);
            this.grbDimR2.Controls.Add(this.lblNomDimR);
            this.grbDimR2.Controls.Add(this.btnBuscarDimR);
            this.grbDimR2.Controls.Add(this.txtCuentaDimr);
            this.grbDimR2.Controls.Add(this.lblCuentaDimr);
            this.grbDimR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.grbDimR2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grbDimR2.Location = new System.Drawing.Point(6, 17);
            this.grbDimR2.Name = "grbDimR2";
            this.grbDimR2.Size = new System.Drawing.Size(875, 113);
            this.grbDimR2.TabIndex = 0;
            this.grbDimR2.TabStop = false;
            // 
            // lblCuentaDimr
            // 
            this.lblCuentaDimr.AutoSize = true;
            this.lblCuentaDimr.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCuentaDimr.Location = new System.Drawing.Point(4, 24);
            this.lblCuentaDimr.Name = "lblCuentaDimr";
            this.lblCuentaDimr.Size = new System.Drawing.Size(49, 15);
            this.lblCuentaDimr.TabIndex = 0;
            this.lblCuentaDimr.Text = "Cuenta:";
            // 
            // txtCuentaDimr
            // 
            this.txtCuentaDimr.BackColor = System.Drawing.SystemColors.Window;
            this.txtCuentaDimr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCuentaDimr.Enabled = false;
            this.txtCuentaDimr.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCuentaDimr.Location = new System.Drawing.Point(73, 24);
            this.txtCuentaDimr.Name = "txtCuentaDimr";
            this.txtCuentaDimr.ReadOnly = true;
            this.txtCuentaDimr.Size = new System.Drawing.Size(230, 21);
            this.txtCuentaDimr.TabIndex = 1;
            // 
            // btnBuscarDimR
            // 
            this.btnBuscarDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBuscarDimR.Location = new System.Drawing.Point(322, 22);
            this.btnBuscarDimR.Name = "btnBuscarDimR";
            this.btnBuscarDimR.Size = new System.Drawing.Size(84, 23);
            this.btnBuscarDimR.TabIndex = 2;
            this.btnBuscarDimR.Text = "Buscar Cte";
            this.btnBuscarDimR.UseVisualStyleBackColor = true;
            this.btnBuscarDimR.Click += new System.EventHandler(this.btnBuscarDimR_Click);
            // 
            // lblNomDimR
            // 
            this.lblNomDimR.AutoSize = true;
            this.lblNomDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNomDimR.Location = new System.Drawing.Point(6, 54);
            this.lblNomDimR.Name = "lblNomDimR";
            this.lblNomDimR.Size = new System.Drawing.Size(55, 15);
            this.lblNomDimR.TabIndex = 3;
            this.lblNomDimR.Text = "Nombre:";
            // 
            // txtNomDimR
            // 
            this.txtNomDimR.BackColor = System.Drawing.SystemColors.Window;
            this.txtNomDimR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNomDimR.Enabled = false;
            this.txtNomDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNomDimR.Location = new System.Drawing.Point(73, 51);
            this.txtNomDimR.Name = "txtNomDimR";
            this.txtNomDimR.ReadOnly = true;
            this.txtNomDimR.Size = new System.Drawing.Size(315, 21);
            this.txtNomDimR.TabIndex = 4;
            // 
            // lblDirecDimr
            // 
            this.lblDirecDimr.AutoSize = true;
            this.lblDirecDimr.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDirecDimr.Location = new System.Drawing.Point(6, 80);
            this.lblDirecDimr.Name = "lblDirecDimr";
            this.lblDirecDimr.Size = new System.Drawing.Size(62, 15);
            this.lblDirecDimr.TabIndex = 7;
            this.lblDirecDimr.Text = "Direccion:";
            // 
            // txtDirecDimR
            // 
            this.txtDirecDimR.Enabled = false;
            this.txtDirecDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDirecDimR.Location = new System.Drawing.Point(73, 77);
            this.txtDirecDimR.MaxLength = 250;
            this.txtDirecDimR.Name = "txtDirecDimR";
            this.txtDirecDimR.Size = new System.Drawing.Size(380, 21);
            this.txtDirecDimR.TabIndex = 8;
            // 
            // btnBorrarDimR
            // 
            this.btnBorrarDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBorrarDimR.Location = new System.Drawing.Point(432, 22);
            this.btnBorrarDimR.Name = "btnBorrarDimR";
            this.btnBorrarDimR.Size = new System.Drawing.Size(84, 23);
            this.btnBorrarDimR.TabIndex = 9;
            this.btnBorrarDimR.Text = "Borra Datos";
            this.btnBorrarDimR.UseVisualStyleBackColor = true;
            this.btnBorrarDimR.Click += new System.EventHandler(this.btnBorrarDimR_Click);
            // 
            // grbDimR
            // 
            this.grbDimR.AutoSize = true;
            this.grbDimR.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbDimR.BackColor = System.Drawing.Color.LightBlue;
            this.grbDimR.Controls.Add(this.grbDimR2);
            this.grbDimR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDimR.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbDimR.Location = new System.Drawing.Point(184, 4);
            this.grbDimR.Name = "grbDimR";
            this.grbDimR.Size = new System.Drawing.Size(887, 151);
            this.grbDimR.TabIndex = 8;
            this.grbDimR.TabStop = false;
            this.grbDimR.Text = "Recomendado Por:";
            this.grbDimR.Visible = false;
            // 
            // CteExpress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1092, 690);
            this.Controls.Add(this.grbDimR);
            this.Controls.Add(this.grbRefComBan);
            this.Controls.Add(this.grbContactos);
            this.Controls.Add(this.grbTelefono);
            this.Controls.Add(this.grbDatNominales);
            this.Controls.Add(this.grbRef);
            this.Controls.Add(this.grboxEmpleoCte);
            this.Controls.Add(this.grboxCaps);
            this.Controls.Add(this.grbox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CteExpress";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cliente Express";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CteExpress_FormClosing);
            this.Load += new System.EventHandler(this.CteExpress_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.CteExpress_Scroll);
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.CteExpess_MouseWheel);
            this.grbox1.ResumeLayout(false);
            this.grboxCte.ResumeLayout(false);
            this.grboxCte.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.grBoxDomAnt.ResumeLayout(false);
            this.grBoxDomAnt.PerformLayout();
            this.grBoxDirCte.ResumeLayout(false);
            this.grBoxDirCte.PerformLayout();
            this.grboxCaps.ResumeLayout(false);
            this.grboxCaps.PerformLayout();
            this.grboxEmpleoCte.ResumeLayout(false);
            this.grboxDirEmpA.ResumeLayout(false);
            this.grboxDirEmpA.PerformLayout();
            this.grboxDirEmpleo.ResumeLayout(false);
            this.grboxDirEmpleo.PerformLayout();
            this.grbEmpCte.ResumeLayout(false);
            this.grbEmpCte.PerformLayout();
            this.grbRef.ResumeLayout(false);
            this.grbBusCte.ResumeLayout(false);
            this.grbBusCte.PerformLayout();
            this.grbDatComBan.ResumeLayout(false);
            this.grbDatComBan.PerformLayout();
            this.grbDatNominales.ResumeLayout(false);
            this.grbNomi.ResumeLayout(false);
            this.grbNomi.PerformLayout();
            this.grbTelefono.ResumeLayout(false);
            this.grbTiempo.ResumeLayout(false);
            this.grbTiempo.PerformLayout();
            this.grbTel.ResumeLayout(false);
            this.grbTel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTelefono)).EndInit();
            this.grbContactos.ResumeLayout(false);
            this.grbCont.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCto)).EndInit();
            this.grbRefComBan.ResumeLayout(false);
            this.grbDimR2.ResumeLayout(false);
            this.grbDimR2.PerformLayout();
            this.grbDimR.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CteExpress_OnGotFocus(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.GroupBox grbox1;
        private System.Windows.Forms.Label lblCol;
        private System.Windows.Forms.Label lblEntC;
        private System.Windows.Forms.TextBox txtEntreC;
        private System.Windows.Forms.ComboBox cmbTipoCalle;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.TextBox txtNumInt;
        private System.Windows.Forms.Label lblNumInt;
        private System.Windows.Forms.TextBox txtNumExt;
        private System.Windows.Forms.Label lblNumEx;
        private System.Windows.Forms.TextBox txtDir;
        private System.Windows.Forms.Label lblDom;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TextBox txtColCte;
        private System.Windows.Forms.TextBox txtPaisCte;
        private System.Windows.Forms.Label lblPaisCte;
        private System.Windows.Forms.TextBox txtEstCte;
        private System.Windows.Forms.Label lblEstCte;
        private System.Windows.Forms.TextBox txtPobCte;
        private System.Windows.Forms.Label lblPobCte;
        private System.Windows.Forms.TextBox txtDelCte;
        private System.Windows.Forms.Label lblDelCte;
        private System.Windows.Forms.TextBox txtCpCte;
        private System.Windows.Forms.Label lblCpCte;
        private System.Windows.Forms.ComboBox cmbViveCalCte;
        private System.Windows.Forms.Label lblViveCalCte;
        private System.Windows.Forms.Label lblMesAntCte;
        private System.Windows.Forms.Label lblYearAntCte;
        private System.Windows.Forms.GroupBox grBoxDirCte;
        private System.Windows.Forms.GroupBox grBoxDomAnt;
        private System.Windows.Forms.TextBox txtEntreCAnt;
        private System.Windows.Forms.Label lblDirCteAnt;
        private System.Windows.Forms.Label lblMesAntCteA;
        private System.Windows.Forms.TextBox txtDirAnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblYearAntCteA;
        private System.Windows.Forms.TextBox txtNumExtAnt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNumIntAnt;
        private System.Windows.Forms.TextBox txtPaisCteAnt;
        private System.Windows.Forms.Label lblTipoCalleAnt;
        private System.Windows.Forms.Label lblPaisCteAnt;
        private System.Windows.Forms.ComboBox cmbTipoCalleAnt;
        private System.Windows.Forms.TextBox txtEstCteAnt;
        private System.Windows.Forms.Label lblEntCAnt;
        private System.Windows.Forms.Label lblEstCteAnt;
        private System.Windows.Forms.Label lblColAnt;
        private System.Windows.Forms.TextBox txtPobCteAnt;
        private System.Windows.Forms.TextBox txtColCteAnt;
        private System.Windows.Forms.Label lblPobCteAnt;
        private System.Windows.Forms.Button btnBuscarAnt;
        private System.Windows.Forms.TextBox txtDelCteAnt;
        private System.Windows.Forms.Label lblCpCteAnt;
        private System.Windows.Forms.Label lblDelCteAnt;
        private System.Windows.Forms.TextBox txtCpCteAnt;
        private System.Windows.Forms.GroupBox grboxCte;
        private System.Windows.Forms.TextBox txtEdad;
        private System.Windows.Forms.Label lblEd;
        private System.Windows.Forms.DateTimePicker dtpFechNac;
        private System.Windows.Forms.Label lblEdoC;
        private System.Windows.Forms.ComboBox cmbEdoCivil;
        private System.Windows.Forms.TextBox txtRfc;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtApePat;
        private System.Windows.Forms.TextBox txtApeMat;
        private System.Windows.Forms.TextBox txtCanal;
        private System.Windows.Forms.Label lblrfc;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblFechNac;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.ComboBox cmbSex;
        private System.Windows.Forms.Label lblApePat;
        private System.Windows.Forms.Label lblApMat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblReg;
        private System.Windows.Forms.ComboBox cmbRegimen;
        private System.Windows.Forms.GroupBox grboxCaps;
        private System.Windows.Forms.Button btnCapDatCte;
        private System.Windows.Forms.GroupBox grboxEmpleoCte;
        private System.Windows.Forms.GroupBox grbEmpCte;
        private System.Windows.Forms.TextBox txtEmpCte;
        private System.Windows.Forms.Label lblEmpCte;
        private System.Windows.Forms.Label lblFunEmpCte;
        private System.Windows.Forms.TextBox txtFunEmpCte;
        private System.Windows.Forms.Label lblMesEmp;
        private System.Windows.Forms.Label lblYearEmp;
        private System.Windows.Forms.TextBox txtDepEmpCte;
        private System.Windows.Forms.Label lblDepEmpCte;
        private System.Windows.Forms.TextBox txtPstoJefe;
        private System.Windows.Forms.Label lblPstoJefInme;
        private System.Windows.Forms.TextBox txtJefe;
        private System.Windows.Forms.Label lblJefe;
        private System.Windows.Forms.Label lblIngresos;
        private System.Windows.Forms.TextBox txtIngreso;
        private System.Windows.Forms.ComboBox cmbPerIngreso;
        private System.Windows.Forms.Label lblPerIngreso;
        private System.Windows.Forms.GroupBox grboxDirEmpleo;
        private System.Windows.Forms.TextBox txtEntCalleE;
        private System.Windows.Forms.Label lblDirEmp;
        private System.Windows.Forms.TextBox txtDirEmp;
        private System.Windows.Forms.Label lblNumExEmp;
        private System.Windows.Forms.TextBox txtNumExtEmp;
        private System.Windows.Forms.Label lblNumIntEmp;
        private System.Windows.Forms.TextBox txtNumIntEmp;
        private System.Windows.Forms.TextBox txtPaisEmp;
        private System.Windows.Forms.Label lblTipCalleE;
        private System.Windows.Forms.Label lblPaisE;
        private System.Windows.Forms.ComboBox cmbTipCalleE;
        private System.Windows.Forms.TextBox txtEstEmp;
        private System.Windows.Forms.Label lblEntCalleE;
        private System.Windows.Forms.Label lblEstEmp;
        private System.Windows.Forms.Label lblColEmp;
        private System.Windows.Forms.TextBox txtPobEmp;
        private System.Windows.Forms.TextBox txtColEmp;
        private System.Windows.Forms.Label lblPobEmp;
        private System.Windows.Forms.Button btnBusColE;
        private System.Windows.Forms.TextBox txtDelEmp;
        private System.Windows.Forms.Label lblCpEmp;
        private System.Windows.Forms.Label lblDelEmp;
        private System.Windows.Forms.TextBox txtCpEmp;
        private System.Windows.Forms.CheckBox chboxComprob;
        private System.Windows.Forms.GroupBox grboxDirEmpA;
        private System.Windows.Forms.TextBox txtEntCalleEa;
        private System.Windows.Forms.Label lblDirAntE;
        private System.Windows.Forms.TextBox txtDirAntE;
        private System.Windows.Forms.Label lblExtEmpA;
        private System.Windows.Forms.TextBox txtExtEmpA;
        private System.Windows.Forms.Label lblIntEmpA;
        private System.Windows.Forms.TextBox txtIntEmpA;
        private System.Windows.Forms.TextBox txtPaisEmpA;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPaisEmpA;
        private System.Windows.Forms.ComboBox cmbTipCalleEmpA;
        private System.Windows.Forms.TextBox txtEstEmpA;
        private System.Windows.Forms.Label lblEntCalleEa;
        private System.Windows.Forms.Label lblEstEmpA;
        private System.Windows.Forms.Label lblColEmpA;
        private System.Windows.Forms.TextBox txtPobEmpA;
        private System.Windows.Forms.TextBox txtColEmpA;
        private System.Windows.Forms.Label lblPobEmpA;
        private System.Windows.Forms.Button btnBusColA;
        private System.Windows.Forms.TextBox txtDelEmpA;
        private System.Windows.Forms.Label lblCpEmpA;
        private System.Windows.Forms.Label lblDelEmpA;
        private System.Windows.Forms.TextBox txtCpEmpA;
        private System.Windows.Forms.ComboBox cmbKeLiveEnC;
        private System.Windows.Forms.Label lblKeViveEnC;
        private System.Windows.Forms.ComboBox cmbLiveCon;
        private System.Windows.Forms.Label lblLiveCon;
        private System.Windows.Forms.Label lblCon;
        private System.Windows.Forms.GroupBox grbRef;
        private System.Windows.Forms.GroupBox grbBusCte;
        private System.Windows.Forms.TextBox txtRecPor;
        private System.Windows.Forms.Label lblBuscte;
        private System.Windows.Forms.Button btnBuscCte;
        private System.Windows.Forms.ComboBox cmbParent;
        private System.Windows.Forms.Label lblParen;
        private System.Windows.Forms.TextBox txtDirRe;
        private System.Windows.Forms.Label lblDirRe;
        private System.Windows.Forms.TextBox txtNomR;
        private System.Windows.Forms.Label lblNomR;
        private System.Windows.Forms.Button btnCapEmpCte;
        private System.Windows.Forms.Button btnCapRefCte;
        private System.Windows.Forms.GroupBox grbDatNominales;
        private System.Windows.Forms.GroupBox grbNomi;
        private System.Windows.Forms.TextBox txtMpioN;
        private System.Windows.Forms.Label lblMpioN;
        private System.Windows.Forms.TextBox txtCargoN;
        private System.Windows.Forms.Label lblCargoN;
        private System.Windows.Forms.TextBox txtCveInst;
        private System.Windows.Forms.Label lblCveInst;
        private System.Windows.Forms.TextBox txtRfcInst;
        private System.Windows.Forms.Label lblRfcInst;
        private System.Windows.Forms.Label lblPuestoN;
        private System.Windows.Forms.TextBox txtPuestoN;
        private System.Windows.Forms.TextBox txtConfNomina;
        private System.Windows.Forms.Label lblConfNom;
        private System.Windows.Forms.TextBox txtNomina;
        private System.Windows.Forms.Label lblNomina;
        private System.Windows.Forms.Button btnDatNomi;
        private System.Windows.Forms.GroupBox grbTelefono;
        private System.Windows.Forms.GroupBox grbTel;
        private System.Windows.Forms.DataGridView dgvTelefono;
        private System.Windows.Forms.Button btnAgrTel;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.GroupBox grbContactos;
        private System.Windows.Forms.GroupBox grbCont;
        private System.Windows.Forms.DataGridView dgvCto;
        private System.Windows.Forms.Button btnAgregarCto;
        private System.Windows.Forms.TextBox txtEmpAnt;
        private System.Windows.Forms.Label lblEmpAnt;
        private System.Windows.Forms.GroupBox grbDatComBan;
        private System.Windows.Forms.TextBox txtTarjBan3;
        private System.Windows.Forms.Label lblTarjBan3;
        private System.Windows.Forms.TextBox txtEmiBan3;
        private System.Windows.Forms.Label lblEmiBan3;
        private System.Windows.Forms.TextBox txtTarjBan2;
        private System.Windows.Forms.Label lblTarjBan2;
        private System.Windows.Forms.TextBox txtTarjBan1;
        private System.Windows.Forms.Label lblTarjBan1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lblTarjCom2;
        private System.Windows.Forms.TextBox txtTarjCom1;
        private System.Windows.Forms.Label lblTarjCom1;
        private System.Windows.Forms.TextBox txtEmiBan2;
        private System.Windows.Forms.Label lblEmiBan2;
        private System.Windows.Forms.TextBox txtEmiBan1;
        private System.Windows.Forms.Label lblEmiBan1;
        private System.Windows.Forms.TextBox txtEmiCom2;
        private System.Windows.Forms.Label lblEmiCom2;
        private System.Windows.Forms.TextBox txtEmiCom1;
        private System.Windows.Forms.Label lblEmiCom1;
        private System.Windows.Forms.Button btnTelefonos;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.Button btnImp;
        private System.Windows.Forms.Button btnGoogle;
        private System.Windows.Forms.Label lblSpid;
        private System.Windows.Forms.Label lblAnuncio;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.GroupBox grbRefComBan;
        private System.Windows.Forms.TextBox txtCtrlMes;
        private System.Windows.Forms.TextBox txtCtrlYear;
        private System.Windows.Forms.MaskedTextBox mskFechaNac;
        private System.Windows.Forms.TextBox txtMesDirAnt;
        private System.Windows.Forms.TextBox txtYearDomA;
        private System.Windows.Forms.TextBox txtMesEmp;
        private System.Windows.Forms.TextBox txtYearEmp;
        private System.Windows.Forms.Label lblFormatoFech;
        private System.Windows.Forms.GroupBox grbTiempo;
        private System.Windows.Forms.TextBox txtTiempo;
        private System.Windows.Forms.CheckBox chbPresent;
        private System.Windows.Forms.Label lblTipEMp;
        private System.Windows.Forms.ComboBox cmbTipEmp;
        private System.Windows.Forms.Label lblMail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parentesco;
        private System.Windows.Forms.DataGridViewTextBoxColumn ApePat;
        private System.Windows.Forms.DataGridViewTextBoxColumn ApeMat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn CnlVent;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lada;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn FechaN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EdoC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ViveEnCal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ViveCon;
        private System.Windows.Forms.DataGridViewTextBoxColumn CalidadCon;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCto;
        private System.Windows.Forms.DataGridViewTextBoxColumn EsCasa;
        private System.Windows.Forms.DataGridViewTextBoxColumn NoCuenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn rfcCto;
        private System.Windows.Forms.DataGridViewButtonColumn Editar;
        private System.Windows.Forms.DataGridViewButtonColumn Eliminar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox cmbTipoCred;
        private System.Windows.Forms.TextBox txtTipdesc;
        private System.Windows.Forms.Label lblTipDesc;
        private System.Windows.Forms.Label lblTipoCte;
        private System.Windows.Forms.DataGridViewButtonColumn Borrar;
        private System.Windows.Forms.DataGridViewComboBoxColumn TipoTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn LadaTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn TelefonoTel;
        private System.Windows.Forms.Label lblOpcion;
        private System.Windows.Forms.GroupBox grbDimR2;
        private System.Windows.Forms.Button btnBorrarDimR;
        private System.Windows.Forms.TextBox txtDirecDimR;
        private System.Windows.Forms.Label lblDirecDimr;
        private System.Windows.Forms.TextBox txtNomDimR;
        private System.Windows.Forms.Label lblNomDimR;
        private System.Windows.Forms.Button btnBuscarDimR;
        private System.Windows.Forms.TextBox txtCuentaDimr;
        private System.Windows.Forms.Label lblCuentaDimr;
        private System.Windows.Forms.GroupBox grbDimR;
        

    }
}

