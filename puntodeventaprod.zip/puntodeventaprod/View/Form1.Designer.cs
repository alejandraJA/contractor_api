﻿namespace PuntoVenta.View
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbx_VentaDetalle = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dvg_detalleVenta = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Observaciones = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CantidadDev = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_MonederoElectronico = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_MonederoElectroni = new System.Windows.Forms.GroupBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel_ActualizacionDatos = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Datos = new System.Windows.Forms.Button();
            this.btn_ObligatorioDatos = new System.Windows.Forms.Button();
            this.gbx_DatosEntrega = new System.Windows.Forms.GroupBox();
            this.btn_AgregarDatosEntrega = new System.Windows.Forms.Button();
            this.dgv_DatosEntrega = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TelPart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TelMovil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_Anticipo = new System.Windows.Forms.Button();
            this.gbx_Anticipo = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.panel_SHM = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_SHM = new System.Windows.Forms.Button();
            this.panel_Afectar = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Afectar = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.gbx_VentaDima = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_VentaD = new System.Windows.Forms.GroupBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.gbx_VentaDetalle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).BeginInit();
            this.gbx_MonederoElectronico.SuspendLayout();
            this.gbx_MonederoElectroni.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel_ActualizacionDatos.SuspendLayout();
            this.gbx_DatosEntrega.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DatosEntrega)).BeginInit();
            this.gbx_Anticipo.SuspendLayout();
            this.panel_SHM.SuspendLayout();
            this.panel_Afectar.SuspendLayout();
            this.gbx_VentaDima.SuspendLayout();
            this.gbx_VentaD.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_VentaDetalle
            // 
            this.gbx_VentaDetalle.Controls.Add(this.label5);
            this.gbx_VentaDetalle.Controls.Add(this.label6);
            this.gbx_VentaDetalle.Controls.Add(this.dvg_detalleVenta);
            this.gbx_VentaDetalle.Controls.Add(this.label19);
            this.gbx_VentaDetalle.Controls.Add(this.textBox16);
            this.gbx_VentaDetalle.Controls.Add(this.label18);
            this.gbx_VentaDetalle.Controls.Add(this.textBox15);
            this.gbx_VentaDetalle.Controls.Add(this.label17);
            this.gbx_VentaDetalle.Controls.Add(this.textBox14);
            this.gbx_VentaDetalle.Controls.Add(this.flowLayoutPanel5);
            this.gbx_VentaDetalle.Controls.Add(this.gbx_MonederoElectronico);
            this.gbx_VentaDetalle.Controls.Add(this.gbx_VentaDima);
            this.gbx_VentaDetalle.Location = new System.Drawing.Point(120, 12);
            this.gbx_VentaDetalle.Name = "gbx_VentaDetalle";
            this.gbx_VentaDetalle.Size = new System.Drawing.Size(925, 425);
            this.gbx_VentaDetalle.TabIndex = 89;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 10);
            this.label5.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 46;
            this.label5.Text = "Unidad";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(72, 10);
            this.label6.Margin = new System.Windows.Forms.Padding(10, 10, 3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 19);
            this.label6.TabIndex = 47;
            this.label6.Text = "Descripcion";
            // 
            // dvg_detalleVenta
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dvg_detalleVenta.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dvg_detalleVenta.BackgroundColor = System.Drawing.Color.Snow;
            this.dvg_detalleVenta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dvg_detalleVenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dvg_detalleVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg_detalleVenta.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Observaciones,
            this.CantidadDev});
            this.dvg_detalleVenta.EnableHeadersVisualStyles = false;
            this.dvg_detalleVenta.Location = new System.Drawing.Point(3, 36);
            this.dvg_detalleVenta.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.dvg_detalleVenta.Name = "dvg_detalleVenta";
            this.dvg_detalleVenta.RowHeadersVisible = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            this.dvg_detalleVenta.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dvg_detalleVenta.Size = new System.Drawing.Size(917, 139);
            this.dvg_detalleVenta.TabIndex = 39;
            // 
            // Column1
            // 
            this.Column1.FillWeight = 120F;
            this.Column1.HeaderText = "Articulo";
            this.Column1.Name = "Column1";
            this.Column1.Width = 120;
            // 
            // Column2
            // 
            this.Column2.FillWeight = 120F;
            this.Column2.HeaderText = "Cantidad";
            this.Column2.Name = "Column2";
            this.Column2.Width = 120;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Precio";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.FillWeight = 120F;
            this.Column4.HeaderText = "Sub Total";
            this.Column4.Name = "Column4";
            this.Column4.Width = 120;
            // 
            // Column5
            // 
            this.Column5.FillWeight = 85F;
            this.Column5.HeaderText = "Disponible";
            this.Column5.Name = "Column5";
            this.Column5.Width = 85;
            // 
            // Column6
            // 
            this.Column6.FillWeight = 120F;
            this.Column6.HeaderText = "Serie";
            this.Column6.Name = "Column6";
            this.Column6.Width = 120;
            // 
            // Observaciones
            // 
            this.Observaciones.FillWeight = 130F;
            this.Observaciones.HeaderText = "Observaciones";
            this.Observaciones.Name = "Observaciones";
            this.Observaciones.Width = 130;
            // 
            // CantidadDev
            // 
            this.CantidadDev.FillWeight = 80F;
            this.CantidadDev.HeaderText = "Cant a Devolver";
            this.CantidadDev.Name = "CantidadDev";
            this.CantidadDev.Width = 80;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(3, 188);
            this.label19.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(34, 15);
            this.label19.TabIndex = 51;
            this.label19.Text = "Total";
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.White;
            this.textBox16.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(43, 181);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(121, 22);
            this.textBox16.TabIndex = 53;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(170, 178);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 15);
            this.label18.TabIndex = 49;
            this.label18.Text = "Impuestos ";
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.White;
            this.textBox15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(241, 181);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(126, 22);
            this.textBox15.TabIndex = 52;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(373, 178);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 15);
            this.label17.TabIndex = 48;
            this.label17.Text = "Sub Total";
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.White;
            this.textBox14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(437, 181);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(111, 22);
            this.textBox14.TabIndex = 50;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Location = new System.Drawing.Point(554, 181);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(366, 22);
            this.flowLayoutPanel5.TabIndex = 54;
            // 
            // gbx_MonederoElectronico
            // 
            this.gbx_MonederoElectronico.Controls.Add(this.gbx_MonederoElectroni);
            this.gbx_MonederoElectronico.Location = new System.Drawing.Point(3, 209);
            this.gbx_MonederoElectronico.Name = "gbx_MonederoElectronico";
            this.gbx_MonederoElectronico.Size = new System.Drawing.Size(564, 201);
            this.gbx_MonederoElectronico.TabIndex = 55;
            // 
            // gbx_MonederoElectroni
            // 
            this.gbx_MonederoElectroni.BackColor = System.Drawing.Color.White;
            this.gbx_MonederoElectroni.Controls.Add(this.textBox25);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox24);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox23);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox22);
            this.gbx_MonederoElectroni.Controls.Add(this.label28);
            this.gbx_MonederoElectroni.Controls.Add(this.label27);
            this.gbx_MonederoElectroni.Controls.Add(this.label26);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox20);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox19);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox18);
            this.gbx_MonederoElectroni.Controls.Add(this.textBox17);
            this.gbx_MonederoElectroni.Controls.Add(this.label25);
            this.gbx_MonederoElectroni.Controls.Add(this.label24);
            this.gbx_MonederoElectroni.Controls.Add(this.label23);
            this.gbx_MonederoElectroni.Controls.Add(this.label22);
            this.gbx_MonederoElectroni.Controls.Add(this.label21);
            this.gbx_MonederoElectroni.Controls.Add(this.label20);
            this.gbx_MonederoElectroni.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_MonederoElectroni.Location = new System.Drawing.Point(3, 3);
            this.gbx_MonederoElectroni.Name = "gbx_MonederoElectroni";
            this.gbx_MonederoElectroni.Size = new System.Drawing.Size(549, 183);
            this.gbx_MonederoElectroni.TabIndex = 44;
            this.gbx_MonederoElectroni.TabStop = false;
            this.gbx_MonederoElectroni.Text = "Monedero Electronico";
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.White;
            this.textBox25.Location = new System.Drawing.Point(391, 134);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(126, 22);
            this.textBox25.TabIndex = 51;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.Color.White;
            this.textBox24.Location = new System.Drawing.Point(379, 42);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(81, 22);
            this.textBox24.TabIndex = 46;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.White;
            this.textBox23.Location = new System.Drawing.Point(379, 69);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(81, 22);
            this.textBox23.TabIndex = 47;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.panel_ActualizacionDatos);
            this.flowLayoutPanel1.Controls.Add(this.btn_ObligatorioDatos);
            this.flowLayoutPanel1.Controls.Add(this.gbx_DatosEntrega);
            this.flowLayoutPanel1.Controls.Add(this.btn_Anticipo);
            this.flowLayoutPanel1.Controls.Add(this.gbx_Anticipo);
            this.flowLayoutPanel1.Controls.Add(this.panel_SHM);
            this.flowLayoutPanel1.Controls.Add(this.panel_Afectar);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(142, 463);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(935, 1106);
            this.flowLayoutPanel1.TabIndex = 97;
            // 
            // panel_ActualizacionDatos
            // 
            this.panel_ActualizacionDatos.Controls.Add(this.btn_Datos);
            this.panel_ActualizacionDatos.Location = new System.Drawing.Point(3, 3);
            this.panel_ActualizacionDatos.Name = "panel_ActualizacionDatos";
            this.panel_ActualizacionDatos.Size = new System.Drawing.Size(900, 62);
            this.panel_ActualizacionDatos.TabIndex = 82;
            // 
            // btn_Datos
            // 
            this.btn_Datos.BackColor = System.Drawing.Color.White;
            this.btn_Datos.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btn_Datos.FlatAppearance.BorderSize = 0;
            this.btn_Datos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Datos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Datos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Datos.Image")));
            this.btn_Datos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Datos.Location = new System.Drawing.Point(3, 3);
            this.btn_Datos.Name = "btn_Datos";
            this.btn_Datos.Size = new System.Drawing.Size(171, 50);
            this.btn_Datos.TabIndex = 25;
            this.btn_Datos.Text = "Actualizacion de Datos";
            this.btn_Datos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Datos.UseVisualStyleBackColor = false;
            // 
            // btn_ObligatorioDatos
            // 
            this.btn_ObligatorioDatos.BackColor = System.Drawing.Color.White;
            this.btn_ObligatorioDatos.FlatAppearance.BorderSize = 0;
            this.btn_ObligatorioDatos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ObligatorioDatos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ObligatorioDatos.Image = ((System.Drawing.Image)(resources.GetObject("btn_ObligatorioDatos.Image")));
            this.btn_ObligatorioDatos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ObligatorioDatos.Location = new System.Drawing.Point(3, 71);
            this.btn_ObligatorioDatos.Name = "btn_ObligatorioDatos";
            this.btn_ObligatorioDatos.Size = new System.Drawing.Size(132, 33);
            this.btn_ObligatorioDatos.TabIndex = 26;
            this.btn_ObligatorioDatos.Text = "Datos de Entrega";
            this.btn_ObligatorioDatos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_ObligatorioDatos.UseVisualStyleBackColor = false;
            // 
            // gbx_DatosEntrega
            // 
            this.gbx_DatosEntrega.Controls.Add(this.btn_AgregarDatosEntrega);
            this.gbx_DatosEntrega.Controls.Add(this.dgv_DatosEntrega);
            this.gbx_DatosEntrega.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_DatosEntrega.Location = new System.Drawing.Point(3, 110);
            this.gbx_DatosEntrega.Name = "gbx_DatosEntrega";
            this.gbx_DatosEntrega.Size = new System.Drawing.Size(920, 220);
            this.gbx_DatosEntrega.TabIndex = 85;
            this.gbx_DatosEntrega.TabStop = false;
            // 
            // btn_AgregarDatosEntrega
            // 
            this.btn_AgregarDatosEntrega.BackColor = System.Drawing.Color.White;
            this.btn_AgregarDatosEntrega.FlatAppearance.BorderSize = 0;
            this.btn_AgregarDatosEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgregarDatosEntrega.Image = ((System.Drawing.Image)(resources.GetObject("btn_AgregarDatosEntrega.Image")));
            this.btn_AgregarDatosEntrega.Location = new System.Drawing.Point(7, 152);
            this.btn_AgregarDatosEntrega.Name = "btn_AgregarDatosEntrega";
            this.btn_AgregarDatosEntrega.Size = new System.Drawing.Size(125, 38);
            this.btn_AgregarDatosEntrega.TabIndex = 37;
            this.btn_AgregarDatosEntrega.Text = "Agregar";
            this.btn_AgregarDatosEntrega.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_AgregarDatosEntrega.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_AgregarDatosEntrega.UseVisualStyleBackColor = false;
            // 
            // dgv_DatosEntrega
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_DatosEntrega.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_DatosEntrega.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_DatosEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_DatosEntrega.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_DatosEntrega.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_DatosEntrega.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.TelPart,
            this.TelMovil,
            this.Column13});
            this.dgv_DatosEntrega.EnableHeadersVisualStyles = false;
            this.dgv_DatosEntrega.Location = new System.Drawing.Point(6, 25);
            this.dgv_DatosEntrega.Name = "dgv_DatosEntrega";
            this.dgv_DatosEntrega.RowHeadersVisible = false;
            this.dgv_DatosEntrega.Size = new System.Drawing.Size(911, 121);
            this.dgv_DatosEntrega.TabIndex = 36;
            // 
            // Column7
            // 
            this.Column7.FillWeight = 150F;
            this.Column7.HeaderText = "Direccion";
            this.Column7.Name = "Column7";
            this.Column7.Width = 150;
            // 
            // Column8
            // 
            this.Column8.FillWeight = 120F;
            this.Column8.HeaderText = "Colonia";
            this.Column8.Name = "Column8";
            this.Column8.Width = 120;
            // 
            // Column9
            // 
            this.Column9.FillWeight = 120F;
            this.Column9.HeaderText = "Población";
            this.Column9.Name = "Column9";
            this.Column9.Width = 120;
            // 
            // Column10
            // 
            this.Column10.FillWeight = 120F;
            this.Column10.HeaderText = "Cp";
            this.Column10.Name = "Column10";
            this.Column10.Width = 120;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Estado";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.FillWeight = 130F;
            this.Column12.HeaderText = "Entre Calles";
            this.Column12.Name = "Column12";
            this.Column12.Width = 130;
            // 
            // TelPart
            // 
            this.TelPart.HeaderText = "Telefono Particular";
            this.TelPart.Name = "TelPart";
            // 
            // TelMovil
            // 
            this.TelMovil.HeaderText = "Telefono Movil";
            this.TelMovil.Name = "TelMovil";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Referencia";
            this.Column13.Name = "Column13";
            // 
            // btn_Anticipo
            // 
            this.btn_Anticipo.BackColor = System.Drawing.Color.White;
            this.btn_Anticipo.FlatAppearance.BorderSize = 0;
            this.btn_Anticipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Anticipo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Anticipo.Image = ((System.Drawing.Image)(resources.GetObject("btn_Anticipo.Image")));
            this.btn_Anticipo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Anticipo.Location = new System.Drawing.Point(7, 336);
            this.btn_Anticipo.Margin = new System.Windows.Forms.Padding(7, 3, 3, 3);
            this.btn_Anticipo.Name = "btn_Anticipo";
            this.btn_Anticipo.Size = new System.Drawing.Size(96, 40);
            this.btn_Anticipo.TabIndex = 55;
            this.btn_Anticipo.Text = "Anticipo";
            this.btn_Anticipo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Anticipo.UseVisualStyleBackColor = false;
            // 
            // gbx_Anticipo
            // 
            this.gbx_Anticipo.BackColor = System.Drawing.Color.White;
            this.gbx_Anticipo.Controls.Add(this.label32);
            this.gbx_Anticipo.Controls.Add(this.label43);
            this.gbx_Anticipo.Controls.Add(this.textBox31);
            this.gbx_Anticipo.Controls.Add(this.button6);
            this.gbx_Anticipo.Controls.Add(this.label39);
            this.gbx_Anticipo.Controls.Add(this.textBox29);
            this.gbx_Anticipo.Controls.Add(this.textBox32);
            this.gbx_Anticipo.Controls.Add(this.label42);
            this.gbx_Anticipo.Controls.Add(this.textBox30);
            this.gbx_Anticipo.Controls.Add(this.label40);
            this.gbx_Anticipo.Controls.Add(this.textBox28);
            this.gbx_Anticipo.Controls.Add(this.label41);
            this.gbx_Anticipo.Location = new System.Drawing.Point(3, 382);
            this.gbx_Anticipo.Name = "gbx_Anticipo";
            this.gbx_Anticipo.Size = new System.Drawing.Size(934, 140);
            this.gbx_Anticipo.TabIndex = 88;
            this.gbx_Anticipo.TabStop = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(495, 30);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(137, 15);
            this.label32.TabIndex = 67;
            this.label32.Text = "Agregar Forma de Pago";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(44, 25);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(72, 15);
            this.label43.TabIndex = 53;
            this.label43.Text = "Forma Pago";
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.Color.White;
            this.textBox31.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(47, 41);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(81, 22);
            this.textBox31.TabIndex = 56;
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Blackadder ITC", 1.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(443, 25);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(43, 32);
            this.button6.TabIndex = 61;
            this.button6.Text = "+";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(45, 64);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 15);
            this.label39.TabIndex = 57;
            this.label39.Text = "Total ";
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.Color.White;
            this.textBox29.Location = new System.Drawing.Point(47, 80);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(79, 20);
            this.textBox29.TabIndex = 58;
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.Color.White;
            this.textBox32.Location = new System.Drawing.Point(250, 80);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(81, 20);
            this.textBox32.TabIndex = 60;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(151, 25);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 15);
            this.label42.TabIndex = 54;
            this.label42.Text = "Monto";
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.Color.White;
            this.textBox30.Location = new System.Drawing.Point(150, 80);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(81, 20);
            this.textBox30.TabIndex = 59;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.White;
            this.label40.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(248, 64);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(51, 15);
            this.label40.TabIndex = 56;
            this.label40.Text = "Cambio ";
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.Color.White;
            this.textBox28.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(150, 41);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(81, 22);
            this.textBox28.TabIndex = 57;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.White;
            this.label41.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(151, 64);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(47, 15);
            this.label41.TabIndex = 55;
            this.label41.Text = "Recibo ";
            // 
            // panel_SHM
            // 
            this.panel_SHM.Controls.Add(this.btn_SHM);
            this.panel_SHM.Location = new System.Drawing.Point(3, 528);
            this.panel_SHM.Name = "panel_SHM";
            this.panel_SHM.Size = new System.Drawing.Size(934, 43);
            this.panel_SHM.TabIndex = 95;
            // 
            // btn_SHM
            // 
            this.btn_SHM.BackColor = System.Drawing.Color.White;
            this.btn_SHM.FlatAppearance.BorderSize = 0;
            this.btn_SHM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SHM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SHM.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_SHM.Image = ((System.Drawing.Image)(resources.GetObject("btn_SHM.Image")));
            this.btn_SHM.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_SHM.Location = new System.Drawing.Point(3, 3);
            this.btn_SHM.Name = "btn_SHM";
            this.btn_SHM.Size = new System.Drawing.Size(81, 33);
            this.btn_SHM.TabIndex = 62;
            this.btn_SHM.Text = "SHM";
            this.btn_SHM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_SHM.UseVisualStyleBackColor = false;
            // 
            // panel_Afectar
            // 
            this.panel_Afectar.Controls.Add(this.btn_Afectar);
            this.panel_Afectar.Location = new System.Drawing.Point(3, 577);
            this.panel_Afectar.Name = "panel_Afectar";
            this.panel_Afectar.Size = new System.Drawing.Size(900, 44);
            this.panel_Afectar.TabIndex = 95;
            // 
            // btn_Afectar
            // 
            this.btn_Afectar.BackColor = System.Drawing.Color.White;
            this.btn_Afectar.FlatAppearance.BorderSize = 0;
            this.btn_Afectar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Afectar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Afectar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Afectar.Image")));
            this.btn_Afectar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Afectar.Location = new System.Drawing.Point(3, 3);
            this.btn_Afectar.Name = "btn_Afectar";
            this.btn_Afectar.Size = new System.Drawing.Size(155, 33);
            this.btn_Afectar.TabIndex = 63;
            this.btn_Afectar.Text = "Generar Movimiento";
            this.btn_Afectar.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btn_Afectar.UseVisualStyleBackColor = false;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.White;
            this.textBox22.Location = new System.Drawing.Point(379, 100);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(81, 22);
            this.textBox22.TabIndex = 48;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(273, 46);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(103, 15);
            this.label28.TabIndex = 51;
            this.label28.Text = "Cuenta Monedero";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(273, 69);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(37, 15);
            this.label27.TabIndex = 50;
            this.label27.Text = "Saldo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(273, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 15);
            this.label26.TabIndex = 49;
            this.label26.Text = "Monto  Redimir";
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.White;
            this.textBox20.Location = new System.Drawing.Point(165, 134);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(217, 22);
            this.textBox20.TabIndex = 50;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.White;
            this.textBox19.Location = new System.Drawing.Point(76, 134);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(81, 22);
            this.textBox19.TabIndex = 49;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.White;
            this.textBox18.Location = new System.Drawing.Point(122, 75);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(81, 22);
            this.textBox18.TabIndex = 45;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.White;
            this.textBox17.Location = new System.Drawing.Point(122, 46);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(81, 22);
            this.textBox17.TabIndex = 44;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(13, 49);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 15);
            this.label25.TabIndex = 44;
            this.label25.Text = "Cuenta Monedero";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(14, 75);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 15);
            this.label24.TabIndex = 43;
            this.label24.Text = "Puntos";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 141);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 15);
            this.label23.TabIndex = 42;
            this.label23.Text = "Autoriza";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(220, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 15);
            this.label22.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(273, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 15);
            this.label21.TabIndex = 40;
            this.label21.Text = "Redime";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(82, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 15);
            this.label20.TabIndex = 39;
            this.label20.Text = "Generación";
            // 
            // gbx_VentaDima
            // 
            this.gbx_VentaDima.Controls.Add(this.gbx_VentaD);
            this.gbx_VentaDima.Location = new System.Drawing.Point(573, 209);
            this.gbx_VentaDima.Name = "gbx_VentaDima";
            this.gbx_VentaDima.Size = new System.Drawing.Size(327, 201);
            this.gbx_VentaDima.TabIndex = 56;
            // 
            // gbx_VentaD
            // 
            this.gbx_VentaD.BackColor = System.Drawing.Color.White;
            this.gbx_VentaD.Controls.Add(this.textBox27);
            this.gbx_VentaD.Controls.Add(this.textBox26);
            this.gbx_VentaD.Controls.Add(this.textBox21);
            this.gbx_VentaD.Controls.Add(this.label31);
            this.gbx_VentaD.Controls.Add(this.label30);
            this.gbx_VentaD.Controls.Add(this.label29);
            this.gbx_VentaD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_VentaD.Location = new System.Drawing.Point(3, 3);
            this.gbx_VentaD.Name = "gbx_VentaD";
            this.gbx_VentaD.Size = new System.Drawing.Size(284, 183);
            this.gbx_VentaD.TabIndex = 45;
            this.gbx_VentaD.TabStop = false;
            this.gbx_VentaD.Text = "Venta Dima";
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.Color.White;
            this.textBox27.Location = new System.Drawing.Point(60, 33);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(81, 22);
            this.textBox27.TabIndex = 52;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.Color.White;
            this.textBox26.Location = new System.Drawing.Point(115, 97);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(130, 22);
            this.textBox26.TabIndex = 54;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.White;
            this.textBox21.Location = new System.Drawing.Point(60, 62);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(81, 22);
            this.textBox21.TabIndex = 53;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(20, 65);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 15);
            this.label31.TabIndex = 43;
            this.label31.Text = " Nip ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(20, 100);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(84, 15);
            this.label30.TabIndex = 42;
            this.label30.Text = "Recomendado ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(20, 36);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 15);
            this.label29.TabIndex = 41;
            this.label29.Text = "Vale ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1267, 581);
            this.Controls.Add(this.gbx_VentaDetalle);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbx_VentaDetalle.ResumeLayout(false);
            this.gbx_VentaDetalle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_detalleVenta)).EndInit();
            this.gbx_MonederoElectronico.ResumeLayout(false);
            this.gbx_MonederoElectroni.ResumeLayout(false);
            this.gbx_MonederoElectroni.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel_ActualizacionDatos.ResumeLayout(false);
            this.gbx_DatosEntrega.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DatosEntrega)).EndInit();
            this.gbx_Anticipo.ResumeLayout(false);
            this.gbx_Anticipo.PerformLayout();
            this.panel_SHM.ResumeLayout(false);
            this.panel_Afectar.ResumeLayout(false);
            this.gbx_VentaDima.ResumeLayout(false);
            this.gbx_VentaD.ResumeLayout(false);
            this.gbx_VentaD.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel gbx_VentaDetalle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dvg_detalleVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Observaciones;
        private System.Windows.Forms.DataGridViewTextBoxColumn CantidadDev;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.FlowLayoutPanel gbx_MonederoElectronico;
        private System.Windows.Forms.GroupBox gbx_MonederoElectroni;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel panel_ActualizacionDatos;
        private System.Windows.Forms.Button btn_Datos;
        private System.Windows.Forms.Button btn_ObligatorioDatos;
        private System.Windows.Forms.GroupBox gbx_DatosEntrega;
        private System.Windows.Forms.Button btn_AgregarDatosEntrega;
        private System.Windows.Forms.DataGridView dgv_DatosEntrega;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn TelPart;
        private System.Windows.Forms.DataGridViewTextBoxColumn TelMovil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.Button btn_Anticipo;
        private System.Windows.Forms.GroupBox gbx_Anticipo;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.FlowLayoutPanel panel_SHM;
        private System.Windows.Forms.Button btn_SHM;
        private System.Windows.Forms.FlowLayoutPanel panel_Afectar;
        private System.Windows.Forms.Button btn_Afectar;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.FlowLayoutPanel gbx_VentaDima;
        private System.Windows.Forms.GroupBox gbx_VentaD;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
    }
}