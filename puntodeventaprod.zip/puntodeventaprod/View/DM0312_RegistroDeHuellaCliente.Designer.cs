﻿namespace PuntoVenta
{
    partial class RegistroDeHuellaCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistroDeHuellaCliente));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_Fotos = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.gv_Huellas = new System.Windows.Forms.DataGridView();
            this.EsValido = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gv_PregYRes = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbFecha = new System.Windows.Forms.ComboBox();
            this.cmbSucursal = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMovID = new System.Windows.Forms.Label();
            this.lblMov = new System.Windows.Forms.Label();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.btn_refrescar = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_DIMAafil = new System.Windows.Forms.Button();
            this.btnHistorico = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Huellas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PregYRes)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Fotos
            // 
            this.btn_Fotos.BackColor = System.Drawing.Color.White;
            this.btn_Fotos.FlatAppearance.BorderSize = 0;
            this.btn_Fotos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fotos.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fotos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Fotos.Image")));
            this.btn_Fotos.Location = new System.Drawing.Point(-1, 172);
            this.btn_Fotos.Name = "btn_Fotos";
            this.btn_Fotos.Size = new System.Drawing.Size(83, 60);
            this.btn_Fotos.TabIndex = 7;
            this.btn_Fotos.Text = "Imagenes";
            this.btn_Fotos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Fotos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Fotos.UseVisualStyleBackColor = false;
            this.btn_Fotos.Click += new System.EventHandler(this.btn_Fotos_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_Comentarios);
            this.groupBox1.Controls.Add(this.gv_Huellas);
            this.groupBox1.Controls.Add(this.gv_PregYRes);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbFecha);
            this.groupBox1.Controls.Add(this.cmbSucursal);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(90, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1145, 498);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(331, 16);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(808, 38);
            this.txt_Comentarios.TabIndex = 123;
            // 
            // gv_Huellas
            // 
            this.gv_Huellas.AllowUserToAddRows = false;
            this.gv_Huellas.AllowUserToDeleteRows = false;
            this.gv_Huellas.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gv_Huellas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Huellas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.gv_Huellas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_Huellas.BackgroundColor = System.Drawing.Color.Snow;
            this.gv_Huellas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Huellas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Huellas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Huellas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EsValido});
            this.gv_Huellas.EnableHeadersVisualStyles = false;
            this.gv_Huellas.Location = new System.Drawing.Point(6, 78);
            this.gv_Huellas.MultiSelect = false;
            this.gv_Huellas.Name = "gv_Huellas";
            this.gv_Huellas.RowHeadersVisible = false;
            this.gv_Huellas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Huellas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Huellas.Size = new System.Drawing.Size(1133, 210);
            this.gv_Huellas.TabIndex = 3;
            this.gv_Huellas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Huellas_CellClick);
            this.gv_Huellas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Huellas_CellContentClick);
            this.gv_Huellas.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gv_Huellas_ColumnHeaderMouseClick);
            this.gv_Huellas.SelectionChanged += new System.EventHandler(this.gv_Huellas_SelectionChanged);
            // 
            // EsValido
            // 
            this.EsValido.HeaderText = "Es Valido";
            this.EsValido.Name = "EsValido";
            this.EsValido.Width = 63;
            // 
            // gv_PregYRes
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gv_PregYRes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.gv_PregYRes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_PregYRes.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_PregYRes.BackgroundColor = System.Drawing.Color.Snow;
            this.gv_PregYRes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PregYRes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_PregYRes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_PregYRes.EnableHeadersVisualStyles = false;
            this.gv_PregYRes.Location = new System.Drawing.Point(0, 334);
            this.gv_PregYRes.Name = "gv_PregYRes";
            this.gv_PregYRes.RowHeadersVisible = false;
            this.gv_PregYRes.Size = new System.Drawing.Size(1054, 144);
            this.gv_PregYRes.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(168, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Sucursal ";
            // 
            // cmbFecha
            // 
            this.cmbFecha.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFecha.FormattingEnabled = true;
            this.cmbFecha.Location = new System.Drawing.Point(20, 31);
            this.cmbFecha.Name = "cmbFecha";
            this.cmbFecha.Size = new System.Drawing.Size(121, 23);
            this.cmbFecha.TabIndex = 1;
            this.cmbFecha.SelectedIndexChanged += new System.EventHandler(this.cmbFecha_SelectedIndexChanged);
            // 
            // cmbSucursal
            // 
            this.cmbSucursal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSucursal.FormattingEnabled = true;
            this.cmbSucursal.Location = new System.Drawing.Point(171, 31);
            this.cmbSucursal.Name = "cmbSucursal";
            this.cmbSucursal.Size = new System.Drawing.Size(121, 23);
            this.cmbSucursal.TabIndex = 2;
            this.cmbSucursal.SelectedIndexChanged += new System.EventHandler(this.cmbSucursal_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fecha ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 513);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cliente";
            // 
            // lblMovID
            // 
            this.lblMovID.AutoSize = true;
            this.lblMovID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMovID.Location = new System.Drawing.Point(1120, 513);
            this.lblMovID.Name = "lblMovID";
            this.lblMovID.Size = new System.Drawing.Size(42, 15);
            this.lblMovID.TabIndex = 4;
            this.lblMovID.Text = "MovID";
            // 
            // lblMov
            // 
            this.lblMov.AutoSize = true;
            this.lblMov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMov.Location = new System.Drawing.Point(935, 513);
            this.lblMov.Name = "lblMov";
            this.lblMov.Size = new System.Drawing.Size(29, 15);
            this.lblMov.TabIndex = 5;
            this.lblMov.Text = "Mov";
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Guardar.Image")));
            this.btn_Guardar.Location = new System.Drawing.Point(2, 12);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(71, 77);
            this.btn_Guardar.TabIndex = 5;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // btn_refrescar
            // 
            this.btn_refrescar.BackColor = System.Drawing.Color.White;
            this.btn_refrescar.FlatAppearance.BorderSize = 0;
            this.btn_refrescar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_refrescar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refrescar.Image = ((System.Drawing.Image)(resources.GetObject("btn_refrescar.Image")));
            this.btn_refrescar.Location = new System.Drawing.Point(1, 95);
            this.btn_refrescar.Name = "btn_refrescar";
            this.btn_refrescar.Size = new System.Drawing.Size(72, 71);
            this.btn_refrescar.TabIndex = 6;
            this.btn_refrescar.Text = "Refrescar (F5)";
            this.btn_refrescar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_refrescar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_refrescar.UseVisualStyleBackColor = false;
            this.btn_refrescar.Click += new System.EventHandler(this.btn_refrescar_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(12, 443);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(61, 67);
            this.btn_ayuda.TabIndex = 10;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            this.btn_ayuda.Click += new System.EventHandler(this.btn_ayuda_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(2, 377);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(85, 60);
            this.btn_Regresar.TabIndex = 9;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_DIMAafil
            // 
            this.btn_DIMAafil.BackColor = System.Drawing.Color.White;
            this.btn_DIMAafil.FlatAppearance.BorderSize = 0;
            this.btn_DIMAafil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DIMAafil.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DIMAafil.Image = ((System.Drawing.Image)(resources.GetObject("btn_DIMAafil.Image")));
            this.btn_DIMAafil.Location = new System.Drawing.Point(2, 296);
            this.btn_DIMAafil.Name = "btn_DIMAafil";
            this.btn_DIMAafil.Size = new System.Drawing.Size(83, 75);
            this.btn_DIMAafil.TabIndex = 12;
            this.btn_DIMAafil.Text = "Ver DIMA afiliador";
            this.btn_DIMAafil.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_DIMAafil.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_DIMAafil.UseVisualStyleBackColor = false;
            this.btn_DIMAafil.Click += new System.EventHandler(this.btn_DIMAafil_Click);
            // 
            // btnHistorico
            // 
            this.btnHistorico.BackColor = System.Drawing.Color.White;
            this.btnHistorico.FlatAppearance.BorderSize = 0;
            this.btnHistorico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHistorico.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistorico.Image = ((System.Drawing.Image)(resources.GetObject("btnHistorico.Image")));
            this.btnHistorico.Location = new System.Drawing.Point(-1, 238);
            this.btnHistorico.Name = "btnHistorico";
            this.btnHistorico.Size = new System.Drawing.Size(83, 60);
            this.btnHistorico.TabIndex = 13;
            this.btnHistorico.Text = "Imagenes Hist";
            this.btnHistorico.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHistorico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnHistorico.UseVisualStyleBackColor = false;
            this.btnHistorico.Click += new System.EventHandler(this.btnHistorico_Click);
            // 
            // RegistroDeHuellaCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1247, 533);
            this.Controls.Add(this.btnHistorico);
            this.Controls.Add(this.btn_DIMAafil);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.btn_ayuda);
            this.Controls.Add(this.btn_refrescar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.lblMov);
            this.Controls.Add(this.lblMovID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_Fotos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "RegistroDeHuellaCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro De Huella";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegistroDeHuellaCliente_FormClosing);
            this.Load += new System.EventHandler(this.RegistroDeHuellaCliente_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RegistroDeHuellaCliente_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Huellas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PregYRes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Fotos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbFecha;
        private System.Windows.Forms.ComboBox cmbSucursal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView gv_PregYRes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMovID;
        private System.Windows.Forms.Label lblMov;
        private System.Windows.Forms.DataGridView gv_Huellas;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Button btn_refrescar;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.DataGridViewCheckBoxColumn EsValido;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.Button btn_DIMAafil;
        private System.Windows.Forms.Button btnHistorico;
    }
}