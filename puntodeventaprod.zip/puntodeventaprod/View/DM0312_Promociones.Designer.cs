﻿namespace PuntoVenta.View
{
    partial class DM0312_Promociones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_Imagen1 = new System.Windows.Forms.Button();
            this.btn_Imagen2 = new System.Windows.Forms.Button();
            this.btn_Imagen3 = new System.Windows.Forms.Button();
            this.btn_Imagen4 = new System.Windows.Forms.Button();
            this.txt_Imagen1 = new System.Windows.Forms.TextBox();
            this.txt_Imagen2 = new System.Windows.Forms.TextBox();
            this.txt_Imagen3 = new System.Windows.Forms.TextBox();
            this.txt_Imagen4 = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox4VIU = new System.Windows.Forms.PictureBox();
            this.pictureBox3VIU = new System.Windows.Forms.PictureBox();
            this.pictureBox2VIU = new System.Windows.Forms.PictureBox();
            this.pictureBox1VIU = new System.Windows.Forms.PictureBox();
            this.txt_Imagen1VIU = new System.Windows.Forms.TextBox();
            this.txt_Imagen4VIU = new System.Windows.Forms.TextBox();
            this.lbl_Imagen1VIU = new System.Windows.Forms.Label();
            this.txt_Imagen3VIU = new System.Windows.Forms.TextBox();
            this.btn_Imagen4VIU = new System.Windows.Forms.Button();
            this.lbl_Imagen2VIU = new System.Windows.Forms.Label();
            this.btn_Imagen3VIU = new System.Windows.Forms.Button();
            this.txt_Imagen2VIU = new System.Windows.Forms.TextBox();
            this.lbl_Imagen4VIU = new System.Windows.Forms.Label();
            this.btn_Imagen1VIU = new System.Windows.Forms.Button();
            this.lbl_Imagen3VIU = new System.Windows.Forms.Label();
            this.btn_Imagen2VIU = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4VIU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3VIU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2VIU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1VIU)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(74, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "IMAGEN 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(74, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "IMAGEN 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(74, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMAGEN 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(74, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "IMAGEN 4";
            // 
            // btn_Imagen1
            // 
            this.btn_Imagen1.Location = new System.Drawing.Point(392, 38);
            this.btn_Imagen1.Name = "btn_Imagen1";
            this.btn_Imagen1.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen1.TabIndex = 4;
            this.btn_Imagen1.Text = "   . . .";
            this.btn_Imagen1.UseVisualStyleBackColor = true;
            this.btn_Imagen1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Imagen2
            // 
            this.btn_Imagen2.Location = new System.Drawing.Point(392, 100);
            this.btn_Imagen2.Name = "btn_Imagen2";
            this.btn_Imagen2.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen2.TabIndex = 5;
            this.btn_Imagen2.Text = "  . . .";
            this.btn_Imagen2.UseVisualStyleBackColor = true;
            this.btn_Imagen2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_Imagen3
            // 
            this.btn_Imagen3.Location = new System.Drawing.Point(392, 158);
            this.btn_Imagen3.Name = "btn_Imagen3";
            this.btn_Imagen3.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen3.TabIndex = 6;
            this.btn_Imagen3.Text = "  . . .";
            this.btn_Imagen3.UseVisualStyleBackColor = true;
            this.btn_Imagen3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_Imagen4
            // 
            this.btn_Imagen4.Location = new System.Drawing.Point(392, 217);
            this.btn_Imagen4.Name = "btn_Imagen4";
            this.btn_Imagen4.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen4.TabIndex = 7;
            this.btn_Imagen4.Text = " . . .";
            this.btn_Imagen4.UseVisualStyleBackColor = true;
            this.btn_Imagen4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txt_Imagen1
            // 
            this.txt_Imagen1.AccessibleName = "";
            this.txt_Imagen1.Location = new System.Drawing.Point(175, 40);
            this.txt_Imagen1.Name = "txt_Imagen1";
            this.txt_Imagen1.ReadOnly = true;
            this.txt_Imagen1.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen1.TabIndex = 8;
            // 
            // txt_Imagen2
            // 
            this.txt_Imagen2.AccessibleName = "";
            this.txt_Imagen2.Location = new System.Drawing.Point(175, 103);
            this.txt_Imagen2.Name = "txt_Imagen2";
            this.txt_Imagen2.ReadOnly = true;
            this.txt_Imagen2.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen2.TabIndex = 9;
            // 
            // txt_Imagen3
            // 
            this.txt_Imagen3.AccessibleName = "";
            this.txt_Imagen3.Location = new System.Drawing.Point(175, 161);
            this.txt_Imagen3.Name = "txt_Imagen3";
            this.txt_Imagen3.ReadOnly = true;
            this.txt_Imagen3.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen3.TabIndex = 10;
            // 
            // txt_Imagen4
            // 
            this.txt_Imagen4.AccessibleName = "";
            this.txt_Imagen4.Location = new System.Drawing.Point(175, 220);
            this.txt_Imagen4.Name = "txt_Imagen4";
            this.txt_Imagen4.ReadOnly = true;
            this.txt_Imagen4.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen4.TabIndex = 11;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Location = new System.Drawing.Point(51, 48);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(692, 386);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.pictureBox3);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.txt_Imagen1);
            this.tabPage1.Controls.Add(this.txt_Imagen4);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txt_Imagen3);
            this.tabPage1.Controls.Add(this.btn_Imagen4);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btn_Imagen3);
            this.tabPage1.Controls.Add(this.txt_Imagen2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.btn_Imagen1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.btn_Imagen2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(684, 360);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "MA";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(509, 195);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4.TabIndex = 32;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(509, 139);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(509, 83);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(509, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage2.Controls.Add(this.pictureBox4VIU);
            this.tabPage2.Controls.Add(this.pictureBox3VIU);
            this.tabPage2.Controls.Add(this.pictureBox2VIU);
            this.tabPage2.Controls.Add(this.pictureBox1VIU);
            this.tabPage2.Controls.Add(this.txt_Imagen1VIU);
            this.tabPage2.Controls.Add(this.txt_Imagen4VIU);
            this.tabPage2.Controls.Add(this.lbl_Imagen1VIU);
            this.tabPage2.Controls.Add(this.txt_Imagen3VIU);
            this.tabPage2.Controls.Add(this.btn_Imagen4VIU);
            this.tabPage2.Controls.Add(this.lbl_Imagen2VIU);
            this.tabPage2.Controls.Add(this.btn_Imagen3VIU);
            this.tabPage2.Controls.Add(this.txt_Imagen2VIU);
            this.tabPage2.Controls.Add(this.lbl_Imagen4VIU);
            this.tabPage2.Controls.Add(this.btn_Imagen1VIU);
            this.tabPage2.Controls.Add(this.lbl_Imagen3VIU);
            this.tabPage2.Controls.Add(this.btn_Imagen2VIU);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(684, 360);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "VIU";
            // 
            // pictureBox4VIU
            // 
            this.pictureBox4VIU.Location = new System.Drawing.Point(532, 211);
            this.pictureBox4VIU.Name = "pictureBox4VIU";
            this.pictureBox4VIU.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4VIU.TabIndex = 28;
            this.pictureBox4VIU.TabStop = false;
            this.pictureBox4VIU.Click += new System.EventHandler(this.pictureBox4VIU_Click);
            // 
            // pictureBox3VIU
            // 
            this.pictureBox3VIU.Location = new System.Drawing.Point(532, 155);
            this.pictureBox3VIU.Name = "pictureBox3VIU";
            this.pictureBox3VIU.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3VIU.TabIndex = 27;
            this.pictureBox3VIU.TabStop = false;
            this.pictureBox3VIU.Click += new System.EventHandler(this.pictureBox3VIU_Click);
            // 
            // pictureBox2VIU
            // 
            this.pictureBox2VIU.Location = new System.Drawing.Point(532, 99);
            this.pictureBox2VIU.Name = "pictureBox2VIU";
            this.pictureBox2VIU.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2VIU.TabIndex = 26;
            this.pictureBox2VIU.TabStop = false;
            this.pictureBox2VIU.Click += new System.EventHandler(this.pictureBox2VIU_Click);
            // 
            // pictureBox1VIU
            // 
            this.pictureBox1VIU.Location = new System.Drawing.Point(532, 43);
            this.pictureBox1VIU.Name = "pictureBox1VIU";
            this.pictureBox1VIU.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1VIU.TabIndex = 25;
            this.pictureBox1VIU.TabStop = false;
            this.pictureBox1VIU.Click += new System.EventHandler(this.pictureBox1VIU_Click);
            // 
            // txt_Imagen1VIU
            // 
            this.txt_Imagen1VIU.AccessibleName = "";
            this.txt_Imagen1VIU.Location = new System.Drawing.Point(193, 53);
            this.txt_Imagen1VIU.Name = "txt_Imagen1VIU";
            this.txt_Imagen1VIU.ReadOnly = true;
            this.txt_Imagen1VIU.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen1VIU.TabIndex = 20;
            // 
            // txt_Imagen4VIU
            // 
            this.txt_Imagen4VIU.AccessibleName = "";
            this.txt_Imagen4VIU.Location = new System.Drawing.Point(193, 233);
            this.txt_Imagen4VIU.Name = "txt_Imagen4VIU";
            this.txt_Imagen4VIU.ReadOnly = true;
            this.txt_Imagen4VIU.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen4VIU.TabIndex = 23;
            // 
            // lbl_Imagen1VIU
            // 
            this.lbl_Imagen1VIU.AutoSize = true;
            this.lbl_Imagen1VIU.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Imagen1VIU.Location = new System.Drawing.Point(92, 60);
            this.lbl_Imagen1VIU.Name = "lbl_Imagen1VIU";
            this.lbl_Imagen1VIU.Size = new System.Drawing.Size(66, 13);
            this.lbl_Imagen1VIU.TabIndex = 12;
            this.lbl_Imagen1VIU.Text = "IMAGEN 1";
            // 
            // txt_Imagen3VIU
            // 
            this.txt_Imagen3VIU.AccessibleName = "";
            this.txt_Imagen3VIU.Location = new System.Drawing.Point(193, 174);
            this.txt_Imagen3VIU.Name = "txt_Imagen3VIU";
            this.txt_Imagen3VIU.ReadOnly = true;
            this.txt_Imagen3VIU.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen3VIU.TabIndex = 22;
            // 
            // btn_Imagen4VIU
            // 
            this.btn_Imagen4VIU.Location = new System.Drawing.Point(410, 230);
            this.btn_Imagen4VIU.Name = "btn_Imagen4VIU";
            this.btn_Imagen4VIU.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen4VIU.TabIndex = 19;
            this.btn_Imagen4VIU.Text = "  . . . ";
            this.btn_Imagen4VIU.UseVisualStyleBackColor = true;
            this.btn_Imagen4VIU.Click += new System.EventHandler(this.button5_Click);
            // 
            // lbl_Imagen2VIU
            // 
            this.lbl_Imagen2VIU.AutoSize = true;
            this.lbl_Imagen2VIU.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Imagen2VIU.Location = new System.Drawing.Point(92, 124);
            this.lbl_Imagen2VIU.Name = "lbl_Imagen2VIU";
            this.lbl_Imagen2VIU.Size = new System.Drawing.Size(66, 13);
            this.lbl_Imagen2VIU.TabIndex = 13;
            this.lbl_Imagen2VIU.Text = "IMAGEN 2";
            // 
            // btn_Imagen3VIU
            // 
            this.btn_Imagen3VIU.Location = new System.Drawing.Point(410, 172);
            this.btn_Imagen3VIU.Name = "btn_Imagen3VIU";
            this.btn_Imagen3VIU.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen3VIU.TabIndex = 18;
            this.btn_Imagen3VIU.Text = "  . . .";
            this.btn_Imagen3VIU.UseVisualStyleBackColor = true;
            this.btn_Imagen3VIU.Click += new System.EventHandler(this.button6_Click);
            // 
            // txt_Imagen2VIU
            // 
            this.txt_Imagen2VIU.AccessibleName = "";
            this.txt_Imagen2VIU.Location = new System.Drawing.Point(193, 116);
            this.txt_Imagen2VIU.Name = "txt_Imagen2VIU";
            this.txt_Imagen2VIU.ReadOnly = true;
            this.txt_Imagen2VIU.Size = new System.Drawing.Size(220, 20);
            this.txt_Imagen2VIU.TabIndex = 21;
            // 
            // lbl_Imagen4VIU
            // 
            this.lbl_Imagen4VIU.AutoSize = true;
            this.lbl_Imagen4VIU.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Imagen4VIU.Location = new System.Drawing.Point(92, 236);
            this.lbl_Imagen4VIU.Name = "lbl_Imagen4VIU";
            this.lbl_Imagen4VIU.Size = new System.Drawing.Size(66, 13);
            this.lbl_Imagen4VIU.TabIndex = 15;
            this.lbl_Imagen4VIU.Text = "IMAGEN 4";
            // 
            // btn_Imagen1VIU
            // 
            this.btn_Imagen1VIU.Location = new System.Drawing.Point(410, 51);
            this.btn_Imagen1VIU.Name = "btn_Imagen1VIU";
            this.btn_Imagen1VIU.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen1VIU.TabIndex = 16;
            this.btn_Imagen1VIU.Text = "  . . .";
            this.btn_Imagen1VIU.UseVisualStyleBackColor = true;
            this.btn_Imagen1VIU.Click += new System.EventHandler(this.button7_Click);
            // 
            // lbl_Imagen3VIU
            // 
            this.lbl_Imagen3VIU.AutoSize = true;
            this.lbl_Imagen3VIU.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Imagen3VIU.Location = new System.Drawing.Point(92, 181);
            this.lbl_Imagen3VIU.Name = "lbl_Imagen3VIU";
            this.lbl_Imagen3VIU.Size = new System.Drawing.Size(66, 13);
            this.lbl_Imagen3VIU.TabIndex = 14;
            this.lbl_Imagen3VIU.Text = "IMAGEN 3";
            // 
            // btn_Imagen2VIU
            // 
            this.btn_Imagen2VIU.Location = new System.Drawing.Point(410, 113);
            this.btn_Imagen2VIU.Name = "btn_Imagen2VIU";
            this.btn_Imagen2VIU.Size = new System.Drawing.Size(75, 23);
            this.btn_Imagen2VIU.TabIndex = 17;
            this.btn_Imagen2VIU.Text = "  . . . ";
            this.btn_Imagen2VIU.UseVisualStyleBackColor = true;
            this.btn_Imagen2VIU.Click += new System.EventHandler(this.button8_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(55, 4);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(688, 38);
            this.txt_Comentarios.TabIndex = 105;
            // 
            // DM0312_Promociones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(786, 468);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.tabControl1);
            this.Name = "DM0312_Promociones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Promociones";
            this.Load += new System.EventHandler(this.DM0312_Promociones_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4VIU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3VIU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2VIU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1VIU)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_Imagen1;
        private System.Windows.Forms.Button btn_Imagen2;
        private System.Windows.Forms.Button btn_Imagen3;
        private System.Windows.Forms.Button btn_Imagen4;
        private System.Windows.Forms.TextBox txt_Imagen1;
        private System.Windows.Forms.TextBox txt_Imagen2;
        private System.Windows.Forms.TextBox txt_Imagen3;
        private System.Windows.Forms.TextBox txt_Imagen4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txt_Imagen1VIU;
        private System.Windows.Forms.TextBox txt_Imagen4VIU;
        private System.Windows.Forms.Label lbl_Imagen1VIU;
        private System.Windows.Forms.TextBox txt_Imagen3VIU;
        private System.Windows.Forms.Button btn_Imagen4VIU;
        private System.Windows.Forms.Label lbl_Imagen2VIU;
        private System.Windows.Forms.Button btn_Imagen3VIU;
        private System.Windows.Forms.TextBox txt_Imagen2VIU;
        private System.Windows.Forms.Label lbl_Imagen4VIU;
        private System.Windows.Forms.Button btn_Imagen1VIU;
        private System.Windows.Forms.Label lbl_Imagen3VIU;
        private System.Windows.Forms.Button btn_Imagen2VIU;
        private System.Windows.Forms.PictureBox pictureBox4VIU;
        private System.Windows.Forms.PictureBox pictureBox3VIU;
        private System.Windows.Forms.PictureBox pictureBox2VIU;
        private System.Windows.Forms.PictureBox pictureBox1VIU;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txt_Comentarios;
    }
}