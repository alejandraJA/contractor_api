﻿
namespace PuntoVenta.View
{
    partial class frmVisorImagenes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnGirarD = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnPictureBox = new System.Windows.Forms.Panel();
            this.pbImagen = new System.Windows.Forms.PictureBox();
            this.btnRechazar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnGirarI = new System.Windows.Forms.Button();
            this.btnZoomMenos = new System.Windows.Forms.Button();
            this.btnZoomMas = new System.Windows.Forms.Button();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnPictureBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(812, 62);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnRechazar, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnAceptar, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(169, 56);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnGirarD, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnGirarI, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(543, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(170, 56);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // btnGirarD
            // 
            this.btnGirarD.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnGirarD.Image = global::PuntoVenta.Properties.Resources.rotar_izq;
            this.btnGirarD.Location = new System.Drawing.Point(88, 21);
            this.btnGirarD.Margin = new System.Windows.Forms.Padding(3, 3, 49, 3);
            this.btnGirarD.Name = "btnGirarD";
            this.btnGirarD.Size = new System.Drawing.Size(33, 32);
            this.btnGirarD.TabIndex = 3;
            this.btnGirarD.UseVisualStyleBackColor = true;
            this.btnGirarD.Click += new System.EventHandler(this.btnGirarD_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.btnZoomMenos, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.btnZoomMas, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(273, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(169, 56);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.49215F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(818, 68);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pnPictureBox
            // 
            this.pnPictureBox.AutoScroll = true;
            this.pnPictureBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnPictureBox.Controls.Add(this.pbImagen);
            this.pnPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnPictureBox.Location = new System.Drawing.Point(0, 68);
            this.pnPictureBox.Name = "pnPictureBox";
            this.pnPictureBox.Size = new System.Drawing.Size(818, 531);
            this.pnPictureBox.TabIndex = 1;
            // 
            // pbImagen
            // 
            this.pbImagen.Location = new System.Drawing.Point(12, 6);
            this.pbImagen.Name = "pbImagen";
            this.pbImagen.Size = new System.Drawing.Size(794, 513);
            this.pbImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImagen.TabIndex = 0;
            this.pbImagen.TabStop = false;
            this.pbImagen.LoadCompleted += new System.ComponentModel.AsyncCompletedEventHandler(this.pbImagen_LoadCompleted);
            this.pbImagen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbImagen_MouseDown);
            this.pbImagen.MouseEnter += new System.EventHandler(this.pbImagen_MouseEnter);
            this.pbImagen.MouseLeave += new System.EventHandler(this.pbImagen_MouseLeave);
            this.pbImagen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbImagen_MouseMove);
            // 
            // btnRechazar
            // 
            this.btnRechazar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnRechazar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRechazar.Image = global::PuntoVenta.Properties.Resources.cancelar;
            this.btnRechazar.Location = new System.Drawing.Point(87, 21);
            this.btnRechazar.Margin = new System.Windows.Forms.Padding(3, 3, 49, 3);
            this.btnRechazar.Name = "btnRechazar";
            this.btnRechazar.Size = new System.Drawing.Size(33, 32);
            this.btnRechazar.TabIndex = 2;
            this.btnRechazar.UseVisualStyleBackColor = true;
            this.btnRechazar.Click += new System.EventHandler(this.btnRechazar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Image = global::PuntoVenta.Properties.Resources.comprobar;
            this.btnAceptar.Location = new System.Drawing.Point(49, 21);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(49, 3, 3, 3);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(32, 32);
            this.btnAceptar.TabIndex = 1;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnGirarI
            // 
            this.btnGirarI.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnGirarI.Image = global::PuntoVenta.Properties.Resources.actualizar;
            this.btnGirarI.Location = new System.Drawing.Point(49, 21);
            this.btnGirarI.Margin = new System.Windows.Forms.Padding(49, 3, 3, 3);
            this.btnGirarI.Name = "btnGirarI";
            this.btnGirarI.Size = new System.Drawing.Size(33, 32);
            this.btnGirarI.TabIndex = 2;
            this.btnGirarI.UseVisualStyleBackColor = true;
            this.btnGirarI.Click += new System.EventHandler(this.btnGirarI_Click);
            // 
            // btnZoomMenos
            // 
            this.btnZoomMenos.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnZoomMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZoomMenos.Image = global::PuntoVenta.Properties.Resources.zoom_out;
            this.btnZoomMenos.Location = new System.Drawing.Point(87, 21);
            this.btnZoomMenos.Margin = new System.Windows.Forms.Padding(3, 3, 49, 3);
            this.btnZoomMenos.Name = "btnZoomMenos";
            this.btnZoomMenos.Size = new System.Drawing.Size(33, 32);
            this.btnZoomMenos.TabIndex = 3;
            this.btnZoomMenos.UseVisualStyleBackColor = true;
            this.btnZoomMenos.Click += new System.EventHandler(this.btnZoomMenos_Click);
            // 
            // btnZoomMas
            // 
            this.btnZoomMas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnZoomMas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZoomMas.Image = global::PuntoVenta.Properties.Resources.zoom_in;
            this.btnZoomMas.Location = new System.Drawing.Point(49, 21);
            this.btnZoomMas.Margin = new System.Windows.Forms.Padding(49, 3, 3, 3);
            this.btnZoomMas.Name = "btnZoomMas";
            this.btnZoomMas.Size = new System.Drawing.Size(32, 32);
            this.btnZoomMas.TabIndex = 2;
            this.btnZoomMas.UseVisualStyleBackColor = true;
            this.btnZoomMas.Click += new System.EventHandler(this.btnZoomMas_Click);
            // 
            // frmVisorImagenes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 599);
            this.Controls.Add(this.pnPictureBox);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.Name = "frmVisorImagenes";
            this.Text = "frmVisorImagenes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVisorImagenes_FormClosing);
            this.Load += new System.EventHandler(this.frmVisorImagenes_Load);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pnPictureBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnRechazar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btnGirarD;
        private System.Windows.Forms.Button btnGirarI;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button btnZoomMenos;
        private System.Windows.Forms.Button btnZoomMas;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel pnPictureBox;
        private System.Windows.Forms.PictureBox pbImagen;
    }
}