﻿//-FlujoMonedero

using System;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_LoginCancelacion : Form
    {
        private readonly DM0312__CLoginCancelacion controller = new DM0312__CLoginCancelacion();

        public DM0312_LoginCancelacion()
        {
            InitializeComponent();
        }

        ~DM0312_LoginCancelacion()
        {
            GC.Collect();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            login();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DM0312_LoginCancelacion_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();

            if (e.Control && e.KeyCode == Keys.G) login();
        }


        private void txt_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txt_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13) txt_password.Focus();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void login()
        {
            string usuario = txt_usuario.Text;
            string password = txt_password.Text;

            if (controller.LoginCancelacion(usuario, password))
            {
                if (controller.PermisosCancelacion(usuario))
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("El usuario no tiene permisos para cancelar el movimiento.", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Usuario y/o contraseña incorrecta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
    }
}