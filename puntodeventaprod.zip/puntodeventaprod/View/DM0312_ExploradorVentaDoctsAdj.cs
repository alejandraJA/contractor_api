﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class DM0312_ExploradorVentaDoctsAdj : Form
    {
        public int i = 0;
        public List<Image> ListaImagenes = new List<Image>();

        public DM0312_ExploradorVentaDoctsAdj()
        {
            InitializeComponent();
        }

        ~DM0312_ExploradorVentaDoctsAdj()
        {
            GC.Collect();
        }

        private void DM0312_ExploradorVentaDoctsAdj_Load(object sender, EventArgs e)
        {
            LlenarList();
        }

        public void LlenarList()
        {
            foreach (Image i in ListaImagenes) imageList.Images.Add(i);

            ListViewImage.View = System.Windows.Forms.View.LargeIcon;

            imageList.ImageSize = new Size(256, 256);

            ListViewImage.LargeImageList = imageList;

            for (int j = 0; j < imageList.Images.Count; j++)
            {
                ListViewItem item = new ListViewItem();

                item.ImageIndex = j;

                ListViewImage.Items.Add(item);
            }
        }

        private void ListViewImage_Click(object sender, EventArgs e)
        {
            Image img = null;
            ListViewItem item = ListViewImage.SelectedItems[0];

            int index = item.ImageIndex;

            img = imageList.Images[index];


            DM0312_ExploradorVentaRegistroFoto frm = new DM0312_ExploradorVentaRegistroFoto();

            Image image;
            int Width = 0;
            int Height = 0;
            Width = img.Width * 2;
            Height = img.Height * 2;
            if (ClaseEstatica.FormActivo == "InformacionCliente")
            {
                frm.Width = Width + 10;
                frm.Height = Height + 40;
            }
            else
            {
                frm.Width = Width;
                frm.Height = Height;
            }

            image = scaleImage(img, Width, Height);
            frm.Imagen = image;
            frm.ShowDialog();
        }

        private void ListViewImage_ItemActivate(object sender, EventArgs e)
        {
        }

        public Image scaleImage(Image img, int Width, int Height)
        {
            using (img)
            {
                double xRatio = (double)img.Width / Width;
                double yRatio = (double)img.Height / Height;
                double ratio = Math.Max(xRatio, yRatio);
                int nnx = (int)Math.Floor(img.Width / ratio);
                int nny = (int)Math.Floor(img.Height / ratio);
                Bitmap cpy = new Bitmap(nnx, nny, PixelFormat.Format32bppArgb);
                using (Graphics gr = Graphics.FromImage(cpy))
                {
                    gr.Clear(Color.Transparent);

                    gr.InterpolationMode = InterpolationMode.HighQualityBicubic;

                    gr.DrawImage(img,
                        new Rectangle(0, 0, nnx, nny),
                        new Rectangle(0, 0, img.Width, img.Height),
                        GraphicsUnit.Pixel);
                }

                return cpy;
            }
        }

        private void DM0312_ExploradorVentaDoctsAdj_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }
    }
}