﻿using System;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class frmEventoReactivacion : Form
    {
        private bool accion;
        private string agente;
        private readonly EventoController eventoC = new EventoController();
        private readonly DM0312_MExploradorVenta modeloVenta;
        private bool ReactivaUsr = false;
        private int recibeMensaje;

        public frmEventoReactivacion(DM0312_MExploradorVenta ModeloVenta)
        {
            InitializeComponent();
            modeloVenta = ModeloVenta;
            lbl_Mov.Text = "Movimiento : " + modeloVenta.Mov;
            lbl_Cliente.Text = "Cliente : " + modeloVenta.Cliente + " " + modeloVenta.Nombre;
            lbl_MovID.Text = "MovID : " + modeloVenta.MovId;
            agente = modeloVenta.Agente;
        }

        ~frmEventoReactivacion()
        {
            GC.Collect();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            //Dispose();
            escAction();
        }

        private void frmEventoReactivacion_KeyDown(object sender, KeyEventArgs e)
        {
            /*if (e.Modifiers == Keys.Control && e.KeyCode == Keys.N) {
                MessageBox.Show("paso");
            }*/
            if (e.KeyCode == Keys.Escape) escAction();
            //Dispose();
        }

        private void escAction()
        {
            if (accion)
            {
                if (DialogResult.Yes ==
                    MessageBox.Show("Se perderán los avances ¿Estás seguro de salir?", "Confirmación",
                        MessageBoxButtons.YesNo))
                {
                    showMainButtons(true);
                    showEventButtons(false);
                    accion = false;
                }
            }
            else
            {
                Dispose();
                DM0312_ExploradorVentas.EjecutaEvento = true;
            }
        }

        private void btn_reactivacion_Click(object sender, EventArgs e)
        {
            accion = true;

            showMainButtons(false);
            showEventButtons(true);
        }

        private void showEventButtons(bool show)
        {
            lbl_msgReactivacion.Visible = show;
            btn_liberacion.Visible = show;
            btn_complemento.Visible = show;

            accion = true;

            Text = show ? "Reactivación" : Text;
        }

        private void showMainButtons(bool show)
        {
            lbl_reactivacion.Visible = show;
            lbl_reanalisis.Visible = show;
            lbl_fechaSeguimiento.Visible = show;
            btn_reactivacion.Visible = show;
            btn_reanalisis.Visible = show;
            btn_fechaSeguimiento.Visible = show;

            accion = false;

            Text = show ? "Reactivación / Seguimiento / Reanálisis" : Text;
        }

        private void AddEventUser()
        {
            accesoPorNomina();
        }

        private void agregarEvento(string nomina)
        {
            Visible = false;
            using (DM0312_AgregarEvento agregaEvento = new DM0312_AgregarEvento())
            {
                agregaEvento.recibeIdVenta = modeloVenta.ID.ToString();
                agregaEvento.recibeUsuario = modeloVenta.Usuario;
                agregaEvento.recibeSucursal = modeloVenta.Sucursal.ToString();
                agregaEvento.recibeEstatus = modeloVenta.Estatus;
                agregaEvento.recibeMovId = modeloVenta.MovId;
                agregaEvento.recibeMov = modeloVenta.Mov;
                agregaEvento.recibeSituacion = modeloVenta.Situacion;
                agregaEvento.recibeCliente = modeloVenta.Cliente;

                agregaEvento.iCanalVenta = int.Parse(modeloVenta.EnviarA);
                agregaEvento.recibeIdecommerce = modeloVenta.IDEcommerce;
                agregaEvento.recibeMensaje = recibeMensaje;

                agregaEvento.agente = nomina;

                agregaEvento.ShowDialog();
            }

            Visible = true;
        }

        private void btn_liberacion_Click(object sender, EventArgs e)
        {
            recibeMensaje = 4;
            AddEventUser();
        }

        private void btn_complemento_Click(object sender, EventArgs e)
        {
            recibeMensaje = 5;
            AddEventUser();
        }

        private void btn_fechaSeguimiento_Click(object sender, EventArgs e)
        {
            if (eventoC.getStdMAXCITAS() > eventoC.getCantidadDeCitas(modeloVenta.ID))
            {
                recibeMensaje = 6;
                AddEventUser();
            }
            else
            {
                MessageBox.Show("No es posible generar más citas. Excede al parámetro configurado");
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "frmEventoReactivacion")
                        forma.Close();
            }
        }

        private void btn_reanalisis_Click(object sender, EventArgs e)
        {
            recibeMensaje = 7;
            AddEventUser();
        }

        public void accesoPorNomina()
        {
            bool result = false;
            using (Form form = new Form())
            {
                // 
                // Acceso Nomina
                // 
                form.AutoScaleDimensions = new SizeF(6F, 13F);
                form.AutoScaleMode = AutoScaleMode.Font;
                form.ClientSize = new Size(170, 170);
                form.MaximumSize = new Size(170, 170);
                form.MinimumSize = new Size(170, 170);

                form.MaximizeBox = false;
                form.MinimizeBox = false;
                form.Name = "Acceso Nomina";
                form.ShowIcon = false;
                form.ShowInTaskbar = false;
                form.StartPosition = FormStartPosition.CenterScreen;
                form.Text = "Login";

                Label lbl_Nomina;
                TextBox textBox1;
                TextBox textBox2;
                Label lbl_contrasenia;
                Button btn_aceptar = new Button();

                lbl_Nomina = new Label();
                textBox1 = new TextBox();
                textBox2 = new TextBox();
                lbl_contrasenia = new Label();
                SuspendLayout();
                // 
                // lbl_Nomina
                // 
                lbl_Nomina.Location = new Point(12, 9);
                lbl_Nomina.Name = "lbl_Nomina";
                lbl_Nomina.Size = new Size(129, 20);
                lbl_Nomina.TabIndex = 0;
                lbl_Nomina.Text = "Nomina";
                lbl_Nomina.TextAlign = ContentAlignment.MiddleLeft;
                // 
                // textBox1
                // 
                textBox1.Location = new Point(12, 32);
                textBox1.Name = "textBox1";
                textBox1.Size = new Size(129, 20);
                textBox1.TabIndex = 1;
                // 
                // textBox2
                // 
                textBox2.Location = new Point(12, 78);
                textBox2.Name = "textBox2";
                textBox2.Size = new Size(129, 20);
                textBox2.TabIndex = 3;
                textBox2.PasswordChar = '*';
                // 
                // lbl_contrasenia
                // 
                lbl_contrasenia.Location = new Point(12, 55);
                lbl_contrasenia.Name = "lbl_contrasenia";
                lbl_contrasenia.Size = new Size(129, 20);
                lbl_contrasenia.TabIndex = 2;
                lbl_contrasenia.Text = "Contraseña";
                lbl_contrasenia.TextAlign = ContentAlignment.MiddleLeft;
                // 
                // btn_aceptar
                // 
                btn_aceptar.Location = new Point(12, 104);
                btn_aceptar.Name = "btn_aceptar";
                btn_aceptar.Size = new Size(129, 20);
                btn_aceptar.TabIndex = 4;
                btn_aceptar.Text = "Aceptar";
                btn_aceptar.UseVisualStyleBackColor = true;

                btn_aceptar.Click += (send, args) =>
                {
                    if (eventoC.accesoPorNomina(textBox1.Text, textBox2.Text))
                    {
                        form.Visible = false;
                        agregarEvento(textBox1.Text.ToUpper());
                    }
                    else
                    {
                        MessageBox.Show("Nómina o contraseña incorrecto");
                    }
                };

                form.Controls.Add(lbl_Nomina);
                form.Controls.Add(textBox1);
                form.Controls.Add(lbl_contrasenia);
                form.Controls.Add(textBox2);
                form.Controls.Add(btn_aceptar);

                ResumeLayout(false);
                PerformLayout();
                form.ShowDialog();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void frmEventoReactivacion_Load(object sender, EventArgs e)
        {
            btn_reanalisis.Visible = eventoC.ValidarPermiso();
            lbl_reanalisis.Visible = eventoC.ValidarPermiso();
        }
    }
}