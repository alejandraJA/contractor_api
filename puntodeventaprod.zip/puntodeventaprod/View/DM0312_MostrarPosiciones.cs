﻿using System;
using System.Windows.Forms;

namespace PuntoVenta.View
{
    public partial class DM0312_MostrarPosiciones : Form
    {
        public DM0312_MostrarPosiciones()
        {
            StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
        }

        ~DM0312_MostrarPosiciones()
        {
            GC.Collect();
        }

        private void DM0312_MostrarPosiciones_Load(object sender, EventArgs e)
        {
        }

        private void DM0312_MostrarPosiciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }
    }
}