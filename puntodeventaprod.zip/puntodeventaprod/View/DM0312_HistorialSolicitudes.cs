﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using SortOrder = System.Windows.Forms.SortOrder;

namespace PuntoVenta
{
    public partial class HistorialSolicitudes : Form
    {
        public int ColumnaAOrdenar = -1;
        public bool ColumnaOrden;
        private readonly CDetalleVenta controlDetalleVenta = new CDetalleVenta();
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        public DM0312_Loading_ frmLoading;
        private readonly Funciones funciones = new Funciones();
        private readonly CrtlHistorialSolicitudes historialSolicitudes = new CrtlHistorialSolicitudes();
        private int index;
        public List<string> ListaControles;
        public List<DM0312_MComentariosVenta> ListaHistorialComentario;
        private List<DM0312_MHistorialSolicitudes> ListaHistorialSolicitudes;
        private List<DM0312_MHistorialSolicitudes> listHistorial = new List<DM0312_MHistorialSolicitudes>();
        public DM0312_MHistorialSolicitudes ModelSeleccionadoHistorico;
        public string recibeCliente;
        public string recibeEstatus;
        public string recibeFecha;
        public string recibeFechaD;
        public string recibeMensajeCliente;
        public string recibeMensajeIdVenta;
        public string recibeMensajeUsuario;
        public string recibeMov;
        public string recibeMovId;
        public string recibeSituacion;
        public string recibeSucursal;
        private readonly string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        private bool validaAcceso;
        public bool validaFormEmpty = false;

        public HistorialSolicitudes()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            ListaHistorialSolicitudes = new List<DM0312_MHistorialSolicitudes>();
            ModelSeleccionadoHistorico = new DM0312_MHistorialSolicitudes();
            frmLoading = new DM0312_Loading_();
            ListaControles = new List<string>();
        }

        ~HistorialSolicitudes()
        {
            GC.Collect();
        }

        private void btn_CatalagoCalif_Click(object sender, EventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "CatalogoDeCalificaciones")
                {
                    forma.Close();
                    break;
                }

            CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
            catalogoCalificacion.Show();
        }

        #region "Methods"

        public void FillComboSituacion()
        {
            cbx_Situacion.Items.Clear();
            List<string> situaciones = new List<string>();
            situaciones = historialSolicitudes.ComboSituacion(this);
            if (situaciones.Count > 0 && cbx_movimiento.Text == "Analisis Credito")
            {
                cbx_Situacion.Items.Add("(Todos)");
                foreach (string data in situaciones) cbx_Situacion.Items.Add(data);
                cbx_Situacion.Text = "(Todos)";
            }
            else
            {
                cbx_Situacion.Items.Add("(Todos)");
                cbx_Situacion.Text = "(Todos)";
            }
        }

        public async void fillDataHistorialSolicitudes(string cliente)
        {
            string cuentaCliente = cliente;
            string shortDateA = recibeFecha;
            cbx_FechaA.Text = shortDateA;
            string mov = cbx_movimiento.Text;
            string situacion = cbx_Situacion.Text;
            string estatus = cbx_Estatus.Text;
            string fechaD = txt_FechaD.Text;
            string fechaA = dateTimePicker2.Text;
            string movId = "";
            string canal = cbx_Canal.Text;
            if (lbl_Buscar.Text == "")
                movId = "";
            else
                movId = lbl_Buscar.Text;

            if (fechaD == "") fechaD = "1900-01-01";
            string fechaDFinal = DateTime.Parse(fechaD).ToString("yyyy-MM-dd");
            string fechaAFinal = DateTime.Parse(fechaA).ToString("yyyy-MM-dd");
            if (!frmLoading.Visible)
            {
                frmLoading.Show(this);
                DesabilitarControles(false);
            }

            listHistorial = await Task.Run(() =>
                historialSolicitudes.LlenaDataGridHistorialSolicitudes(mov, situacion, estatus, fechaDFinal,
                    fechaAFinal, cuentaCliente, movId, canal));
            dgv_HistorialSolicitudes.DataSource =
                listHistorial.OrderByDescending(ordenar => ordenar.fechaAlta).ToList();
            dgv_HistorialSolicitudes.Columns["ImporteTotal"].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;

            if (frmLoading.Visible)
            {
                frmLoading.Hide();
                DesabilitarControles(true);
            }

            int height = 50;

            //1709
            if (ColumnaAOrdenar > -1)
            {
                dgv_HistorialSolicitudes.Columns[ColumnaAOrdenar].HeaderCell.SortGlyphDirection =
                    ColumnaOrden ? SortOrder.Ascending : SortOrder.Descending;
                OrdenerHistorialSolicitudes(ColumnaAOrdenar);
            }

            //if (usuarioVenta == "VENTP")
            //{
            //    foreach (DataGridViewRow item in dgv_HistorialSolicitudes.Rows)
            //    {
            //        if (height < 400)
            //            height += item.Height;
            //    }
            //    dgv_HistorialSolicitudes.Height = height + 10;
            //    groupBox3.Height = height + 200;
            //    groupBox4.Visible = false;
            //    groupBox1.Location = new Point(100, height + 160);
            //}
            //else
            //{
            groupBox1.Location = new Point(100, height + 400);
            //}

            txt_CuentaCliente.Select();
            validaAcceso = true;
            dgv_HistorialSolicitudes_SelectionChanged(null, null);
        }

        private void FillDataGridEventos()
        {
            if (dgv_HistorialSolicitudes.Rows.Count > 0)
            {
                string validaUsuario = ClaseEstatica.Usuario.Usser.Substring(0, 5);
                //if (validaUsuario != "VENTP")
                //{
                dgv_Eventos.DataSource = null;
                DataTable listEventos = new DataTable();
                listEventos =
                    historialSolicitudes.LlenaConsultarEventosHistorialSolicitudes(
                        Convert.ToString(ModelSeleccionadoHistorico.Id), ModelSeleccionadoHistorico.Mov);
                if (listEventos.Rows.Count > 0) dgv_Eventos.DataSource = listEventos;
                //groupBox4.Visible = false;
            }
        }

        private void DesabilitarControles(bool estado)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in Controls)
                    if (!item.Enabled)
                        ListaControles.Add(item.Name);
                    else
                        item.Enabled = estado;
            }
            else
            {
                foreach (Control item in Controls)
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
            }
        }

        /// <summary>
        ///     Metodo que permite llenar ComboBox Canal
        /// </summary>
        /// <returns>List<string></returns>
        /// Developer: Victor Avila
        /// Date:20/07/2017
        private void FillComboBoxCanal(string cliente)
        {
            List<int> canal = new List<int>();
            if (cliente != null) canal = historialSolicitudes.ComboCanalesVenta(cliente);

            foreach (int data in canal) cbx_Canal.Items.Add(data);
        }

        /// <summary>
        ///     Metodo que permite llenar ComboBox Estatus HistorialSolicitudes
        /// </summary>
        /// <returns>List<string></returns>
        /// Developer: Victor Avila
        /// Date:20/07/2017
        public List<string> LlenaComboBoxEstatus()
        {
            List<string> list = new List<string>();
            list.Add("Pendiente");
            list.Add("Cancelado");
            list.Add("Concluido");
            list.Add("SinAfectar");
            return list;
        }

        /// <summary>
        ///     Metodo que permite llenar ComboBox Movimiento HistorialSolicitudes
        /// </summary>
        /// <returns>List<string></returns>
        /// Developer: Victor Avila
        /// Date:20/07/2017
        public List<string> LlenaComboBoxMovimiento()
        {
            List<string> list = new List<string>();
            list.Add("Solicitud Credito");
            list.Add("Analisis Credito");
            return list;
        }

        /// <summary>
        ///     Llena comboBox Estatus
        /// </summary>
        /// <returns>List<string></returns>
        /// Developer: Victor Avila
        /// Date:20/07/2017
        public void Cbx_Estatus_FillCombo()
        {
            List<string> estatus = new List<string>();
            estatus = LlenaComboBoxEstatus();
            foreach (string data in estatus) cbx_Estatus.Items.Add(data);
        }

        /// <summary>
        ///     Llena combobox Movimiento
        /// </summary>
        /// <returns>List<string></returns>
        /// Developer: Victor Avila
        /// Date:20/07/2017
        public void Cbx_movimiento_FillCombo()
        {
            List<string> movimiento = new List<string>();
            movimiento = LlenaComboBoxMovimiento();
            foreach (string data in movimiento) cbx_movimiento.Items.Add(data);
        }

        private void CountTotal()
        {
            int totalSolicitud = listHistorial.Count(x => x.Mov == "Solicitud Credito");
            lbl_SolicitudCredito.Text = totalSolicitud + " Solicitud Credito";
            string totalSolicitudTotal = " $ " + listHistorial.Where(x => x.Mov == "Solicitud Credito")
                .Sum(x => Convert.ToDouble(x.Totalizador));
            lbl_SolicitudCreditoTotal.Text = Convert.ToString(totalSolicitudTotal);
            int totalAnalisis = listHistorial.Count(x => x.Mov == "Analisis Credito");
            lbl_AnalisisCredito.Text = totalAnalisis + " Analisis Credito";
            string totalAnalisisTotal = " $ " + listHistorial.Where(x => x.Mov == "Analisis Credito")
                .Sum(x => Convert.ToDouble(x.Totalizador));
            lbl_AnalisisCreditoTotal.Text = Convert.ToString(totalAnalisisTotal);
        }

        private void Busqueda()
        {
            if (txt_CuentaCliente.Text == "")
            {
                MessageBox.Show("Debe ingresar un cliente valido", "!!Mensaje", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                int validaCliente = historialSolicitudes.ValidaUsuario(txt_CuentaCliente.Text);
                if (validaCliente == 1)
                {
                    fillDataHistorialSolicitudes(txt_CuentaCliente.Text);
                    FillComboBoxCanal(txt_CuentaCliente.Text);
                    recibeMensajeCliente = txt_CuentaCliente.Text;
                    recibeCliente = txt_CuentaCliente.Text;
                }
                else
                {
                    MessageBox.Show("Cliente no valido, favor de verificar que sea el usuario correcto", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txt_CuentaCliente.Text = "";
                    txt_CuentaCliente.Focus();
                }
            }
        }

        private void OrdenerHistorialSolicitudes(int Columna)
        {
            List<object> TempObjects = new List<object>(listHistorial);
            funciones.OrderGridview(dgv_HistorialSolicitudes, Columna, TempObjects,
                listHistorial.GetType().GetGenericArguments().Single());
            if (ModelSeleccionadoHistorico.Mov != "" && ModelSeleccionadoHistorico.Id != 0)
            {
                FillDataGridEventos();

                CountTotal();
            }

            dgv_HistorialSolicitudes.Columns["ImporteTotal"].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;
            dgv_HistorialSolicitudes.Columns["FechaAlta"].DefaultCellStyle.Format = "dd/MM/yyyy";
            dgv_HistorialSolicitudes.Columns["fechaAlta"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            if (dgv_Eventos.Rows.Count > 0)
                groupBox4.Visible = true;
            else
                groupBox4.Visible = false;
        }

        #endregion

        #region "Handles"

        private void HistorialSolicitudes_Load(object sender, EventArgs e)
        {
            label10.Visible = false;
            Sucursal.Visible = false;
            label12.Visible = false;
            Act1.Visible = false;
            Act2.Visible = false;
            Act3.Visible = false;

            txt_ComentarioAyuda.Text = "HISTORIAL COMPLETO DEL CLIENTE";
            if (validaFormEmpty)
            {
                //if (usuarioVenta == "VENTP")
                //{
                //    btn_Eventos.Visible = false;
                //}
                lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
                KeyPreview = true;
                dateTimePicker2.Text = recibeFecha;
                txt_FechaD.Text = "";
                // SE OBTIENE LOS COMENTARIOS DE LOS COMPONENTES
                ListaHistorialComentario = Funciones.ConsultaComentario("Historial de Solicitudes");

                Cbx_movimiento_FillCombo();
                Cbx_Estatus_FillCombo();
                FillComboBoxCanal(recibeCliente);
                cbx_movimiento.Text = "(Todos)";
                cbx_Estatus.Text = "(Todos)";
                cbx_Situacion.Text = "(Todos)";
                cbx_Canal.Text = "(Todos)";
                toolTip1.SetToolTip(btn_Refrescar, "Refrescar");
                toolTip1.SetToolTip(btn_Eventos, "Eventos, Notas y Citas");
                toolTip1.SetToolTip(btn_UsuariosTiempos, "Usuarios y Tiempos");
                toolTip1.SetToolTip(btn_PosMov, "Posicion del Movimiento");
                toolTip1.SetToolTip(btn_Kardex, "Kardex del Cliente");
                toolTip1.SetToolTip(btn_ayuda, "Ayuda");
                toolTip1.SetToolTip(btn_Regresar, "Regresar");
                txt_ComentarioAyuda.Text =
                    "HISTORIAL COMPLETO DEL CLIENTE, AGREGAR LA CUENTA DEL CLIENTE PARA VER SU HISTORIAL EN EL CAMPO BUSCAR CUENTA.";
            }
            else
            {
                //if (usuarioVenta == "VENTP")
                //{
                //    btn_Eventos.Visible = false;
                //}
                lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
                KeyPreview = true;
                dateTimePicker2.Text = recibeFecha;
                txt_FechaD.Text = "";
                // SE OBTIENE LOS COMENTARIOS DE LOS COMPONENTES
                ListaHistorialComentario = Funciones.ConsultaComentario("Historial de Solicitudes");
                Cbx_movimiento_FillCombo();
                Cbx_Estatus_FillCombo();
                FillComboBoxCanal(recibeCliente);
                cbx_movimiento.Text = "(Todos)";
                cbx_Estatus.Text = "(Todos)";
                cbx_Situacion.Text = "(Todos)";
                cbx_Canal.Text = "(Todos)";
                txt_CuentaCliente.Text = recibeCliente;
                fillDataHistorialSolicitudes(recibeMensajeCliente);
            }

            toolTip1.SetToolTip(btn_Refrescar, "Refrescar");
            toolTip1.SetToolTip(btn_Eventos, "Eventos, Notas y Citas");
            toolTip1.SetToolTip(btn_UsuariosTiempos, "Usuarios y Tiempos");
            toolTip1.SetToolTip(btn_PosMov, "Posicion del Movimiento");
            toolTip1.SetToolTip(btn_Kardex, "Kardex del Cliente");
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            txt_CuentaCliente.Select();

            if (dgv_Eventos.Rows.Count > 0)
                groupBox4.Visible = true;
            else
                groupBox4.Visible = false;

            Text = "Historial De Solicitudes        " + "SPID:" + ClaseEstatica.SPID + "       " +
                   controllerExplorador.FechaActualServidor();

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_HistorialSolicitudes.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;

                flowLayoutPanel1.BackColor = Color.AliceBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_HistorialSolicitudes.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_HistorialSolicitudes.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                flowLayoutPanel1.BackColor = Color.LightCyan;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_HistorialSolicitudes.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_Eventos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                flowLayoutPanel1.BackColor = Color.WhiteSmoke;
            }


            if (usuarioVenta == "CREDI")
                btn_Kardex.Visible = true;
            else
                btn_Kardex.Visible = false;
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Eventos_Click(object sender, EventArgs e)
        {
            if (dgv_HistorialSolicitudes.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_EventosNotasCitas")
                    {
                        forma.Close();
                        break;
                    }

                DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                eventNotaCita = (DM0312_EventosNotasCitas)UsuarioAcceso.AplicarVistas(eventNotaCita);
                DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(ModelSeleccionadoHistorico.Id);
                DM0312_EventosNotasCitas.recibeMov = ModelSeleccionadoHistorico.Mov;
                DM0312_EventosNotasCitas.recibeMovId = Convert.ToString(ModelSeleccionadoHistorico.IdMovimiento);
                DM0312_EventosNotasCitas.recibeEstatus = ModelSeleccionadoHistorico.Estatus;
                DM0312_EventosNotasCitas.recibeSucursal = ModelSeleccionadoHistorico.Suc;
                DM0312_EventosNotasCitas.recibeUsuario = recibeMensajeUsuario;
                DM0312_EventosNotasCitas.recibeCliente = ModelSeleccionadoHistorico.Cuenta;
                DM0312_EventosNotasCitas.recibeSituacion = ModelSeleccionadoHistorico.Situacion;
                eventNotaCita.validaVistaHistorialSol = true;
                eventNotaCita.ShowDialog();
                StartPosition = FormStartPosition.CenterScreen;
            }

            if (DM0312_ExploradorVentas.EjecutaEvento)
                dgv_HistorialSolicitudes_CellClick(dgv_HistorialSolicitudes, new DataGridViewCellEventArgs(0, 0));
        }

        private void btn_UsuariosTiempos_Click(object sender, EventArgs e)
        {
            if (dgv_HistorialSolicitudes.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "TiemposUsuarios")
                    {
                        forma.Close();
                        break;
                    }

                TiemposUsuarios tiemposUsuario = new TiemposUsuarios();
                if (tiemposUsuario != null)
                {
                    tiemposUsuario.recibeCliente = recibeMensajeCliente;
                    tiemposUsuario.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionadoHistorico.Id);
                    tiemposUsuario.recibeMov = ModelSeleccionadoHistorico.Mov;
                    tiemposUsuario.recibeMovId = ModelSeleccionadoHistorico.IdMovimiento;
                    tiemposUsuario.recibeIdVenta = Convert.ToString(ModelSeleccionadoHistorico.Id);
                    tiemposUsuario.Show();
                }
            }
        }

        private void btn_PosMov_Click(object sender, EventArgs e)
        {
            if (dgv_HistorialSolicitudes.Rows.Count > 0)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_ReportePosicionMov")
                    {
                        forma.Close();
                        break;
                    }

                try
                {
                    int idVenta = ModelSeleccionadoHistorico.Id;
                    string mov = ModelSeleccionadoHistorico.Mov;
                    if (ModelSeleccionadoHistorico.Estatus != "SINAFECTAR")
                        funciones.FillReportePosicionMov(idVenta, mov);
                    else
                        MessageBox.Show("Movimiento origen sin Afectar", "Informacion", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_HistorialSolicitudes",
                        ex);
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("No hay información en el DataGrid Principal", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            //foreach (Form forma in Application.OpenForms)
            //{
            //    if (forma.Name == "TiemposUsuarios")
            //    {
            //        forma.Close();
            //        break;
            //    }
            //}
            //foreach (Form forma in Application.OpenForms)
            //{
            //    if (forma.Name == "DM0312_EventosNotasCitas")
            //    {
            //        forma.Close();
            //        break;
            //    }
            //}
            //foreach (Form forma in Application.OpenForms)
            //{
            //    if (forma.Name == "DM0312_ReportePosicionMov")
            //    {
            //        forma.Close();
            //        break;
            //    }
            //}
            //System.Diagnostics.Process[] procesos = System.Diagnostics.Process.GetProcesses();
            //foreach (System.Diagnostics.Process proceso in procesos)
            //{
            //    if (proceso.ProcessName == "KardexXCliente")
            //        proceso.Kill();
            //}
            Dispose();
        }

        private void btn_Refrescar_Click(object sender, EventArgs e)
        {
            validaAcceso = false;
            fillDataHistorialSolicitudes(recibeMensajeCliente);
        }

        private void btn_Kardex_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process[] procesos = Process.GetProcesses();
                foreach (Process proceso in procesos)
                    if (proceso.ProcessName == "KardexXCliente")
                        proceso.Kill();

                Process pTicket = new Process();
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                {
                    if (ModelSeleccionadoHistorico.mov == "Solicitud Credito")
                    {
                        int estacion = ClaseEstatica.WorkStation;
                        int idventa = ModelSeleccionadoHistorico.Id;
                        string cliente = ModelSeleccionadoHistorico.Cuenta;

                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments =
                            recibeMensajeUsuario + " " + estacion + " " + cliente + " " + idventa;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                    }
                    else
                    {
                        int estacion = ClaseEstatica.WorkStation;
                        string cliente = ModelSeleccionadoHistorico.Cuenta;
                        int idventa = controllerExplorador.origenID(ModelSeleccionadoHistorico.mov,
                            ModelSeleccionadoHistorico.idMovimiento);
                        pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                        pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                        pTicket.StartInfo.Verb = "runas";
                        pTicket.StartInfo.Arguments =
                            recibeMensajeUsuario + " " + estacion + " " + cliente + " " + idventa;
                        pTicket.StartInfo.UseShellExecute = false;
                        pTicket.Start();
                        pTicket.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_HistorialSolicitudes", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void gbx_menu_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox3_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void groupBox4_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.Clear(Color.White);
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            string shortDateATemp = dateTimePicker2.Value.ToShortDateString();
            if (dateTimePicker2.Value >= dtp_FechaD.Value)
            {
                errorProvider1.SetError(dateTimePicker2, string.Empty);
                string shortDateA = dateTimePicker2.Value.ToShortDateString();
                cbx_FechaA.Text = shortDateA;
            }
            else
            {
                errorProvider1.SetError(dateTimePicker2, "**Fecha final invalida");
                MessageBox.Show("No se permite seleccionar una fecha menor a la fecha de inicio", "!Aviso¡",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                dateTimePicker2.Text = dtp_FechaD.Text;
            }
        }

        private void dataGridView1_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            index = 0;
            index = dgv_HistorialSolicitudes.CurrentRow.Index;
        }

        private void lbl_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;

            if (e.KeyChar == (int)Keys.Enter)
            {
                validaAcceso = false;
                Busqueda();
            }
        }

        private void cbx_movimiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillComboSituacion();
            if (validaAcceso)
                if (dgv_HistorialSolicitudes.Rows.Count >= 0)
                {
                    validaAcceso = false;
                    Busqueda();
                }
        }

        private void cbx_Estatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (validaAcceso)
                if (dgv_HistorialSolicitudes.Rows.Count >= 0)
                {
                    validaAcceso = false;
                    Busqueda();
                }
        }

        private void cbx_Situacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (validaAcceso)
                if (dgv_HistorialSolicitudes.Rows.Count >= 0)
                {
                    validaAcceso = false;
                    Busqueda();
                }
        }

        private void cbx_Canal_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (validaAcceso)
                if (dgv_HistorialSolicitudes.Rows.Count >= 0)
                {
                    validaAcceso = false;
                    fillDataHistorialSolicitudes(recibeMensajeCliente);
                }
        }

        private void dgv_HistorialSolicitudes_SelectionChanged(object sender, EventArgs e)
        {
            if (validaAcceso)
            {
                ListaHistorialSolicitudes = new List<DM0312_MHistorialSolicitudes>();
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                {
                    DM0312_MHistorialSolicitudes model_ = new DM0312_MHistorialSolicitudes();
                    if (dgv_HistorialSolicitudes.SelectedRows.Count > 0)
                    {
                        model_ = (DM0312_MHistorialSolicitudes)dgv_HistorialSolicitudes.SelectedRows[0].DataBoundItem;
                        ListaHistorialSolicitudes.Add(model_);
                        ModelSeleccionadoHistorico = ListaHistorialSolicitudes.FirstOrDefault();
                        validaAcceso = true;
                        if (ModelSeleccionadoHistorico.Mov != "" && ModelSeleccionadoHistorico.Id != 0)
                        {
                            FillDataGridEventos();
                            CountTotal();
                        }
                    }
                }

                //ModelSeleccionadoHistorico.Id
                List<string> ListaActualizacion = new List<string>();
                ListaActualizacion = historialSolicitudes.ActualizacionDatos(ModelSeleccionadoHistorico.cuenta);
                if (ListaActualizacion.Count > 0)
                {
                    Act1.Text = ListaActualizacion[0];
                    Act2.Text = ListaActualizacion[1];
                    Act3.Text = ListaActualizacion[2];
                    label10.Visible = true;
                    Sucursal.Visible = true;
                    label12.Visible = true;
                    Act1.Visible = true;
                    Act2.Visible = true;
                    Act3.Visible = true;
                }
                else
                {
                    label10.Visible = false;
                    Sucursal.Visible = false;
                    label12.Visible = false;
                    Act1.Visible = false;
                    Act2.Visible = false;
                    Act3.Visible = false;
                }
            }

            if (dgv_Eventos.Rows.Count > 0)
                groupBox4.Visible = true;
            else
                groupBox4.Visible = false;
        }

        private void dgv_HistorialSolicitudes_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
                dgv_HistorialSolicitudes.Columns["fechaAlta"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }

        private void dgv_Eventos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 46) e.Handled = true;
        }

        private void HistorialSolicitudes_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.E)
            {
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                {
                    DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
                    AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                    eventNotaCita = (DM0312_EventosNotasCitas)UsuarioAcceso.AplicarVistas(eventNotaCita);
                    DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(ModelSeleccionadoHistorico.Id);
                    DM0312_EventosNotasCitas.recibeMov = ModelSeleccionadoHistorico.Mov;
                    DM0312_EventosNotasCitas.recibeMovId = Convert.ToString(ModelSeleccionadoHistorico.IdMovimiento);
                    DM0312_EventosNotasCitas.recibeEstatus = ModelSeleccionadoHistorico.Estatus;
                    DM0312_EventosNotasCitas.recibeSucursal = ModelSeleccionadoHistorico.Suc;
                    DM0312_EventosNotasCitas.recibeUsuario = recibeMensajeUsuario;
                    DM0312_EventosNotasCitas.recibeCliente = ModelSeleccionadoHistorico.Cuenta;
                    DM0312_EventosNotasCitas.recibeSituacion = ModelSeleccionadoHistorico.Situacion;
                    eventNotaCita.Show();
                }
                else
                {
                    MessageBox.Show("No hay Registros", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }

            if (e.Control && e.KeyCode == Keys.P)
            {
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                    try
                    {
                        int idVenta = ModelSeleccionadoHistorico.Id;
                        string mov = ModelSeleccionadoHistorico.Mov;
                        if (ModelSeleccionadoHistorico.Estatus != "SINAFECTAR")
                            funciones.FillReportePosicionMov(idVenta, mov);
                        else
                            MessageBox.Show("Movimiento origen sin Afectar", "Informacion", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                    }
                    catch (SqlException sqlException)
                    {
                        DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_HistorialSolicitudes",
                            sqlException);
                        MessageBox.Show(sqlException.Message);
                    }
                else
                    MessageBox.Show("No hay información en el DataGrid Principal", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
            }

            if (e.Control && e.KeyCode == Keys.U)
            {
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                {
                    TiemposUsuarios tiemposUsuario = new TiemposUsuarios();
                    tiemposUsuario.recibeCliente = recibeMensajeCliente;
                    tiemposUsuario.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionadoHistorico.Id);
                    tiemposUsuario.recibeMov = ModelSeleccionadoHistorico.Mov;
                    tiemposUsuario.recibeMovId = ModelSeleccionadoHistorico.IdMovimiento;
                    tiemposUsuario.recibeIdVenta = Convert.ToString(ModelSeleccionadoHistorico.Id);
                    tiemposUsuario.Show();
                }
                else
                {
                    MessageBox.Show("No hay Registros", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }

            if (e.Control && e.KeyCode == Keys.O)
            {
                if (dgv_HistorialSolicitudes.Rows.Count > 0)
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "CatalogoDeCalificaciones")
                        {
                            forma.Close();
                            break;
                        }

                    CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
                    catalogoCalificacion.Show();
                }
                else
                {
                    MessageBox.Show("No hay Registros", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }

            if (e.KeyCode == Keys.F11)
                try
                {
                    if (usuarioVenta == "CREDI")
                    {
                        if (dgv_HistorialSolicitudes.Rows.Count > 0)
                        {
                            if (ModelSeleccionadoHistorico.mov == "Solicitud Credito")
                            {
                                int estacion = ClaseEstatica.WorkStation;
                                int idventa = ModelSeleccionadoHistorico.Id;
                                Process pTicket = new Process();
                                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                                pTicket.StartInfo.Verb = "runas";
                                pTicket.StartInfo.Arguments = recibeMensajeUsuario + " " + estacion + " " +
                                                              recibeMensajeCliente + " " + idventa;
                                pTicket.StartInfo.UseShellExecute = false;
                                pTicket.Start();
                                pTicket.Dispose();
                            }
                            else
                            {
                                int estacion = ClaseEstatica.WorkStation;
                                int idventa = controllerExplorador.origenID(ModelSeleccionadoHistorico.mov,
                                    ModelSeleccionadoHistorico.idMovimiento);
                                Process pTicket = new Process();
                                pTicket.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                                pTicket.StartInfo.FileName = ClaseEstatica.plugInPath + @"KardexXCliente.exe";
                                pTicket.StartInfo.Verb = "runas";
                                pTicket.StartInfo.Arguments = recibeMensajeUsuario + " " + estacion + " " +
                                                              recibeMensajeCliente + " " + idventa;
                                pTicket.StartInfo.UseShellExecute = false;
                                pTicket.Start();
                                pTicket.Dispose();
                            }
                        }
                        else
                        {
                            MessageBox.Show("No hay Registros", "Informacion", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_HistorialSolicitudes",
                        ex);
                    MessageBox.Show(ex.Message);
                }

            if (e.KeyCode == Keys.Escape) Close();

            if (e.KeyCode == Keys.F5)
            {
                validaAcceso = false;
                Busqueda();
            }
        }

        private void dgv_Eventos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }
        }

        private void txt_FechaD_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txt_FechaD.Text, "[^0-9-/-]"))
            {
                MessageBox.Show("Solo Numeros, formato DD/MM/YYYY", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                txt_FechaD.Text = "";
            }
        }

        private void dgv_HistorialSolicitudes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DM0312_MExploradorVenta modelList =
                    controlDetalleVenta.ModeloDeMovimiento(ModelSeleccionadoHistorico.Id);
                List<DM0312_MExploradorVenta> temp = new List<DM0312_MExploradorVenta>();
                temp.Add(modelList);
                DM0312_ExploradorVentas.ListaExplorador = new List<DM0312_MExploradorVenta>(temp);

                controllerExplorador.LLenadoListaArticulosSeleccionados(temp);
                DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
                detalle.FlagAbrirDeHistorial = true;
                detalle.ShowDialog();

                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_ExploradorVentas")
                    {
                        DM0312_ExploradorVentas evento = (DM0312_ExploradorVentas)forma;
                        DM0312_ExploradorVentas.validaAcceso = true;
                        evento.dgv_TablaMovimientos_SelectionChanged_1(null, null);
                        break;
                    }

                //Cbx_movimiento_FillCombo();
                //Cbx_Estatus_FillCombo();
                //FillComboBoxCanal(recibeCliente);
                //cbx_movimiento.Text = "(Todos)";
                //cbx_Estatus.Text = "(Todos)";
                //cbx_Situacion.Text = "(Todos)";
                //cbx_Canal.Text = "(Todos)";
                fillDataHistorialSolicitudes(recibeMensajeCliente);
            }
        }

        private void HistorialSolicitudes_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "TiemposUsuarios")
                {
                    forma.Close();
                    break;
                }

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_EventosNotasCitas")
                {
                    forma.Close();
                    break;
                }

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_ReportePosicionMov")
                {
                    forma.Close();
                    break;
                }

            //System.Diagnostics.Process[] procesos = System.Diagnostics.Process.GetProcesses();
            //foreach (System.Diagnostics.Process proceso in procesos)
            //{
            //    if (proceso.ProcessName == "KardexXCliente")
            //        proceso.Kill();
            //}
            Dispose();
        }

        private void cbx_FechaA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (int)Keys.Enter)
            {
                Busqueda();
                dgv_HistorialSolicitudes.Select();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#' || e.KeyChar == '.' || e.KeyChar == '-' || e.KeyChar == '_')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void txt_FechaD_Validating(object sender, CancelEventArgs e)
        {
            DateTime dtInicio;
            if (txt_FechaD.Text != "")
            {
                if (!DateTime.TryParse(txt_FechaD.Text, out dtInicio))
                {
                    errorProvider1.SetError(txt_FechaD, "**Fecha Inicio invalida");
                    ClaseEstatica.FechaInicio = new DateTime();
                    txt_FechaD.Text = "";
                    MessageBox.Show("Error al seleccionar la fecha de inicio", "¡ Aviso !", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                errorProvider1.SetError(txt_FechaD, string.Empty);
                ClaseEstatica.FechaInicio = dtInicio;
            }
        }

        private void dtp_FechaD_Validating(object sender, CancelEventArgs e)
        {
            DateTime dtInicio;
            if (txt_FechaD.Text != "")
            {
                if (!DateTime.TryParse(txt_FechaD.Text, out dtInicio))
                {
                    errorProvider1.SetError(txt_FechaD, "**Fecha Inicio invalida");
                    ClaseEstatica.FechaInicio = new DateTime();
                    txt_FechaD.Text = "";
                    MessageBox.Show("Error al seleccionar la fecha de inicio", "¡ Aviso !", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                errorProvider1.SetError(txt_FechaD, string.Empty);
                ClaseEstatica.FechaInicio = dtInicio;
            }
        }

        private void dgv_HistorialSolicitudes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (ModelSeleccionadoHistorico.Mov != "" && ModelSeleccionadoHistorico.Id != 0) FillDataGridEventos();

            if (dgv_Eventos.Rows.Count > 0)
                groupBox4.Visible = true;
            else
                groupBox4.Visible = false;
        }

        private void lbl_Buscar_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta buscar =
                ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Buscar MovId"));
            txt_ComentarioAyuda.Text = buscar != null ? buscar.Comentario : "";
        }

        private void cbx_movimiento_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta movimiento =
                ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Movimiento"));
            txt_ComentarioAyuda.Text = movimiento != null ? movimiento.Comentario : "";
        }

        private void cbx_Situacion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta situacion_ =
                ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Situacion"));
            txt_ComentarioAyuda.Text = situacion_ != null ? situacion_.Comentario : "";
        }

        private void cbx_Canal_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta canal =
                ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Canales Venta"));
            txt_ComentarioAyuda.Text = canal != null ? canal.Comentario : "";
        }

        private void cbx_FechaD_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fechaD = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Fecha D"));
            txt_ComentarioAyuda.Text = fechaD != null ? fechaD.Comentario : "";
        }

        private void dateTimePicker2_MouseUp(object sender, MouseEventArgs e)
        {
            DM0312_MComentariosVenta fechaA = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Fecha A"));
            txt_ComentarioAyuda.Text = fechaA != null ? fechaA.Comentario : "";
        }

        private void txt_FechaD_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fechaA = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Fecha D"));
            txt_ComentarioAyuda.Text = fechaA != null ? fechaA.Comentario : "";
        }

        private void txt_CuentaCliente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta cuenta = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Cuenta"));
            txt_ComentarioAyuda.Text = cuenta != null ? cuenta.Comentario : "";
        }

        private void dtp_FechaD_MouseUp(object sender, MouseEventArgs e)
        {
            DM0312_MComentariosVenta fechaD = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Fecha D"));
            txt_ComentarioAyuda.Text = fechaD != null ? fechaD.Comentario : "";
        }

        private void cbx_Estatus_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta estatus = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Estatus"));
            txt_ComentarioAyuda.Text = estatus != null ? estatus.Comentario : "";
        }

        private void txt_FechaD_Click_1(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fechaD = ListaHistorialComentario.FirstOrDefault(x => x.Campo.Equals("Fecha D"));
            txt_ComentarioAyuda.Text = fechaD != null ? fechaD.Comentario : "";
        }

        private void btn_Refrescar_Click_1(object sender, EventArgs e)
        {
            validaAcceso = false;
            Busqueda();
        }

        private void dtp_FechaD_ValueChanged(object sender, EventArgs e)
        {
            if (dtp_FechaD.Value <= dateTimePicker2.Value)
            {
                errorProvider1.SetError(dtp_FechaD, string.Empty);
                txt_FechaD.Text = dtp_FechaD.Text;
            }
            else
            {
                errorProvider1.SetError(dtp_FechaD, "**Fecha Inicio invalida");
                MessageBox.Show("No se permite seleccionar una fecha mayor a la fecha final", "!Aviso¡",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txt_FechaD.Text = dateTimePicker2.Text;
            }
        }

        private void dgv_HistorialSolicitudes_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ColumnaAOrdenar = e.ColumnIndex;
            ColumnaOrden = dgv_HistorialSolicitudes.Columns[e.ColumnIndex].HeaderCell.SortGlyphDirection ==
                           SortOrder.None
                           || dgv_HistorialSolicitudes.Columns[e.ColumnIndex].HeaderCell.SortGlyphDirection ==
                           SortOrder.Descending
                ? false
                : true;

            OrdenerHistorialSolicitudes(e.ColumnIndex);
        }

        #endregion
    }
}