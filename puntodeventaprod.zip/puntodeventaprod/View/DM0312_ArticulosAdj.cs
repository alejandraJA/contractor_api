﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_ArticulosAdj : Form
    {
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        public static List<DM0312_MPuntoDeVentaAlmacen> listaAlmacen = new List<DM0312_MPuntoDeVentaAlmacen>();
        public static List<DM0312_M_ArticulosAdjudicados> Lista = new List<DM0312_M_ArticulosAdjudicados>();
        public static List<DM0312_M_ArticulosAdjudicados> ListaF = new List<DM0312_M_ArticulosAdjudicados>();
        public string almacenV = "";
        private string Estatus, Articulo;
        private readonly Funciones funciones = new Funciones();
        public string idArticulo, NomArt, dispo, unidad, impuesto, LineaPV, Tipo;
        public int indice = -1;

        public DM0312_ArticulosAdj()
        {
            InitializeComponent();
        }

        ~DM0312_ArticulosAdj()
        {
            GC.Collect();
        }

        private void DM0312_ArticulosAdj_Load(object sender, EventArgs e)
        {
            LlenaArticulos();
            LlenaEstatus();

            toolTip1.SetToolTip(lbl_Buscar, "AGREGAR ARTICULO ADJUDICADO A BUSCAR");
            toolTip1.SetToolTip(txt_Buscar, "AGREGAR ARTICULO ADJUDICADO A BUSCAR");
            toolTip1.SetToolTip(lbl_Estatus,
                "FILTRO CON LOS ESTATUS DE LOS ARTICULOS, SELECCIONAR EL QUE SE DESEA BUSCAR");
            toolTip1.SetToolTip(cmb_Estatus,
                "FILTRO CON LOS ESTATUS DE LOS ARTICULOS, SELECCIONAR EL QUE SE DESEA BUSCAR");
            txt_Comentarios.Text =
                "CATALOGO DE ARTICULOS ADJUDICADOS, SELECCIONAR EL ARTICULO A VENDER DANDO DOBLE CLICK AL ARTICULO SELECCIONADO";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_Articulos.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        public void LlenaEstatus()
        {
            try
            {
                cmb_Estatus.Items.Add("TODOS");
                cmb_Estatus.Items.Add("ALTA");
                cmb_Estatus.Items.Add("BLOQUEADO");
                cmb_Estatus.Text = "TODOS";
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaEstatus", "DM0312_ArticulosAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }


        public async void LlenaArticulos()
        {
            try
            {
                Lista = new List<DM0312_M_ArticulosAdjudicados>();
                string almacenI = "";
                almacenI = controlador.AlmacenI(almacenV);
                if (Lista.Count == 0)
                {
                    DM0312_Loading_ frmLoading = new DM0312_Loading_();
                    frmLoading.Show(this);
                    lbl_Buscar.Enabled = false;
                    txt_Buscar.Enabled = false;
                    lbl_Estatus.Enabled = false;
                    cmb_Estatus.Enabled = false;
                    Lista = await Task.Run(() => controlador.BuscaArticulosADJ(almacenV));
                    ListaF = Lista;
                    frmLoading.Hide();
                    lbl_Buscar.Enabled = true;
                    txt_Buscar.Enabled = true;
                    lbl_Estatus.Enabled = true;
                    cmb_Estatus.Enabled = true;
                }

                List<DM0312_M_ArticulosAdjudicados> objetos = Lista.Take(2000).ToList();
                dgv_Articulos.DataSource = objetos;
                dgv_Articulos.Visible = true;

                if (Lista.Count > 0)
                {
                    dgv_Articulos.Columns[7].Visible = false;
                    dgv_Articulos.Columns[5].Visible = false;
                }

                if (Lista.Count == 0)
                {
                    MessageBox.Show("No se encuentran Articulos Adjudicados", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    txt_Buscar.Text = "";
                    dgv_Articulos.Visible = false;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaArticulos", "DM0312_ArticulosAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void dgv_Articulos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            indice = e.RowIndex;
            if (indice >= 0)
            {
                idArticulo = dgv_Articulos.Rows[e.RowIndex].Cells["Codigo"].FormattedValue.ToString();
                NomArt = dgv_Articulos.Rows[e.RowIndex].Cells["Nombre"].FormattedValue.ToString();
                dispo = dgv_Articulos.Rows[e.RowIndex].Cells["Disponible"].FormattedValue.ToString();
                impuesto = dgv_Articulos.Rows[e.RowIndex].Cells["Impuesto"].FormattedValue.ToString();
                unidad = dgv_Articulos.Rows[e.RowIndex].Cells["unidad"].FormattedValue.ToString();
                LineaPV = dgv_Articulos.Rows[e.RowIndex].Cells["Linea"].FormattedValue.ToString();
                Tipo = dgv_Articulos.Rows[e.RowIndex].Cells["Tipo"].FormattedValue.ToString();
                Close();
            }
        }

        private void cmb_Estatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            string art = txt_Buscar.Text;
            art = art.Replace("*", "");
            string Condicion = string.Empty;
            Estatus = cmb_Estatus.Text;
            Condicion = "";


            if (Estatus != "" && Estatus != "TODOS")
            {
                if (art.Trim() != "")
                {
                    ListaF = Lista.Where(x =>
                        x.Estatus.Contains(Estatus) && (x.Codigo.Contains(art) || x.Nombre.Contains(art))).ToList();
                    ListaF = ListaF.Take(2000).ToList();
                    dgv_Articulos.DataSource = ListaF;
                }
                else
                {
                    ListaF = Lista.Where(x => x.Estatus.Contains(Estatus)).ToList();
                    ListaF = ListaF.Take(2000).ToList();
                    dgv_Articulos.DataSource = ListaF;
                }
            }
            else
            {
                dgv_Articulos.DataSource = Lista;
                ListaF = Lista;
            }

            //if (dgv_Articulos.RowCount == 0)
            //{
            //    MessageBox.Show("No se encuentran Articulos", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }


        private void ValidarArticulos()
        {
            string art = txt_Buscar.Text;
            art = art.Replace("*", "");
            string Condicion = string.Empty;
            Estatus = cmb_Estatus.Text;

            if (Estatus != "" && Estatus != "TODOS")
            {
                if (art != "")
                {
                    ListaF = Lista.Where(x =>
                        x.Estatus.Contains(Estatus) && (x.Codigo.Contains(art) || x.Nombre.Contains(art))).ToList();
                    ListaF = ListaF.Take(2000).ToList();
                    dgv_Articulos.DataSource = ListaF;
                }
                else
                {
                    ListaF = Lista.Where(x => x.Estatus.Contains(Estatus)).ToList();
                    ListaF = ListaF.Take(2000).ToList();
                    dgv_Articulos.DataSource = ListaF;
                }
            }
            else
            {
                if (art.Trim() != "")
                {
                    ListaF = Lista.Where(x => x.Codigo.Contains(art) || x.Nombre.Contains(art)).ToList();
                    ListaF = ListaF.Take(2000).ToList();
                    dgv_Articulos.DataSource = ListaF;
                }
                else
                {
                    dgv_Articulos.DataSource = Lista;
                    ListaF = Lista;
                }
            }

            if (ListaF.Count == 0)
            {
                MessageBox.Show("No se encuentran Articulos Adjudicados", "Informacion", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                txt_Buscar.Text = "";
            }
        }

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ValidarArticulos();

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dgv_Articulos_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(ListaF);
            funciones.OrderGridview(dgv_Articulos, e.ColumnIndex, TempObjects,
                ListaF.GetType().GetGenericArguments().Single());

            dgv_Articulos.Columns[7].Visible = false;
            dgv_Articulos.Columns[5].Visible = false;
        }

        private void dgv_Articulos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridViewCell cell = dgv_Articulos.Rows[e.RowIndex].Cells[e.ColumnIndex];
            cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN ARTICULO ADJUDICADO";
        }
    }
}