﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_DevSerieArticulo : Form
    {
        private DM0312_CPuntoDeVenta controladorPuntoVenta;

        private readonly CSerieArticulos ControladorSerie;

        public List<MSerieArticulos> ListInIdDevolucion;

        public List<MSerieArticulos> ListInIdFactura;

        public List<MSerieArticulos> ListOldSeries;

        public MSerieArticulos ModeloCatalogo;

        public MSerieArticulos ModeloSeries;

        public DM0312_DevSerieArticulo()
        {
            InitializeComponent();

            //Lista de Series Insertadas para devolucion
            ListInIdDevolucion = new List<MSerieArticulos>();

            //Lista Disponibles para devolver
            ListInIdFactura = new List<MSerieArticulos>();

            ControladorSerie = new CSerieArticulos();

            controladorPuntoVenta = new DM0312_CPuntoDeVenta();

            ModeloCatalogo = new MSerieArticulos();

            ModeloSeries = new MSerieArticulos();

            ListOldSeries = new List<MSerieArticulos>();
        }

        public int IdVentaFactura { get; set; }

        public string articulo { get; set; }

        public string ReferenciaFactura { get; set; }

        public string descripcion { get; set; }

        public int IdVentaDev { get; set; }

        public int Cantidad { get; set; }

        public string SerieAsig { get; set; }

        public int SucursalOrigen { get; set; }

        public int RenglonID { get; set; }

        ~DM0312_DevSerieArticulo()
        {
            GC.Collect();
        }

        private void DM0312_DevSerieArticulo_Load(object sender, EventArgs e)
        {
            lbl_articulo.Text = "Articulo:" + articulo;

            lbl_descripcion.Text = descripcion;

            llenarGrids();

            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }


        #region Metodos

        public void llenarGrids(bool dev = false)
        {
            if (!dev)
            {
                //Lista de Series Insertadas para devolucion
                ListInIdDevolucion = ControladorSerie.ObtenerSeriesArticulos(IdVentaDev, articulo);

                ListOldSeries = ControladorSerie.ObtenerSeriesArticulos(IdVentaDev, articulo);
            }

            //Lista Disponibles para devolver
            ListInIdFactura = ControladorSerie.GetSeriesDev(ReferenciaFactura, articulo, IdVentaFactura);

            if (ListInIdDevolucion.Count == 0)
            {
                IEnumerable<string> series = ListInIdDevolucion.Select(s => s.Serie);

                IEnumerable<MSerieArticulos> facturas = from ListFactu in ListInIdFactura
                    where !series.Contains(ListFactu.Serie)
                    select ListFactu;

                ListInIdFactura = new List<MSerieArticulos>();

                ListInIdFactura = facturas.ToList();
            }
            else
            {
                foreach (MSerieArticulos item in ListInIdFactura)
                {
                    string serie = ListInIdDevolucion.Where(x => x.Serie == item.Serie).Select(x => x.Serie)
                        .FirstOrDefault();

                    if (serie != null) item.Editar = true;
                }
            }

            dgv_serieArticulo.DataSource = null;
            dgv_serieArticulo.DataSource = new BindingList<MSerieArticulos>(ListInIdDevolucion);

            if (ListInIdDevolucion.Count > 0) dgv_serieArticulo.Columns[0].Visible = false;

            dgv_catalogo.DataSource = null;
            dgv_catalogo.DataSource = new BindingList<MSerieArticulos>(ListInIdFactura);
        }

        #endregion

        private void DM0312_DevSerieArticulo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();

            if (e.Control && e.KeyCode == Keys.G)
            {
                ControladorSerie.ActualizarSerie(IdVentaDev, articulo, ListOldSeries, ListInIdDevolucion,
                    SucursalOrigen, RenglonID);

                llenarGrids();

                Dispose();
            }
        }


        #region Eventos

        private void dgv_catalogo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            if (e.ColumnIndex == 0)
            {
                ModeloCatalogo = (MSerieArticulos)dgv_catalogo.SelectedRows[0].DataBoundItem;

                MSerieArticulos model = ListInIdDevolucion.Where(x => x.Serie == ModeloCatalogo.Serie).FirstOrDefault();

                if (model != null)
                {
                    ListInIdDevolucion.Remove(model);
                    llenarGrids(true);
                }
                else
                {
                    if (dgv_serieArticulo.RowCount == Cantidad)
                    {
                        MessageBox.Show("Error el número de series elegidas excede la cantidad de articulos elegidos",
                            "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        ModeloCatalogo = (MSerieArticulos)dgv_catalogo.SelectedRows[0].DataBoundItem;

                        ModeloCatalogo.Editar = true;

                        ListInIdDevolucion.Add(ModeloCatalogo);

                        llenarGrids(true);
                    }
                }
            }
        }

        private void Aceptar_Click(object sender, EventArgs e)
        {
            if (ListOldSeries.Count > 0)
            {
                DM0312_CPuntoDeVenta Controlador_ = new DM0312_CPuntoDeVenta();

                Controlador_.DeleteSeriesLotes("123", IdVentaDev, articulo);
            }

            ListOldSeries = new List<MSerieArticulos>();

            ControladorSerie.ActualizarSerie(IdVentaDev, articulo, ListOldSeries, ListInIdDevolucion, SucursalOrigen,
                RenglonID);

            llenarGrids();

            Dispose();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        #endregion
    }
}