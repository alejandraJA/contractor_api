﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class frmVisorImagenes : Form
    {
        private bool btipoCerrado;

        public bool cambio;
        private int iX;
        private int iY;

        private int iZoom;

        public frmVisorImagenes(Image imagen)
        {
            InitializeComponent();
            pbImagen.Image = imagen;
        }

        public bool bEstatusImangen { get; set; }

        ~frmVisorImagenes()
        {
            GC.Collect();
        }

        private void frmVisorImagenes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!btipoCerrado)
                if (DialogResult.No == MessageBox.Show("¿Desea salir de la validacion?", "Punto De Venta",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                    e.Cancel = true;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                bEstatusImangen = true;
                btipoCerrado = true;
                cambio = true;
                Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRechazar_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes ==
                MessageBox.Show("¿desea rechazar la imagen?", "Confirmación", MessageBoxButtons.YesNo))
                try
                {
                    bEstatusImangen = false;
                    btipoCerrado = true;
                    Close();
                }
                catch (Exception ex)
                {
                    DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                        MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                    MessageBox.Show(ex.Message);
                }
        }

        private void btnZoomMas_Click(object sender, EventArgs e)
        {
            try
            {
                //iZoom++;
                pbImagen.Height += 10;
                pbImagen.Width += 10;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btnZoomMenos_Click(object sender, EventArgs e)
        {
            try
            {
                iZoom--;
                pbImagen.Height -= 10;
                pbImagen.Width -= 10;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void frmVisorImagenes_Load(object sender, EventArgs e)
        {
            try
            {
                pbImagen.Width = pbImagen.Image.Width;
                pbImagen.Height = pbImagen.Image.Height;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void pbImagen_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pbImagen.Left = pbImagen.Left + e.X - iX;
                pbImagen.Top = pbImagen.Top + e.Y - iY;
            }
        }

        private void pbImagen_MouseDown(object sender, MouseEventArgs e)
        {
            iX = e.X;
            iY = e.Y;
            Cursor.Current = Cursors.IBeam;
        }

        private void pbImagen_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            pbImagen.Width = pbImagen.Image.Width;
            pbImagen.Height = pbImagen.Image.Height;
        }

        private void pbImagen_MouseLeave(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.Arrow;
        }

        private void pbImagen_MouseEnter(object sender, EventArgs e)
        {
            pbImagen.Cursor = Cursors.Hand;
        }

        private void btnGirarI_Click(object sender, EventArgs e)
        {
            pbImagen.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            pbImagen.Refresh();
        }

        private void btnGirarD_Click(object sender, EventArgs e)
        {
            pbImagen.Image.RotateFlip(RotateFlipType.Rotate90FlipXY);
            pbImagen.Refresh();
        }
    }
}