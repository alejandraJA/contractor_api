﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class AyudaAgente : Form
    {
        private readonly ControlAyudaAgente ayudaAgente = new ControlAyudaAgente();
        public List<DM0312_MComentariosVenta> ComentariosF;
        private DateTime day = DateTime.Now;
        public string enviaClaveAgente;
        public string enviaNombre;
        private Funciones funciones = new Funciones();
        public string recibeEstatus;
        public string recibeFecha;
        public string recibeHora;
        public string recibeIdecommerce;
        public string recibeIdVenta;
        public int recibeMensaje;
        public string recibeSituacion;
        public string recibeSucursal;
        public string recibeTexto;
        public string recibeUsuario;
        public bool validaCierreForma;

        public AyudaAgente()
        {
            InitializeComponent();
        }

        ~AyudaAgente()
        {
            GC.Collect();
        }

        private void AyudaAgente_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Dispose();
                Close();
            }
        }

        private void txt_Comentarios_TextChanged(object sender, EventArgs e)
        {
        }

        #region "Methods"

        public void llenaDataGridAyudaAgente()
        {
            DataTable dataTable = ayudaAgente.AyudaAgente(ClaseEstatica.Usuario.Sucursal);
            dgv_AyudaAgente.DataSource = dataTable;
        }

        public void llenaTexto()
        {
            DataTable table = ayudaAgente.AyudaAgenteTextoBuscar(txt_BuscarAgente.Text);
            dgv_AyudaAgente.DataSource = table;
        }

        #endregion

        #region "Handles"

        private void AyudaAgente_Load(object sender, EventArgs e)
        {
            ListaComentarios();
            llenaDataGridAyudaAgente();
            StartPosition = FormStartPosition.CenterScreen;

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_AyudaAgente.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_AyudaAgente.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_AyudaAgente.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_AyudaAgente.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void ListaComentarios()
        {
            ComentariosF = Funciones.ConsultaComentario("AsistenteAgente");
            DM0312_MComentariosVenta agente = ComentariosF.Where(x => x.Campo.Equals("BuscarAgente")).FirstOrDefault();
            DM0312_MComentariosVenta regresar = ComentariosF.Where(x => x.Campo.Equals("Regresar")).FirstOrDefault();
            DM0312_MComentariosVenta Bayuda = ComentariosF.Where(x => x.Campo.Equals("BotonAyuda")).FirstOrDefault();
            DM0312_MComentariosVenta ComentarioP =
                ComentariosF.Where(x => x.Campo.Equals("ComentarioForma")).FirstOrDefault();
            if (agente != null) toolTip1.SetToolTip(txt_BuscarAgente, agente.Comentario);
            if (regresar != null) toolTip1.SetToolTip(button1, regresar.Comentario);
            if (Bayuda != null) toolTip1.SetToolTip(button2, Bayuda.Comentario);
            if (ComentarioP != null)
                txt_Comentarios.Text = ComentarioP.Comentario + " " + ClaseEstatica.Usuario.sucursal;
        }

        private void txt_BuscarAgente_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];

            if (e.KeyChar == (int)Keys.Enter)
                if (txt_BuscarAgente.Text != "")
                    llenaTexto();
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
            Close();
        }

        private void dgv_AyudaAgente_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ModelAgregaEvento model = new ModelAgregaEvento();
            int index = dgv_AyudaAgente.CurrentRow.Index;
            enviaClaveAgente = dgv_AyudaAgente.Rows[index].Cells[0].Value.ToString();
            enviaNombre = dgv_AyudaAgente.Rows[index].Cells[1].Value.ToString();
            DM0312_AgregarEvento agregaEvento = new DM0312_AgregarEvento();
            model.ClaveAgente = enviaClaveAgente;
            model.NombreAgente = enviaNombre;
            model.Comentario = recibeTexto;
            DM0312_AgregarEvento.list.Add(model);

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "AyudaAgente")
                {
                    forma.Close();
                    break;
                }

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_AgregarEvento")
                {
                    DM0312_AgregarEvento evento = (DM0312_AgregarEvento)forma;
                    evento.AgregarEvento_Load(null, null);
                    evento.recibeIdVenta = recibeIdVenta;
                    evento.recibeUsuario = recibeUsuario;
                    evento.recibeSucursal = recibeSucursal;
                    evento.recibeSituacion = recibeSituacion;
                    evento.recibeMensaje = recibeMensaje;
                    evento.txt_AsuntObserva.Text = recibeTexto;
                    evento.txt_Fecha.Text = day.ToShortDateString();
                    evento.recibeEstatus = recibeEstatus;
                    DM0312_AgregarEvento.recibeTexto = recibeTexto;
                    evento.recibeHora = recibeHora;
                    evento.recibeFecha = recibeFecha;
                    evento.recibeIdecommerce = recibeIdecommerce;

                    evento.Show();
                    break;
                }
        }

        private void txt_BuscarAgente_TextChanged(object sender, EventArgs e)
        {
            if (txt_BuscarAgente.Text != "") llenaTexto();
        }

        private void AyudaAgente_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dispose();
        }

        private void AyudaAgente_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "AyudaAgente")
                    Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
            Close();
        }

        private void dgv_AyudaAgente_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }

            DataGridViewCell cell = dgv_AyudaAgente.Rows[e.RowIndex].Cells[e.ColumnIndex];
            cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UN AGENTE";
        }

        #endregion
    }
}