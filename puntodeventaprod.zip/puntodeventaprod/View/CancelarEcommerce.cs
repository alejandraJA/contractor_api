﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta
{
    public partial class CancelarEcommerce : Form
    {
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public int idventa;
        public string motivo = "";

        public CancelarEcommerce()
        {
            InitializeComponent();
            ObtenerComentariosCancelacion();
        }

        ~CancelarEcommerce()
        {
            GC.Collect();
        }

        private void CancelarEcommerce_Load(object sender, EventArgs e)
        {
            txt_Otro.Visible = false;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            GuardarMotivo();
        }

        private void ObtenerComentariosCancelacion()
        {
            List<string> sComentarios = CDetalleVenta.ObtenerComentariosCancelacion();
            if (sComentarios.Count > 0)
            {
                foreach (string item in sComentarios) cb_opciones.Items.Add(item);
                cb_opciones.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("No se encontraron comentarios configurados", "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                cb_opciones.Items.Add("OTRO");
                cb_opciones.SelectedIndex = 0;
                txt_Otro.Visible = true;
            }
        }


        public void GuardarMotivo()
        {
            if (cb_opciones.SelectedIndex != -1)
            {
                if (cb_opciones.SelectedItem.ToString() != "OTRO")
                {
                    motivo = cb_opciones.SelectedItem.ToString();

                    CDetalleVenta.MotivoCancelacion(motivo, idventa);
                    MessageBox.Show("Registro guardado correctamente", "Punto De Venta", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    Close();
                }
                else if (cb_opciones.SelectedItem.ToString() == "OTRO" && !string.IsNullOrEmpty(txt_Otro.Text))
                {
                    motivo = txt_Otro.Text;

                    CDetalleVenta.MotivoCancelacion(motivo, idventa);
                    Close();
                }
                else
                {
                    MessageBox.Show("Es obligatorio ingresar un motivo de cancelacion ", "Advertencia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar algun motivo de cancelacion para poder continuar ", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void CancelarEcommerce_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
            else if (e.Modifiers == Keys.Control && e.KeyCode == Keys.G) GuardarMotivo();
        }

        private void cb_opciones_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_opciones.SelectedItem.ToString() != "OTRO")
            {
                txt_Otro.Enabled = false;
                txt_Otro.Clear();
                txt_Otro.Visible = false;
            }
            else
            {
                txt_Otro.Enabled = true;
                txt_Otro.Visible = true;
            }
        }
    }
}