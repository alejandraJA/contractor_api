﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_PuntoDeVentaCanalNuevo : Form
    {
        public static DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        private bool existe;

        private int indice = -1, Canal;

        public DM0312_PuntoDeVentaCanalNuevo()
        {
            InitializeComponent();
        }

        ~DM0312_PuntoDeVentaCanalNuevo()
        {
            GC.Collect();
        }

        private void DM0312_PuntoDeVentaCanalNuevo_Load(object sender, EventArgs e)
        {
            LlenaTodosCanales();
            dgv_Canales.Select();
            txt_Id.Text = dgv_Canales.Rows[0].Cells[0].FormattedValue.ToString();
            Canal = int.Parse(txt_Id.Text);
            txt_NombreCanal.Text = dgv_Canales.Rows[0].Cells[1].FormattedValue.ToString();
            //SendKeys.Send("{CellClick}");

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Canales.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Canales.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Canales.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris") dgv_Canales.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        #region "EVENTOS"

        private void dgv_Canales_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indice = e.RowIndex;
            if (indice >= 0)
            {
                txt_Id.Text = dgv_Canales.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
                Canal = int.Parse(txt_Id.Text);
                txt_NombreCanal.Text = dgv_Canales.Rows[e.RowIndex].Cells["Cadena"].FormattedValue.ToString();
            }
        }

        #endregion

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            ValidaExiste();
            if (existe)
            {
                MessageBox.Show("El cliente ya cuenta con ese canal", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                AgregaNuevoCanal();
                MessageBox.Show("Se agrego nuevo canal de venta", "Exito!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Close();
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DM0312_PuntoDeVentaCanalNuevo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
        }

        #region "METODOS"

        public void LlenaTodosCanales()
        {
            DataTable dataSet = new DataTable();
            dataSet = controlador.LlenaTodosLosCanales(ClaseEstatica.Usuario.Uen);
            dgv_Canales.DataSource = dataSet;
            dgv_Canales.Columns[0].Width = 70;
            dgv_Canales.Columns[1].Width = 300;
        }

        public void ValidaExiste()
        {
            DM0312_MPuntoDeVentaCanales var = PuntoDeVenta.listaCanal
                .Where(x => x.Canal == Convert.ToInt32(txt_Id.Text)).FirstOrDefault();
            if (var != null)
                existe = true;
            else
                existe = false;
        }

        public void AgregaNuevoCanal()
        {
            bool Inserta = new bool();
            Inserta = controlador.AgregaNuevoCanal(DM0312_CatalogosPuntoDeVenta.Cliente, Canal);
        }

        #endregion
    }
}