﻿using System.ComponentModel;

namespace PuntoVenta.View {
    partial class EnviarConAnalista {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
           
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.lbl_Mov = new System.Windows.Forms.Label();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_Movimiento = new System.Windows.Forms.Label();
            this.cbx_Analista = new System.Windows.Forms.ComboBox();
            this.lbl_message = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Mov
            // 
            this.lbl_Mov.AutoSize = true;
            this.lbl_Mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mov.Location = new System.Drawing.Point(267, 200);
            this.lbl_Mov.Name = "lbl_Mov";
            this.lbl_Mov.Size = new System.Drawing.Size(126, 15);
            this.lbl_Mov.TabIndex = 5;
            this.lbl_Mov.Text = "Mov: XXXXXXXXXX";
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = global::PuntoVenta.Properties.Resources.icons8_volver_30;
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 83);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(73, 73);
            this.btn_Regresar.TabIndex = 10;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Image = global::PuntoVenta.Properties.Resources.floppy_icon;
            this.btn_Guardar.Location = new System.Drawing.Point(3, 3);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(73, 74);
            this.btn_Guardar.TabIndex = 9;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_Guardar);
            this.flowLayoutPanel1.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 7);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(82, 175);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(3, 185);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(51, 15);
            this.lbl_Cliente.TabIndex = 14;
            this.lbl_Cliente.Text = "Cliente:";
            // 
            // lbl_Movimiento
            // 
            this.lbl_Movimiento.AutoSize = true;
            this.lbl_Movimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Movimiento.Location = new System.Drawing.Point(3, 200);
            this.lbl_Movimiento.Name = "lbl_Movimiento";
            this.lbl_Movimiento.Size = new System.Drawing.Size(166, 15);
            this.lbl_Movimiento.TabIndex = 15;
            this.lbl_Movimiento.Text = "Movimiento: Analisis Credito";
            // 
            // cbx_Analista
            // 
            this.cbx_Analista.FormattingEnabled = true;
            this.cbx_Analista.Location = new System.Drawing.Point(150, 83);
            this.cbx_Analista.Name = "cbx_Analista";
            this.cbx_Analista.Size = new System.Drawing.Size(403, 21);
            this.cbx_Analista.TabIndex = 16;
            // 
            // lbl_message
            // 
            this.lbl_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_message.Location = new System.Drawing.Point(91, 7);
            this.lbl_message.Name = "lbl_message";
            this.lbl_message.Size = new System.Drawing.Size(388, 52);
            this.lbl_message.TabIndex = 17;
            this.lbl_message.Text = "SELECCIONE UN ANALISTA PARA ENVIAR EL MOVIMIENTO";
            this.lbl_message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(91, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 15);
            this.label1.TabIndex = 33;
            this.label1.Text = "Analista";
            // 
            // EnviarConAnalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(558, 225);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_message);
            this.Controls.Add(this.cbx_Analista);
            this.Controls.Add(this.lbl_Movimiento);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.lbl_Mov);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "EnviarConAnalista";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enviar Con Analista";
            this.Load += new System.EventHandler(this.EnviarConAnalista_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EnviarConAnalista_KeyDown);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ComboBox cbx_Analista;

        private System.Windows.Forms.Label lbl_message;

        private System.Windows.Forms.ComboBox comboBox1;

        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox3;

        public System.Windows.Forms.TextBox textBox1;

        #endregion

        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.Label lbl_Mov;
        private System.Windows.Forms.Label lbl_Agente;
        public System.Windows.Forms.TextBox txt_AgenteDescripcion;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Label lbl_Hora;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Movimiento;
    }
}