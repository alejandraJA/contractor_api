﻿namespace PuntoVenta.View
{
    partial class EscanearArticuloPequeno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpContenido = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.txtArticulo = new System.Windows.Forms.TextBox();
            this.btnValidarGerente = new System.Windows.Forms.Button();
            this.tlpContenido.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpContenido
            // 
            this.tlpContenido.ColumnCount = 3;
            this.tlpContenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tlpContenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tlpContenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tlpContenido.Controls.Add(this.lblTitulo, 1, 1);
            this.tlpContenido.Controls.Add(this.txtArticulo, 1, 3);
            this.tlpContenido.Controls.Add(this.btnValidarGerente, 1, 5);
            this.tlpContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpContenido.Location = new System.Drawing.Point(0, 0);
            this.tlpContenido.Name = "tlpContenido";
            this.tlpContenido.RowCount = 7;
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpContenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpContenido.Size = new System.Drawing.Size(384, 151);
            this.tlpContenido.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(60, 26);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(262, 15);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Favor escanee el artículo";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtArticulo
            // 
            this.txtArticulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtArticulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArticulo.Location = new System.Drawing.Point(60, 54);
            this.txtArticulo.Name = "txtArticulo";
            this.txtArticulo.ShortcutsEnabled = false;
            this.txtArticulo.Size = new System.Drawing.Size(262, 21);
            this.txtArticulo.TabIndex = 0;
            this.txtArticulo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArticulo_KeyPress);
            // 
            // btnValidarGerente
            // 
            this.btnValidarGerente.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnValidarGerente.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnValidarGerente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnValidarGerente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidarGerente.Location = new System.Drawing.Point(172, 91);
            this.btnValidarGerente.Name = "btnValidarGerente";
            this.btnValidarGerente.Size = new System.Drawing.Size(150, 30);
            this.btnValidarGerente.TabIndex = 1;
            this.btnValidarGerente.Text = "Validar por gerente";
            this.btnValidarGerente.UseVisualStyleBackColor = false;
            this.btnValidarGerente.Click += new System.EventHandler(this.btnValidarGerente_Click);
            // 
            // EscanearArticuloPequeno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 151);
            this.Controls.Add(this.tlpContenido);
            this.MaximumSize = new System.Drawing.Size(400, 190);
            this.MinimumSize = new System.Drawing.Size(400, 190);
            this.Name = "EscanearArticuloPequeno";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Escanear artículo";
            this.tlpContenido.ResumeLayout(false);
            this.tlpContenido.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpContenido;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtArticulo;
        private System.Windows.Forms.Button btnValidarGerente;
    }
}