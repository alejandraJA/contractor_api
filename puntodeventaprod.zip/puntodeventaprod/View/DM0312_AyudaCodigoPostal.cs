﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_AyudaCodigoPostal : Form
    {
        public int activeEstado;
        private readonly DM0312_C_CampoExtra controlCampoExtra = new DM0312_C_CampoExtra();
        public string delegacion;
        public string estado;
        private readonly Funciones funciones = new Funciones();
        private List<DM0312_MCamposExtra> modelList = new List<DM0312_MCamposExtra>();
        public string recibeCliente;
        public int recibeCodigoPostal;
        public string recibeCruce;
        public int recibeIdVenta;
        public string recibeMov;
        public string recibeNombreConyuge;
        public string recibeNomCalle;
        public string recibeNumExterior;
        public string recibeNumIdenti;
        public string recibeNumInterior;
        public string recibeRelacionado;
        public string recibeTelefono;
        public string recibeTipoCalle;
        public bool validaFiltros;

        public DM0312_AyudaCodigoPostal()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        ~DM0312_AyudaCodigoPostal()
        {
            GC.Collect();
        }

        private void DM0312_AyudaCodigoPostal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Dispose();
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_CamposExtra")
                    {
                        forma.Show();
                        break;
                    }
            }
        }

        private void dgv_CodigoPostal_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridViewCell cell = dgv_CodigoPostal.Rows[e.RowIndex].Cells[e.ColumnIndex];
            cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UNA DIRECCION";
        }

        private void cbx_Estado_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbx_Delegacion.Text = "";
        }

        private void cbx_Delegacion_Validating(object sender, CancelEventArgs e)
        {
            recibeCodigoPostal = 0;
            FillDgvCodigoPostal();
            estado = controlCampoExtra.ValidaEstado(ClaseEstatica.Usuario.Sucursal);
            delegacion = controlCampoExtra.ValidaDelegacion(ClaseEstatica.Usuario.Sucursal);
        }

        #region "Methods"

        private void FillDgvCodigoPostal()
        {
            string estadoTem = cbx_Estado.Text;
            string delegacionTemp = cbx_Delegacion.Text;
            int codigoPostal = recibeCodigoPostal;
            modelList = controlCampoExtra.GetDataSucursal(estadoTem, delegacionTemp, codigoPostal, this);
            if (modelList.Count > 0) dgv_CodigoPostal.DataSource = modelList;
        }

        private void FillCbxEstado()
        {
            List<DM0312_MCamposExtra> model_ = new List<DM0312_MCamposExtra>();
            model_ = controlCampoExtra.FillComboEstado();
            foreach (DM0312_MCamposExtra item in model_) cbx_Estado.Items.Add(item.Estado);
        }

        private void FillCbxDelegacion()
        {
            string estadoTemp = cbx_Estado.Text;
            List<DM0312_MCamposExtra> model_ = new List<DM0312_MCamposExtra>();
            model_ = controlCampoExtra.FillComboDelegacion(estadoTemp);
            foreach (DM0312_MCamposExtra item in model_) cbx_Delegacion.Items.Add(item.Delegacion);
        }

        #endregion

        #region "Handles"

        private void DM0312_AyudaCodigoPostal_Load(object sender, EventArgs e)
        {
            //cbx_Estado.DropDownStyle = ComboBoxStyle.DropDownList;
            //cbx_Delegacion.DropDownStyle = ComboBoxStyle.DropDownList;
            validaFiltros = false;
            estado = controlCampoExtra.ValidaEstado(ClaseEstatica.Usuario.Sucursal);
            delegacion = controlCampoExtra.ValidaDelegacion(ClaseEstatica.Usuario.Sucursal);
            cbx_Estado.Text = estado;
            cbx_Delegacion.Text = delegacion;
            FillDgvCodigoPostal();


            toolTip1.SetToolTip(cbx_Estado, "INGRESAR ESTADO A BUSCAR ");
            toolTip1.SetToolTip(cbx_Delegacion, "INGRESAR DELEGACION A BUSCAR");
            toolTip1.SetToolTip(txt_Buscar, "INGRESAR COLONIA A BUSCAR");
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR (ESC)");
            txt_Comentarios.Text =
                "ASISTENTE DE DIRECCION, BUSCAR LA DIRECCION DEL CLIENTE, SE PUEDE FILTRAR POR ESTADO, DELEGACION Y COLONIA, DAR DOBLE CLICK A LA DIRECCION QUE DESEA AGREGAR";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_CodigoPostal.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_CodigoPostal.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_CodigoPostal.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_CodigoPostal.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }


        private void cbx_Estado_Click(object sender, EventArgs e)
        {
            activeEstado++;
            if (activeEstado == 1)
            {
                cbx_Estado.Items.Clear();
                FillCbxEstado();
            }
        }

        private void cbx_Delegacion_Click(object sender, EventArgs e)
        {
            cbx_Delegacion.Items.Clear();
            FillCbxDelegacion();
        }

        private void cbx_Delegacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            recibeCodigoPostal = 0;
            FillDgvCodigoPostal();
            estado = controlCampoExtra.ValidaEstado(ClaseEstatica.Usuario.Sucursal);
            delegacion = controlCampoExtra.ValidaDelegacion(ClaseEstatica.Usuario.Sucursal);
        }

        private void txt_CodigoPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (int)Keys.Enter)
                if (validaFiltros)
                    FillDgvCodigoPostal();
        }

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (int)Keys.Enter) FillDgvCodigoPostal();
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dgv_CodigoPostal_DoubleClick(object sender, EventArgs e)
        {
            int index = dgv_CodigoPostal.CurrentRow.Index;
            int colonia = 2;
            int codigoPostal = 3;
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_CamposExtra")
                {
                    DM0312_CamposExtra campoExtra = (DM0312_CamposExtra)forma;
                    campoExtra.camposExtraRecibe.Mov = recibeMov;
                    campoExtra.camposExtraRecibe.IdVenta = recibeIdVenta;
                    campoExtra.camposExtraRecibe.Cliente = recibeCliente;
                    campoExtra.camposExtraRecibe.TipoCalle = recibeTipoCalle;
                    campoExtra.camposExtraRecibe.NomCalle = recibeNomCalle;
                    campoExtra.camposExtraRecibe.NumExterior = recibeNumExterior;
                    campoExtra.camposExtraRecibe.NumInterior = recibeNumInterior;
                    campoExtra.camposExtraRecibe.Cruce = recibeCruce;
                    campoExtra.camposExtraRecibe.CodigoPostal =
                        dgv_CodigoPostal.Rows[index].Cells[codigoPostal].Value.ToString();
                    campoExtra.txt_CodigoPostal.Text =
                        dgv_CodigoPostal.Rows[index].Cells[codigoPostal].Value.ToString();
                    campoExtra.cbx_Colonia.Text = dgv_CodigoPostal.Rows[index].Cells[colonia].Value.ToString();
                    campoExtra.camposExtraRecibe.Colonia = dgv_CodigoPostal.Rows[index].Cells[colonia].Value.ToString();
                    campoExtra.camposExtraRecibe.Telefono = recibeTelefono;
                    campoExtra.Visible = true;
                }

            Dispose();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_CamposExtra")
                {
                    forma.Show();
                    break;
                }
        }

        private void dgv_CodigoPostal_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(modelList);
            funciones.OrderGridview(dgv_CodigoPostal, e.ColumnIndex, TempObjects,
                modelList.GetType().GetGenericArguments().Single());
        }

        private void cbx_Estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            //e.Handled = true;
        }

        private void cbx_Delegacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            //e.Handled = true;
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                recibeCodigoPostal = 0;
                FillDgvCodigoPostal();
                estado = controlCampoExtra.ValidaEstado(ClaseEstatica.Usuario.Sucursal);
                delegacion = controlCampoExtra.ValidaDelegacion(ClaseEstatica.Usuario.Sucursal);
            }
        }

        private void DM0312_AyudaCodigoPostal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dispose();
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_CamposExtra")
                {
                    forma.Show();
                    break;
                }
        }

        #endregion
    }
}