﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class frmObservaciones : Form
    {
        private readonly DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
        private List<string> listaObservaciones = new List<string>();

        public frmObservaciones()
        {
            InitializeComponent();
        }

        public string sObservacion { get; set; }

        ~frmObservaciones()
        {
            GC.Collect();
        }

        private void frmObservaciones_Load(object sender, EventArgs e)
        {
            listaObservaciones = controlador.obtenerObservaciones();

            try
            {
                if (listaObservaciones.Count > 0)
                {
                    dgObservaciones.Rows.Clear();
                    dgObservaciones.Columns.Clear();
                    dgObservaciones.Columns.Add("observaciones", "Observaciones");
                    foreach (string item in listaObservaciones)
                    {
                        int renglon = dgObservaciones.Rows.Add();
                        dgObservaciones.Rows[renglon].Cells["observaciones"].Value = item;
                    }

                    dgObservaciones.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                sObservacion = dgObservaciones.CurrentRow.Cells["observaciones"].Value.ToString();
                Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void dgObservaciones_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                sObservacion = dgObservaciones.CurrentRow.Cells["observaciones"].Value.ToString();
                Close();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}