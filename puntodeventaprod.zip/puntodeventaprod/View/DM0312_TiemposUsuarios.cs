﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta
{
    public partial class TiemposUsuarios : Form
    {
        private int index;

        private List<DM0312_MUsuariosTmp> ListData = new List<DM0312_MUsuariosTmp>();
        public string recibeCliente;
        public string recibeIdVenta;

        public string recibeMensajeIdVenta;
        public string recibeMov;
        public string recibeMovId;
        public string recibeUsuario;
        private readonly CrtlsTiemposUsuarios tiemposUsuarios = new CrtlsTiemposUsuarios();

        public TiemposUsuarios()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        ~TiemposUsuarios()
        {
            GC.Collect();
        }

        private void TiemposUsuarios_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        #region "Methods"

        public void llenaTextTiempos()
        {
            string temp = tiemposUsuarios.CalculaTiemposTotalesUsuarios(recibeMensajeIdVenta);
        }


        /// <summary>
        ///     permite llenar dataGrid Principal dgv_TiemposUsuarios
        /// </summary>
        /// <returns></returns>
        /// Developer: Victor Avila
        /// Date: 31/07/2017
        public void fillDataGrid()
        {
            //DataTable dataTable = tiemposUsuarios.LlenaDatGridUsuarioTiempo(Convert.ToInt32(recibeMensajeIdVenta));

            ListData = tiemposUsuarios.TiemposCorrectos(Convert.ToInt32(recibeMensajeIdVenta));

            dgv_TiemposUsuarios.DataSource = ListData;
            //this.dgv_TiemposUsuarios.Columns["FechaComenzo"].HeaderText = "Fecha Comenzo";
        }

        #endregion

        #region "Handles"

        private void TiemposUsuarios_Load(object sender, EventArgs e)
        {
            txt_Comentarios.Text =
                "SE MUESTRAN LOS TIEMPOS QUE DURO EN GENERAR CADA MOVIMIENTO COMO EL USUARIO QUE LO GENERA";
            lbl_Mov.Text = recibeMov;
            lbl_MovId.Text = recibeMovId;
            lbl_Cliente.Text = recibeCliente;
            fillDataGrid();
            llenaTextTiempos();
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            toolTip1.SetToolTip(btn_Ayuda, "Ayuda");

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_TiemposUsuarios.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_TiemposUsuarios.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_TiemposUsuarios.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_TiemposUsuarios.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void dgv_TiemposUsuarios_SelectionChanged_1(object sender, EventArgs e)
        {
            if (index > 0 && dgv_TiemposUsuarios.Rows.Count > 0) index = 0;
        }

        private void dgv_TiemposUsuarios_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            index = 0;
            index = dgv_TiemposUsuarios.CurrentRow.Index;
        }

        private void dgv_TiemposUsuarios_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }
        }

        #endregion
    }
}