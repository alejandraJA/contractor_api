﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class frmLineaCredito : Form
    {
        private readonly CLimiteCredito cLimite;
        private readonly int iCanalVenta;
        private List<MLimiteCredito> listaCanal;
        private readonly string sCliente;

        public frmLineaCredito(string sCliente, int iCanalVenta)
        {
            InitializeComponent();
            cLimite = new CLimiteCredito();
            this.iCanalVenta = iCanalVenta;
            this.sCliente = sCliente;
            listaCanal = new List<MLimiteCredito>();
            lblCanalVenta.Text = "Canal Venta " + iCanalVenta + ", Cliente: " + sCliente;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
        }

        private void frmLineaCredito_Load(object sender, EventArgs e)
        {
            List<MLimiteCredito> lista = cLimite.obteneLimiteCredito();
            listaCanal = iCanalVenta == 80
                ? lista.Where(y => y.TipoDima.Contains("Creditazzo")).ToList()
                : lista.Where(x => !x.TipoDima.Contains("Creditazzo")).ToList();

            cmbTipoDima.DataSource = listaCanal.Select(x => x.TipoDima).Distinct().ToList();
            cmbTipoDima.DisplayMember = "TipoDima";
            cmbTipoDima.SelectedIndex = 0;

            if (iCanalVenta == 76)
                txtImporteFactura.Text =
                    string.Format("{0:C}", Convert.ToInt32(cLimite.obtenerImporteCliente(sCliente)));
        }

        private void cmbTipoDima_SelectedValueChanged(object sender, EventArgs e)
        {
            List<MLimiteCredito> resultado = listaCanal.Where(x => x.TipoDima == cmbTipoDima.Text).ToList();
            if (resultado != null)
            {
                MLimiteCredito res = resultado.FirstOrDefault(x => x.Mov == "Credilana");
                if (res != null) txtImporteCredilana.Text = string.Format("{0:C}", Convert.ToInt32(res.LimiteCredito));
            }
        }

        private void txtImporteFactura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                e.KeyChar != '.')
                e.Handled = true;
        }

        private void btnAceptar_Click_1(object sender, EventArgs e)
        {
            double dIporteFactura = 0, dImporteCredilana = 0;
            double.TryParse(txtImporteFactura.Text.Replace("$", ""), out dIporteFactura);
            double.TryParse(txtImporteCredilana.Text.Replace("$", ""), out dImporteCredilana);
            if (cLimite.actualizarSaldos(sCliente, dImporteCredilana, dIporteFactura, cmbTipoDima.Text) > 0)
            {
                MessageBox.Show("Saldos actualizados correctamente.", "Punto De Venta", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Close();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}