﻿namespace PuntoVenta.View
{
    partial class DM0312_CamposExtra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lbl_Tel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_CamposExtra));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb_TelefonoParticular = new System.Windows.Forms.RadioButton();
            this.rb_TelefonoMovil = new System.Windows.Forms.RadioButton();
            this.txt_TipoIdentificacion2 = new System.Windows.Forms.TextBox();
            this.txt_TipoIdentificacion = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbx_Colonia = new System.Windows.Forms.ComboBox();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Relacionado = new System.Windows.Forms.TextBox();
            this.txt_NombreConyuge = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtp_FechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.lbl_Tipo = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_CodigoPostal = new System.Windows.Forms.TextBox();
            this.txt_Cruces = new System.Windows.Forms.TextBox();
            this.txt_NumInterior = new System.Windows.Forms.TextBox();
            this.txt_numExterior = new System.Windows.Forms.TextBox();
            this.txt_NombreCalle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbx_TipoCalle = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.Aceptar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            lbl_Tel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Tel
            // 
            lbl_Tel.AutoSize = true;
            lbl_Tel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl_Tel.Location = new System.Drawing.Point(32, 149);
            lbl_Tel.Name = "lbl_Tel";
            lbl_Tel.Size = new System.Drawing.Size(57, 13);
            lbl_Tel.TabIndex = 17;
            lbl_Tel.Text = "Telefono";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.groupBox1.Controls.Add(this.rb_TelefonoParticular);
            this.groupBox1.Controls.Add(this.rb_TelefonoMovil);
            this.groupBox1.Controls.Add(this.txt_TipoIdentificacion2);
            this.groupBox1.Controls.Add(this.txt_TipoIdentificacion);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbx_Colonia);
            this.groupBox1.Controls.Add(this.txt_Telefono);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txt_Relacionado);
            this.groupBox1.Controls.Add(this.txt_NombreConyuge);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.dtp_FechaNacimiento);
            this.groupBox1.Controls.Add(this.lbl_Tipo);
            this.groupBox1.Controls.Add(lbl_Tel);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_CodigoPostal);
            this.groupBox1.Controls.Add(this.txt_Cruces);
            this.groupBox1.Controls.Add(this.txt_NumInterior);
            this.groupBox1.Controls.Add(this.txt_numExterior);
            this.groupBox1.Controls.Add(this.txt_NombreCalle);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbx_TipoCalle);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(73, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(605, 383);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // rb_TelefonoParticular
            // 
            this.rb_TelefonoParticular.AutoSize = true;
            this.rb_TelefonoParticular.Location = new System.Drawing.Point(317, 143);
            this.rb_TelefonoParticular.Name = "rb_TelefonoParticular";
            this.rb_TelefonoParticular.Size = new System.Drawing.Size(69, 17);
            this.rb_TelefonoParticular.TabIndex = 30;
            this.rb_TelefonoParticular.Text = "Particular";
            this.rb_TelefonoParticular.UseVisualStyleBackColor = true;
            // 
            // rb_TelefonoMovil
            // 
            this.rb_TelefonoMovil.AutoSize = true;
            this.rb_TelefonoMovil.Checked = true;
            this.rb_TelefonoMovil.Location = new System.Drawing.Point(261, 143);
            this.rb_TelefonoMovil.Name = "rb_TelefonoMovil";
            this.rb_TelefonoMovil.Size = new System.Drawing.Size(50, 17);
            this.rb_TelefonoMovil.TabIndex = 29;
            this.rb_TelefonoMovil.TabStop = true;
            this.rb_TelefonoMovil.Text = "Móvil";
            this.rb_TelefonoMovil.UseVisualStyleBackColor = true;
            // 
            // txt_TipoIdentificacion2
            // 
            this.txt_TipoIdentificacion2.Location = new System.Drawing.Point(282, 252);
            this.txt_TipoIdentificacion2.Name = "txt_TipoIdentificacion2";
            this.txt_TipoIdentificacion2.Size = new System.Drawing.Size(150, 20);
            this.txt_TipoIdentificacion2.TabIndex = 28;
            // 
            // txt_TipoIdentificacion
            // 
            this.txt_TipoIdentificacion.FormattingEnabled = true;
            this.txt_TipoIdentificacion.Items.AddRange(new object[] {
            "IFE",
            "PASAPORTE",
            "LICENCIA"});
            this.txt_TipoIdentificacion.Location = new System.Drawing.Point(155, 252);
            this.txt_TipoIdentificacion.Name = "txt_TipoIdentificacion";
            this.txt_TipoIdentificacion.Size = new System.Drawing.Size(121, 21);
            this.txt_TipoIdentificacion.TabIndex = 27;
            this.txt_TipoIdentificacion.Click += new System.EventHandler(this.txt_TipoIdentificacion_Click);
            this.txt_TipoIdentificacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_TipoIdentificacion_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 15);
            this.label9.TabIndex = 26;
            this.label9.Text = "*";
            // 
            // cbx_Colonia
            // 
            this.cbx_Colonia.FormattingEnabled = true;
            this.cbx_Colonia.Location = new System.Drawing.Point(155, 198);
            this.cbx_Colonia.Name = "cbx_Colonia";
            this.cbx_Colonia.Size = new System.Drawing.Size(170, 21);
            this.cbx_Colonia.TabIndex = 7;
            this.cbx_Colonia.Click += new System.EventHandler(this.cbx_Colonia_Click_1);
            this.cbx_Colonia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_Colonia_KeyPress);
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(155, 142);
            this.txt_Telefono.MaxLength = 10;
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(100, 20);
            this.txt_Telefono.TabIndex = 5;
            this.txt_Telefono.Click += new System.EventHandler(this.txt_Telefono_Click);
            this.txt_Telefono.TextChanged += new System.EventHandler(this.txt_Telefono_TextChanged);
            this.txt_Telefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Telefono_KeyPress);
            this.txt_Telefono.Leave += new System.EventHandler(this.txt_Telefono_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(34, 334);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Relacionado a";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(34, 308);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Nombre Conyuge";
            // 
            // txt_Relacionado
            // 
            this.txt_Relacionado.Location = new System.Drawing.Point(155, 331);
            this.txt_Relacionado.Name = "txt_Relacionado";
            this.txt_Relacionado.Size = new System.Drawing.Size(100, 20);
            this.txt_Relacionado.TabIndex = 12;
            this.txt_Relacionado.Click += new System.EventHandler(this.txt_Relacionado_Click);
            this.txt_Relacionado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Relacionado_KeyPress);
            // 
            // txt_NombreConyuge
            // 
            this.txt_NombreConyuge.Location = new System.Drawing.Point(155, 305);
            this.txt_NombreConyuge.Name = "txt_NombreConyuge";
            this.txt_NombreConyuge.Size = new System.Drawing.Size(100, 20);
            this.txt_NombreConyuge.TabIndex = 11;
            this.txt_NombreConyuge.Click += new System.EventHandler(this.txt_NombreConyuge_Click);
            this.txt_NombreConyuge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_NombreConyuge_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(32, 279);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Fecha Nacimiento";
            // 
            // dtp_FechaNacimiento
            // 
            this.dtp_FechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaNacimiento.Location = new System.Drawing.Point(155, 279);
            this.dtp_FechaNacimiento.Name = "dtp_FechaNacimiento";
            this.dtp_FechaNacimiento.Size = new System.Drawing.Size(100, 20);
            this.dtp_FechaNacimiento.TabIndex = 10;
            this.dtp_FechaNacimiento.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dtp_FechaNacimiento_MouseUp);
            // 
            // lbl_Tipo
            // 
            this.lbl_Tipo.AutoSize = true;
            this.lbl_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tipo.Location = new System.Drawing.Point(32, 256);
            this.lbl_Tipo.Name = "lbl_Tipo";
            this.lbl_Tipo.Size = new System.Drawing.Size(113, 13);
            this.lbl_Tipo.TabIndex = 19;
            this.lbl_Tipo.Text = "Tipo Identificacion";
            // 
            // label8
            // 
            this.label8.AccessibleName = "txt_Telefono";
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(168, 365);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 15);
            this.label8.TabIndex = 15;
            // 
            // txt_CodigoPostal
            // 
            this.txt_CodigoPostal.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.txt_CodigoPostal.Enabled = false;
            this.txt_CodigoPostal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodigoPostal.Location = new System.Drawing.Point(155, 225);
            this.txt_CodigoPostal.MaxLength = 5;
            this.txt_CodigoPostal.Name = "txt_CodigoPostal";
            this.txt_CodigoPostal.ReadOnly = true;
            this.txt_CodigoPostal.Size = new System.Drawing.Size(92, 22);
            this.txt_CodigoPostal.TabIndex = 8;
            this.txt_CodigoPostal.Click += new System.EventHandler(this.txt_CodigoPostal_Click);
            this.txt_CodigoPostal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CodigoPostal_KeyPress);
            // 
            // txt_Cruces
            // 
            this.txt_Cruces.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cruces.Location = new System.Drawing.Point(155, 169);
            this.txt_Cruces.Name = "txt_Cruces";
            this.txt_Cruces.Size = new System.Drawing.Size(277, 22);
            this.txt_Cruces.TabIndex = 6;
            this.txt_Cruces.Click += new System.EventHandler(this.txt_Cruces_Click);
            this.txt_Cruces.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Cruces_KeyPress);
            // 
            // txt_NumInterior
            // 
            this.txt_NumInterior.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumInterior.Location = new System.Drawing.Point(155, 113);
            this.txt_NumInterior.Name = "txt_NumInterior";
            this.txt_NumInterior.Size = new System.Drawing.Size(95, 22);
            this.txt_NumInterior.TabIndex = 4;
            this.txt_NumInterior.Click += new System.EventHandler(this.txt_NumInterior_Click);
            this.txt_NumInterior.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_NumInterior_KeyPress);
            // 
            // txt_numExterior
            // 
            this.txt_numExterior.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numExterior.Location = new System.Drawing.Point(155, 83);
            this.txt_numExterior.Name = "txt_numExterior";
            this.txt_numExterior.Size = new System.Drawing.Size(92, 22);
            this.txt_numExterior.TabIndex = 3;
            this.txt_numExterior.Click += new System.EventHandler(this.txt_numExterior_Click);
            this.txt_numExterior.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_numExterior_KeyPress);
            // 
            // txt_NombreCalle
            // 
            this.txt_NombreCalle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NombreCalle.Location = new System.Drawing.Point(155, 55);
            this.txt_NombreCalle.Name = "txt_NombreCalle";
            this.txt_NombreCalle.Size = new System.Drawing.Size(277, 22);
            this.txt_NombreCalle.TabIndex = 2;
            this.txt_NombreCalle.Click += new System.EventHandler(this.txt_NombreCalle_Click);
            this.txt_NombreCalle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_NombreCalle_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Codigo Postal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Colonia";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Cruces";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Numero Interior";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Numero Exterior";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre de Calle";
            // 
            // cbx_TipoCalle
            // 
            this.cbx_TipoCalle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_TipoCalle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_TipoCalle.FormattingEnabled = true;
            this.cbx_TipoCalle.Location = new System.Drawing.Point(155, 26);
            this.cbx_TipoCalle.Name = "cbx_TipoCalle";
            this.cbx_TipoCalle.Size = new System.Drawing.Size(121, 23);
            this.cbx_TipoCalle.TabIndex = 1;
            this.cbx_TipoCalle.Click += new System.EventHandler(this.cbx_TipoCalle_Click);
            this.cbx_TipoCalle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_TipoCalle_KeyPress);
            this.cbx_TipoCalle.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbx_TipoCalle_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo Calle";
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.White;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(73, 3);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.ReadOnly = true;
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(605, 65);
            this.txt_ComentarioAyuda.TabIndex = 51;
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.Color.White;
            this.btn_Cancelar.FlatAppearance.BorderSize = 0;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cancelar.Image")));
            this.btn_Cancelar.Location = new System.Drawing.Point(3, 74);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(57, 76);
            this.btn_Cancelar.TabIndex = 28;
            this.btn_Cancelar.Text = "Cancelar (Esc)";
            this.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // Aceptar
            // 
            this.Aceptar.BackColor = System.Drawing.Color.White;
            this.Aceptar.FlatAppearance.BorderSize = 0;
            this.Aceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aceptar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aceptar.Image = ((System.Drawing.Image)(resources.GetObject("Aceptar.Image")));
            this.Aceptar.Location = new System.Drawing.Point(3, 3);
            this.Aceptar.Name = "Aceptar";
            this.Aceptar.Size = new System.Drawing.Size(56, 65);
            this.Aceptar.TabIndex = 29;
            this.Aceptar.Text = "Aceptar (Crtl-G)";
            this.Aceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Aceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Aceptar.UseVisualStyleBackColor = false;
            this.Aceptar.Click += new System.EventHandler(this.Aceptar_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.37891F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.62109F));
            this.tableLayoutPanel1.Controls.Add(this.Aceptar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txt_ComentarioAyuda, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_Cancelar, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.65217F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 84.34782F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(681, 460);
            this.tableLayoutPanel1.TabIndex = 52;
            // 
            // DM0312_CamposExtra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(681, 460);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_CamposExtra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Campos Extras";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_CamposExtra_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_CamposExtra_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_CamposExtra_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_Cruces;
        private System.Windows.Forms.TextBox txt_NumInterior;
        private System.Windows.Forms.TextBox txt_numExterior;
        private System.Windows.Forms.TextBox txt_NombreCalle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_TipoCalle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button Aceptar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_Relacionado;
        private System.Windows.Forms.TextBox txt_NombreConyuge;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtp_FechaNacimiento;
        private System.Windows.Forms.Label lbl_Tipo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Telefono;
        public System.Windows.Forms.TextBox txt_CodigoPostal;
        public System.Windows.Forms.ComboBox cbx_Colonia;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.ComboBox txt_TipoIdentificacion;
        private System.Windows.Forms.TextBox txt_TipoIdentificacion2;
        private System.Windows.Forms.RadioButton rb_TelefonoParticular;
        private System.Windows.Forms.RadioButton rb_TelefonoMovil;
    }
}