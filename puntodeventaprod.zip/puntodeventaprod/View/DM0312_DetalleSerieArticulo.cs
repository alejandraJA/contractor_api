﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_DetalleSerieArticulo : Form
    {
        public static int cantidadArticulo;
        public static int RenglonID;

        public static List<MSerieArticulos> Catalogos = new List<MSerieArticulos>();
        public static List<MSerieArticulos> OldSeriesArticulos = new List<MSerieArticulos>();

        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();

        private readonly CSerieArticulos ControladorSerieArticulos = new CSerieArticulos();
        /**********************/

        private readonly Funciones funciones = new Funciones();

        /*DM0312_PuntoDeVenta*/
        public MSerieArticulos modelEliminar;

        private bool NuevasSeries;

        public DM0312_DetalleSerieArticulo()
        {
            InitializeComponent();
            Constructor();
        }

        public static string ArticuloSeleccionado { get; set; }
        public static string DescripcionArticulo { get; set; }
        public static int IDVenta { get; set; }
        public static string AlmacenArticulo { get; set; }
        public static int? SucursalOrigen { get; set; }
        public static bool MovConcluido { get; set; }

        ~DM0312_DetalleSerieArticulo()
        {
            GC.Collect();
        }

        private void SerieArt_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(Aceptar, "SELECCIONAR PARA GUARDAR LOS CAMBIOS");
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            toolTip1.SetToolTip(btn_Regresar, "REGRESAE");
            toolTip1.SetToolTip(btn_InformacionSerie, "SELECCIONAR PARA VER LA INFORMACION DE LA SERIE");
            txt_Comentarios.Text =
                "ASISTENTE DE SERIES, DONDE SE MUESTRAN LAS SERIES POSIBLES DEL ARTICULO, SELECCIONAR LA SERIE O LAS SERIES DEPENDIENDO DEL NUMERO DE ARTICULOS QUE SE VENDIERON";
            if (ClaseEstatica.Usuario.color == "Azul")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            }

            if (ClaseEstatica.Usuario.color == "Rosa")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            }

            if (ClaseEstatica.Usuario.color == "Verde")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            }

            if (ClaseEstatica.Usuario.color == "Gris")
            {
                dgv_serieArticulo.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
                dgv_catalogo.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
            }
        }

        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        public void GuardarDetalleS()
        {
            DM0312_DetalleLoginMotos.LoginCorrecto = false;
            if (CDetalleVenta.LoginSerieMotos())
            {
                DM0312_DetalleLoginMotos loginMotos = new DM0312_DetalleLoginMotos();
                TopMost = false;
                loginMotos.ShowDialog();
            }
            else
            {
                DM0312_DetalleLoginMotos.LoginCorrecto = true;
            }

            if (DM0312_DetalleLoginMotos.LoginCorrecto)
            {
                if (dgv_catalogo.Rows.Count > 0)
                {
                    string SerieLote = dgv_catalogo.SelectedRows[dgv_catalogo.SelectedRows.Count - 1]
                        .Cells[(int)Enums.SerieLoteColumnas.SerieLote].ToString();
                    string PropiedadesOCuadro = dgv_catalogo.SelectedRows[dgv_catalogo.SelectedRows.Count - 1]
                        .Cells[(int)Enums.SerieLoteColumnas.Propiedades].ToString();
                    //ControladorSerieArticulos.ActualizarSerie(IDVenta, ArticuloSeleccionado);
                    ControladorSerieArticulos.ActualizarSerie(IDVenta, ArticuloSeleccionado);
                    //if (dgv_serieArticulo.Rows.Count > 0)
                    //{
                    //    var item = (MSerieArticulos)dgv_serieArticulo.SelectedRows[0].DataBoundItem;
                    //    PuntoDeVenta_Serie = item.Serie;
                    //    PuntoDeVenta_Cancel = true;
                    //}
                }

                Close();
            }
            else
            {
                MessageBox.Show("Login incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///     Actualiza la serie del articulo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 17/08/17
        private void Aceptar_Click(object sender, EventArgs e)
        {
            DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();
            controlador.DeleteSeriesLotes("SeriePrro", IDVenta, ArticuloSeleccionado);
            OldSeriesArticulos.Clear();
            GuardarDetalleS();
        }

        /// <summary>
        ///     Cambio de fila seleccionada
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        protected void ChangeSelectedCheckbox()
        {
            int selectedRowCount = dgv_serieArticulo.Rows.GetRowCount(DataGridViewElementStates.Selected);
            foreach (DataGridViewRow dgrow in dgv_serieArticulo.Rows)
                if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                {
                    DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                    if (selectedRowCount > 0 &&
                        dgrow.Index == dgv_serieArticulo.SelectedRows[selectedRowCount - 1].Index)
                    {
                        if ((bool)dcb.Value)
                            dcb.Value = false;
                        else
                            dcb.Value = true;
                    }
                    else
                    {
                        dcb.Value = false;
                    }
                }
        }

        /// <summary>
        ///     datagridview serie seleccion de celda
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 18/08/17
        private void Dgv_serieArticulo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            if (ClaseEstatica.SeriesArticulos.Count > 0)
            {
                modelEliminar = (MSerieArticulos)dgv_serieArticulo.SelectedRows[0].DataBoundItem;

                ChangeSelectedCheckbox();

                dgv_serieArticulo.RefreshEdit();
                dgv_serieArticulo.NotifyCurrentCellDirty(true);

                bool checkboxSelected = false;
                foreach (DataGridViewRow dgrow in dgv_serieArticulo.Rows)
                    if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                        if (Convert.ToBoolean(dgrow.Cells[0].Value))
                            checkboxSelected = true;

                lbl_catalogo.Visible = false;
                dgv_catalogo.Visible = false;
                int selectedRowCount = dgv_serieArticulo.Rows.GetRowCount(DataGridViewElementStates.Selected);
                int ColumnaSerie = 1;
                string SerieSeleccionada = dgv_serieArticulo.SelectedRows[selectedRowCount - 1].Cells[ColumnaSerie]
                    .Value.ToString();
                if (ClaseEstatica.Usuario.Sucursal != 0)
                {
                    if (dgv_serieArticulo.Columns[0].Visible == false) SerieSeleccionada = string.Empty;
                    Catalogos = ControladorSerieArticulos.ObtenerCatalogos(IDVenta, ArticuloSeleccionado,
                        AlmacenArticulo, SucursalOrigen, SerieSeleccionada);

                    if (Catalogos.Count > 0 && !MovConcluido && (checkboxSelected || NuevasSeries))
                    {
                        lbl_catalogo.Visible = true;
                        lbl_catalogo.Text = "Catalogo de serie del almacen: " + AlmacenArticulo;
                        dgv_catalogo.Visible = true;

                        if (NuevasSeries)
                        {
                            foreach (MSerieArticulos SerieArt in ClaseEstatica.SeriesArticulos)
                            foreach (MSerieArticulos SerieCatalogo in Catalogos)
                                if (SerieCatalogo.Serie == SerieArt.Serie)
                                {
                                    SerieCatalogo.Editar = true;
                                    break;
                                }
                        }
                        else
                        {
                            foreach (MSerieArticulos SerieArt in ClaseEstatica.SeriesArticulos)
                                for (int i = Catalogos.Count - 1; i >= 0; i--)
                                    if (Catalogos[i].Serie == SerieArt.Serie)
                                    {
                                        Catalogos.RemoveAt(i);
                                        break;
                                    }
                        }

                        dgv_catalogo.DataSource = Catalogos;
                        int ColumnaSeleccion = 0;
                        dgv_catalogo.Columns[0].Name = "Seleccionar";
                        foreach (DataGridViewRow dgrow in dgv_catalogo.Rows)
                            if (dgrow.Cells[ColumnaSerie].Value.ToString() == SerieSeleccionada)
                            {
                                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dgrow.Cells[ColumnaSeleccion];
                                chk.Value = true;
                                break;
                            }

                        dgv_catalogo.Columns[0].Width = 140;
                        dgv_catalogo.Columns[1].Width = 140;
                        dgv_catalogo.Columns[dgv_catalogo.Columns.Count - 1].Width = 200;
                    }
                }
            }
        }

        /// <summary>
        ///     Cambio de fila seleccionada
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 03/08/2017
        protected void ChangeSelectedCheckboxCatalogo()
        {
            if (!NuevasSeries)
            {
                int selectedRowCount = dgv_catalogo.Rows.GetRowCount(DataGridViewElementStates.Selected);
                int selectedRowCountSerie = dgv_serieArticulo.Rows.GetRowCount(DataGridViewElementStates.Selected);

                int ColumnaSerie = 1;
                string SerieSeleccionada = dgv_serieArticulo.SelectedRows[selectedRowCountSerie - 1].Cells[ColumnaSerie]
                    .Value.ToString();
                string NuevaSerie = dgv_catalogo.SelectedRows[selectedRowCount - 1].Cells[ColumnaSerie].Value
                    .ToString();

                foreach (DataGridViewRow dgrow in dgv_catalogo.Rows)
                    if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                    {
                        DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                        if (selectedRowCount > 0 &&
                            dgrow.Index == dgv_catalogo.SelectedRows[selectedRowCount - 1].Index)
                        {
                            dcb.Value = true;
                            MSerieArticulos NuevaSerieSeleccionada =
                                Catalogos.FirstOrDefault(x => x.Serie == NuevaSerie);
                            ControladorSerieArticulos.CambiarSerie(SerieSeleccionada, NuevaSerieSeleccionada);
                            dgv_serieArticulo.DataSource = null;
                            dgv_serieArticulo.DataSource = ClaseEstatica.SeriesArticulos;
                            dgv_serieArticulo.Columns[dgv_serieArticulo.Columns.Count - 1].Width = 200;
                            dgv_serieArticulo.Columns[0].Width = 100;
                            dgv_serieArticulo.Columns[1].Width = 140;
                            dgv_serieArticulo.Columns[2].Width = 140;
                        }
                        else
                        {
                            dcb.Value = false;
                        }
                    }
            }
            else
            {
                int selectedRowCount = dgv_catalogo.Rows.GetRowCount(DataGridViewElementStates.Selected);
                int selectedRowCountSerie = dgv_serieArticulo.Rows.GetRowCount(DataGridViewElementStates.Selected);

                int Seleccionados = 0;
                foreach (DataGridViewRow dgrow in dgv_catalogo.Rows)
                    if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                    {
                        DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                        if (dcb.Value.ToString() == "True")
                            Seleccionados = Seleccionados + 1;
                        else if (selectedRowCount > 0 &&
                                 dgrow.Index == dgv_catalogo.SelectedRows[selectedRowCount - 1].Index)
                            Seleccionados = Seleccionados + 1;
                    }

                if (CDetalleVenta.EsMoto) cantidadArticulo = 1;

                if (Seleccionados > cantidadArticulo)
                {
                    if (CDetalleVenta.EsMoto)
                        MessageBox.Show("Solo se puede seleccionar una serie para motos", "Informacion",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Solo puede seleccionar series para " + cantidadArticulo + " articulo/s",
                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    ClaseEstatica.SeriesArticulos = new List<MSerieArticulos>();
                    foreach (DataGridViewRow dgrow in dgv_catalogo.Rows)
                        if (dgrow.Cells[0] is DataGridViewCheckBoxCell)
                        {
                            DataGridViewCheckBoxCell dcb = (DataGridViewCheckBoxCell)dgrow.Cells[0];
                            if (selectedRowCount > 0 &&
                                dgrow.Index == dgv_catalogo.SelectedRows[selectedRowCount - 1].Index)
                            {
                                if (dcb.Value.ToString() == "True")
                                    dcb.Value = false;
                                else
                                    dcb.Value = true;
                            }

                            if (dcb.Value.ToString() == "True")
                            {
                                MSerieArticulos NuevoCatalogo = new MSerieArticulos
                                {
                                    Serie = dgrow.Cells[1].Value.ToString(),
                                    Pedimento = dgrow.Cells[3].Value.ToString(),
                                    Color = dgrow.Cells[5].Value.ToString(),
                                    Modelo = dgrow.Cells[4].Value.ToString(),
                                    Aduana = dgrow.Cells[6].Value.ToString()
                                };
                                if (dgrow.Cells[7].Value != null && dgrow.Cells[7].Value.ToString() != string.Empty)
                                    NuevoCatalogo.FechaAduana = Convert.ToDateTime(dgrow.Cells[7].Value.ToString())
                                        .ToString("dd-MM-yyyy");
                                NuevoCatalogo.Cuadro = dgrow.Cells[2].Value.ToString();
                                ClaseEstatica.SeriesArticulos.Add(NuevoCatalogo);
                            }
                        }

                    dgv_serieArticulo.DataSource = null;
                    dgv_serieArticulo.DataSource = ClaseEstatica.SeriesArticulos;
                    dgv_serieArticulo.Columns[0].Visible = false;
                    dgv_serieArticulo.Columns[dgv_serieArticulo.Columns.Count - 1].Width = 200;
                    //dgv_serieArticulo.Columns[0].Width = 100;
                    dgv_serieArticulo.Columns[1].Width = 140;
                    dgv_serieArticulo.Columns[2].Width = 140;
                }
            }
        }

        /// <summary>
        ///     Click de gridview
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 19/08/17
        private void Dgv_catalogo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            ChangeSelectedCheckboxCatalogo();

            dgv_catalogo.RefreshEdit();
            dgv_catalogo.NotifyCurrentCellDirty(true);

            if (!NuevasSeries)
            {
                int selectedRowCount = dgv_serieArticulo.Rows.GetRowCount(DataGridViewElementStates.Selected);
                int ColumnaSerie = 1;
                string SerieSeleccionada = dgv_serieArticulo.SelectedRows[selectedRowCount - 1].Cells[ColumnaSerie]
                    .Value.ToString();
                if (dgv_serieArticulo.Columns[0].Visible == false) SerieSeleccionada = string.Empty;
                Catalogos = ControladorSerieArticulos.ObtenerCatalogos(IDVenta, ArticuloSeleccionado, AlmacenArticulo,
                    SucursalOrigen, SerieSeleccionada);

                foreach (MSerieArticulos SerieArt in ClaseEstatica.SeriesArticulos)
                    for (int i = Catalogos.Count - 1; i >= 0; i--)
                        if (Catalogos[i].Serie == SerieArt.Serie)
                        {
                            Catalogos.RemoveAt(i);
                            break;
                        }

                dgv_catalogo.DataSource = Catalogos;
                dgv_catalogo.Columns[0].Name = "Seleccionar";
                dgv_catalogo.Columns[0].Width = 140;
                dgv_catalogo.Columns[1].Width = 140;
                dgv_catalogo.Columns[dgv_catalogo.Columns.Count - 1].Width = 200;
            }
        }

        /// <summary>
        ///     Actualiza datagridview
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 19/08/17
        private void Dgv_serieArticulo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgv_serieArticulo.RefreshEdit();
        }

        /// <summary>
        ///     Content click de catalogo
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 14/10/17
        private void Dgv_catalogo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgv_catalogo.RefreshEdit();
        }

        /// <summary>
        ///     obtiene la informacion del articulo de la serie
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 04/09/17
        private void Btn_InformacionSerie_Click(object sender, EventArgs e)
        {
            if (dgv_serieArticulo.SelectedRows.Count > 0)
            {
                DM0312_DetalleInfoSerieArticulo.SerieSeleccionada = dgv_serieArticulo
                    .SelectedRows[dgv_serieArticulo.SelectedRows.Count - 1].Cells["Serie"].Value.ToString();
                DM0312_DetalleInfoSerieArticulo InfoSerieArticulo = new DM0312_DetalleInfoSerieArticulo();
                Visible = false;
                InfoSerieArticulo.ShowDialog();
                Visible = true;
            }
        }

        /// <summary>
        ///     Elimina la serie asiganada
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Rodolfo Sanchez
        /// Date: 19/10/17
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (modelEliminar.Serie == null) return;
            CSerieArticulos ControladorSerie = new CSerieArticulos();
            DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();

            controlador.DeleteSeriesLotes(modelEliminar.Serie);

            ClaseEstatica.SeriesArticulos = new List<MSerieArticulos>();

            ClaseEstatica.SeriesArticulos = ControladorSerie.ObtenerSeriesArticulos(IDVenta, ArticuloSeleccionado);

            //this.DM0312_DetalleSerieArticulo();

            //this = new DM0312_DetalleSerieArticulo();
            Constructor();
        }

        public void Constructor()
        {
            modelEliminar = new MSerieArticulos();
            MaximizeBox = false;
            MinimizeBox = false;

            lbl_catalogo.Visible = false;
            dgv_catalogo.Visible = false;
            dgv_catalogo.DataSource = null;
            if (MovConcluido
                //|| 
                //    (
                //        ClaseEstatica.Usuario.Grupo != "VENTAS PISO" &&
                //        ClaseEstatica.Usuario.Grupo != "CONTABILIDAD" &&
                //        ClaseEstatica.Usuario.Grupo != "FACTURACION"
                //    )
               )
                Aceptar.Visible = false;


            lbl_articulo.Text = "Articulo: " + ArticuloSeleccionado;
            lbl_descripcion.Text = "Descripcion: " + DescripcionArticulo;

            OldSeriesArticulos.Clear();
            foreach (MSerieArticulos SArticulos in ClaseEstatica.SeriesArticulos)
            {
                MSerieArticulos NuevaSerie = new MSerieArticulos
                {
                    Cuadro = SArticulos.Cuadro,
                    Aduana = SArticulos.Aduana,
                    Color = SArticulos.Color
                };
                NuevaSerie.Cuadro = SArticulos.Cuadro;
                if (SArticulos.FechaAduana != string.Empty)
                    NuevaSerie.FechaAduana = Convert.ToDateTime(SArticulos.FechaAduana).ToString("dd-MM-yyyy");
                NuevaSerie.Modelo = SArticulos.Modelo;
                NuevaSerie.Pedimento = SArticulos.Pedimento;
                NuevaSerie.Serie = SArticulos.Serie;
                OldSeriesArticulos.Add(NuevaSerie);
            }

            dgv_serieArticulo.EndEdit();
            dgv_serieArticulo.DataSource = null;
            dgv_serieArticulo.DataSource = ClaseEstatica.SeriesArticulos;
            dgv_serieArticulo.Columns[dgv_serieArticulo.Columns.Count - 1].Width = 200;
            dgv_serieArticulo.Columns[0].Width = 100;
            dgv_serieArticulo.Columns[1].Width = 140;
            dgv_serieArticulo.Columns[2].Width = 140;

            if (ClaseEstatica.SeriesArticulos.Count <= cantidadArticulo)
            {
                dgv_serieArticulo.Columns[0].Visible = false;
                NuevasSeries = true;
                lbl_catalogo.Visible = false;
                dgv_catalogo.Visible = false;
                Catalogos = ControladorSerieArticulos.ObtenerCatalogos(IDVenta, ArticuloSeleccionado, AlmacenArticulo,
                    SucursalOrigen);

                if (Catalogos.Count > 0 && !MovConcluido)
                {
                    lbl_catalogo.Visible = true;
                    lbl_catalogo.Text = "Catalogo de serie del almacen: " + AlmacenArticulo;
                    dgv_catalogo.Visible = true;

                    dgv_catalogo.DataSource = null;
                    dgv_catalogo.DataSource = Catalogos;
                    foreach (MSerieArticulos Serie in ClaseEstatica.SeriesArticulos)
                    {
                        MSerieArticulos SerieCatalogo = Catalogos.FirstOrDefault(x => x.Serie == Serie.Serie);
                        SerieCatalogo.Editar = true;
                    }

                    dgv_catalogo.Columns[0].Name = "Seleccionar";
                    dgv_catalogo.Columns[0].Width = 140;
                    dgv_catalogo.Columns[1].Width = 140;
                    dgv_catalogo.Columns[dgv_catalogo.Columns.Count - 1].Width = 200;
                }
            }
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_serieArticulo_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(ClaseEstatica.SeriesArticulos.ToList());
            funciones.OrderGridview(dgv_serieArticulo, e.ColumnIndex, ref TempObjects,
                ClaseEstatica.SeriesArticulos.GetType().GetGenericArguments().Single());
            ClaseEstatica.SeriesArticulos = TempObjects.OfType<MSerieArticulos>().ToList();

            dgv_serieArticulo.DataSource = null;
            dgv_serieArticulo.DataSource = ClaseEstatica.SeriesArticulos;
            dgv_serieArticulo.Columns[0].Visible = false;
            dgv_serieArticulo.Columns[dgv_serieArticulo.Columns.Count - 1].Width = 200;
            //dgv_serieArticulo.Columns[0].Width = 100;
            dgv_serieArticulo.Columns[1].Width = 140;
            dgv_serieArticulo.Columns[2].Width = 140;
        }

        /// <summary>
        ///     Ordenamiento columnas
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">DataGridViewCellMouseEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 13/11/17
        private void Dgv_catalogo_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 0)
                return;
            List<object> TempObjects = new List<object>(Catalogos.ToList());
            funciones.OrderGridview(dgv_catalogo, e.ColumnIndex, TempObjects,
                Catalogos.GetType().GetGenericArguments().Single());
        }

        /// <summary>
        ///     Close with escape
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">KeyEventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 16/11/17
        private void DM0312_DetalleSerieArticulo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();

            if (e.Control && e.KeyCode == Keys.G) GuardarDetalleS();
        }
    }
}