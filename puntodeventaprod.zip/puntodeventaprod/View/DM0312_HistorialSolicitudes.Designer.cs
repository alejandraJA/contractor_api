﻿namespace PuntoVenta
{
    partial class HistorialSolicitudes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HistorialSolicitudes));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Act3 = new System.Windows.Forms.Label();
            this.Act2 = new System.Windows.Forms.Label();
            this.Act1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Sucursal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.cbx_FechaA = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_CuentaCliente = new System.Windows.Forms.TextBox();
            this.txt_FechaD = new System.Windows.Forms.TextBox();
            this.dtp_FechaD = new System.Windows.Forms.DateTimePicker();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbx_Canal = new System.Windows.Forms.ComboBox();
            this.lbl_Buscar = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbx_Estatus = new System.Windows.Forms.ComboBox();
            this.cbx_Situacion = new System.Windows.Forms.ComboBox();
            this.cbx_movimiento = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgv_HistorialSolicitudes = new System.Windows.Forms.DataGridView();
            this.lbl_AnalisisCreditoTotal = new System.Windows.Forms.Label();
            this.lbl_AnalisisCredito = new System.Windows.Forms.Label();
            this.lbl_SolicitudCreditoTotal = new System.Windows.Forms.Label();
            this.lbl_SolicitudCredito = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgv_Eventos = new System.Windows.Forms.DataGridView();
            this.btn_PosMov = new System.Windows.Forms.Button();
            this.btn_UsuariosTiempos = new System.Windows.Forms.Button();
            this.btn_Eventos = new System.Windows.Forms.Button();
            this.btn_Kardex = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Refrescar = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_CatalagoCalif = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_HistorialSolicitudes)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Eventos)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Act3);
            this.groupBox2.Controls.Add(this.Act2);
            this.groupBox2.Controls.Add(this.Act1);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.Sucursal);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lbl_Usuario);
            this.groupBox2.Controls.Add(this.cbx_FechaA);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txt_CuentaCliente);
            this.groupBox2.Controls.Add(this.txt_FechaD);
            this.groupBox2.Controls.Add(this.dtp_FechaD);
            this.groupBox2.Controls.Add(this.txt_ComentarioAyuda);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbx_Canal);
            this.groupBox2.Controls.Add(this.lbl_Buscar);
            this.groupBox2.Controls.Add(this.dateTimePicker2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.cbx_Estatus);
            this.groupBox2.Controls.Add(this.cbx_Situacion);
            this.groupBox2.Controls.Add(this.cbx_movimiento);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(87, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1183, 110);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox2_Paint);
            // 
            // Act3
            // 
            this.Act3.AutoSize = true;
            this.Act3.Location = new System.Drawing.Point(1016, 92);
            this.Act3.Name = "Act3";
            this.Act3.Size = new System.Drawing.Size(14, 15);
            this.Act3.TabIndex = 59;
            this.Act3.Text = "1";
            // 
            // Act2
            // 
            this.Act2.AutoSize = true;
            this.Act2.Location = new System.Drawing.Point(1016, 77);
            this.Act2.Name = "Act2";
            this.Act2.Size = new System.Drawing.Size(14, 15);
            this.Act2.TabIndex = 58;
            this.Act2.Text = "1";
            // 
            // Act1
            // 
            this.Act1.AutoSize = true;
            this.Act1.Location = new System.Drawing.Point(1016, 62);
            this.Act1.Name = "Act1";
            this.Act1.Size = new System.Drawing.Size(14, 15);
            this.Act1.TabIndex = 57;
            this.Act1.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(890, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 15);
            this.label12.TabIndex = 56;
            this.label12.Text = "Usuario";
            // 
            // Sucursal
            // 
            this.Sucursal.AutoSize = true;
            this.Sucursal.Location = new System.Drawing.Point(890, 77);
            this.Sucursal.Name = "Sucursal";
            this.Sucursal.Size = new System.Drawing.Size(57, 15);
            this.Sucursal.TabIndex = 55;
            this.Sucursal.Text = "Sucursal";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(890, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 15);
            this.label10.TabIndex = 54;
            this.label10.Text = "Ultima Actualizacion";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1003, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 19);
            this.label9.TabIndex = 53;
            this.label9.Text = "Usuario:";
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.AutoSize = true;
            this.lbl_Usuario.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Usuario.Location = new System.Drawing.Point(1075, 14);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(61, 19);
            this.lbl_Usuario.TabIndex = 12;
            this.lbl_Usuario.Text = "Usuario";
            // 
            // cbx_FechaA
            // 
            this.cbx_FechaA.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_FechaA.Location = new System.Drawing.Point(865, 30);
            this.cbx_FechaA.Name = "cbx_FechaA";
            this.cbx_FechaA.Size = new System.Drawing.Size(70, 22);
            this.cbx_FechaA.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Buscar:  Cuenta";
            // 
            // txt_CuentaCliente
            // 
            this.txt_CuentaCliente.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_CuentaCliente.Location = new System.Drawing.Point(6, 34);
            this.txt_CuentaCliente.MaxLength = 9;
            this.txt_CuentaCliente.Name = "txt_CuentaCliente";
            this.txt_CuentaCliente.Size = new System.Drawing.Size(111, 22);
            this.txt_CuentaCliente.TabIndex = 1;
            this.txt_CuentaCliente.Click += new System.EventHandler(this.txt_CuentaCliente_Click);
            this.txt_CuentaCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbx_FechaA_KeyPress);
            // 
            // txt_FechaD
            // 
            this.txt_FechaD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FechaD.Location = new System.Drawing.Point(749, 31);
            this.txt_FechaD.Name = "txt_FechaD";
            this.txt_FechaD.Size = new System.Drawing.Size(77, 22);
            this.txt_FechaD.TabIndex = 7;
            this.txt_FechaD.Click += new System.EventHandler(this.txt_FechaD_Click_1);
            this.txt_FechaD.TextChanged += new System.EventHandler(this.txt_FechaD_TextChanged);
            this.txt_FechaD.Validating += new System.ComponentModel.CancelEventHandler(this.txt_FechaD_Validating);
            // 
            // dtp_FechaD
            // 
            this.dtp_FechaD.CalendarFont = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_FechaD.CalendarTitleBackColor = System.Drawing.SystemColors.HighlightText;
            this.dtp_FechaD.CalendarTitleForeColor = System.Drawing.SystemColors.HighlightText;
            this.dtp_FechaD.CalendarTrailingForeColor = System.Drawing.SystemColors.HighlightText;
            this.dtp_FechaD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_FechaD.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaD.Location = new System.Drawing.Point(749, 31);
            this.dtp_FechaD.Name = "dtp_FechaD";
            this.dtp_FechaD.Size = new System.Drawing.Size(107, 22);
            this.dtp_FechaD.TabIndex = 7;
            this.dtp_FechaD.Value = new System.DateTime(2017, 7, 18, 0, 0, 0, 0);
            this.dtp_FechaD.ValueChanged += new System.EventHandler(this.dtp_FechaD_ValueChanged);
            this.dtp_FechaD.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dtp_FechaD_MouseUp);
            this.dtp_FechaD.Validating += new System.ComponentModel.CancelEventHandler(this.dtp_FechaD_Validating);
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.White;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(6, 62);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.ReadOnly = true;
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(850, 34);
            this.txt_ComentarioAyuda.TabIndex = 50;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(619, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 15);
            this.label7.TabIndex = 8;
            this.label7.Text = "Canales Venta *";
            // 
            // cbx_Canal
            // 
            this.cbx_Canal.BackColor = System.Drawing.Color.White;
            this.cbx_Canal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Canal.FormattingEnabled = true;
            this.cbx_Canal.Items.AddRange(new object[] {
            "(Todos)"});
            this.cbx_Canal.Location = new System.Drawing.Point(622, 31);
            this.cbx_Canal.Name = "cbx_Canal";
            this.cbx_Canal.Size = new System.Drawing.Size(121, 23);
            this.cbx_Canal.TabIndex = 6;
            this.cbx_Canal.SelectedIndexChanged += new System.EventHandler(this.cbx_Canal_SelectedIndexChanged);
            this.cbx_Canal.Click += new System.EventHandler(this.cbx_Canal_Click);
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.lbl_Buscar.Location = new System.Drawing.Point(123, 34);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(112, 22);
            this.lbl_Buscar.TabIndex = 2;
            this.lbl_Buscar.Click += new System.EventHandler(this.lbl_Buscar_Click);
            this.lbl_Buscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lbl_Buscar_KeyPress);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.CalendarTitleBackColor = System.Drawing.SystemColors.HighlightText;
            this.dateTimePicker2.CalendarTitleForeColor = System.Drawing.SystemColors.HighlightText;
            this.dateTimePicker2.CalendarTrailingForeColor = System.Drawing.SystemColors.HighlightText;
            this.dateTimePicker2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(865, 30);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(101, 22);
            this.dateTimePicker2.TabIndex = 8;
            this.dateTimePicker2.Value = new System.DateTime(2017, 7, 18, 0, 0, 0, 0);
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            this.dateTimePicker2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dateTimePicker2_MouseUp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(862, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "A la Fecha *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(238, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Movimiento *";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(365, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Situacion *";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(492, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Estatus *";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(746, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "De la Fecha *";
            // 
            // cbx_Estatus
            // 
            this.cbx_Estatus.BackColor = System.Drawing.Color.White;
            this.cbx_Estatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Estatus.FormattingEnabled = true;
            this.cbx_Estatus.Items.AddRange(new object[] {
            "(Todos)"});
            this.cbx_Estatus.Location = new System.Drawing.Point(495, 32);
            this.cbx_Estatus.Name = "cbx_Estatus";
            this.cbx_Estatus.Size = new System.Drawing.Size(121, 23);
            this.cbx_Estatus.TabIndex = 5;
            this.cbx_Estatus.SelectedIndexChanged += new System.EventHandler(this.cbx_Estatus_SelectedIndexChanged);
            this.cbx_Estatus.Click += new System.EventHandler(this.cbx_Estatus_Click);
            // 
            // cbx_Situacion
            // 
            this.cbx_Situacion.BackColor = System.Drawing.Color.White;
            this.cbx_Situacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Situacion.FormattingEnabled = true;
            this.cbx_Situacion.Items.AddRange(new object[] {
            "(Todos)"});
            this.cbx_Situacion.Location = new System.Drawing.Point(368, 33);
            this.cbx_Situacion.Name = "cbx_Situacion";
            this.cbx_Situacion.Size = new System.Drawing.Size(121, 23);
            this.cbx_Situacion.TabIndex = 4;
            this.cbx_Situacion.SelectedIndexChanged += new System.EventHandler(this.cbx_Situacion_SelectedIndexChanged);
            this.cbx_Situacion.Click += new System.EventHandler(this.cbx_Situacion_Click);
            // 
            // cbx_movimiento
            // 
            this.cbx_movimiento.BackColor = System.Drawing.Color.White;
            this.cbx_movimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_movimiento.FormattingEnabled = true;
            this.cbx_movimiento.Items.AddRange(new object[] {
            "(Todos)"});
            this.cbx_movimiento.Location = new System.Drawing.Point(241, 33);
            this.cbx_movimiento.Name = "cbx_movimiento";
            this.cbx_movimiento.Size = new System.Drawing.Size(121, 23);
            this.cbx_movimiento.TabIndex = 3;
            this.cbx_movimiento.SelectedIndexChanged += new System.EventHandler(this.cbx_movimiento_SelectedIndexChanged);
            this.cbx_movimiento.Click += new System.EventHandler(this.cbx_movimiento_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(120, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Buscar:  MovId";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgv_HistorialSolicitudes);
            this.groupBox3.Location = new System.Drawing.Point(87, 119);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1181, 327);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox3_Paint);
            // 
            // dgv_HistorialSolicitudes
            // 
            this.dgv_HistorialSolicitudes.AllowUserToAddRows = false;
            this.dgv_HistorialSolicitudes.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_HistorialSolicitudes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_HistorialSolicitudes.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_HistorialSolicitudes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_HistorialSolicitudes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_HistorialSolicitudes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_HistorialSolicitudes.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_HistorialSolicitudes.EnableHeadersVisualStyles = false;
            this.dgv_HistorialSolicitudes.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgv_HistorialSolicitudes.Location = new System.Drawing.Point(7, 9);
            this.dgv_HistorialSolicitudes.MultiSelect = false;
            this.dgv_HistorialSolicitudes.Name = "dgv_HistorialSolicitudes";
            this.dgv_HistorialSolicitudes.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_HistorialSolicitudes.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_HistorialSolicitudes.RowHeadersVisible = false;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_HistorialSolicitudes.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_HistorialSolicitudes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_HistorialSolicitudes.Size = new System.Drawing.Size(1164, 311);
            this.dgv_HistorialSolicitudes.TabIndex = 6;
            this.dgv_HistorialSolicitudes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_HistorialSolicitudes_CellClick);
            this.dgv_HistorialSolicitudes.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_HistorialSolicitudes_CellDoubleClick);
            this.dgv_HistorialSolicitudes.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_HistorialSolicitudes_CellFormatting);
            this.dgv_HistorialSolicitudes.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellLeave);
            this.dgv_HistorialSolicitudes.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_HistorialSolicitudes_ColumnHeaderMouseClick);
            this.dgv_HistorialSolicitudes.SelectionChanged += new System.EventHandler(this.dgv_HistorialSolicitudes_SelectionChanged);
            // 
            // lbl_AnalisisCreditoTotal
            // 
            this.lbl_AnalisisCreditoTotal.AutoSize = true;
            this.lbl_AnalisisCreditoTotal.Enabled = false;
            this.lbl_AnalisisCreditoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AnalisisCreditoTotal.Location = new System.Drawing.Point(353, 16);
            this.lbl_AnalisisCreditoTotal.Name = "lbl_AnalisisCreditoTotal";
            this.lbl_AnalisisCreditoTotal.Size = new System.Drawing.Size(0, 13);
            this.lbl_AnalisisCreditoTotal.TabIndex = 10;
            // 
            // lbl_AnalisisCredito
            // 
            this.lbl_AnalisisCredito.AutoSize = true;
            this.lbl_AnalisisCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AnalisisCredito.Location = new System.Drawing.Point(233, 16);
            this.lbl_AnalisisCredito.Name = "lbl_AnalisisCredito";
            this.lbl_AnalisisCredito.Size = new System.Drawing.Size(0, 13);
            this.lbl_AnalisisCredito.TabIndex = 9;
            // 
            // lbl_SolicitudCreditoTotal
            // 
            this.lbl_SolicitudCreditoTotal.AutoSize = true;
            this.lbl_SolicitudCreditoTotal.Enabled = false;
            this.lbl_SolicitudCreditoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SolicitudCreditoTotal.Location = new System.Drawing.Point(143, 16);
            this.lbl_SolicitudCreditoTotal.Name = "lbl_SolicitudCreditoTotal";
            this.lbl_SolicitudCreditoTotal.Size = new System.Drawing.Size(0, 13);
            this.lbl_SolicitudCreditoTotal.TabIndex = 8;
            // 
            // lbl_SolicitudCredito
            // 
            this.lbl_SolicitudCredito.AutoSize = true;
            this.lbl_SolicitudCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SolicitudCredito.Location = new System.Drawing.Point(22, 16);
            this.lbl_SolicitudCredito.Name = "lbl_SolicitudCredito";
            this.lbl_SolicitudCredito.Size = new System.Drawing.Size(0, 13);
            this.lbl_SolicitudCredito.TabIndex = 7;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgv_Eventos);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(88, 489);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1177, 183);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Eventos";
            this.groupBox4.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox4_Paint);
            // 
            // dgv_Eventos
            // 
            this.dgv_Eventos.AllowUserToAddRows = false;
            this.dgv_Eventos.AllowUserToOrderColumns = true;
            this.dgv_Eventos.AllowUserToResizeColumns = false;
            this.dgv_Eventos.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Eventos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_Eventos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Eventos.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_Eventos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Eventos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_Eventos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Eventos.EnableHeadersVisualStyles = false;
            this.dgv_Eventos.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgv_Eventos.Location = new System.Drawing.Point(-1, 25);
            this.dgv_Eventos.Name = "dgv_Eventos";
            this.dgv_Eventos.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Eventos.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_Eventos.RowHeadersVisible = false;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_Eventos.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_Eventos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Eventos.Size = new System.Drawing.Size(1171, 158);
            this.dgv_Eventos.TabIndex = 14;
            this.dgv_Eventos.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_Eventos_CellFormatting);
            this.dgv_Eventos.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgv_Eventos_KeyDown);
            // 
            // btn_PosMov
            // 
            this.btn_PosMov.BackColor = System.Drawing.Color.Transparent;
            this.btn_PosMov.FlatAppearance.BorderSize = 0;
            this.btn_PosMov.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_PosMov.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PosMov.Image = ((System.Drawing.Image)(resources.GetObject("btn_PosMov.Image")));
            this.btn_PosMov.Location = new System.Drawing.Point(3, 342);
            this.btn_PosMov.Name = "btn_PosMov";
            this.btn_PosMov.Size = new System.Drawing.Size(77, 81);
            this.btn_PosMov.TabIndex = 9;
            this.btn_PosMov.Text = "Posicion del Movimiento (Ctl-P)";
            this.btn_PosMov.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_PosMov.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_PosMov.UseVisualStyleBackColor = false;
            this.btn_PosMov.Click += new System.EventHandler(this.btn_PosMov_Click);
            // 
            // btn_UsuariosTiempos
            // 
            this.btn_UsuariosTiempos.BackColor = System.Drawing.Color.Transparent;
            this.btn_UsuariosTiempos.FlatAppearance.BorderSize = 0;
            this.btn_UsuariosTiempos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UsuariosTiempos.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UsuariosTiempos.Image = ((System.Drawing.Image)(resources.GetObject("btn_UsuariosTiempos.Image")));
            this.btn_UsuariosTiempos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_UsuariosTiempos.Location = new System.Drawing.Point(3, 245);
            this.btn_UsuariosTiempos.Name = "btn_UsuariosTiempos";
            this.btn_UsuariosTiempos.Size = new System.Drawing.Size(77, 91);
            this.btn_UsuariosTiempos.TabIndex = 10;
            this.btn_UsuariosTiempos.Text = "Usuarios y Tiempos (Ctl-U)";
            this.btn_UsuariosTiempos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_UsuariosTiempos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_UsuariosTiempos.UseVisualStyleBackColor = false;
            this.btn_UsuariosTiempos.Click += new System.EventHandler(this.btn_UsuariosTiempos_Click);
            // 
            // btn_Eventos
            // 
            this.btn_Eventos.BackColor = System.Drawing.Color.Transparent;
            this.btn_Eventos.FlatAppearance.BorderSize = 0;
            this.btn_Eventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Eventos.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Eventos.Image = ((System.Drawing.Image)(resources.GetObject("btn_Eventos.Image")));
            this.btn_Eventos.Location = new System.Drawing.Point(3, 159);
            this.btn_Eventos.Name = "btn_Eventos";
            this.btn_Eventos.Size = new System.Drawing.Size(77, 80);
            this.btn_Eventos.TabIndex = 8;
            this.btn_Eventos.Text = "Eventos, Notas y Citas (Ctl-E)";
            this.btn_Eventos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Eventos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Eventos.UseVisualStyleBackColor = false;
            this.btn_Eventos.Click += new System.EventHandler(this.btn_Eventos_Click);
            // 
            // btn_Kardex
            // 
            this.btn_Kardex.BackColor = System.Drawing.Color.Transparent;
            this.btn_Kardex.FlatAppearance.BorderSize = 0;
            this.btn_Kardex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Kardex.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Kardex.Image = ((System.Drawing.Image)(resources.GetObject("btn_Kardex.Image")));
            this.btn_Kardex.Location = new System.Drawing.Point(3, 429);
            this.btn_Kardex.Name = "btn_Kardex";
            this.btn_Kardex.Size = new System.Drawing.Size(77, 89);
            this.btn_Kardex.TabIndex = 11;
            this.btn_Kardex.Text = "Kardex del Cliente (F11)";
            this.btn_Kardex.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Kardex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Kardex.UseVisualStyleBackColor = false;
            this.btn_Kardex.Click += new System.EventHandler(this.btn_Kardex_Click_1);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.Transparent;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ayuda.Location = new System.Drawing.Point(3, 605);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(77, 61);
            this.btn_ayuda.TabIndex = 13;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_Refrescar);
            this.flowLayoutPanel1.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel1.Controls.Add(this.btn_Eventos);
            this.flowLayoutPanel1.Controls.Add(this.btn_UsuariosTiempos);
            this.flowLayoutPanel1.Controls.Add(this.btn_PosMov);
            this.flowLayoutPanel1.Controls.Add(this.btn_Kardex);
            this.flowLayoutPanel1.Controls.Add(this.btn_CatalagoCalif);
            this.flowLayoutPanel1.Controls.Add(this.btn_ayuda);
            this.flowLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(1, 21);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(81, 669);
            this.flowLayoutPanel1.TabIndex = 8;
            // 
            // btn_Refrescar
            // 
            this.btn_Refrescar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Refrescar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Refrescar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Refrescar.FlatAppearance.BorderSize = 0;
            this.btn_Refrescar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Refrescar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Refrescar.Image")));
            this.btn_Refrescar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Refrescar.Location = new System.Drawing.Point(3, 3);
            this.btn_Refrescar.Name = "btn_Refrescar";
            this.btn_Refrescar.Size = new System.Drawing.Size(77, 71);
            this.btn_Refrescar.TabIndex = 14;
            this.btn_Refrescar.Text = "Refrescar (F5)";
            this.btn_Refrescar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Refrescar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Refrescar.UseVisualStyleBackColor = false;
            this.btn_Refrescar.Click += new System.EventHandler(this.btn_Refrescar_Click_1);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 80);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(77, 73);
            this.btn_Regresar.TabIndex = 12;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_CatalagoCalif
            // 
            this.btn_CatalagoCalif.BackColor = System.Drawing.Color.Transparent;
            this.btn_CatalagoCalif.FlatAppearance.BorderSize = 0;
            this.btn_CatalagoCalif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CatalagoCalif.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CatalagoCalif.Image = ((System.Drawing.Image)(resources.GetObject("btn_CatalagoCalif.Image")));
            this.btn_CatalagoCalif.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CatalagoCalif.Location = new System.Drawing.Point(3, 524);
            this.btn_CatalagoCalif.Name = "btn_CatalagoCalif";
            this.btn_CatalagoCalif.Size = new System.Drawing.Size(77, 75);
            this.btn_CatalagoCalif.TabIndex = 39;
            this.btn_CatalagoCalif.Text = "Catalogo de Cal. (Crtl-O)";
            this.btn_CatalagoCalif.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CatalagoCalif.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CatalagoCalif.UseVisualStyleBackColor = false;
            this.btn_CatalagoCalif.Click += new System.EventHandler(this.btn_CatalagoCalif_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_SolicitudCreditoTotal);
            this.groupBox1.Controls.Add(this.lbl_AnalisisCreditoTotal);
            this.groupBox1.Controls.Add(this.lbl_SolicitudCredito);
            this.groupBox1.Controls.Add(this.lbl_AnalisisCredito);
            this.groupBox1.Location = new System.Drawing.Point(87, 448);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(518, 28);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // HistorialSolicitudes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1296, 692);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HistorialSolicitudes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historial De Solicitudes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HistorialSolicitudes_FormClosing);
            this.Load += new System.EventHandler(this.HistorialSolicitudes_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HistorialSolicitudes_KeyDown);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_HistorialSolicitudes)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Eventos)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbx_Estatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgv_Eventos;
        private System.Windows.Forms.Button btn_PosMov;
        private System.Windows.Forms.Button btn_UsuariosTiempos;
        private System.Windows.Forms.Button btn_Eventos;
        private System.Windows.Forms.Button btn_Kardex;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox lbl_Buscar;
        public System.Windows.Forms.ComboBox cbx_movimiento;
        public System.Windows.Forms.ComboBox cbx_Situacion;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbx_Canal;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.Button btn_Refrescar;
        private System.Windows.Forms.DateTimePicker dtp_FechaD;
        public System.Windows.Forms.DataGridView dgv_HistorialSolicitudes;
        private System.Windows.Forms.Label lbl_AnalisisCreditoTotal;
        private System.Windows.Forms.Label lbl_AnalisisCredito;
        private System.Windows.Forms.Label lbl_SolicitudCreditoTotal;
        private System.Windows.Forms.Label lbl_SolicitudCredito;
        private System.Windows.Forms.TextBox txt_FechaD;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_CuentaCliente;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.TextBox cbx_FechaA;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_CatalagoCalif;
        private System.Windows.Forms.Label Act3;
        private System.Windows.Forms.Label Act2;
        private System.Windows.Forms.Label Act1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Sucursal;
        private System.Windows.Forms.Label label10;
    }
}