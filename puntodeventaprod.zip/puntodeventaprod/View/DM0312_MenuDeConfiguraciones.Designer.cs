﻿namespace PuntoVenta.View
{
    partial class DM0312_MenuDeConfiguraciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_MenuDeConfiguraciones));
            this.btn_ConfiguracionComent = new System.Windows.Forms.Button();
            this.btn_ConfiguracionComp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ConfiguracionComent
            // 
            this.btn_ConfiguracionComent.BackColor = System.Drawing.Color.White;
            this.btn_ConfiguracionComent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ConfiguracionComent.FlatAppearance.BorderSize = 0;
            this.btn_ConfiguracionComent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ConfiguracionComent.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfiguracionComent.Image = ((System.Drawing.Image)(resources.GetObject("btn_ConfiguracionComent.Image")));
            this.btn_ConfiguracionComent.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ConfiguracionComent.Location = new System.Drawing.Point(123, 141);
            this.btn_ConfiguracionComent.Name = "btn_ConfiguracionComent";
            this.btn_ConfiguracionComent.Size = new System.Drawing.Size(101, 85);
            this.btn_ConfiguracionComent.TabIndex = 3;
            this.btn_ConfiguracionComent.Text = "Configuracion de Comentarios";
            this.btn_ConfiguracionComent.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ConfiguracionComent.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ConfiguracionComent.UseVisualStyleBackColor = false;
            this.btn_ConfiguracionComent.Click += new System.EventHandler(this.btn_ConfiguracionComent_Click);
            // 
            // btn_ConfiguracionComp
            // 
            this.btn_ConfiguracionComp.BackColor = System.Drawing.Color.White;
            this.btn_ConfiguracionComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ConfiguracionComp.FlatAppearance.BorderSize = 0;
            this.btn_ConfiguracionComp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ConfiguracionComp.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfiguracionComp.Image = ((System.Drawing.Image)(resources.GetObject("btn_ConfiguracionComp.Image")));
            this.btn_ConfiguracionComp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ConfiguracionComp.Location = new System.Drawing.Point(114, 29);
            this.btn_ConfiguracionComp.Name = "btn_ConfiguracionComp";
            this.btn_ConfiguracionComp.Size = new System.Drawing.Size(122, 87);
            this.btn_ConfiguracionComp.TabIndex = 4;
            this.btn_ConfiguracionComp.Text = "Configuracion de Componentes ";
            this.btn_ConfiguracionComp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ConfiguracionComp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ConfiguracionComp.UseVisualStyleBackColor = false;
            this.btn_ConfiguracionComp.Click += new System.EventHandler(this.btn_ConfiguracionComp_Click);
            // 
            // DM0312_MenuDeConfiguraciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(349, 264);
            this.Controls.Add(this.btn_ConfiguracionComp);
            this.Controls.Add(this.btn_ConfiguracionComent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DM0312_MenuDeConfiguraciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu de configuraciones Punto de Venta";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_ConfiguracionComent;
        private System.Windows.Forms.Button btn_ConfiguracionComp;
    }
}