﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta
{
    //dev:Rodolfo
    //Date: 26/08/2017
    //Modulo:Credito
    //Submodulo:MonederoRedimir
    public partial class MonederoPorRedimir : Form
    {
        private readonly DM0312_CMonederoxRedimir controlador;
        private Dictionary<int, string> Datos;

        public MonederoPorRedimir()
        {
            InitializeComponent();

            controlador = new DM0312_CMonederoxRedimir();

            Datos = new Dictionary<int, string>();
        }

        public int idVenta { get; set; }

        ~MonederoPorRedimir()
        {
            GC.Collect();
        }


        private void MonederoPorRedimir_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            toolTip1.SetToolTip(btn_Ayuda, "Ayuda");

            controlador.idVenta = idVenta;

            if (ValidacionMonedero())
            {
                llenarTxt();
            }
            else
            {
                MessageBox.Show("Sin datos que mostrar", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }


        #region EventosForm

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        #endregion

        #region Metodos

        private void llenarTxt()
        {
            Datos = controlador.GetMonederoPorRedimir();

            txtCliente.Text = Datos.Where(x => x.Key == 0).Select(x => x.Value).First();

            txtMov.Text = Datos.Where(x => x.Key == 1).Select(x => x.Value).First();

            txtMovid.Text = Datos.Where(x => x.Key == 2).Select(x => x.Value).First();

            txtMonedero.Text = Datos.Where(x => x.Key == 3).Select(x => x.Value).First();

            string SaldoMon = Datos.Where(x => x.Key == 4).Select(x => x.Value).First();

            if (SaldoMon != string.Empty)
                txtSaldoMon.Text = Convert.ToDouble(SaldoMon).ToString("C", Thread.CurrentThread.CurrentCulture);
            else
                txtSaldoMon.Text = "$0.00";

            string PorRedimir = Datos.Where(x => x.Key == 5).Select(x => x.Value).First();

            if (PorRedimir != string.Empty)
                txtPorRedimir.Text = Convert.ToDouble(PorRedimir).ToString("C", Thread.CurrentThread.CurrentCulture);
            else
                txtPorRedimir.Text = "$0.00";

            string SaldoPost = Datos.Where(x => x.Key == 6).Select(x => x.Value).First();

            if (SaldoPost != string.Empty)
                txtSaldoPost.Text = Convert.ToDouble(SaldoPost).ToString("C", Thread.CurrentThread.CurrentCulture);
            else
                txtSaldoPost.Text = "$0.00";
        }

        private bool ValidacionMonedero()
        {
            return controlador.CondicionesMonedero();
        }

        private void MonederoPorRedimir_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        #endregion
    }
}