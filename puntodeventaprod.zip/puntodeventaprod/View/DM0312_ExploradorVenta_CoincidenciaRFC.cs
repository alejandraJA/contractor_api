﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class DM0312_ExploradorVenta_CoincidenciaRFC : Form
    {
        public DialogResult resultadoForm;

        public DM0312_ExploradorVenta_CoincidenciaRFC(List<CoincidenciasRFCModelo> ListaExplorador)
        {
            InitializeComponent();
            lb_titleRFC.Text += ListaExplorador.Select(x => x._rfc).FirstOrDefault();
            dgv_TablaMovimientos.DataSource = ListaExplorador;
        }

        private void btn_corresponde_Click(object sender, EventArgs e)
        {
            DialogResult resultado =
                MessageBox.Show("Favor de seguir con la actualización de cuenta en el kardex(F11) del prospecto",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            resultadoForm = resultado;
            Close();
        }

        private void btn_noCorresponde_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("¿Estas seguro?", "Alerta", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                resultadoForm = resultado;
                Close();
            }
        }
    }
}