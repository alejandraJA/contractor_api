﻿using System;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta.View
{
    public partial class DM0312_EscanearValeDigital : Form
    {
        public string vale;

        public DM0312_EscanearValeDigital()
        {
            InitializeComponent();
        }
        //DM0312_C_EscanearValeDigital valeDigitalC = new DM0312_C_EscanearValeDigital();

        ~DM0312_EscanearValeDigital()
        {
            GC.Collect();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(codigo.Text))
            {
                MessageBox.Show("Introduzca un vale.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (validacionesValeDigital(codigo.Text))
            {
                vale = codigo.Text;
                DialogResult = DialogResult.OK;
                Close();
            }
        }


        private bool validacionesValeDigital(string vale)
        {
            int num = ValeDigitalController.getEstatusVale(vale);

            bool respuesta = false;

            switch (num)
            {
                case 0:
                    respuesta = true;
                    break;
                case 1:
                    MessageBox.Show("No existe el vale.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                case 2:
                    MessageBox.Show("Vale Vencido.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                case 3:
                    MessageBox.Show("Vale cancelado por Dima.", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    break;
                case 4:
                    MessageBox.Show("Vale ya utilizado.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                case 5:
                    MessageBox.Show("Error de Aplicacion.", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    break;
                default:
                    MessageBox.Show("Error de Aplicacion", "Advertencia.", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    break;
            }

            return respuesta;
        }
    }
}