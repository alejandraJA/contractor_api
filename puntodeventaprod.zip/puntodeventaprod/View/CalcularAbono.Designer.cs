﻿namespace PuntoVenta.View
{
    partial class CalcularAbono
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbl_Contenedor = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tbl_Contenido = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_Plazo = new System.Windows.Forms.Label();
            this.lbl_TotalPagar = new System.Windows.Forms.Label();
            this.lblFechaPrimerAbono = new System.Windows.Forms.Label();
            this.lbl_PagoNormal = new System.Windows.Forms.Label();
            this.lbl_PagoInmediato = new System.Windows.Forms.Label();
            this.lbl_CantidadParcialidadPagoNormal = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Plazo = new System.Windows.Forms.TextBox();
            this.txt_TotalPagar = new System.Windows.Forms.TextBox();
            this.txtFechaPrimerAbono = new System.Windows.Forms.TextBox();
            this.txt_ImporteParcialidadPagoNormal = new System.Windows.Forms.TextBox();
            this.txt_ImportePagoNormal = new System.Windows.Forms.TextBox();
            this.txt_ImportePagoInmediato = new System.Windows.Forms.TextBox();
            this.txt_ImporteAhorro = new System.Windows.Forms.TextBox();
            this.txt_ImporteParcialidadPagoInmediato = new System.Windows.Forms.TextBox();
            this.lbl_CantidadParcialidadPagoInmediato = new System.Windows.Forms.Label();
            this.btn_Cerrar = new System.Windows.Forms.Button();
            this.lbl_Bonificacion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.tbl_Contenedor.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tbl_Contenido.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbl_Contenedor
            // 
            this.tbl_Contenedor.BackColor = System.Drawing.Color.White;
            this.tbl_Contenedor.ColumnCount = 3;
            this.tbl_Contenedor.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenedor.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_Contenedor.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenedor.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tbl_Contenedor.Controls.Add(this.lbl_Cliente, 1, 0);
            this.tbl_Contenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl_Contenedor.Location = new System.Drawing.Point(0, 0);
            this.tbl_Contenedor.Name = "tbl_Contenedor";
            this.tbl_Contenedor.RowCount = 3;
            this.tbl_Contenedor.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenedor.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_Contenedor.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenedor.Size = new System.Drawing.Size(632, 424);
            this.tbl_Contenedor.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.tbl_Contenido, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(23, 23);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 377F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(586, 378);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tbl_Contenido
            // 
            this.tbl_Contenido.ColumnCount = 7;
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.39885F));
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.139037F));
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.57803F));
            this.tbl_Contenido.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 14F));
            this.tbl_Contenido.Controls.Add(this.lbl_Plazo, 1, 1);
            this.tbl_Contenido.Controls.Add(this.lbl_TotalPagar, 4, 1);
            this.tbl_Contenido.Controls.Add(this.lblFechaPrimerAbono, 1, 4);
            this.tbl_Contenido.Controls.Add(this.lbl_PagoNormal, 1, 7);
            this.tbl_Contenido.Controls.Add(this.lbl_PagoInmediato, 1, 8);
            this.tbl_Contenido.Controls.Add(this.lbl_CantidadParcialidadPagoNormal, 4, 7);
            this.tbl_Contenido.Controls.Add(this.label9, 1, 10);
            this.tbl_Contenido.Controls.Add(this.txt_Plazo, 2, 1);
            this.tbl_Contenido.Controls.Add(this.txt_TotalPagar, 5, 1);
            this.tbl_Contenido.Controls.Add(this.txtFechaPrimerAbono, 1, 5);
            this.tbl_Contenido.Controls.Add(this.txt_ImporteParcialidadPagoNormal, 5, 7);
            this.tbl_Contenido.Controls.Add(this.txt_ImportePagoNormal, 2, 7);
            this.tbl_Contenido.Controls.Add(this.txt_ImportePagoInmediato, 2, 8);
            this.tbl_Contenido.Controls.Add(this.txt_ImporteAhorro, 1, 11);
            this.tbl_Contenido.Controls.Add(this.txt_ImporteParcialidadPagoInmediato, 5, 8);
            this.tbl_Contenido.Controls.Add(this.lbl_CantidadParcialidadPagoInmediato, 4, 8);
            this.tbl_Contenido.Controls.Add(this.btn_Cerrar, 1, 13);
            this.tbl_Contenido.Controls.Add(this.lbl_Bonificacion, 3, 13);
            this.tbl_Contenido.Controls.Add(this.label2, 5, 6);
            this.tbl_Contenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl_Contenido.Location = new System.Drawing.Point(4, 4);
            this.tbl_Contenido.Name = "tbl_Contenido";
            this.tbl_Contenido.RowCount = 16;
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Contenido.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_Contenido.Size = new System.Drawing.Size(578, 370);
            this.tbl_Contenido.TabIndex = 0;
            // 
            // lbl_Plazo
            // 
            this.lbl_Plazo.AutoSize = true;
            this.lbl_Plazo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Plazo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Plazo.Location = new System.Drawing.Point(11, 20);
            this.lbl_Plazo.Name = "lbl_Plazo";
            this.lbl_Plazo.Size = new System.Drawing.Size(85, 30);
            this.lbl_Plazo.TabIndex = 0;
            this.lbl_Plazo.Text = "Plazo:";
            this.lbl_Plazo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_TotalPagar
            // 
            this.lbl_TotalPagar.AutoSize = true;
            this.lbl_TotalPagar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_TotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPagar.Location = new System.Drawing.Point(273, 20);
            this.lbl_TotalPagar.Name = "lbl_TotalPagar";
            this.lbl_TotalPagar.Size = new System.Drawing.Size(112, 30);
            this.lbl_TotalPagar.TabIndex = 1;
            this.lbl_TotalPagar.Text = "Total a pagar:";
            this.lbl_TotalPagar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblFechaPrimerAbono
            // 
            this.lblFechaPrimerAbono.AutoSize = true;
            this.tbl_Contenido.SetColumnSpan(this.lblFechaPrimerAbono, 5);
            this.lblFechaPrimerAbono.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFechaPrimerAbono.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaPrimerAbono.Location = new System.Drawing.Point(11, 78);
            this.lblFechaPrimerAbono.Name = "lblFechaPrimerAbono";
            this.lblFechaPrimerAbono.Size = new System.Drawing.Size(549, 18);
            this.lblFechaPrimerAbono.TabIndex = 2;
            this.lblFechaPrimerAbono.Text = "Fecha primer abono:";
            this.lblFechaPrimerAbono.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_PagoNormal
            // 
            this.lbl_PagoNormal.AutoSize = true;
            this.lbl_PagoNormal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_PagoNormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PagoNormal.Location = new System.Drawing.Point(11, 146);
            this.lbl_PagoNormal.Name = "lbl_PagoNormal";
            this.lbl_PagoNormal.Size = new System.Drawing.Size(85, 30);
            this.lbl_PagoNormal.TabIndex = 3;
            this.lbl_PagoNormal.Text = "PN:";
            this.lbl_PagoNormal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_PagoInmediato
            // 
            this.lbl_PagoInmediato.AutoSize = true;
            this.lbl_PagoInmediato.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_PagoInmediato.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PagoInmediato.Location = new System.Drawing.Point(11, 176);
            this.lbl_PagoInmediato.Name = "lbl_PagoInmediato";
            this.lbl_PagoInmediato.Size = new System.Drawing.Size(85, 30);
            this.lbl_PagoInmediato.TabIndex = 4;
            this.lbl_PagoInmediato.Text = "P.Puntual:";
            this.lbl_PagoInmediato.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_CantidadParcialidadPagoNormal
            // 
            this.lbl_CantidadParcialidadPagoNormal.AutoSize = true;
            this.lbl_CantidadParcialidadPagoNormal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_CantidadParcialidadPagoNormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CantidadParcialidadPagoNormal.Location = new System.Drawing.Point(273, 146);
            this.lbl_CantidadParcialidadPagoNormal.Name = "lbl_CantidadParcialidadPagoNormal";
            this.lbl_CantidadParcialidadPagoNormal.Size = new System.Drawing.Size(112, 30);
            this.lbl_CantidadParcialidadPagoNormal.TabIndex = 6;
            this.lbl_CantidadParcialidadPagoNormal.Text = "- Abonos de:";
            this.lbl_CantidadParcialidadPagoNormal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.tbl_Contenido.SetColumnSpan(this.label9, 5);
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(11, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(549, 18);
            this.label9.TabIndex = 7;
            this.label9.Text = "Con pago puntual usted ahorra:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_Plazo
            // 
            this.txt_Plazo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_Plazo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Plazo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Plazo.Location = new System.Drawing.Point(102, 23);
            this.txt_Plazo.Name = "txt_Plazo";
            this.txt_Plazo.ReadOnly = true;
            this.txt_Plazo.Size = new System.Drawing.Size(158, 24);
            this.txt_Plazo.TabIndex = 1;
            this.txt_Plazo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_TotalPagar
            // 
            this.txt_TotalPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_TotalPagar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_TotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TotalPagar.Location = new System.Drawing.Point(391, 23);
            this.txt_TotalPagar.Name = "txt_TotalPagar";
            this.txt_TotalPagar.ReadOnly = true;
            this.txt_TotalPagar.Size = new System.Drawing.Size(169, 24);
            this.txt_TotalPagar.TabIndex = 2;
            this.txt_TotalPagar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFechaPrimerAbono
            // 
            this.txtFechaPrimerAbono.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.tbl_Contenido.SetColumnSpan(this.txtFechaPrimerAbono, 5);
            this.txtFechaPrimerAbono.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtFechaPrimerAbono.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaPrimerAbono.Location = new System.Drawing.Point(11, 99);
            this.txtFechaPrimerAbono.Name = "txtFechaPrimerAbono";
            this.txtFechaPrimerAbono.ReadOnly = true;
            this.txtFechaPrimerAbono.Size = new System.Drawing.Size(549, 24);
            this.txtFechaPrimerAbono.TabIndex = 3;
            this.txtFechaPrimerAbono.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ImporteParcialidadPagoNormal
            // 
            this.txt_ImporteParcialidadPagoNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_ImporteParcialidadPagoNormal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ImporteParcialidadPagoNormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImporteParcialidadPagoNormal.Location = new System.Drawing.Point(391, 149);
            this.txt_ImporteParcialidadPagoNormal.Name = "txt_ImporteParcialidadPagoNormal";
            this.txt_ImporteParcialidadPagoNormal.ReadOnly = true;
            this.txt_ImporteParcialidadPagoNormal.Size = new System.Drawing.Size(169, 24);
            this.txt_ImporteParcialidadPagoNormal.TabIndex = 5;
            this.txt_ImporteParcialidadPagoNormal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ImportePagoNormal
            // 
            this.txt_ImportePagoNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_ImportePagoNormal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ImportePagoNormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImportePagoNormal.Location = new System.Drawing.Point(102, 149);
            this.txt_ImportePagoNormal.Name = "txt_ImportePagoNormal";
            this.txt_ImportePagoNormal.ReadOnly = true;
            this.txt_ImportePagoNormal.Size = new System.Drawing.Size(158, 24);
            this.txt_ImportePagoNormal.TabIndex = 4;
            this.txt_ImportePagoNormal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ImportePagoInmediato
            // 
            this.txt_ImportePagoInmediato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_ImportePagoInmediato.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ImportePagoInmediato.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImportePagoInmediato.Location = new System.Drawing.Point(102, 179);
            this.txt_ImportePagoInmediato.Name = "txt_ImportePagoInmediato";
            this.txt_ImportePagoInmediato.ReadOnly = true;
            this.txt_ImportePagoInmediato.Size = new System.Drawing.Size(158, 24);
            this.txt_ImportePagoInmediato.TabIndex = 6;
            this.txt_ImportePagoInmediato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ImporteAhorro
            // 
            this.txt_ImporteAhorro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.tbl_Contenido.SetColumnSpan(this.txt_ImporteAhorro, 5);
            this.txt_ImporteAhorro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ImporteAhorro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImporteAhorro.Location = new System.Drawing.Point(11, 258);
            this.txt_ImporteAhorro.Name = "txt_ImporteAhorro";
            this.txt_ImporteAhorro.ReadOnly = true;
            this.txt_ImporteAhorro.Size = new System.Drawing.Size(549, 24);
            this.txt_ImporteAhorro.TabIndex = 8;
            this.txt_ImporteAhorro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_ImporteParcialidadPagoInmediato
            // 
            this.txt_ImporteParcialidadPagoInmediato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.txt_ImporteParcialidadPagoInmediato.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_ImporteParcialidadPagoInmediato.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImporteParcialidadPagoInmediato.Location = new System.Drawing.Point(391, 179);
            this.txt_ImporteParcialidadPagoInmediato.Name = "txt_ImporteParcialidadPagoInmediato";
            this.txt_ImporteParcialidadPagoInmediato.ReadOnly = true;
            this.txt_ImporteParcialidadPagoInmediato.Size = new System.Drawing.Size(169, 24);
            this.txt_ImporteParcialidadPagoInmediato.TabIndex = 7;
            this.txt_ImporteParcialidadPagoInmediato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_CantidadParcialidadPagoInmediato
            // 
            this.lbl_CantidadParcialidadPagoInmediato.AutoSize = true;
            this.lbl_CantidadParcialidadPagoInmediato.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_CantidadParcialidadPagoInmediato.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CantidadParcialidadPagoInmediato.Location = new System.Drawing.Point(273, 176);
            this.lbl_CantidadParcialidadPagoInmediato.Name = "lbl_CantidadParcialidadPagoInmediato";
            this.lbl_CantidadParcialidadPagoInmediato.Size = new System.Drawing.Size(112, 30);
            this.lbl_CantidadParcialidadPagoInmediato.TabIndex = 16;
            this.lbl_CantidadParcialidadPagoInmediato.Text = "- Abonos de:";
            this.lbl_CantidadParcialidadPagoInmediato.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Cerrar
            // 
            this.btn_Cerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.tbl_Contenido.SetColumnSpan(this.btn_Cerrar, 2);
            this.btn_Cerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cerrar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Cerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cerrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btn_Cerrar.Location = new System.Drawing.Point(11, 309);
            this.btn_Cerrar.Name = "btn_Cerrar";
            this.tbl_Contenido.SetRowSpan(this.btn_Cerrar, 2);
            this.btn_Cerrar.Size = new System.Drawing.Size(249, 50);
            this.btn_Cerrar.TabIndex = 9;
            this.btn_Cerrar.Text = "Cerrar";
            this.btn_Cerrar.UseVisualStyleBackColor = false;
            this.btn_Cerrar.Click += new System.EventHandler(this.btn_Cerrar_Click);
            // 
            // lbl_Bonificacion
            // 
            this.lbl_Bonificacion.AutoSize = true;
            this.tbl_Contenido.SetColumnSpan(this.lbl_Bonificacion, 3);
            this.lbl_Bonificacion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Bonificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Bonificacion.Location = new System.Drawing.Point(266, 306);
            this.lbl_Bonificacion.Name = "lbl_Bonificacion";
            this.tbl_Contenido.SetRowSpan(this.lbl_Bonificacion, 2);
            this.lbl_Bonificacion.Size = new System.Drawing.Size(294, 56);
            this.lbl_Bonificacion.TabIndex = 17;
            this.lbl_Bonificacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(391, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "P. Abono Mensual:";
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Cliente.Location = new System.Drawing.Point(23, 0);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(20, 18);
            this.lbl_Cliente.TabIndex = 2;
            this.lbl_Cliente.Text = "C";
            // 
            // CalcularAbono
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Cerrar;
            this.ClientSize = new System.Drawing.Size(632, 424);
            this.Controls.Add(this.tbl_Contenedor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MinimumSize = new System.Drawing.Size(648, 463);
            this.Name = "CalcularAbono";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calcular abono";
            this.tbl_Contenedor.ResumeLayout(false);
            this.tbl_Contenedor.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tbl_Contenido.ResumeLayout(false);
            this.tbl_Contenido.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbl_Contenedor;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tbl_Contenido;
        private System.Windows.Forms.Label lbl_Plazo;
        private System.Windows.Forms.Label lbl_TotalPagar;
        private System.Windows.Forms.Label lblFechaPrimerAbono;
        private System.Windows.Forms.Label lbl_PagoNormal;
        private System.Windows.Forms.Label lbl_PagoInmediato;
        private System.Windows.Forms.Label lbl_CantidadParcialidadPagoNormal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Plazo;
        private System.Windows.Forms.TextBox txt_TotalPagar;
        private System.Windows.Forms.TextBox txtFechaPrimerAbono;
        private System.Windows.Forms.TextBox txt_ImporteParcialidadPagoNormal;
        private System.Windows.Forms.TextBox txt_ImportePagoNormal;
        private System.Windows.Forms.TextBox txt_ImportePagoInmediato;
        private System.Windows.Forms.TextBox txt_ImporteAhorro;
        private System.Windows.Forms.TextBox txt_ImporteParcialidadPagoInmediato;
        private System.Windows.Forms.Label lbl_CantidadParcialidadPagoInmediato;
        private System.Windows.Forms.Button btn_Cerrar;
        private System.Windows.Forms.Label lbl_Bonificacion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Cliente;
    }
}