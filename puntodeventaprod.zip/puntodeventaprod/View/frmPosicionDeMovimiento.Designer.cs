﻿
namespace PuntoVenta.View
{
    partial class frmPosicionDeMovimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPosicionDeMovimiento));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.tlpPrincipal = new System.Windows.Forms.TableLayoutPanel();
            this.dgMovimientosOrigen = new System.Windows.Forms.DataGridView();
            this.gbOrigen = new System.Windows.Forms.GroupBox();
            this.tvOrigen = new System.Windows.Forms.TreeView();
            this.gbDestino = new System.Windows.Forms.GroupBox();
            this.tvDestino = new System.Windows.Forms.TreeView();
            this.dgMovimientosDestino = new System.Windows.Forms.DataGridView();
            this.lblMovimiento = new System.Windows.Forms.Label();
            this.tlpPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMovimientosOrigen)).BeginInit();
            this.gbOrigen.SuspendLayout();
            this.gbDestino.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMovimientosDestino)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRegresar
            // 
            this.btnRegresar.BackColor = System.Drawing.Color.Transparent;
            this.btnRegresar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRegresar.FlatAppearance.BorderSize = 0;
            this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.Image = ((System.Drawing.Image)(resources.GetObject("btnRegresar.Image")));
            this.btnRegresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnRegresar.Location = new System.Drawing.Point(3, 3);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(78, 74);
            this.btnRegresar.TabIndex = 36;
            this.btnRegresar.Text = "Regresar (Esc)";
            this.btnRegresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRegresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // tlpPrincipal
            // 
            this.tlpPrincipal.ColumnCount = 2;
            this.tlpPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPrincipal.Controls.Add(this.btnRegresar, 0, 0);
            this.tlpPrincipal.Controls.Add(this.dgMovimientosOrigen, 0, 2);
            this.tlpPrincipal.Controls.Add(this.gbOrigen, 0, 1);
            this.tlpPrincipal.Controls.Add(this.gbDestino, 1, 1);
            this.tlpPrincipal.Controls.Add(this.dgMovimientosDestino, 1, 2);
            this.tlpPrincipal.Controls.Add(this.lblMovimiento, 1, 0);
            this.tlpPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tlpPrincipal.Name = "tlpPrincipal";
            this.tlpPrincipal.RowCount = 3;
            this.tlpPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tlpPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPrincipal.Size = new System.Drawing.Size(691, 456);
            this.tlpPrincipal.TabIndex = 39;
            // 
            // dgMovimientosOrigen
            // 
            this.dgMovimientosOrigen.AllowUserToAddRows = false;
            this.dgMovimientosOrigen.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgMovimientosOrigen.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgMovimientosOrigen.BackgroundColor = System.Drawing.Color.White;
            this.dgMovimientosOrigen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgMovimientosOrigen.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgMovimientosOrigen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgMovimientosOrigen.EnableHeadersVisualStyles = false;
            this.dgMovimientosOrigen.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgMovimientosOrigen.Location = new System.Drawing.Point(3, 271);
            this.dgMovimientosOrigen.Name = "dgMovimientosOrigen";
            this.dgMovimientosOrigen.ReadOnly = true;
            this.dgMovimientosOrigen.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgMovimientosOrigen.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgMovimientosOrigen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgMovimientosOrigen.Size = new System.Drawing.Size(339, 182);
            this.dgMovimientosOrigen.TabIndex = 39;
            // 
            // gbOrigen
            // 
            this.gbOrigen.Controls.Add(this.tvOrigen);
            this.gbOrigen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbOrigen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbOrigen.Location = new System.Drawing.Point(3, 83);
            this.gbOrigen.Name = "gbOrigen";
            this.gbOrigen.Size = new System.Drawing.Size(339, 182);
            this.gbOrigen.TabIndex = 40;
            this.gbOrigen.TabStop = false;
            this.gbOrigen.Text = "Origen";
            // 
            // tvOrigen
            // 
            this.tvOrigen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvOrigen.Location = new System.Drawing.Point(3, 18);
            this.tvOrigen.Name = "tvOrigen";
            this.tvOrigen.Size = new System.Drawing.Size(333, 161);
            this.tvOrigen.TabIndex = 38;
            this.tvOrigen.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvOrigen_BeforeSelect);
            // 
            // gbDestino
            // 
            this.gbDestino.Controls.Add(this.tvDestino);
            this.gbDestino.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbDestino.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbDestino.Location = new System.Drawing.Point(348, 83);
            this.gbDestino.Name = "gbDestino";
            this.gbDestino.Size = new System.Drawing.Size(340, 182);
            this.gbDestino.TabIndex = 41;
            this.gbDestino.TabStop = false;
            this.gbDestino.Text = "Destino";
            // 
            // tvDestino
            // 
            this.tvDestino.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvDestino.Location = new System.Drawing.Point(3, 18);
            this.tvDestino.Name = "tvDestino";
            this.tvDestino.Size = new System.Drawing.Size(334, 161);
            this.tvDestino.TabIndex = 39;
            this.tvDestino.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvDestino_BeforeSelect);
            // 
            // dgMovimientosDestino
            // 
            this.dgMovimientosDestino.AllowUserToAddRows = false;
            this.dgMovimientosDestino.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgMovimientosDestino.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgMovimientosDestino.BackgroundColor = System.Drawing.Color.White;
            this.dgMovimientosDestino.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgMovimientosDestino.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgMovimientosDestino.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgMovimientosDestino.EnableHeadersVisualStyles = false;
            this.dgMovimientosDestino.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgMovimientosDestino.Location = new System.Drawing.Point(348, 271);
            this.dgMovimientosDestino.Name = "dgMovimientosDestino";
            this.dgMovimientosDestino.ReadOnly = true;
            this.dgMovimientosDestino.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgMovimientosDestino.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgMovimientosDestino.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgMovimientosDestino.Size = new System.Drawing.Size(340, 182);
            this.dgMovimientosDestino.TabIndex = 42;
            // 
            // lblMovimiento
            // 
            this.lblMovimiento.AllowDrop = true;
            this.lblMovimiento.AutoSize = true;
            this.lblMovimiento.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblMovimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblMovimiento.Location = new System.Drawing.Point(688, 0);
            this.lblMovimiento.Name = "lblMovimiento";
            this.lblMovimiento.Size = new System.Drawing.Size(0, 80);
            this.lblMovimiento.TabIndex = 43;
            // 
            // frmPosicionDeMovimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(691, 456);
            this.Controls.Add(this.tlpPrincipal);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frmPosicionDeMovimiento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Posicion Del Movimiento";
            this.Load += new System.EventHandler(this.frmPosicionDeMovimiento_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmPosicionDeMovimiento_KeyDown);
            this.tlpPrincipal.ResumeLayout(false);
            this.tlpPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMovimientosOrigen)).EndInit();
            this.gbOrigen.ResumeLayout(false);
            this.gbDestino.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgMovimientosDestino)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.TableLayoutPanel tlpPrincipal;
        public System.Windows.Forms.DataGridView dgMovimientosOrigen;
        private System.Windows.Forms.GroupBox gbOrigen;
        private System.Windows.Forms.TreeView tvOrigen;
        private System.Windows.Forms.GroupBox gbDestino;
        private System.Windows.Forms.TreeView tvDestino;
        public System.Windows.Forms.DataGridView dgMovimientosDestino;
        private System.Windows.Forms.Label lblMovimiento;
    }
}