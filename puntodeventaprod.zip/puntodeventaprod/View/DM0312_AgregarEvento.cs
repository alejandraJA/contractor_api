﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;
using PuntoVenta.View;

namespace PuntoVenta
{
    public partial class DM0312_AgregarEvento : Form
    {
        public static List<ModelAgregaEvento> list = new List<ModelAgregaEvento>();
        public static string recibeTexto;
        public static bool validaCierreForma;
        public static bool CancelarVenta;

        public string agente;
        public bool bandera = true;
        private readonly ControlAgregarEvento cAgregarEvento = new ControlAgregarEvento();
        public bool CancelarSituacion = false;

        //-430
        private readonly CDetalleVenta cDetalle = new CDetalleVenta();
        public string claveEvento = "";
        private readonly CtrlClaveSeguimiento claveSeguimiento = new CtrlClaveSeguimiento();
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        private readonly EventoController eventC = new EventoController();

        public bool fechaCorrectaSeguimiento;

        //-Dineralia
        public int iCanalVenta = 0;
        public List<DM0312_MComentariosVenta> ListaAgregaEventoComentario;
        private List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
        public string recibeCliente;
        public string recibeEstatus;
        public string recibeFecha;
        public string recibeHora;
        public string recibeIdecommerce;
        public string recibeIdventa;
        public string recibeIdVenta;

        public int recibeMensaje; // variable que valida el swith(determina que funcion abrirá)
        public string recibeMov;
        public string recibeMovId;
        public string recibeSituacion;
        public string recibeSucursal;
        public string recibeUsuario;
        public string tipoEvento = "";

        public string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        public int ValidaCanalVenta;
        public bool validaCierre = false;
        public bool validaUsuarioDima;

        public DM0312_AgregarEvento()
        {
            InitializeComponent();
            btn_CancelarVenta.Visible = false;
        }

        ~DM0312_AgregarEvento()
        {
            GC.Collect();
        }

        private void DM0312_AgregarEvento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "ClaveSeguimiento")
                    {
                        forma.Close();
                        break;
                    }

                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "AyudaAgente")
                    {
                        forma.Close();
                        break;
                    }

                if (!validaUsuarioDima)
                {
                    if (txt_AsuntObserva.Text == "" || cbx_Agente.Text == "")
                    {
                        DialogResult dialogResult = MessageBox.Show("Se perderan los avances ¿Esta seguro de Salir?",
                            "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (dialogResult == DialogResult.Yes)
                        {
                            foreach (Form forma in Application.OpenForms)
                                if (forma.Name == "DM0312_EventosNotasCitas")
                                {
                                    forma.Visible = true;
                                    Dispose();
                                    break;
                                }
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            validaCierreForma = false;
                            return;
                        }
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Se perderan los avances ¿Esta seguro de Salir?",
                            "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (dialogResult == DialogResult.Yes)
                        {
                            foreach (Form forma in Application.OpenForms)
                                if (forma.Name == "DM0312_EventosNotasCitas")
                                {
                                    forma.Visible = true;
                                    break;
                                }

                            validaCierreForma = true;
                            Dispose();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            validaCierreForma = false;
                            return;
                        }
                    }

                    validaCierreForma = true;
                    Dispose();
                }
                else
                {
                    MessageBox.Show("Debes de llenar todos los campos", "Advertencia!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }

            if (e.Control && e.KeyCode == Keys.G) GuardarEvent();

            if (e.KeyCode == Keys.F1)
            {
                CatalogoDeCalificaciones catalogoCalificacion = new CatalogoDeCalificaciones();
                catalogoCalificacion.ShowDialog();
            }

            if (e.KeyCode == Keys.F2)
                switch (recibeMensaje)
                {
                    case 1:
                        DM0312_ConsultarEvento consultaEvento = new DM0312_ConsultarEvento();
                        AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                        consultaEvento = (DM0312_ConsultarEvento)UsuarioAcceso.AplicarVistas(consultaEvento);
                        consultaEvento.recibeMovId = recibeMovId;
                        consultaEvento.recibeMov = recibeMov;
                        consultaEvento.recibeUsuario = recibeUsuario;
                        consultaEvento.recibeIdVenta = recibeIdVenta;
                        consultaEvento.opcionForma = 1;
                        consultaEvento.opcionForma = (int)Enums.EventoNotacita.Evento;
                        consultaEvento.CargarLista();
                        consultaEvento.ShowDialog();
                        break;

                    case 2:
                        DM0312_ConsultarEvento consultaNota = new DM0312_ConsultarEvento();
                        consultaNota.recibeIdVenta = recibeIdventa;
                        consultaNota.recibeMovId = recibeMovId;
                        consultaNota.recibeUsuario = recibeUsuario;
                        consultaNota.recibeSucursal = recibeSucursal;
                        consultaNota.recibeSituacion = recibeSituacion;
                        consultaNota.recibeEstatus = recibeEstatus;
                        consultaNota.recibeCliente = recibeCliente;
                        consultaNota.opcionForma = 2;
                        consultaNota.opcionForma = (int)Enums.EventoNotacita.Nota;
                        consultaNota.CargarLista();
                        consultaNota.ShowDialog();
                        break;


                    case 3:
                        DM0312_ConsultarEvento consultaCita = new DM0312_ConsultarEvento();
                        consultaCita.recibeMovId = recibeMovId;
                        consultaCita.recibeMov = recibeMov;
                        consultaCita.recibeUsuario = recibeUsuario;
                        consultaCita.recibeIdVenta = recibeIdVenta;
                        consultaCita.opcionForma = 3;
                        consultaCita.opcionForma = (int)Enums.EventoNotacita.Cita;
                        consultaCita.CargarLista();
                        consultaCita.ShowDialog();
                        break;

                    default:
                        Console.WriteLine("Error al seleccionar el menu");
                        break;
                }

            if (e.KeyCode == Keys.F3)
                if (recibeMensaje == 1)
                {
                    txt_Descripcion.Text = "";
                    cbx_Clave.Text = "";
                    recibeTexto = "";
                    DM0312_MComentariosVenta clave = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Clave"))
                        .FirstOrDefault();
                    txt_ComentarioAyuda.Text = clave.Comentario;

                    ClaveSeguimiento claveSeguimiento = new ClaveSeguimiento();
                    claveSeguimiento.recibeIdVenta = recibeIdVenta;
                    claveSeguimiento.recibeSucursal = recibeSucursal;
                    claveSeguimiento.recibeUsuario = recibeUsuario;
                    claveSeguimiento.recibeSituacion = recibeSituacion;
                    claveSeguimiento.recibeMensaje = recibeMensaje;
                    claveSeguimiento.recibeEstatus = recibeEstatus;
                    claveSeguimiento.ValidaCanalVenta = ValidaCanalVenta;
                    claveSeguimiento.validaCierreForma = true;
                    ClaveSeguimiento.recibeMov = recibeMov;
                    claveSeguimiento.recibeMovID = recibeMovId;
                    claveSeguimiento.recibeHora = cbx_Hora.Text;
                    claveSeguimiento.recibeFecha = txt_Fecha.Text;
                    claveSeguimiento.recibeTexto = txt_AsuntObserva.Text;


                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_EventosNotasCitas")
                        {
                            forma.Visible = false;
                            break;
                        }

                    txt_AsuntObserva.Text = recibeTexto;
                    claveSeguimiento.ShowDialog();
                    cbx_Hora.Text = recibeHora;
                    SendKeys.Send("{ENTER}");
                    foreach (ModelAgregaEvento model in list)
                    {
                        if (model.clave != null && model.descripcion != null)
                        {
                            cbx_Clave.Text = model.clave;
                            txt_Descripcion.Text = model.descripcion;
                            txt_AsuntObserva.Text = recibeTexto;
                            cbx_Hora.Text = recibeHora;
                            txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                            //DateTime day = controllerExplorador.FechaActualServidor();
                            //txt_Fecha.Text = day.ToShortDateString();
                        }

                        if (model.claveAgente != null && model.nombreAgente != null)
                        {
                            cbx_Agente.Text = model.claveAgente;
                            txt_AgenteDescripcion.Text = model.nombreAgente;
                            txt_AsuntObserva.Text = recibeTexto;
                            cbx_Hora.Text = recibeHora;
                            txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                            //DateTime day = controllerExplorador.FechaActualServidor();
                            //txt_Fecha.Text = day.ToShortDateString();
                        }
                    }

                    toolTip1.SetToolTip(txt_Descripcion, txt_Descripcion.Text);
                }
        }

        private void ck_Cliente_CheckedChanged(object sender, EventArgs e)
        {
            if (ck_Cliente.Checked) ck_Aval.Checked = false;
        }

        private void ck_Aval_CheckedChanged(object sender, EventArgs e)
        {
            if (ck_Aval.Checked) ck_Cliente.Checked = false;
        }

        #region "Methods"

        private bool ValidaInsertEvento()
        {
            bool validaTemp = false;
            string agente = cbx_Agente.Text;
            string clave = cbx_Clave.Text;
            string modulo = "VTAS";
            int movId = Convert.ToInt32(recibeIdVenta);
            DateTime date = controllerExplorador.FechaActualServidor();
            string datefinal = date.ToString("yyyy-MM-dd HH:mm:ss");
            string evento = txt_AsuntObserva.Text;
            int sucursal = Convert.ToInt32(recibeSucursal);
            string usuario = ClaseEstatica.Usuario.Usser;
            string tipo = "Comentario";
            string situacion = recibeSituacion;
            string estatus = recibeEstatus;

            //1655
            ListaNegraHistorico listaNegraHistorico = new ListaNegraHistorico();
            listaNegraHistorico.idVenta = Convert.ToInt32(recibeIdVenta);
            listaNegraHistorico.usuario = usuario;
            listaNegraHistorico.calificacion = clave;
            listaNegraHistorico.observaciones = evento;
            listaNegraHistorico.origen = "INTELISIS";

            if (situacion == "" || situacion == null)
                situacion = "";
            else
                situacion = recibeSituacion;
            if (estatus == "(Todos)" || estatus == null) estatus = "";
            if (situacion == "(Todos)") situacion = "";
            if (evento == "") evento = txt_AsuntObserva.Text;

            //-RQ Forma de Pago Negativa Buro
            //validaTemp = cAgregarEvento.InsertaEvento(agente, clave, modulo, movId, datefinal, evento, sucursal, usuario, tipo, estatus, situacion, 0, 0, Convert.ToDateTime(txt_Fecha.Text), "", "EVENTO", recibeMov);

            /*string Variant = "agente" + agente +
                             "\nclave" + clave +
                             "\nmodulo" + modulo +
                             "\nmovId" + movId.ToString() +
                             "\ndatefinal" + datefinal +
                             "\nevento" + evento +
                             "\nsucursal" + sucursal.ToString() +
                             "\nusuario" + usuario +
                             "\ntipo" + tipo +
                             "\nestatus" + estatus +
                             "\nsituacion" + situacion +
                             "\n0" +
                             "\n0" +
                             "\ntxt_Fecha.Text" + txt_Fecha.Text +
                             "\nVOID" +
                             "\nEVENTO" +
                             "\nrecibeMov" + recibeMov +
                             "\nrecibeCliente" + recibeCliente;

            MessageBox.Show(Variant);*/

            if (recibeMensaje == 6) evento = date.ToString("yyyy-MM-dd") + " " + evento;

            validaTemp = cAgregarEvento.InsertaEvento(agente, clave, modulo, movId, datefinal, evento, sucursal,
                usuario, tipo, estatus, situacion, 0, 0, Convert.ToDateTime(txt_Fecha.Text), "", "EVENTO", recibeMov,
                recibeCliente);

            //-ListaNegra
            cAgregarEvento.ejecutarListaNegra(claveEvento, evento, int.Parse(recibeSucursal), int.Parse(recibeIdVenta));

            cAgregarEvento.listaNegraHistorico(listaNegraHistorico);

            return validaTemp;
        }

        private bool ValidaInsertNota()
        {
            bool validaTemp;
            string modulo = "CXC";
            string evento = txt_AsuntObserva.Text;
            string cuenta = recibeCliente;
            string usuario = ClaseEstatica.Usuario.Usser; // ventp
            validaTemp = cAgregarEvento.InsertaNota(modulo, cuenta, evento, usuario);
            return validaTemp;
        }

        private bool ValidaInsertaSituacion()
        {
            bool validaTemp = false;
            string agente = cbx_Agente.Text;
            string clave = "VTA99999";
            string modulo = "VTAS";
            int movId = Convert.ToInt32(recibeIdVenta);
            DateTime date = Convert.ToDateTime(dtp_Fecha.Value);
            string datefinal = date.ToString("yyyy-MM-dd HH:mm:ss");
            string evento = recibeTexto;
            int sucursal = Convert.ToInt32(recibeSucursal);
            string usuario = ClaseEstatica.Usuario.Usser;
            string tipo = "Comentario";
            string situacion = recibeSituacion;
            string estatus = recibeEstatus;
            string hora = recibeHora;
            DateTime horaActual = controllerExplorador.FechaActualServidor();
            string horaActualFinal = horaActual.ToString("yyyy-MM-dd HH:mm:ss");
            DateTime day = DateTime.Now;
            string horaAct = cbx_Hora.Text;
            int checkCliente = 0;
            int chackaval = 0;

            if (situacion == "" || situacion == null)
                situacion = "";
            else
                situacion = recibeSituacion;
            if (estatus == "(Todos)") estatus = "";
            if (situacion == "(Todos)") situacion = "";
            if (evento == "" || evento == null) evento = txt_AsuntObserva.Text;
            if (cbx_Hora.Text == "" || cbx_Hora.Text == null)
            {
                MessageBox.Show("Se debe de ingresar la Hora", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }

            if (hora == "" || hora == null) hora = cbx_Hora.Text;
            if (ck_Cliente.Checked)
            {
                checkCliente = 1;
            }
            else
            {
                if (ck_Aval.Checked) chackaval = 1;
            }

            //-RQ Forma de Pago Negativa Buro
            //validaTemp = cAgregarEvento.InsertaEvento(agente, clave, modulo, movId, horaActualFinal, txt_Fecha.Text + " " + horaAct + " Observaciones : " + evento, sucursal, usuario, tipo, recibeEstatus, situacion, checkCliente, chackaval, Convert.ToDateTime(txt_Fecha.Text), horaAct, "CITA");
            /*string Variables = "agente" + agente +
                               "\nclave" + clave +
                               "\nmodulo" + modulo +
                               "\nmovId" + movId.ToString() +
                               "\nhoraActualFinal" + horaActualFinal +
                               "\ntxt_Fecha" + txt_Fecha.Text +
                               "\nhoraAct" + horaAct +
                               "\n Observaciones : " + evento +
                               "\nsucursal" + sucursal +
                               "\nusuario" + usuario +
                               "\ntipo" + tipo +
                               "\nrecibeEstatus" + recibeEstatus +
                               "\nsituacion" + situacion +
                               "\ncheckCliente" + checkCliente.ToString() +
                               "\nchackaval" + chackaval.ToString() +
                               "\ntxt_Fecha" + txt_Fecha.Text +
                               "\nhoraAct" + horaAct +
                               "\nCITA: CITA" +
                               "\nrecibeMov" + recibeMov +
                               "\nrecibeCliente" + recibeCliente;

            MessageBox.Show(Variables);*/

            validaTemp = cAgregarEvento.InsertaEvento(agente, clave, modulo, movId, horaActualFinal,
                txt_Fecha.Text + " " + horaAct + " Observaciones : " + evento, sucursal, usuario, tipo, recibeEstatus,
                situacion, checkCliente, chackaval, Convert.ToDateTime(txt_Fecha.Text), horaAct, "CITA", recibeMov,
                recibeCliente);
            return validaTemp;
        }

        public bool fill_cbx_Agente()
        {
            bool validaUsuario = false;
            List<ModelAgregaEvento> listAgent = new List<ModelAgregaEvento>();
            listAgent = cAgregarEvento.fillAgent(ClaseEstatica.Usuario.Usser);
            if (ClaseEstatica.Usuario.Acceso != "VENTP_LIMA")
            {
                ModelAgregaEvento valAgente = listAgent.Where(x => x.ClaveAgente.Equals(ClaseEstatica.Usuario.Usser))
                    .FirstOrDefault();
                if (valAgente.Clave != "")
                {
                    cbx_Agente.Text = valAgente.Clave;
                    txt_AgenteDescripcion.Text = valAgente.NombreAgente;
                    validaUsuario = true;
                }
            }

            return validaUsuario;
        }

        #endregion

        #region "Handles"

        public void AgregarEvento_Load(object sender, EventArgs e)
        {
            if (validaUsuarioDima)
            {
                btn_CancelarVenta.Visible = true;
                btn_Regresar.Visible = false;
            }

            Name = "Agregar Evento";
            lbl_Cliente.Text = recibeCliente;
            lbl_Mov.Text = recibeMov;
            lbl_MovId.Text = recibeMovId;
            cbx_Clave.Text = "";
            txt_Descripcion.Text = "";
            txt_AgenteDescripcion.Text = "";
            txt_AsuntObserva.Text = "";
            cbx_Agente.Text = "";
            txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
            DateTime fechaServidor = Convert.ToDateTime(controllerExplorador.FechaActualServidor().ToString());
            dtp_Fecha.MinDate = fechaServidor;

            if (fill_cbx_Agente()) cbx_Agente.Enabled = false;


            init_cbx_clave_agente();

            txt_AsuntObserva.Text = recibeTexto;
            cbx_Hora.Text = recibeHora;
            initTipoDeEvento();

            ///////////////////////////////////////////////////////////////////////
            ListaAgregaEventoComentario = Funciones.ConsultaComentario("Agregar Evento");

            listModel = cAgregarEvento.LlenaComboClaveEvento();
        }

        private void init_cbx_clave_agente()
        {
            cbx_Clave.Items.Clear();
            cbx_Clave.SelectedIndex = -1;
            foreach (ModelAgregaEvento model in list)
            {
                if (model.clave != null && model.descripcion != null)
                {
                    cbx_Clave.Text = model.clave;
                    txt_Descripcion.Text = model.descripcion;
                    txt_AsuntObserva.Text = recibeTexto;
                    cbx_Hora.Text = recibeHora;
                    txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                }

                if (model.claveAgente != null && model.nombreAgente != null)
                {
                    cbx_Agente.Text = model.claveAgente;
                    txt_AgenteDescripcion.Text = model.nombreAgente;
                    txt_AsuntObserva.Text = recibeTexto;
                    cbx_Hora.Text = recibeHora;
                    txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                }
            }
        }

        private void initTipoDeEvento()
        {
            switch (recibeMensaje)
            {
                case 1:
                    lbl_Observaciones.Visible = false;
                    lbl_Hora.Visible = false;
                    cbx_Hora.Visible = false;
                    dtp_Fecha.Visible = false;
                    lbl_Fecha.Location = new Point(507, 32);
                    txt_Fecha.Location = new Point(559, 29);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(98, 227);
                    txt_Descripcion.Location = new Point(233, 51);
                    txt_AgenteDescripcion.Location = new Point(252, 230);
                    txt_Fecha.Enabled = false;
                    Text = "Agregar Evento";
                    tipoEvento = "EL EVENTO";
                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UN EVENTO, PARA PODER GUARDARLO SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN *. SELECCIONAR F1 PARA VER EL CATÁLOGO DE CALIFICACIONES, F2 PARA CONSULTAR LOS EVENTOS Y F3 PARA ABRIR EL CATÁLOGO DE CLAVES";
                    if (usuarioVenta == "CREDI")
                    {
                        toolTip1.SetToolTip(cbx_Clave,
                            "CLAVE DEL EVENTO QUE SE VA AGREGAR, AL AGREGAR LA CLAVE SE ACTUALIZARA LA SITUACION QUE LE CORRESPONDE A CADA CLAVE DE EVENTO");
                        toolTip1.SetToolTip(lbl_Clave,
                            "CLAVE DEL EVENTO QUE SE VA AGREGAR, AL AGREGAR LA CLAVE SE ACTUALIZARA LA SITUACION QUE LE CORRESPONDE A CADA CLAVE DE EVENTO");
                    }
                    else
                    {
                        toolTip1.SetToolTip(cbx_Clave, "CLAVE DEL EVENTO QUE SE VA AGREGAR");
                        toolTip1.SetToolTip(lbl_Clave, "CLAVE DEL EVENTO QUE SE VA AGREGAR");
                    }

                    toolTip1.SetToolTip(txt_Descripcion, "NOMBRE DE LA CLAVE DEL EVENTO");
                    toolTip1.SetToolTip(txt_AsuntObserva, "OBSERVACIONES A ANEXAR AL EVENTO: " + cbx_Clave.Text);
                    toolTip1.SetToolTip(lbl_Asunto, "OBSERVACIONES A ANEXAR AL EVENTO: " + cbx_Clave.Text);
                    toolTip1.SetToolTip(cbx_Agente, "USUARIO QUE GENERA EL EVENTO");
                    toolTip1.SetToolTip(lbl_Agente, "USUARIO QUE GENERA EL EVENTO");
                    toolTip1.SetToolTip(txt_AgenteDescripcion, "NOMBRE DEL USUARIO QUE GENERA EL EVENTO");
                    toolTip1.SetToolTip(lbl_Fecha, "FECHA ACTUAL EN LA QUE SE GENERA EL EVENTO");
                    toolTip1.SetToolTip(txt_Fecha, "FECHA ACTUAL EN LA QUE SE GENERA EL EVENTO");
                    break;

                case 2:
                    lbl_Observaciones.Visible = false;
                    lbl_Agente.Visible = false;
                    cbx_Agente.Visible = false;
                    txt_AgenteDescripcion.Visible = false;
                    lbl_Clave.Visible = false;
                    cbx_Clave.Visible = false;
                    lbl_Hora.Visible = false;
                    lbl_Mov.Visible = false;
                    txt_Descripcion.Visible = false;
                    lbl_MovId.Visible = false;
                    cbx_Hora.Visible = false;
                    lbl_Fecha.Location = new Point(30, 70);
                    dtp_Fecha.Location = new Point(155, 70);
                    txt_Fecha.Location = new Point(90, 70);
                    lbl_Asunto.Location = new Point(28, 124);
                    txt_AsuntObserva.Location = new Point(91, 124);
                    dtp_Fecha.Enabled = false;
                    lbl_Mov.Visible = false;
                    lbl_Movimiento.Visible = false;
                    lbl_MovimientoID.Visible = false;
                    lbl_MovId.Visible = false;
                    Text = "Agregar Nota";
                    tipoEvento = "LA NOTA";
                    lbl_Asunto.Text = "*Asunto";
                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UNA NOTA, PARA PODER GUARDARLA SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN *. SELECCIONAR F1 PARA VER EL CATÁLOGO DE CALIFICACIONES, Y F2 PARA CONSULTAR LOS EVENTOS";
                    toolTip1.SetToolTip(lbl_Asunto,
                        "AGREGAR CONTENIDO DE LA NOTA, EN LA CUAL PUEDE SER ALGUNA OBSERVACION O ACLARACION");
                    toolTip1.SetToolTip(txt_AsuntObserva,
                        "AGREGAR CONTENIDO DE LA NOTA, EN LA CUAL PUEDE SER ALGUNA OBSERVACION O ACLARACION");
                    toolTip1.SetToolTip(lbl_Fecha, "FECHA ACTUAL EN LA QUE SE GENERA LA NOTA");
                    toolTip1.SetToolTip(txt_Fecha, "FECHA ACTUAL EN LA QUE SE GENERA LA NOTA");
                    break;

                case 3:
                    ck_Cliente.Visible = true;
                    ck_Aval.Visible = true;
                    lbl_Agente.Visible = false;
                    cbx_Agente.Visible = false;
                    cbx_Agente.Visible = false;
                    lbl_Clave.Visible = false;
                    cbx_Agente.Visible = true;
                    lbl_Agente.Visible = true;
                    cbx_Clave.Visible = false;
                    txt_Descripcion.Visible = false;
                    lbl_Asunto.Visible = false;
                    lbl_Fecha.Location = new Point(26, 50);
                    dtp_Fecha.Location = new Point(155, 50);
                    txt_Fecha.Location = new Point(90, 50);
                    lbl_Hora.Location = new Point(240, 50);
                    cbx_Hora.Location = new Point(280, 50);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(98, 227);
                    txt_AgenteDescripcion.Location = new Point(252, 226);
                    Text = "Agregar Cita";
                    tipoEvento = "LA CITA";
                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UNA CITA DE SUPERVISION, PARA PODER GUARDARLA SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN * NO OLVIDAR PONER EL RANGO DE HORA EN QUE SERA LA CITA. SELECCIONAR F1 PARA VER EL CATÁLOGO DE CALIFICACIONES, Y F2 PARA CONSULTAR LOS EVENTOS";
                    lbl_Hora.Text = "*Hora";
                    lbl_Fecha.Text = "*Fecha";
                    toolTip1.SetToolTip(cbx_Hora,
                        "AGREGAR EL RANGO DE HORA EN LA QUE SE REALIZARA LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(lbl_Hora,
                        "AGREGAR EL RANGO DE HORA EN LA QUE SE REALIZARA LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(txt_Descripcion, "POSIBLES COMENTARIOS SOBRE LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(txt_AsuntObserva, "POSIBLES COMENTARIOS SOBRE LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(lbl_Observaciones, "POSIBLES COMENTARIOS SOBRE LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(cbx_Agente, "USUARIO QUE GENERA LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(lbl_Agente, "USUARIO QUE GENERA LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(txt_AgenteDescripcion, "NOMBRE DEL USUARIO QUE GENERA LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(lbl_Fecha,
                        "AGREGAR LA FECHA EN LA QUE SE LLEVARA A CABO LA CITA DE SUPERVICION");
                    toolTip1.SetToolTip(txt_Fecha,
                        "AGREGAR LA FECHA EN LA QUE SE LLEVARA A CABO LA CITA DE SUPERVICION");
                    break;

                case 4: // Reactivacion Liberacion
                    lbl_Observaciones.Visible = false;
                    lbl_Hora.Visible = false;
                    cbx_Hora.Visible = false;
                    dtp_Fecha.Visible = false;
                    btn_ayuda.Visible = false;

                    lbl_Fecha.Location = new Point(507, 32);
                    txt_Fecha.Location = new Point(559, 29);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(125, 227);
                    txt_Descripcion.Location = new Point(233, 51);
                    txt_AgenteDescripcion.Location = new Point(272, 230);

                    txt_Fecha.Enabled = false;
                    cbx_Agente.Enabled = false;
                    cbx_Clave.Enabled = false;

                    cbx_Clave.Items.Clear();
                    cbx_Clave.Text = "VTA10000";
                    tipoEvento = "REACTIVACIÓN (LIBERACIÓN)";
                    txt_Descripcion.Text = eventC.getDescripcionEvento(cbx_Clave.Text);
                    txt_Descripcion.Text = "REACTIVACIÓN (LIBERACIÓN)";


                    cbx_Agente.Items.Clear();
                    cbx_Agente.Text = agente;
                    txt_AgenteDescripcion.Text = cAgregarEvento.nombreAgente(agente);

                    lbl_Agente.Text = "Agente Ventas";
                    Text = "Reactivación Liberación";
                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UN EVENTO, PARA PODER GUARDARLO SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN *.";

                    break;
                case 5: // Reactivacion Complemento
                    lbl_Observaciones.Visible = false;
                    lbl_Hora.Visible = false;
                    cbx_Hora.Visible = false;
                    dtp_Fecha.Visible = false;
                    btn_ayuda.Visible = false;

                    lbl_Fecha.Location = new Point(507, 32);
                    txt_Fecha.Location = new Point(559, 29);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(125, 227);
                    txt_Descripcion.Location = new Point(233, 51);
                    txt_AgenteDescripcion.Location = new Point(272, 230);

                    txt_Fecha.Enabled = false;
                    cbx_Agente.Enabled = false;
                    cbx_Clave.Enabled = false;

                    cbx_Clave.Items.Clear();
                    cbx_Clave.Text = "VTA00012";
                    tipoEvento = "REACTIVACIÓN (COMPLEMENTO)";
                    txt_Descripcion.Text = eventC.getDescripcionEvento(cbx_Clave.Text);
                    txt_Descripcion.Text = "REACTIVACIÓN (COMPLEMENTO)";


                    cbx_Agente.Items.Clear();
                    cbx_Agente.Text = agente;
                    txt_AgenteDescripcion.Text = cAgregarEvento.nombreAgente(agente);

                    lbl_Agente.Text = "Agente Ventas";
                    Text = "Reactivación Complemento";

                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UN EVENTO, PARA PODER GUARDARLO SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN *.";

                    break;
                case 6: // Fecha Seguimiento
                    lbl_Observaciones.Visible = false;
                    lbl_Hora.Visible = false;
                    cbx_Hora.Visible = false;
                    btn_ayuda.Visible = false;
                    txt_Fecha.Visible = true;
                    dtp_Fecha.Visible = true;

                    lbl_Fecha.Location = new Point(507, 32);
                    txt_Fecha.Location = new Point(559, 29);
                    dtp_Fecha.Location = new Point(628, 29);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(125, 227);
                    txt_Descripcion.Location = new Point(233, 51);
                    txt_AgenteDescripcion.Location = new Point(272, 230);

                    dtp_Fecha.Enabled = true;
                    cbx_Agente.Enabled = false;
                    cbx_Clave.Enabled = false;

                    cbx_Clave.Items.Clear();
                    cbx_Clave.Text = "VTA10001";
                    txt_Descripcion.Text = eventC.getDescripcionEvento(cbx_Clave.Text);

                    cbx_Agente.Items.Clear();
                    cbx_Agente.Text = agente;
                    txt_AgenteDescripcion.Text = cAgregarEvento.nombreAgente(agente);
                    //txt_AgenteDescripcion.Text = "ANALISIS CON SEGUIMIENTO DE SUC";


                    lbl_Agente.Text = "Agente Ventas";
                    Text = "Seguimiento";
                    if (recibeMov != "Analisis Credito" && recibeEstatus != "PENDIENTE") Text = "Agregar Evento";
                    tipoEvento = "ANALISIS CON SEGUIMIENTO DE SUC";
                    txt_Comentarios.Text =
                        "Forma para agregar un evento, para poder guardarlo se  tienen que llenar los campos que contengan un * (campo obligatorio).";

                    dtp_Fecha.MinDate = eventC.FechaActualServidor();
                    dtp_Fecha.MaxDate = eventC.FechaActualServidor().AddDays(eventC.getStdDIASHABIL() - 1);

                    // 1286 puede que inicie desde 0 o 1 depende de como lo quiera el area
                    /*for(int i = 0; i < eventC.getStdDIASHABIL(); i++) {
                        if (eventC.FechaActualServidor().AddDays(i).DayOfWeek == DayOfWeek.Saturday ) {
                            dtp_Fecha.MaxDate = dtp_Fecha.MaxDate.AddDays(1);
                        }
                        dtp_Fecha.MaxDate = dtp_Fecha.MaxDate.AddDays( 1);
                    }*/

                    break;
                case 7: // Reanalisis
                    lbl_Observaciones.Visible = false;
                    lbl_Hora.Visible = false;
                    cbx_Hora.Visible = false;
                    dtp_Fecha.Visible = false;
                    btn_ayuda.Visible = false;

                    lbl_Fecha.Location = new Point(507, 32);
                    txt_Fecha.Location = new Point(559, 29);
                    lbl_Agente.Location = new Point(35, 230);
                    cbx_Agente.Location = new Point(125, 227);
                    txt_Descripcion.Location = new Point(233, 51);
                    txt_AgenteDescripcion.Location = new Point(272, 230);

                    txt_Fecha.Enabled = false;
                    cbx_Agente.Enabled = false;
                    cbx_Clave.Enabled = false;

                    cbx_Clave.Items.Clear();
                    cbx_Clave.Text = "VTA00050";
                    tipoEvento = "SOLICITUD DE REANALISIS";
                    txt_Descripcion.Text = eventC.getDescripcionEvento(cbx_Clave.Text);
                    txt_Descripcion.Text = "SOLICITUD DE REANALISIS";

                    cbx_Agente.Items.Clear();
                    cbx_Agente.Text = agente;
                    txt_AgenteDescripcion.Text = cAgregarEvento.nombreAgente(agente);

                    lbl_Agente.Text = "Agente Ventas";
                    Text = "Reanalisis";

                    txt_Comentarios.Text =
                        "FORMA PARA AGREGAR UN EVENTO, PARA PODER GUARDARLO SE TIENEN QUE LLENAR LOS CAMPOS QUE CONTENGAN UN *.";

                    break;

                default:
                    MessageBox.Show("Tipo Evento Error");
                    break;
            }

            toolTip1.SetToolTip(btn_Guardar,
                "SI YA SE INGRESO INFORMACION EN LOS CAMPOS OBLIGATORIOS, SELECCIONAR PARA GUARDAR " + tipoEvento);
            toolTip1.SetToolTip(btn_Regresar, "SELECCIONAR PARA CANCELAR " + tipoEvento);
            toolTip1.SetToolTip(btn_CancelarVenta, "SELECCIONAR PARA CANCELAR " + tipoEvento + " Y LA VENTA");
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER MANUAL DE COMO UTILIZAR LA FORMA");
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "ClaveSeguimiento")
                {
                    forma.Close();
                    break;
                }

            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "AyudaAgente")
                {
                    forma.Close();
                    break;
                }

            if (!validaUsuarioDima)
                switch (recibeMensaje)
                {
                    case 1:

                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 2:
                        if (txt_AsuntObserva.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 3:
                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "" ||
                            cbx_Hora.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 4:

                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 5:

                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 6:
                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?",
                                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;
                    case 7:

                        if (txt_AsuntObserva.Text != "" || cbx_Agente.Text != "" || cbx_Clave.Text != "")
                        {
                            DialogResult dialogResult = MessageBox.Show(
                                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        Dispose();
                                        break;
                                    }
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Esta seguro de Salir?", "Confirmar",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dialogResult == DialogResult.Yes)
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_EventosNotasCitas")
                                    {
                                        forma.Visible = true;
                                        break;
                                    }

                                validaCierreForma = true;
                                Dispose();
                            }
                            else if (dialogResult == DialogResult.No)
                            {
                                validaCierreForma = false;
                                return;
                            }
                        }

                        validaCierreForma = true;
                        Dispose();
                        break;

                    default:
                        Console.WriteLine("Error al regresar");
                        break;
                }
            else
                MessageBox.Show("Debes de llenar todos los campos", "Advertencia!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        //-Venta Cruzada 
        public void GuardarEvent()
        {
            if (recibeCliente.Substring(0, 1) == "P" && (cbx_Clave.Text.Contains("MEN06207") ||
                                                         cbx_Clave.Text.Contains("MEN06208") ||
                                                         cbx_Clave.Text.Contains("MEN06209") ||
                                                         cbx_Clave.Text.Contains("MEN06210")))
            {
                MessageBox.Show(
                    "Este evento no se puede agregar a un prospecto, favor de asignar una cuenta al cliente",
                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cbx_Clave.Text == "MEN03621")
            {
                string sBeneficiarioFinal = cAgregarEvento.obtenerBeneficiarioFinal(int.Parse(recibeIdVenta));
                if (!string.IsNullOrEmpty(sBeneficiarioFinal))
                    if (cAgregarEvento.ValidarAltaCteFValida(sBeneficiarioFinal))
                    {
                        MessageBox.Show(
                            "El registro de ALTA del beneficiario final aun no esta validado, favor de revisar.",
                            "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Close();
                        return;
                    }
            }

            bool validaInsercion;
            if (recibeMensaje == 1)
            {
                if (cbx_Clave.Text != "" && cbx_Agente.Text != "")
                {
                    //
                    string RESUL = controllerExplorador.ValidaEventoVCruzada(cbx_Clave.Text);
                    if (RESUL != "NO")
                        if (controllerExplorador.ventaCruzadaSuc(recibeMov, recibeMovId) != 501)
                        {
                            MessageBox.Show("Este evento es exclusivo para venta cruzada", "Advertencia!!",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            cbx_Clave.Text = "";
                            return;
                        }

                    validaInsercion = ValidaInsertEvento();
                    if (validaInsercion)
                    {
                        //-430
                        if (iCanalVenta == 76 || iCanalVenta == 80)
                            if (cDetalle.validarDimaNuevo(int.Parse(recibeIdVenta)))
                                if (recibeMov == "Solicitud Credito" || recibeMov == "Analisis Credito")
                                {
                                    string vObservaciones = txt_AsuntObserva.Text;
                                    string vCalificacion = cbx_Clave.Text;

                                    cDetalle.ActualizarHistorialEventos(recibeEstatus, recibeMov, recibeMovId,
                                        vCalificacion, vObservaciones);
                                }

                        validaCierreForma = true;
                        DM0312_DetalleVenta.EventoInsertado = true;
                        MessageBox.Show("Registro almacenado con exito", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        string clave = cbx_Clave.Text;

                        //if (ClaseEstatica.Usuario.usuario.Substring(0,5) == "CREDI")
                        //{
                        //    controllerExplorador.depurarNotificaciones();
                        //}

                        //-Dineralia
                        CDetalleVenta cDetalleVenta = new CDetalleVenta();
                        DM0312_DetalleVenta detalleVenta = new DM0312_DetalleVenta();
                        if (recibeMov == "Analisis Credito" && iCanalVenta == 77 && recibeEstatus == "PENDIENTE")
                        {
                            recibeSituacion = cDetalleVenta.obtenerSituacion(int.Parse(recibeIdVenta));
                            string sCorreo = cDetalleVenta.validarCorreo(int.Parse(recibeIdVenta), recibeSituacion);
                            if (!string.IsNullOrEmpty(sCorreo))
                            {
                                //aqui mando el aceptado
                                string sHtml =
                                    detalleVenta.hmtlDineralia(sCorreo, recibeCliente, int.Parse(recibeIdVenta));
                                string sCorreoCliente = cDetalleVenta.obtenerNombreCliente(recibeCliente, 2);
                                List<string> lsCorreoCliente = new List<string>();
                                lsCorreoCliente.Add(sCorreoCliente);
                                if (sCorreo == "CreditoNoAprobado")
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                if (sCorreo == "CONDICIONADO" || sCorreo == "CreditoAprobadoAjuste")
                                {
                                    cDetalle.insertarDatosSms(recibeCliente, cbx_Clave.Text, int.Parse(recibeIdVenta),
                                        "PRETENCIONES", "");
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                    cDetalle.insertarSms(recibeCliente, int.Parse(recibeIdVenta), 37);
                                }

                                if (sCorreo == "CreditoAprobado")
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                cDetalleVenta.actualizarCorreoEnviado(int.Parse(recibeIdVenta));
                            }
                        }

                        string validaUsuario_ = ClaseEstatica.Usuario.Usser.Substring(0, 5);
                        if (RESUL != "NO" && recibeMov == "Analisis Credito" && recibeEstatus == "PENDIENTE" &&
                            validaUsuario_ == "CREDI")
                            if (controllerExplorador.ventaCruzadaSuc(recibeMov, recibeMovId) == 501)
                            {
                                int idOrigen = controllerExplorador.origenID(recibeMov, recibeMovId);
                                string agente = controllerExplorador.ValidaAgenteVCruzada(idOrigen);
                                if (RESUL == "NEGATIVO")
                                {
                                    int res = controllerExplorador.RespVentaCruzada(agente,
                                        Convert.ToInt32(recibeIdVenta));
                                }
                                else
                                {
                                    if (RESUL == "POSITIVO")
                                    {
                                        controllerExplorador.RespVentaCruzadaAsig(agente, recibeCliente);
                                        int res = controllerExplorador.RespVentaCruzada(agente,
                                            Convert.ToInt32(recibeIdVenta));
                                    }
                                }
                            }

                        validaUsuarioDima = false;
                        //this.Close();
                        DM0312_ExploradorVentas.EjecutaEvento = true;
                        Dispose();
                        validaCierreForma = true;
                        foreach (Form forma in Application.OpenForms)
                            if (forma.Name == "DM0312_EventosNotasCitas")
                            {
                                forma.Visible = true;
                                break;
                            }
                    } //Termina If (validaInsercion == true)
                }
                else
                {
                    if (cbx_Clave.Text == "" && cbx_Agente.Text == "")
                    {
                        MessageBox.Show("Debe ingresar una clave de evento y un agente", "Advertencia!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cbx_Clave.Select();
                        iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                        iconError.SetError(cbx_Agente, "Ingresar usuario que realiza el evento");
                    }
                    else
                    {
                        if (cbx_Clave.Text == "")
                        {
                            MessageBox.Show("Debe ingresar una clave de evento", "Advertencia!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            cbx_Clave.Select();
                            iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                        }
                        else
                        {
                            if (cbx_Agente.Text == "")
                            {
                                MessageBox.Show("Debe ingresar un agente", "Advertencia!!", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                                cbx_Agente.Select();
                                iconError.SetError(cbx_Agente, "Ingresar usuario que realiza el evento");
                            }
                        }
                    }
                }
            }

            if (recibeMensaje == 2)
            {
                if (txt_AsuntObserva.Text != "")
                {
                    validaInsercion = ValidaInsertNota();
                    if (validaInsercion)
                    {
                        MessageBox.Show("Registro almacenado con exito", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        Close();
                        validaCierreForma = true;
                        foreach (Form forma in Application.OpenForms)
                            if (forma.Name == "DM0312_EventosNotasCitas")
                            {
                                forma.Visible = true;
                                break;
                            }
                    }
                }
                else
                {
                    MessageBox.Show("Debe ingresar un asunto para guardar su nota", "Advertencia!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            if (recibeMensaje == 3)
            {
                if (ck_Aval.Checked || ck_Cliente.Checked)
                {
                    if (cbx_Hora.Text != "" && cbx_Agente.Text != "")
                    {
                        validaInsercion = ValidaInsertaSituacion();
                        if (validaInsercion)
                        {
                            MessageBox.Show("Registro almacenado con exito", "Mensaje!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                            Close();
                            validaCierreForma = true;
                            foreach (Form forma in Application.OpenForms)
                                if (forma.Name == "DM0312_EventosNotasCitas")
                                {
                                    forma.Visible = true;
                                    break;
                                }
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se permite ingresar registros en blanco", "Advertencia!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("No se permite guardar cita, favor de agregar si sera de tipo aval o cliente",
                        "Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            if (recibeMensaje == 4 || recibeMensaje == 5 || recibeMensaje == 6 || recibeMensaje == 7)
            {
                if (cbx_Clave.Text != "" && cbx_Agente.Text != "")
                {
                    //
                    string RESUL = controllerExplorador.ValidaEventoVCruzada(cbx_Clave.Text);
                    if (RESUL != "NO")
                        if (controllerExplorador.ventaCruzadaSuc(recibeMov, recibeMovId) != 501)
                        {
                            MessageBox.Show("Este evento es exclusivo para venta cruzada", "Advertencia!!",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            cbx_Clave.Text = "";
                            return;
                        }

                    if (recibeMensaje == 6)
                        if (!fechaCorrectaSeguimiento)
                        {
                            string domingo = "";
                            string sabado = "";

                            domingo = dtp_Fecha.Value.DayOfWeek == DayOfWeek.Sunday ? "Domingo" : "";
                            sabado = dtp_Fecha.Value.DayOfWeek == DayOfWeek.Saturday ? "Sabado" : "";

                            MessageBox.Show("Dia Seleccionado: " + sabado + domingo + "\n Seleccione otra fecha");
                            return;
                        }

                    if (ValidaInsertEvento())
                    {
                        validaCierreForma = true;
                        DM0312_DetalleVenta.EventoInsertado = true;
                        MessageBox.Show("Registro almacenado con exito", "Mensaje!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

                        //-Dineralia
                        CDetalleVenta cDetalleVenta = new CDetalleVenta();
                        DM0312_DetalleVenta detalleVenta = new DM0312_DetalleVenta();
                        if (recibeMov == "Analisis Credito" && iCanalVenta == 77 && recibeEstatus == "PENDIENTE")
                        {
                            recibeSituacion = cDetalleVenta.obtenerSituacion(int.Parse(recibeIdVenta));
                            string sCorreo = cDetalleVenta.validarCorreo(int.Parse(recibeIdVenta), recibeSituacion);
                            if (!string.IsNullOrEmpty(sCorreo))
                            {
                                //aqui mando el aceptado
                                string sHtml =
                                    detalleVenta.hmtlDineralia(sCorreo, recibeCliente, int.Parse(recibeIdVenta));
                                string sCorreoCliente = cDetalleVenta.obtenerNombreCliente(recibeCliente, 2);
                                List<string> lsCorreoCliente = new List<string>();
                                lsCorreoCliente.Add(sCorreoCliente);
                                if (sCorreo == "CreditoNoAprobado")
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                if (sCorreo == "CONDICIONADO" || sCorreo == "CreditoAprobadoAjuste")
                                {
                                    cDetalle.insertarDatosSms(recibeCliente, cbx_Clave.Text, int.Parse(recibeIdVenta),
                                        "PRETENCIONES", "");
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                    cDetalle.insertarSms(recibeCliente, int.Parse(recibeIdVenta), 37);
                                }

                                if (sCorreo == "CreditoAprobado")
                                    detalleVenta.enviarCorreos("Dineralia", sHtml, lsCorreoCliente, "", 1, 1, "");

                                cDetalleVenta.actualizarCorreoEnviado(int.Parse(recibeIdVenta));
                            }
                        }

                        string validaUsuario_ = ClaseEstatica.Usuario.Usser.Substring(0, 5);
                        if (RESUL != "NO" && recibeMov == "Analisis Credito" && recibeEstatus == "PENDIENTE" &&
                            validaUsuario_ == "CREDI")
                            if (controllerExplorador.ventaCruzadaSuc(recibeMov, recibeMovId) == 501)
                            {
                                int idOrigen = controllerExplorador.origenID(recibeMov, recibeMovId);
                                string agente = controllerExplorador.ValidaAgenteVCruzada(idOrigen);
                                if (RESUL == "NEGATIVO")
                                {
                                    int res = controllerExplorador.RespVentaCruzada(agente,
                                        Convert.ToInt32(recibeIdVenta));
                                }
                                else
                                {
                                    if (RESUL == "POSITIVO")
                                    {
                                        controllerExplorador.RespVentaCruzadaAsig(agente, recibeCliente);
                                        int res = controllerExplorador.RespVentaCruzada(agente,
                                            Convert.ToInt32(recibeIdVenta));
                                    }
                                }
                            }


                        validaUsuarioDima = false;
                        //this.Close();
                        DM0312_ExploradorVentas.EjecutaEvento = true;
                        Dispose();
                        validaCierreForma = true;
                        foreach (Form forma in Application.OpenForms)
                            if (forma.Name == "DM0312_EventosNotasCitas")
                            {
                                forma.Visible = true;
                                break;
                            }
                    } //Termina If (validaInsercion == true)
                }
                else
                {
                    if (cbx_Clave.Text == "" && cbx_Agente.Text == "")
                    {
                        MessageBox.Show("Debe ingresar una clave de evento y un agente", "Advertencia!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cbx_Clave.Select();
                        iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                        iconError.SetError(cbx_Agente, "Ingresar usuario que realiza el evento");
                    }
                    else
                    {
                        if (cbx_Clave.Text == "")
                        {
                            MessageBox.Show("Debe ingresar una clave de evento", "Advertencia!!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            cbx_Clave.Select();
                            iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                        }
                        else
                        {
                            if (cbx_Agente.Text == "")
                            {
                                MessageBox.Show("Debe ingresar un agente", "Advertencia!!", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                                cbx_Agente.Select();
                                iconError.SetError(cbx_Agente, "Ingresar usuario que realiza el evento");
                            }
                        }
                    }
                }
            }
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            iconError.SetError(cbx_Clave, string.Empty);
            iconError.SetError(cbx_Agente, string.Empty);
            GuardarEvent();

            cbx_Clave.Text = "";
            txt_Descripcion.Text = "";

            if ((claveEvento == "MEN00135" || claveEvento == "MEN01111" || claveEvento == "MEN00011") &&
                recibeMov == "Analisis Credito" && (iCanalVenta == 7 || iCanalVenta == 3) &&
                recibeEstatus == "PENDIENTE")
                if ((recibeSucursal == "504" || recibeSucursal == "505") && recibeIdecommerce != "0" &&
                    recibeIdecommerce != "")
                {
                    string ArgumentosPlugin = "VTASPEDIDO " + recibeIdecommerce + " " + "PRETENCIONES";
                    cDetalle.EjecutarPlugins(ArgumentosPlugin, "actualizaEcommerce.exe",
                        ClaseEstatica.plugInPath + "ActualizaEcommerce\\");
                }
        }


        private void cbx_Hora_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != (char)Keys.Back) e.KeyChar = (char)Keys.None;
        }


        private void txt_Fecha_TextChanged(object sender, EventArgs e)
        {
            if (!bandera)
                if (Regex.IsMatch(txt_Fecha.Text, "[^0-9-/-]"))
                {
                    //MessageBox.Show("Solo Numeros, formato DD/MM/YYYY.", "Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_Fecha.Text = txt_Fecha.Text.Remove(txt_Fecha.Text.Length - txt_Fecha.Text.Length);
                    bandera = true;
                    //DateTime day = controllerExplorador.FechaActualServidor();
                    txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                }
            //if (recibeMensaje == 3)
            //{
            //    DateTime fechaAC = controllerExplorador.FechaActualServidor();
            //    if (dtp_Fecha.Value.Date >= fechaAC)
            //    {
            //        txt_Fecha.Text = dtp_Fecha.Text;
            //    }
            //    else
            //        System.Windows.Forms.MessageBox.Show("No se permite agregar una fecha menor a la actual", "Advertencia!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            //}


            bandera = false;
        }

        private void dtp_Fecha_ValueChanged(object sender, EventArgs e)
        {
            txt_Fecha.Text = dtp_Fecha.Text;
            if (recibeMensaje == 6)
            {
                if (dtp_Fecha.Value.DayOfWeek == DayOfWeek.Sunday || dtp_Fecha.Value.DayOfWeek == DayOfWeek.Saturday)
                    fechaCorrectaSeguimiento = false;
                else
                    fechaCorrectaSeguimiento = true;
            }
        }


        private void cbx_Agente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta agente = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Agente"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = agente.Comentario;
            if (!fill_cbx_Agente())
            {
                recibeTexto = "";
                AyudaAgente ayudaAgente = new AyudaAgente();
                ayudaAgente.recibeIdVenta = recibeIdVenta;
                ayudaAgente.recibeSucursal = recibeSucursal;
                ayudaAgente.recibeUsuario = recibeUsuario;
                ayudaAgente.recibeSituacion = recibeSituacion;
                ayudaAgente.recibeMensaje = recibeMensaje;
                ayudaAgente.recibeEstatus = recibeEstatus;
                ayudaAgente.validaCierreForma = true;
                ayudaAgente.recibeHora = cbx_Hora.Text;
                ayudaAgente.recibeFecha = txt_Fecha.Text;
                ayudaAgente.recibeTexto = txt_AsuntObserva.Text;
                recibeTexto = ayudaAgente.recibeTexto;
                foreach (Form forma in Application.OpenForms)
                    if (forma.Name == "DM0312_EventosNotasCitas")
                    {
                        forma.Visible = false;
                        break;
                    }

                txt_AsuntObserva.Text = recibeTexto;
                ayudaAgente.ShowDialog();
                cbx_Hora.Text = recibeHora;
                SendKeys.Send("{ENTER}");
                foreach (ModelAgregaEvento model in list)
                {
                    if (model.clave != null && model.descripcion != null)
                    {
                        cbx_Clave.Text = model.clave;
                        txt_Descripcion.Text = model.descripcion;
                        txt_AsuntObserva.Text = recibeTexto;
                        cbx_Hora.Text = recibeHora;
                        txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                        //DateTime day = controllerExplorador.FechaActualServidor();
                        //txt_Fecha.Text = day.ToShortDateString();
                    }

                    if (model.claveAgente != null && model.nombreAgente != null)
                    {
                        cbx_Agente.Text = model.claveAgente;
                        txt_AgenteDescripcion.Text = model.nombreAgente;
                        txt_AsuntObserva.Text = recibeTexto;
                        cbx_Hora.Text = recibeHora;
                        txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                        //DateTime day = controllerExplorador.FechaActualServidor();
                        //txt_Fecha.Text = day.ToShortDateString();
                    }
                }
            }
        }

        private void txt_Descripcion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta descripcion = ListaAgregaEventoComentario
                .Where(x => x.Campo.Equals("Descripcion Clave")).FirstOrDefault();
            txt_ComentarioAyuda.Text = descripcion.Comentario;
        }

        private void cbx_Hora_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta hora = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Hora"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = hora.Comentario;
        }

        private void txt_AsuntObserva_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta asunto = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Asunto"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = asunto.Comentario;
        }

        private void txt_Fecha_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta fecha = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Fecha"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = fecha.Comentario;
        }

        private void txt_AgenteDescripcion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta descripcionAgente = ListaAgregaEventoComentario
                .Where(x => x.Campo.Equals("Descripcion Agente")).FirstOrDefault();
            txt_ComentarioAyuda.Text = descripcionAgente.Comentario;
        }

        private bool ValidaFlujo()
        {
            bool valClave = false;
            List<MSituaciones> listClave = claveSeguimiento.ValidaClaveUsser();
            MSituaciones clave = listClave.Where(x => x.Flujo == "Final" && x.Situacion == recibeSituacion)
                .FirstOrDefault();
            if (clave == null)
            {
                valClave = true;
            }
            else
            {
                if (recibeSituacion == "Aceptado" || recibeSituacion == "Cancelado")
                {
                    valClave = false;
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_AgregarEvento")
                        {
                            forma.Show();
                            break;
                        }

                    MessageBox.Show("Ya cuenta con una Situacion Final", "Advertencia!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else
                {
                    valClave = true;
                }
            }

            return valClave;
        }

        private void cbx_Clave_KeyPress(object sender, KeyPressEventArgs e)
        {
            iconError.SetError(cbx_Clave, string.Empty);
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                string sit = controllerExplorador.CambioDeSituacion(recibeIdVenta);
                if ((cbx_Clave.Text != "" && claveEvento != cbx_Clave.Text) ||
                    (cbx_Clave.Text != "" && recibeSituacion == sit))
                    //    string validaClave = string.Empty;
                    //    validaClave = cbx_Clave.Text;
                    //    listModel = cAgregarEvento.LlenaComboClaveEvento();
                    //    var ValidaClave = listModel.Where(x => x.Clave == validaClave).Select(x => x.Clave).FirstOrDefault();
                    //    var ValidaDescripcion = listModel.Where(x => x.Clave == validaClave).Select(x => x.Descripcion).FirstOrDefault();
                    //    if (ValidaClave == "" || ValidaClave == null && cbx_Clave.Text != "")
                    //    {
                    //        MessageBox.Show("Error al seleccionar la clave, !! Clave no Valida", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //        iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                    //        cbx_Clave.Text = "";
                    //        txt_Descripcion.Text = "";
                    //    }
                    //    else
                    //    {
                    //        cbx_Clave.Text = ValidaClave;
                    //        txt_Descripcion.Text = ValidaDescripcion;
                    txt_AsuntObserva.Focus();
                //        if (cbx_Clave.Text != "")
                //        {
                //            string validaUsuario_ = ClaseEstatica.Usuario.Usser.Substring(0, 5);
                //            if (recibeMov == "Analisis Credito" && recibeEstatus == "PENDIENTE" && validaUsuario_ == "CREDI")
                //            {
                //                DM0312_DetalleSituaciones situaciones = new DM0312_DetalleSituaciones(DM0312_ExploradorVentas.ListaExplorador);
                //                situaciones.recibeMov = recibeMov;
                //                DM0312_DetalleSituaciones.IDVenta = Convert.ToInt32(recibeIdVenta);
                //                DM0312_DetalleSituaciones.Estatus = recibeEstatus;
                //                DM0312_DetalleSituaciones.Mov = recibeMov;
                //                situaciones.validaSituacion = true;
                //                situaciones.recibeSituacion = cAgregarEvento.Situacion(ValidaClave);
                //                if (ValidaFlujo())
                //                {
                //                    foreach (Form forma in Application.OpenForms)
                //                    {
                //                        if (forma.Name == "DM0312_AgregarEvento")
                //                        {
                //                            forma.Show();
                //                            break;
                //                        }
                //                    }
                //                    situaciones.ShowDialog();
                //                    recibeSituacion = cAgregarEvento.Situacion(ValidaClave);
                //                }
                //                else
                //                {
                //                    foreach (Form forma in Application.OpenForms)
                //                    {
                //                        if (forma.Name == "DM0312_AgregarEvento")
                //                        {
                //                            forma.Show();
                //                            break;
                //                        }
                //                    }
                //                    return;
                //                }
                //            }
                //        }
                //        toolTip1.SetToolTip(txt_Descripcion, txt_Descripcion.Text);
                //        claveEvento = cbx_Clave.Text;
                //    }
            }
        }

        private void AgregarEvento_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (CancelarVenta)
            //    return;

            //if (validaUsuarioDima && e.CloseReason == CloseReason.UserClosing)
            //{
            //    e.Cancel = true;
            //    MessageBox.Show("Debes de llenar todos los campos");
            //}
            //else

            //    if (validaCierreForma == false && txt_AsuntObserva.Text == "" && PuntoDeVenta.exit == false)
            //    {
            //        DialogResult dialogResult = System.Windows.Forms.MessageBox.Show("Se perderan los avances ¿Desea continuar?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //        if (dialogResult == DialogResult.Yes)
            //        {
            //      //      PuntoDeVenta.exit = true;
            //            list.Clear();
            //            DM0312_ExploradorVentas.EjecutaEvento = true;
            //            this.Dispose();
            //            foreach (Form forma in Application.OpenForms)
            //            {
            //                if (forma.Name == "DM0312_EventosNotasCitas")
            //                {
            //                    forma.Visible = true;
            //                    break;
            //                }
            //            }
            //        }
            //        else if (dialogResult == DialogResult.No)
            //        {

            //            e.Cancel = false;
            //            foreach (Form forma in Application.OpenForms)
            //            {
            //                if (forma.Name == "Agregar Evento")
            //                {
            //                    forma.Visible = true;
            //                    break;
            //                }
            //            }
            //        }
            //    }
        }

        private void cbx_Agente_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void AgregarEvento_FormClosed(object sender, FormClosedEventArgs e)
        {
            //if (!validaUsuarioDima)
            //{
            //    this.Dispose();
            //}
        }

        private void cbx_Clave_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_Descripcion.Text = "";
            cbx_Clave.Text = "";
            if (cbx_Clave.Text != "")
            {
                string validaClave = string.Empty;
                validaClave = cbx_Clave.Text;
                List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
                listModel = cAgregarEvento.LlenaComboClaveEvento();
                string ValidaClave = listModel.Where(x => x.Clave == validaClave).Select(x => x.Clave).FirstOrDefault();
                string ValidaDescripcion = listModel.Where(x => x.Clave == validaClave).Select(x => x.Descripcion)
                    .FirstOrDefault();
                if (ValidaClave == "" || ValidaClave == null)
                {
                    MessageBox.Show("Error al seleccionar la clave, !! Clave no Valida", "Error!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cbx_Clave.Text = "";
                    txt_Descripcion.Text = "";
                }
                else
                {
                    cbx_Clave.Text = ValidaClave;
                    txt_Descripcion.Text = ValidaDescripcion;
                    txt_AsuntObserva.Focus();
                }
            }
        }

        private void cbx_Clave_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta claveComentario =
                ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Clave")).FirstOrDefault();
            txt_ComentarioAyuda.Text = claveComentario.Comentario;
        }

        private void cbx_Clave_DropDown(object sender, EventArgs e)
        {
            txt_Descripcion.Text = "";
            cbx_Clave.Text = "";
            recibeTexto = "";
            DM0312_MComentariosVenta clave = ListaAgregaEventoComentario.Where(x => x.Campo.Equals("Clave"))
                .FirstOrDefault();
            txt_ComentarioAyuda.Text = clave.Comentario;

            ClaveSeguimiento claveSeguimiento = new ClaveSeguimiento();
            claveSeguimiento.recibeIdVenta = recibeIdVenta;
            claveSeguimiento.recibeSucursal = recibeSucursal;
            claveSeguimiento.recibeUsuario = recibeUsuario;
            claveSeguimiento.recibeSituacion = recibeSituacion;
            claveSeguimiento.recibeMensaje = recibeMensaje;
            claveSeguimiento.recibeEstatus = recibeEstatus;
            claveSeguimiento.ValidaCanalVenta = ValidaCanalVenta;
            claveSeguimiento.validaCierreForma = true;
            ClaveSeguimiento.recibeMov = recibeMov;
            claveSeguimiento.recibeMovID = recibeMovId;
            claveSeguimiento.recibeHora = cbx_Hora.Text;
            claveSeguimiento.recibeFecha = txt_Fecha.Text;
            claveSeguimiento.recibeTexto = txt_AsuntObserva.Text;


            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_EventosNotasCitas")
                {
                    forma.Visible = false;
                    break;
                }

            txt_AsuntObserva.Text = recibeTexto;

            claveSeguimiento.ShowDialog();
            cbx_Hora.Text = recibeHora;
            //claveEvento = Clave;
            //SendKeys.Send("{ENTER}");


            //txt_AsuntObserva.Focus();
            //txt_AsuntObserva.Select();
            foreach (ModelAgregaEvento model in list)
            {
                if (model.clave != null && model.descripcion != null)
                {
                    cbx_Clave.Text = model.clave;
                    claveEvento = model.clave;
                    txt_Descripcion.Text = model.descripcion;
                    txt_AsuntObserva.Text = recibeTexto;
                    cbx_Hora.Text = recibeHora;
                    //txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                    //DateTime day = controllerExplorador.FechaActualServidor();
                    //txt_Fecha.Text = day.ToShortDateString();
                }

                if (model.claveAgente != null && model.nombreAgente != null)
                {
                    cbx_Agente.Text = model.claveAgente;
                    txt_AgenteDescripcion.Text = model.nombreAgente;
                    claveEvento = model.clave;
                    txt_AsuntObserva.Text = recibeTexto;
                    cbx_Hora.Text = recibeHora;
                    txt_Fecha.Text = controllerExplorador.FechaActualServidor().ToString();
                    //DateTime day = controllerExplorador.FechaActualServidor();
                    //txt_Fecha.Text = day.ToShortDateString();
                }
            }

            toolTip1.SetToolTip(txt_Descripcion, txt_Descripcion.Text);
            cbx_Clave.Select();

            SendKeys.Send("{ENTER}");
        }

        private void cbx_Clave_Validating(object sender, CancelEventArgs e)
        {
            string sit = controllerExplorador.CambioDeSituacion(recibeIdventa);
            if ((cbx_Clave.Text != "" && claveEvento != cbx_Clave.Text) ||
                (cbx_Clave.Text != "" && recibeSituacion != sit))
            {
                string validaClave = string.Empty;
                validaClave = cbx_Clave.Text;

                listModel = cAgregarEvento.LlenaComboClaveEvento();
                string ValidaClave = listModel.Where(x => x.Clave == validaClave).Select(x => x.Clave).FirstOrDefault();
                string ValidaDescripcion = listModel.Where(x => x.Clave == validaClave).Select(x => x.Descripcion)
                    .FirstOrDefault();
                if (ValidaClave == "" || (ValidaClave == null && cbx_Clave.Text != ""))
                {
                    MessageBox.Show("Error al seleccionar la clave, !! Clave no Valida", "Error!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    iconError.SetError(cbx_Clave, "Ingresar clave del evento");
                    cbx_Clave.Text = "";
                    txt_Descripcion.Text = "";
                }
                else
                {
                    cbx_Clave.Text = ValidaClave;
                    txt_Descripcion.Text = ValidaDescripcion;
                    txt_AsuntObserva.Focus();
                    if (cbx_Clave.Text != "")
                    {
                        string validaUsuario_ = ClaseEstatica.Usuario.Usser.Substring(0, 5);
                        if (recibeMov == "Analisis Credito" && recibeEstatus == "PENDIENTE" &&
                            validaUsuario_ == "CREDI")
                        {
                            //-Venta Cruzada
                            //DM0312_DetalleSituaciones situaciones = new DM0312_DetalleSituaciones(DM0312_ExploradorVentas.ListaExplorador);

                            List<DM0312_MExploradorVenta> DetalleVentasSeleccionadas;
                            if (DM0312_DetalleVenta.VentasSelecEventos != null &&
                                DM0312_DetalleVenta.VentasSelecEventos.Count != 0)
                                DetalleVentasSeleccionadas = DM0312_DetalleVenta.VentasSelecEventos;
                            else
                                DetalleVentasSeleccionadas = DM0312_ExploradorVentas.ListaExplorador;
                            if (recibeCliente.Substring(0, 1) == "P" && (cbx_Clave.Text.Contains("MEN06207") ||
                                                                         cbx_Clave.Text.Contains("MEN06208") ||
                                                                         cbx_Clave.Text.Contains("MEN06209") ||
                                                                         cbx_Clave.Text.Contains("MEN06210")))
                            {
                                MessageBox.Show(
                                    "Este evento no se puede agregar a un prospecto, favor de asignar una cuenta al cliente",
                                    "Punto De Venta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }


                            Dm0312DetalleSituaciones situaciones =
                                new Dm0312DetalleSituaciones(DetalleVentasSeleccionadas);
                            situaciones.RecibeMov = recibeMov;
                            Dm0312DetalleSituaciones.IdVenta = Convert.ToInt32(recibeIdVenta);
                            Dm0312DetalleSituaciones.Estatus = recibeEstatus;
                            Dm0312DetalleSituaciones.Mov = recibeMov;
                            situaciones.ContSit = 1;
                            situaciones.ValidaSituacion = true;
                            situaciones.RecibeSituacion = cAgregarEvento.Situacion(ValidaClave);

                            if (ValidaFlujo())
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_AgregarEvento")
                                    {
                                        forma.Show();
                                        break;
                                    }

                                situaciones.ShowDialog();
                                recibeSituacion = cAgregarEvento.Situacion(ValidaClave);
                            }
                            else
                            {
                                foreach (Form forma in Application.OpenForms)
                                    if (forma.Name == "DM0312_AgregarEvento")
                                    {
                                        forma.Show();
                                        break;
                                    }

                                return;
                            }
                        }
                    }

                    toolTip1.SetToolTip(txt_Descripcion, txt_Descripcion.Text);
                    claveEvento = cbx_Clave.Text;
                }
            }
        }

        private void btn_CancelarVenta_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(
                "Se perderan los avances ¿Esta seguro de Salir?", "Confirmar", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                PuntoDeVenta.exit = true;
                Dispose();
                CancelarVenta = true;
            }
        }

        #endregion
    }
}