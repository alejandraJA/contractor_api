﻿namespace PuntoVenta.View
{
    partial class DM0312_CapRelacionado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_CapRelacionado));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.gb_buscar = new System.Windows.Forms.GroupBox();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.BtnDatosRel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbClienteRel = new System.Windows.Forms.ComboBox();
            this.gb_relacionar = new System.Windows.Forms.GroupBox();
            this.BtnRegresar_ClRel = new System.Windows.Forms.Button();
            this.BtnGuardar_ClRel = new System.Windows.Forms.Button();
            this.cmb_Aval = new System.Windows.Forms.ComboBox();
            this.cmb_Parentesco = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCuenta = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.flowLayoutPanel1.SuspendLayout();
            this.gb_buscar.SuspendLayout();
            this.gb_relacionar.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.gb_buscar);
            this.flowLayoutPanel1.Controls.Add(this.gb_relacionar);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(516, 411);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // gb_buscar
            // 
            this.gb_buscar.Controls.Add(this.txt_ComentarioAyuda);
            this.gb_buscar.Controls.Add(this.BtnDatosRel);
            this.gb_buscar.Controls.Add(this.label1);
            this.gb_buscar.Controls.Add(this.cmbClienteRel);
            this.gb_buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_buscar.Location = new System.Drawing.Point(3, 3);
            this.gb_buscar.Name = "gb_buscar";
            this.gb_buscar.Size = new System.Drawing.Size(503, 104);
            this.gb_buscar.TabIndex = 0;
            this.gb_buscar.TabStop = false;
            this.gb_buscar.Text = "Buscar Relacionado";
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BackColor = System.Drawing.Color.White;
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(129, 9);
            this.txt_ComentarioAyuda.Multiline = true;
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.ReadOnly = true;
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(368, 37);
            this.txt_ComentarioAyuda.TabIndex = 52;
            // 
            // BtnDatosRel
            // 
            this.BtnDatosRel.FlatAppearance.BorderSize = 0;
            this.BtnDatosRel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDatosRel.Image = ((System.Drawing.Image)(resources.GetObject("BtnDatosRel.Image")));
            this.BtnDatosRel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDatosRel.Location = new System.Drawing.Point(324, 64);
            this.BtnDatosRel.Name = "BtnDatosRel";
            this.BtnDatosRel.Size = new System.Drawing.Size(173, 34);
            this.BtnDatosRel.TabIndex = 2;
            this.BtnDatosRel.Text = "Ver Datos Relacionado";
            this.BtnDatosRel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnDatosRel.UseVisualStyleBackColor = true;
            this.BtnDatosRel.Click += new System.EventHandler(this.BtnDatosRel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cliente:";
            // 
            // cmbClienteRel
            // 
            this.cmbClienteRel.FormattingEnabled = true;
            this.cmbClienteRel.Location = new System.Drawing.Point(29, 52);
            this.cmbClienteRel.MaxLength = 10;
            this.cmbClienteRel.Name = "cmbClienteRel";
            this.cmbClienteRel.Size = new System.Drawing.Size(169, 23);
            this.cmbClienteRel.TabIndex = 0;
            this.cmbClienteRel.DropDown += new System.EventHandler(this.cmbClienteRel_DropDown);
            this.cmbClienteRel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbClienteRel_KeyPress);
            // 
            // gb_relacionar
            // 
            this.gb_relacionar.Controls.Add(this.BtnRegresar_ClRel);
            this.gb_relacionar.Controls.Add(this.BtnGuardar_ClRel);
            this.gb_relacionar.Controls.Add(this.cmb_Aval);
            this.gb_relacionar.Controls.Add(this.cmb_Parentesco);
            this.gb_relacionar.Controls.Add(this.label6);
            this.gb_relacionar.Controls.Add(this.label5);
            this.gb_relacionar.Controls.Add(this.TxtDireccion);
            this.gb_relacionar.Controls.Add(this.label4);
            this.gb_relacionar.Controls.Add(this.txtNombre);
            this.gb_relacionar.Controls.Add(this.label3);
            this.gb_relacionar.Controls.Add(this.txtCuenta);
            this.gb_relacionar.Controls.Add(this.label2);
            this.gb_relacionar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_relacionar.Location = new System.Drawing.Point(3, 113);
            this.gb_relacionar.Name = "gb_relacionar";
            this.gb_relacionar.Size = new System.Drawing.Size(503, 288);
            this.gb_relacionar.TabIndex = 1;
            this.gb_relacionar.TabStop = false;
            this.gb_relacionar.Text = "Cliente Relacionado";
            this.gb_relacionar.Visible = false;
            // 
            // BtnRegresar_ClRel
            // 
            this.BtnRegresar_ClRel.FlatAppearance.BorderSize = 0;
            this.BtnRegresar_ClRel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRegresar_ClRel.Image = ((System.Drawing.Image)(resources.GetObject("BtnRegresar_ClRel.Image")));
            this.BtnRegresar_ClRel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnRegresar_ClRel.Location = new System.Drawing.Point(295, 207);
            this.BtnRegresar_ClRel.Name = "BtnRegresar_ClRel";
            this.BtnRegresar_ClRel.Size = new System.Drawing.Size(83, 75);
            this.BtnRegresar_ClRel.TabIndex = 15;
            this.BtnRegresar_ClRel.Text = "Regresar (Crtl+Esc)";
            this.BtnRegresar_ClRel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnRegresar_ClRel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnRegresar_ClRel.UseVisualStyleBackColor = true;
            this.BtnRegresar_ClRel.Click += new System.EventHandler(this.BtnRegresar_ClRel_Click);
            // 
            // BtnGuardar_ClRel
            // 
            this.BtnGuardar_ClRel.FlatAppearance.BorderSize = 0;
            this.BtnGuardar_ClRel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnGuardar_ClRel.Image = ((System.Drawing.Image)(resources.GetObject("BtnGuardar_ClRel.Image")));
            this.BtnGuardar_ClRel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnGuardar_ClRel.Location = new System.Drawing.Point(384, 207);
            this.BtnGuardar_ClRel.Name = "BtnGuardar_ClRel";
            this.BtnGuardar_ClRel.Size = new System.Drawing.Size(98, 75);
            this.BtnGuardar_ClRel.TabIndex = 14;
            this.BtnGuardar_ClRel.Text = "Guardar (Crtl+G)";
            this.BtnGuardar_ClRel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnGuardar_ClRel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnGuardar_ClRel.UseVisualStyleBackColor = true;
            this.BtnGuardar_ClRel.Click += new System.EventHandler(this.BtnGuardar_ClRel_Click);
            // 
            // cmb_Aval
            // 
            this.cmb_Aval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Aval.FormattingEnabled = true;
            this.cmb_Aval.Location = new System.Drawing.Point(157, 176);
            this.cmb_Aval.Name = "cmb_Aval";
            this.cmb_Aval.Size = new System.Drawing.Size(195, 23);
            this.cmb_Aval.TabIndex = 13;
            // 
            // cmb_Parentesco
            // 
            this.cmb_Parentesco.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Parentesco.FormattingEnabled = true;
            this.cmb_Parentesco.Location = new System.Drawing.Point(141, 135);
            this.cmb_Parentesco.Name = "cmb_Parentesco";
            this.cmb_Parentesco.Size = new System.Drawing.Size(211, 23);
            this.cmb_Parentesco.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Quiere Fungir como Aval:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Parentesco:";
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Location = new System.Drawing.Point(141, 99);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(350, 22);
            this.TxtDireccion.TabIndex = 7;
            this.TxtDireccion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtDireccion_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Direccion:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(141, 61);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(350, 22);
            this.txtNombre.TabIndex = 5;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nombre:";
            // 
            // txtCuenta
            // 
            this.txtCuenta.Location = new System.Drawing.Point(141, 24);
            this.txtCuenta.Name = "txtCuenta";
            this.txtCuenta.Size = new System.Drawing.Size(142, 22);
            this.txtCuenta.TabIndex = 3;
            this.txtCuenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCuenta_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cuenta:";
            // 
            // DM0312_CapRelacionado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(516, 411);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DM0312_CapRelacionado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Captura Relacionado";
            this.Load += new System.EventHandler(this.DM0312_CapRelacionado_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_CapRelacionado_KeyDown);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.gb_buscar.ResumeLayout(false);
            this.gb_buscar.PerformLayout();
            this.gb_relacionar.ResumeLayout(false);
            this.gb_relacionar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox gb_buscar;
        private System.Windows.Forms.GroupBox gb_relacionar;
        private System.Windows.Forms.ComboBox cmbClienteRel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnDatosRel;
        private System.Windows.Forms.ComboBox cmb_Aval;
        private System.Windows.Forms.ComboBox cmb_Parentesco;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TxtDireccion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCuenta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnGuardar_ClRel;
        private System.Windows.Forms.Button BtnRegresar_ClRel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
    }
}