﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View.Evento;

namespace PuntoVenta.View
{
    public partial class HistorialSolicitudCancelacion : Form
    {
        public HistorialSolicitudCancelacion(List<SolicitudCancelaciones> SolicitudCancelaciones)
        {
            InitializeComponent();
            listaSolicitudCancelaciones = SolicitudCancelaciones;
        }

        private void HistorialSolicitudCancelacion_Load(object sender, EventArgs e)
        {
            fillTablaMovimientos();
        }

        #region classAttributes

        private readonly VentaController ventaController = new VentaController();
        private List<SolicitudCancelaciones> listaSolicitudCancelaciones;
        private readonly SolicitudCancelacionesController SCCOntroller = new SolicitudCancelacionesController();

        #endregion

        #region Triggers

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            cerrarVentana();
        }

        private void btn_RechazarSolicitud_Click(object sender, EventArgs e)
        {
            showRechazarSolicitudEvento();
            reloadGrid();
        }

        private void btn_CancelarTodo_Click(object sender, EventArgs e)
        {
            cancelarTodosMovimientos();
            reloadGrid();
        }

        private void btn_CancelarMovimiento_Click(object sender, EventArgs e)
        {
            CancelarMovimiento();
            reloadGrid();
        }

        private void HistorialSolicitudCancelacion_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) btn_Regresar_Click(btn_Regresar, null);

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R) btn_RechazarSolicitud_Click(null, null);

            if (e.KeyCode == Keys.F2) btn_CancelarMovimiento_Click(null, null);

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.F2) btn_CancelarTodo_Click(null, null);

            if (e.KeyCode == Keys.F5) reloadGrid();
        }

        #endregion


        #region Metodos

        private void fillTablaMovimientos()
        {
            try
            {
                if (listaSolicitudCancelaciones.Count > 0)
                {
                    dgv_ListaMovimientos.DataSource = listaSolicitudCancelaciones;
                    dgv_ListaMovimientosHideColumns();
                }
                else
                {
                    MessageBox.Show("No hay registros por atender.");
                    cerrarVentana();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        private void dgv_ListaMovimientosHideColumns()
        {
            try
            {
                if (dgv_ListaMovimientos.Columns["Id"] != null)
                    dgv_ListaMovimientos.Columns["Id"].Visible = false;
                if (dgv_ListaMovimientos.Columns["Mov"] != null)
                    dgv_ListaMovimientos.Columns["Mov"].Visible = false;
                if (dgv_ListaMovimientos.Columns["MovID"] != null)
                    dgv_ListaMovimientos.Columns["MovID"].Visible = false;
                if (dgv_ListaMovimientos.Columns["EnviarA"] != null)
                    dgv_ListaMovimientos.Columns["EnviarA"].Visible = false;
                if (dgv_ListaMovimientos.Columns["Rid"] != null)
                    dgv_ListaMovimientos.Columns["Rid"].Visible = false;
                if (dgv_ListaMovimientos.Columns["Clave"] != null)
                    dgv_ListaMovimientos.Columns["Clave"].Visible = false;
                if (dgv_ListaMovimientos.Columns["Visible"] != null)
                    dgv_ListaMovimientos.Columns["Visible"].Visible = false;
            }
            catch (Exception exception)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, exception);
                sbp_EstatusPrograma.Text = @"Error: " + exception.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + exception.Message, exception);
            }
        }

        private void cerrarVentana()
        {
            Close();
            Dispose();
        }

        private void showRechazarSolicitudEvento()
        {
            try
            {
                if (dgv_ListaMovimientos.SelectedCells.Count > 0)
                {
                    int selectedrowindex = dgv_ListaMovimientos.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = dgv_ListaMovimientos.Rows[selectedrowindex];

                    DM0312_MExploradorVenta VentaM =
                        ventaController.getVenta(Convert.ToInt32(selectedRow.Cells["id"].Value));

                    using (RechazoSolicitudCancelacion RSC = new RechazoSolicitudCancelacion(VentaM))
                    {
                        RSC.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            finally
            {
                sbp_EstatusPrograma.Text = "Estatus: " + MethodBase.GetCurrentMethod().Name + " OK";
            }
        }

        private void CancelarMovimiento()
        {
            try
            {
                if (dgv_ListaMovimientos.SelectedCells.Count > 0)
                {
                    int selectedrowindex = dgv_ListaMovimientos.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = dgv_ListaMovimientos.Rows[selectedrowindex];
                    DM0312_MExploradorVenta VentaM = new DM0312_MExploradorVenta();

                    VentaM.ID = (int)selectedRow.Cells["ID"].Value;
                    VentaM.Mov = selectedRow.Cells["Mov"].Value.ToString();
                    VentaM.MovId = selectedRow.Cells["MovID"].Value.ToString();
                    VentaM.EnviarA = selectedRow.Cells["EnviarA"].Value.ToString();

                    string tipomsgRef = string.Empty;
                    if (ventaController.CancelarMovimiento(ref tipomsgRef, VentaM) == "Afectación incorrecta")
                        MessageBox.Show(VentaM.Mov + " " + VentaM.MovId + "\nLa cancelación no pudo ser completada.");
                    else
                        MessageBox.Show("Movimiento cancelado exitosamente");
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            finally
            {
                sbp_EstatusPrograma.Text = "Estatus: " + MethodBase.GetCurrentMethod().Name + " OK";
            }
        }

        private void cancelarTodosMovimientos()
        {
            try
            {
                if (dgv_ListaMovimientos.RowCount > 0)
                {
                    List<DM0312_MExploradorVenta> listVentaM = getListaVenta();

                    string msg = "";
                    foreach (DM0312_MExploradorVenta ventaM in listVentaM)
                        if (ventaM.ID > 0)
                        {
                            string tipomsgRef = string.Empty;

                            if ("Afectación incorrecta" == ventaController.CancelarMovimiento(ref tipomsgRef, ventaM))
                                msg += ventaM.Mov + " " + ventaM.MovId + "error: " + tipomsgRef + ".\n";
                        }

                    if (msg.Length > 1)
                        MessageBox.Show(msg + "\nAlgunas cancelaciónes No se completaron");
                    else
                        MessageBox.Show("La cancelación fue correcta para todos los movimientos");
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
            finally
            {
                sbp_EstatusPrograma.Text = "Estatus: " + MethodBase.GetCurrentMethod().Name + " OK";
            }
        }

        private List<DM0312_MExploradorVenta> getListaVenta()
        {
            List<DM0312_MExploradorVenta> listaVentas = new List<DM0312_MExploradorVenta>();
            foreach (DataGridViewRow row in dgv_ListaMovimientos.Rows)
            {
                DM0312_MExploradorVenta venta = new DM0312_MExploradorVenta();

                if (row.Visible)
                {
                    venta.ID = (int)row.Cells["ID"].Value;
                    venta.Mov = row.Cells["Mov"].Value.ToString();
                    venta.MovId = row.Cells["MovID"].Value.ToString();
                    venta.EnviarA = row.Cells["EnviarA"].Value.ToString();

                    listaVentas.Add(venta);
                }
            }

            return listaVentas;
        }

        private void reloadGrid()
        {
            try
            {
                listaSolicitudCancelaciones = SCCOntroller.getSolicitudesCancelacion();
                fillTablaMovimientos();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, ex);
                sbp_EstatusPrograma.Text = @"Error: " + ex.Message;
                throw new Exception(
                    "CLASE: " + MethodBase.GetCurrentMethod().DeclaringType?.Name + "\nMETODO: " +
                    MethodBase.GetCurrentMethod().Name + "\nMessage:" + ex.Message, ex);
            }
        }

        #endregion
    }
}