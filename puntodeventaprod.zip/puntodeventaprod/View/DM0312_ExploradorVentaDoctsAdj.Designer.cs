﻿namespace PuntoVenta.View
{
    partial class DM0312_ExploradorVentaDoctsAdj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.ListViewImage = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(32, 32);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // ListViewImage
            // 
            this.ListViewImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListViewImage.Location = new System.Drawing.Point(0, 0);
            this.ListViewImage.Name = "ListViewImage";
            this.ListViewImage.Size = new System.Drawing.Size(356, 432);
            this.ListViewImage.TabIndex = 4;
            this.ListViewImage.UseCompatibleStateImageBehavior = false;
            this.ListViewImage.ItemActivate += new System.EventHandler(this.ListViewImage_ItemActivate);
            this.ListViewImage.Click += new System.EventHandler(this.ListViewImage_Click);
            // 
            // DM0312_ExploradorVentaDoctsAdj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 432);
            this.Controls.Add(this.ListViewImage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.KeyPreview = true;
            this.Name = "DM0312_ExploradorVentaDoctsAdj";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Documentos Adjuntos";
            this.Load += new System.EventHandler(this.DM0312_ExploradorVentaDoctsAdj_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_ExploradorVentaDoctsAdj_KeyDown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.ListView ListViewImage;

    }
}