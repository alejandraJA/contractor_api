﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class ClaveSeguimiento : Form
    {
        public static string recibeMov;
        private readonly CtrlClaveSeguimiento claveSeguimiento = new CtrlClaveSeguimiento();
        public List<DM0312_MComentariosVenta> ComentariosF;
        private DateTime day = DateTime.Now;
        public string enviaClave;
        public string enviaDescripcion;
        private readonly Funciones funciones = new Funciones();
        private List<DM0312_MClaveSeguimiento> listClaveSeg;
        private List<DM0312_MClaveSeguimiento> listModel = new List<DM0312_MClaveSeguimiento>();
        private List<DM0312_MClaveSeguimiento> listModeloTemp = new List<DM0312_MClaveSeguimiento>();
        private readonly ModelAgregaEvento model = new ModelAgregaEvento();
        private List<DM0312_MClaveSeguimiento> model_ = new List<DM0312_MClaveSeguimiento>();
        public DM0312_MClaveSeguimiento ModelSeleccionadoClave;
        public string recibeEstatus;
        public string recibeFecha;
        public string recibeHora;
        public string recibeIdVenta;
        public int recibeMensaje;
        public string recibeMovID;
        public string recibeSituacion;
        public string recibeSucursal;
        public string recibeTexto;
        public string recibeUsuario;
        public string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);
        private bool validaAcceso;
        public int ValidaCanalVenta;
        public bool validaCierreForma;
        public bool validaEnvioDato;
        public bool validaIndex;

        public ClaveSeguimiento()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            ModelSeleccionadoClave = new DM0312_MClaveSeguimiento();
            listClaveSeg = new List<DM0312_MClaveSeguimiento>();
        }

        ~ClaveSeguimiento()
        {
            GC.Collect();
        }

        private void ClaveSeguimiento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (!validaEnvioDato) DM0312_AgregarEvento.list.Clear();

                try
                {
                    Dispose();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        #region "Methods"

        public void llenaDataGridClaveSeguimiento()
        {
            if (ValidaCanalVenta == 76)
            {
                txt_Buscar.Visible = false;
                lbl_Buscar.Visible = false;
                listModel = claveSeguimiento.LlenaComboClaveEvento();
                model_ = listModel.Where(x =>
                        x.Clave == "VTA00110" || x.Clave == "VTA00120" || x.Clave == "VTA00130" ||
                        x.Clave == "VTA00140")
                    .ToList();
                dgv_ClaveSeguimiento.DataSource = model_;
            }
            else
            {
                listModel = claveSeguimiento.LlenaComboClaveEvento();
                dgv_ClaveSeguimiento.DataSource = listModel;
            }

            validaAcceso = true;
            dgv_ClaveSeguimiento_SelectionChanged(null, null);
        }

        private void llenaTexto()
        {
            listModeloTemp = claveSeguimiento.LlenaTextoClaveSeguimiento(txt_Buscar.Text).ToList();
            validaAcceso = false;
            dgv_ClaveSeguimiento.DataSource = listModeloTemp;
        }

        /// <summary>
        ///     Valida situacion final, con la situacion  principal DataGrid Movimientos
        /// </summary>
        /// <returns></returns>
        private bool ValidaFlujo()
        {
            bool valClave = false;
            List<MSituaciones> listClave = claveSeguimiento.ValidaClaveUsser();
            MSituaciones clave = listClave.Where(x => x.Flujo == "Final" && x.Situacion == recibeSituacion)
                .FirstOrDefault();
            if (clave == null)
            {
                valClave = true;
            }
            else
            {
                if (recibeSituacion == "Aceptado" || recibeSituacion == "Cancelado")
                {
                    valClave = false;
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_AgregarEvento")
                        {
                            forma.Show();
                            break;
                        }

                    MessageBox.Show("Ya cuenta con una Situacion Final", "Advertencia!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else
                {
                    valClave = true;
                }
            }

            return valClave;
        }

        #endregion

        #region "Handles"

        private void ClaveSeguimiento_Load(object sender, EventArgs e)
        {
            llenaDataGridClaveSeguimiento();
            ListaComentarios();

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_ClaveSeguimiento.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_ClaveSeguimiento.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_ClaveSeguimiento.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_ClaveSeguimiento.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void ListaComentarios()
        {
            ComentariosF = Funciones.ConsultaComentario("AsistentaClaveSeguimiento");
            DM0312_MComentariosVenta lblBuscar =
                ComentariosF.Where(x => x.Campo.Equals("EtiquetaBuscarClave")).FirstOrDefault();
            DM0312_MComentariosVenta txtBuscar =
                ComentariosF.Where(x => x.Campo.Equals("TxtBuscarClave")).FirstOrDefault();
            DM0312_MComentariosVenta RegresarB = ComentariosF.Where(x => x.Campo.Equals("Regresar")).FirstOrDefault();
            DM0312_MComentariosVenta AyudaB = ComentariosF.Where(x => x.Campo.Equals("Ayuda")).FirstOrDefault();

            if (lblBuscar != null) toolTip1.SetToolTip(lbl_Buscar, lblBuscar.Comentario);
            if (txtBuscar != null) toolTip1.SetToolTip(txt_Buscar, txtBuscar.Comentario);
            if (RegresarB != null) toolTip1.SetToolTip(btn_Regresar, RegresarB.Comentario);
            if (AyudaB != null) toolTip1.SetToolTip(btn_ayuda, AyudaB.Comentario);

            if (usuarioVenta == "CREDI")
                txt_Comentarios.Text =
                    "SELECCIONAR UNA CLAVE PARA PODER AGREGAR UN EVENTO, LA CLAVE SELECCIONADA AGREGARA LA SITUACION QUE LA UNE, REVISAR QUE SI SEA UNA SITUACION VALIDA";
            else
                txt_Comentarios.Text = "SELECCIONAR UNA CLAVE PARA PODER AGREGAR UN EVENTO";
        }

        private void dgv_ClaveSeguimiento_DoubleClick(object sender, EventArgs e)
        {
            validaIndex = false;
            validaEnvioDato = true;
            validaAcceso = true;
            dgv_ClaveSeguimiento_SelectionChanged(dgv_ClaveSeguimiento, new DataGridViewCellEventArgs(0, 0));
            enviaClave = ModelSeleccionadoClave.Clave;
            enviaDescripcion = ModelSeleccionadoClave.Descripcion;
            model.Clave = enviaClave;
            model.Descripcion = enviaDescripcion;
            model.Comentario = recibeTexto;
            DM0312_AgregarEvento.list.Add(model);
            //-Venta Cruzada (OLD)
            //foreach (Form forma in Application.OpenForms)
            //{
            //    if (forma.Name == "ClaveSeguimiento")
            //    {
            //        forma.Close();
            //        break;
            //    }
            //}
            Close();
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_AgregarEvento")
                {
                    DM0312_AgregarEvento evento = (DM0312_AgregarEvento)forma;
                    evento.AgregarEvento_Load(null, null);
                    evento.recibeIdVenta = recibeIdVenta;
                    evento.recibeUsuario = recibeUsuario;
                    evento.recibeSucursal = recibeSucursal;
                    evento.recibeSituacion = recibeSituacion;
                    evento.recibeMensaje = recibeMensaje;
                    evento.recibeEstatus = recibeEstatus;
                    evento.txt_Fecha.Text = day.ToShortDateString();
                    evento.txt_AsuntObserva.Text = recibeTexto;
                    evento.Text = recibeTexto;
                    evento.recibeHora = recibeHora;
                    evento.recibeFecha = recibeFecha;
                    evento.ValidaCanalVenta = ValidaCanalVenta;
                    evento.Show();
                    break;
                }

            string validaUsuario_ = ClaseEstatica.Usuario.Usser.Substring(0, 5);
            if (recibeMov == "Analisis Credito" && recibeEstatus == "PENDIENTE" && validaUsuario_ == "CREDI")
            {
                //-Venta Cruzada
                List<DM0312_MExploradorVenta> DetalleVentasSeleccionadas;
                if (DM0312_DetalleVenta.VentasSelecEventos != null && DM0312_DetalleVenta.VentasSelecEventos.Count != 0)
                    DetalleVentasSeleccionadas = DM0312_DetalleVenta.VentasSelecEventos;
                else
                    DetalleVentasSeleccionadas = DM0312_ExploradorVentas.ListaExplorador;

                Dm0312DetalleSituaciones situaciones = new Dm0312DetalleSituaciones(DetalleVentasSeleccionadas);
                //DM0312_DetalleSituaciones situaciones = new DM0312_DetalleSituaciones(DM0312_ExploradorVentas.ListaExplorador);
                situaciones.PaginadoActual = DM0312_DetalleVenta.paginaSeleccionada;
                situaciones.RecibeMov = recibeMov;
                situaciones.ContSit = 1;
                Dm0312DetalleSituaciones.IdVenta = Convert.ToInt32(recibeIdVenta);
                Dm0312DetalleSituaciones.Estatus = recibeEstatus;
                Dm0312DetalleSituaciones.Mov = recibeMov;
                situaciones.ValidaSituacion = true;
                situaciones.RecibeSituacion = ModelSeleccionadoClave.Situacion;
                if (ValidaFlujo())
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_AgregarEvento")
                        {
                            forma.Show();
                            break;
                        }

                    situaciones.ShowDialog();
                }
                else
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "DM0312_AgregarEvento")
                        {
                            forma.Show();
                            break;
                        }
                }
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            if (!validaEnvioDato) DM0312_AgregarEvento.list.Clear();

            try
            {
                Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClaveSeguimiento_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgv_ClaveSeguimiento_SelectionChanged(object sender, EventArgs e)
        {
            if (validaIndex)
                return;

            if (validaAcceso)
            {
                listClaveSeg = new List<DM0312_MClaveSeguimiento>();
                if (dgv_ClaveSeguimiento.Rows.Count > 0)
                {
                    DM0312_MClaveSeguimiento model_ = new DM0312_MClaveSeguimiento();
                    model_ = (DM0312_MClaveSeguimiento)dgv_ClaveSeguimiento.SelectedRows[0].DataBoundItem;
                    listClaveSeg.Add(model_);
                    ModelSeleccionadoClave = listClaveSeg.FirstOrDefault();
                }
            }
        }

        private void ClaveSeguimiento_FormClosed(object sender, FormClosedEventArgs e)
        {
            Dispose();
        }

        private void dgv_ClaveSeguimiento_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }

            DataGridViewCell cell = dgv_ClaveSeguimiento.Rows[e.RowIndex].Cells[e.ColumnIndex];
            cell.ToolTipText = "DAR DOBLE CLICK PARA SELECCIONAR UNA CLAVE Y CONTINUAR CON LA CAPTURA DEL EVENTO";
        }

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper().ToCharArray(0, 1)[0];
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txt_Buscar.Text != "")
                    llenaTexto();
                else
                    llenaDataGridClaveSeguimiento();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dgv_ClaveSeguimiento_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (ValidaCanalVenta == 76)
            {
                List<object> TempObjects = new List<object>(model_);
                validaIndex = true;
                funciones.OrderGridview(dgv_ClaveSeguimiento, e.ColumnIndex, TempObjects,
                    model_.GetType().GetGenericArguments().Single());
                return;
            }

            if (listModel.Count > 0)
            {
                List<object> TempObjects = new List<object>(listModel);
                validaIndex = true;
                funciones.OrderGridview(dgv_ClaveSeguimiento, e.ColumnIndex, TempObjects,
                    listModel.GetType().GetGenericArguments().Single());
            }
            else
            {
                validaIndex = true;
                List<object> TempObjects = new List<object>(listModeloTemp);
                funciones.OrderGridview(dgv_ClaveSeguimiento, e.ColumnIndex, TempObjects,
                    listModeloTemp.GetType().GetGenericArguments().Single());
            }
        }

        private void ClaveSeguimiento_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                dgv_ClaveSeguimiento.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            else
                dgv_ClaveSeguimiento.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        #endregion
    }
}