﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta
{
    public partial class DM0312_ConsultarEvento : Form
    {
        private readonly CrtlConsultaEvento controlConsultarEvento = new CrtlConsultaEvento();
        private readonly Funciones funciones = new Funciones();
        public List<DM0312_MConsultarEvento> listMain = new List<DM0312_MConsultarEvento>();
        public int opcionForma;
        public string recibeCliente;
        public string recibeCuentaUsuario;
        public string recibeEstatus;
        public string recibeIdVenta;
        public string recibeMov;
        public string recibeMovId;
        public string recibeSituacion;
        public string recibeSucursal;
        public string recibeUsuario;
        public string usuarioVenta = ClaseEstatica.Usuario.Acceso.Substring(0, 5);

        public DM0312_ConsultarEvento()
        {
            InitializeComponent();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);
        }

        ~DM0312_ConsultarEvento()
        {
            GC.Collect();
        }

        private void DM0312_ConsultarEvento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        #region "Methods"

        private void LlenaDataGridNotas()
        {
            if (listMain.Count > 0)
            {
                dgv_ConsultaEvento.DataSource = listMain;
                dgv_ConsultaEvento.Columns["Clave"].Visible = false;
            }
            else
            {
                MessageBox.Show("El cliente " + recibeCliente + " no cuenta con Notas", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Dispose();
            }
        }

        private void LlenaDataGridConsultaCita()
        {
            if (listMain.Count > 0)
            {
                dgv_ConsultaEvento.DataSource = listMain;
                dgv_ConsultaEvento.Columns["Fecha"].HeaderText = "Fecha Registro";
                dgv_ConsultaEvento.Columns["Evento"].HeaderText = "Cita";
                dgv_ConsultaEvento.Columns["Clave"].Visible = false;
            }
            else
            {
                MessageBox.Show("No cuenta con movimientos a consultar", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Dispose();
            }
        }

        private void LlenaDataGridEventos()
        {
            if (listMain.Count > 0)
            {
                dgv_ConsultaEvento.DataSource = listMain;
                if (usuarioVenta == "CREDI")
                    dgv_ConsultaEvento.Columns["Usuario"].Visible = true;
                else
                    dgv_ConsultaEvento.Columns["Usuario"].Visible = false;
            }
            else
            {
                MessageBox.Show("No cuenta con movimientos a consultar", "", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Dispose();
            }
        }


        public void CargarLista()
        {
            if (opcionForma == (int)Enums.EventoNotacita.Evento)
                listMain = controlConsultarEvento.LlenaConsultarEventos(recibeIdVenta, recibeMov);
            else if (opcionForma == (int)Enums.EventoNotacita.Nota)
                listMain = controlConsultarEvento.LlenaNotas(recibeCliente);
            else if (opcionForma == (int)Enums.EventoNotacita.Cita)
                listMain = controlConsultarEvento.LlenaConsultarCita(recibeIdVenta, ClaseEstatica.Usuario.Usser);
        }

        #endregion

        #region "Handles"

        private void DM0312_ConsultarEvento_Load(object sender, EventArgs e)
        {
            lbl_Cliente.Text = recibeCliente;
            lbl_Mov.Text = recibeMov;
            lbl_MovId.Text = recibeMovId;
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR");
            toolTip1.SetToolTip(btn_Ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE COMO UTILIZAR LA FORMA");

            switch (opcionForma)
            {
                case (int)Enums.EventoNotacita.Evento:
                    LlenaDataGridEventos();
                    Text = "Consultar Eventos";
                    txt_Comentarios.Text = "FORMA DE CONSULTA DE LOS EVENTOS DEL CLIENTE: " + lbl_Cliente.Text +
                                           " LIGADOS AL MOVIMIENTO: " + recibeMov + " " + recibeMovId;
                    break;
                case (int)Enums.EventoNotacita.Nota:
                    LlenaDataGridNotas();
                    Text = "Consultar Nota";
                    txt_Comentarios.Text = "FORMA DE CONSULTA DE LAS NOTAS DEL CLIENTE: " + lbl_Cliente.Text;
                    break;
                case (int)Enums.EventoNotacita.Cita:
                    LlenaDataGridConsultaCita();
                    Text = "Consultar Cita";
                    txt_Comentarios.Text = "FORMA DE CONSULTA DE LOS CITAS DE SUPERVICION DEL CLIENTE: " +
                                           lbl_Cliente.Text + "LIGADAS AL MOVIMIENTO: " + recibeMov + " " + recibeMovId;
                    break;
                default:
                    Console.WriteLine("Error al seleccionar el menu");
                    break;
            }

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_ConsultaEvento.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_ConsultaEvento.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_ConsultaEvento.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_ConsultaEvento.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void ConsultarEvento_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void dgv_ConsultaEvento_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null)
            {
                e.Value = e.Value.ToString().ToUpper();
                e.FormattingApplied = true;
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }


        private void dgv_ConsultaEvento_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            List<object> TempObjects = new List<object>(listMain);
            funciones.OrderGridview(dgv_ConsultaEvento, e.ColumnIndex, TempObjects,
                listMain.GetType().GetGenericArguments().Single());
            switch (opcionForma)
            {
                case (int)Enums.EventoNotacita.Evento:
                    break;
                case (int)Enums.EventoNotacita.Nota:
                    if (listMain.Count > 0)
                        dgv_ConsultaEvento.Columns["Fecha"].HeaderText = "Fecha Registro";
                    dgv_ConsultaEvento.Columns["Evento"].HeaderText = "Cita";
                    dgv_ConsultaEvento.Columns["Clave"].Visible = false;
                    break;
                case (int)Enums.EventoNotacita.Cita:
                    if (listMain.Count > 0)
                        dgv_ConsultaEvento.Columns["Clave"].Visible = false;
                    break;
                default:
                    MessageBox.Show("No cuenta con registros a ordenar", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    break;
            }
        }

        #endregion
    }
}