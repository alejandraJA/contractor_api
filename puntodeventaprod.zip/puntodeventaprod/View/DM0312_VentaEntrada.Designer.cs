﻿namespace PuntoVenta
{
    partial class DM0312_VentaEntrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_VentaEntrada));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbx_explorador = new System.Windows.Forms.GroupBox();
            this.btnReimprimir = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_CodigoPostal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Cuenta = new System.Windows.Forms.Label();
            this.txt_cuenta = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.dgv_VentanaEntrada = new System.Windows.Forms.DataGridView();
            this.gbx_AdjMov = new System.Windows.Forms.GroupBox();
            this.btn_IrVenta = new System.Windows.Forms.Button();
            this.txt_Mov = new System.Windows.Forms.ComboBox();
            this.txt_MovId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.txt_TituloEntrada = new System.Windows.Forms.TextBox();
            this.panelMovimientos = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Venta = new System.Windows.Forms.Button();
            this.btn_Devolucion = new System.Windows.Forms.Button();
            this.btn_Adjudicacion = new System.Windows.Forms.Button();
            this.btnPagoServicio = new System.Windows.Forms.Button();
            this.panel_TipoVenta = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Contado = new System.Windows.Forms.Button();
            this.btn_Dima = new System.Windows.Forms.Button();
            this.btnDimaForaneo = new System.Windows.Forms.Button();
            this.btn_Credito = new System.Windows.Forms.Button();
            this.btn_CEmp = new System.Windows.Forms.Button();
            this.btn_Instituciones = new System.Windows.Forms.Button();
            this.btn_Mayoreo = new System.Windows.Forms.Button();
            this.btn_SolValera = new System.Windows.Forms.Button();
            this.btnValDigital = new System.Windows.Forms.Button();
            this.btnRecarga = new System.Windows.Forms.Button();
            this.btnPromocionesVencidas = new System.Windows.Forms.Button();
            this.panel_Buscador = new System.Windows.Forms.FlowLayoutPanel();
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbx_PublicoG = new System.Windows.Forms.CheckBox();
            this.gbx_Valera = new System.Windows.Forms.GroupBox();
            this.txt_Valera = new System.Windows.Forms.ComboBox();
            this.lbl_Valera = new System.Windows.Forms.Label();
            this.gbPromociones = new System.Windows.Forms.GroupBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.cbTipoCapturaPromocion = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Ir = new System.Windows.Forms.Button();
            this.btnTelNip = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.gbx_explorador.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VentanaEntrada)).BeginInit();
            this.gbx_AdjMov.SuspendLayout();
            this.panelMovimientos.SuspendLayout();
            this.panel_TipoVenta.SuspendLayout();
            this.panel_Buscador.SuspendLayout();
            this.panelContactos.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbx_Valera.SuspendLayout();
            this.gbPromociones.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_explorador
            // 
            this.gbx_explorador.BackColor = System.Drawing.Color.White;
            this.gbx_explorador.Controls.Add(this.btnReimprimir);
            this.gbx_explorador.Controls.Add(this.label6);
            this.gbx_explorador.Controls.Add(this.txt_CodigoPostal);
            this.gbx_explorador.Controls.Add(this.label3);
            this.gbx_explorador.Controls.Add(this.lbl_Cuenta);
            this.gbx_explorador.Controls.Add(this.txt_cuenta);
            this.gbx_explorador.Controls.Add(this.btnBuscar);
            this.gbx_explorador.Controls.Add(this.txtTelefono);
            this.gbx_explorador.Controls.Add(this.lbl_Buscar);
            this.gbx_explorador.Controls.Add(this.lblTelefono);
            this.gbx_explorador.Controls.Add(this.txtNombre);
            this.gbx_explorador.Controls.Add(this.txtDireccion);
            this.gbx_explorador.Controls.Add(this.lblDireccion);
            this.gbx_explorador.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_explorador.Location = new System.Drawing.Point(3, 391);
            this.gbx_explorador.Name = "gbx_explorador";
            this.gbx_explorador.Size = new System.Drawing.Size(763, 101);
            this.gbx_explorador.TabIndex = 3;
            this.gbx_explorador.TabStop = false;
            this.gbx_explorador.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_explorador_Paint);
            // 
            // btnReimprimir
            // 
            this.btnReimprimir.FlatAppearance.BorderSize = 0;
            this.btnReimprimir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReimprimir.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnReimprimir.Image = ((System.Drawing.Image)(resources.GetObject("btnReimprimir.Image")));
            this.btnReimprimir.Location = new System.Drawing.Point(630, 53);
            this.btnReimprimir.Name = "btnReimprimir";
            this.btnReimprimir.Size = new System.Drawing.Size(40, 40);
            this.btnReimprimir.TabIndex = 86;
            this.btnReimprimir.UseVisualStyleBackColor = true;
            this.btnReimprimir.Click += new System.EventHandler(this.btnReimprimir_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(113, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(248, 15);
            this.label6.TabIndex = 23;
            this.label6.Text = "(Apellido Paterno  Apellido Materno  Nombre)";
            // 
            // txt_CodigoPostal
            // 
            this.txt_CodigoPostal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodigoPostal.Location = new System.Drawing.Point(113, 75);
            this.txt_CodigoPostal.MaxLength = 5;
            this.txt_CodigoPostal.Name = "txt_CodigoPostal";
            this.txt_CodigoPostal.Size = new System.Drawing.Size(111, 22);
            this.txt_CodigoPostal.TabIndex = 19;
            this.txt_CodigoPostal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CodigoPostal_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 17;
            this.label3.Text = "Codigo Postal";
            // 
            // lbl_Cuenta
            // 
            this.lbl_Cuenta.AutoSize = true;
            this.lbl_Cuenta.Location = new System.Drawing.Point(0, 8);
            this.lbl_Cuenta.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.lbl_Cuenta.Name = "lbl_Cuenta";
            this.lbl_Cuenta.Size = new System.Drawing.Size(89, 15);
            this.lbl_Cuenta.TabIndex = 16;
            this.lbl_Cuenta.Text = "Buscar Cuenta";
            // 
            // txt_cuenta
            // 
            this.txt_cuenta.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_cuenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cuenta.Location = new System.Drawing.Point(0, 26);
            this.txt_cuenta.MaxLength = 9;
            this.txt_cuenta.Name = "txt_cuenta";
            this.txt_cuenta.Size = new System.Drawing.Size(107, 22);
            this.txt_cuenta.TabIndex = 11;
            this.txt_cuenta.TextChanged += new System.EventHandler(this.txt_cuenta_TextChanged);
            this.txt_cuenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_cuenta_KeyPress);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.FlatAppearance.BorderSize = 0;
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscar.Image")));
            this.btnBuscar.Location = new System.Drawing.Point(699, 8);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(64, 63);
            this.btnBuscar.TabIndex = 15;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txtTelefono
            // 
            this.txtTelefono.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefono.Location = new System.Drawing.Point(603, 25);
            this.txtTelefono.MaxLength = 10;
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(90, 22);
            this.txtTelefono.TabIndex = 14;
            this.txtTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefono_KeyPress);
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Location = new System.Drawing.Point(113, 8);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(93, 15);
            this.lbl_Buscar.TabIndex = 7;
            this.lbl_Buscar.Text = "Buscar Nombre";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(600, 8);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(96, 15);
            this.lblTelefono.TabIndex = 14;
            this.lblTelefono.Text = "Buscar Teléfono";
            // 
            // txtNombre
            // 
            this.txtNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(113, 25);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(253, 22);
            this.txtNombre.TabIndex = 12;
            this.txtNombre.Click += new System.EventHandler(this.txtNombre_Click);
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // txtDireccion
            // 
            this.txtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDireccion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccion.Location = new System.Drawing.Point(373, 25);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(224, 22);
            this.txtDireccion.TabIndex = 13;
            this.txtDireccion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDireccion_KeyPress);
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Location = new System.Drawing.Point(370, 7);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(104, 15);
            this.lblDireccion.TabIndex = 13;
            this.lblDireccion.Text = "Buscar Dirección";
            // 
            // dgv_VentanaEntrada
            // 
            this.dgv_VentanaEntrada.AllowUserToAddRows = false;
            this.dgv_VentanaEntrada.AllowUserToDeleteRows = false;
            this.dgv_VentanaEntrada.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_VentanaEntrada.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_VentanaEntrada.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_VentanaEntrada.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_VentanaEntrada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_VentanaEntrada.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_VentanaEntrada.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_VentanaEntrada.EnableHeadersVisualStyles = false;
            this.dgv_VentanaEntrada.Location = new System.Drawing.Point(3, 3);
            this.dgv_VentanaEntrada.Name = "dgv_VentanaEntrada";
            this.dgv_VentanaEntrada.ReadOnly = true;
            this.dgv_VentanaEntrada.RowHeadersVisible = false;
            this.dgv_VentanaEntrada.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_VentanaEntrada.Size = new System.Drawing.Size(749, 182);
            this.dgv_VentanaEntrada.TabIndex = 16;
            this.dgv_VentanaEntrada.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_VentanaEntrada_CellClick);
            this.dgv_VentanaEntrada.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_VentanaEntrada_CellDoubleClick);
            this.dgv_VentanaEntrada.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_VentanaEntrada_CellFormatting);
            this.dgv_VentanaEntrada.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_VentanaEntrada_ColumnHeaderMouseClick);
            this.dgv_VentanaEntrada.DoubleClick += new System.EventHandler(this.dgv_VentanaEntrada_DoubleClick);
            // 
            // gbx_AdjMov
            // 
            this.gbx_AdjMov.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.gbx_AdjMov.Controls.Add(this.btn_IrVenta);
            this.gbx_AdjMov.Controls.Add(this.txt_Mov);
            this.gbx_AdjMov.Controls.Add(this.txt_MovId);
            this.gbx_AdjMov.Controls.Add(this.label2);
            this.gbx_AdjMov.Controls.Add(this.label1);
            this.gbx_AdjMov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_AdjMov.Location = new System.Drawing.Point(300, 109);
            this.gbx_AdjMov.Name = "gbx_AdjMov";
            this.gbx_AdjMov.Padding = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.gbx_AdjMov.Size = new System.Drawing.Size(485, 72);
            this.gbx_AdjMov.TabIndex = 32;
            this.gbx_AdjMov.TabStop = false;
            this.gbx_AdjMov.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_AdjMov_Paint);
            // 
            // btn_IrVenta
            // 
            this.btn_IrVenta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_IrVenta.FlatAppearance.BorderSize = 0;
            this.btn_IrVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_IrVenta.Image = ((System.Drawing.Image)(resources.GetObject("btn_IrVenta.Image")));
            this.btn_IrVenta.Location = new System.Drawing.Point(388, 12);
            this.btn_IrVenta.Name = "btn_IrVenta";
            this.btn_IrVenta.Size = new System.Drawing.Size(91, 49);
            this.btn_IrVenta.TabIndex = 5;
            this.btn_IrVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_IrVenta.UseVisualStyleBackColor = true;
            this.btn_IrVenta.Click += new System.EventHandler(this.btn_IrVenta_Click);
            // 
            // txt_Mov
            // 
            this.txt_Mov.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_Mov.FormattingEnabled = true;
            this.txt_Mov.Location = new System.Drawing.Point(93, 24);
            this.txt_Mov.Name = "txt_Mov";
            this.txt_Mov.Size = new System.Drawing.Size(134, 23);
            this.txt_Mov.TabIndex = 3;
            // 
            // txt_MovId
            // 
            this.txt_MovId.Location = new System.Drawing.Point(275, 25);
            this.txt_MovId.MaxLength = 15;
            this.txt_MovId.Name = "txt_MovId";
            this.txt_MovId.Size = new System.Drawing.Size(100, 22);
            this.txt_MovId.TabIndex = 4;
            this.txt_MovId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_MovId_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(249, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Movimiento";
            // 
            // txt_TituloEntrada
            // 
            this.txt_TituloEntrada.BackColor = System.Drawing.Color.White;
            this.txt_TituloEntrada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TituloEntrada.Enabled = false;
            this.txt_TituloEntrada.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TituloEntrada.Location = new System.Drawing.Point(264, 27);
            this.txt_TituloEntrada.Multiline = true;
            this.txt_TituloEntrada.Name = "txt_TituloEntrada";
            this.txt_TituloEntrada.Size = new System.Drawing.Size(611, 43);
            this.txt_TituloEntrada.TabIndex = 77;
            // 
            // panelMovimientos
            // 
            this.panelMovimientos.AutoSize = true;
            this.panelMovimientos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelMovimientos.Controls.Add(this.btn_Venta);
            this.panelMovimientos.Controls.Add(this.btn_Devolucion);
            this.panelMovimientos.Controls.Add(this.btn_Adjudicacion);
            this.panelMovimientos.Controls.Add(this.btnPagoServicio);
            this.panelMovimientos.Location = new System.Drawing.Point(222, 11);
            this.panelMovimientos.Name = "panelMovimientos";
            this.panelMovimientos.Size = new System.Drawing.Size(414, 83);
            this.panelMovimientos.TabIndex = 78;
            // 
            // btn_Venta
            // 
            this.btn_Venta.BackColor = System.Drawing.Color.White;
            this.btn_Venta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Venta.FlatAppearance.BorderSize = 0;
            this.btn_Venta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Venta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Venta.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Venta.Image = ((System.Drawing.Image)(resources.GetObject("btn_Venta.Image")));
            this.btn_Venta.Location = new System.Drawing.Point(3, 3);
            this.btn_Venta.Name = "btn_Venta";
            this.btn_Venta.Size = new System.Drawing.Size(93, 77);
            this.btn_Venta.TabIndex = 0;
            this.btn_Venta.Text = "Venta";
            this.btn_Venta.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Venta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Venta.UseVisualStyleBackColor = false;
            this.btn_Venta.Click += new System.EventHandler(this.btn_Venta_Click);
            // 
            // btn_Devolucion
            // 
            this.btn_Devolucion.BackColor = System.Drawing.Color.White;
            this.btn_Devolucion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Devolucion.FlatAppearance.BorderSize = 0;
            this.btn_Devolucion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Devolucion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Devolucion.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Devolucion.Image = ((System.Drawing.Image)(resources.GetObject("btn_Devolucion.Image")));
            this.btn_Devolucion.Location = new System.Drawing.Point(102, 3);
            this.btn_Devolucion.Name = "btn_Devolucion";
            this.btn_Devolucion.Size = new System.Drawing.Size(99, 77);
            this.btn_Devolucion.TabIndex = 1;
            this.btn_Devolucion.Text = "Devolución";
            this.btn_Devolucion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Devolucion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Devolucion.UseVisualStyleBackColor = false;
            this.btn_Devolucion.Click += new System.EventHandler(this.btn_Devolucion_Click);
            // 
            // btn_Adjudicacion
            // 
            this.btn_Adjudicacion.BackColor = System.Drawing.Color.White;
            this.btn_Adjudicacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Adjudicacion.FlatAppearance.BorderSize = 0;
            this.btn_Adjudicacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Adjudicacion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Adjudicacion.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Adjudicacion.Image = ((System.Drawing.Image)(resources.GetObject("btn_Adjudicacion.Image")));
            this.btn_Adjudicacion.Location = new System.Drawing.Point(207, 3);
            this.btn_Adjudicacion.Name = "btn_Adjudicacion";
            this.btn_Adjudicacion.Size = new System.Drawing.Size(99, 77);
            this.btn_Adjudicacion.TabIndex = 2;
            this.btn_Adjudicacion.Text = "Adjudicacion";
            this.btn_Adjudicacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Adjudicacion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Adjudicacion.UseVisualStyleBackColor = false;
            this.btn_Adjudicacion.Click += new System.EventHandler(this.btn_Adjudicacion_Click);
            // 
            // btnPagoServicio
            // 
            this.btnPagoServicio.BackColor = System.Drawing.Color.White;
            this.btnPagoServicio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPagoServicio.FlatAppearance.BorderSize = 0;
            this.btnPagoServicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPagoServicio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPagoServicio.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnPagoServicio.Image = ((System.Drawing.Image)(resources.GetObject("btnPagoServicio.Image")));
            this.btnPagoServicio.Location = new System.Drawing.Point(312, 3);
            this.btnPagoServicio.Name = "btnPagoServicio";
            this.btnPagoServicio.Size = new System.Drawing.Size(99, 77);
            this.btnPagoServicio.TabIndex = 5;
            this.btnPagoServicio.Text = "Pago Servicios";
            this.btnPagoServicio.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPagoServicio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPagoServicio.UseVisualStyleBackColor = false;
            this.btnPagoServicio.Click += new System.EventHandler(this.btnPagoServicio_Click);
            // 
            // panel_TipoVenta
            // 
            this.panel_TipoVenta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel_TipoVenta.AutoSize = true;
            this.panel_TipoVenta.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_TipoVenta.Controls.Add(this.btn_Contado);
            this.panel_TipoVenta.Controls.Add(this.btn_Dima);
            this.panel_TipoVenta.Controls.Add(this.btnDimaForaneo);
            this.panel_TipoVenta.Controls.Add(this.btn_Credito);
            this.panel_TipoVenta.Controls.Add(this.btn_CEmp);
            this.panel_TipoVenta.Controls.Add(this.btn_Instituciones);
            this.panel_TipoVenta.Controls.Add(this.btn_Mayoreo);
            this.panel_TipoVenta.Controls.Add(this.btn_SolValera);
            this.panel_TipoVenta.Controls.Add(this.btnValDigital);
            this.panel_TipoVenta.Controls.Add(this.btnRecarga);
            this.panel_TipoVenta.Controls.Add(this.btnPromocionesVencidas);
            this.panel_TipoVenta.Location = new System.Drawing.Point(3, 187);
            this.panel_TipoVenta.Name = "panel_TipoVenta";
            this.panel_TipoVenta.Size = new System.Drawing.Size(1080, 107);
            this.panel_TipoVenta.TabIndex = 79;
            // 
            // btn_Contado
            // 
            this.btn_Contado.BackColor = System.Drawing.Color.White;
            this.btn_Contado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Contado.FlatAppearance.BorderSize = 0;
            this.btn_Contado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Contado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Contado.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Contado.Image = ((System.Drawing.Image)(resources.GetObject("btn_Contado.Image")));
            this.btn_Contado.Location = new System.Drawing.Point(3, 3);
            this.btn_Contado.Name = "btn_Contado";
            this.btn_Contado.Size = new System.Drawing.Size(86, 85);
            this.btn_Contado.TabIndex = 6;
            this.btn_Contado.Text = "Contado";
            this.btn_Contado.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Contado.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Contado.UseVisualStyleBackColor = false;
            this.btn_Contado.Click += new System.EventHandler(this.btn_Contado_Click);
            // 
            // btn_Dima
            // 
            this.btn_Dima.BackColor = System.Drawing.Color.White;
            this.btn_Dima.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Dima.FlatAppearance.BorderSize = 0;
            this.btn_Dima.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dima.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dima.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Dima.Image = ((System.Drawing.Image)(resources.GetObject("btn_Dima.Image")));
            this.btn_Dima.Location = new System.Drawing.Point(95, 3);
            this.btn_Dima.Name = "btn_Dima";
            this.btn_Dima.Size = new System.Drawing.Size(94, 85);
            this.btn_Dima.TabIndex = 7;
            this.btn_Dima.Text = "Dima";
            this.btn_Dima.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Dima.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Dima.UseVisualStyleBackColor = false;
            this.btn_Dima.Click += new System.EventHandler(this.btn_Dima_Click);
            // 
            // btnDimaForaneo
            // 
            this.btnDimaForaneo.BackColor = System.Drawing.Color.White;
            this.btnDimaForaneo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDimaForaneo.FlatAppearance.BorderSize = 0;
            this.btnDimaForaneo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDimaForaneo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDimaForaneo.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnDimaForaneo.Image = global::PuntoVenta.Properties.Resources.bloggif_59a1a7a26e5b9;
            this.btnDimaForaneo.Location = new System.Drawing.Point(195, 3);
            this.btnDimaForaneo.Name = "btnDimaForaneo";
            this.btnDimaForaneo.Size = new System.Drawing.Size(94, 85);
            this.btnDimaForaneo.TabIndex = 18;
            this.btnDimaForaneo.Text = "El Creditazzo";
            this.btnDimaForaneo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDimaForaneo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDimaForaneo.UseVisualStyleBackColor = false;
            this.btnDimaForaneo.Visible = false;
            this.btnDimaForaneo.Click += new System.EventHandler(this.btnDimaForaneo_Click);
            // 
            // btn_Credito
            // 
            this.btn_Credito.BackColor = System.Drawing.Color.White;
            this.btn_Credito.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Credito.FlatAppearance.BorderSize = 0;
            this.btn_Credito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Credito.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Credito.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Credito.Image = ((System.Drawing.Image)(resources.GetObject("btn_Credito.Image")));
            this.btn_Credito.Location = new System.Drawing.Point(295, 3);
            this.btn_Credito.Name = "btn_Credito";
            this.btn_Credito.Size = new System.Drawing.Size(87, 85);
            this.btn_Credito.TabIndex = 8;
            this.btn_Credito.Text = "Credito Menudeo";
            this.btn_Credito.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Credito.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Credito.UseVisualStyleBackColor = false;
            this.btn_Credito.Click += new System.EventHandler(this.btn_Credito_Click);
            // 
            // btn_CEmp
            // 
            this.btn_CEmp.BackColor = System.Drawing.Color.White;
            this.btn_CEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_CEmp.FlatAppearance.BorderSize = 0;
            this.btn_CEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CEmp.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CEmp.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_CEmp.Image = global::PuntoVenta.Properties.Resources.employee;
            this.btn_CEmp.Location = new System.Drawing.Point(388, 3);
            this.btn_CEmp.Name = "btn_CEmp";
            this.btn_CEmp.Size = new System.Drawing.Size(87, 85);
            this.btn_CEmp.TabIndex = 9;
            this.btn_CEmp.Text = "Credito Empresario";
            this.btn_CEmp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CEmp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CEmp.UseVisualStyleBackColor = false;
            this.btn_CEmp.Click += new System.EventHandler(this.Btn_CEmp_Click);
            // 
            // btn_Instituciones
            // 
            this.btn_Instituciones.BackColor = System.Drawing.Color.White;
            this.btn_Instituciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Instituciones.FlatAppearance.BorderSize = 0;
            this.btn_Instituciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Instituciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Instituciones.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Instituciones.Image = ((System.Drawing.Image)(resources.GetObject("btn_Instituciones.Image")));
            this.btn_Instituciones.Location = new System.Drawing.Point(481, 3);
            this.btn_Instituciones.Name = "btn_Instituciones";
            this.btn_Instituciones.Size = new System.Drawing.Size(88, 101);
            this.btn_Instituciones.TabIndex = 9;
            this.btn_Instituciones.Text = "Instituciones";
            this.btn_Instituciones.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Instituciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Instituciones.UseVisualStyleBackColor = false;
            this.btn_Instituciones.Click += new System.EventHandler(this.btn_Instituciones_Click);
            // 
            // btn_Mayoreo
            // 
            this.btn_Mayoreo.BackColor = System.Drawing.Color.White;
            this.btn_Mayoreo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Mayoreo.FlatAppearance.BorderSize = 0;
            this.btn_Mayoreo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Mayoreo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mayoreo.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Mayoreo.Image = ((System.Drawing.Image)(resources.GetObject("btn_Mayoreo.Image")));
            this.btn_Mayoreo.Location = new System.Drawing.Point(575, 3);
            this.btn_Mayoreo.Name = "btn_Mayoreo";
            this.btn_Mayoreo.Size = new System.Drawing.Size(88, 85);
            this.btn_Mayoreo.TabIndex = 10;
            this.btn_Mayoreo.Text = "Mayoreo";
            this.btn_Mayoreo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Mayoreo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Mayoreo.UseVisualStyleBackColor = false;
            this.btn_Mayoreo.Click += new System.EventHandler(this.btn_Mayoreo_Click);
            // 
            // btn_SolValera
            // 
            this.btn_SolValera.BackColor = System.Drawing.Color.White;
            this.btn_SolValera.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_SolValera.FlatAppearance.BorderSize = 0;
            this.btn_SolValera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SolValera.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SolValera.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_SolValera.Image = ((System.Drawing.Image)(resources.GetObject("btn_SolValera.Image")));
            this.btn_SolValera.Location = new System.Drawing.Point(669, 3);
            this.btn_SolValera.Name = "btn_SolValera";
            this.btn_SolValera.Size = new System.Drawing.Size(101, 85);
            this.btn_SolValera.TabIndex = 11;
            this.btn_SolValera.Text = "Solicitud Valera";
            this.btn_SolValera.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_SolValera.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_SolValera.UseVisualStyleBackColor = false;
            this.btn_SolValera.Click += new System.EventHandler(this.btn_SolValera_Click);
            // 
            // btnValDigital
            // 
            this.btnValDigital.BackColor = System.Drawing.Color.White;
            this.btnValDigital.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnValDigital.FlatAppearance.BorderSize = 0;
            this.btnValDigital.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValDigital.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValDigital.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnValDigital.Image = global::PuntoVenta.Properties.Resources.barcode;
            this.btnValDigital.Location = new System.Drawing.Point(776, 3);
            this.btnValDigital.Name = "btnValDigital";
            this.btnValDigital.Size = new System.Drawing.Size(101, 85);
            this.btnValDigital.TabIndex = 12;
            this.btnValDigital.Text = "Vale Digital";
            this.btnValDigital.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnValDigital.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnValDigital.UseVisualStyleBackColor = false;
            this.btnValDigital.Click += new System.EventHandler(this.btnValDigital_Click);
            // 
            // btnRecarga
            // 
            this.btnRecarga.BackColor = System.Drawing.Color.White;
            this.btnRecarga.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecarga.FlatAppearance.BorderSize = 0;
            this.btnRecarga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRecarga.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecarga.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnRecarga.Image = ((System.Drawing.Image)(resources.GetObject("btnRecarga.Image")));
            this.btnRecarga.Location = new System.Drawing.Point(883, 3);
            this.btnRecarga.Name = "btnRecarga";
            this.btnRecarga.Size = new System.Drawing.Size(101, 85);
            this.btnRecarga.TabIndex = 15;
            this.btnRecarga.Text = "Recargas";
            this.btnRecarga.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRecarga.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRecarga.UseVisualStyleBackColor = false;
            this.btnRecarga.Click += new System.EventHandler(this.btnRecarga_Click);
            // 
            // btnPromocionesVencidas
            // 
            this.btnPromocionesVencidas.BackColor = System.Drawing.Color.White;
            this.btnPromocionesVencidas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPromocionesVencidas.FlatAppearance.BorderSize = 0;
            this.btnPromocionesVencidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPromocionesVencidas.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPromocionesVencidas.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnPromocionesVencidas.Image = global::PuntoVenta.Properties.Resources._50offL2;
            this.btnPromocionesVencidas.Location = new System.Drawing.Point(990, 3);
            this.btnPromocionesVencidas.Name = "btnPromocionesVencidas";
            this.btnPromocionesVencidas.Size = new System.Drawing.Size(87, 85);
            this.btnPromocionesVencidas.TabIndex = 17;
            this.btnPromocionesVencidas.Text = "Promociones Vencidas";
            this.btnPromocionesVencidas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPromocionesVencidas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPromocionesVencidas.UseVisualStyleBackColor = false;
            this.btnPromocionesVencidas.Click += new System.EventHandler(this.btnPromocionesVencidas_Click);
            // 
            // panel_Buscador
            // 
            this.panel_Buscador.Controls.Add(this.dgv_VentanaEntrada);
            this.panel_Buscador.Location = new System.Drawing.Point(3, 498);
            this.panel_Buscador.Name = "panel_Buscador";
            this.panel_Buscador.Size = new System.Drawing.Size(760, 194);
            this.panel_Buscador.TabIndex = 80;
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.Controls.Add(this.groupBox1);
            this.panelContactos.Controls.Add(this.gbx_AdjMov);
            this.panelContactos.Controls.Add(this.panel_TipoVenta);
            this.panelContactos.Controls.Add(this.cbx_PublicoG);
            this.panelContactos.Controls.Add(this.gbx_Valera);
            this.panelContactos.Controls.Add(this.gbx_explorador);
            this.panelContactos.Controls.Add(this.panel_Buscador);
            this.panelContactos.Controls.Add(this.gbPromociones);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(107, 72);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(1086, 754);
            this.panelContactos.TabIndex = 81;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panelMovimientos);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(763, 100);
            this.groupBox1.TabIndex = 81;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // cbx_PublicoG
            // 
            this.cbx_PublicoG.AutoSize = true;
            this.cbx_PublicoG.BackColor = System.Drawing.Color.LightBlue;
            this.cbx_PublicoG.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbx_PublicoG.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_PublicoG.ForeColor = System.Drawing.Color.DarkBlue;
            this.cbx_PublicoG.Location = new System.Drawing.Point(3, 300);
            this.cbx_PublicoG.Name = "cbx_PublicoG";
            this.cbx_PublicoG.Size = new System.Drawing.Size(212, 26);
            this.cbx_PublicoG.TabIndex = 83;
            this.cbx_PublicoG.Text = "Venta Publico General";
            this.cbx_PublicoG.UseVisualStyleBackColor = false;
            this.cbx_PublicoG.CheckedChanged += new System.EventHandler(this.cbx_PublicoG_CheckedChanged);
            // 
            // gbx_Valera
            // 
            this.gbx_Valera.BackColor = System.Drawing.Color.White;
            this.gbx_Valera.Controls.Add(this.txt_Valera);
            this.gbx_Valera.Controls.Add(this.lbl_Valera);
            this.gbx_Valera.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_Valera.Location = new System.Drawing.Point(3, 332);
            this.gbx_Valera.Name = "gbx_Valera";
            this.gbx_Valera.Size = new System.Drawing.Size(739, 53);
            this.gbx_Valera.TabIndex = 82;
            this.gbx_Valera.TabStop = false;
            this.gbx_Valera.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_Valera_Paint);
            // 
            // txt_Valera
            // 
            this.txt_Valera.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_Valera.FormattingEnabled = true;
            this.txt_Valera.Location = new System.Drawing.Point(321, 21);
            this.txt_Valera.Name = "txt_Valera";
            this.txt_Valera.Size = new System.Drawing.Size(129, 23);
            this.txt_Valera.TabIndex = 14;
            this.txt_Valera.SelectedIndexChanged += new System.EventHandler(this.txt_Valera_SelectedIndexChanged);
            // 
            // lbl_Valera
            // 
            this.lbl_Valera.AutoSize = true;
            this.lbl_Valera.Location = new System.Drawing.Point(272, 24);
            this.lbl_Valera.Name = "lbl_Valera";
            this.lbl_Valera.Size = new System.Drawing.Size(43, 15);
            this.lbl_Valera.TabIndex = 13;
            this.lbl_Valera.Text = "Valera";
            // 
            // gbPromociones
            // 
            this.gbPromociones.BackColor = System.Drawing.Color.White;
            this.gbPromociones.Controls.Add(this.txtId);
            this.gbPromociones.Controls.Add(this.label5);
            this.gbPromociones.Controls.Add(this.btnProcesar);
            this.gbPromociones.Controls.Add(this.cbTipoCapturaPromocion);
            this.gbPromociones.Controls.Add(this.label4);
            this.gbPromociones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPromociones.Location = new System.Drawing.Point(3, 698);
            this.gbPromociones.Name = "gbPromociones";
            this.gbPromociones.Size = new System.Drawing.Size(739, 53);
            this.gbPromociones.TabIndex = 85;
            this.gbPromociones.TabStop = false;
            this.gbPromociones.Visible = false;
            // 
            // txtId
            // 
            this.txtId.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtId.Location = new System.Drawing.Point(402, 21);
            this.txtId.MaxLength = 10;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(111, 22);
            this.txtId.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(378, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "Id";
            // 
            // btnProcesar
            // 
            this.btnProcesar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProcesar.FlatAppearance.BorderSize = 0;
            this.btnProcesar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProcesar.Image = ((System.Drawing.Image)(resources.GetObject("btnProcesar.Image")));
            this.btnProcesar.Location = new System.Drawing.Point(545, 7);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(91, 49);
            this.btnProcesar.TabIndex = 15;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // cbTipoCapturaPromocion
            // 
            this.cbTipoCapturaPromocion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTipoCapturaPromocion.FormattingEnabled = true;
            this.cbTipoCapturaPromocion.Items.AddRange(new object[] {
            "Refacturación",
            "Disminución de pretenciones"});
            this.cbTipoCapturaPromocion.Location = new System.Drawing.Point(233, 21);
            this.cbTipoCapturaPromocion.Name = "cbTipoCapturaPromocion";
            this.cbTipoCapturaPromocion.Size = new System.Drawing.Size(129, 23);
            this.cbTipoCapturaPromocion.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(134, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Tipo de captura";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel2.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel2.Controls.Add(this.btn_Ir);
            this.flowLayoutPanel2.Controls.Add(this.btnTelNip);
            this.flowLayoutPanel2.Controls.Add(this.btn_ayuda);
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 72);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(101, 308);
            this.flowLayoutPanel2.TabIndex = 83;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(95, 60);
            this.btn_Regresar.TabIndex = 15;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click_1);
            // 
            // btn_Ir
            // 
            this.btn_Ir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Ir.FlatAppearance.BorderSize = 0;
            this.btn_Ir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ir.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ir.Image = ((System.Drawing.Image)(resources.GetObject("btn_Ir.Image")));
            this.btn_Ir.Location = new System.Drawing.Point(3, 69);
            this.btn_Ir.Name = "btn_Ir";
            this.btn_Ir.Size = new System.Drawing.Size(95, 87);
            this.btn_Ir.TabIndex = 16;
            this.btn_Ir.Text = "Cliente Nuevo";
            this.btn_Ir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Ir.UseVisualStyleBackColor = true;
            this.btn_Ir.Click += new System.EventHandler(this.btn_Ir_Click);
            // 
            // btnTelNip
            // 
            this.btnTelNip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTelNip.Enabled = false;
            this.btnTelNip.FlatAppearance.BorderSize = 0;
            this.btnTelNip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTelNip.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelNip.Image = global::PuntoVenta.Properties.Resources.nip;
            this.btnTelNip.Location = new System.Drawing.Point(3, 162);
            this.btnTelNip.Name = "btnTelNip";
            this.btnTelNip.Size = new System.Drawing.Size(95, 67);
            this.btnTelNip.TabIndex = 20;
            this.btnTelNip.Text = "Tel / Nip";
            this.btnTelNip.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTelNip.UseVisualStyleBackColor = true;
            this.btnTelNip.Visible = false;
            this.btnTelNip.Click += new System.EventHandler(this.btnTelNip_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(3, 235);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(95, 70);
            this.btn_ayuda.TabIndex = 17;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // DM0312_VentaEntrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1234, 504);
            this.ControlBox = false;
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.panelContactos);
            this.Controls.Add(this.txt_TituloEntrada);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_VentaEntrada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venta Entrada";
            this.Load += new System.EventHandler(this.VentanaEntrada_Load);
            this.LocationChanged += new System.EventHandler(this.DM0312_VentaEntrada_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_VentaEntrada_KeyDown);
            this.gbx_explorador.ResumeLayout(false);
            this.gbx_explorador.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VentanaEntrada)).EndInit();
            this.gbx_AdjMov.ResumeLayout(false);
            this.gbx_AdjMov.PerformLayout();
            this.panelMovimientos.ResumeLayout(false);
            this.panel_TipoVenta.ResumeLayout(false);
            this.panel_Buscador.ResumeLayout(false);
            this.panelContactos.ResumeLayout(false);
            this.panelContactos.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbx_Valera.ResumeLayout(false);
            this.gbx_Valera.PerformLayout();
            this.gbPromociones.ResumeLayout(false);
            this.gbPromociones.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btn_Venta;
        public System.Windows.Forms.GroupBox gbx_explorador;
        public System.Windows.Forms.Label lbl_Buscar;
        public System.Windows.Forms.DataGridView dgv_VentanaEntrada;
        public System.Windows.Forms.Button btn_Mayoreo;
        public System.Windows.Forms.Button btn_Instituciones;
        public System.Windows.Forms.Button btn_Dima;
        public System.Windows.Forms.Button btn_Contado;
        public System.Windows.Forms.Button btn_Ir;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.GroupBox gbx_AdjMov;
        private System.Windows.Forms.TextBox txt_MovId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox txt_Mov;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.TextBox txt_TituloEntrada;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.FlowLayoutPanel panelMovimientos;
        private System.Windows.Forms.FlowLayoutPanel panel_TipoVenta;
        private System.Windows.Forms.FlowLayoutPanel panel_Buscador;
        public System.Windows.Forms.Button btn_IrVenta;
        public System.Windows.Forms.Button btnBuscar;
        public System.Windows.Forms.Button btn_Credito;
        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_Cuenta;
        private System.Windows.Forms.TextBox txt_cuenta;
        public System.Windows.Forms.Button btn_SolValera;
        public System.Windows.Forms.GroupBox gbx_Valera;
        private System.Windows.Forms.ComboBox txt_Valera;
        private System.Windows.Forms.Label lbl_Valera;
        public System.Windows.Forms.Button btn_Adjudicacion;
        private System.Windows.Forms.CheckBox cbx_PublicoG;
        private System.Windows.Forms.TextBox txt_CodigoPostal;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Button btn_Devolucion;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button btnValDigital;
        public System.Windows.Forms.Button btn_CEmp; //-CreditoEmpresario
        public System.Windows.Forms.Button btnPagoServicio;
        public System.Windows.Forms.Button btnRecarga;
        private System.Windows.Forms.Button btnReimprimir;
        public System.Windows.Forms.Button btnTelNip;
        public System.Windows.Forms.Button btnPromocionesVencidas;
        public System.Windows.Forms.GroupBox gbPromociones;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.ComboBox cbTipoCapturaPromocion;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Button btnDimaForaneo;
    }
}