﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
//using CrypterPass;


namespace PuntoVenta
{
    public partial class CteExpress : Form //, ICteExpress // se agrega nombre de interfaze
    {
        private const int MF_BYPOSITION = 0x0400;
        private const int MF_DISABLED = 0x0002;
        public int Canal;
        public string Categoria;

        public string colonia;

        // credito express
        //bool ActivoForm = true;
        //bool esCredExpress;
        private double contador;

        public int Estacion, Sucursal, IDcte;
        //-------------------------------------------------------------------------------------------------

        private DataGridViewTextBoxEditingControl formatoTel;
        private int idCtoCouyuA;
        private int IdCtoRecConyu;
        private int IdCtoRecomen;
        public string LinConex;
        private string NombreTipoCaptura;

        public string Prospecto;
        private int TipoCaptura;
        private string Usuario;

        public CteExpress(string Pro, int Cnl, string Cat, int suc, string usua, int est)
        {
            InitializeComponent();
            Prospecto = Pro;
            Canal = Cnl;
            Categoria = Cat.Replace("_", " ");
            Sucursal = suc;
            Usuario = usua;
            Estacion = est;
            //this.MaximumSize = new System.Drawing.Size(1132, 900);
            //----------------para controla el tab con el enter en los groupbox--------------            
            tab(grboxCte);
            tab(grBoxDirCte);
            tab(grBoxDomAnt);
            tab(grbEmpCte);
            tab(grboxDirEmpleo);
            tab(grboxDirEmpA);
            tab(grbCont);
            tab(grbRefComBan);
            tab(grbBusCte);
            tab(grbNomi);
            tab(grbTel);
        }

        public CteExpress()
        {
            InitializeComponent();
        }

        [DllImport("user32.dll", EntryPoint = "GetSystemMenu")]
        private static extern IntPtr GetSystemMenu(IntPtr hwnd, int revert);

        [DllImport("user32.dll", EntryPoint = "GetMenuItemCount")]
        private static extern int GetMenuItemCount(IntPtr hmenu);

        [DllImport("user32.dll", EntryPoint = "RemoveMenu")]
        private static extern int RemoveMenu(IntPtr hmenu, int npos, int wflags);

        [DllImport("user32.dll", EntryPoint = "DrawMenuBar")]
        private static extern int DrawMenuBar(IntPtr hwnd);

        //============================================================================================
        private void CteExpress_Load(object sender, EventArgs e)
        {
            IntPtr hmenu = GetSystemMenu(Handle, 0);
            int cnt = GetMenuItemCount(hmenu);
            // remove 'close' action
            RemoveMenu(hmenu, cnt - 1, MF_DISABLED | MF_BYPOSITION);


            dtpFechNac.Value = DateTime.Now.Date;
            //Conexiones LineaConex = new Conexiones();
            //CapturaCte cte = new CapturaCte();
            //LinConex = LineaConex.setCadena();
            //IDcte = cte.RegresaIDCte(LinConex, Prospecto);
            //grboxEmpleoCte.Location = new Point(184, grbox1.Size.Height + 100);
            lblCon.Text = Prospecto; //LineaConex.getCadena();
            Desapacer(Categoria);
            txtCanal.Text = Convert.ToString(Canal);
            llenarCombosDatCte();
            LLenarCombosDirCte();
            llenarCombosDirecAnt();
            llenarComboEmpleo();
            llenaComboDirEmpleo();
            llenarComboParentR();
            llenarComboGrid();

            //Consultas Consult = new Consultas();
            //lblSpid.Text = lblSpid.Text + Consult.Spid(LinConex);
            //frmTipoCte tipo = new frmTipoCte();
            cmbTipoCred.DisplayMember = "Value";
            cmbTipoCred.ValueMember = "Key";
            //cmbTipoCred.DataSource = tipo.llenaCombo_Tipo();
            cmbTipoCred.SelectedIndex = cmbTipoCred.FindString("Credito Agil");
            timer1.Start();
        }

        //-----------------------------------------------------------------------------------------------------
        private void tab(GroupBox g)
        {
            foreach (Control x in g.Controls) x.KeyPress += keypressed;
        }

        //-----------------------------------------------------------------------------------------------------
        private void keypressed(object o, KeyPressEventArgs e)
        {
            grboxCaps.Location = new Point(10, 10);
            if (e.KeyChar == (char)Keys.Return)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        //------------------------------------------------------------------------------------------------        
        private void Desapacer(string Cat)
        {
            //if (Cat == "CONTADO")
            //{
            //    grbox1.Location = new Point(184, 4);
            //    grBoxDomAnt.Visible = false;
            //    grboxEmpleoCte.Visible = false;
            //    grbTelefono.Visible = true;
            //    grbTelefono.Location = new Point(203, (grbox1.Location.Y + grbox1.Size.Height + 20));
            //    btnImp.Visible = false;
            //    btnGoogle.Visible = false;
            //    btnCapDatCte.Visible = false;
            //    btnCapEmpCte.Visible = false;
            //    btnDatNomi.Visible = false;
            //    btnCapRefCte.Visible = false;
            //    btnTelefonos.Visible = false;
            //    btnDatNomi.Enabled = false;
            //    grbDatNominales.Visible = false;
            //    grbContactos.Visible = false;
            //    lblEntC.Visible = false;
            //    txtEntreC.Visible = false;
            //    lblYearAntCte.Visible = false;
            //    txtCtrlYear.Visible = false;
            //    lblMesAntCte.Visible = false;
            //    txtCtrlMes.Visible = false;
            //    lblTipo.Visible = false;
            //    cmbTipoCalle.Visible = false;
            //    btnSalir.Location = new Point(7, 78);
            //    grboxCaps.Size = new Size(164, 200);
            //    this.Size = new Size(1094, 650);
            //    lblCon.Location = new Point(6, 131);
            //    lblSpid.Location = new Point(104, 170);
            //    lblViveCalCte.Visible = false;
            //    cmbViveCalCte.Visible = false;
            //    lblEdoC.Visible = false;
            //    cmbEdoCivil.Visible = false;
            //    lblLiveCon.Visible = false;
            //    cmbLiveCon.Visible = false;
            //    lblKeViveEnC.Visible = false;
            //    cmbKeLiveEnC.Visible = false;
            //    lblSex.Visible = false;
            //    cmbSex.Visible = false;
            //    lblMail.Visible = true;
            //    txtEmail.Visible = true;
            //    grbTiempo.Visible = false;
            //}
            //if (Cat == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            //{
            grbRef.Visible = true;
            btnDatNomi.Enabled = false;
            grbDatNominales.Visible = false;
            grbRefComBan.Visible = true;
            //if (Categoria == "ASOCIADOS")
            //{
            //    grbDimR.Visible = true;
            //}
            //else
            //{
            grbRef.Location = new Point(184, 4);
            grbox1.Location = new Point(184, grbRef.Location.Y + grbRef.Size.Height + 20);
            grboxEmpleoCte.Location = new Point(184, grbox1.Location.Y + grbox1.Size.Height + 20);
            //}

            grbContactos.Location = new Point(184, grboxEmpleoCte.Location.Y + grboxEmpleoCte.Size.Height + 20);
            //grbRef.Location = new Point(184, (grbContactos.Location.Y + grbContactos.Size.Height + 20));
            grbRefComBan.Location = new Point(184, grbContactos.Location.Y + grbContactos.Size.Height + 20);
            grbTelefono.Location = new Point(184, grbRefComBan.Location.Y + grbRefComBan.Size.Height + 20);

            //}

            //if (Cat == "INSTITUCIONES")
            //{
            //    grbRef.Visible = true;
            //    //grbRef.Location = new Point(184, (grbContactos.Location.Y + grbContactos.Size.Height + 20));
            //    grboxEmpleoCte.Location = new Point(184, (grbox1.Location.Y + grbox1.Size.Height + 20));
            //    grbContactos.Location = new Point(184, (grboxEmpleoCte.Location.Y + grboxEmpleoCte.Size.Height + 20));
            //    grbDatNominales.Location = new Point(184, (grbContactos.Location.Y + grbContactos.Size.Height + 20));
            //    grbTelefono.Location = new Point(184, (grbDatNominales.Location.Y + grbDatNominales.Size.Height + 20));
            //    btnCapRefCte.Enabled = false;
            //}
        }

        //--------------------------------------------------------------------------------------------------------
        private void llenarCombosDatCte()
        {
            if (Categoria == "CONTADO")
            {
                cmbRegimen.Items.Add("Persona Fisica");
                cmbRegimen.Items.Add("Persona Moral");
                cmbSex.Items.Add("Masculino");
                cmbSex.Items.Add("Femenino");
                cmbEdoCivil.Enabled = false;
            }

            if (Categoria == "CREDITO EXTERNO" || Categoria == "CREDITO MENUDEO" || Categoria == "INSTITUCIONES" ||
                Categoria == "ASOCIADOS")
            {
                cmbRegimen.Items.Add("Persona Fisica");
                cmbRegimen.SelectedItem = "Persona Fisica";
                cmbSex.Items.Add("Masculino");
                cmbSex.Items.Add("Femenino");
            }
        }

        //-----------------------------------------------------------------------------------
        private void cmbRegimen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Categoria == "CONTADO")
            {
                if (cmbRegimen.Text == "Persona Moral")
                {
                    cmbSex.Text = "";
                    cmbSex.Enabled = false;
                    dtpFechNac.Enabled = false;
                    txtApePat.Clear();
                    txtApePat.Enabled = false;
                    txtApeMat.Clear();
                    txtApeMat.Enabled = false;
                    cmbEdoCivil.Text = "";
                    cmbEdoCivil.Enabled = false;
                    txtRfc.Text = "";
                    mskFechaNac.Text = "";
                    mskFechaNac.Enabled = false;
                }

                else
                {
                    cmbSex.Enabled = true;
                    dtpFechNac.Enabled = true;
                    mskFechaNac.Enabled = true;
                    txtApePat.Enabled = true;
                    txtApeMat.Enabled = true;
                    mskFechaNac.Enabled = true;
                }
            }

            if ((Categoria == "CREDITO MENUDEO" || Categoria == "INSTITUCIONES" || Categoria == "ASOCIADOS") &&
                cmbRegimen.Text == "Persona Moral")
            {
                cmbEdoCivil.Text = "";
                cmbEdoCivil.Enabled = false;
            }

            modificarRFC();
            txtCanal.Focus();
        }

        //----------------------------------------------------------------------------------
        private void cmbSex_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Consultas Con = new Consultas();
            List<string> list = new List<string>();
            if (Categoria == "CREDITO EXTERNO") cmbEdoCivil.Enabled = false;
            if ((Categoria == "CREDITO MENUDEO" || Categoria == "INSTITUCIONES" || Categoria == "ASOCIADOS") &&
                cmbRegimen.Text != "Persona Moral") cmbEdoCivil.Items.Clear();
            //list = Con.EstadoCivil(LinConex, cmbSex.Text);
            //foreach (var lis in list)
            //{
            //    cmbEdoCivil.Items.Add(lis);
            //}
            mskFechaNac.Focus();
        }

        //----------------------------------------------------------------------------------    
        private void dtpFechNac_LostFocus(object sender, EventArgs e)
        {
            //Consultas Con = new Consultas();
            //txtEdad.Text = Con.SetEdad(String.Format("{0:yyyy-MM-dd}", dtpFechNac.Value.Date), LinConex);
            //mskFechaNac.Text = String.Format("{0:dd/MM/yyyy}", dtpFechNac.Value.Date);
            //modificarRFC();
        }

        private void dtpFechNac_CloseUp(object sender, EventArgs e)
        {
            //Consultas Con = new Consultas();
            //txtEdad.Text = Con.SetEdad(String.Format("{0:yyyy-MM-dd}", dtpFechNac.Value.Date), LinConex);
            mskFechaNac.Text = string.Format("{0:dd/MM/yyyy}", dtpFechNac.Value.Date);
            modificarRFC();
        }

        //--------------------------------------------------------------------------------------------
        private void mskFechaNac_LostFocus(object sender, EventArgs e)
        {
            if (mskFechaNac.Text.Length == 10)
            {
                //Consultas Con = new Consultas();
                string fechaN;
                try
                {
                    fechaN = string.Format("{0:yyyy-MM-dd}", DateTime.Parse(mskFechaNac.Text));
                    //txtEdad.Text = Con.SetEdad(fechaN, LinConex);
                    modificarRFC();
                }
                catch (Exception w)
                {
                    if (w.Source != null)
                    {
                        MessageBox.Show("Escriba una fecha valida");
                        mskFechaNac.Text = "";
                    }
                }
            }
            else
            {
                mskFechaNac.Text = "";
                txtRfc.Text = "";
            }
        }

        //---------------------------------------------------------------------------------------
        private void LLenarCombosDirCte()
        {
            //Andador Autopista Avenida Boulevard Calle Callejón Calzada Camino Carretera Cerrada o Privada Pasaje 
            List<string> lista = new List<string>();
            //Consultas ListaTipC = new Consultas();

            List<string> lisCali = new List<string>();

            //lista = ListaTipC.TipoCalle();
            foreach (string li in lista) cmbTipoCalle.Items.Add(li);
            if (Categoria == "CREDITO MENUDEO" || Categoria == "INSTITUCIONES" || Categoria == "MAYOREO" ||
                Categoria == "ASOCIADOS")
            {
                //Consultas Con = new Consultas();
                //lisCali = Con.opcViveEnCalidad(LinConex);
                foreach (string l in lisCali) cmbViveCalCte.Items.Add(l);
                //cmbViveCalCte.DataSource = Con.opcViveEnCalidad(LinConex);
                cmbViveCalCte.Items.Add("");
            }
            else
            {
                cmbViveCalCte.Enabled = false;
            }
        }

        //--------------------------------------------------------------------------------------
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Dir("Act", "cte");
            txtCpCte.Focus();
        }

        //------------------------------------------------------------------------------------------       
        private void llenarCombosDirecAnt()
        {
            List<string> list = new List<string>();
            //Consultas Com = new Consultas();

            //list = Com.TipoCalle();

            foreach (string li in list) cmbTipoCalleAnt.Items.Add(li);
            cmbTipoCalleAnt.Items.Add("");
            list.Clear();
            //list = Com.opcViveEnCalidad(LinConex);
        }

        //---------------------------------------------------------------------------------
        private void btnBuscarAnt_Click(object sender, EventArgs e)
        {
            Dir("Ant", "cte");
            txtCpCteAnt.Focus();
        }

        //-----------------------------------------------------------------------------------         
        private void Dir(string a, string sec) //los botones de buscar colonia llaman a este prosedimiento
        {
            //BuscarColonia bsc = new BuscarColonia(a, sec, Sucursal);
            //bsc.Show(this);
        }

        //----------------------------------------------------------------------------------------
        private void cmbEdoCivil_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int year = 0, mes = 0;
            //string estadoC = "Union Libre", sex = "";
            //GuadarCto ct = new GuadarCto();

            //count = ct.ExisteConyuge(LinConex, Prospecto, "CONYUGE");
            if (cmbEdoCivil.Text == "Casado" || cmbEdoCivil.Text == "Casada" || cmbEdoCivil.Text == "Union Libre")
            {
                //CapturaCto cap = new CapturaCto(Canal, Sucursal, Prospecto, Categoria, cmbRegimen.Text, Respuesta1, Usuario, "CONYUGE", esCredExpress,NombreTipoCaptura);
                //cap.Show(this);
                //if (txtCtrlYear.Text.Trim() != "")
                //{
                //    year = Convert.ToInt32(txtCtrlYear.Text);
                //}
                //if (txtCtrlMes.Text.Trim() != "")
                //{
                //    mes = Convert.ToInt32(txtCtrlMes.Text);
                //}

                //if (cmbEdoCivil.Text == "Casado")
                //{
                //    estadoC = "Casada";
                //    sex = "Femenino";
                //}
                //if (cmbEdoCivil.Text == "Casada")
                //{
                //    estadoC = "Casado";
                //    sex = "Masculino";
                //}

                //if (cmbEdoCivil.Text == "Union Libre")
                //{
                //    estadoC = "Union Libre";
                //    if (cmbSex.Text == "Masculino")
                //        sex = "Femenino";
                //    if (cmbSex.Text == "Femenino")
                //        sex = "Masculino";
                //}
                //cap.CapturaCto_Load1(cmbViveCalCte.Text, estadoC, sex, "Particular", year, mes, cmbTipoCalle.Text, txtDir.Text, txtNumExt.Text, txtNumInt.Text, txtEntreC.Text, txtColCte.Text, txtDelCte.Text, txtPobCte.Text, txtCpCte.Text, txtEstCte.Text, txtPaisCte.Text);
            }

            txtDir.Focus();
        }

        //-------------------------------------------------------------------------------
        private void btnCapDatCte_Click(object sender, EventArgs e)
        {
            grboxCaps.Location = new Point(10, grbox1.Location.Y);
            grbox1.Focus();
            cmbRegimen.Focus();
        }

        //-------------------------------------------------------------------------
        private void CambioMesYear(NumericUpDown year, NumericUpDown mes)
        {
            if (mes.Value == 12)
            {
                year.Value = 1;
                mes.Value = 0;
            }
        }

        //------------------INICIO CAPTURA EMPLEO CTE-----------------------------------
        //---------------------------------------------------------------------------
        private void txtIngreso_KeyPess(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
            {
                e.Handled = true;
                txtIngreso.Focus();
            }
            else if (char.IsDigit(e.KeyChar) || e.KeyChar == 46)
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        //----------------------------------------------------------------------------------------------------
        private void txtIngreso_LostFocus(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(txtIngreso.Text) >= 0.000 && Convert.ToDouble(txtIngreso.Text) <= 9999999.999)
                {
                }
                else
                {
                    MessageBox.Show("valor no valido");
                }
            }
            catch (Exception ee)
            {
                if (ee.Source != null)
                    MessageBox.Show("valor no valido");
                txtIngreso.Clear();
                //txtIngreso.Focus();
            }
        }

        //----------------------------------------------------------------------------------------------         
        private void llenarComboEmpleo()
        {
            //Consultas con = new Consultas();
            //Conexiones c = new Conexiones();
            //linea = c.setCadena();
            List<string> list = new List<string>();
            List<string> lisTipo = new List<string>();

            //lisTipo = con.tipoEmp(linea);

            foreach (string x in lisTipo) cmbTipEmp.Items.Add(x);
            cmbTipEmp.Items.Add("");

            //list = con.PeriodoIngreso();

            foreach (string l in list) cmbPerIngreso.Items.Add(l);
            cmbPerIngreso.Items.Add("");
        }

        //--------------------------------------------------------------------------------------------
        private void llenaComboDirEmpleo()
        {
            List<string> list = new List<string>();
            //Consultas c = new Consultas();

            //list = c.TipoCalle();

            foreach (string l in list)
            {
                cmbTipCalleE.Items.Add(l);
                cmbTipCalleEmpA.Items.Add(l);
            }

            cmbTipCalleE.Items.Add("");
            cmbTipCalleEmpA.Items.Add("");
        }

        //---------------------------------------------------------------------------------------
        private void btnBusColE_Click(object sender, EventArgs e)
        {
            if (txtDirEmp.Text.Trim() != "" && cmbTipCalleE.Text.Trim() != "")
            {
                Dir("Emp", "cte");
                txtCpEmp.Focus();
            }
            else
            {
                MessageBox.Show("es nesesario que los campos Direccion y tipo de calle tengan datos");
            }
        }

        private void btnBusColA_Click(object sender, EventArgs e)
        {
            if (txtDirAntE.Text.Trim() != "" && cmbTipCalleEmpA.Text.Trim() != "" && txtDirAntE.Text.Trim() != "")
            {
                Dir("EmpA", "cte");
                txtPobEmpA.Focus();
            }
            else
            {
                MessageBox.Show("es nesesario que los campos Empresa y Direccion y tipo de calle tengan datos");
            }
        }

        //----------------------------------------------------------------------------------------
        private void cmbViveCalCte_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Consultas con = new Consultas();
            List<string> listViveCon = new List<string>();
            List<string> listViveEnC = new List<string>();

            if (cmbViveCalCte.Text == "HUESPED" && (Categoria == "CREDITO MENUDEO" || Categoria == "INSTITUCIONES" ||
                                                    Categoria == "MAYOREO" || Categoria == "ASOCIADOS"))
            {
                cmbLiveCon.Enabled = true;
                cmbKeLiveEnC.Enabled = true;
                lblKeViveEnC.Enabled = true;
                lblLiveCon.Enabled = true;

                //listViveCon = con.ViveCon(LinConex);
                foreach (string l in listViveCon) cmbLiveCon.Items.Add(l);

                //listViveEnC = con.keViveEnC(LinConex);
                foreach (string li in listViveEnC) cmbKeLiveEnC.Items.Add(li);
            }
            else
            {
                cmbLiveCon.Items.Clear();
                cmbKeLiveEnC.Items.Clear();
                cmbKeLiveEnC.Enabled = false;
                cmbLiveCon.Enabled = false;
                lblKeViveEnC.Enabled = false;
                lblLiveCon.Enabled = false;
            }

            cmbLiveCon.Focus();
        }
        //-------------------------------------------------------------------------------------------------------

        //----------------------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------------------------- 
        //-----------------------final CAPTURA EMPLEO CTE--------------------

        //---------------------------------------------------------------------------------------
        //---------inicio--------------------------PARA MOVER EL GROUP BOX DE LOS BOTONES---------------
        private void CteExpress_Scroll(object sender, ScrollEventArgs e)
        {
            if (Categoria == "INSTITUCIONES" || Categoria == "CREDITO MENUDEO" || Categoria == "CONTADO" ||
                Categoria == "ASOCIADOS")
                grboxCaps.Location = new Point(10, 10);
        }

        private void CteExpess_MouseWheel(object sender, MouseEventArgs e)
        {
            int y = 0;
            if (Categoria == "INSTITUCIONES" || Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            {
                y = grboxCaps.Location.Y + e.Delta * -1;
                if (y <= 10)
                    y = 10;

                if (VerticalScroll.Value <= Size.Height)
                {
                    grboxCaps.Focus();
                    grboxCaps.Location = new Point(10, y);
                }
                else
                {
                    grboxCaps.Location = new Point(10, 10);
                }
            }


            //MessageBox.Show(Convert.ToString(grboxCaps.Location.Y));
        }

        //------------final-------------------PARA MOVER EL GROUP BOX DE LOS BOTONES---------------
        //-----------------------------------------------------------------------------------------------------
        private void btnBuscCte_Click(object sender, EventArgs e)
        {
            if (IdCtoRecomen == 0)
                //BuscarCte bus = new BuscarCte();
                //bus.Show(this);
                txtNomR.Focus();
            if (IdCtoRecomen > 0)
            {
                DialogResult r = MessageBox.Show("Desea eliminar el contacto Aval Recomendado? ", "Elimina",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    eliminaCtoRecomendado(IdCtoRecomen);
                    eliminaCtoRecomendado(idCtoCouyuA);
                    eliminaCtoRecConyu();
                    cmbParent.SelectedItem = "";
                    IdCtoRecomen = 0;
                    txtRecPor.Text = "";
                    txtNomR.Text = "";
                    txtDirRe.Text = "";
                    cmbParent.SelectedText = "";
                    //BuscarCte bus = new BuscarCte();
                    //bus.Show(this);
                    txtNomR.Focus();
                }
            }
        }

        //-------------------------------------------------------------------------------------------------
        private void llenarComboParentR()
        {
            List<string> list = new List<string>();
            //Consultas cns = new Consultas();

            //list = cns.ViveCon(LinConex);

            foreach (string l in list)
            {
                cmbParent.Items.Add(l);
                cmbParent.Items.Remove("AVALADO");
                cmbParent.Items.Remove("CONCUBINA");
                cmbParent.Items.Remove("CONCUBINO");
                cmbParent.Items.Remove("EL");
                cmbParent.Items.Remove("ELLA");
                cmbParent.Items.Remove("EMPLEADO");
                cmbParent.Items.Remove("NOVIA");
                cmbParent.Items.Remove("NOVIO");
                cmbParent.Items.Remove("PATRON");
            }

            cmbParent.Items.Add("");
        }

        //------------------------------------------------------------------------------------------------
        private void btnCapEmpCte_Click(object sender, EventArgs e)
        {
            grboxCaps.Location = new Point(10, grboxEmpleoCte.Location.Y);
            grboxEmpleoCte.Focus();
            txtEmpCte.Focus();
        }

        //------------------------------------------------------------------------------------------------
        private void btnDatNomi_Click(object sender, EventArgs e)
        {
            grboxCaps.Location = new Point(10, grbDatNominales.Location.Y);
            grbDatNominales.Focus();
        }

        //------------------------------------------------------------------------------------------------
        private void btnCapRefCte_Click(object sender, EventArgs e)
        {
            if (Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            {
                grboxCaps.Location = new Point(10, grbRef.Location.Y);
                grbRef.Focus();
                btnBuscCte.Focus();
            }
        }

        //---------------------------------------------------------------------------------------------------
        private void grbox1_SizeChanged(object sender, EventArgs e)
        {
            if (Categoria != "CREDITO MENUDEO" || Categoria != "ASOCIADOS")
            {
                grboxEmpleoCte.Location = new Point(184, grbox1.Location.Y + grbox1.Size.Height + 20);
                grbContactos.Location = new Point(184, grboxEmpleoCte.Location.Y + grboxEmpleoCte.Size.Height + 20);
                grbDatNominales.Location = new Point(184, grbContactos.Location.Y + grbContactos.Size.Height + 20);
                //grbRef.Location = new Point(184, grbDatNominales.Location.Y + grbDatNominales.Size.Height + 20);
                grbTelefono.Location = new Point(184, grbDatNominales.Location.Y + grbDatNominales.Size.Height + 20);
            }

            if (Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            {
                grboxEmpleoCte.Location = new Point(184, grbox1.Location.Y + grbox1.Size.Height + 20);
                grbContactos.Location = new Point(184, grboxEmpleoCte.Location.Y + grboxEmpleoCte.Size.Height + 20);
                //grbRef.Location = new Point(184, grbContactos.Location.Y + grbContactos.Size.Height + 20);
                grbRefComBan.Location = new Point(184, grbContactos.Location.Y + grbContactos.Size.Height + 20);
                grbTelefono.Location = new Point(184, grbRefComBan.Location.Y + grbRefComBan.Size.Height + 20);
            }
        }

        //-------------inicia------CAPTURA DE CONTACTO
        //------------------------------------------------------------------------------------------------------
        private void btnAgregarCto_Click(object sender, EventArgs e)
        {
            if (cmbRegimen.Text.Trim() != "")
            {
                //CapturaCto cap = new CapturaCto(Canal, Sucursal, Prospecto, Categoria, cmbRegimen.Text, Respuesta1, Usuario, "", esCredExpress, NombreTipoCaptura);
                //cap.Show(this);
            }
            else
            {
                MessageBox.Show("Capturar Regimen Fiscal");
            }
        }

        //-----------------------------------------------------------------------------------------------------
        private void dgvCto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int ID, CtrlYear = 0, CtrlMes = 0;

            if (txtCtrlYear.Text.Trim() != "")
                int.TryParse(txtCtrlYear.Text, out CtrlYear);

            if (txtCtrlMes.Text.Trim() != "")
                int.TryParse(txtCtrlMes.Text, out CtrlMes);
            if (dgvCto.Columns[e.ColumnIndex].Name.Equals("Editar"))
            {
                //x = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Nombre"].Value);
                //MessageBox.Show(x); 
                string tipo = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Tipo"].Value);
                string Parent = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Parentesco"].Value);
                string Apat = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["ApePat"].Value);
                string Amat = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["ApeMat"].Value);
                string Nom = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Nombre"].Value);
                string Cnl = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["CnlVent"].Value);
                string lada = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Lada"].Value);
                string tel = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Telefono"].Value);
                string Fech = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["FechaN"].Value);
                string sexo = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["Sexo"].Value);
                string Edo = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["EdoC"].Value);
                string ViveC = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["ViveEnCal"].Value);
                string ViveCon = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["ViveCon"].Value);
                string Calidad = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["CalidadCon"].Value);
                ID = Convert.ToInt32(dgvCto.Rows[e.RowIndex].Cells["idCto"].Value);
                int EsCasa = Convert.ToInt32(dgvCto.Rows[e.RowIndex].Cells["EsCasa"].Value);
                string NoCuenta = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["NoCuenta"].Value);
                string rfccto = Convert.ToString(dgvCto.Rows[e.RowIndex].Cells["rfcCto"].Value);

                //ActualizaCto act = new ActualizaCto(Canal, Sucursal, Prospecto, Categoria, cmbRegimen.Text, Respuesta1, Usuario, ID, esCredExpress,NombreTipoCaptura);
                //act.Show(this);
                if (cmbEdoCivil.Text == "Casado")
                {
                    Edo = "Casada";
                    sexo = "Femenino";
                }
                else if (cmbEdoCivil.Text == "Casada")
                {
                    Edo = "Casado";
                    sexo = "Masculino";
                }
                else if (cmbEdoCivil.Text == "Union Libre")
                {
                    Edo = "Union Libre";
                    if (cmbSex.Text == "Masculino")
                        sexo = "Femenino";
                    else
                        sexo = "Masculino";
                }
                //act.ActualizaCto_Load1(tipo, Parent, Apat, Amat, Nom, Cnl, lada, tel, Fech, sexo, Edo, ViveC, ViveCon, Calidad, Canal, Sucursal, "Particular", CtrlYear, CtrlMes, cmbTipoCalle.Text, txtDir.Text, txtNumExt.Text, txtNumInt.Text, txtEntreC.Text, txtColCte.Text, txtDelCte.Text, txtPobCte.Text, txtCpCte.Text, txtEstCte.Text, txtPaisCte.Text, EsCasa, NoCuenta, rfccto, esCredExpress);
                // si es conyuge se lleva la misma direccion del cliente ,, en el ActualizaCto.cs determina si es conyuge sino carga la direccion del registro del contacto a editar
            }

            if (dgvCto.Columns[e.ColumnIndex].Name.Equals("Eliminar")) // para eliminar el contacto dentro del grid
            {
                DialogResult r = MessageBox.Show("Desea Eliminar al contacto ", "Eliminar", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    ID = Convert.ToInt32(dgvCto.Rows[e.RowIndex].Cells["idCto"].Value);
                    //GuadarCto gt = new GuadarCto();

                    if (ID == IdCtoRecomen || ID == idCtoCouyuA)
                        eliminaCtoRecomendado(ID);
                    else if (ID == IdCtoRecConyu)
                        eliminaCtoRecConyu();
                    else
                        //gt.EliminarCto(LinConex, Prospecto, ID);
                        dgvCto.Rows.RemoveAt(e.RowIndex);
                }
            }
        }

        //--------------------------------------------------------------------------------------------------------
        private void btnAgrTel_Click(object sender, EventArgs e)
        {
            string datosOk = "";
            int filasBanco, cuantos = 1;
            int digitos = 0;

            if (dgvTelefono.RowCount > 0)
            {
                filasBanco = dgvTelefono.RowCount;

                if (filasBanco == 0)
                {
                    MessageBox.Show("favor de capturar datos de banco");
                    datosOk = "no";
                }
                else
                {
                    for (int x = 0; x < filasBanco; x++)
                    {
                        if (Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value).Trim() == "" ||
                            Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value).Trim() == "" ||
                            Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value).Trim() == "")
                        {
                            MessageBox.Show("En Telefono: " + Convert.ToString(cuantos) + " falta capturar datos <->");
                            datosOk = "no";
                            break;
                        }

                        datosOk = "ok";
                        digitos = dgvTelefono.Rows[x].Cells[2].Value.ToString().Trim().Length +
                                  dgvTelefono.Rows[x].Cells[3].Value.ToString().Trim().Length;


                        cuantos = cuantos + 1;
                    }
                }

                if (datosOk == "ok")
                    dgvTelefono.Rows.Add();
                //else
                //{
                //    dgvTelefono.Rows[dgvTelefono.CurrentRow.Index].ErrorText = "la lada junto con el telefono no son los 10 digitos";
                //    MessageBox.Show("la lada junto con el telefono no son los 10 digitos");
                //}
            }
            else
            {
                dgvTelefono.Rows.Add();
            }
        }

        //------------------------------------------------------------------------------------------------------
        private void llenarComboGrid()
        {
            List<string> listaTipoDirec = new List<string>();

            //Consultas consul = new Consultas();

            //listaTipoDirec = consul.opcTelefono(LinConex);

            DataGridViewComboBoxColumn comboboxColumn = dgvTelefono.Columns["TipoTel"] as DataGridViewComboBoxColumn;

            foreach (string l in listaTipoDirec) comboboxColumn.Items.Add(l);
        }

        //------------------------------------------------------------------------------------------
        private void dgvTelefono_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SendKeys.Send("{TAB}");
            }
        }

        //------------------------------------------------------------------------------------------
        private void dgvTelefono_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex != -1 && dgvTelefono.Columns[e.ColumnIndex].Name.Equals("Borrar") && e.RowIndex != -1)
                dgvTelefono.Rows.RemoveAt(e.RowIndex);
        }

        private void dgvTelefono_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            int columnIndex = dgvTelefono.CurrentCell.ColumnIndex;
            if (dgvTelefono.Columns[columnIndex].Name.Equals("TelefonoTel") ||
                dgvTelefono.Columns[columnIndex].Name.Equals("LadaTel"))
            {
                formatoTel = (DataGridViewTextBoxEditingControl)e.Control;
                formatoTel.KeyPress += formatoTel_KeyPress;
            }
        }

        //---------------------------------------------------------------------------------------------------------        
        private void formatoTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            int columnIndex = dgvTelefono.CurrentCell.ColumnIndex;
            if (dgvTelefono.Columns[columnIndex].Name.Equals("TelefonoTel") ||
                dgvTelefono.Columns[columnIndex].Name.Equals("LadaTel"))
            {
                if (char.IsNumber(e.KeyChar) || e.KeyChar == (char)Keys.Back)
                    e.Handled = false;
                else
                    e.Handled = true;
            }
        }

        //------------------------------------------------------------------------------------------------------------
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //string DatosCteOk = "", NominalesOk = "", telOk = "", mensaje = "";
            //string Tipo, Lada, Telefono;
            //int countTel;
            //countTel = dgvTelefono.RowCount;
            //DatosCteOk = verificaDatosCte();
            //this.Close();
            //PuntoDeVenta venta = new PuntoDeVenta();
            //venta.ShowDialog();
            Dispose();


            //if (Categoria == "INSTITUCIONES")
            //{
            //    telOk = verificaTelefonos();
            //    NominalesOk = verificaDatosNominales();
            //    if (DatosCteOk == "ok" && NominalesOk == "ok" && telOk == "ok")
            //    {
            //        CapturaCte cte = new CapturaCte();
            //        ActualizaCte();
            //        cte.GuardaDatNomi(txtNomina.Text, Prospecto, txtPuestoN.Text, txtRfcInst.Text, txtCveInst.Text, txtCargoN.Text, txtMpioN.Text, LinConex);
            //        cte.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            cte.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        cte.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza", 1, 0);
            //        mensaje = cte.CargaClientesMavi(LinConex, Prospecto, "Agregar", Estacion, IDcte, Usuario, cmbRegimen.Text);
            //        MessageBox.Show(mensaje);
            //        bandera = 1;
            //        this.Close();
            //    }
            //}

            //if (Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            //{

            //    telOk = verificaTelefonos();
            //    if (DatosCteOk == "ok" && telOk == "ok")
            //    {
            //        CapturaCte cte = new CapturaCte();
            //        ActualizaCte();
            //        cte.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            cte.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        cte.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza", 1, 0);
            //        mensaje = cte.CargaClientesMavi(LinConex, Prospecto, "Agregar", Estacion, IDcte, Usuario, cmbRegimen.Text);
            //        if (Categoria == "ASOCIADOS" && !string.IsNullOrEmpty(txtCuentaDimr.Text) && !string.IsNullOrEmpty(txtNomDimR.Text))
            //        {
            //            Consultas consul = new Consultas();
            //            if (!consul.EsRDP(Sucursal, LinConex))
            //            {
            //                FRM_DIMA_RECOM recom = new FRM_DIMA_RECOM(Prospecto, txtCuentaDimr.Text);
            //                recom.ShowDialog();
            //            }
            //            else
            //            {
            //                RutaTicket();
            //            }
            //        }
            //        MessageBox.Show(mensaje);
            //        bandera = 1;
            //        this.Close();
            //    }
            //}

            //if (Categoria == "CONTADO")
            //{
            //    if (DatosCteOk == "ok")
            //    {
            //        CapturaCte cte = new CapturaCte();
            //        ActualizaCte();
            //        cte.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            cte.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        cte.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza", 1, 0);
            //        mensaje = cte.CargaClientesMavi(LinConex, Prospecto, "Agregar", Estacion, IDcte, Usuario, cmbRegimen.Text);
            //        MessageBox.Show(mensaje);
            //        bandera = 1;
            //        this.Close();
            //    }
            //}
        }

        private void RutaTicket()
        {
            //CapturaCte setUen = new CapturaCte();
            //string UEN = setUen.SetUEN(LinConex, Convert.ToString(Canal));

            //try
            //{
            //    Conexiones ruta = new Conexiones();
            //    System.Diagnostics.ProcessStartInfo InfoPreguntas = new System.Diagnostics.ProcessStartInfo();
            //    InfoPreguntas.Arguments = " SHM4 " + Prospecto + " " + txtCuentaDimr.Text + " " + Sucursal + " " + Estacion + " " + Usuario;
            //    InfoPreguntas.FileName = ruta.setRutaMaps() + "RutaTicket.exe";
            //    InfoPreguntas.WorkingDirectory = ruta.setRutaMaps(); ;
            //    try
            //    {
            //        System.Diagnostics.Process PreguntasSeguridad = new System.Diagnostics.Process();
            //        PreguntasSeguridad.StartInfo = InfoPreguntas;
            //        PreguntasSeguridad.Start();
            //        PreguntasSeguridad.WaitForExit();
            //    }
            //    catch (Exception w)
            //    {
            //        string mensaje = w.Message;
            //    }

            //}
            //catch (Exception e)
            //{
            //    MessageBox.Show("error al madar llamar RutaTicket, " + e.Message);
            //}
        }

        private void ActualizaCte()
        {
            string fechaN = "";
            int cyear = 0, cmes = 0, Eyear = 0, Emes = 0;
            double ingreso = 0.0;
            try
            {
                if (txtIngreso.Text.Trim() != "")
                    ingreso = Convert.ToDouble(txtIngreso.Text);
                //if (chboxComprob.Checked == true)
                //    Compr = 1;
                //else
                //    Compr = 0;

                if (txtCtrlYear.Text.Trim() != "")
                    int.TryParse(txtCtrlYear.Text, out cyear);

                if (txtCtrlMes.Text.Trim() != "")
                    int.TryParse(txtCtrlMes.Text, out cmes);

                if (txtYearEmp.Text.Trim() != "")
                    int.TryParse(txtYearEmp.Text, out Eyear);

                if (txtMesEmp.Text.Trim() != "")
                    int.TryParse(txtMesEmp.Text, out Emes);

                if (mskFechaNac.Text.Length == 10)
                {
                    try
                    {
                        fechaN = string.Format("{0:yyyy-MM-dd}", DateTime.Parse(mskFechaNac.Text));
                    }
                    catch (Exception w)
                    {
                        if (w.Source != null)
                        {
                            MessageBox.Show("Escriba una fecha valida");
                            mskFechaNac.Text = "";
                        }
                    }
                }
                else
                {
                    mskFechaNac.Text = "";
                    fechaN = "";
                }
            }
            catch (Exception dd)
            {
                if (dd.Source != null)
                    MessageBox.Show("error en CteExpress.cs-ActualizaCte(). " + dd.Message);
            }


            //fechaN = String.Format("{0:yyyy-MM-dd}", DateTime.Parse(mskFechaNac.Text));
            //CapturaCte cte = new CapturaCte();
            //cte.UpdateCliente(LinConex, Estacion, IDcte, Usuario, Prospecto, txtNom.Text, cmbRegimen.Text, txtApePat.Text, txtApeMat.Text, txtApePat.Text + " " + txtApeMat.Text + " " + txtNom.Text, fechaN, cmbTipoCalle.Text, txtDir.Text, txtNumExt.Text, txtNumInt.Text, txtEntreC.Text, txtColCte.Text, txtCpCte.Text, txtDelCte.Text, txtPobCte.Text, txtEstCte.Text, txtPaisCte.Text, cmbViveCalCte.Text, 0.0, 99, txtRfc.Text, cmbSex.Text, cmbEdoCivil.Text, 0, Categoria, Convert.ToString(Canal), txtNomina.Text, txtPuestoN.Text, txtRfcInst.Text, txtEmail.Text, txtRecPor.Text, txtCveInst.Text, txtCargoN.Text, txtMpioN.Text, "", "MAVI", Estacion, Sucursal, cmbLiveCon.Text, cmbKeLiveEnC.Text, cmbParent.Text, txtDirRe.Text, txtEmiCom1.Text, txtTarjCom1.Text, txtEmiCom2.Text, txtTarjBan2.Text, txtEmiBan1.Text, txtTarjBan1.Text, txtEmiBan2.Text, txtTarjBan2.Text, txtEmiBan3.Text, txtTarjBan3.Text, txtTiempo.Text, cmes, cyear, cmbTipoCalleAnt.Text, txtDirAnt.Text, txtNumExtAnt.Text, txtNumIntAnt.Text, txtEntreCAnt.Text, txtColCteAnt.Text, txtCpCteAnt.Text, txtDelCteAnt.Text, txtPobCteAnt.Text, txtEstCteAnt.Text, txtPaisCteAnt.Text, txtEmpCte.Text, txtFunEmpCte.Text, txtDepEmpCte.Text, Emes, Eyear, txtJefe.Text, txtPstoJefe.Text, ingreso, cmbPerIngreso.Text, Compr, cmbTipCalleE.Text, txtDirEmp.Text, txtNumExtEmp.Text, txtNumIntEmp.Text, txtEntCalleE.Text, txtColEmp.Text, txtCpEmp.Text, txtDelEmp.Text, txtEstEmp.Text, txtPaisEmp.Text, txtEmpAnt.Text, cmbTipCalleEmpA.Text, txtDirAntE.Text, txtNumExtAnt.Text, txtNumIntAnt.Text, txtEntreCAnt.Text, txtColEmpA.Text, txtCpEmpA.Text, txtDelEmpA.Text, txtEstEmpA.Text, txtPaisEmpA.Text, cmbTipEmp.Text, esCredExpress,TipoCaptura);
        }

        //-----------------------------------------------------------------------------------------------
        private string verificaDatosCte()
        {
            string DatosCte = "", fechaAux = "";
            double Ingreso = 0.0;

            if (txtIngreso.Text.Trim() != "")
                Ingreso = Convert.ToDouble(txtIngreso.Text);
            //fechaAux = mskFechaNac.Text;

            if (mskFechaNac.Text.Length == 10)
            {
                try
                {
                    fechaAux = string.Format("{0:yyyy-MM-dd}", DateTime.Parse(mskFechaNac.Text));
                }
                catch (Exception w)
                {
                    if (w.Source != null)
                    {
                        MessageBox.Show("Escriba una fecha valida");
                        mskFechaNac.Text = "";
                    }
                }
            }
            else
            {
                mskFechaNac.Text = "";
                fechaAux = "";
            }
            //CapturaCte cte = new CapturaCte();

            //DatosCte = cte.ValidaDatosCliente(LinConex, Prospecto, Categoria, cmbRegimen.Text, cmbSex.Text, fechaAux, txtApePat.Text + " " + txtApeMat.Text + " " + txtNom.Text, txtApePat.Text, txtApeMat.Text, txtNom.Text, cmbTipoCalle.Text, txtDir.Text, txtNumExt.Text, txtEntreC.Text, txtColCte.Text, txtCpCte.Text, txtDelCte.Text, txtEstCte.Text, txtPaisCte.Text, cmbViveCalCte.Text, cmbLiveCon.Text, cmbKeLiveEnC.Text, "", "", txtRfc.Text, cmbEdoCivil.Text, 00, "", txtRecPor.Text, cmbParent.Text, txtDirRe.Text, cmbTipoCalleAnt.Text, txtDirAnt.Text, txtNumExtAnt.Text, txtEntreCAnt.Text, txtColCteAnt.Text, txtCpCteAnt.Text, txtDelCteAnt.Text, txtEstCteAnt.Text, txtPaisCteAnt.Text, txtEmpCte.Text, Convert.ToString(txtCtrlYear.Text), Convert.ToString(txtCtrlMes.Text), 0.0, Convert.ToString(txtYearDomA.Text), Convert.ToString(txtMesDirAnt.Text), Convert.ToString(txtYearEmp.Text), Convert.ToString(txtMesEmp.Text), Ingreso, cmbPerIngreso.Text, txtDirEmp.Text, txtNumExtEmp.Text, cmbTipCalleE.Text, txtColEmp.Text, txtEmpAnt.Text, txtDirAntE.Text, txtExtEmpA.Text, cmbTipCalleEmpA.Text, txtColEmpA.Text, txtTiempo.Text, cmbTipEmp.Text);

            if (Categoria == "CREDITO MENUDEO" && TipoCaptura == 8) DatosCte = "ok";

            //MessageBox.Show("datos generales: " + DatosCte);
            if (DatosCte != "ok")
                MessageBox.Show(DatosCte);
            return DatosCte;
        }

        //------------------------------------------------------------------------------------------------
        private string verificaDatosNominales()
        {
            string Nominales = "";
            try
            {
                if (txtNomina.Text.Trim() == "" || txtConfNomina.Text.Trim() == "" || txtPuestoN.Text.Trim() == "" ||
                    txtCveInst.Text.Trim() == "" || txtCargoN.Text.Trim() == "" || txtMpioN.Text.Trim() == "" ||
                    txtRfcInst.Text.Trim() == "")
                {
                    Nominales = "Falta capturar Datos Nominales";
                    MessageBox.Show(Nominales);
                }
                else
                {
                    if (txtNomina.Text.Trim() != "" && txtPuestoN.Text.Trim() != "")
                    {
                        if (txtNomina.Text != txtConfNomina.Text)
                        {
                            Nominales = "la nomina no concide con la confirmacion";
                            MessageBox.Show(Nominales);
                        }
                        else
                        {
                            Nominales = "ok";
                            //MessageBox.Show("nominales: " + Nominales);
                        }
                    }
                    else
                    {
                        Nominales = "los campos Nomina y Puesto son obligatorios(datos nominales)";
                        MessageBox.Show(Nominales);
                    }
                }
            }
            catch (Exception ss)
            {
                MessageBox.Show("error en CteExpress.cs-verificaDatosNominales(). " + ss.Message);
            }

            return Nominales;
        }

        //----------------------------------------------------------------------------------------------
        private string verificaTelefonos()
        {
            int countTel, cuantos = 1;
            string Tipo, Lada, Telefono, tel = "";
            countTel = dgvTelefono.RowCount;
            try
            {
                if (countTel == 0)
                {
                    tel = "Capturar telefono";
                    MessageBox.Show(tel);
                }
                else
                {
                    for (int x = 0; x < dgvTelefono.RowCount; x++)
                    {
                        Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
                        Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
                        Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);

                        if (Lada.Length + Telefono.Length < 10 || Lada.Length + Telefono.Length > 10)
                        {
                            tel = "Favor de verificar los telefono, no cumple los requisitos";
                            MessageBox.Show(tel);
                            break;
                        }

                        if (string.IsNullOrEmpty(Tipo.Trim()) || string.IsNullOrEmpty(Lada.Trim()) ||
                            string.IsNullOrEmpty(Telefono.Trim()))
                        {
                            tel = "Al telefono " + Convert.ToString(cuantos) + ": le falta capturar datos";
                            MessageBox.Show(tel);
                            break;
                        }

                        if (verificaRepetidos(Telefono))
                        {
                            tel = "tiene capturado telefonos repetidos";
                            MessageBox.Show(tel);
                            break;
                        }

                        if (verificaCelular() == false)
                        {
                            tel = "es obligatorio capturar al menos un numero tipo Movil";
                            MessageBox.Show(tel);
                            break;
                        }

                        if (verificaFijo() == false)
                        {
                            tel = "es obligatorio capturar un numero tipo Particular";
                            MessageBox.Show(tel);
                            break;
                        }
                        //else if (countTel < 2)
                        //{
                        //    tel = "tiene que capturar al menos 2 telefonos";
                        //    MessageBox.Show(tel);
                        //    break;
                        //}

                        tel = "ok";

                        cuantos += 1;
                    }
                    //MessageBox.Show("telefono: " + tel);
                }
            }
            catch (Exception ee)
            {
                if (ee.Source != null)
                    MessageBox.Show("error en CteExpress.cs-verificaTelefonos(). " + ee.Message);
            }

            return tel;
        }

        //------------------------------------------------------------------------------------------------
        private bool verificaRepetidos(string tel)
        {
            bool existe = false;
            int cont = 0;

            foreach (DataGridViewRow row in dgvTelefono.Rows)
            {
                string verifica = Convert.ToString(row.Cells[3].Value);
                if (tel == verifica)
                {
                    cont += 1;
                    if (cont > 1) // por que tel se va a encotrar a si mismo si se encuentra una segunda vez esta repetido
                    {
                        existe = true;
                        break;
                    }
                }
            }

            return existe;
        }

        //------------------------------------------------------------------------------------------------
        private bool verificaCelular()
        {
            bool existe = false;

            foreach (DataGridViewRow row in dgvTelefono.Rows)
            {
                string verifica = Convert.ToString(row.Cells[1].Value);
                if (verifica == "Movil")
                {
                    existe = true;
                    break;
                }
            }

            return existe;
        }

        //------------------------------------------------------------------------------------------------
        private bool verificaFijo()
        {
            bool existe = false;

            foreach (DataGridViewRow row in dgvTelefono.Rows)
            {
                string verifica = Convert.ToString(row.Cells[1].Value);
                if (verifica == "Particular")
                {
                    existe = true;
                    break;
                }
            }

            return existe;
        }

        //------------------------------------------------------------------------------------------------
        private void txtNom_TextChanged(object sender, EventArgs e)
        {
            modificarRFC();
        }

        //--------------------------------------------------------------------------------------------
        private void txtApePat_TextChanged(object sender, EventArgs e)
        {
            modificarRFC();
        }

        //--------------------------------------------------------------------------------------------
        private void txtApeMat_TextChanged(object sender, EventArgs e)
        {
            modificarRFC();
        }

        //--------------------------------------------------------------------------------------------
        private void modificarRFC()
        {
            string fechaAux = "";
            if (mskFechaNac.Text.Length == 10)
            {
                try
                {
                    fechaAux = string.Format("{0:yyyy-MM-dd}", DateTime.Parse(mskFechaNac.Text));
                }
                catch (Exception w)
                {
                    if (w.Source != null)
                    {
                        MessageBox.Show("Escriba una fecha valida");
                        mskFechaNac.Text = "";
                    }
                }
            }
            else
            {
                mskFechaNac.Text = "";
                fechaAux = "";
            }

            if (cmbRegimen.Text == "Persona Fisica" && fechaAux != "" && txtNom.Text != "" && txtApeMat.Text != "" &&
                txtNom.Text.Length > 2)
            {
                //Consultas Con = new Consultas();
                txtRfc.Text = "";
                txtRfcInst.Text = "";
                //txtRfc.Text = Con.SetRFC("RFC", "", txtNom.Text, txtApePat.Text, txtApeMat.Text, fechaAux, LinConex);
                txtRfcInst.Text = txtRfc.Text;
            }
        }

        //--------------------------------------------------------------------------------------------
        private void dgvTelefono_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int cLada = 0, cTel = 0;
            string headertext = dgvTelefono.Columns[e.ColumnIndex].HeaderText;
            if (!headertext.Equals("Lada") && !headertext.Equals("Telefono"))
                return;

            cLada = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value).Length;
            cTel = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[3].Value).Length;

            dgvTelefono.Rows[e.RowIndex].ErrorText = string.Empty;
            if (headertext.Equals("Lada") && string.IsNullOrEmpty(e.FormattedValue.ToString()))
                dgvTelefono.Rows[e.RowIndex].ErrorText = "el campo lada esta vacio";
            else if (headertext.Equals("Telefono") && string.IsNullOrEmpty(e.FormattedValue.ToString()))
                dgvTelefono.Rows[e.RowIndex].ErrorText = "el campo telefono esta vacio";
        }

        //--------------------------------------------------------------------------------------------
        private void dgvTelefono_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int charLada, charTel;

            string charTipo = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value);
            if (Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value).Length > 3)
            {
                dgvTelefono.Rows[e.RowIndex].ErrorText = "el campo lada rebaso el maximo de 3 digitos";
                MessageBox.Show("el campo lada rebaso el maximo de 3 digitos");
                dgvTelefono.Rows[e.RowIndex].Cells[2].Value = "";
                return;
            }

            charLada = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value).Length;
            charTel = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[3].Value).Length;
            if (charLada + charTel > 10)
            {
                //dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                dgvTelefono.Rows[e.RowIndex].ErrorText = "la lada junto con el telefono rebaso los 10 digitos";
                MessageBox.Show("la lada junto con el telefono rebaso los 10 digitos");
                return;
            }

            if (charLada > 0 && charTel > 0)
            {
                string lada1 = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value);
                string telefono1 = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[3].Value);
                string real1 = lada1 + telefono1;
                if (charLada + charTel < 10)
                {
                    dgvTelefono.Rows[e.RowIndex].ErrorText = "la lada junto con el telefono no son los 10 digitos";
                    MessageBox.Show("la lada junto con el telefono no son los 10 digitos");
                }

                if (real1 == "123456789" || real1 == "987654321" || telefono1 == "12345678" ||
                    telefono1 == "87654321" || telefono1 == "7654321" || telefono1 == "1234567" ||
                    telefono1 == "23456789" || telefono1 == "98765432")
                {
                    dgvTelefono.Rows[e.RowIndex].ErrorText = "el telefono no puede ser descendente ó ascendente";
                    MessageBox.Show("el telefono no puede ser decendente ó acendente");
                    dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                    dgvTelefono.Rows[e.RowIndex].Cells[2].Value = "";
                }
            }

            if (charTel == 10)
            {
                dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                dgvTelefono.Rows[e.RowIndex].ErrorText = "el telefono no puede tener los 10 digitos maximos";
                MessageBox.Show("el telefono no puede tener los 10 digitos maximos");
                return;
            }

            if (charLada + charTel == 10)
            {
                string lada = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[2].Value);
                string telefono = Convert.ToString(dgvTelefono.Rows[e.RowIndex].Cells[3].Value);
                if (validaDIgitosTel(telefono))
                {
                    dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                    dgvTelefono.Rows[e.RowIndex].ErrorText = "no se permiten capturar numeros con digitos iguales";
                    MessageBox.Show("no se permiten capturar numero con digitos iguales");
                    return;
                }

                if (!validaDIgitos(lada + telefono)) return;

                string real = lada + telefono;
                if (real == "0123456789" || real == "9876543210" || telefono == "12345678" || telefono == "87654321" ||
                    telefono == "7654321" || telefono == "1234567" || telefono == "23456789" || telefono == "98765432")
                {
                    dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                    dgvTelefono.Rows[e.RowIndex].Cells[2].Value = "";
                    dgvTelefono.Rows[e.RowIndex].ErrorText = "el telefono no puede ser decendente ó acendente";
                    MessageBox.Show("el telefono no puede ser decendente ó acendente");
                    return;
                }

                if (validaDIgitos(real))
                {
                    dgvTelefono.Rows[e.RowIndex].Cells[3].Value = "";
                    dgvTelefono.Rows[e.RowIndex].ErrorText = "no se permiten capturar numeros con digitos iguales";
                    MessageBox.Show("no se permiten capturar numero con digitos iguales");
                }
            }
        }

        //--------------------------------------------------------------------------------------------
        public bool validaDIgitosTel(string d)
        {
            bool repetido = false;
            if (d.Count() == 8)
                switch (d)
                {
                    case "11111111":
                        repetido = true;
                        break;
                    case "22222222":
                        repetido = true;
                        break;
                    case "33333333":
                        repetido = true;
                        break;
                    case "44444444":
                        repetido = true;
                        break;
                    case "55555555":
                        repetido = true;
                        break;
                    case "66666666":
                        repetido = true;
                        break;
                    case "77777777":
                        repetido = true;
                        break;
                    case "88888888":
                        repetido = true;
                        break;
                    case "99999999":
                        repetido = true;
                        break;
                }

            if (d.Count() == 7)
                switch (d)
                {
                    case "1111111":
                        repetido = true;
                        break;
                    case "2222222":
                        repetido = true;
                        break;
                    case "3333333":
                        repetido = true;
                        break;
                    case "4444444":
                        repetido = true;
                        break;
                    case "5555555":
                        repetido = true;
                        break;
                    case "6666666":
                        repetido = true;
                        break;
                    case "7777777":
                        repetido = true;
                        break;
                    case "8888888":
                        repetido = true;
                        break;
                    case "9999999":
                        repetido = true;
                        break;
                }

            return repetido;
        }

        //--------------------------------------------------------------------------------------------
        public bool validaDIgitos(string d)
        {
            bool repetido = false;
            switch (d)
            {
                case "1111111111":
                    repetido = true;
                    break;
                case "2222222222":
                    repetido = true;
                    break;
                case "3333333333":
                    repetido = true;
                    break;
                case "4444444444":
                    repetido = true;
                    break;
                case "5555555555":
                    repetido = true;
                    break;
                case "6666666666":
                    repetido = true;
                    break;
                case "7777777777":
                    repetido = true;
                    break;
                case "8888888888":
                    repetido = true;
                    break;
                case "9999999999":
                    repetido = true;
                    break;
            }

            return repetido;
        }

        //--------------------------------------------------------------------------------------------     
        private void btnSalir_Click(object sender, EventArgs e)
        {
            //DialogResult rs = MessageBox.Show("Desea Salir sin guardar", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //if (rs == DialogResult.Yes)
            //{
            //    CapturaCte cap = new CapturaCte();
            //    cap.Cancelar(LinConex, Prospecto);
            //    cap.AlcerrarForm(LinConex, Prospecto);

            //    CapturaCte cte = new CapturaCte();
            //    cte.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Borrar", 0, 0);
            Close();
            //}
        }

        //----------------------------------------------------------------------------------------------
        private void txtNumExt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //--------------------------------------------------------------------------------------------
        private void btnTelefonos_Click(object sender, EventArgs e)
        {
            if (Categoria == "INSTITUCIONES" || Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            {
                grboxCaps.Location = new Point(10, grbRef.Location.Y);
                grbTelefono.Focus();
            }
        }

        //--------------------------------------------------------------------------------------------
        private void button1_Click(object sender, EventArgs e)
        {
            //string Tipo, Lada, Telefono;
            int countTel;
            countTel = dgvTelefono.RowCount;
            //if (Categoria == "INSTITUCIONES")
            //{
            //    if (verificaDatosCte() == "ok" && verificaTelefonos() == "ok" && verificaDatosNominales() == "ok")
            //    {
            //        ActualizaCte();
            //        CapturaCte imp = new CapturaCte();
            //        imp.GuardaDatNomi(txtNomina.Text, Prospecto, txtPuestoN.Text, txtRfcInst.Text, txtCveInst.Text, txtCargoN.Text, txtMpioN.Text, LinConex);
            //        imp.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            imp.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        //imp.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza",1);
            //        imp.generarDatosRep(Prospecto);
            //    }
            //}
            //if (Categoria == "CREDITO MENUDEO" || Categoria == "ASOCIADOS")
            //{
            //    if (verificaDatosCte() == "ok" && verificaTelefonos() == "ok")
            //    {
            //        ActualizaCte();
            //        CapturaCte imp = new CapturaCte();
            //        imp.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            imp.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        //imp.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza", 1);
            //        imp.generarDatosRep(Prospecto);
            //    }
            //}

            //if (Categoria == "CONTADO")
            //{
            //    if (verificaDatosCte() == "ok" && verificaTelefonos() == "ok")
            //    {
            //        ActualizaCte();
            //        CapturaCte imp = new CapturaCte();
            //        imp.BorraTel(Prospecto, LinConex);

            //        for (int x = 0; x < dgvTelefono.RowCount; x++)
            //        {
            //            Tipo = Convert.ToString(dgvTelefono.Rows[x].Cells[1].Value);
            //            Lada = Convert.ToString(dgvTelefono.Rows[x].Cells[2].Value);
            //            Telefono = Convert.ToString(dgvTelefono.Rows[x].Cells[3].Value);
            //            imp.GrabarTel(Prospecto, Tipo, Lada, Telefono, LinConex);
            //        }
            //        //imp.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Actualiza", 1);
            //        imp.generarDatosRep(Prospecto);
            //    }
            //}
        }

        //--------------------------------------------------------------------------------------------       

        private void btnGoogle_Click(object sender, EventArgs e)
        {
            //CapturaCte setUen = new CapturaCte();
            //string UEN = setUen.SetUEN(LinConex, Convert.ToString(Canal));

            //if (txtDir.Text.Trim() != "" && txtNumExt.Text.Trim() != "" && txtColCte.Text.Trim() != "" && txtDelCte.Text.Trim() != "" && txtEstCte.Text.Trim() != "")
            //{

            //    try
            //    {

            //        System.Diagnostics.Process.Start("http://172.16.202.5/gmaps?__VIEWSTATE=%2FwEPDwULLTE2NzUwNjg0ODdkZLnalVODlvd%2FSmkRTbRzVWl3mlo4otUgAP1Gm4SHJeK8&__EVENTVALIDATION=%2FwEdAAe546fVgDc7yWxVkpY4cOg13X1BS8z8T5NYyBgKqKGbUBlgPQJeBXgHtgTdhtGNhIPMrVLLRo%2B1TPjfRjlP4KmTaTAZY8ILtUSo1IbEW6je7q30zknFlnPyG7cQ%2BBM0xUWjC58LLxcpNQhfGIAsTYUV06jk8XjwmB%2FR1i8mH9Cc3inFVjCmX5W9lDhi%2BSY9d%2Bo%3D&busqueda_auto=" + txtDelCte.Text + " " + txtEstCte.Text + ", " + txtDir.Text + " " + txtNumExt.Text + ", " + txtColCte.Text + "&Latitud=&Prospecto=" + Prospecto + "&Contacto=0" + "&uen=" + UEN + "&btn_guardar=Guardar");

            //    }
            //    catch (Exception w)
            //    {
            //        string mensaje = w.Message;
            //    }

            //}
            //else
            //    MessageBox.Show("Los campos Direccion,NumeroExteriror,Colonia,Delegacion y Estado deben tener datos");
        }

        private void txtCanal_TextChanged(object sender, EventArgs e)
        {
        }

        //--------------------------------------------------------------------------------------------
        private void cmbTipoCalle_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEntreC.Focus();
        }

        private void cmbLiveCon_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbKeLiveEnC.Focus();
        }

        private void cmbKeLiveEnC_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDirAnt.Focus();
        }

        private void cmbTipoCalleAnt_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEntreCAnt.Focus();
        }

        private void cmbTipCalleEmpA_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEntCalleEa.Focus();
        }

        private void cmbParent_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbParent.Text == "CONYUGE")
            //{
            //    string[] datos;

            //    CapturaCte cap = new CapturaCte();
            //    if (txtRecPor.Text.Trim() != "" && IdCtoRecConyu == 0)
            //    {

            //        IdCtoRecConyu = cap.ConyugeRecomienda(LinConex, txtRecPor.Text, Prospecto, "Genera");
            //        if (IdCtoRecConyu > 0)
            //        {
            //            int rows = dgvCto.Rows.Count;
            //            string antTipo;

            //            for (int x = 0; x < rows; x++) //solo funciona para cuando actualizan un contacto
            //            {
            //                antTipo = Convert.ToString(dgvCto.Rows[x].Cells["Tipo"].Value);
            //                if (antTipo == "CONYUGE")
            //                {
            //                    dgvCto.Rows.RemoveAt(x);
            //                    break;
            //                }

            //            }

            //            datos = cap.DatosAvalReco(LinConex, Prospecto, IdCtoRecConyu).ToArray();
            //            dgvCto.Rows.Add(datos[0], datos[1], datos[2], datos[3], datos[4], datos[5], datos[6], datos[7], datos[8], datos[9], datos[10], datos[11], datos[12], datos[13], datos[14], datos[15]);
            //        }

            //    }
            //}

            //if (cmbParent.Text == "CONYUGE")
            //{
            //    int rows = dgvCto.Rows.Count;
            //    string antTipo;
            //    int idAnt = 0;

            //    for (int x = 0; x < rows; x++) //solo funciona para cuando actualizan un contacto
            //    {
            //        antTipo = Convert.ToString(dgvCto.Rows[x].Cells["Tipo"].Value);
            //        if (antTipo == "CONYUGE DEL AVAL")
            //        {
            //            idAnt = Convert.ToInt32(dgvCto.Rows[x].Cells["idCto"].Value);
            //            //eliminaCtoRecomendado(idAnt);
            //            //dgvCto.Rows.RemoveAt(x);
            //            break;
            //        }

            //    }
            //}

            //if (cmbParent.Text != "CONYUGE")
            //{
            //    if (IdCtoRecConyu > 0)
            //    {
            //        DialogResult r = MessageBox.Show("Desea eliminar el contacto Conyuge generado en recomendado por ?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //        if (r == DialogResult.Yes)
            //        {
            //            eliminaCtoRecConyu();
            //        }
            //        else
            //            cmbParent.SelectedItem = "CONYUGE";

            //    }

            //}
            txtDirRe.Focus();
        }

        //-------------------------------------------------------------------------------------------------------------------
        private void txtCtrlYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //-----------------------------------------------------------------------------------------------------------------------
        private void txtCtrlMes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //---------------------------------------------------------------------------------------------------------------------------
        private void txtCtrlYear_TextChanged(object sender, EventArgs e)
        {
            int year;
            year = 0;

            if (txtCtrlYear.Text == "0")
                txtCtrlYear.Text = "";

            if (txtCtrlYear.Text != "")
                year = int.Parse(txtCtrlYear.Text);
            else
                year = 0;

            IEnumerable<TextBox> text = grBoxDomAnt.Controls.OfType<TextBox>();
            IEnumerable<ComboBox> combo = grBoxDomAnt.Controls.OfType<ComboBox>();
            IEnumerable<NumericUpDown> numUpDown = grBoxDomAnt.Controls.OfType<NumericUpDown>();


            if (year > 0) grBoxDomAnt.Visible = false;
            if (year == 0)
                if (Categoria != "CREDITO EXTERNO" && Categoria != "CONTADO")
                {
                    grBoxDomAnt.Visible = true;
                    foreach (TextBox tx in text) tx.Clear();
                    foreach (ComboBox cm in combo)
                    {
                        cm.Items.Remove("");
                        cm.Items.Add("");
                        cm.SelectedItem = "";
                    }
                }
        }

        //-----------------------------------------------------------------------------------------------------------------------
        private void txtCtrlMes_TextChanged(object sender, EventArgs e)
        {
            int textCont = 0;

            if (txtCtrlMes.Text == "0")
            {
                txtCtrlMes.Text = "";
                textCont = 0;
            }
            else
            {
                int.TryParse(txtCtrlMes.Text, out textCont);
            }

            if (textCont > 12)
                //int year;
                //int mes;
                //year = int.Parse(txtCtrlMes.Text) / 12;
                //mes = int.Parse(txtCtrlMes.Text) - (12 * year);
                //txtCtrlMes.Text = Convert.ToString(mes);
                //txtCtrlYear.Text = Convert.ToString(year);
                txtCtrlMes.Text = "";
        }

        //------------------------------------------------------------------------------------------------------------------------
        private void dtpFechNac_ValueChanged(object sender, EventArgs e)
        {
            //txtFechaN.Text = dtpFechNac.Text;
        }

        private void txtMesDirAnt_TextChanged(object sender, EventArgs e)
        {
            CambioMesYear1(txtYearDomA, txtMesDirAnt);
        }

        //-----------------------------------------------------------------------------------------------------------------------
        private void txtYearDomA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //-------------------------------------------------------------------------------------------------------------------------
        private void txtMesDirAnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //------------------------------------------------------------------------------------------------------------------------
        private void CambioMesYear1(TextBox year, TextBox mes)
        {
            int textCont = 0;

            if (mes.Text == "0")
            {
                mes.Text = "";
                textCont = 0;
            }
            else
            {
                int.TryParse(mes.Text, out textCont);
            }

            if (textCont > 12) mes.Text = "";
        }

        //------------------------------------------------------------------------------------------------------------------------
        private void txtMesEmp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //------------------------------------------------------------------------------------------------------------------------
        private void txtYearEmp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
                e.Handled = true;
            else if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        //-------------------------------------------------------------------------------------------------------------------------
        private void txtMesEmp_TextChanged(object sender, EventArgs e)
        {
            CambioMesYear1(txtYearEmp, txtMesEmp);
        }

        //-------------------------------------------------------------------------------------------------------------------------
        private void CteExpress_FormClosing(object sender, FormClosingEventArgs e)
        {
            //switch (e.CloseReason)
            //{
            //    case CloseReason.UserClosing:
            //        if (bandera == 0)
            //        {
            //            CapturaCte cap = new CapturaCte();
            //            cap.Cancelar(LinConex, Prospecto);
            //            cap.AlcerrarForm(LinConex, Prospecto);

            //            CapturaCte cte = new CapturaCte();
            //            cte.registraProspecto(LinConex, Usuario, Prospecto, Estacion, "Borrar", 0, 0);
            //        }

            //        break;
            //}
        }

        //------------------------------------------------------------------------------------------------------------------
        private void chbPresent_CheckedChanged(object sender, EventArgs e)
        {
            if (chbPresent.Checked)
            {
                eliminaCtoRecomendado(IdCtoRecomen);
                eliminaCtoRecomendado(idCtoCouyuA);
                IdCtoRecomen = 0;
            }
        }

        //-------------------------------------------------------------------------------------------------------
        private void eliminaCtoRecomendado(int id)
        {
            int ok = 0;
            //exist = 0;
            int rows = 0;
            string EsAval = "";
            //EsConyA = "";
            //CapturaCte cap = new CapturaCte();


            //ok = cap.BorraAvalRecomienda(LinConex, Prospecto, id, "Elimina");
            rows = dgvCto.Rows.Count;

            int antID;

            for (int x = 0; x < rows; x++)
            {
                antID = Convert.ToInt32(dgvCto.Rows[x].Cells["idCto"].Value);
                if (antID == id)
                {
                    EsAval = Convert.ToString(dgvCto.Rows[x].Cells["tipo"].Value);
                    dgvCto.Rows.RemoveAt(x);

                    break;
                }
            }

            if (ok == 0 && EsAval == "AVAL")
            {
                IdCtoRecomen = 0;
                //chbPresent.Checked = false;
                MessageBox.Show("contacto Aval eliminado");
            }
            //rows = dgvCto.Rows.Count;
            //if (EsAval == "AVAL")
            //{
            //    for (int y = 0; y < rows; y++) 
            //    {
            //        EsConyA = Convert.ToString(dgvCto.Rows[y].Cells["tipo"].Value);
            //        antID = Convert.ToInt32(dgvCto.Rows[y].Cells["idCto"].Value);
            //        if (EsConyA == "CONYUGE DEL AVAL")
            //        {
            //            dgvCto.Rows.RemoveAt(y);
            //            exist = cap.BorraAvalRecomienda(LinConex, Prospecto, antID, "Elimina");
            //            break;
            //        }

            //    }
            //}
        }

        //-------------------------------------------------------------------------------------------------------
        private void eliminaCtoRecConyu()
        {
            int ok = 1;
            //CapturaCte cap = new CapturaCte();


            //ok = cap.BorraConyuRecomienda(LinConex, Prospecto, IdCtoRecConyu, "Elimina");
            int rows = dgvCto.Rows.Count;
            int antID;

            for (int x = 0; x < rows; x++) //solo funciona para cuando actualizan un contacto
            {
                antID = Convert.ToInt32(dgvCto.Rows[x].Cells["idCto"].Value);
                if (antID == IdCtoRecConyu)
                {
                    dgvCto.Rows.RemoveAt(x);
                    break;
                }
            }

            if (ok == 0 && IdCtoRecConyu > 0)
            {
                IdCtoRecConyu = 0;
                cmbParent.SelectedItem = "";
                MessageBox.Show("contacto Conyuge eliminado en recomendado por");
            }
        }

        //-------------------------------------------------------------------------------------------
        private void txtRecPor_TextChanged(object sender, EventArgs e)
        {
            // List<string> datos = new List<string>();
            //string[] datos;
            //string[] datos1;
            //CapturaCte cap = new CapturaCte();

            //if (txtRecPor.Text.Trim() != "" && Recomendado != txtRecPor.Text && IdCtoRecomen > 0)
            //{
            //    if (txtRecPor.Text.Trim() != "" && IdCtoRecomen > 0)
            //    {
            //        if (IdCtoRecomen > 0)
            //        {
            //            DialogResult r = MessageBox.Show("Desea eliminar el contacto generado en recomendado por ?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //            if (r == DialogResult.Yes)
            //            {
            //                eliminaCtoRecomendado(IdCtoRecomen);
            //                eliminaCtoRecomendado(idCtoCouyuA);
            //            }
            //            else
            //                 txtRecPor.Text = Recomendado ;

            //        }
            //    }
            //}

            if (txtRecPor.Text.Trim() != "" && IdCtoRecomen == 0)
            {
                //IdCtoRecomen = cap.AvalRecomienda(LinConex, txtRecPor.Text.Trim(), Prospecto, "Genera");
                //idCtoCouyuA = cap.AvalConyuRecomienda(LinConex, txtRecPor.Text.Trim(), Prospecto, "Genera"); // le genera el contacto conyuge del aval
                //if (IdCtoRecomen > 0)
                //{
                //    int rows = dgvCto.Rows.Count;
                //    string tipo;
                //    int id = 0;
                //    Recomendado = txtRecPor.Text;
                //    for (int x = 0; x < rows; x++)
                //    {
                //        tipo = Convert.ToString(dgvCto.Rows[x].Cells["tipo"].Value);
                //        id = Convert.ToInt32(dgvCto.Rows[x].Cells["idCto"].Value);
                //        if (tipo == "AVAL")
                //        {
                //            int exist = cap.BorraAvalRecomienda(LinConex, Prospecto, id, "Elimina");
                //            dgvCto.Rows.RemoveAt(x);
                //            break;
                //        }
                //    }
                //    datos = cap.DatosAvalReco(LinConex, Prospecto, IdCtoRecomen).ToArray();
                //    dgvCto.Rows.Add(datos[0], datos[1], datos[2], datos[3], datos[4], datos[5], datos[6], datos[7], datos[8], datos[9], datos[10], datos[11], datos[12], datos[13], datos[14], datos[15]);

                //    if (idCtoCouyuA > 0)
                //    {
                //        datos1 = cap.DatosAvalReco(LinConex, Prospecto, idCtoCouyuA).ToArray();
                //        dgvCto.Rows.Add(datos1[0], datos1[1], datos1[2], datos1[3], datos1[4], datos1[5], datos1[6], datos1[7], datos1[8], datos1[9], datos1[10], datos1[11], datos1[12], datos1[13], datos1[14], datos1[15]);
                //    }

                //    MessageBox.Show("!Contacto Creado con exito!");
                //    chbPresent.Checked = false;
                //}
            }
            //else
            //{
            //    if (cmbRegimen.Text.Trim() != "" && txtRecPor.Text.Trim() == "" && chbPresent.Checked == true)
            //        {
            //            CapturaCto cto = new CapturaCto(Canal, Sucursal, Prospecto, Categoria, cmbRegimen.Text, Respuesta1, Usuario, "");
            //            cto.Show(this);
            //        }                                 
            //}
        }

        private void cmbTipEmp_SelectedIndexChanged(object sender, EventArgs e)
        {
            IEnumerable<TextBox> text = grbEmpCte.Controls.OfType<TextBox>();
            IEnumerable<ComboBox> combo = grbEmpCte.Controls.OfType<ComboBox>();
            IEnumerable<CheckBox> chk = grbEmpCte.Controls.OfType<CheckBox>();

            IEnumerable<TextBox> text1 = grboxDirEmpleo.Controls.OfType<TextBox>();
            IEnumerable<ComboBox> combo1 = grboxDirEmpleo.Controls.OfType<ComboBox>();
            IEnumerable<CheckBox> chk1 = grboxDirEmpleo.Controls.OfType<CheckBox>();

            IEnumerable<TextBox> text2 = grboxDirEmpA.Controls.OfType<TextBox>();
            IEnumerable<ComboBox> combo2 = grboxDirEmpA.Controls.OfType<ComboBox>();
            IEnumerable<CheckBox> chk2 = grboxDirEmpA.Controls.OfType<CheckBox>();

            if (cmbTipEmp.Text == "AMA DE CASA" || cmbTipEmp.Text == "DESEMPLEADO")
            {
                foreach (TextBox tx in text)
                {
                    tx.Clear();
                    tx.ReadOnly = true;
                }

                foreach (TextBox tx in text1)
                {
                    tx.Clear();
                    tx.ReadOnly = true;
                }

                foreach (TextBox tx in text2)
                {
                    tx.Clear();
                    tx.ReadOnly = true;
                }

                foreach (ComboBox cm in combo)
                    if (cm.Name != "cmbTipEmp")
                    {
                        cm.Text = "";
                        cm.Enabled = false;
                    }

                foreach (ComboBox cm in combo1)
                    if (cm.Name != "cmbTipEmp")
                    {
                        cm.Text = "";
                        cm.Enabled = false;
                    }

                foreach (ComboBox cm in combo2)
                    if (cm.Name != "cmbTipEmp")
                    {
                        cm.Text = "";
                        cm.Enabled = false;
                    }

                foreach (CheckBox ch in chk)
                {
                    ch.Checked = false;
                    ch.Enabled = false;
                }

                foreach (CheckBox ch in chk1)
                {
                    ch.Checked = false;
                    ch.Enabled = false;
                }

                foreach (CheckBox ch in chk2)
                {
                    ch.Checked = false;
                    ch.Enabled = false;
                }
            }
            else
            {
                foreach (TextBox tx in text) tx.ReadOnly = false;

                foreach (TextBox tx in text1)
                    if (tx.Name != "txtColEmp" && tx.Name != "txtCpEmp" && tx.Name != "txtDelEmp" &&
                        tx.Name != "txtEstEmp" && tx.Name != "txtPobEmp" && tx.Name != "txtPaisEmp")
                        tx.ReadOnly = false;

                foreach (TextBox tx in text2)
                    if (tx.Name != "txtColEmpA" && tx.Name != "txtCpEmpA" && tx.Name != "txtDelEmpA" &&
                        tx.Name != "txtEstEmpA" && tx.Name != "txtPobEmpA" && tx.Name != "txtPaisEmpA")
                        tx.ReadOnly = false;

                foreach (ComboBox cm in combo)
                    if (cm.Name != "cmbTipEmp")
                        cm.Enabled = true;

                foreach (ComboBox cm in combo1)
                    if (cm.Name != "cmbTipEmp")
                        cm.Enabled = true;

                foreach (ComboBox cm in combo2)
                    if (cm.Name != "cmbTipEmp")
                        cm.Enabled = true;

                foreach (CheckBox ch in chk) ch.Enabled = true;
            }
        }

        private void lblTipEMp_Click(object sender, EventArgs e)
        {
        }

        private void btnBuscarDimR_Click(object sender, EventArgs e)
        {
            //ClienteExpress.DimaR.FRM_ClientesDIMA dima = new DimaR.FRM_ClientesDIMA();
            //dima.ShowDialog();

            //if (dima.condato == 1)
            //{
            //    txtCuentaDimr.Text = dima.cliente;
            //    txtDirecDimR.Text = dima.direccion;
            //    txtNomDimR.Text = dima.nombre;
            //}
        }

        private void btnBorrarDimR_Click(object sender, EventArgs e)
        {
            txtCuentaDimr.Text = "";
            txtNomDimR.Text = "";
            txtDirecDimR.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            contador = contador + 1;

            //if (contador == 1)
            //{
            //    if (Categoria == "CREDITO MENUDEO")
            //    {
            //        frmTipoCte tipo = new frmTipoCte();
            //        tipo.ShowDialog();
            //        cmbTipoCred.SelectedIndex = tipo.tipo;
            //        Consultas con = new Consultas();
            //        //con.PermiteDomRef(LinConex, tipo.idTipoCaptura);
            //        TipoCaptura = tipo.idTipoCaptura;
            //        if (con.PermiteDomRef(LinConex, tipo.idTipoCaptura) == 0)
            //        {
            //            esCredExpress = true;
            //        }
            //        else
            //        {
            //            esCredExpress = false;
            //        }

            //        if (con.PermiteCapCont(LinConex, tipo.idTipoCaptura) == 0)
            //        {
            //            grbContactos.Enabled = false;
            //        }
            //    }
            //    timer1.Stop();
            //}
        }

        private void cmbTipoCred_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idTipo = ((KeyValuePair<int, string>)cmbTipoCred.SelectedItem).Key;
            string value = ((KeyValuePair<int, string>)cmbTipoCred.SelectedItem).Value;
            NombreTipoCaptura = value;
            TipoCaptura = idTipo;
            //Consultas con = new Consultas();
            //con.PermiteDomRef(LinConex, tipo.idTipoCaptura);

            //txtTipdesc.Text = con.TipoDescrip(LinConex, idTipo);

            //if (con.PermiteDomRef(LinConex, idTipo) == 0)
            //{
            //    esCredExpress = true;
            //}
            //else
            //{
            //    esCredExpress = false;
            //}

            //if (con.PermiteCapCont(LinConex, idTipo) == 0)
            //{
            //    grbContactos.Enabled = false;
            //    con.eliminaCto(LinConex, Prospecto);
            //}
            //else
            //    grbContactos.Enabled = true;
        }

        private void cmbTipoCred_KeyPress(object sender, KeyPressEventArgs e)
        {
            int index;
            if (e.KeyChar == 78 || e.KeyChar == 110)
            {
                index = cmbTipoCred.FindString("Credito Normal");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 69 || e.KeyChar == 101)
            {
                index = cmbTipoCred.FindString("Credito Express");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 82 || e.KeyChar == 114)
            {
                index = cmbTipoCred.FindString("Credito Relacionado");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 68 || e.KeyChar == 100)
            {
                index = cmbTipoCred.FindString("Credito Relacionado con Diferente Domicilio");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 65 || e.KeyChar == 97)
            {
                index = cmbTipoCred.FindString("Credito Agil");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 67 || e.KeyChar == 99)
            {
                index = cmbTipoCred.FindString("Credito Agil  Calzado");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 77 || e.KeyChar == 109)
            {
                index = cmbTipoCred.FindString("Credito DIMA");
                cmbTipoCred.SelectedIndex = index;
            }

            if (e.KeyChar == 83 || e.KeyChar == 115)
            {
                index = cmbTipoCred.FindString("Credito Seguro Express");
                cmbTipoCred.SelectedIndex = index;
            }
        }

        //interfaz para pasar datos de un formulario hijo al padre 

        #region ICteExpress Members

        public void CargaTextBoxCte(string Col, string cp, string dele, string edo, string pais, string ActAnt)
        {
            if (ActAnt == "Act")
            {
                txtColCte.Text = Col;
                txtCpCte.Text = cp;
                txtDelCte.Text = dele;
                txtEstCte.Text = edo;
                txtPaisCte.Text = pais;
                txtPobCte.Text = dele;
            }

            if (ActAnt == "Ant")
            {
                txtColCteAnt.Text = Col;
                txtCpCteAnt.Text = cp;
                txtDelCteAnt.Text = dele;
                txtEstCteAnt.Text = edo;
                txtPobCteAnt.Text = dele;
                txtPaisCteAnt.Text = pais;
            }

            if (ActAnt == "Emp")
            {
                txtColEmp.Text = Col;
                txtCpEmp.Text = cp;
                txtDelEmp.Text = dele;
                txtEstEmp.Text = edo;
                txtPobEmp.Text = dele;
                txtPaisEmp.Text = pais;
            }

            if (ActAnt == "EmpA")
            {
                txtColEmpA.Text = Col;
                txtCpEmpA.Text = cp;
                txtDelEmpA.Text = dele;
                txtEstEmpA.Text = edo;
                txtPobEmpA.Text = dele;
                txtPaisEmpA.Text = pais;
            }
        }

        public void CargatxtRecomineda(string cliente, string nombre)
        {
            txtRecPor.Text = "";
            txtRecPor.Text = cliente;
            txtNomR.Text = nombre;
            //Consultas c = new Consultas();//aki se decide si se borra el tipo conyuge recomnedado en dado caso de que se haya decido cambiar de cte recomienda 
            //if (IdCtoRecConyu > 0 && c.ExisteConyReco(Prospecto, IdCtoRecConyu) != txtNomR.Text.Trim())
            //    eliminaCtoRecConyu();
        }

        public void Contactos(string tipo, string parent, string apePat, string apeMat, string nom, string lada,
            string tel, string fechN, string sex, string edo, string live, string viveCon, string calidadCon, int ID,
            string Accion, int EsCasa, string NoCuenta, string rfcCto)
        {
            int rows = dgvCto.Rows.Count;
            int antID;

            if (Accion == "Actualiza")
                for (int r = 0; r < rows; r++) //solo funciona para cuando actualizan un contacto
                {
                    antID = Convert.ToInt32(dgvCto.Rows[r].Cells["idCto"].Value);
                    if (antID == ID)
                    {
                        dgvCto.Rows.RemoveAt(r);
                        break;
                    }
                }

            dgvCto.Rows.Add(tipo, parent, apePat, apeMat, nom, Canal, lada, tel, fechN, sex, edo, live, viveCon,
                calidadCon, ID, EsCasa, NoCuenta, rfcCto);

            //Conexiones LineaConex = new Conexiones(); //ESTE ES PARA CUANDO NO SE CAPTURA CONYUGE DEL AVAL YA SEA DESDE ACTUALIZAR O CAPTURAR NEW
            //string LIN = LineaConex.setCadena();
            //GuadarCto ct = new GuadarCto();
            //int count = ct.ExisteConyuge(LIN, Prospecto, "CONYUGE DEL AVAL");
            //if ((edo == "Casado" || edo == "Casada" || edo == "Union Libre") && tipo == "AVAL" && count == 0 && Accion == "Actualiza")
            //{

            //    CapturaCto cap = new CapturaCto(Canal, Sucursal, Prospecto, Categoria, cmbRegimen.Text, Respuesta1, Usuario, "CONYUGE DEL AVAL", esCredExpress,NombreTipoCaptura);
            //    cap.Show(this);
            //}
        }

        #endregion
    }
}