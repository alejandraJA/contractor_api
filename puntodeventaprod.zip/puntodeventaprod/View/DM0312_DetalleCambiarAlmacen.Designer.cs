﻿namespace PuntoVenta.View
{
    partial class DM0312_DetalleCambiarAlmacen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_DetalleCambiarAlmacen));
            this.txt_busqueda = new System.Windows.Forms.TextBox();
            this.lbl_almacen = new System.Windows.Forms.Label();
            this.dgv_almacenes = new System.Windows.Forms.DataGridView();
            this.lbl_almacenAnterior = new System.Windows.Forms.Label();
            this.lbl_NuevoAlmacen = new System.Windows.Forms.Label();
            this.btn_CambiarAlmacen = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_almacenes)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_busqueda
            // 
            this.txt_busqueda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_busqueda.Location = new System.Drawing.Point(193, 109);
            this.txt_busqueda.Name = "txt_busqueda";
            this.txt_busqueda.Size = new System.Drawing.Size(118, 22);
            this.txt_busqueda.TabIndex = 0;
            this.txt_busqueda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_almacenSeleccionado_KeyPress);
            // 
            // lbl_almacen
            // 
            this.lbl_almacen.AutoSize = true;
            this.lbl_almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_almacen.Location = new System.Drawing.Point(87, 111);
            this.lbl_almacen.Name = "lbl_almacen";
            this.lbl_almacen.Size = new System.Drawing.Size(51, 15);
            this.lbl_almacen.TabIndex = 1;
            this.lbl_almacen.Text = "Buscar:";
            this.lbl_almacen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgv_almacenes
            // 
            this.dgv_almacenes.AllowUserToAddRows = false;
            this.dgv_almacenes.AllowUserToDeleteRows = false;
            this.dgv_almacenes.AllowUserToResizeColumns = false;
            this.dgv_almacenes.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_almacenes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_almacenes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_almacenes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_almacenes.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_almacenes.BackgroundColor = System.Drawing.Color.White;
            this.dgv_almacenes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_almacenes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_almacenes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_almacenes.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_almacenes.EnableHeadersVisualStyles = false;
            this.dgv_almacenes.Location = new System.Drawing.Point(83, 137);
            this.dgv_almacenes.Margin = new System.Windows.Forms.Padding(10, 3, 10, 40);
            this.dgv_almacenes.Name = "dgv_almacenes";
            this.dgv_almacenes.ReadOnly = true;
            this.dgv_almacenes.RowHeadersVisible = false;
            this.dgv_almacenes.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgv_almacenes.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_almacenes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_almacenes.Size = new System.Drawing.Size(739, 362);
            this.dgv_almacenes.TabIndex = 37;
            this.dgv_almacenes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_almacenes_CellContentClick);
            this.dgv_almacenes.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_almacenes_CellDoubleClick);
            this.dgv_almacenes.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Dgv_almacenes_ColumnHeaderMouseClick);
            this.dgv_almacenes.SelectionChanged += new System.EventHandler(this.Dgv_almacenes_SelectionChanged);
            // 
            // lbl_almacenAnterior
            // 
            this.lbl_almacenAnterior.AutoSize = true;
            this.lbl_almacenAnterior.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_almacenAnterior.Location = new System.Drawing.Point(87, 49);
            this.lbl_almacenAnterior.Name = "lbl_almacenAnterior";
            this.lbl_almacenAnterior.Size = new System.Drawing.Size(107, 15);
            this.lbl_almacenAnterior.TabIndex = 38;
            this.lbl_almacenAnterior.Text = "Almacen anterior:";
            this.lbl_almacenAnterior.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_NuevoAlmacen
            // 
            this.lbl_NuevoAlmacen.AutoSize = true;
            this.lbl_NuevoAlmacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NuevoAlmacen.Location = new System.Drawing.Point(87, 78);
            this.lbl_NuevoAlmacen.Name = "lbl_NuevoAlmacen";
            this.lbl_NuevoAlmacen.Size = new System.Drawing.Size(92, 15);
            this.lbl_NuevoAlmacen.TabIndex = 39;
            this.lbl_NuevoAlmacen.Text = "Nuevo almacen:";
            this.lbl_NuevoAlmacen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_CambiarAlmacen
            // 
            this.btn_CambiarAlmacen.BackColor = System.Drawing.Color.White;
            this.btn_CambiarAlmacen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_CambiarAlmacen.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_CambiarAlmacen.FlatAppearance.BorderSize = 0;
            this.btn_CambiarAlmacen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CambiarAlmacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CambiarAlmacen.Image = ((System.Drawing.Image)(resources.GetObject("btn_CambiarAlmacen.Image")));
            this.btn_CambiarAlmacen.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_CambiarAlmacen.Location = new System.Drawing.Point(5, 22);
            this.btn_CambiarAlmacen.Name = "btn_CambiarAlmacen";
            this.btn_CambiarAlmacen.Size = new System.Drawing.Size(72, 58);
            this.btn_CambiarAlmacen.TabIndex = 12;
            this.btn_CambiarAlmacen.Text = "Cambiar almacen";
            this.btn_CambiarAlmacen.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_CambiarAlmacen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_CambiarAlmacen.UseVisualStyleBackColor = false;
            this.btn_CambiarAlmacen.Click += new System.EventHandler(this.Btn_CambiarAlmacen_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(1, 86);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(76, 70);
            this.btn_Regresar.TabIndex = 40;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.Btn_Cancelar_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(83, 2);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(739, 44);
            this.txt_Comentarios.TabIndex = 113;
            // 
            // DM0312_DetalleCambiarAlmacen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 510);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.lbl_NuevoAlmacen);
            this.Controls.Add(this.lbl_almacenAnterior);
            this.Controls.Add(this.dgv_almacenes);
            this.Controls.Add(this.btn_CambiarAlmacen);
            this.Controls.Add(this.lbl_almacen);
            this.Controls.Add(this.txt_busqueda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_DetalleCambiarAlmacen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalogo almacen";
            this.Load += new System.EventHandler(this.DM0312_CambiarAlmacenDetalle_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_DetalleCambiarAlmacen_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_almacenes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_busqueda;
        private System.Windows.Forms.Label lbl_almacen;
        private System.Windows.Forms.Button btn_CambiarAlmacen;
        private System.Windows.Forms.DataGridView dgv_almacenes;
        private System.Windows.Forms.Label lbl_almacenAnterior;
        private System.Windows.Forms.Label lbl_NuevoAlmacen;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}