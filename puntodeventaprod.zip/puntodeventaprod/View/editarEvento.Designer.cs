﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace PuntoVenta.View {
    partial class editarEvento {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
           
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.lbl_Mov = new System.Windows.Forms.Label();
            this.lbl_Clave = new System.Windows.Forms.Label();
            this.lbl_Asunto = new System.Windows.Forms.Label();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.txt_AsuntObserva = new System.Windows.Forms.TextBox();
            this.txt_eventoDescripcion = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtp_Fecha = new System.Windows.Forms.DateTimePicker();
            this.txt_agenteDescripcion = new System.Windows.Forms.TextBox();
            this.txt_usuarioDescripcion = new System.Windows.Forms.TextBox();
            this.txt_eventoClave = new System.Windows.Forms.TextBox();
            this.txt_Agente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_ComentarioAyuda = new System.Windows.Forms.TextBox();
            this.lbl_Observaciones = new System.Windows.Forms.Label();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Movimiento = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(156, 353);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(50, 15);
            this.lbl_Cliente.TabIndex = 4;
            this.lbl_Cliente.Text = "Cliente ";
            // 
            // lbl_Mov
            // 
            this.lbl_Mov.AutoSize = true;
            this.lbl_Mov.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mov.Location = new System.Drawing.Point(567, 353);
            this.lbl_Mov.Name = "lbl_Mov";
            this.lbl_Mov.Size = new System.Drawing.Size(29, 15);
            this.lbl_Mov.TabIndex = 5;
            this.lbl_Mov.Text = "Mov";
            // 
            // lbl_Clave
            // 
            this.lbl_Clave.AutoSize = true;
            this.lbl_Clave.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Clave.Location = new System.Drawing.Point(28, 55);
            this.lbl_Clave.Name = "lbl_Clave";
            this.lbl_Clave.Size = new System.Drawing.Size(37, 15);
            this.lbl_Clave.TabIndex = 0;
            this.lbl_Clave.Text = "Clave";
            // 
            // lbl_Asunto
            // 
            this.lbl_Asunto.AutoSize = true;
            this.lbl_Asunto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Asunto.Location = new System.Drawing.Point(28, 104);
            this.lbl_Asunto.Name = "lbl_Asunto";
            this.lbl_Asunto.Size = new System.Drawing.Size(49, 15);
            this.lbl_Asunto.TabIndex = 3;
            this.lbl_Asunto.Text = "Asunto ";
            // 
            // txt_usuario
            // 
            this.txt_usuario.Enabled = false;
            this.txt_usuario.Location = new System.Drawing.Point(91, 253);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.ReadOnly = true;
            this.txt_usuario.Size = new System.Drawing.Size(72, 20);
            this.txt_usuario.TabIndex = 8;
            // 
            // txt_AsuntObserva
            // 
            this.txt_AsuntObserva.BackColor = System.Drawing.Color.Snow;
            this.txt_AsuntObserva.Location = new System.Drawing.Point(91, 104);
            this.txt_AsuntObserva.MaxLength = 200;
            this.txt_AsuntObserva.Multiline = true;
            this.txt_AsuntObserva.Name = "txt_AsuntObserva";
            this.txt_AsuntObserva.Size = new System.Drawing.Size(489, 96);
            this.txt_AsuntObserva.TabIndex = 5;
            // 
            // txt_eventoDescripcion
            // 
            this.txt_eventoDescripcion.Enabled = false;
            this.txt_eventoDescripcion.Location = new System.Drawing.Point(218, 51);
            this.txt_eventoDescripcion.Name = "txt_eventoDescripcion";
            this.txt_eventoDescripcion.ReadOnly = true;
            this.txt_eventoDescripcion.Size = new System.Drawing.Size(276, 20);
            this.txt_eventoDescripcion.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.dtp_Fecha);
            this.groupBox1.Controls.Add(this.txt_agenteDescripcion);
            this.groupBox1.Controls.Add(this.txt_usuarioDescripcion);
            this.groupBox1.Controls.Add(this.txt_eventoClave);
            this.groupBox1.Controls.Add(this.txt_Agente);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_ComentarioAyuda);
            this.groupBox1.Controls.Add(this.lbl_Observaciones);
            this.groupBox1.Controls.Add(this.lbl_fecha);
            this.groupBox1.Controls.Add(this.txt_eventoDescripcion);
            this.groupBox1.Controls.Add(this.txt_AsuntObserva);
            this.groupBox1.Controls.Add(this.txt_usuario);
            this.groupBox1.Controls.Add(this.lbl_Asunto);
            this.groupBox1.Controls.Add(this.lbl_Usuario);
            this.groupBox1.Controls.Add(this.lbl_Clave);
            this.groupBox1.Location = new System.Drawing.Point(102, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(710, 295);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // dtp_Fecha
            // 
            this.dtp_Fecha.CustomFormat = "dd/MM/yyyy";
            this.dtp_Fecha.Enabled = false;
            this.dtp_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Fecha.Location = new System.Drawing.Point(553, 51);
            this.dtp_Fecha.Name = "dtp_Fecha";
            this.dtp_Fecha.Size = new System.Drawing.Size(120, 20);
            this.dtp_Fecha.TabIndex = 27;
            // 
            // txt_agenteDescripcion
            // 
            this.txt_agenteDescripcion.Enabled = false;
            this.txt_agenteDescripcion.Location = new System.Drawing.Point(169, 225);
            this.txt_agenteDescripcion.Name = "txt_agenteDescripcion";
            this.txt_agenteDescripcion.ReadOnly = true;
            this.txt_agenteDescripcion.Size = new System.Drawing.Size(220, 20);
            this.txt_agenteDescripcion.TabIndex = 26;
            // 
            // txt_usuarioDescripcion
            // 
            this.txt_usuarioDescripcion.Enabled = false;
            this.txt_usuarioDescripcion.Location = new System.Drawing.Point(169, 253);
            this.txt_usuarioDescripcion.Name = "txt_usuarioDescripcion";
            this.txt_usuarioDescripcion.ReadOnly = true;
            this.txt_usuarioDescripcion.Size = new System.Drawing.Size(220, 20);
            this.txt_usuarioDescripcion.TabIndex = 25;
            // 
            // txt_eventoClave
            // 
            this.txt_eventoClave.Enabled = false;
            this.txt_eventoClave.Location = new System.Drawing.Point(91, 51);
            this.txt_eventoClave.Name = "txt_eventoClave";
            this.txt_eventoClave.ReadOnly = true;
            this.txt_eventoClave.Size = new System.Drawing.Size(121, 20);
            this.txt_eventoClave.TabIndex = 23;
            // 
            // txt_Agente
            // 
            this.txt_Agente.Enabled = false;
            this.txt_Agente.Location = new System.Drawing.Point(91, 225);
            this.txt_Agente.Name = "txt_Agente";
            this.txt_Agente.ReadOnly = true;
            this.txt_Agente.Size = new System.Drawing.Size(72, 20);
            this.txt_Agente.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "Agente";
            // 
            // txt_ComentarioAyuda
            // 
            this.txt_ComentarioAyuda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ComentarioAyuda.Enabled = false;
            this.txt_ComentarioAyuda.Location = new System.Drawing.Point(6, 10);
            this.txt_ComentarioAyuda.Name = "txt_ComentarioAyuda";
            this.txt_ComentarioAyuda.Size = new System.Drawing.Size(526, 13);
            this.txt_ComentarioAyuda.TabIndex = 18;
            // 
            // lbl_Observaciones
            // 
            this.lbl_Observaciones.AutoSize = true;
            this.lbl_Observaciones.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Observaciones.Location = new System.Drawing.Point(28, 82);
            this.lbl_Observaciones.Name = "lbl_Observaciones";
            this.lbl_Observaciones.Size = new System.Drawing.Size(90, 15);
            this.lbl_Observaciones.TabIndex = 12;
            this.lbl_Observaciones.Text = "Observaciones ";
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(508, 55);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(39, 15);
            this.lbl_fecha.TabIndex = 10;
            this.lbl_fecha.Text = "Fecha";
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.AutoSize = true;
            this.lbl_Usuario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Usuario.Location = new System.Drawing.Point(28, 255);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(50, 15);
            this.lbl_Usuario.TabIndex = 1;
            this.lbl_Usuario.Text = "Usuario";
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = global::PuntoVenta.Properties.Resources.icons8_volver_30;
            this.btn_Regresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Regresar.Location = new System.Drawing.Point(3, 83);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(73, 73);
            this.btn_Regresar.TabIndex = 10;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.Color.White;
            this.btn_Guardar.FlatAppearance.BorderSize = 0;
            this.btn_Guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guardar.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Image = global::PuntoVenta.Properties.Resources.floppy_icon;
            this.btn_Guardar.Location = new System.Drawing.Point(3, 3);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(73, 74);
            this.btn_Guardar.TabIndex = 9;
            this.btn_Guardar.Text = "Guardar (Crtl-G)";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Guardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_Guardar);
            this.flowLayoutPanel1.Controls.Add(this.btn_Regresar);
            this.flowLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 7);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(82, 347);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(99, 353);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "Cliente:";
            // 
            // lbl_Movimiento
            // 
            this.lbl_Movimiento.AutoSize = true;
            this.lbl_Movimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Movimiento.Location = new System.Drawing.Point(487, 353);
            this.lbl_Movimiento.Name = "lbl_Movimiento";
            this.lbl_Movimiento.Size = new System.Drawing.Size(74, 15);
            this.lbl_Movimiento.TabIndex = 15;
            this.lbl_Movimiento.Text = "Movimiento:";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(102, 0);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(710, 59);
            this.txt_Comentarios.TabIndex = 110;
            // 
            // editarEvento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(845, 377);
            this.ControlBox = false;
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.lbl_Movimiento);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.lbl_Mov);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "editarEvento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recalificar Evento";
            this.Load += new System.EventHandler(this.editarEvento_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_AgregarEvento_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.DateTimePicker dtp_Fecha;

        private System.Windows.Forms.Label lbl_fecha;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox3;

        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;

        #endregion

        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.Label lbl_Mov;
        private System.Windows.Forms.Label lbl_Clave;
        private System.Windows.Forms.Label lbl_Agente;
        private System.Windows.Forms.Label lbl_Asunto;
        private System.Windows.Forms.Label lbl_Usuario;
        public System.Windows.Forms.TextBox txt_AgenteDescripcion;
        public System.Windows.Forms.TextBox txt_AsuntObserva;
        public System.Windows.Forms.TextBox txt_agenteDescripcion;
        public System.Windows.Forms.TextBox txt_usuarioDescripcion;
        public System.Windows.Forms.TextBox txt_usuario;
        public System.Windows.Forms.TextBox txt_Agente;
        public System.Windows.Forms.TextBox txt_eventoClave;
        public System.Windows.Forms.TextBox txt_eventoDescripcion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Label lbl_Observaciones;
        private System.Windows.Forms.Label lbl_Hora;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox txt_ComentarioAyuda;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Movimiento;
        private System.Windows.Forms.TextBox txt_Comentarios;
    }
}