﻿namespace PuntoVenta.View
{
    partial class Dm0312DetalleSituaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dm0312DetalleSituaciones));
            this.Aceptar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_retroceder = new System.Windows.Forms.Button();
            this.cb_situacion = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_fechaSeguimiento = new System.Windows.Forms.Label();
            this.lbl_usuario = new System.Windows.Forms.Label();
            this.lbl_UsuarioActual = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // Aceptar
            // 
            this.Aceptar.BackColor = System.Drawing.Color.White;
            this.Aceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Aceptar.FlatAppearance.BorderSize = 0;
            this.Aceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aceptar.Image = ((System.Drawing.Image)(resources.GetObject("Aceptar.Image")));
            this.Aceptar.Location = new System.Drawing.Point(2, 1);
            this.Aceptar.Name = "Aceptar";
            this.Aceptar.Size = new System.Drawing.Size(73, 73);
            this.Aceptar.TabIndex = 3;
            this.Aceptar.Text = "Aceptar (Crtl-G)";
            this.Aceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Aceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Aceptar.UseVisualStyleBackColor = false;
            this.Aceptar.Click += new System.EventHandler(this.Aceptar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.Color.White;
            this.btn_Cancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Cancelar.FlatAppearance.BorderSize = 0;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cancelar.Image")));
            this.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Cancelar.Location = new System.Drawing.Point(2, 80);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(73, 76);
            this.btn_Cancelar.TabIndex = 10;
            this.btn_Cancelar.Text = "Cancelar (Esc)";
            this.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.Btn_Cancelar_Click);
            // 
            // btn_retroceder
            // 
            this.btn_retroceder.BackColor = System.Drawing.Color.White;
            this.btn_retroceder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_retroceder.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_retroceder.FlatAppearance.BorderSize = 0;
            this.btn_retroceder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_retroceder.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_retroceder.Image = ((System.Drawing.Image)(resources.GetObject("btn_retroceder.Image")));
            this.btn_retroceder.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_retroceder.Location = new System.Drawing.Point(2, 162);
            this.btn_retroceder.Name = "btn_retroceder";
            this.btn_retroceder.Size = new System.Drawing.Size(73, 71);
            this.btn_retroceder.TabIndex = 11;
            this.btn_retroceder.Text = "Retroceder ";
            this.btn_retroceder.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_retroceder.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_retroceder.UseVisualStyleBackColor = false;
            this.btn_retroceder.Click += new System.EventHandler(this.Btn_retroceder_Click);
            // 
            // cb_situacion
            // 
            this.cb_situacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_situacion.FormattingEnabled = true;
            this.cb_situacion.Location = new System.Drawing.Point(111, 88);
            this.cb_situacion.Name = "cb_situacion";
            this.cb_situacion.Size = new System.Drawing.Size(189, 21);
            this.cb_situacion.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(111, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 15);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nueva situacion:";
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(111, 123);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(113, 15);
            this.lbl_fecha.TabIndex = 14;
            this.lbl_fecha.Text = "Fecha seguimiento:";
            // 
            // lbl_fechaSeguimiento
            // 
            this.lbl_fechaSeguimiento.AutoSize = true;
            this.lbl_fechaSeguimiento.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fechaSeguimiento.Location = new System.Drawing.Point(117, 146);
            this.lbl_fechaSeguimiento.Name = "lbl_fechaSeguimiento";
            this.lbl_fechaSeguimiento.Size = new System.Drawing.Size(39, 15);
            this.lbl_fechaSeguimiento.TabIndex = 15;
            this.lbl_fechaSeguimiento.Text = "Fecha";
            // 
            // lbl_usuario
            // 
            this.lbl_usuario.AutoSize = true;
            this.lbl_usuario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_usuario.Location = new System.Drawing.Point(117, 201);
            this.lbl_usuario.Name = "lbl_usuario";
            this.lbl_usuario.Size = new System.Drawing.Size(49, 15);
            this.lbl_usuario.TabIndex = 17;
            this.lbl_usuario.Text = "Usuario";
            // 
            // lbl_UsuarioActual
            // 
            this.lbl_UsuarioActual.AutoSize = true;
            this.lbl_UsuarioActual.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UsuarioActual.Location = new System.Drawing.Point(111, 176);
            this.lbl_UsuarioActual.Name = "lbl_UsuarioActual";
            this.lbl_UsuarioActual.Size = new System.Drawing.Size(54, 15);
            this.lbl_UsuarioActual.TabIndex = 16;
            this.lbl_UsuarioActual.Text = "Usuario:";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(81, 1);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(269, 45);
            this.txt_Comentarios.TabIndex = 118;
            this.txt_Comentarios.TextChanged += new System.EventHandler(this.txt_Comentarios_TextChanged);
            // 
            // DM0312_DetalleSituaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(353, 233);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.lbl_usuario);
            this.Controls.Add(this.lbl_UsuarioActual);
            this.Controls.Add(this.lbl_fechaSeguimiento);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_situacion);
            this.Controls.Add(this.btn_retroceder);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.Aceptar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Dm0312DetalleSituaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Situaciones";
            this.Load += new System.EventHandler(this.DM0312_Situaciones_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_DetalleSituaciones_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Aceptar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_retroceder;
        private System.Windows.Forms.ComboBox cb_situacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_fechaSeguimiento;
        private System.Windows.Forms.Label lbl_usuario;
        private System.Windows.Forms.Label lbl_UsuarioActual;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ToolTip toolTip1;

    }
}