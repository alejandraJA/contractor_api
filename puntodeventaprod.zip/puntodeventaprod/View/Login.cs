﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View;
namespace PuntoVenta.View
{
    public partial class Login : Form
    {
        public string Acceso;
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lbl_Login.Text == "sr09")
            {
                ClaseEstatica.plugInPath = System.Configuration.ConfigurationManager.AppSettings["plugInsCubos"];
                DM0312_ExploradorVentas tablero = new DM0312_ExploradorVentas();
                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                ConfigColumnas CColumnas = new ConfigColumnas();
                AccesosDeUsuario.AccesosUsuario = UsuarioAcceso.ObtenerAccesos(ClaseEstatica.Usuario.Usser);

                //Obtener accesos de usuario que quedan en toda la aplicacion
                UsuarioAcceso.ObtenerConfiguracionUsuario(ClaseEstatica.Usuario.Usser, ClaseEstatica.Usuario.grupo);
                CColumnas.ObtenerColumnasTablero();
                tablero = (DM0312_ExploradorVentas)UsuarioAcceso.AplicarVistas(tablero);
                tablero.recibeMensaje = ClaseEstatica.Usuario.Usser;
                tablero.recibeSucursal = ClaseEstatica.Usuario.sucursal;
                //Application.Run(tablero);
                tablero.ShowDialog();

           
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
