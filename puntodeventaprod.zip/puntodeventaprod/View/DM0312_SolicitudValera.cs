﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta.View
{
    public partial class DM0312_SolicitudValera : Form
    {
        public static List<DM0312_MPuntoDeVentaCanales> listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
        public static string Codigo = "";
        public static string Agente, Almacen;
        public static List<string> datosCliente = new List<string>();
        public static List<string> datosCondicion = new List<string>();
        public static int idVenta, NumValidacion;
        private string almacenOrigen, Alm;
        public int Canal, EnviarA, canalC = 0, suc;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool CerrarVenta;
        private string Cliente = "", Vendedor = "", Movimiento = "", Condicion = ""; //Datos para obtener el idVenta
        private readonly string NoCtaPago = ""; //Datos para obtener el idVenta
        private string Observacion = "", Comentario = ""; //Datos para obtener el idVenta
        public List<DM0312_MComentariosVenta> ComentariosSolValera;
        private string componenteValidado = "";
        private readonly DM0312_CPuntoDeVenta controladorP = new DM0312_CPuntoDeVenta();
        private readonly DM0312_C_SolicitudValera controladorV = new DM0312_C_SolicitudValera();
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        private readonly DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
        private bool existe;

        private readonly DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public string mensajeBoton = "";
        private List<DM0312_MSolicitudValera> ModeloDetalle = new List<DM0312_MSolicitudValera>();
        public DM0312_MSolicitudValera modelSelect;
        private string movimiento = "";

        private bool obligatorioCliente,
            obligatorioAgente,
            obligatorioCanal,
            obligatorioCondicion = true,
            obligatorioAlmacen,
            obligatorio;

        public string valera = "";
        public string ValidaEstatus = "", mensajeValidacion = "";

        public DM0312_SolicitudValera(string Cliente, int CanalP)
        {
            Codigo = Cliente;
            Canal = CanalP;
            InitializeComponent();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);
        }

        ~DM0312_SolicitudValera()
        {
            GC.Collect();
        }

        private void DM0312_SolicitudValera_Load(object sender, EventArgs e)
        {
            btn_Detalle.Enabled = false;
            lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
            ComentariosSolValera = Funciones.ConsultaComentario("Solicitud Valera");
            lbl_Estatus.Text = "SIN AFECTAR";
            movimiento = "Solicitud Credito";
            CargaCliente();
            string validaCasa = string.Empty;
            validaCasa = controladorP.validaCasa(Codigo, Canal);
            txt_Comentarios.Text =
                "SOLICITUD VALERA, INGRESAR EL VENDEDOR EN EL CAMPO AGENTE, VERIFICAR LOS DATOS DE LA VALERA Y AFECTAR EL MOVIMIENTO";
            if (validaCasa == "Casa")
                LlenaCondicion(1);
            else
                LlenaCondicion(2);
            LlenaListaCanalesCliente();
            ValidaCanal();
            if (existe != true)
            {
                AgregaNuevoCanal();

                if (valera != "VALR00001")
                {
                    RedDima frmRed = new RedDima();
                    frmRed.cuenta = Codigo;
                    frmRed.ShowDialog();
                }
            }

            ConsultaAlmacen();
            EstatusComponentes();

            ComponentesFocus();
            panel_Detalle.Visible = false;
            gbx_VentaDetalle.Visible = false;
            Size = new Size(1112, 352);
            btn_Afecta.Visible = false;
            Text = "Solicitud Valera       SPID:" + ClaseEstatica.SPID + "        " +
                   controllerExplorador.FechaActualServidor();

            toolTip1.SetToolTip(btn_Regresar, "CANCELAR SOLICITUD VALERA");
            toolTip1.SetToolTip(btn_Afecta,
                "SI TIENE LOS DATOS CORRECTOS SOBRE LA VALERA: " + valera +
                " PRESIONAR BOTÓN PARA SEGUIR PROCESO DE LA SOLICITUD VALERA");
            toolTip1.SetToolTip(btn_InformacionCliente,
                "INFORMACIÓN IMPORTANTE DEL CLIENTE AL QUE SE LE VA HACER LA SOLICITUD VALERA");
            toolTip1.SetToolTip(txt_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(btn_ayuda, "AYUDA");
            toolTip1.SetToolTip(cbx_Cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA SOLICITUD VALERA");
            toolTip1.SetToolTip(txt_ClienteNombre, "NOMBRE DEL CLIENTE");
            toolTip1.SetToolTip(cbx_Agente, "VENDEDOR QUE REALIZA LA SOLICITUD VALERA");
            toolTip1.SetToolTip(cbx_Canal, "TIPO DE VENTA DIMA");
            toolTip1.SetToolTip(cbx_Condicion, "PLAZO DE PAGO DE LA SOLICITUD VALERA");
            toolTip1.SetToolTip(cbx_Almacen, "ALMACÉN DONDE SE REALIZA LA SOLICITU VALERA");
            toolTip1.SetToolTip(txt_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Usuario, "USUARIO");
            toolTip1.SetToolTip(lbl_Estatus, "ESTATUS DE LA SOLICITUD VALERA");
            toolTip1.SetToolTip(lbl_ID, "ID DE LA SOLICITUD VALERA");
            toolTip1.SetToolTip(gbx_VentaDetalle,
                "DETALLE DEL MOVIMIENTO SI ES NECESARIO INSERTAR OBSERVACIONES,  UNA VEZ TERMINADO AFECTAR LA SOLICITUD Y SEGUIR CON SU PROCESO");
            toolTip1.SetToolTip(lbl_cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA SOLICITUD VALERA");
            toolTip1.SetToolTip(lbl_canal, "TIPO DE VENTA DIMA");
            toolTip1.SetToolTip(lbl_Agente, "VENDEDOR QUE REALIZA LA SOLICITUD VALERA");
            toolTip1.SetToolTip(lbl_condicion, "PLAZO DE PAGO DE LA SOLICITUD VALERA");
            toolTip1.SetToolTip(lbl_almacen, "ALMACÉN DONDE SE REALIZA LA SOLICITU VALERA");
            toolTip1.SetToolTip(lbl_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");

            if (ClaseEstatica.Usuario.color == "Azul")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;

            if (ClaseEstatica.Usuario.Uen == 3)
            {
                lbl_Empresa.Text = "MAVI";
                toolTip1.SetToolTip(lbl_Empresa, "MAVI DE OCCIDENTE");
            }
            else
            {
                if (ClaseEstatica.Usuario.Uen == 1)
                {
                    lbl_Empresa.Text = "MA";
                    toolTip1.SetToolTip(lbl_Empresa, "MUEBLES AMERICA");
                }
                else
                {
                    if (ClaseEstatica.Usuario.Uen == 2)
                    {
                        lbl_Empresa.Text = "VIU";
                        toolTip1.SetToolTip(lbl_Empresa, "VIU");
                    }
                    else
                    {
                        lbl_Empresa.Text = "";
                        toolTip1.SetToolTip(lbl_Empresa, "");
                    }
                }
            }
        }

        private void Cbx_Cliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                if (cbx_Cliente.Text != Codigo)
                {
                    Codigo = cbx_Cliente.Text;
                    CargaCliente();
                    ValidarCliente();
                }

                if (obligatorioCliente)
                {
                    componenteValidado = "cliente";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioCliente) ComponentesFocus();
            }
        }

        private void Cbx_Cliente_Validating(object sender, CancelEventArgs e)
        {
            mensajeValidacion = "";
            if (btn_Regresar.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && dvg_detalleVenta.Focused == false)
            {
                if (cbx_Cliente.Text != Codigo)
                {
                    Codigo = cbx_Cliente.Text;
                    CargaCliente();
                    ValidarCliente();
                    cbx_Cliente.Text = Codigo;
                }
                else if (obligatorioCliente && lbl_ID.Text == "")
                {
                    componenteValidado = "cliente";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void dvg_detalleVenta_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            ((DataGridViewTextBoxColumn)dvg_detalleVenta.Columns["Observaciones"]).MaxInputLength = 100;
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            if (controladorP.ValidarCliente(cbx_Cliente.Text) == "NO")
            {
                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                cbx_Cliente.Focus();
            }
            else
            {
                if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                {
                    Codigo = cbx_Cliente.Text.ToUpper();
                    CargaCliente();
                    ValidarCliente();
                }
            }
        }

        private void DM0312_SolicitudValera_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (lbl_ID.Text != "")
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        EliminarId();
                        Dispose();
                    }
                }
                else
                {
                    Dispose();
                }
            }


            if (e.Control && e.KeyCode == Keys.I)
                try
                {
                    if (cbx_Cliente.Text == "")
                    {
                        MessageBox.Show("Ingrese un Cliente", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (controladorP.ValidarCliente(cbx_Cliente.Text) == "NO")
                        {
                            MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                            cbx_Cliente.Focus();
                        }
                        else
                        {
                            if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                            {
                                Codigo = cbx_Cliente.Text.ToUpper();
                                CargaCliente();
                                ValidarCliente();
                            }

                            InformacionCliente infoCliente = new InformacionCliente
                            {
                                mensaje = cbx_Cliente.Text
                            };
                            infoCliente.Show();
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }

            if (e.Control && e.KeyCode == Keys.F) Afectar();
        }

        private void dvg_detalleVenta_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            //foreach (DataGridViewRow drow in dvg_detalleVenta.Rows)
            //{
            //    drow.Cells["Importe"].Value = Convert.ToDouble(drow.Cells["Importe"].Value).ToString("C");
            //}
        }

        #region "METODOS"

        public void CargaCliente()
        {
            try
            {
                datosCliente = new List<string>();
                datosCliente = controladorP.LlenaDatosCliente(Codigo);
                if (datosCliente.Count > 0)
                {
                    cbx_Cliente.Items.Add(datosCliente[0]);
                    cbx_Cliente.SelectedIndex = 0;
                    cbx_Cliente.Text = datosCliente[0];
                    ;
                    txt_ClienteNombre.Text = datosCliente[1];
                    cbx_Canal.Text = "76";
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("CargaCliente", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaCondicion(int Var)
        {
            try
            {
                datosCondicion = new List<string>();
                datosCondicion = controladorP.LlenaCondicion(ClaseEstatica.Usuario.usuario, Canal, Var);
                if (datosCondicion.Count > 0)
                {
                    cbx_Condicion.DataSource = null;
                    cbx_Condicion.DataSource = datosCondicion.ToArray();
                }
                else
                {
                    cbx_Condicion.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaCondicion", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ActualizarInfoIdVenta()
        {
            try
            {
                bool Actualiza = new bool();
                Movimiento = movimiento;
                Cliente = Codigo;
                EnviarA = Canal;
                Alm = Almacen;
                Vendedor = Agente;
                Condicion = cbx_Condicion.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                almacenOrigen = controladorP.AlmacenDeSucursal(ClaseEstatica.Usuario.sucursal);
                suc = DevolucionMov.SucursalALM(Alm);
                Actualiza = controladorP.ActualizaIdVenta("MAVI", Movimiento, ClaseEstatica.Usuario.usuario, Cliente,
                    EnviarA, almacenOrigen, Vendedor, Condicion, suc,
                    ClaseEstatica.Usuario.Uen, NoCtaPago, Observacion, Comentario, "", "QUINCENAL", "", "", 2, idVenta,
                    ValidaEstatus, "", "", false, false, false, "", "", "", "", 0, 0);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public async void ObtenIdVenta()
        {
            try
            {
                Movimiento = movimiento;
                Cliente = Codigo;
                EnviarA = Canal;
                Alm = Almacen;
                Vendedor = Agente;
                Condicion = cbx_Condicion.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                almacenOrigen = await Task.Run(() => controladorP.AlmacenDeSucursal(ClaseEstatica.Usuario.sucursal));
                suc = DevolucionMov.SucursalALM(Alm);
                //FALTA QUE DAN PONGA EL ALMACEN ORIGEN
                idVenta = controladorP.IdVenta("MAVI", Movimiento, ClaseEstatica.Usuario.usuario, Cliente, EnviarA,
                    almacenOrigen, Vendedor, Condicion, suc,
                    ClaseEstatica.Usuario.Uen, NoCtaPago, Observacion, Comentario, "", "QUINCENAL", "", "", 1, "", "",
                    false, false, "", false, "", "", "");
                lbl_ID.Text = Convert.ToString(idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void EstatusComponentes()
        {
            if (cbx_Cliente.Text != "") obligatorioCliente = true;
            if (cbx_Canal.Text != "") obligatorioCanal = true;
            if (cbx_Agente.Text != "") obligatorioAgente = true;
            if (cbx_Condicion.Text != "") obligatorioCondicion = true;
            if (cbx_Almacen.Text != "") obligatorioAlmacen = true;
        }

        public void LlenaAgente()
        {
            try
            {
                if (Agente != null)
                {
                    cbx_Agente.Items.Add(Agente);
                    cbx_Agente.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaCanal()
        {
            try
            {
                DM0312_MPuntoDeVentaCanales var = listaCanal.Where(x => x.Canal == Convert.ToInt32(Canal))
                    .FirstOrDefault();
                if (var != null)
                    existe = true;
                else
                    existe = false;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void AgregaNuevoCanal()
        {
            try
            {
                bool Inserta = new bool();
                Inserta = controladorP.AgregaNuevoCanal(Codigo, Canal);
                LlenaListaCanalesCliente();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaListaCanalesCliente()
        {
            try
            {
                listaCanal = new List<DM0312_MPuntoDeVentaCanales>();
                listaCanal = controladorP.LlenaCanalesCliente(Codigo);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaAgente()
        {
            try
            {
                Agente = cbx_Agente.Text;
                string Resultado = "";
                int suc = controladorP.GetSucursal(cbx_Almacen.Text);

                Resultado = controladorP.ValidarAgente(Agente, suc);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (Agente == "")
                    {
                        MessageBox.Show("Debe ingresar un Agente", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAgente = false;
                        cbx_Agente.Focus();
                    }
                    else
                    {
                        MessageBox.Show("El Agente es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAgente = false;
                        cbx_Agente.Focus();
                    }

                    cbx_Agente.Text = "";
                    NumValidacion = 20;
                    obligatorioAgente = false;
                }
                else
                {
                    cbx_Agente.Items.Clear();
                    LlenaAgente();
                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text))
                        ActualizarInfoIdVenta();
                    //cbx_Canal.Focus();
                    obligatorioAgente = true;
                    NumValidacion = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAgente", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidacionComponentes(string componente)
        {
            try
            {
                ValidaCamposObligatorios2(componente);
                if (obligatorio != true)
                    if (obligatorioCliente = true && obligatorioAgente && obligatorioCanal && obligatorioAlmacen)
                        if (lbl_ID.Text == "")
                        {
                            ObtenIdVenta();
                            MessageBox.Show("Datos generales correctos, verificar su valera y afectar su solicitud",
                                "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (lbl_ID.Text != "")
                            {
                                DetalleSolicitudVal();
                                panel_Detalle.Visible = true;
                                gbx_VentaDetalle.Visible = true;
                                Size = new Size(1112, 561);
                                if (!CDetalleVenta.PuedeAfectar(ClaseEstatica.Usuario.usuario, "SINAFECTAR", "",
                                        "Solicitud Credito"))
                                {
                                    btn_Afecta.Visible = false;
                                }
                                else
                                {
                                    btn_Afecta.Visible = true;
                                    btn_Afecta.Focus();
                                }

                                dvg_detalleVenta.Select();
                                txt_Comentarios.Text = "VERIFICAR DATOS DE LA VALERA: " + valera +
                                                       " SI SON CORRECTOS AFECTAR LA SOLICITUD VALERA";
                            }
                            else
                            {
                                MessageBox.Show("Error al generar id de venta", "Error", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                Dispose();
                            }
                        }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidacionComponentes", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ComponentesFocus()
        {
            if (cbx_Cliente.Text == "")
            {
                cbx_Cliente.Select();
                cbx_Cliente.Focus();
            }
            else if (cbx_Agente.Text == "")
            {
                cbx_Agente.Select();
                cbx_Agente.Focus();
            }
            else if (cbx_Canal.Text == "")
            {
                cbx_Canal.Select();
                cbx_Canal.Focus();
            }
            else if (cbx_Almacen.Text == "")
            {
                cbx_Almacen.Select();
                cbx_Almacen.Focus();
            }
            else if (txt_Observaciones.Text == "" && txt_Observaciones.Visible)
            {
                txt_Observaciones.Select();
                txt_Observaciones.Focus();
            }
            else if (txt_Comentario.Text == "" && txt_Comentario.Visible)
            {
                txt_Comentario.Select();
                txt_Comentario.Focus();
            }
        }

        public void ValidaCamposObligatorios2(string componente)
        {
            try
            {
                if (componente == "cliente")
                {
                    if (cbx_Cliente.Text == "")
                    {
                        mensajeValidacion = ", Cuenta del Cliente";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidarCliente();
                    }
                }

                if (componente == "Agente")
                {
                    if (cbx_Agente.Text == "")
                    {
                        mensajeValidacion = mensajeValidacion + ", Agente";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidaAgente();
                    }
                }

                if (componente == "Condicion")
                    if (cbx_Condicion.Text == "")
                    {
                        mensajeValidacion = mensajeValidacion + ", Condicion";
                        NumValidacion++;
                    }

                if (componente == "Almacen")
                {
                    if (cbx_Almacen.Text == "")
                    {
                        mensajeValidacion = mensajeValidacion + ", Almacen";
                        NumValidacion++;
                    }
                    else
                    {
                        ValidaAlmacen();
                    }
                }

                if (NumValidacion == 20)
                {
                    obligatorio = true;
                    NumValidacion = 0;
                }
                else
                {
                    if (NumValidacion > 0)
                    {
                        obligatorio = true;
                        NumValidacion = 0;
                        ComponentesFocus();
                    }
                    else
                    {
                        obligatorio = false;
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaCamposObligatorios2", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ValidaAlmacen()
        {
            try
            {
                string almacen = cbx_Almacen.Text;
                string Resultado = "";

                Resultado = controladorP.ValidarAlmacen(almacen);
                if (Resultado == "NO" || Resultado == "")
                {
                    if (almacen == "")
                    {
                        MessageBox.Show("Debe ingresar un Almacen", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAlmacen = false;
                    }
                    else
                    {
                        MessageBox.Show("El Almacen es incorrecto", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        obligatorioAlmacen = false;
                    }

                    cbx_Almacen.Text = "";
                    NumValidacion = 20;
                    cbx_Almacen.Focus();
                }
                else
                {
                    cbx_Almacen.Items.Clear();
                    LlenaAlmacen();

                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text))
                        ActualizarInfoIdVenta();
                    obligatorioAlmacen = true;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ValidaAlmacen", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenaAlmacen()
        {
            try
            {
                if (Almacen != null)
                {
                    cbx_Almacen.Items.Add(Almacen);
                    cbx_Almacen.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenaAlmacen", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private void ValidarCliente()
        {
            try
            {
                string cliente = Codigo;
                string Resultado = "";
                Resultado = controladorP.ValidarCliente(Codigo);
                if (Resultado == "NO" || Resultado == "")
                {
                    MessageBox.Show("El Cliente es incorrecto", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    cbx_Cliente.Text = "";
                    txt_ClienteNombre.Text = "";
                    NumValidacion++;
                    mensajeValidacion = ", Cuenta del Cliente";
                    cbx_Cliente.Focus();
                    obligatorioCliente = false;
                }
                else
                {
                    txt_ClienteNombre.Text = Resultado;
                    cbx_Cliente.Items.Clear();
                    ValidaCanal();
                    if (existe != true) AgregaNuevoCanal();

                    if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                              Condicion != cbx_Condicion.Text || Alm != Almacen
                                              || Observacion != txt_Observaciones.Text ||
                                              Comentario != txt_Comentario.Text))
                        ActualizarInfoIdVenta();
                    obligatorioCliente = true;
                    ComponentesFocus();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("validarCliente", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void EliminarId()
        {
            try
            {
                bool Eliminar = new bool();
                Eliminar = controladorP.EliminarIdVenta(3, idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarId", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ConsultaAlmacen()
        {
            try
            {
                Almacen = controladorP.LlenaAlmacen(ClaseEstatica.Usuario.sucursal);
                LlenaAlmacen();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ConsultaAlmacen", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void DetalleSolicitudVal()
        {
            try
            {
                DataTable dataSet = new DataTable();
                dataSet = controladorV.InformacionValera(valera);
                ModeloDetalle = new List<DM0312_MSolicitudValera>();
                foreach (DataRow model in dataSet.Rows)
                {
                    DM0312_MSolicitudValera modelDev = new DM0312_MSolicitudValera
                    {
                        Articulo = model["Articulo"].ToString(),
                        Cantidad = "1"
                    };
                    modelDev.PrecioUnitario =
                        Math.Round(controladorP.GetPrice(modelDev.Articulo, idVenta, 2048, false), 2);
                    modelDev.Importe = Math.Round(modelDev.PrecioUnitario, 2);
                    modelDev.Observaciones = model["Observaciones"].ToString();
                    modelDev.Descripcion = model["Descripcion"].ToString();
                    modelDev.Unidad = model["Unidad"].ToString();
                    modelDev.impuesto = model["impuesto"].ToString();
                    ModeloDetalle.Add(modelDev);
                }

                dvg_detalleVenta.DataSource = null;
                dvg_detalleVenta.DataSource = ModeloDetalle;
                dvg_detalleVenta.Columns["Articulo"].ReadOnly = true;
                dvg_detalleVenta.Columns["Cantidad"].ReadOnly = true;
                dvg_detalleVenta.Columns["PrecioUnitario"].ReadOnly = true;
                dvg_detalleVenta.Columns["Importe"].ReadOnly = true;
                dvg_detalleVenta.Columns["Descripcion"].Visible = false;
                dvg_detalleVenta.Columns["Unidad"].Visible = false;
                dvg_detalleVenta.Columns["impuesto"].Visible = false;

                string Unidad = dvg_detalleVenta.CurrentRow.Cells[5].Value.ToString();
                lblUnidad.Text = "Unidad: " + Unidad;
                string Descripcion = dvg_detalleVenta.CurrentRow.Cells[4].Value.ToString();
                lblDescr.Text = "Descripcion: " + Descripcion;

                double iva = Convert.ToDouble(modelSelect.impuesto) / 100 + 1;
                double subtotalParcial = Convert.ToInt32(modelSelect.Cantidad) * (modelSelect.PrecioUnitario / iva);
                double subtotalImpuesto = modelSelect.PrecioUnitario - subtotalParcial;
                double Total = subtotalParcial + subtotalImpuesto;

                txtSubTotal.Text = subtotalParcial.ToString("C");
                txtImpuestos.Text = subtotalImpuesto.ToString("C");
                txtTotal.Text = Total.ToString("C");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DetalleDev", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void GuardarDetalle()
        {
            try
            {
                foreach (DM0312_MSolicitudValera item in ModeloDetalle)
                {
                    double costo = controladorP.ExecspVerCosto(suc, item.Articulo, item.Unidad);

                    controladorV.InsertVentaDSolVal(item, idVenta, Canal, cbx_Almacen.Text, cbx_Agente.Text, 5, costo);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("GuardarDetalle", "DM0312_SolicitudValera", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region "EVENTOS"

        private void Cbx_Agente_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(2);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Agente.Items.Clear();
            LlenaAgente();
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || Observacion != txt_Observaciones.Text || Comentario != txt_Comentario.Text))
                ActualizarInfoIdVenta();
            cbx_Agente.Focus();
            SendKeys.Send("{tab}");
        }

        private void Cbx_Cliente_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(1);
            //this.Visible = false;
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Cliente.Items.Clear();
            CargaCliente();

            ValidaCanal();
            if (existe != true) AgregaNuevoCanal();

            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || Observacion != txt_Observaciones.Text || Comentario != txt_Comentario.Text))
                ActualizarInfoIdVenta();
            cbx_Cliente.Focus();
            SendKeys.Send("{tab}");
        }

        private void Cbx_Agente_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && dvg_detalleVenta.Focused == false && cbx_Cliente.Focused == false)
            {
                mensajeValidacion = "";
                ValidaAgente();
                if (obligatorioAgente && lbl_ID.Text == "")
                {
                    componenteValidado = "Agente";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void Cbx_Agente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                componenteValidado = "Agente";
                ValidacionComponentes(componenteValidado);
                if (obligatorioAgente) ComponentesFocus();
            }
        }

        private void Cbx_Almacen_Validating(object sender, CancelEventArgs e)
        {
            if (btn_Regresar.Focused == false && btn_InformacionCliente.Focused == false &&
                btn_ayuda.Focused == false && cbx_Cliente.Focused == false)
            {
                mensajeValidacion = "";
                ValidaAlmacen();
                if (obligatorioAlmacen && lbl_ID.Text == "")
                {
                    componenteValidado = "Almacen";
                    ValidacionComponentes(componenteValidado);
                }
            }
        }

        private void Cbx_Almacen_DropDown(object sender, EventArgs e)
        {
            DM0312_CatalogosPuntoDeVenta catalogo = new DM0312_CatalogosPuntoDeVenta(4);
            catalogo.ShowDialog();
            Visible = true;
            StartPosition = FormStartPosition.CenterScreen;
            cbx_Almacen.Items.Clear();
            LlenaAlmacen();

            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || Observacion != txt_Observaciones.Text || Comentario != txt_Comentario.Text))
                ActualizarInfoIdVenta();
            cbx_Almacen.Focus();
            SendKeys.Send("{tab}");
        }

        private void Cbx_Almacen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                mensajeValidacion = "";
                ValidaAlmacen();
                if (obligatorioAlmacen)
                {
                    componenteValidado = "Almacen";
                    ValidacionComponentes(componenteValidado);
                }

                if (obligatorioAlmacen) ComponentesFocus();
            }

            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void Cbx_Condicion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) cbx_Almacen.Focus();
        }

        private void Cbx_Condicion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "" && (Codigo != Cliente || Agente != Vendedor || Canal != EnviarA ||
                                      Condicion != cbx_Condicion.Text || Alm != Almacen
                                      || Observacion != txt_Observaciones.Text || Comentario != txt_Comentario.Text))
                ActualizarInfoIdVenta();
        }

        private void Btn_InformacionCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbx_Cliente.Text == "")
                {
                    MessageBox.Show("Ingrese un Cliente", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (controladorP.ValidarCliente(cbx_Cliente.Text) == "NO")
                    {
                        MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        cbx_Cliente.Focus();
                    }
                    else
                    {
                        if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                        {
                            Codigo = cbx_Cliente.Text.ToUpper();
                            CargaCliente();
                            ValidarCliente();
                        }

                        InformacionCliente infoCliente = new InformacionCliente
                        {
                            mensaje = cbx_Cliente.Text
                        };
                        infoCliente.Show();
                    }
                }
            }
            catch
            {
                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void Btn_Regresar_Click(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
            {
                if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    EliminarId();
                    Dispose();
                }
            }
            else
            {
                Dispose();
            }
        }

        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
                if (MessageBox.Show("Se perderán los cambios, desea eliminar el registro?", "Confirmar",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    EliminarId();
        }

        private void CopiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(lbl_ID.Text);
        }

        private void Dvg_detalleVenta_SelectionChanged(object sender, EventArgs e)
        {
            int index = dvg_detalleVenta.CurrentRow.Index;

            if (index == -1)
                return;

            modelSelect = new DM0312_MSolicitudValera();

            modelSelect = (DM0312_MSolicitudValera)dvg_detalleVenta.CurrentRow.DataBoundItem;

            dvg_detalleVenta.EndEdit();
        }

        public async void Afectar()
        {
            if (controladorP.ValidarCliente(cbx_Cliente.Text) == "NO")
            {
                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                cbx_Cliente.Focus();
            }
            else
            {
                if (cbx_Cliente.Text.ToUpper() != Codigo || obligatorioCliente == false)
                {
                    Codigo = cbx_Cliente.Text.ToUpper();
                    CargaCliente();
                    ValidarCliente();
                }

                if (obligatorioCliente = true && obligatorioAgente && obligatorioCanal && obligatorioAlmacen)
                {
                    GuardarDetalle();
                    if (dvg_detalleVenta.Rows.Count < 1)
                    {
                        MessageBox.Show("No hay articulos añadidos", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return;
                    }

                    string Canal = EnviarA.ToString();
                    string[] IDyCategoria = CDetalleVenta.ObtenerCategoriaCanal(Canal);
                    int EnteroCategoria = 1;

                    int EnteroEmision = 0;
                    int EnteroVencimiento = 1;
                    string[] FechaEmisionyVencimiento = controladorP.ObtenerFechasParaDetalle(idVenta);

                    double iva = Convert.ToDouble(modelSelect.impuesto) / 100 + 1;
                    double subtotalParcial = Convert.ToInt32(modelSelect.Cantidad) * (modelSelect.PrecioUnitario / iva);
                    double subtotalImpuesto = modelSelect.PrecioUnitario - subtotalParcial;
                    double Total = subtotalParcial + subtotalImpuesto;

                    string[] Parametros =
                    {
                        Movimiento,
                        "", //movID
                        "VTAS",
                        lbl_ID.Text,
                        cbx_Cliente.Text,
                        "SINAFECTAR",
                        EnviarA.ToString(),
                        FechaEmisionyVencimiento[EnteroEmision], //fecha alta
                        ClaseEstatica.Usuario.sucursal.ToString(),
                        cbx_Condicion.Text,
                        IDyCategoria[EnteroCategoria], //categoriaenviarA
                        "", //articulo seleccionado
                        cbx_Almacen.Text,
                        ClaseEstatica.Usuario.Uen.ToString(),
                        "", //origenID
                        "", //referencia orden compra
                        "", //origen
                        Convert.ToString(Math.Round(Total, 2)),
                        "", //mov tipo
                        FechaEmisionyVencimiento[EnteroVencimiento], //vencimiento
                        "", //origen tipo
                        Convert.ToString(Math.Round(subtotalImpuesto, 2)), //impuestos
                        Convert.ToString(Math.Round(subtotalParcial, 2)), //importe
                        "", //origen tipo mov
                        "0", //idecommerce
                        IDyCategoria[EnteroCategoria],
                        string.Empty,
                        string.Empty
                    };

                    string msgPrecaucion = string.Empty;
                    string msgTitulo = "";

                    if (!frmLoading.Visible)
                    {
                        frmLoading.Show(this);
                        CDetalleVenta.DesabilitarControles(false, this);
                    }

                    List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
                    CDetalleVenta.CargaMovimientoCreado(
                        Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                        Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]), VentasSeleccionadas);
                    CDetalleVenta.FromDetalle = true;
                    if (await Task.Run(() => CDetalleVenta.ValidacionesAfectar(Parametros, ref msgPrecaucion)))
                        if (await Task.Run(() => CDetalleVenta.CondicionAfectar(Parametros, ref msgPrecaucion)))
                            if (await Task.Run(
                                    () => CDetalleVenta.Afectar(Parametros, ref msgPrecaucion, ref msgTitulo)))
                            {
                                if (frmLoading.Visible)
                                {
                                    frmLoading.Hide();
                                    CDetalleVenta.DesabilitarControles(true, this);
                                }

                                MessageBox.Show("Movimiento afectado satisfactoriamente", "Exito!",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                if (Canal == "76" || Canal == "80")
                                    if (CDetalleVenta.validarDimaNuevo(idVenta))
                                    {
                                        DM0312_MExploradorVenta mVenta = new DM0312_MExploradorVenta();
                                        mVenta.Agente = Agente;
                                        mVenta.MovId = Parametros[(int)Enums.ParametrosDetallesVenta.MovID];
                                        mVenta.Mov = Parametros[(int)Enums.ParametrosDetallesVenta.Mov];
                                        mVenta.Estatus = Parametros[(int)Enums.ParametrosDetallesVenta.Estatus];
                                        List<string> lsDatos = CDetalleVenta.ObtenerComentarios(
                                            Parametros[(int)Enums.ParametrosDetallesVenta.MovID],
                                            Parametros[(int)Enums.ParametrosDetallesVenta.Mov]);

                                        CDetalleVenta.guardarHistorialDima(mVenta, lsDatos, "PENDIENTE");
                                    }

                                CDetalleVenta.CargaMovimientoCreado(
                                    Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                    Convert.ToInt32(Parametros[(int)Enums.ParametrosDetallesVenta.IDVenta]),
                                    VentasSeleccionadas, true);
                                AbrirDetalle(VentasSeleccionadas);
                            }

                    if (frmLoading.Visible)
                    {
                        frmLoading.Hide();
                        CDetalleVenta.DesabilitarControles(true, this);
                    }

                    if (msgPrecaucion != string.Empty)
                    {
                        string Titulo = "Afectar";
                        if (msgTitulo != string.Empty) Titulo = "Error: " + msgTitulo;
                        MessageBox.Show(msgPrecaucion, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void Btn_Afecta_Click(object sender, EventArgs e)
        {
            //////////TipoDima///////////////////
            if (Canal == 76 || Canal == 80)
                //if (controladorP.validaCasa(Codigo, Canal) == "Nuevo")
                //{
                //    controladorP.UpdateTipoDima(Codigo);
                //}
                //-TipoDima ↓ 2019-05-25
                if (controladorP.ValorTipoDIMA(Codigo) == "")
                    controladorP.UpdateTipoDima(Codigo, Canal == 76 ? "Normal" : "Dima Ranch");
            Afectar();
        }

        /// <summary>
        ///     Abre el detalle del mov afectado / creado
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void AbrirDetalle(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_ExploradorVentas.ListaExplorador = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
            controllerExplorador.LLenadoListaArticulosSeleccionados(VentasSeleccionadas);
            DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
            if (Alm.Trim() != almacenOrigen.Trim())
            {
                PuntoDeVenta.ActualizarAlmacen = true;
                PuntoDeVenta.Alm = Alm;
            }

            CerrarVenta = true;
            Close();
            detalle.Show();
            detalle.TopMost = true;
            detalle.Focus();
        }

        #endregion

        #region Comentarios

        private void cbx_Cliente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Cliente =
                ComentariosSolValera.Where(x => x.Campo.Equals("Cliente")).FirstOrDefault();
            if (Cliente != null) txt_Comentarios.Text = Cliente.Comentario;
        }

        private void cbx_Agente_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta
                Agente = ComentariosSolValera.Where(x => x.Campo.Equals("Agente")).FirstOrDefault();
            if (Agente != null) txt_Comentarios.Text = Agente.Comentario;
        }

        private void cbx_Condicion_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Condicion =
                ComentariosSolValera.Where(x => x.Campo.Equals("Condicion")).FirstOrDefault();
            if (Condicion != null) txt_Comentarios.Text = Condicion.Comentario;
        }

        private void cbx_Almacen_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Almacen =
                ComentariosSolValera.Where(x => x.Campo.Equals("Almacen")).FirstOrDefault();
            if (Almacen != null) txt_Comentarios.Text = Almacen.Comentario;
        }

        private void txt_Observaciones_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Observaciones =
                ComentariosSolValera.Where(x => x.Campo.Equals("Observaciones")).FirstOrDefault();
            if (Observaciones != null) txt_Comentarios.Text = Observaciones.Comentario;
        }

        private void txt_Comentario_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Comentario =
                ComentariosSolValera.Where(x => x.Campo.Equals("Comentario")).FirstOrDefault();
            if (Comentario != null) txt_Comentarios.Text = Comentario.Comentario;
        }

        private void dvg_detalleVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DM0312_MComentariosVenta TablaValera =
                ComentariosSolValera.Where(x => x.Campo.Equals("TablaValera")).FirstOrDefault();
            if (TablaValera != null) txt_Comentarios.Text = TablaValera.Comentario;
        }

        #endregion
    }
}