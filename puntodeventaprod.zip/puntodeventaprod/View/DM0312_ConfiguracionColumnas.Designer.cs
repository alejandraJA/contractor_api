﻿namespace PuntoVenta
{
    partial class ConfiguracionColumnas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfiguracionColumnas));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbx_Eventos = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.chk_gris = new System.Windows.Forms.CheckBox();
            this.chk_Verde = new System.Windows.Forms.CheckBox();
            this.chk_Azul = new System.Windows.Forms.CheckBox();
            this.btnDownPosition = new System.Windows.Forms.Button();
            this.btn_UpPosition = new System.Windows.Forms.Button();
            this.btn_Quitar = new System.Windows.Forms.Button();
            this.btn_Agregar = new System.Windows.Forms.Button();
            this.data_GridColumnaUso = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.data_GridColumnas = new System.Windows.Forms.DataGridView();
            this.ColumnasDisponibles = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.Aceptar = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gbx_Eventos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_GridColumnaUso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_GridColumnas)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Eventos
            // 
            this.gbx_Eventos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.gbx_Eventos.BackColor = System.Drawing.Color.White;
            this.gbx_Eventos.Controls.Add(this.textBox1);
            this.gbx_Eventos.Controls.Add(this.chk_gris);
            this.gbx_Eventos.Controls.Add(this.chk_Verde);
            this.gbx_Eventos.Controls.Add(this.chk_Azul);
            this.gbx_Eventos.Controls.Add(this.btnDownPosition);
            this.gbx_Eventos.Controls.Add(this.btn_UpPosition);
            this.gbx_Eventos.Controls.Add(this.btn_Quitar);
            this.gbx_Eventos.Controls.Add(this.btn_Agregar);
            this.gbx_Eventos.Controls.Add(this.data_GridColumnaUso);
            this.gbx_Eventos.Controls.Add(this.data_GridColumnas);
            this.gbx_Eventos.Location = new System.Drawing.Point(81, 75);
            this.gbx_Eventos.Name = "gbx_Eventos";
            this.gbx_Eventos.Size = new System.Drawing.Size(949, 433);
            this.gbx_Eventos.TabIndex = 14;
            this.gbx_Eventos.TabStop = false;
            this.gbx_Eventos.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_Eventos_Paint);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(728, 19);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(221, 55);
            this.textBox1.TabIndex = 110;
            this.textBox1.Text = "CONFIGURACION DEL COLOR DEL SELECCIONADOR DE CADA TABLA DE CADA UNA DE LAS FORMAS" +
    "";
            // 
            // chk_gris
            // 
            this.chk_gris.AutoSize = true;
            this.chk_gris.BackColor = System.Drawing.Color.Gray;
            this.chk_gris.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_gris.Location = new System.Drawing.Point(801, 181);
            this.chk_gris.Name = "chk_gris";
            this.chk_gris.Size = new System.Drawing.Size(57, 23);
            this.chk_gris.TabIndex = 9;
            this.chk_gris.Text = "Gris";
            this.chk_gris.UseVisualStyleBackColor = false;
            this.chk_gris.CheckedChanged += new System.EventHandler(this.chk_gris_CheckedChanged);
            // 
            // chk_Verde
            // 
            this.chk_Verde.AutoSize = true;
            this.chk_Verde.BackColor = System.Drawing.Color.CadetBlue;
            this.chk_Verde.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Verde.Location = new System.Drawing.Point(801, 142);
            this.chk_Verde.Name = "chk_Verde";
            this.chk_Verde.Size = new System.Drawing.Size(68, 23);
            this.chk_Verde.TabIndex = 8;
            this.chk_Verde.Text = "Verde";
            this.chk_Verde.UseVisualStyleBackColor = false;
            this.chk_Verde.CheckedChanged += new System.EventHandler(this.chk_Verde_CheckedChanged);
            // 
            // chk_Azul
            // 
            this.chk_Azul.AutoSize = true;
            this.chk_Azul.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.chk_Azul.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Azul.Location = new System.Drawing.Point(801, 102);
            this.chk_Azul.Name = "chk_Azul";
            this.chk_Azul.Size = new System.Drawing.Size(57, 23);
            this.chk_Azul.TabIndex = 7;
            this.chk_Azul.Text = "Azul";
            this.chk_Azul.UseVisualStyleBackColor = false;
            this.chk_Azul.CheckedChanged += new System.EventHandler(this.chk_Azul_CheckedChanged);
            // 
            // btnDownPosition
            // 
            this.btnDownPosition.BackColor = System.Drawing.Color.White;
            this.btnDownPosition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDownPosition.FlatAppearance.BorderSize = 0;
            this.btnDownPosition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownPosition.Image = global::PuntoVenta.Properties.Resources.DownArrow;
            this.btnDownPosition.Location = new System.Drawing.Point(614, 130);
            this.btnDownPosition.Name = "btnDownPosition";
            this.btnDownPosition.Size = new System.Drawing.Size(75, 46);
            this.btnDownPosition.TabIndex = 5;
            this.btnDownPosition.UseVisualStyleBackColor = false;
            this.btnDownPosition.Click += new System.EventHandler(this.btnDownPosition_Click);
            // 
            // btn_UpPosition
            // 
            this.btn_UpPosition.BackColor = System.Drawing.Color.White;
            this.btn_UpPosition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_UpPosition.FlatAppearance.BorderSize = 0;
            this.btn_UpPosition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UpPosition.Image = global::PuntoVenta.Properties.Resources.upArrow;
            this.btn_UpPosition.Location = new System.Drawing.Point(614, 78);
            this.btn_UpPosition.Name = "btn_UpPosition";
            this.btn_UpPosition.Size = new System.Drawing.Size(75, 46);
            this.btn_UpPosition.TabIndex = 4;
            this.btn_UpPosition.UseVisualStyleBackColor = false;
            this.btn_UpPosition.Click += new System.EventHandler(this.btn_UpPosition_Click);
            // 
            // btn_Quitar
            // 
            this.btn_Quitar.BackColor = System.Drawing.Color.White;
            this.btn_Quitar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Quitar.FlatAppearance.BorderSize = 0;
            this.btn_Quitar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Quitar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Quitar.Image")));
            this.btn_Quitar.Location = new System.Drawing.Point(256, 130);
            this.btn_Quitar.Name = "btn_Quitar";
            this.btn_Quitar.Size = new System.Drawing.Size(75, 46);
            this.btn_Quitar.TabIndex = 3;
            this.btn_Quitar.UseVisualStyleBackColor = false;
            this.btn_Quitar.Click += new System.EventHandler(this.btn_Quitar_Click_2);
            // 
            // btn_Agregar
            // 
            this.btn_Agregar.BackColor = System.Drawing.Color.White;
            this.btn_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Agregar.FlatAppearance.BorderSize = 0;
            this.btn_Agregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Agregar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Agregar.Image")));
            this.btn_Agregar.Location = new System.Drawing.Point(256, 78);
            this.btn_Agregar.Name = "btn_Agregar";
            this.btn_Agregar.Size = new System.Drawing.Size(75, 46);
            this.btn_Agregar.TabIndex = 2;
            this.btn_Agregar.UseVisualStyleBackColor = false;
            this.btn_Agregar.Click += new System.EventHandler(this.btn_Agregar_Click_1);
            // 
            // data_GridColumnaUso
            // 
            this.data_GridColumnaUso.AllowUserToAddRows = false;
            this.data_GridColumnaUso.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.data_GridColumnaUso.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.data_GridColumnaUso.BackgroundColor = System.Drawing.Color.Snow;
            this.data_GridColumnaUso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.data_GridColumnaUso.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.data_GridColumnaUso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_GridColumnaUso.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.data_GridColumnaUso.EnableHeadersVisualStyles = false;
            this.data_GridColumnaUso.Location = new System.Drawing.Point(360, 19);
            this.data_GridColumnaUso.Name = "data_GridColumnaUso";
            this.data_GridColumnaUso.ReadOnly = true;
            this.data_GridColumnaUso.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.data_GridColumnaUso.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.data_GridColumnaUso.Size = new System.Drawing.Size(222, 369);
            this.data_GridColumnaUso.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Columnas en Uso";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // data_GridColumnas
            // 
            this.data_GridColumnas.AllowUserToAddRows = false;
            this.data_GridColumnas.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.data_GridColumnas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.data_GridColumnas.BackgroundColor = System.Drawing.Color.Snow;
            this.data_GridColumnas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.data_GridColumnas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.data_GridColumnas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_GridColumnas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnasDisponibles});
            this.data_GridColumnas.EnableHeadersVisualStyles = false;
            this.data_GridColumnas.Location = new System.Drawing.Point(6, 19);
            this.data_GridColumnas.Name = "data_GridColumnas";
            this.data_GridColumnas.ReadOnly = true;
            this.data_GridColumnas.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.data_GridColumnas.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.data_GridColumnas.Size = new System.Drawing.Size(223, 369);
            this.data_GridColumnas.TabIndex = 0;
            // 
            // ColumnasDisponibles
            // 
            this.ColumnasDisponibles.FillWeight = 120F;
            this.ColumnasDisponibles.HeaderText = "Columnas Disponibles";
            this.ColumnasDisponibles.Name = "ColumnasDisponibles";
            this.ColumnasDisponibles.ReadOnly = true;
            this.ColumnasDisponibles.Width = 200;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(3, 75);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(63, 69);
            this.btn_Regresar.TabIndex = 14;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // Aceptar
            // 
            this.Aceptar.BackColor = System.Drawing.Color.White;
            this.Aceptar.FlatAppearance.BorderSize = 0;
            this.Aceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aceptar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aceptar.Image = ((System.Drawing.Image)(resources.GetObject("Aceptar.Image")));
            this.Aceptar.Location = new System.Drawing.Point(3, 3);
            this.Aceptar.Name = "Aceptar";
            this.Aceptar.Size = new System.Drawing.Size(63, 65);
            this.Aceptar.TabIndex = 0;
            this.Aceptar.Text = "Aceptar (Crtl-G)";
            this.Aceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Aceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Aceptar.UseVisualStyleBackColor = false;
            this.Aceptar.Click += new System.EventHandler(this.Aceptar_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(76, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(825, 65);
            this.txt_Comentarios.TabIndex = 108;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.106599F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 92.8934F));
            this.tableLayoutPanel1.Controls.Add(this.Aceptar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txt_Comentarios, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_Regresar, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.gbx_Eventos, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.09002F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85.90998F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1038, 511);
            this.tableLayoutPanel1.TabIndex = 109;
            // 
            // ConfiguracionColumnas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1038, 511);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "ConfiguracionColumnas";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuracion de Columnas";
            this.Load += new System.EventHandler(this.ConfiguracionColumnas_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ConfiguracionColumnas_KeyDown);
            this.gbx_Eventos.ResumeLayout(false);
            this.gbx_Eventos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_GridColumnaUso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_GridColumnas)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Aceptar;
        private System.Windows.Forms.GroupBox gbx_Eventos;
        private System.Windows.Forms.Button btn_Quitar;
        private System.Windows.Forms.Button btn_Agregar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        public System.Windows.Forms.DataGridView data_GridColumnaUso;
        public System.Windows.Forms.DataGridView data_GridColumnas;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnasDisponibles;
        private System.Windows.Forms.Button btnDownPosition;
        private System.Windows.Forms.Button btn_UpPosition;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.CheckBox chk_gris;
        private System.Windows.Forms.CheckBox chk_Verde;
        private System.Windows.Forms.CheckBox chk_Azul;
        private System.Windows.Forms.TextBox textBox1;
    }
}