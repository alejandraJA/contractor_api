﻿namespace PuntoVenta
{
    partial class DM0312_DetalleInformacionArticulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_DetalleInformacionArticulo));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_linea = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_CategoriaAF = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_IVA = new System.Windows.Forms.TextBox();
            this.txt_Estatus = new System.Windows.Forms.TextBox();
            this.txt_Familia = new System.Windows.Forms.TextBox();
            this.txt_Tipo = new System.Windows.Forms.TextBox();
            this.txt_UnidadVenta = new System.Windows.Forms.TextBox();
            this.txt_Categoria = new System.Windows.Forms.TextBox();
            this.txt_Descripcion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gpx_articulos = new System.Windows.Forms.GroupBox();
            this.lblNoArticulos = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv_Almacenes = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbl_mavi = new System.Windows.Forms.Label();
            this.lbl_todos = new System.Windows.Forms.Label();
            this.lbl_bodega = new System.Windows.Forms.Label();
            this.lbl_viu = new System.Windows.Forms.Label();
            this.txt_TotalDisponible = new System.Windows.Forms.TextBox();
            this.txt_totalTransito = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.lbl_total = new System.Windows.Forms.Label();
            this.lbl_transito = new System.Windows.Forms.Label();
            this.lbl_disponible = new System.Windows.Forms.Label();
            this.lbl_codigoArticulo = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btn_VentaPendiente = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.gpx_articulos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Almacenes)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_linea);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_CategoriaAF);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_IVA);
            this.groupBox1.Controls.Add(this.txt_Estatus);
            this.groupBox1.Controls.Add(this.txt_Familia);
            this.groupBox1.Controls.Add(this.txt_Tipo);
            this.groupBox1.Controls.Add(this.txt_UnidadVenta);
            this.groupBox1.Controls.Add(this.txt_Categoria);
            this.groupBox1.Controls.Add(this.txt_Descripcion);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(88, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(771, 144);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox1, "INFORMACIN IMPORTANTE DEL ARTICULO A VENDER");
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
            // 
            // txt_linea
            // 
            this.txt_linea.BackColor = System.Drawing.Color.White;
            this.txt_linea.Enabled = false;
            this.txt_linea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_linea.Location = new System.Drawing.Point(583, 60);
            this.txt_linea.Name = "txt_linea";
            this.txt_linea.Size = new System.Drawing.Size(150, 22);
            this.txt_linea.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(536, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 15);
            this.label10.TabIndex = 18;
            this.label10.Text = "Linea ";
            // 
            // txt_CategoriaAF
            // 
            this.txt_CategoriaAF.BackColor = System.Drawing.Color.White;
            this.txt_CategoriaAF.Enabled = false;
            this.txt_CategoriaAF.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CategoriaAF.Location = new System.Drawing.Point(466, 93);
            this.txt_CategoriaAF.Name = "txt_CategoriaAF";
            this.txt_CategoriaAF.Size = new System.Drawing.Size(119, 22);
            this.txt_CategoriaAF.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(384, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Categoria Af";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(236, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Iva";
            // 
            // txt_IVA
            // 
            this.txt_IVA.BackColor = System.Drawing.Color.White;
            this.txt_IVA.Enabled = false;
            this.txt_IVA.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IVA.Location = new System.Drawing.Point(283, 92);
            this.txt_IVA.Name = "txt_IVA";
            this.txt_IVA.Size = new System.Drawing.Size(81, 22);
            this.txt_IVA.TabIndex = 7;
            // 
            // txt_Estatus
            // 
            this.txt_Estatus.BackColor = System.Drawing.Color.White;
            this.txt_Estatus.Enabled = false;
            this.txt_Estatus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Estatus.Location = new System.Drawing.Point(656, 92);
            this.txt_Estatus.Name = "txt_Estatus";
            this.txt_Estatus.Size = new System.Drawing.Size(77, 22);
            this.txt_Estatus.TabIndex = 9;
            // 
            // txt_Familia
            // 
            this.txt_Familia.BackColor = System.Drawing.Color.White;
            this.txt_Familia.Enabled = false;
            this.txt_Familia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Familia.Location = new System.Drawing.Point(283, 60);
            this.txt_Familia.Name = "txt_Familia";
            this.txt_Familia.Size = new System.Drawing.Size(247, 22);
            this.txt_Familia.TabIndex = 4;
            // 
            // txt_Tipo
            // 
            this.txt_Tipo.BackColor = System.Drawing.Color.White;
            this.txt_Tipo.Enabled = false;
            this.txt_Tipo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Tipo.Location = new System.Drawing.Point(656, 26);
            this.txt_Tipo.Name = "txt_Tipo";
            this.txt_Tipo.Size = new System.Drawing.Size(77, 22);
            this.txt_Tipo.TabIndex = 2;
            // 
            // txt_UnidadVenta
            // 
            this.txt_UnidadVenta.BackColor = System.Drawing.Color.White;
            this.txt_UnidadVenta.Enabled = false;
            this.txt_UnidadVenta.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_UnidadVenta.Location = new System.Drawing.Point(99, 92);
            this.txt_UnidadVenta.Name = "txt_UnidadVenta";
            this.txt_UnidadVenta.Size = new System.Drawing.Size(120, 22);
            this.txt_UnidadVenta.TabIndex = 6;
            // 
            // txt_Categoria
            // 
            this.txt_Categoria.BackColor = System.Drawing.Color.White;
            this.txt_Categoria.Enabled = false;
            this.txt_Categoria.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Categoria.Location = new System.Drawing.Point(99, 60);
            this.txt_Categoria.Name = "txt_Categoria";
            this.txt_Categoria.Size = new System.Drawing.Size(120, 22);
            this.txt_Categoria.TabIndex = 3;
            // 
            // txt_Descripcion
            // 
            this.txt_Descripcion.BackColor = System.Drawing.Color.White;
            this.txt_Descripcion.Enabled = false;
            this.txt_Descripcion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Descripcion.Location = new System.Drawing.Point(99, 26);
            this.txt_Descripcion.Name = "txt_Descripcion";
            this.txt_Descripcion.Size = new System.Drawing.Size(487, 22);
            this.txt_Descripcion.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(231, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Familia ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(600, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Estatus ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Unidad Venta ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(603, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tipo ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Categoria ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Descripcion ";
            // 
            // gpx_articulos
            // 
            this.gpx_articulos.Controls.Add(this.lblNoArticulos);
            this.gpx_articulos.Controls.Add(this.label8);
            this.gpx_articulos.Controls.Add(this.dgv_Almacenes);
            this.gpx_articulos.Controls.Add(this.groupBox3);
            this.gpx_articulos.Controls.Add(this.txt_TotalDisponible);
            this.gpx_articulos.Controls.Add(this.txt_totalTransito);
            this.gpx_articulos.Controls.Add(this.txt_total);
            this.gpx_articulos.Controls.Add(this.lbl_total);
            this.gpx_articulos.Controls.Add(this.lbl_transito);
            this.gpx_articulos.Controls.Add(this.lbl_disponible);
            this.gpx_articulos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpx_articulos.Location = new System.Drawing.Point(88, 187);
            this.gpx_articulos.Name = "gpx_articulos";
            this.gpx_articulos.Size = new System.Drawing.Size(771, 234);
            this.gpx_articulos.TabIndex = 1;
            this.gpx_articulos.TabStop = false;
            this.toolTip1.SetToolTip(this.gpx_articulos, "EXISTENCIAS DEL ARTICULO SELECCIONADO EN LOS DISTINTOS ALMACENES DE LA EMPRESA");
            this.gpx_articulos.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox2_Paint);
            // 
            // lblNoArticulos
            // 
            this.lblNoArticulos.AutoSize = true;
            this.lblNoArticulos.Location = new System.Drawing.Point(104, 58);
            this.lblNoArticulos.Name = "lblNoArticulos";
            this.lblNoArticulos.Size = new System.Drawing.Size(72, 15);
            this.lblNoArticulos.TabIndex = 19;
            this.lblNoArticulos.Text = "Cargando....";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 15);
            this.label8.TabIndex = 4;
            // 
            // dgv_Almacenes
            // 
            this.dgv_Almacenes.AllowUserToAddRows = false;
            this.dgv_Almacenes.AllowUserToDeleteRows = false;
            this.dgv_Almacenes.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Almacenes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Almacenes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Almacenes.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv_Almacenes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Almacenes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_Almacenes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Almacenes.EnableHeadersVisualStyles = false;
            this.dgv_Almacenes.Location = new System.Drawing.Point(108, 20);
            this.dgv_Almacenes.Name = "dgv_Almacenes";
            this.dgv_Almacenes.ReadOnly = true;
            this.dgv_Almacenes.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_Almacenes.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_Almacenes.Size = new System.Drawing.Size(625, 150);
            this.dgv_Almacenes.TabIndex = 10;
            this.dgv_Almacenes.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Dgv_Almacenes_ColumnHeaderMouseClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbl_mavi);
            this.groupBox3.Controls.Add(this.lbl_todos);
            this.groupBox3.Controls.Add(this.lbl_bodega);
            this.groupBox3.Controls.Add(this.lbl_viu);
            this.groupBox3.Location = new System.Drawing.Point(12, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(86, 140);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Almacenes";
            // 
            // lbl_mavi
            // 
            this.lbl_mavi.AutoSize = true;
            this.lbl_mavi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_mavi.Location = new System.Drawing.Point(6, 28);
            this.lbl_mavi.Name = "lbl_mavi";
            this.lbl_mavi.Size = new System.Drawing.Size(41, 15);
            this.lbl_mavi.TabIndex = 5;
            this.lbl_mavi.Text = "MAVI ";
            this.lbl_mavi.Click += new System.EventHandler(this.SeleccionaAlmacen);
            // 
            // lbl_todos
            // 
            this.lbl_todos.AutoSize = true;
            this.lbl_todos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_todos.Location = new System.Drawing.Point(6, 107);
            this.lbl_todos.Name = "lbl_todos";
            this.lbl_todos.Size = new System.Drawing.Size(52, 15);
            this.lbl_todos.TabIndex = 4;
            this.lbl_todos.Text = "TODOS";
            this.lbl_todos.Click += new System.EventHandler(this.SeleccionaAlmacen);
            // 
            // lbl_bodega
            // 
            this.lbl_bodega.AutoSize = true;
            this.lbl_bodega.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_bodega.Location = new System.Drawing.Point(6, 77);
            this.lbl_bodega.Name = "lbl_bodega";
            this.lbl_bodega.Size = new System.Drawing.Size(62, 15);
            this.lbl_bodega.TabIndex = 3;
            this.lbl_bodega.Text = "BODEGA ";
            this.lbl_bodega.Click += new System.EventHandler(this.SeleccionaAlmacen);
            // 
            // lbl_viu
            // 
            this.lbl_viu.AutoSize = true;
            this.lbl_viu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_viu.Location = new System.Drawing.Point(6, 51);
            this.lbl_viu.Name = "lbl_viu";
            this.lbl_viu.Size = new System.Drawing.Size(31, 15);
            this.lbl_viu.TabIndex = 2;
            this.lbl_viu.Text = "VIU ";
            this.lbl_viu.Click += new System.EventHandler(this.SeleccionaAlmacen);
            // 
            // txt_TotalDisponible
            // 
            this.txt_TotalDisponible.BackColor = System.Drawing.Color.White;
            this.txt_TotalDisponible.Enabled = false;
            this.txt_TotalDisponible.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TotalDisponible.Location = new System.Drawing.Point(200, 186);
            this.txt_TotalDisponible.Name = "txt_TotalDisponible";
            this.txt_TotalDisponible.Size = new System.Drawing.Size(100, 22);
            this.txt_TotalDisponible.TabIndex = 11;
            this.txt_TotalDisponible.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_totalTransito
            // 
            this.txt_totalTransito.BackColor = System.Drawing.Color.White;
            this.txt_totalTransito.Enabled = false;
            this.txt_totalTransito.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_totalTransito.Location = new System.Drawing.Point(411, 183);
            this.txt_totalTransito.Name = "txt_totalTransito";
            this.txt_totalTransito.Size = new System.Drawing.Size(100, 22);
            this.txt_totalTransito.TabIndex = 12;
            this.txt_totalTransito.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_total
            // 
            this.txt_total.BackColor = System.Drawing.Color.White;
            this.txt_total.Enabled = false;
            this.txt_total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.Location = new System.Drawing.Point(583, 183);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(100, 22);
            this.txt_total.TabIndex = 13;
            this.txt_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.BackColor = System.Drawing.Color.White;
            this.lbl_total.Location = new System.Drawing.Point(526, 186);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(37, 15);
            this.lbl_total.TabIndex = 4;
            this.lbl_total.Text = "Total ";
            // 
            // lbl_transito
            // 
            this.lbl_transito.AutoSize = true;
            this.lbl_transito.Location = new System.Drawing.Point(321, 186);
            this.lbl_transito.Name = "lbl_transito";
            this.lbl_transito.Size = new System.Drawing.Size(86, 15);
            this.lbl_transito.TabIndex = 3;
            this.lbl_transito.Text = "Total Transito ";
            // 
            // lbl_disponible
            // 
            this.lbl_disponible.AutoSize = true;
            this.lbl_disponible.Location = new System.Drawing.Point(105, 190);
            this.lbl_disponible.Name = "lbl_disponible";
            this.lbl_disponible.Size = new System.Drawing.Size(98, 15);
            this.lbl_disponible.TabIndex = 2;
            this.lbl_disponible.Text = "Total Disponible ";
            // 
            // lbl_codigoArticulo
            // 
            this.lbl_codigoArticulo.AutoSize = true;
            this.lbl_codigoArticulo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_codigoArticulo.Location = new System.Drawing.Point(757, 19);
            this.lbl_codigoArticulo.Name = "lbl_codigoArticulo";
            this.lbl_codigoArticulo.Size = new System.Drawing.Size(64, 15);
            this.lbl_codigoArticulo.TabIndex = 2;
            this.lbl_codigoArticulo.Text = "CodigoArt";
            // 
            // btn_VentaPendiente
            // 
            this.btn_VentaPendiente.BackColor = System.Drawing.Color.White;
            this.btn_VentaPendiente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_VentaPendiente.FlatAppearance.BorderSize = 0;
            this.btn_VentaPendiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_VentaPendiente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_VentaPendiente.Image = global::PuntoVenta.Properties.Resources.System_Info_icon;
            this.btn_VentaPendiente.Location = new System.Drawing.Point(0, 125);
            this.btn_VentaPendiente.Name = "btn_VentaPendiente";
            this.btn_VentaPendiente.Size = new System.Drawing.Size(82, 83);
            this.btn_VentaPendiente.TabIndex = 16;
            this.btn_VentaPendiente.Text = "Ventas pendientes";
            this.btn_VentaPendiente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_VentaPendiente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_VentaPendiente.UseVisualStyleBackColor = false;
            this.btn_VentaPendiente.Click += new System.EventHandler(this.btn_VentaPendiente_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(0, 214);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(82, 65);
            this.btn_ayuda.TabIndex = 15;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(0, 45);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(82, 74);
            this.btn_Regresar.TabIndex = 14;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.Btn_Regresar_Click);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(88, -2);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(623, 43);
            this.txt_Comentarios.TabIndex = 115;
            // 
            // DM0312_DetalleInformacionArticulo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(866, 428);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.btn_VentaPendiente);
            this.Controls.Add(this.btn_ayuda);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.lbl_codigoArticulo);
            this.Controls.Add(this.gpx_articulos);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "DM0312_DetalleInformacionArticulo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Informacion del Articulo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_DetalleInformacionArticulo_FormClosing);
            this.Load += new System.EventHandler(this.InfoArticulo_Load);
            this.LocationChanged += new System.EventHandler(this.DM0312_DetalleInformacionArticulo_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_DetalleInformacionArticulo_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gpx_articulos.ResumeLayout(false);
            this.gpx_articulos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Almacenes)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_linea;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_CategoriaAF;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_IVA;
        private System.Windows.Forms.TextBox txt_Estatus;
        private System.Windows.Forms.TextBox txt_Familia;
        private System.Windows.Forms.TextBox txt_Tipo;
        private System.Windows.Forms.TextBox txt_UnidadVenta;
        private System.Windows.Forms.TextBox txt_Categoria;
        private System.Windows.Forms.TextBox txt_Descripcion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gpx_articulos;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_mavi;
        private System.Windows.Forms.Label lbl_todos;
        private System.Windows.Forms.Label lbl_bodega;
        private System.Windows.Forms.Label lbl_viu;
        private System.Windows.Forms.TextBox txt_TotalDisponible;
        private System.Windows.Forms.TextBox txt_totalTransito;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label lbl_transito;
        private System.Windows.Forms.Label lbl_disponible;
        private System.Windows.Forms.Label lbl_codigoArticulo;
        private System.Windows.Forms.DataGridView dgv_Almacenes;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.Label lblNoArticulos;
        private System.Windows.Forms.Button btn_VentaPendiente;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.ToolTip toolTip2;
    }
}