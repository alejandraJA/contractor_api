﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Conversiones;
using PuntoVenta.Controller;
using PuntoVenta.Model.Enumeradores;

namespace PuntoVenta.View
{
    public partial class DM0312_LineaCredito : Form
    {
        //-Dineralia
        public bool bDineralia;
        public string Cliente;
        private readonly DM0312_C_Prospecto_A_Cliente cnn;

        private readonly Conv conversion = new Conv();
        public string CredEspecial;

        private bool flag;
        public double Importe;
        public List<string> PoliticasCredito = new List<string>();

        public DM0312_LineaCredito()
        {
            InitializeComponent();
            cnn = new DM0312_C_Prospecto_A_Cliente();
        }

        ~DM0312_LineaCredito()
        {
            GC.Collect();
        }

        private void DM0312_LineaCredito_Load(object sender, EventArgs e)
        {
            bDineralia = cnn.validarDineraliaCliente(Cliente);
            int iOpcion = 1;
            if (bDineralia) iOpcion = 2;
            llenarComboImporte(iOpcion);
            LlenarCreditoEspecial();
            if (!bDineralia)
            {
                LlenarPoliticaCredito();
            }
            else
            {
                PoliticasCredito = new List<string>();
                PoliticasCredito.Add("DINERALIA");
                if (PoliticasCredito.Count > 0)
                {
                    cbx_PoliticaCred.DataSource = null;
                    cbx_PoliticaCred.DataSource = PoliticasCredito.ToArray();
                }
            }
        }

        private void txtImporte_Click(object sender, EventArgs e)
        {
            txtImporte.SelectionStart = 0;

            txtImporte.SelectionLength = txtImporte.Text.Length;
        }

        //-CreditoEmpresario
        private void cmbImporte_DropDownClosed(object sender, EventArgs e)
        {
            int id = int.Parse(cmbImporte.SelectedValue.ToString());
            string politica = cnn.GetDescripcionLineaCredito(id);
            notaTxt.Text = politica;
        }


        #region Metodos

        private void llenarComboImporte(int iOpcion)
        {
            IDictionary<int, double> datos = new Dictionary<int, double>();

            datos = cnn.GetLineaCredito(iOpcion);

            cmbImporte.DataSource = null;
            cmbImporte.DataSource = datos.ToList();
            cmbImporte.DisplayMember = "Value";
            cmbImporte.ValueMember = "Key";

            string politica = cnn.GetDescripcionLineaCredito(int.Parse(cmbImporte.SelectedValue.ToString()));
            notaTxt.Text = politica;
        }

        private void LlenarPoliticaCredito()
        {
            PoliticasCredito = new List<string>();
            PoliticasCredito = cnn.LlenaPoliticas();
            if (PoliticasCredito.Count > 0)
            {
                cbx_PoliticaCred.DataSource = null;
                cbx_PoliticaCred.DataSource = PoliticasCredito.ToArray();
            }
        }


        private void LlenarCreditoEspecial()
        {
            cmbCredSpe.DataSource = Enum.GetValues(typeof(Enums.Contactos));
        }

        private bool Fn_txtImporte()
        {
            string txt = txtImporte.Text;

            if (txt == string.Empty)
                return false;

            double importe = conversion.ConvertFormatMoney(txtImporte.Text, false);

            if (importe == 0)
                return false;

            return true;
        }

        #endregion


        #region Eventos

        private void txtImporte_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtImporte.Text.Contains("."))
            {
                if (e.KeyChar.ToString() == ".")
                {
                    e.Handled = true;
                    return;
                }
            }
            else
            {
                if ((e.KeyChar.ToString() == ".") & (txtImporte.Text.Length == 0))
                {
                    e.Handled = true;
                    return;
                }
            }

            if (char.IsDigit(e.KeyChar) || e.KeyChar.ToString() == ".")
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;

            //if (Char.IsDigit(e.KeyChar))
            //{
            //    e.Handled = false;
            //}
            //else
            //    if (Char.IsControl(e.KeyChar)) 
            //    {
            //        e.Handled = false;
            //    }
            //    else
            //    {
            //        e.Handled = true;
            //    } 
        }

        private void DM0312_LineaCredito_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!flag)
            {
                e.Cancel = true;
                MessageBox.Show("Tiene que guardar la información", "Error!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (Fn_txtImporte())
                Importe = conversion.ConvertFormatMoney(txtImporte.Text);
            else
                Importe = double.Parse(cmbImporte.Text);

            if (bDineralia)
                if (!cnn.validarLineaCredito(Importe))
                {
                    MessageBox.Show("El importe es mayor al configurado para dineralia", "Dineralia",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            cnn.InsertPolitica(Cliente, cbx_PoliticaCred.Text);
            if (bDineralia) cnn.actualizarMonto(Cliente, Importe);
            CredEspecial = cmbCredSpe.SelectedItem.ToString();
            flag = true;
            Close();
        }

        private void txtImporte_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtImporte.Text))
            {
                double importe = conversion.ConvertFormatMoney(txtImporte.Text);


                txtImporte.Text = importe.ToString("C", Thread.CurrentThread.CurrentCulture);
            }
            else
            {
                txtImporte.Text = "$0.0";
            }
        }

        private void txtImporte_Enter(object sender, EventArgs e)
        {
            txtImporte.Text =
                conversion.ConvertFormatMoney(txtImporte.Text).ToString(); //txtRediImporte.Text.Replace("$", "");

            txtImporte.SelectionStart = 0;

            txtImporte.SelectionLength = txtImporte.Text.Length;
        }

        #endregion
    }
}