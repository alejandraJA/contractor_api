﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta
{
    public partial class CatalogoDeCalificaciones : Form
    {
        private readonly DM0312_C_CatalogoCalificaciones cat = new DM0312_C_CatalogoCalificaciones();

        public CatalogoDeCalificaciones()
        {
            InitializeComponent();
        }

        ~CatalogoDeCalificaciones()
        {
            GC.Collect();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void CatalogoDeCalificaciones_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(btn_Regresar, "REGRESAR AL EXPLORADOR DE VENTAS");
            toolTip1.SetToolTip(btn_ayuda, "SELECCIONAR PARA VER EL MANUAL DE USUARIO DE LA FORMA");
            DatosCatalogoCalificaciones();
            dgv_CatalogoCalificaciones.Select();
            textBox1.Text = "FORMA LA CUAL MUESTRA LAS CLAVES DE EVENTOS CON LA DESCRIPCCION DE CADA UNA";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_CatalogoCalificaciones.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_CatalogoCalificaciones.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_CatalogoCalificaciones.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_CatalogoCalificaciones.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        #region Metodos

        public void DatosCatalogoCalificaciones()
        {
            try
            {
                DataTable dataSet = new DataTable();
                dataSet = cat.CatalagoCalifiaciones(txt_Buscar.Text);
                dgv_CatalogoCalificaciones.DataSource = null;
                dgv_CatalogoCalificaciones.DataSource = dataSet;
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("DatosCatalogoCalificaciones", "DM0312_CatalogoDeCalificaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
        }


        #region Eventos

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void txt_Buscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                //dgv_CatalogoCalificaciones.Rows.Clear();
                DatosCatalogoCalificaciones();
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dgv_CatalogoCalificaciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 46) e.Handled = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }


        private void CatalogoDeCalificaciones_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                dgv_CatalogoCalificaciones.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            else
                dgv_CatalogoCalificaciones.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void CatalogoDeCalificaciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }

        #endregion
    }
}