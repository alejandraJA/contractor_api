﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.Properties;
using Application = System.Windows.Forms.Application;

namespace PuntoVenta.View
{
    public partial class DM0312_Adjudicaciones : Form
    {
        public static List<string> datosAlmacen = new List<string>();
        public static List<DM0312_MVentaDetalle> ListVentaDAdju;
        public int Canal, idVenta;
        private readonly CDetalleVenta CDetalleVenta = new CDetalleVenta();
        public bool CerrarVenta, verCosto;
        public List<DM0312_MComentariosVenta> ComentariosAdjudicacion;
        public DM0312_CPuntoDeVenta controlador = new DM0312_CPuntoDeVenta();

        private readonly CSerieArticulos ControladorSerie = new CSerieArticulos();
        private readonly DM0312_C_ExploradorVenta controllerExplorador = new DM0312_C_ExploradorVenta();
        public List<string> datosConcepto = new List<string>();
        private readonly DM0312_C_DevolucionesAdj DevolucionMov = new DM0312_C_DevolucionesAdj();
        public DM0312_Loading_ frmLoading = new DM0312_Loading_();
        public Image img;
        public List<string> ListaControles;
        public string mensajeBoton;

        public DM0312_MVentaDetalle modeloVacio;
        public DM0312_MVentaDetalle modeloVentaDetalle;
        public string Mov, codigo, MovID, idFactura, importe, impuestos;
        public string oldValue = string.Empty;
        public int suc;
        public string TipoMovimiento, FormaPago = "";
        public string ValidaEstatus, Concepto = "", Observacion = "", Comentario = "", almacen = "";

        public DM0312_Adjudicaciones()
        {
            InitializeComponent();
            AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
            UsuarioAcceso.AplicarVistas(this);

            ListVentaDAdju = new List<DM0312_MVentaDetalle>();

            modeloVentaDetalle = new DM0312_MVentaDetalle();

            modeloVacio = new DM0312_MVentaDetalle();
        }

        ~DM0312_Adjudicaciones()
        {
            GC.Collect();
        }

        private void DM0312_Adjudicaciones_Load(object sender, EventArgs e)
        {
            ListaControles = new List<string>();
            lbl_Estatus.Text = ValidaEstatus;
            lbl_Usuario.Text = ClaseEstatica.Usuario.Usser;
            ComentariosAdjudicacion = Funciones.ConsultaComentario("Adjudicacion");

            cbx_Cliente.Enabled = false;
            txt_ClienteNombre.Enabled = false;
            cbx_Agente.Enabled = false;
            cbx_Canal.Enabled = false;
            cbx_Condicion.Enabled = false;
            txt_Referencia.Enabled = false;
            txt_Pago.Enabled = false;
            TipoMovimiento = "Sol Dev Unicaja";
            LlenarAlmacen();
            InformacionDev();
            FormaPago = "DEVOLUCION";
            lbl_Estatus.Text = "SIN AFECTAR";

            //imagen que se muestra en el grid
            EditImagen();

            /*agregar modelo vacio*/
            ListVentaDAdju.Add(modeloVacio);

            //llenado inicial del grid
            llenarGrid();

            txt_Comentarios.Text =
                "VERIFICAR LOS DATOS PERSONALES DEL CLIENTE, SI SON CORRECTOS AGREGAR LOS ARTICULOS QUE SE VENDERAN UNA VEZ AGREGADOS SELECCIONAR EL BOTON DE SITUACIONES PARA SEGUIR EL PROCESO DE LA ADJUDICACION";

            toolTip1.SetToolTip(cbx_Cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(txt_ClienteNombre, "NOMBRE DEL CLIENTE");
            toolTip1.SetToolTip(cbx_Agente, "VENDEDOR QUE REALIZA LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(cbx_Canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(cbx_Condicion, "PLAZO DE PAGO DE LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(cbx_Almacen, "ALMACÉN DONDE SE REALIZA LA VENTA");
            toolTip1.SetToolTip(cbx_Concepto, "MOTIVO POR EL CUAL SE SOLICITA LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(txt_Referencia,
                "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(txt_Pago, "MONEDERO QUE SE REDIMIÓ PARA LA FACTURA " + Mov + " " + MovID);
            toolTip1.SetToolTip(txt_Observaciones, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(txt_Comentario, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(btn_Regresar, "CANCELAR ADJUDICACION");
            toolTip1.SetToolTip(btn_Situaciones,
                "SI TIENE LOS DATOS CORRECTOS Y YA SE AGREGO AL DETALLE ARTICULOS ADJUDICADOS PRESIONAR BOTÓN PARA SEGUIR PROCESO DE SU VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(btn_InformacionCliente,
                "INFORMACIÓN IMPORTANTE DEL CLIENTE AL QUE SE LE VA HACER LA ADJUDICACION");
            toolTip1.SetToolTip(btn_ayuda, "AYUDA");

            toolTip1.SetToolTip(lbl_cliente, "CUENTA DEL CLIENTE AL QUE SE LE VA REALIZAR UNA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_Agente, "VENDEDOR QUE REALIZA LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_canal, "TIPO DE VENTA");
            toolTip1.SetToolTip(lbl_condicion, "PLAZO DE PAGO DE LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_almacen, "ALMACÉN DONDE SE REALIZA LA VENTA");
            toolTip1.SetToolTip(lbl_Concepto, "MOTIVO POR EL CUAL SE SOLICITA LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_Referencia,
                "MOVIMIENTO Y FOLIO AL QUE SE LE VA A REALIZAR UNA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_MonederoRedimido, "MONEDERO QUE SE REDIMIÓ PARA LA FACTURA " + Mov + " " + MovID);
            toolTip1.SetToolTip(lbl_Comentario, "CAMPO LIBRE PARA OBSERVACIONES SOBRE EL MOVIMIENTO");
            toolTip1.SetToolTip(lbl_Observaciones, "CAMPO LIBRE PARA COMENTARIOS SOBRE EL MOVIMIENTO");

            toolTip1.SetToolTip(btnImportExcel,
                "IMPORTADOR DE ARTICULOS ADJUDICADOS, CREAR UN ARCHIVO .XLSX EN EL CREAR ENCABEZADO QUE CONSTA DE: ARTICULO Y CANTIDAD ");
            toolTip1.SetToolTip(BtnAdd,
                "SELECCIONAR PARA ABRIR EL CATALOGO DE ARTICULOS ADJUDICADOS DEL ALMACEN SELECCIONADO");
            toolTip1.SetToolTip(lbl_subt, "SUBTOTAL DE LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_Impuestos, "TOTAL DE IMPUESTOS QUE GENERA LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_total, "SUMA DEL SUBTOTAL Y DE LOS IMPUESTOS");
            toolTip1.SetToolTip(gbx_VentaDetalle,
                "DETALLE DEL MOVIMIENTO INSERTAR SI LO NECESITA OBSERVACIONES UNA VEZ TERMINADO AFECTAR LA VENTA Y SEGUIR CON SU PROCESO");
            toolTip1.SetToolTip(lbl_Usuario, "USUARIO");
            toolTip1.SetToolTip(lbl_Estatus, "ESTATUS DE LA VENTA DE ADJUDICADOS");
            toolTip1.SetToolTip(lbl_ID, "ID DE LA VENTA DE ADJUDICADOS");


            if (ClaseEstatica.Usuario.Uen == 3)
            {
                lbl_Empresa.Text = "MAVI";
                toolTip1.SetToolTip(lbl_Empresa, "MAVI DE OCCIDENTE");
            }
            else
            {
                if (ClaseEstatica.Usuario.Uen == 1)
                {
                    lbl_Empresa.Text = "MA";
                    toolTip1.SetToolTip(lbl_Empresa, "MUEBLES AMERICA");
                }
                else
                {
                    if (ClaseEstatica.Usuario.Uen == 2)
                    {
                        lbl_Empresa.Text = "VIU";
                        toolTip1.SetToolTip(lbl_Empresa, "VIU");
                    }
                    else
                    {
                        lbl_Empresa.Text = "";
                        toolTip1.SetToolTip(lbl_Empresa, "");
                    }
                }
            }

            if (ClaseEstatica.Usuario.color == "Azul")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dvg_detalleVenta.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void dvg_detalleVenta_SelectionChanged(object sender, EventArgs e)
        {
            int index = dvg_detalleVenta.CurrentRow.Index;

            if (index == -1)
                return;

            modeloVentaDetalle = new DM0312_MVentaDetalle();

            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.CurrentRow.DataBoundItem;

            llenarLabels(modeloVentaDetalle);

            dvg_detalleVenta.EndEdit();
        }

        private void DM0312_Adjudicaciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (lbl_ID.Text != "")
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        EliminarId();
                        EliminarVentaD();
                        Dispose();
                    }
                }
                else
                {
                    Dispose();
                }
            }


            if (e.Control && e.KeyCode == Keys.I)
                try
                {
                    if (btn_InformacionCliente.Visible)
                    {
                        if (cbx_Cliente.Text == "")
                        {
                            MessageBox.Show("Ingrese un Cliente", "Informacion", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                        else
                        {
                            foreach (Form forma in Application.OpenForms)
                                if (forma.Name == "InformacionCliente")
                                {
                                    forma.Close();
                                    break;
                                }

                            InformacionCliente infoCliente = new InformacionCliente();
                            infoCliente.mensaje = cbx_Cliente.Text;
                            infoCliente.Show();
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("No es una Cuenta Correcta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void cbx_Agente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == (char)32 ||
                e.KeyChar == '#')
                e.Handled = false;
            else
                e.Handled = true;
        }


        #region "METODOS"

        public void InformacionDev()
        {
            try
            {
                List<string> Resultado = new List<string>();
                string monedero = "";
                string Agente = "";
                lbl_Estatus.Text = ValidaEstatus;
                Resultado = DevolucionMov.InformacionFacturaDevolucion(Mov, MovID);
                monedero = DevolucionMov.MonederoRedimido(Resultado[7]);
                Agente = DevolucionMov.PropAgente(ClaseEstatica.Usuario.Usser);
                idFactura = Resultado[7];
                Text = " Venta de " + TipoMovimiento + "       SPID:" + ClaseEstatica.SPID + "        " +
                       controllerExplorador.FechaActualServidor();
                LlenarConcepto();
                cbx_Concepto.Text = "ADJUDICACION + DE 12";
                cbx_Cliente.Text = Resultado[0];
                txt_ClienteNombre.Text = Resultado[1];
                cbx_Agente.Text = Agente;
                cbx_Canal.Text = Resultado[3];
                cbx_Condicion.Text = "(Fecha)";
                cbx_Almacen.Text = "V00094";
                txt_Referencia.Text = Mov + " " + MovID;
                codigo = cbx_Cliente.Text;
                txt_Pago.Text = monedero;
                if (monedero == "")
                {
                    txt_Pago.Visible = false;
                    lbl_MonederoRedimido.Visible = false;
                }

                ObtenIdVenta();
                if (lbl_ID.Text == "")
                {
                    MessageBox.Show("Error al generar id de venta", "Error", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    Dispose();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("InformacionDev", "DM0312_DevolucionAdj", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ActualizarInfoIdVenta()
        {
            try
            {
                bool Actualiza = new bool();
                almacen = cbx_Almacen.Text;
                suc = DevolucionMov.SucursalALM(almacen);
                Actualiza = controlador.ActualizaIdVentaD("MAVI", TipoMovimiento, ClaseEstatica.Usuario.usuario, codigo,
                    Convert.ToInt32(cbx_Canal.Text), almacen, cbx_Agente.Text, cbx_Condicion.Text, suc,
                    ClaseEstatica.Usuario.Uen, "No Identificado", txt_Observaciones.Text, txt_Comentario.Text,
                    cbx_Concepto.Text, FormaPago, txt_Referencia.Text, "", 2, idVenta, ValidaEstatus, "", "", false,
                    false, false, "", "", "", "Casa");
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ActualizarInfoIdVenta", "DM0312_Adjudicaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void ObtenIdVenta()
        {
            try
            {
                Concepto = cbx_Concepto.Text;
                Observacion = txt_Observaciones.Text;
                Comentario = txt_Comentario.Text;
                almacen = cbx_Almacen.Text;
                suc = DevolucionMov.SucursalALM(almacen);

                idVenta = controlador.IdVentaD("MAVI", TipoMovimiento, ClaseEstatica.Usuario.usuario, codigo,
                    Convert.ToInt32(cbx_Canal.Text), almacen, cbx_Agente.Text, cbx_Condicion.Text, suc,
                    ClaseEstatica.Usuario.Uen, "No Identificado", txt_Observaciones.Text, txt_Comentario.Text,
                    cbx_Concepto.Text, FormaPago, txt_Referencia.Text, "", 1,
                    "", "", false, false, "", false, "", "", "Casa");
                lbl_ID.Text = Convert.ToString(idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("ObtenIdVenta", "DM0312_Adjudicaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenarAlmacen()
        {
            try
            {
                datosAlmacen = new List<string>();
                datosAlmacen = DevolucionMov.ListaAlmacenesADJ();
                if (datosAlmacen.Count > 0)
                {
                    cbx_Almacen.DataSource = null;
                    cbx_Almacen.DataSource = datosAlmacen.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarAlmacen", "DM0312_Adjudicaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void EliminarId()
        {
            try
            {
                bool Eliminar = new bool();
                Eliminar = controlador.EliminarIdVenta(3, idVenta);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarId", "DM0312_Adjudicaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void LlenarConcepto()
        {
            try
            {
                datosConcepto = new List<string>();
                datosConcepto = controlador.LlenaConcepto(TipoMovimiento);
                if (datosConcepto.Count > 0)
                {
                    cbx_Concepto.DataSource = null;
                    cbx_Concepto.DataSource = datosConcepto.ToArray();
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("LlenarConcepto", "DM0312_Adjudicaciones", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public void VerCosto()
        {
            bool res_ = false;
            //List<string> TipoMovs = new List<string>();

            if ((AccesosDeUsuario.CUsuario.BloquearCostos == false) & AccesosDeUsuario.CUsuario.Costos)
                //TipoMovs = controlador.GetTiposMov();
                if (TipoMovimiento.Contains("Sol Dev Unicaja"))
                    res_ = true;

            verCosto = res_;
        }

        private async void LeerExcel()
        {
            try
            {
                List<DM0312_MVentaDetalle> DatosExcel = new List<DM0312_MVentaDetalle>();
                List<string> ArticulosConError = new List<string>();

                OpenFileDialog fichero = new OpenFileDialog();
                fichero.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
                if (fichero.ShowDialog() == DialogResult.OK)
                {
                    frmLoading.Show(this);
                    DesabilitarControles(false);

                    //libro excel
                    DatosExcel = await Task.Run(() => OpenExcel(fichero.FileName));

                    frmLoading.Hide();
                    DesabilitarControles(true);

                    if (DatosExcel.Count == 0)
                    {
                        MessageBox.Show("Sin articulos por Agregar", "Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation);
                        return;
                    }

                    foreach (DM0312_MVentaDetalle i in DatosExcel)
                    {
                        if (i.Cantidad <= 0)
                            i.Cantidad = 1;

                        if (!BuscarArticulos(i.Articulo, false, true))
                            ArticulosConError.Add(i.Articulo);
                    }

                    if (ArticulosConError.Count > 0)
                        MessageBox.Show("Algunos articulos tienen Error y no pudieron ser agregados", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        private List<DM0312_MVentaDetalle> OpenExcel(string filename)
        {
            List<DM0312_MVentaDetalle> DatosExcel = new List<DM0312_MVentaDetalle>();

            Microsoft.Office.Interop.Excel.Application objectExcel = new Microsoft.Office.Interop.Excel.Application();

            Workbook theWorkbook = objectExcel.Workbooks.Open(filename, 0, true, 5, "", "", true, XlPlatform.xlWindows,
                "\t", false, false, 0, true);

            Sheets sheets = theWorkbook.Worksheets;
            Worksheet worksheet = (Worksheet)sheets.get_Item(1);

            Range range = worksheet.UsedRange;

            int RowsCount = range.Rows.Count;

            //recorre rows
            for (int r = 2; r <= RowsCount; r++)
            {
                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                if (range.Cells[r, 1].Value != null)
                {
                    model.Articulo = (range.Cells[r, 1] as Range).Value.ToString();

                    if (range.Cells[r, 2].Value != null)
                    {
                        Type type = range.Cells[r, 2].Value.GetType();

                        if (type.Name.Contains("String"))
                            model.Cantidad = 1;
                        else
                            model.Cantidad = (int)(range.Cells[r, 2] as Range).Value;
                    }
                    else
                    {
                        model.Cantidad = 1;
                    }

                    DatosExcel.Add(model);
                }
            }

            return DatosExcel;
        }

        private void DesabilitarControles(bool estado)
        {
            if (!estado)
            {
                ListaControles = new List<string>();
                foreach (Control item in Controls)
                    if (!item.Enabled)
                        ListaControles.Add(item.Name);
                    else
                        item.Enabled = estado;
            }
            else
            {
                foreach (Control item in Controls)
                    if (!ListaControles.Contains(item.Name))
                        item.Enabled = estado;
            }
            // DeshabilitarRefrescar(estado);
        }

        #endregion


        #region "EVENTOS"

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
            {
                if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    EliminarId();
                    EliminarVentaD();
                    Dispose();
                }
            }
            else
            {
                Dispose();
            }
        }

        private void btn_eventosNotasCitA_Click(object sender, EventArgs e)
        {
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "DM0312_EventosNotasCitas")
                {
                    forma.Close();
                    break;
                }

            DM0312_EventosNotasCitas eventNotaCita = new DM0312_EventosNotasCitas();
            DM0312_EventosNotasCitas.recibeCliente = codigo;
            DM0312_EventosNotasCitas.recibeIdventa = Convert.ToString(idVenta);
            DM0312_EventosNotasCitas.recibeUsuario = ClaseEstatica.Usuario.Usser;
            DM0312_EventosNotasCitas.recibeMov = TipoMovimiento;
            eventNotaCita.ShowDialog();
        }

        private void btn_InformacionCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbx_Cliente.Text == "")
                {
                    MessageBox.Show("Ingrese un Cliente", "Informacion", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    foreach (Form forma in Application.OpenForms)
                        if (forma.Name == "InformacionCliente")
                        {
                            forma.Close();
                            break;
                        }

                    InformacionCliente infoCliente = new InformacionCliente();
                    infoCliente.mensaje = cbx_Cliente.Text;
                    infoCliente.Show();
                }
            }
            catch
            {
                MessageBox.Show("No es una Cuenta Correcta", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void cbx_Concepto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void txt_Comentario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text))
                    ActualizarInfoIdVenta();
        }

        private void txt_Comentario_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void txt_Observaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                          Comentario != txt_Comentario.Text))
                    ActualizarInfoIdVenta();
        }

        private void txt_Observaciones_Validating(object sender, CancelEventArgs e)
        {
            if (lbl_ID.Text != "" && (Concepto != cbx_Concepto.Text || Observacion != txt_Observaciones.Text ||
                                      Comentario != txt_Comentario.Text)) ActualizarInfoIdVenta();
        }

        private void DM0312_Adjudicaciones_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!CerrarVenta)
                if (lbl_ID.Text != "")
                {
                    if (MessageBox.Show("Se perderán los cambios, desea salir de la venta?", "Confirmar",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        EliminarId();
                        ClaseEstatica.FormActivo = string.Empty;
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(lbl_ID.Text);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            DM0312_ArticulosAdj catalogo = new DM0312_ArticulosAdj();
            catalogo.almacenV = cbx_Almacen.Text;
            catalogo.ShowDialog();

            if (catalogo.idArticulo == null)
                return;

            if (!BuscarArticulos(catalogo.idArticulo, false)) ListVentaDAdju.Add(modeloVacio);
        }

        /// <summary>
        ///     Abre la forma de situaciones para cambiar la situacion de la venta
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        /// Developer: Dan Palacios
        /// Date: 06/11/17
        private void btn_Situaciones_Click(object sender, EventArgs e)
        {
            if (!VerifySeriesIsEmpty())
                return;
            if (dvg_detalleVenta.Rows.Count < 2)
            {
                MessageBox.Show("No hay articulos añadidos", "Mensaje!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (!guardarArticulos()) return;

            Dm0312DetalleSituaciones.IdVenta = idVenta;
            Dm0312DetalleSituaciones.Estatus = "SINAFECTAR";
            Dm0312DetalleSituaciones.Mov = TipoMovimiento;
            Dm0312DetalleSituaciones.MovId = "";
            List<MSituaciones> ListaSituaciones = CSituaciones.ObtenerSituaciones();
            Dm0312DetalleSituaciones.Situaciones = ListaSituaciones;

            List<DM0312_MExploradorVenta> VentasSeleccionadas = new List<DM0312_MExploradorVenta>();
            CDetalleVenta.CargaMovimientoCreado(idVenta, idVenta, VentasSeleccionadas);

            Dm0312DetalleSituaciones situaciones = new Dm0312DetalleSituaciones(VentasSeleccionadas);
            situaciones.ShowDialog();
            if (situaciones.ValidaSituacion)
            {
                ListaSituaciones = CSituaciones.ObtenerSituaciones();
                guardarSeries();
                AbrirDetalle(VentasSeleccionadas);
            }
        }

        /// <summary>
        ///     Abre el detalle del mov afectado / creado
        /// </summary>
        /// <param name="VentasSeleccionadas">List<DM0312_MExploradorVenta></param>
        /// Developer: Dan Palacios
        /// Date: 09/11/17
        private void AbrirDetalle(List<DM0312_MExploradorVenta> VentasSeleccionadas)
        {
            DM0312_ExploradorVentas.ListaExplorador = new List<DM0312_MExploradorVenta>(VentasSeleccionadas);
            controllerExplorador.LLenadoListaArticulosSeleccionados(VentasSeleccionadas);
            DM0312_DetalleVenta detalle = new DM0312_DetalleVenta();
            string[] ParametrosAnticipos = { "" };
            CerrarVenta = true;
            Close();
            detalle.Show();
            detalle.TopMost = true;
            detalle.Focus();
        }

        private void dvg_detalleVenta_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                if (e.RowIndex != ListVentaDAdju.Count - 1)
                    e.Graphics.DrawImage(img, e.CellBounds.Left + 4, e.CellBounds.Top + 1, 25, 25);

                dvg_detalleVenta.Rows[e.RowIndex].Height = 28;

                dvg_detalleVenta.Columns[e.ColumnIndex].Width = 28;

                e.Handled = true;
            }
        }

        private void cbx_Almacen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbl_ID.Text != "")
            {
                ActualizarInfoIdVenta();

                DM0312_MVentaDetalle item = ListVentaDAdju.FirstOrDefault();

                if (item.Articulo != null)
                    if (item.Almacen != cbx_Almacen.Text)
                    {
                        string almacen = item.Almacen;
                        ListVentaDAdju.RemoveAll(x => x.Almacen == almacen);
                        llenarGrid();
                    }
            }
        }

        private void btnImportExcel_Click(object sender, EventArgs e)
        {
            LeerExcel();
        }

        #endregion


        #region MetodosArticulos

        private bool BuscarArticulos(string articulo, bool Editar, bool Excel = false)
        {
            if (!Editar)
            {
            }

            bool bVentaLinea = false;
            foreach (DM0312_MVentaDetalle item in ListVentaDAdju)
                if (!string.IsNullOrEmpty(item.Linea))
                    if (CDetalleVenta.validarFamiliaLinea(item.Linea))
                        bVentaLinea = true;

            //if (ListVentaDAdju.Where(x => x.Linea != null).Any(x => x.Linea=="MOTOCICLETAS"))
            if (bVentaLinea)
            {
                MessageBox.Show(
                    "No se puede agregar otro articulo, Cuando tienes un tipo Serie de la Familia MOTOCICLETAS",
                    "Precaución", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return false;
            }

            string almacenI = string.Empty;

            almacenI = controlador.AlmacenI(cbx_Almacen.Text);

            List<DM0312_M_ArticulosAdjudicados> ListArts = controlador.BuscaArticulosADJ(cbx_Almacen.Text);

            ListArts = ListArts.Where(x => x.Codigo == articulo).ToList();

            if (ListArts.Count == 1)
            {
                //modelo de articulos adjudicados
                DM0312_M_ArticulosAdjudicados modelAdjudicados = new DM0312_M_ArticulosAdjudicados();

                modelAdjudicados = ListArts.FirstOrDefault();

                //modelo vacio para agregar fila vacia
                DM0312_MVentaDetalle modelVacio = new DM0312_MVentaDetalle();

                //buscar si existe el articulo en la lista para no agregar otro igual
                DM0312_MVentaDetalle m = ListVentaDAdju
                    .Where(x => x.Articulo.ToUpper() == modelAdjudicados.Codigo.ToUpper()).FirstOrDefault();

                if (m != null)
                    if (m.Descripcion == null)
                        m = null;


                if (!Editar)
                    if (m != null)
                    {
                        //if (m.Precio > 0)
                        //{
                        MessageBox.Show("Articulo duplicado", "Advertencia!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                        //}
                    }

                //redimir
                bool redimir = false;


                //llenado del modelo por el articulo nuevo
                DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                model.Articulo = modelAdjudicados.Codigo;
                model.Descripcion = modelAdjudicados.Nombre;
                model.Linea = modelAdjudicados.Linea;
                model.Disponible = Convert.ToInt32(modelAdjudicados.Disponible);
                model.impuesto = Convert.ToDouble(modelAdjudicados.Impuesto);
                model.Tipo = modelAdjudicados.Tipo;
                model.Unidad = modelAdjudicados.unidad;
                model.Almacen = cbx_Almacen.Text;

                double precio = controlador.GetPrice(model.Articulo, idVenta, model.Renglon, redimir);

                double value = Math.Truncate(100 * precio) / 100;

                model.Precio = value;

                model.PrecioS = "$" + value;


                //PropreListaID
                //model.PropreListaID = controlador.GetPropreListaID(idVenta, model.Articulo, redimir);

                //eliminar modelo vacio de la lista antes de agregar el otro
                ListVentaDAdju.RemoveAll(x => x.Descripcion == null);

                if (!Editar)
                    if ((model.Linea == "MOTOCICLETAS") &
                        ListVentaDAdju.Where(l => l.Linea != null).Any(x => x.Linea == "MOTOCICLETAS"))
                    {
                        //Motos
                        MessageBox.Show("El articulo es Linea=MOTOCICLETAS, debe ser el unico", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        DM0312_MVentaDetalle modelEmp = new DM0312_MVentaDetalle();
                        ListVentaDAdju.Add(modelEmp);
                        return false;
                    }


                //cantidad
                DM0312_C_DevolucionesAdj cnt = new DM0312_C_DevolucionesAdj();
                string res = cnt.InvDSelect(model.Articulo);

                if (res == string.Empty)
                {
                    MessageBox.Show(
                        "El articulo no se dio de alta en inventarios o su almacen no es el de inicio de Adjudicacion",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                char delimiter = ',';
                string[] substrings = res.Split(delimiter);

                int cantidad = Convert.ToInt32(substrings[2]);

                double Costo = Convert.ToDouble(substrings[1]);

                double Importe = Convert.ToDouble(substrings[3]);

                string almacen = substrings[4];

                if (model.Tipo == "Serie")
                {
                    MSerieArticulos mseriearts = new MSerieArticulos();
                    mseriearts = ControladorSerie.GetSerieLote(almacen, model.Articulo);
                    model.Serie = mseriearts.Serie;
                    model.Propiedades = mseriearts.Propiedades;
                }

                //listas para calcular renglones 
                if (ListVentaDAdju.Count == 0)
                    model.RenglonID = 1;
                else
                    model.RenglonID = ListVentaDAdju.Count + 1;


                model.Cantidad = cantidad;

                model.Renglon = 2048 * model.RenglonID;

                //Dictionary<double, double> item = new Dictionary<double, double>();

                //item = actualizaMovPorModel(model.Cantidad.ToString(), model);

                //model.SubTotal = Convert.ToDouble(item.Keys.FirstOrDefault());

                //model.Total = Convert.ToDouble(item.Values.FirstOrDefault());

                model.SubTotal = Importe / cantidad;

                model.Total = Importe;

                model.TotalS = "$" + Importe;

                if (Editar) DeleteInlist();

                if (model.Linea == "MOTOCICLETAS")
                    if (ListVentaDAdju.Count > 0)
                    {
                        MessageBox.Show("No se puede agregar articulo es Linea MOTOCICLETAS", "Error!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }

                double costo = controlador.ExecspVerCosto(ClaseEstatica.Usuario.sucursal, model.Articulo, model.Unidad);

                double valueA = Math.Truncate(100 * costo) / 100;

                model.Costo = valueA;

                model.Costo_ = "$" + valueA;

                //se agrega modelo desde el articulo encontrado
                ListVentaDAdju.Add(model);

                //se agrega fila vacia
                ListVentaDAdju.Add(modelVacio);

                //se llena grid con el articulo nuevo
                llenarGrid();

                return true;
            }

            if (!Excel)
                MessageBox.Show("No Exiten Articulos con el Codigo:" + articulo, "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            return false;
        }

        private Dictionary<double, double> actualizaMovPorModel(string cambio, DM0312_MVentaDetalle Item)
        {
            Dictionary<double, double> res = new Dictionary<double, double>();

            double cantidad = Convert.ToDouble(cambio);

            //saca valor del Iva
            double iva = Item.impuesto / 100 + 1;

            double subtotalParcial = cantidad * (Item.Precio / iva);

            double value = Math.Truncate(100 * subtotalParcial) / 100;

            Item.SubTotal = Convert.ToDouble(value);

            Item.Total = cantidad * Item.Precio;

            Item.TotalS = "$" + cantidad * Item.Precio;

            res.Add(Item.SubTotal, Item.Total);

            return res;
        }

        public void DeleteInlist()
        {
            IEnumerable<DM0312_MVentaDetalle> item = ListVentaDAdju.Where(x => x.Articulo_Ligado == oldValue);

            foreach (DM0312_MVentaDetalle i in item)
                if (i.Serie != null)
                    controlador.DeleteSeriesLotes(i.Serie, idVenta, i.Articulo);
            //ListVentaDetalle.Remove(i);
            ListVentaDAdju.RemoveAll(x => x.Articulo_Ligado == oldValue);
            ListVentaDAdju.RemoveAll(x => x.Articulo == oldValue);
            ListVentaDAdju.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);


            //if (modeloVentaDetalle.Linea == "MOTOCICLETAS")
            //    EsMoto = false;

            //llenarGrid();
        }

        private void llenarGrid()
        {
            dvg_detalleVenta.DataSource = null;
            dvg_detalleVenta.Columns.Clear();
            dvg_detalleVenta.DataSource = ListVentaDAdju.ToList();

            DataGridViewButtonColumn ButtonEdit = new DataGridViewButtonColumn();
            ButtonEdit.Name = "Opcion";
            if (dvg_detalleVenta.Columns["Opcion"] == null) dvg_detalleVenta.Columns.Insert(0, ButtonEdit);

            if (ListVentaDAdju.Count() >= 1)
            {
                int index = ListVentaDAdju.Count() - 1;

                DataGridViewTextBoxCell cell = new DataGridViewTextBoxCell();
                dvg_detalleVenta.Rows[index].Cells[0] = cell;
            }

            //dvg_detalleVenta tamaño columnas
            dvg_detalleVenta.Columns[0].Width = 30;
            dvg_detalleVenta.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;

            VerCosto();

            dvg_detalleVenta.Columns[5].Visible = verCosto;

            dvg_detalleVenta.Columns["Juego"].Visible = false;

            //HeadersText
            dvg_detalleVenta.Columns[0].HeaderText = "";
            dvg_detalleVenta.Columns[0].ToolTipText = "Editar";


            if (ListVentaDAdju.Count > 0)
            {
                double total, subtotal, impuesto;

                total = Convert.ToDouble(ListVentaDAdju.Where(x => x.Juego == null).Sum(x => x.Total).ToString());

                subtotal = Convert.ToDouble(ListVentaDAdju.Where(x => x.Juego == null).Sum(x => x.SubTotal).ToString());

                impuesto = total - subtotal;

                txtSubTotal.Text = "$" + subtotal;

                txtTotal.Text = "$" + total;

                txtImpuestos.Text = "$" + impuesto;

                //int index_ = 0;
                //if (ListVentaDAdju.Count > 2)
                //    index_ = ListVentaDAdju.Count - 2;

                //DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                //model = ListVentaDAdju[index_];
                //llenarLabels(model);

                //dvg_detalleVenta.Rows[index_].Selected = true;
                //dvg_detalleVenta.CurrentCell = dvg_detalleVenta.Rows[index_].Cells[0];


                int index = 0;

                if (ListVentaDAdju.Count > 1)
                    index = ListVentaDAdju.Count - 2;

                //DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                modeloVentaDetalle = ListVentaDAdju[index];


                dvg_detalleVenta.Rows[index].Selected = true;
                dvg_detalleVenta.CurrentCell = dvg_detalleVenta.Rows[index].Cells[0];

                modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.SelectedRows[0].DataBoundItem;
                llenarLabels(modeloVentaDetalle);
            }
        }

        private void EditImagen()
        {
            //-CambioImagenesResources
            img = Resources.edit;
        }

        public void llenarLabels(DM0312_MVentaDetalle model)
        {
            lblUnidad.Text = "Unidad:" + model.Unidad;
            lblDescr.Text = "Descripción:" + model.Descripcion;
        }

        private void ResetOldValue(string cambio, int rowindex)
        {
            dvg_detalleVenta.CancelEdit();

            string name = dvg_detalleVenta.Columns[rowindex].Name;

            //var i = ListVentaDAdju.Where(x => x.GetType().GetProperty(name).GetValue(x, null).ToString() == cambio & x.Articulo==modeloVentaDetalle.Articulo).FirstOrDefault();
            modeloVentaDetalle.GetType().GetProperty(name).SetValue(modeloVentaDetalle, oldValue);

            ListVentaDAdju.RemoveAll(x => x.Descripcion == null);
            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
            ListVentaDAdju.Add(model);
            llenarGrid();
        }

        public bool guardarArticulos()
        {
            bool rest = true;

            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();

            ListVentaDAdju.RemoveAll(x => x.Descripcion == null);

            if (ListVentaDAdju.Count == 0)
            {
                MessageBox.Show("Sin articulos primero debe agregar articulos", "Advertencia", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                ListVentaDAdju.Add(model);
                return false;
            }

            int canal = Convert.ToInt32(cbx_Canal.Text);
            DM0312_C_UsuarioDescuentoIncremento controller = new DM0312_C_UsuarioDescuentoIncremento();
            foreach (DM0312_MVentaDetalle item in ListVentaDAdju)
            {
                //if (item.Tipo == "Serie")
                //{
                //    MSerieArticulos Serie = new MSerieArticulos();

                //    Serie.Serie = item.Serie;
                //    Serie.Cuadro = null;

                //    List<MSerieArticulos> ListOld = new List<MSerieArticulos>();

                //    List<MSerieArticulos> List = new List<MSerieArticulos>();
                //    List.Add(Serie);

                //    ControladorSerie.ActualizarSerie(idVenta, item.Articulo, ListOld, List, suc, item.RenglonID);

                //    string serie = ControladorSerie.GetSerieLote(idVenta, item.Articulo);

                //    if (serie != item.Serie)
                //    {
                //        MessageBox.Show("No se pudo insertar Serie");
                //        rest = false;
                //        break;
                //    }
                //}
                bool res = controller.InsertVentaD_(item, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text, 1);

                if (!res)
                {
                    ListVentaDAdju.Add(model);
                    return false;
                }
            }

            if (!rest)
            {
                ListVentaDAdju.Add(model);
                return false;
            }


            ListVentaDAdju.Add(model);

            return true;
        }

        public bool guardarSeries()
        {
            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();

            bool rest = true;

            foreach (DM0312_MVentaDetalle item in ListVentaDAdju)
                if (item.Tipo == "Serie")
                {
                    MSerieArticulos Serie = new MSerieArticulos();

                    Serie.Serie = item.Serie;
                    Serie.Propiedades = item.Propiedades;

                    List<MSerieArticulos> ListOld = new List<MSerieArticulos>();

                    List<MSerieArticulos> List = new List<MSerieArticulos>();
                    List.Add(Serie);

                    ControladorSerie.ActualizarSerie(idVenta, item.Articulo, ListOld, List, suc, item.RenglonID);

                    string serie = ControladorSerie.GetSerieLote(idVenta, item.Articulo);

                    if (serie != item.Serie)
                    {
                        MessageBox.Show("No se pudo insertar Serie", "Advertencia", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        rest = false;
                        break;
                    }
                }

            if (!rest)
            {
                ListVentaDAdju.Add(model);
                return false;
            }


            return rest;
        }

        private void EliminarVentaD()
        {
            try
            {
                if (ListVentaDAdju.Count > 1)
                {
                    DM0312_C_UsuarioDescuentoIncremento controller = new DM0312_C_UsuarioDescuentoIncremento();

                    int canal = Convert.ToInt32(cbx_Canal.Text);

                    DM0312_MVentaDetalle articulo = ListVentaDAdju.FirstOrDefault();

                    bool res = controller.InsertVentaD_(articulo, idVenta, canal, cbx_Almacen.Text, cbx_Agente.Text, 3);


                    IEnumerable<DM0312_MVentaDetalle> tiposerie = ListVentaDAdju.Where(x => x.Tipo == "Serie");

                    if (tiposerie.Count() == 0)
                        return;

                    foreach (DM0312_MVentaDetalle tipo in tiposerie)
                        controlador.DeleteSeriesLotes(tipo.Serie, idVenta, tipo.Articulo);
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("EliminarVentaD", "DM0312_PuntoDeVenta", ex);
                MessageBox.Show(ex.Message);
            }
        }

        public bool VerifySeriesIsEmpty()
        {
            List<string> Articulos = new List<string>();
            string series = string.Empty;

            IEnumerable<DM0312_MVentaDetalle> itemsSerie = ListVentaDAdju.Where(x => x.Tipo == "Serie");
            int count = 0;
            foreach (DM0312_MVentaDetalle item in itemsSerie)
            {
                if (item.Serie == string.Empty)
                {
                    if (count == 0)
                        series = item.Articulo;
                    else
                        series = series + "," + item.Articulo;
                }

                count++;
            }

            if (series.Length == 0) return true;

            MessageBox.Show("Los articulos:" + series + " No tienen asignada una serie y es tipo Serie", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        #endregion


        #region EventosGrid

        private void dvg_detalleVenta_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value != null)
                oldValue = dvg_detalleVenta[e.ColumnIndex, e.RowIndex].Value.ToString();
        }

        private void dvg_detalleVenta_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            string cambio = string.Empty;

            if (e.RowIndex < 0)
                return;

            try
            {
                #region Costos

                if (e.ColumnIndex == 5)
                {
                    if (dvg_detalleVenta.SelectedCells[0].Value == null)
                        cambio = "$ ";
                    else
                        cambio = dvg_detalleVenta.SelectedCells[0].Value.ToString();

                    double Costo = Convert.ToDouble(cambio.Replace("$", ""));

                    if (Costo <= 0)
                    {
                        MessageBox.Show("El Costo tiene que ser Mayor a 0", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    if (Costo > 99999)
                    {
                        MessageBox.Show("Costo fuera del margen", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }


                    modeloVentaDetalle.Costo_ = "$" + Costo;

                    modeloVentaDetalle.Costo = Costo;

                    dvg_detalleVenta.CancelEdit();

                    llenarGrid();

                    return;
                }

                #endregion //costos

                #region Precio

                if (e.ColumnIndex == 3)
                {
                    if (dvg_detalleVenta.SelectedCells[0].Value == null)
                        cambio = "$ ";
                    else
                        cambio = dvg_detalleVenta.SelectedCells[0].Value.ToString();

                    double Precio = Convert.ToDouble(cambio.Replace("$", ""));

                    if (Precio <= 0)
                    {
                        MessageBox.Show("El Precio tiene que ser Mayor a 0", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    if (Precio > 99999)
                    {
                        MessageBox.Show("Precio Fuera del margen", "Error!!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    modeloVentaDetalle.PrecioS = "$" + Precio;

                    modeloVentaDetalle.Precio = Precio;

                    modeloVentaDetalle.Total = Precio * modeloVentaDetalle.Cantidad;

                    modeloVentaDetalle.TotalS = "$" + modeloVentaDetalle.Total;

                    dvg_detalleVenta.CancelEdit();

                    llenarGrid();

                    return;
                }

                #endregion

                #region Articulos

                if (e.ColumnIndex == 1)
                {
                    if (dvg_detalleVenta.SelectedCells[0].Value == null)
                    {
                        ResetOldValue(cambio, e.ColumnIndex);
                        return;
                    }

                    cambio = dvg_detalleVenta.SelectedCells[0].Value.ToString();

                    if (modeloVentaDetalle.Descripcion != null)
                    {
                        if (!BuscarArticulos(cambio, true)) ResetOldValue(cambio, e.ColumnIndex);
                    }
                    else
                    {
                        if (!BuscarArticulos(cambio, false))
                        {
                            dvg_detalleVenta.CancelEdit();
                            //ListVentaDetalle.RemoveAll(x => x.Precio == 0.0);
                            ListVentaDAdju.RemoveAll(x => x.Descripcion == null);
                            DM0312_MVentaDetalle model = new DM0312_MVentaDetalle();
                            ListVentaDAdju.Add(model);
                            llenarGrid();
                        }
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("La cadena de entrada no tiene el formato correcto."))
                {
                    MessageBox.Show("El valor tiene que ser Numerico", "Error!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    ResetOldValue(cambio, e.ColumnIndex);
                    return;
                }

                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name, "DM0312_PuntoDeVenta", ex);
                MessageBox.Show("dvg_detalleVenta_CellValueChanged " + ex.Message, "Error!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void dvg_detalleVenta_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            modeloVentaDetalle = new DM0312_MVentaDetalle();
            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.Rows[e.RowIndex].DataBoundItem;
        }

        private void dvg_detalleVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            modeloVentaDetalle = new DM0312_MVentaDetalle();
            modeloVentaDetalle = (DM0312_MVentaDetalle)dvg_detalleVenta.Rows[e.RowIndex].DataBoundItem;

            llenarLabels(modeloVentaDetalle);

            if (e.ColumnIndex == 0)
            {
                dvg_detalleVenta.Columns[0].ReadOnly = true;
                dvg_detalleVenta.CancelEdit();

                if (modeloVentaDetalle.Precio == 0.0) return;

                //llamar catalogo de articulos
                string art = string.Empty;
                DM0312_ArticulosAdj catalogo = new DM0312_ArticulosAdj();
                catalogo.almacenV = cbx_Almacen.Text;
                catalogo.ShowDialog();

                if (catalogo.idArticulo == null)
                    return;

                if (!BuscarArticulos(catalogo.idArticulo, true)) ListVentaDAdju.Add(modeloVacio);
            }

            if (e.ColumnIndex == 2) dvg_detalleVenta.Columns[2].ReadOnly = true;

            if (e.ColumnIndex == 3)
            {
                if (verCosto & (modeloVentaDetalle.Articulo != null))
                    dvg_detalleVenta.Columns[3].ReadOnly = false;
                else
                    dvg_detalleVenta.Columns[3].ReadOnly = true;
            }

            if (e.ColumnIndex == 4) dvg_detalleVenta.Columns[4].ReadOnly = true;

            if (e.ColumnIndex == 5)
            {
                if (verCosto & (modeloVentaDetalle.Articulo != null))
                    dvg_detalleVenta.Columns[5].ReadOnly = false;
                else
                    dvg_detalleVenta.Columns[5].ReadOnly = true;
                //dvg_detalleVenta.Columns[5].ReadOnly = true;
            }

            if (e.ColumnIndex == 6) dvg_detalleVenta.Columns[6].ReadOnly = true;

            if (e.ColumnIndex == 7) dvg_detalleVenta.Columns[7].ReadOnly = true;

            if (e.ColumnIndex == 8)
            {
                if (modeloVentaDetalle.Articulo != null)
                    dvg_detalleVenta.Columns[8].ReadOnly = false;
                else
                    dvg_detalleVenta.Columns[8].ReadOnly = true;
            }
        }

        private void dvg_detalleVenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                DM0312_ArticulosAdj catalogo = new DM0312_ArticulosAdj();
                catalogo.almacenV = cbx_Almacen.Text;
                catalogo.ShowDialog();

                if (catalogo.idArticulo == null)
                    return;

                if (!BuscarArticulos(catalogo.idArticulo, false)) ListVentaDAdju.Add(modeloVacio);
            }

            if (modeloVentaDetalle == null)
                return;

            //eliminar articulo
            if (e.KeyCode == Keys.Delete)
            {
                if (modeloVentaDetalle.Descripcion == null)
                {
                    MessageBox.Show("Primero tiene que agregar un articulo", "Advertencia", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                DialogResult dialogResult =
                    MessageBox.Show("Esta Seguro de Eliminar el articulo:" + modeloVentaDetalle.Articulo, "Advertencia",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    ListVentaDAdju.RemoveAll(x => x.Articulo == modeloVentaDetalle.Articulo);
                    string serie = string.Empty;

                    if (modeloVentaDetalle.Serie == null)
                        serie = string.Empty;
                    else
                        serie = modeloVentaDetalle.Serie;


                    if (serie != string.Empty)
                        controlador.DeleteSeriesLotes(modeloVentaDetalle.Serie, idVenta, modeloVentaDetalle.Articulo);
                }

                llenarGrid();
            }
        }

        #endregion


        #region Comentarios

        private void cbx_Almacen_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Almacen =
                ComentariosAdjudicacion.Where(x => x.Campo.Equals("Almacen")).FirstOrDefault();
            if (Almacen != null) txt_Comentarios.Text = Almacen.Comentario;
        }

        private void cbx_Concepto_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Concepto =
                ComentariosAdjudicacion.Where(x => x.Campo.Equals("Concepto")).FirstOrDefault();
            if (Concepto != null) txt_Comentarios.Text = Concepto.Comentario;
        }

        private void txt_Comentario_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Comentario =
                ComentariosAdjudicacion.Where(x => x.Campo.Equals("Comentarios")).FirstOrDefault();
            if (Comentario != null) txt_Comentarios.Text = Comentario.Comentario;
        }

        private void txt_Observaciones_Click(object sender, EventArgs e)
        {
            DM0312_MComentariosVenta Observ = ComentariosAdjudicacion.Where(x => x.Campo.Equals("Observaciones"))
                .FirstOrDefault();
            if (Observ != null) txt_Comentarios.Text = Observ.Comentario;
        }

        #endregion
    }
}