﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class CalcularAbono : Form
    {
        public CalcularAbono(Abono Abono)
        {
            InitializeComponent();
            InicializarValores(Abono);
        }

        private void btn_Cerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /////////////////////////////////VALIDAR CLIENTE REACTIVADO///////////////////////////////////////////
        private bool EsReactivado(string Cliente)
        {
            try
            {
                bool EsReactivado = false;
                using (SqlCommand comando = new SqlCommand(@"DECLARE @valor int
                EXEC SpCREDIClienteReactivado 'Consultar_Reactivado',
                                  @Cliente,
                                  @EsReactivado = @valor OUTPUT
                select @valor as valor ", ClaseEstatica.ConexionEstatica))
                {
                    comando.CommandType = CommandType.Text;
                    comando.Parameters.AddWithValue("@Cliente", Cliente);
                    SqlDataReader dt = comando.ExecuteReader();
                    while (dt.Read())
                    {
                        string resp = dt["valor"].ToString();
                        EsReactivado = resp.Equals("1");
                    }
                }

                return EsReactivado;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        ////////////////////////////////TRAER TIPO DE CLIENTE///////////////////////////////////////////////
        private bool TipoCte(string Tipo)
        {
            try
            {
                bool TipoCte = false;
                using (SqlCommand comando = new SqlCommand("fnVTASClienteNuevoCasa", ClaseEstatica.ConexionEstatica))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    //comando.Parameters.AddWithValue("@Cliente", cliente);
                    comando.Parameters.AddWithValue("@MaviTipoVenta", Tipo);
                    lbl_Cliente.Text = Tipo;
                    SqlDataReader dt = comando.ExecuteReader();
                    TipoCte = dt.HasRows;
                }

                return TipoCte;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void InicializarValores(Abono Abono)
        {
            ///////////////////Se trae el tipo de cliente (Nuevo o Casa), asi mismo si es Reactivado /////////////           
            string TiposCliente, Reactivado;
            TiposCliente = TipoCte(Abono.TipoCliente) ? "" : lbl_Cliente.Text;
            Reactivado = EsReactivado(Abono.IdCliente) ? "Reactivado" : "";
            lbl_Cliente.Text = "Cliente:" + " " + TiposCliente + " " + Reactivado;
            ///////Si el Cliente es Reactivado se le asigna Reactivado a TipoCliente
            if (Reactivado == "Reactivado")
                Abono.TipoCliente = Reactivado;
            else ////Si no es Cliente Reactivado se le asigna TiposCliente a TipoCliente
                Abono.TipoCliente = TiposCliente;
            ////////////////////VALORES DE CALCULOS SE ASIGNA A LOS TEXT////////////////////////////////
            Abono = ObtBofinicacion(Abono);
            Abono = ObtenerDescuentoPagoInmediato(Abono);
            txtFechaPrimerAbono.Text = Abono.PrimerAbono(DateTime.Now).ToString("dd/MM/yyyy");
            txt_Plazo.Text = Abono.Plazo();
            txt_TotalPagar.Text = Abono.ImportePagoNormal.ToString("C2");
            txt_ImportePagoNormal.Text = Abono.ImportePagoNormal.ToString("C2");
            txt_ImportePagoInmediato.Text = Abono.TotalPagoInmediato().ToString("C2");
            txt_ImporteParcialidadPagoNormal.Text = Abono.ImporteParcialidadPagoNormal().ToString("C2");
            txt_ImporteParcialidadPagoInmediato.Text = Abono.TotalParcialInmediato().ToString("C2");
            txt_ImporteAhorro.Text = Abono.AhorraPInmediato().ToString("C2");
            lbl_CantidadParcialidadPagoNormal.Text = Abono.DANumeroDocumentos + " Abonos de:";
            lbl_CantidadParcialidadPagoInmediato.Text = Abono.DANumeroDocumentos + " Abonos de:";
            lbl_Bonificacion.Text = Abono.Bonificacion() > 0 ? Abono.Bonificacion() + " % de bonificación" : "";
        }

        private Abono ObtenerDescuentoPagoInmediato(Abono Abono)
        {
            DataTable dt = new DataTable();
            DM0312_CPuntoDeVenta helper = new DM0312_CPuntoDeVenta();
            dt = helper.ObtenerBonificacionPagoInmediato(Abono);
            if (dt.Rows.Count == 1)
                foreach (DataRow condicionPago in dt.Rows)
                {
                    Abono.DiasVencimiento = int.Parse(condicionPago["DiasVencimiento"].ToString());
                    Abono.DANumeroDocumentos = int.Parse(condicionPago["DANumeroDocumentos"].ToString());
                    Abono.DAPeriodo = condicionPago["DAPeriodo"].ToString();
                }

            return Abono;
        }

//////////////////////////////TRAE LA BONIFICACIÓN////////////////////////////////////
        private Abono ObtBofinicacion(Abono Abono)
        {
            DataTable dt = new DataTable();
            DM0312_CPuntoDeVenta
                BFNC = new DM0312_CPuntoDeVenta(); // dt = BFNC.PorcentajeBonif(Abono); //dt = BFNC.PorcentajeBFC(Abono); (Abono.TipoCliente)
            dt = BFNC.PorcentajeBFC(Abono.idVenta, Abono.TipoCliente, Abono.Articulos);
            if (dt.Rows.Count > 0)
                foreach (DataRow boni in dt.Rows)
                    Abono.Bonifica = double.Parse(boni["Bonifica"].ToString());

            return Abono;
        }
//////////////////////////////TRAE LA BONIFICACIÓN///////////////////////////////////////
    }
}