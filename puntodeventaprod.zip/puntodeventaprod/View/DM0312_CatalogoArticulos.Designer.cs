﻿namespace PuntoVenta.View
{
    partial class DM0312_CatalogoArticulos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_CatalogoArticulos));
            this.dgv_Articulos = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.preciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_Buscar = new System.Windows.Forms.Label();
            this.txt_Buscar = new System.Windows.Forms.TextBox();
            this.cmb_Estatus = new System.Windows.Forms.ComboBox();
            this.lbl_Estatus = new System.Windows.Forms.Label();
            this.lbl_Almacen = new System.Windows.Forms.Label();
            this.cmb_Almacen = new System.Windows.Forms.ComboBox();
            this.cb_Existencia = new System.Windows.Forms.CheckBox();
            this.lbl_Linea = new System.Windows.Forms.Label();
            this.cmb_Linea = new System.Windows.Forms.ComboBox();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Articulos)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_Articulos
            // 
            this.dgv_Articulos.AllowUserToAddRows = false;
            this.dgv_Articulos.AllowUserToDeleteRows = false;
            this.dgv_Articulos.AllowUserToResizeColumns = false;
            this.dgv_Articulos.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Articulos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Articulos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Articulos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Articulos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Articulos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Articulos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Articulos.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Articulos.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Articulos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Articulos.EnableHeadersVisualStyles = false;
            this.dgv_Articulos.Location = new System.Drawing.Point(3, 106);
            this.dgv_Articulos.Name = "dgv_Articulos";
            this.dgv_Articulos.ReadOnly = true;
            this.dgv_Articulos.RowHeadersVisible = false;
            this.dgv_Articulos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_Articulos.Size = new System.Drawing.Size(979, 402);
            this.dgv_Articulos.TabIndex = 2;
            this.dgv_Articulos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Articulos_CellDoubleClick);
            this.dgv_Articulos.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Articulos_ColumnHeaderMouseClick);
            this.dgv_Articulos.SelectionChanged += new System.EventHandler(this.dgv_Articulos_SelectionChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.preciosToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(155, 26);
            // 
            // preciosToolStripMenuItem
            // 
            this.preciosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("preciosToolStripMenuItem.Image")));
            this.preciosToolStripMenuItem.Name = "preciosToolStripMenuItem";
            this.preciosToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.preciosToolStripMenuItem.Text = "Precios (Crtl-P)";
            this.preciosToolStripMenuItem.Click += new System.EventHandler(this.preciosToolStripMenuItem_Click);
            // 
            // lbl_Buscar
            // 
            this.lbl_Buscar.AutoSize = true;
            this.lbl_Buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Buscar.Location = new System.Drawing.Point(3, 0);
            this.lbl_Buscar.Name = "lbl_Buscar";
            this.lbl_Buscar.Size = new System.Drawing.Size(51, 14);
            this.lbl_Buscar.TabIndex = 3;
            this.lbl_Buscar.Text = "Buscar:";
            // 
            // txt_Buscar
            // 
            this.txt_Buscar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Buscar.Location = new System.Drawing.Point(3, 17);
            this.txt_Buscar.Name = "txt_Buscar";
            this.txt_Buscar.Size = new System.Drawing.Size(122, 22);
            this.txt_Buscar.TabIndex = 0;
            this.txt_Buscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Buscar_KeyPress);
            // 
            // cmb_Estatus
            // 
            this.cmb_Estatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Estatus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Estatus.FormattingEnabled = true;
            this.cmb_Estatus.Location = new System.Drawing.Point(138, 17);
            this.cmb_Estatus.Name = "cmb_Estatus";
            this.cmb_Estatus.Size = new System.Drawing.Size(70, 23);
            this.cmb_Estatus.TabIndex = 5;
            this.cmb_Estatus.SelectedIndexChanged += new System.EventHandler(this.cmb_Estatus_SelectedIndexChanged);
            // 
            // lbl_Estatus
            // 
            this.lbl_Estatus.AutoSize = true;
            this.lbl_Estatus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estatus.Location = new System.Drawing.Point(138, 0);
            this.lbl_Estatus.Name = "lbl_Estatus";
            this.lbl_Estatus.Size = new System.Drawing.Size(51, 14);
            this.lbl_Estatus.TabIndex = 6;
            this.lbl_Estatus.Text = "Estatus:";
            // 
            // lbl_Almacen
            // 
            this.lbl_Almacen.AutoSize = true;
            this.lbl_Almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Almacen.Location = new System.Drawing.Point(395, 0);
            this.lbl_Almacen.Name = "lbl_Almacen";
            this.lbl_Almacen.Size = new System.Drawing.Size(59, 14);
            this.lbl_Almacen.TabIndex = 8;
            this.lbl_Almacen.Text = "Almacen:";
            // 
            // cmb_Almacen
            // 
            this.cmb_Almacen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Almacen.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Almacen.FormattingEnabled = true;
            this.cmb_Almacen.Location = new System.Drawing.Point(395, 17);
            this.cmb_Almacen.Name = "cmb_Almacen";
            this.cmb_Almacen.Size = new System.Drawing.Size(121, 23);
            this.cmb_Almacen.TabIndex = 7;
            this.cmb_Almacen.SelectedIndexChanged += new System.EventHandler(this.cmb_Almacen_SelectedIndexChanged);
            this.cmb_Almacen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmb_Almacen_KeyPress);
            // 
            // cb_Existencia
            // 
            this.cb_Existencia.AutoSize = true;
            this.cb_Existencia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Existencia.Location = new System.Drawing.Point(562, 17);
            this.cb_Existencia.Name = "cb_Existencia";
            this.cb_Existencia.Size = new System.Drawing.Size(84, 19);
            this.cb_Existencia.TabIndex = 9;
            this.cb_Existencia.Text = "Disponible";
            this.cb_Existencia.UseVisualStyleBackColor = true;
            this.cb_Existencia.CheckedChanged += new System.EventHandler(this.cb_Existencia_CheckedChanged);
            // 
            // lbl_Linea
            // 
            this.lbl_Linea.AutoSize = true;
            this.lbl_Linea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Linea.Location = new System.Drawing.Point(235, 0);
            this.lbl_Linea.Name = "lbl_Linea";
            this.lbl_Linea.Size = new System.Drawing.Size(42, 14);
            this.lbl_Linea.TabIndex = 11;
            this.lbl_Linea.Text = "Linea:";
            // 
            // cmb_Linea
            // 
            this.cmb_Linea.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Linea.FormattingEnabled = true;
            this.cmb_Linea.Location = new System.Drawing.Point(235, 17);
            this.cmb_Linea.Name = "cmb_Linea";
            this.cmb_Linea.Size = new System.Drawing.Size(154, 23);
            this.cmb_Linea.TabIndex = 10;
            this.cmb_Linea.SelectedIndexChanged += new System.EventHandler(this.cmb_Linea_SelectedIndexChanged);
            this.cmb_Linea.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmb_Linea_KeyPress);
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(3, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(973, 32);
            this.txt_Comentarios.TabIndex = 109;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgv_Articulos, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 408F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(985, 511);
            this.tableLayoutPanel1.TabIndex = 110;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.txt_Comentarios, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.17526F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.82474F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(979, 97);
            this.tableLayoutPanel3.TabIndex = 111;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.12148F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.80227F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.75657F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.70112F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.61856F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_Buscar, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.cb_Existencia, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmb_Linea, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmb_Almacen, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_Almacen, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_Linea, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_Estatus, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txt_Buscar, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmb_Estatus, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 41);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.75F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(707, 46);
            this.tableLayoutPanel2.TabIndex = 110;
            // 
            // DM0312_CatalogoArticulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(985, 511);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "DM0312_CatalogoArticulos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalogo de Articulos";
            this.Load += new System.EventHandler(this.DM0312_CatalogoArticulos_Load);
            this.LocationChanged += new System.EventHandler(this.DM0312_CatalogoArticulos_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DM0312_CatalogoArticulos_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Articulos)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Articulos;
        private System.Windows.Forms.Label lbl_Buscar;
        private System.Windows.Forms.TextBox txt_Buscar;
        private System.Windows.Forms.ComboBox cmb_Estatus;
        private System.Windows.Forms.Label lbl_Estatus;
        private System.Windows.Forms.Label lbl_Almacen;
        private System.Windows.Forms.ComboBox cmb_Almacen;
        private System.Windows.Forms.CheckBox cb_Existencia;
        private System.Windows.Forms.Label lbl_Linea;
        private System.Windows.Forms.ComboBox cmb_Linea;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem preciosToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}