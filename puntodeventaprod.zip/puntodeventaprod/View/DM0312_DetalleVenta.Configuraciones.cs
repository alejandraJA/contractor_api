﻿namespace PuntoVenta
{
    public partial class DM0312_DetalleVenta
    {
        /// <summary>
        ///     Configuraciones de movimientos
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 07/12/17
        public void ConfiguracionesPorMovEstatus()
        {
            if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO" ||
                VentasSeleccionadas[PaginadoActual].Estatus == "CANCELADO")
                cb_ServicioReporte.Enabled = false;
            if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Devolucion" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Unicaja" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Mayoreo" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Devolucion VIU" ||
                VentasSeleccionadas[PaginadoActual].Mov == "Devolucion Venta")
            {
                lbl_Referencia.Visible = true;
                txt_Referencia.Visible = true;
                lbl_Concepto.Visible = true;
                txt_Concepto.Visible = true;
                pan_refConcepto.Visible = true;
            }
            else
            {
                lbl_Referencia.Visible = false;
                txt_Referencia.Visible = false;
                lbl_Concepto.Visible = false;
                txt_Concepto.Visible = false;
                pan_refConcepto.Visible = false;
            }

            btn_Imprimir.Visible = true;
            if (
                //VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Devolucion" 
                //||  
                VentasSeleccionadas[PaginadoActual].Mov == "Sol Dev Unicaja" ||
                (VentasSeleccionadas[PaginadoActual].Mov == "Credilana" &&
                 VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR"))
                btn_Imprimir.Visible = false;

            //btn_SHM.Visible = CDetalleVenta.SucursalSHM();
            //btn_AdjuntarSHM.Visible = CDetalleVenta.SucursalSHM();
            btn_SHM.Visible = CDetalleVenta.SucursalSHMHV();
            btn_AdjuntarSHM.Visible = CDetalleVenta.SucursalSHMHV();
            btn_HojaV.Visible = CDetalleVenta.SucursalSHMHV();

            if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                txt_Enganche.Enabled = false;
            else
                txt_Enganche.Enabled = true;

            if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO" ||
                VentasSeleccionadas[PaginadoActual].Estatus == "CANCELADO" ||
                VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
            {
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Pedido"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Factura"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Factura VIU")
                {
                    if (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO")
                    {
                        //-Datalogic
                        if (ClaseEstatica.iRecarga == 1)
                        {
                            btn_datosEntrega.Visible = false;
                            lbl_comentariosDatosEntrega.Visible = false;
                        }
                        else
                        {
                            btn_datosEntrega.Visible = true;
                            lbl_comentariosDatosEntrega.Visible = true;
                            lbl_comentariosDatosEntrega.Text =
                                "SELECCIONAR PARA CONSULTAR LOS DATOS DE ENTREGA QUE SE ASIGNO AL MOVIMIENTO " +
                                VentasSeleccionadas[PaginadoActual].Mov.ToUpper() + " " +
                                VentasSeleccionadas[PaginadoActual].MovId;
                        }
                    }
                    else
                    {
                        btn_datosEntrega.Visible = false;
                        lbl_comentariosDatosEntrega.Visible = false;
                        if (VentasSeleccionadas[PaginadoActual].Estatus == "SINAFECTAR")
                        {
                            //-Datalogic
                            if (ClaseEstatica.iRecarga == 1)
                            {
                                btn_datosEntrega.Visible = false;
                                lbl_comentariosDatosEntrega.Visible = false;
                            }
                            else
                            {
                                btn_datosEntrega.Visible = true;
                                lbl_comentariosDatosEntrega.Visible = true;
                            }
                        }
                    }

                    btn_Anticipo.Visible = false;
                    btn_SHM.Visible = false;
                    btn_AdjuntarSHM.Visible = true;
                    btn_HojaV.Visible = true;
                    //-731
                    //btn_Eventos.Visible = false;
                }
                else if (VentasSeleccionadas[PaginadoActual].Mov.Equals("Pedido Mayoreo") &&
                         VentasSeleccionadas[PaginadoActual].Estatus.Equals("SINAFECTAR"))
                {
                    if (ClaseEstatica.Usuario.grupo.Equals("CREDITO MAYOREO"))
                    {
                        btn_datosEntrega.Visible = true;
                        lbl_comentariosDatosEntrega.Visible = true;
                    }
                    else
                    {
                        btn_datosEntrega.Visible = false;
                        lbl_comentariosDatosEntrega.Visible = false;
                    }
                }
                else
                {
                    btn_datosEntrega.Visible = false;
                    btn_Anticipo.Visible = false;
                    btn_SHM.Visible = false;
                    btn_AdjuntarSHM.Visible = false;
                    btn_HojaV.Visible = false;
                    //-731
                    //btn_Eventos.Visible = false;
                    lbl_comentariosDatosEntrega.Visible = false;
                }
            }
            else
            {
                if (VentasSeleccionadas[PaginadoActual].Mov == "Solicitud Credito"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Pedido"
                    || VentasSeleccionadas[PaginadoActual].Mov == "Analisis Credito")
                {
                    if (controllerExplorador.idCanal(VentasSeleccionadas[PaginadoActual].Canal) == 2 ||
                        controllerExplorador.idCanal(VentasSeleccionadas[PaginadoActual].Canal) == 6)
                    {
                        btn_SHM.Visible = false;
                        btn_AdjuntarSHM.Visible = false;
                    }
                    else
                    {
                        btn_SHM.Visible = CDetalleVenta.SucursalSHMHV();
                        btn_AdjuntarSHM.Visible = CDetalleVenta.SucursalSHMHV();
                    }

                    btn_HojaV.Visible = CDetalleVenta.SucursalSHMHV();
                    //-Datalogic
                    if (ClaseEstatica.iRecarga == 1)
                    {
                        btn_datosEntrega.Visible = false;
                        lbl_comentariosDatosEntrega.Visible = false;
                    }
                    else
                    {
                        btn_datosEntrega.Visible = true;
                        lbl_comentariosDatosEntrega.Visible = true;
                    }

                    btn_datosEntrega.Visible = true;
                    btn_Anticipo.Visible = true;
                    //btn_SHM.Visible = false;
                    //btn_AdjuntarSHM.Visible = false;
                    //btn_HojaV.Visible = false;
                    //-731
                    //-btn_Eventos.Visible = true;
                    lbl_comentariosDatosEntrega.Visible = true;
                }
            }

            if (txt_Correo.Text.Trim() == string.Empty)
            {
                txt_Correo.Visible = false;
                lbl_Correo.Visible = false;
                pan_correo.Visible = false;
            }

            cb_Almacen.Enabled = VentasSeleccionadas != null &&
                                 (VentasSeleccionadas[PaginadoActual].Estatus == "CONCLUIDO" ||
                                  VentasSeleccionadas[PaginadoActual].Estatus == "CANCELADO")
                ? false
                : true;

            lbl_nomina.Visible = VentasSeleccionadas != null &&
                                 VentasSeleccionadas[PaginadoActual].EnviarA == "34"
                ? true
                : false;
            tb_nomina.Visible = VentasSeleccionadas != null &&
                                VentasSeleccionadas[PaginadoActual].EnviarA == "34"
                ? true
                : false;
            tb_nomina.Text = CDetalleVenta.ObtenerNomina(VentasSeleccionadas[PaginadoActual].Cliente);

            //-731
            if (CDetalleVenta.accesoBotonEventos())
                btn_Eventos.Visible = true;
            else
                btn_Eventos.Visible = false;
        }

        /// <summary>
        ///     Configura las herramientas que el usuario tiene permitido usar
        /// </summary>
        /// Developer: Dan Palacios
        /// Date: 25/07/2017
        private void ConfigurarUsuario()
        {
            if (!CUsuario.Afectar) btn_Afectar.Visible = false;
            if (!CUsuario.ModificarSituacion) btn_Situaciones.Visible = false;
            if (!CUsuario.Cancelar) btn_Cancelar.Visible = false;
            if (!CUsuario.ImprimirMovs) btn_Imprimir.Visible = false;
        }
    }
}