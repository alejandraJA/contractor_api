﻿namespace PuntoVenta.View
{
    partial class DM0312_LineaCredito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DM0312_LineaCredito));
            this.cmbImporte = new System.Windows.Forms.ComboBox();
            this.cmbCredSpe = new System.Windows.Forms.ComboBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtImporte = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbx_PoliticaCred = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.LabelNota = new System.Windows.Forms.Label();
            this.notaTxt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbImporte
            // 
            this.cmbImporte.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbImporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbImporte.FormattingEnabled = true;
            this.cmbImporte.Location = new System.Drawing.Point(101, 64);
            this.cmbImporte.Name = "cmbImporte";
            this.cmbImporte.Size = new System.Drawing.Size(123, 24);
            this.cmbImporte.TabIndex = 2;
            this.cmbImporte.DropDownClosed += new System.EventHandler(this.cmbImporte_DropDownClosed);
            // 
            // cmbCredSpe
            // 
            this.cmbCredSpe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCredSpe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCredSpe.FormattingEnabled = true;
            this.cmbCredSpe.Location = new System.Drawing.Point(101, 137);
            this.cmbCredSpe.Name = "cmbCredSpe";
            this.cmbCredSpe.Size = new System.Drawing.Size(150, 23);
            this.cmbCredSpe.TabIndex = 3;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancelar.BackgroundImage")));
            this.btnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Location = new System.Drawing.Point(12, 71);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(47, 44);
            this.btnCancelar.TabIndex = 4;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAceptar.BackgroundImage")));
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Location = new System.Drawing.Point(12, 12);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(47, 44);
            this.btnAceptar.TabIndex = 0;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(98, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Importe:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Limite Credito Especial:";
            // 
            // txtImporte
            // 
            this.txtImporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImporte.Location = new System.Drawing.Point(263, 66);
            this.txtImporte.MaxLength = 10;
            this.txtImporte.Name = "txtImporte";
            this.txtImporte.Size = new System.Drawing.Size(107, 22);
            this.txtImporte.TabIndex = 7;
            this.txtImporte.Text = "$0.0";
            this.txtImporte.Click += new System.EventHandler(this.txtImporte_Click);
            this.txtImporte.Enter += new System.EventHandler(this.txtImporte_Enter);
            this.txtImporte.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtImporte_KeyPress);
            this.txtImporte.Leave += new System.EventHandler(this.txtImporte_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(260, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Importe:";
            // 
            // cbx_PoliticaCred
            // 
            this.cbx_PoliticaCred.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_PoliticaCred.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_PoliticaCred.FormattingEnabled = true;
            this.cbx_PoliticaCred.Location = new System.Drawing.Point(101, 193);
            this.cbx_PoliticaCred.Name = "cbx_PoliticaCred";
            this.cbx_PoliticaCred.Size = new System.Drawing.Size(326, 23);
            this.cbx_PoliticaCred.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Politica de Credito";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(101, 0);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(352, 33);
            this.txt_Comentarios.TabIndex = 122;
            // 
            // LabelNota
            // 
            this.LabelNota.AutoSize = true;
            this.LabelNota.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNota.Location = new System.Drawing.Point(98, 91);
            this.LabelNota.Name = "LabelNota";
            this.LabelNota.Size = new System.Drawing.Size(39, 15);
            this.LabelNota.TabIndex = 123;
            this.LabelNota.Text = "Nota: ";
            // 
            // notaTxt
            // 
            this.notaTxt.AutoSize = true;
            this.notaTxt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notaTxt.Location = new System.Drawing.Point(133, 91);
            this.notaTxt.Name = "notaTxt";
            this.notaTxt.Size = new System.Drawing.Size(0, 15);
            this.notaTxt.TabIndex = 124;
            // 
            // DM0312_LineaCredito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(458, 238);
            this.Controls.Add(this.notaTxt);
            this.Controls.Add(this.LabelNota);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbx_PoliticaCred);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtImporte);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.cmbCredSpe);
            this.Controls.Add(this.cmbImporte);
            this.Controls.Add(this.btnAceptar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "DM0312_LineaCredito";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Capturar Linea de Crédito Inicial y Regla de Negocio";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DM0312_LineaCredito_FormClosing);
            this.Load += new System.EventHandler(this.DM0312_LineaCredito_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.ComboBox cmbImporte;
        private System.Windows.Forms.ComboBox cmbCredSpe;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtImporte;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_PoliticaCred;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.Label LabelNota;
        private System.Windows.Forms.Label notaTxt;
    }
}