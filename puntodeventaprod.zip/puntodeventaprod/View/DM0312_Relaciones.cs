﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using PuntoVenta.Controller;

namespace PuntoVenta
{
    public partial class Relaciones : Form
    {
        public string recibeCliente;
        private readonly DM0312_C_Relaciones relacion = new DM0312_C_Relaciones();

        public Relaciones()
        {
            InitializeComponent();
        }

        ~Relaciones()
        {
            GC.Collect();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Relaciones_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(btn_Regresar, "Regresar");
            toolTip1.SetToolTip(btn_ayuda, "Ayuda");
            InformacionRelacionesTablero();
            txt_Comentarios.Text = "MUESTRA LA INFORMACION DEL CLIENTE Y DE SUS CLIENTES RELACIONADOS";

            if (ClaseEstatica.Usuario.color == "Azul")
                dgv_Relaciones.RowsDefaultCellStyle.SelectionBackColor = Color.DeepSkyBlue;
            if (ClaseEstatica.Usuario.color == "Rosa")
                dgv_Relaciones.RowsDefaultCellStyle.SelectionBackColor = Color.MediumVioletRed;
            if (ClaseEstatica.Usuario.color == "Verde")
                dgv_Relaciones.RowsDefaultCellStyle.SelectionBackColor = Color.CadetBlue;
            if (ClaseEstatica.Usuario.color == "Gris")
                dgv_Relaciones.RowsDefaultCellStyle.SelectionBackColor = Color.Gray;
        }

        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
        }

        private void btn_Regresar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void InformacionRelacionesTablero()
        {
            try
            {
                DataTable dataSet = new DataTable();
                dataSet = relacion.DatosRelaciones(recibeCliente);

                dgv_Relaciones.DataSource = null;
                dgv_Relaciones.DataSource = dataSet;

                if (dgv_Relaciones.Rows.Count <= 0)
                {
                    Close();
                    MessageBox.Show("El usuario " + recibeCliente + " no tiene relaciones", "Mensaje!!",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (SqlException sqlException)
            {
                DM0312_ErrorLog.RegistraError("InformacionRelacionesTablero", "DM0312_Relaciones", sqlException);
                MessageBox.Show(sqlException.Message);
            }
        }

        private void Relaciones_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Dispose();
        }
    }
}