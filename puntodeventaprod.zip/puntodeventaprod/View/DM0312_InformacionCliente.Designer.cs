﻿namespace PuntoVenta
{
    partial class InformacionCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InformacionCliente));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_Municipio = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_ForamaPago = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_CuentaUnicaja = new System.Windows.Forms.TextBox();
            this.txt_Otros = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_EntreCalle = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_Cp = new System.Windows.Forms.TextBox();
            this.txt_TelParticular = new System.Windows.Forms.TextBox();
            this.txt_Estado = new System.Windows.Forms.TextBox();
            this.txt_Colonia = new System.Windows.Forms.TextBox();
            this.txt_rfc = new System.Windows.Forms.TextBox();
            this.txt_Direccion = new System.Windows.Forms.TextBox();
            this.txt_TelMovil = new System.Windows.Forms.TextBox();
            this.txt_Correo = new System.Windows.Forms.TextBox();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panelContactos = new System.Windows.Forms.FlowLayoutPanel();
            this.gbx_DatosPorCobrar = new System.Windows.Forms.GroupBox();
            this.cbx_FechaCobrarA = new System.Windows.Forms.DateTimePicker();
            this.cbx_FechaCobrarDe = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_TotalCobrar = new System.Windows.Forms.Label();
            this.lbl_Venciminto = new System.Windows.Forms.Label();
            this.dgv_PorCobrar = new System.Windows.Forms.DataGridView();
            this.gbx_DatosVentasPendientes = new System.Windows.Forms.GroupBox();
            this.txt_VentaPendienteFechaA = new System.Windows.Forms.DateTimePicker();
            this.txt_VentaPendienteFechaDe = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dgv_VentasPendientes = new System.Windows.Forms.DataGridView();
            this.gbx_DatosHabitosPago = new System.Windows.Forms.GroupBox();
            this.txt_BuscarHabitos = new System.Windows.Forms.TextBox();
            this.txt_HabitosPagoFechaDe = new System.Windows.Forms.DateTimePicker();
            this.txt_HabitosPagoFechaA = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lbl_Tot = new System.Windows.Forms.Label();
            this.lbl_ImporteTot = new System.Windows.Forms.Label();
            this.lbl_TotalDiasR = new System.Windows.Forms.Label();
            this.lbl_ImporteDiasRetraso = new System.Windows.Forms.Label();
            this.lbl_DiasRetraso = new System.Windows.Forms.Label();
            this.dgv_HabitosPago = new System.Windows.Forms.DataGridView();
            this.label18 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Panel_Menu = new System.Windows.Forms.FlowLayoutPanel();
            this.btnActualizarAval = new System.Windows.Forms.Button();
            this.lbl_Cliente = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_Comentarios = new System.Windows.Forms.TextBox();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_ImgenesCliente = new System.Windows.Forms.Button();
            this.btn_ayuda = new System.Windows.Forms.Button();
            this.btnActualizarCliente = new System.Windows.Forms.Button();
            this.btnActualizarBeneficiario = new System.Windows.Forms.Button();
            this.btn_DatosCobrar = new System.Windows.Forms.Button();
            this.btn_VentasPendientes = new System.Windows.Forms.Button();
            this.btn_HabitosPago = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panelContactos.SuspendLayout();
            this.gbx_DatosPorCobrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PorCobrar)).BeginInit();
            this.gbx_DatosVentasPendientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VentasPendientes)).BeginInit();
            this.gbx_DatosHabitosPago.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_HabitosPago)).BeginInit();
            this.Panel_Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.txt_Municipio);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txt_ForamaPago);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txt_CuentaUnicaja);
            this.groupBox1.Controls.Add(this.txt_Otros);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txt_EntreCalle);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txt_Cp);
            this.groupBox1.Controls.Add(this.txt_TelParticular);
            this.groupBox1.Controls.Add(this.txt_Estado);
            this.groupBox1.Controls.Add(this.txt_Colonia);
            this.groupBox1.Controls.Add(this.txt_rfc);
            this.groupBox1.Controls.Add(this.txt_Direccion);
            this.groupBox1.Controls.Add(this.txt_TelMovil);
            this.groupBox1.Controls.Add(this.txt_Correo);
            this.groupBox1.Controls.Add(this.txt_Nombre);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(82, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(874, 202);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox1_Paint);
            // 
            // txt_Municipio
            // 
            this.txt_Municipio.BackColor = System.Drawing.Color.White;
            this.txt_Municipio.Enabled = false;
            this.txt_Municipio.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Municipio.Location = new System.Drawing.Point(520, 83);
            this.txt_Municipio.Name = "txt_Municipio";
            this.txt_Municipio.ReadOnly = true;
            this.txt_Municipio.Size = new System.Drawing.Size(185, 22);
            this.txt_Municipio.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(449, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 15);
            this.label14.TabIndex = 34;
            this.label14.Text = "Municipio ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(452, 145);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 15);
            this.label17.TabIndex = 33;
            this.label17.Text = "Otros ";
            // 
            // txt_ForamaPago
            // 
            this.txt_ForamaPago.BackColor = System.Drawing.Color.White;
            this.txt_ForamaPago.Enabled = false;
            this.txt_ForamaPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ForamaPago.Location = new System.Drawing.Point(425, 171);
            this.txt_ForamaPago.Name = "txt_ForamaPago";
            this.txt_ForamaPago.ReadOnly = true;
            this.txt_ForamaPago.Size = new System.Drawing.Size(233, 22);
            this.txt_ForamaPago.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(323, 174);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 15);
            this.label15.TabIndex = 28;
            this.label15.Text = "Forma de Pago";
            // 
            // txt_CuentaUnicaja
            // 
            this.txt_CuentaUnicaja.BackColor = System.Drawing.Color.White;
            this.txt_CuentaUnicaja.Enabled = false;
            this.txt_CuentaUnicaja.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CuentaUnicaja.Location = new System.Drawing.Point(108, 171);
            this.txt_CuentaUnicaja.Name = "txt_CuentaUnicaja";
            this.txt_CuentaUnicaja.ReadOnly = true;
            this.txt_CuentaUnicaja.Size = new System.Drawing.Size(194, 22);
            this.txt_CuentaUnicaja.TabIndex = 13;
            // 
            // txt_Otros
            // 
            this.txt_Otros.BackColor = System.Drawing.Color.White;
            this.txt_Otros.Enabled = false;
            this.txt_Otros.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Otros.Location = new System.Drawing.Point(520, 140);
            this.txt_Otros.Name = "txt_Otros";
            this.txt_Otros.ReadOnly = true;
            this.txt_Otros.Size = new System.Drawing.Size(138, 22);
            this.txt_Otros.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(447, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 15);
            this.label13.TabIndex = 23;
            this.label13.Text = "Rfc";
            // 
            // txt_EntreCalle
            // 
            this.txt_EntreCalle.BackColor = System.Drawing.Color.White;
            this.txt_EntreCalle.Enabled = false;
            this.txt_EntreCalle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EntreCalle.Location = new System.Drawing.Point(108, 113);
            this.txt_EntreCalle.Name = "txt_EntreCalle";
            this.txt_EntreCalle.ReadOnly = true;
            this.txt_EntreCalle.Size = new System.Drawing.Size(315, 22);
            this.txt_EntreCalle.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 113);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 15);
            this.label12.TabIndex = 22;
            this.label12.Text = "Entre Calles  ";
            // 
            // txt_Cp
            // 
            this.txt_Cp.BackColor = System.Drawing.Color.White;
            this.txt_Cp.Enabled = false;
            this.txt_Cp.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cp.Location = new System.Drawing.Point(773, 55);
            this.txt_Cp.Name = "txt_Cp";
            this.txt_Cp.ReadOnly = true;
            this.txt_Cp.Size = new System.Drawing.Size(83, 22);
            this.txt_Cp.TabIndex = 5;
            // 
            // txt_TelParticular
            // 
            this.txt_TelParticular.BackColor = System.Drawing.Color.White;
            this.txt_TelParticular.Enabled = false;
            this.txt_TelParticular.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelParticular.Location = new System.Drawing.Point(108, 142);
            this.txt_TelParticular.Name = "txt_TelParticular";
            this.txt_TelParticular.ReadOnly = true;
            this.txt_TelParticular.Size = new System.Drawing.Size(117, 22);
            this.txt_TelParticular.TabIndex = 10;
            // 
            // txt_Estado
            // 
            this.txt_Estado.BackColor = System.Drawing.Color.White;
            this.txt_Estado.Enabled = false;
            this.txt_Estado.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Estado.Location = new System.Drawing.Point(520, 55);
            this.txt_Estado.Name = "txt_Estado";
            this.txt_Estado.ReadOnly = true;
            this.txt_Estado.Size = new System.Drawing.Size(209, 22);
            this.txt_Estado.TabIndex = 4;
            // 
            // txt_Colonia
            // 
            this.txt_Colonia.BackColor = System.Drawing.Color.White;
            this.txt_Colonia.Enabled = false;
            this.txt_Colonia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Colonia.Location = new System.Drawing.Point(108, 81);
            this.txt_Colonia.Name = "txt_Colonia";
            this.txt_Colonia.ReadOnly = true;
            this.txt_Colonia.Size = new System.Drawing.Size(315, 22);
            this.txt_Colonia.TabIndex = 6;
            // 
            // txt_rfc
            // 
            this.txt_rfc.BackColor = System.Drawing.Color.White;
            this.txt_rfc.Enabled = false;
            this.txt_rfc.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rfc.Location = new System.Drawing.Point(520, 28);
            this.txt_rfc.Name = "txt_rfc";
            this.txt_rfc.ReadOnly = true;
            this.txt_rfc.Size = new System.Drawing.Size(209, 22);
            this.txt_rfc.TabIndex = 2;
            // 
            // txt_Direccion
            // 
            this.txt_Direccion.BackColor = System.Drawing.Color.White;
            this.txt_Direccion.Enabled = false;
            this.txt_Direccion.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Direccion.Location = new System.Drawing.Point(108, 52);
            this.txt_Direccion.Name = "txt_Direccion";
            this.txt_Direccion.ReadOnly = true;
            this.txt_Direccion.Size = new System.Drawing.Size(315, 22);
            this.txt_Direccion.TabIndex = 3;
            // 
            // txt_TelMovil
            // 
            this.txt_TelMovil.BackColor = System.Drawing.Color.White;
            this.txt_TelMovil.Enabled = false;
            this.txt_TelMovil.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelMovil.Location = new System.Drawing.Point(288, 141);
            this.txt_TelMovil.Name = "txt_TelMovil";
            this.txt_TelMovil.ReadOnly = true;
            this.txt_TelMovil.Size = new System.Drawing.Size(135, 22);
            this.txt_TelMovil.TabIndex = 11;
            // 
            // txt_Correo
            // 
            this.txt_Correo.BackColor = System.Drawing.Color.White;
            this.txt_Correo.Enabled = false;
            this.txt_Correo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Correo.Location = new System.Drawing.Point(520, 113);
            this.txt_Correo.Name = "txt_Correo";
            this.txt_Correo.ReadOnly = true;
            this.txt_Correo.Size = new System.Drawing.Size(336, 22);
            this.txt_Correo.TabIndex = 9;
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.BackColor = System.Drawing.Color.White;
            this.txt_Nombre.Enabled = false;
            this.txt_Nombre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre.Location = new System.Drawing.Point(108, 24);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.ReadOnly = true;
            this.txt_Nombre.Size = new System.Drawing.Size(315, 22);
            this.txt_Nombre.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "Nombre ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 15);
            this.label10.TabIndex = 10;
            this.label10.Text = "Direccion ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "Colonia ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(449, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "Correo ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Tel Particular ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Cuenta Unicaja ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(231, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tel Movil ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(745, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(449, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Estado ";
            // 
            // panelContactos
            // 
            this.panelContactos.AutoSize = true;
            this.panelContactos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelContactos.Controls.Add(this.btn_DatosCobrar);
            this.panelContactos.Controls.Add(this.gbx_DatosPorCobrar);
            this.panelContactos.Controls.Add(this.btn_VentasPendientes);
            this.panelContactos.Controls.Add(this.gbx_DatosVentasPendientes);
            this.panelContactos.Controls.Add(this.btn_HabitosPago);
            this.panelContactos.Controls.Add(this.gbx_DatosHabitosPago);
            this.panelContactos.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelContactos.Location = new System.Drawing.Point(82, 249);
            this.panelContactos.Name = "panelContactos";
            this.panelContactos.Size = new System.Drawing.Size(874, 813);
            this.panelContactos.TabIndex = 50;
            // 
            // gbx_DatosPorCobrar
            // 
            this.gbx_DatosPorCobrar.Controls.Add(this.cbx_FechaCobrarA);
            this.gbx_DatosPorCobrar.Controls.Add(this.cbx_FechaCobrarDe);
            this.gbx_DatosPorCobrar.Controls.Add(this.label21);
            this.gbx_DatosPorCobrar.Controls.Add(this.label20);
            this.gbx_DatosPorCobrar.Controls.Add(this.label1);
            this.gbx_DatosPorCobrar.Controls.Add(this.lbl_TotalCobrar);
            this.gbx_DatosPorCobrar.Controls.Add(this.lbl_Venciminto);
            this.gbx_DatosPorCobrar.Controls.Add(this.dgv_PorCobrar);
            this.gbx_DatosPorCobrar.Location = new System.Drawing.Point(3, 56);
            this.gbx_DatosPorCobrar.Name = "gbx_DatosPorCobrar";
            this.gbx_DatosPorCobrar.Size = new System.Drawing.Size(868, 166);
            this.gbx_DatosPorCobrar.TabIndex = 54;
            this.gbx_DatosPorCobrar.TabStop = false;
            // 
            // cbx_FechaCobrarA
            // 
            this.cbx_FechaCobrarA.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.cbx_FechaCobrarA.Location = new System.Drawing.Point(163, 37);
            this.cbx_FechaCobrarA.Name = "cbx_FechaCobrarA";
            this.cbx_FechaCobrarA.Size = new System.Drawing.Size(99, 20);
            this.cbx_FechaCobrarA.TabIndex = 13;
            this.cbx_FechaCobrarA.CloseUp += new System.EventHandler(this.cbx_FechaCobrarA_CloseUp);
            this.cbx_FechaCobrarA.TabIndexChanged += new System.EventHandler(this.cbx_FechaCobrarA_TabIndexChanged);
            // 
            // cbx_FechaCobrarDe
            // 
            this.cbx_FechaCobrarDe.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.cbx_FechaCobrarDe.Location = new System.Drawing.Point(28, 37);
            this.cbx_FechaCobrarDe.Name = "cbx_FechaCobrarDe";
            this.cbx_FechaCobrarDe.Size = new System.Drawing.Size(101, 20);
            this.cbx_FechaCobrarDe.TabIndex = 12;
            this.cbx_FechaCobrarDe.CloseUp += new System.EventHandler(this.cbx_FechaCobrarDe_CloseUp);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(141, 39);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 15);
            this.label21.TabIndex = 11;
            this.label21.Text = "A";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(5, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(22, 15);
            this.label20.TabIndex = 10;
            this.label20.Text = "De";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(282, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Saldo Total";
            // 
            // lbl_TotalCobrar
            // 
            this.lbl_TotalCobrar.AutoSize = true;
            this.lbl_TotalCobrar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalCobrar.Location = new System.Drawing.Point(355, 38);
            this.lbl_TotalCobrar.Name = "lbl_TotalCobrar";
            this.lbl_TotalCobrar.Size = new System.Drawing.Size(38, 15);
            this.lbl_TotalCobrar.TabIndex = 3;
            this.lbl_TotalCobrar.Text = "label1";
            // 
            // lbl_Venciminto
            // 
            this.lbl_Venciminto.AutoSize = true;
            this.lbl_Venciminto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Venciminto.Location = new System.Drawing.Point(119, 16);
            this.lbl_Venciminto.Name = "lbl_Venciminto";
            this.lbl_Venciminto.Size = new System.Drawing.Size(75, 15);
            this.lbl_Venciminto.TabIndex = 1;
            this.lbl_Venciminto.Text = "Vencimiento";
            // 
            // dgv_PorCobrar
            // 
            this.dgv_PorCobrar.AllowUserToAddRows = false;
            this.dgv_PorCobrar.AllowUserToDeleteRows = false;
            this.dgv_PorCobrar.AllowUserToResizeColumns = false;
            this.dgv_PorCobrar.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_PorCobrar.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PorCobrar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_PorCobrar.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_PorCobrar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PorCobrar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_PorCobrar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_PorCobrar.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_PorCobrar.EnableHeadersVisualStyles = false;
            this.dgv_PorCobrar.Location = new System.Drawing.Point(6, 75);
            this.dgv_PorCobrar.Name = "dgv_PorCobrar";
            this.dgv_PorCobrar.ReadOnly = true;
            this.dgv_PorCobrar.RowHeadersVisible = false;
            this.dgv_PorCobrar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_PorCobrar.Size = new System.Drawing.Size(847, 81);
            this.dgv_PorCobrar.TabIndex = 0;
            // 
            // gbx_DatosVentasPendientes
            // 
            this.gbx_DatosVentasPendientes.Controls.Add(this.txt_VentaPendienteFechaA);
            this.gbx_DatosVentasPendientes.Controls.Add(this.txt_VentaPendienteFechaDe);
            this.gbx_DatosVentasPendientes.Controls.Add(this.label22);
            this.gbx_DatosVentasPendientes.Controls.Add(this.label23);
            this.gbx_DatosVentasPendientes.Controls.Add(this.label24);
            this.gbx_DatosVentasPendientes.Controls.Add(this.lbl_Total);
            this.gbx_DatosVentasPendientes.Controls.Add(this.label19);
            this.gbx_DatosVentasPendientes.Controls.Add(this.dgv_VentasPendientes);
            this.gbx_DatosVentasPendientes.Location = new System.Drawing.Point(3, 291);
            this.gbx_DatosVentasPendientes.Name = "gbx_DatosVentasPendientes";
            this.gbx_DatosVentasPendientes.Size = new System.Drawing.Size(868, 203);
            this.gbx_DatosVentasPendientes.TabIndex = 56;
            this.gbx_DatosVentasPendientes.TabStop = false;
            // 
            // txt_VentaPendienteFechaA
            // 
            this.txt_VentaPendienteFechaA.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_VentaPendienteFechaA.Location = new System.Drawing.Point(172, 38);
            this.txt_VentaPendienteFechaA.Name = "txt_VentaPendienteFechaA";
            this.txt_VentaPendienteFechaA.Size = new System.Drawing.Size(104, 20);
            this.txt_VentaPendienteFechaA.TabIndex = 17;
            this.txt_VentaPendienteFechaA.CloseUp += new System.EventHandler(this.txt_VentaPendienteFechaA_CloseUp);
            // 
            // txt_VentaPendienteFechaDe
            // 
            this.txt_VentaPendienteFechaDe.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_VentaPendienteFechaDe.Location = new System.Drawing.Point(34, 38);
            this.txt_VentaPendienteFechaDe.Name = "txt_VentaPendienteFechaDe";
            this.txt_VentaPendienteFechaDe.Size = new System.Drawing.Size(95, 20);
            this.txt_VentaPendienteFechaDe.TabIndex = 14;
            this.txt_VentaPendienteFechaDe.CloseUp += new System.EventHandler(this.txt_VentaPendienteFechaDe_CloseUp);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(150, 41);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 15);
            this.label22.TabIndex = 16;
            this.label22.Text = "A";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 40);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(22, 15);
            this.label23.TabIndex = 15;
            this.label23.Text = "De";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(110, 14);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 15);
            this.label24.TabIndex = 12;
            this.label24.Text = "Fecha Emision";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(361, 38);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(13, 15);
            this.lbl_Total.TabIndex = 7;
            this.lbl_Total.Text = "$";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(288, 38);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 15);
            this.label19.TabIndex = 6;
            this.label19.Text = "Saldo Total";
            // 
            // dgv_VentasPendientes
            // 
            this.dgv_VentasPendientes.AllowUserToAddRows = false;
            this.dgv_VentasPendientes.AllowUserToDeleteRows = false;
            this.dgv_VentasPendientes.AllowUserToResizeColumns = false;
            this.dgv_VentasPendientes.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_VentasPendientes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_VentasPendientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_VentasPendientes.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_VentasPendientes.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_VentasPendientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_VentasPendientes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_VentasPendientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_VentasPendientes.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_VentasPendientes.EnableHeadersVisualStyles = false;
            this.dgv_VentasPendientes.Location = new System.Drawing.Point(21, 78);
            this.dgv_VentasPendientes.Name = "dgv_VentasPendientes";
            this.dgv_VentasPendientes.ReadOnly = true;
            this.dgv_VentasPendientes.RowHeadersVisible = false;
            this.dgv_VentasPendientes.Size = new System.Drawing.Size(832, 107);
            this.dgv_VentasPendientes.TabIndex = 3;
            // 
            // gbx_DatosHabitosPago
            // 
            this.gbx_DatosHabitosPago.Controls.Add(this.txt_BuscarHabitos);
            this.gbx_DatosHabitosPago.Controls.Add(this.txt_HabitosPagoFechaDe);
            this.gbx_DatosHabitosPago.Controls.Add(this.txt_HabitosPagoFechaA);
            this.gbx_DatosHabitosPago.Controls.Add(this.label16);
            this.gbx_DatosHabitosPago.Controls.Add(this.label25);
            this.gbx_DatosHabitosPago.Controls.Add(this.label26);
            this.gbx_DatosHabitosPago.Controls.Add(this.lbl_Tot);
            this.gbx_DatosHabitosPago.Controls.Add(this.lbl_ImporteTot);
            this.gbx_DatosHabitosPago.Controls.Add(this.lbl_TotalDiasR);
            this.gbx_DatosHabitosPago.Controls.Add(this.lbl_ImporteDiasRetraso);
            this.gbx_DatosHabitosPago.Controls.Add(this.lbl_DiasRetraso);
            this.gbx_DatosHabitosPago.Controls.Add(this.dgv_HabitosPago);
            this.gbx_DatosHabitosPago.Controls.Add(this.label18);
            this.gbx_DatosHabitosPago.Controls.Add(this.label5);
            this.gbx_DatosHabitosPago.Location = new System.Drawing.Point(3, 561);
            this.gbx_DatosHabitosPago.Margin = new System.Windows.Forms.Padding(3, 3, 3, 33);
            this.gbx_DatosHabitosPago.Name = "gbx_DatosHabitosPago";
            this.gbx_DatosHabitosPago.Size = new System.Drawing.Size(868, 219);
            this.gbx_DatosHabitosPago.TabIndex = 58;
            this.gbx_DatosHabitosPago.TabStop = false;
            // 
            // txt_BuscarHabitos
            // 
            this.txt_BuscarHabitos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_BuscarHabitos.Location = new System.Drawing.Point(285, 45);
            this.txt_BuscarHabitos.Name = "txt_BuscarHabitos";
            this.txt_BuscarHabitos.Size = new System.Drawing.Size(141, 22);
            this.txt_BuscarHabitos.TabIndex = 22;
            this.txt_BuscarHabitos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_BuscarHabitos_KeyPress_1);
            // 
            // txt_HabitosPagoFechaDe
            // 
            this.txt_HabitosPagoFechaDe.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_HabitosPagoFechaDe.Location = new System.Drawing.Point(28, 45);
            this.txt_HabitosPagoFechaDe.Name = "txt_HabitosPagoFechaDe";
            this.txt_HabitosPagoFechaDe.Size = new System.Drawing.Size(100, 20);
            this.txt_HabitosPagoFechaDe.TabIndex = 18;
            this.txt_HabitosPagoFechaDe.CloseUp += new System.EventHandler(this.txt_HabitosPagoFechaDe_CloseUp);
            // 
            // txt_HabitosPagoFechaA
            // 
            this.txt_HabitosPagoFechaA.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_HabitosPagoFechaA.Location = new System.Drawing.Point(166, 47);
            this.txt_HabitosPagoFechaA.Name = "txt_HabitosPagoFechaA";
            this.txt_HabitosPagoFechaA.Size = new System.Drawing.Size(99, 20);
            this.txt_HabitosPagoFechaA.TabIndex = 19;
            this.txt_HabitosPagoFechaA.CloseUp += new System.EventHandler(this.txt_HabitosPagoFechaA_CloseUp);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(147, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 15);
            this.label16.TabIndex = 21;
            this.label16.Text = "A";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(3, 47);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(22, 15);
            this.label25.TabIndex = 20;
            this.label25.Text = "De";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(110, 24);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(75, 15);
            this.label26.TabIndex = 17;
            this.label26.Text = "Vencimiento";
            // 
            // lbl_Tot
            // 
            this.lbl_Tot.AutoSize = true;
            this.lbl_Tot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tot.Location = new System.Drawing.Point(331, 89);
            this.lbl_Tot.Name = "lbl_Tot";
            this.lbl_Tot.Size = new System.Drawing.Size(13, 15);
            this.lbl_Tot.TabIndex = 14;
            this.lbl_Tot.Text = "$";
            // 
            // lbl_ImporteTot
            // 
            this.lbl_ImporteTot.AutoSize = true;
            this.lbl_ImporteTot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ImporteTot.Location = new System.Drawing.Point(237, 89);
            this.lbl_ImporteTot.Name = "lbl_ImporteTot";
            this.lbl_ImporteTot.Size = new System.Drawing.Size(79, 15);
            this.lbl_ImporteTot.TabIndex = 13;
            this.lbl_ImporteTot.Text = "Importe Total";
            // 
            // lbl_TotalDiasR
            // 
            this.lbl_TotalDiasR.AutoSize = true;
            this.lbl_TotalDiasR.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalDiasR.Location = new System.Drawing.Point(144, 90);
            this.lbl_TotalDiasR.Name = "lbl_TotalDiasR";
            this.lbl_TotalDiasR.Size = new System.Drawing.Size(13, 15);
            this.lbl_TotalDiasR.TabIndex = 12;
            this.lbl_TotalDiasR.Text = "$";
            // 
            // lbl_ImporteDiasRetraso
            // 
            this.lbl_ImporteDiasRetraso.AutoSize = true;
            this.lbl_ImporteDiasRetraso.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ImporteDiasRetraso.Location = new System.Drawing.Point(12, 90);
            this.lbl_ImporteDiasRetraso.Name = "lbl_ImporteDiasRetraso";
            this.lbl_ImporteDiasRetraso.Size = new System.Drawing.Size(123, 15);
            this.lbl_ImporteDiasRetraso.TabIndex = 11;
            this.lbl_ImporteDiasRetraso.Text = "Total Dias de Retraso";
            // 
            // lbl_DiasRetraso
            // 
            this.lbl_DiasRetraso.AutoSize = true;
            this.lbl_DiasRetraso.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiasRetraso.Location = new System.Drawing.Point(160, 250);
            this.lbl_DiasRetraso.Name = "lbl_DiasRetraso";
            this.lbl_DiasRetraso.Size = new System.Drawing.Size(0, 15);
            this.lbl_DiasRetraso.TabIndex = 10;
            // 
            // dgv_HabitosPago
            // 
            this.dgv_HabitosPago.AllowUserToAddRows = false;
            this.dgv_HabitosPago.AllowUserToDeleteRows = false;
            this.dgv_HabitosPago.AllowUserToResizeColumns = false;
            this.dgv_HabitosPago.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_HabitosPago.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_HabitosPago.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_HabitosPago.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_HabitosPago.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_HabitosPago.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_HabitosPago.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_HabitosPago.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_HabitosPago.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_HabitosPago.EnableHeadersVisualStyles = false;
            this.dgv_HabitosPago.Location = new System.Drawing.Point(9, 108);
            this.dgv_HabitosPago.Name = "dgv_HabitosPago";
            this.dgv_HabitosPago.ReadOnly = true;
            this.dgv_HabitosPago.RowHeadersVisible = false;
            this.dgv_HabitosPago.Size = new System.Drawing.Size(856, 102);
            this.dgv_HabitosPago.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(282, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(282, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Buscar Movimiento";
            // 
            // Panel_Menu
            // 
            this.Panel_Menu.Controls.Add(this.btn_Regresar);
            this.Panel_Menu.Controls.Add(this.btn_ImgenesCliente);
            this.Panel_Menu.Controls.Add(this.btn_ayuda);
            this.Panel_Menu.Controls.Add(this.btnActualizarCliente);
            this.Panel_Menu.Controls.Add(this.btnActualizarBeneficiario);
            this.Panel_Menu.Controls.Add(this.btnActualizarAval);
            this.Panel_Menu.Location = new System.Drawing.Point(1, 41);
            this.Panel_Menu.Name = "Panel_Menu";
            this.Panel_Menu.Size = new System.Drawing.Size(84, 514);
            this.Panel_Menu.TabIndex = 52;
            // 
            // btnActualizarAval
            // 
            this.btnActualizarAval.BackColor = System.Drawing.Color.White;
            this.btnActualizarAval.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActualizarAval.FlatAppearance.BorderSize = 0;
            this.btnActualizarAval.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizarAval.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizarAval.Image = global::PuntoVenta.Properties.Resources.btnActualizarAval;
            this.btnActualizarAval.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnActualizarAval.Location = new System.Drawing.Point(3, 439);
            this.btnActualizarAval.Name = "btnActualizarAval";
            this.btnActualizarAval.Size = new System.Drawing.Size(72, 79);
            this.btnActualizarAval.TabIndex = 57;
            this.btnActualizarAval.Text = "Actualizar Aval";
            this.btnActualizarAval.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnActualizarAval.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnActualizarAval.UseVisualStyleBackColor = false;
            this.btnActualizarAval.Click += new System.EventHandler(this.btnActualizarAval_Click);
            // 
            // lbl_Cliente
            // 
            this.lbl_Cliente.AutoSize = true;
            this.lbl_Cliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cliente.Location = new System.Drawing.Point(881, 19);
            this.lbl_Cliente.Name = "lbl_Cliente";
            this.lbl_Cliente.Size = new System.Drawing.Size(57, 19);
            this.lbl_Cliente.TabIndex = 53;
            this.lbl_Cliente.Text = "Cliente";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(809, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(62, 19);
            this.label27.TabIndex = 54;
            this.label27.Text = "Cliente:";
            // 
            // txt_Comentarios
            // 
            this.txt_Comentarios.BackColor = System.Drawing.Color.White;
            this.txt_Comentarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Comentarios.Enabled = false;
            this.txt_Comentarios.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Comentarios.Location = new System.Drawing.Point(85, 3);
            this.txt_Comentarios.Multiline = true;
            this.txt_Comentarios.Name = "txt_Comentarios";
            this.txt_Comentarios.Size = new System.Drawing.Size(702, 35);
            this.txt_Comentarios.TabIndex = 106;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.Color.White;
            this.btn_Regresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Regresar.FlatAppearance.BorderSize = 0;
            this.btn_Regresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regresar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Regresar.Image")));
            this.btn_Regresar.Location = new System.Drawing.Point(3, 3);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(69, 71);
            this.btn_Regresar.TabIndex = 18;
            this.btn_Regresar.Text = "Regresar (Esc)";
            this.btn_Regresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Regresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_ImgenesCliente
            // 
            this.btn_ImgenesCliente.BackColor = System.Drawing.Color.White;
            this.btn_ImgenesCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ImgenesCliente.FlatAppearance.BorderSize = 0;
            this.btn_ImgenesCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ImgenesCliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ImgenesCliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_ImgenesCliente.Image")));
            this.btn_ImgenesCliente.Location = new System.Drawing.Point(3, 80);
            this.btn_ImgenesCliente.Name = "btn_ImgenesCliente";
            this.btn_ImgenesCliente.Size = new System.Drawing.Size(69, 92);
            this.btn_ImgenesCliente.TabIndex = 51;
            this.btn_ImgenesCliente.Text = "Imagenes del Cliente";
            this.btn_ImgenesCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ImgenesCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ImgenesCliente.UseVisualStyleBackColor = false;
            this.btn_ImgenesCliente.Click += new System.EventHandler(this.btn_ImgenesCliente_Click);
            // 
            // btn_ayuda
            // 
            this.btn_ayuda.BackColor = System.Drawing.Color.White;
            this.btn_ayuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ayuda.FlatAppearance.BorderSize = 0;
            this.btn_ayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ayuda.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ayuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ayuda.Image")));
            this.btn_ayuda.Location = new System.Drawing.Point(3, 178);
            this.btn_ayuda.Name = "btn_ayuda";
            this.btn_ayuda.Size = new System.Drawing.Size(72, 63);
            this.btn_ayuda.TabIndex = 19;
            this.btn_ayuda.Text = "Ayuda";
            this.btn_ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ayuda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ayuda.UseVisualStyleBackColor = false;
            // 
            // btnActualizarCliente
            // 
            this.btnActualizarCliente.BackColor = System.Drawing.Color.White;
            this.btnActualizarCliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnActualizarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActualizarCliente.FlatAppearance.BorderSize = 0;
            this.btnActualizarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizarCliente.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizarCliente.Image = global::PuntoVenta.Properties.Resources.btnActualizarCliente;
            this.btnActualizarCliente.Location = new System.Drawing.Point(3, 247);
            this.btnActualizarCliente.Name = "btnActualizarCliente";
            this.btnActualizarCliente.Size = new System.Drawing.Size(69, 92);
            this.btnActualizarCliente.TabIndex = 55;
            this.btnActualizarCliente.Text = "Actualizar Cliente";
            this.btnActualizarCliente.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnActualizarCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnActualizarCliente.UseVisualStyleBackColor = false;
            this.btnActualizarCliente.Click += new System.EventHandler(this.btnActualizarCliente_Click);
            // 
            // btnActualizarBeneficiario
            // 
            this.btnActualizarBeneficiario.BackColor = System.Drawing.Color.White;
            this.btnActualizarBeneficiario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActualizarBeneficiario.FlatAppearance.BorderSize = 0;
            this.btnActualizarBeneficiario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizarBeneficiario.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizarBeneficiario.Image = global::PuntoVenta.Properties.Resources.btnActualizarBeneficiario;
            this.btnActualizarBeneficiario.Location = new System.Drawing.Point(3, 345);
            this.btnActualizarBeneficiario.Name = "btnActualizarBeneficiario";
            this.btnActualizarBeneficiario.Size = new System.Drawing.Size(79, 88);
            this.btnActualizarBeneficiario.TabIndex = 56;
            this.btnActualizarBeneficiario.Text = "Actualizar Beneficiario Final";
            this.btnActualizarBeneficiario.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnActualizarBeneficiario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnActualizarBeneficiario.UseVisualStyleBackColor = false;
            this.btnActualizarBeneficiario.Click += new System.EventHandler(this.btnActualizarBeneficiario_Click);
            // 
            // btn_DatosCobrar
            // 
            this.btn_DatosCobrar.BackColor = System.Drawing.Color.White;
            this.btn_DatosCobrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_DatosCobrar.FlatAppearance.BorderSize = 0;
            this.btn_DatosCobrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DatosCobrar.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatosCobrar.Image = ((System.Drawing.Image)(resources.GetObject("btn_DatosCobrar.Image")));
            this.btn_DatosCobrar.Location = new System.Drawing.Point(3, 3);
            this.btn_DatosCobrar.Name = "btn_DatosCobrar";
            this.btn_DatosCobrar.Size = new System.Drawing.Size(205, 47);
            this.btn_DatosCobrar.TabIndex = 53;
            this.btn_DatosCobrar.Text = "Documentos por Cobrar";
            this.btn_DatosCobrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DatosCobrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_DatosCobrar.UseVisualStyleBackColor = false;
            this.btn_DatosCobrar.Click += new System.EventHandler(this.btn_DatosCobrar_Click);
            // 
            // btn_VentasPendientes
            // 
            this.btn_VentasPendientes.BackColor = System.Drawing.Color.White;
            this.btn_VentasPendientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_VentasPendientes.FlatAppearance.BorderSize = 0;
            this.btn_VentasPendientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_VentasPendientes.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_VentasPendientes.Image = ((System.Drawing.Image)(resources.GetObject("btn_VentasPendientes.Image")));
            this.btn_VentasPendientes.Location = new System.Drawing.Point(3, 228);
            this.btn_VentasPendientes.Name = "btn_VentasPendientes";
            this.btn_VentasPendientes.Size = new System.Drawing.Size(182, 57);
            this.btn_VentasPendientes.TabIndex = 61;
            this.btn_VentasPendientes.Text = "Ventas Pendientes";
            this.btn_VentasPendientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_VentasPendientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_VentasPendientes.UseVisualStyleBackColor = false;
            this.btn_VentasPendientes.Click += new System.EventHandler(this.btn_VentasPendientes_Click);
            // 
            // btn_HabitosPago
            // 
            this.btn_HabitosPago.BackColor = System.Drawing.Color.White;
            this.btn_HabitosPago.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_HabitosPago.FlatAppearance.BorderSize = 0;
            this.btn_HabitosPago.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_HabitosPago.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HabitosPago.Image = ((System.Drawing.Image)(resources.GetObject("btn_HabitosPago.Image")));
            this.btn_HabitosPago.Location = new System.Drawing.Point(3, 500);
            this.btn_HabitosPago.Name = "btn_HabitosPago";
            this.btn_HabitosPago.Size = new System.Drawing.Size(159, 55);
            this.btn_HabitosPago.TabIndex = 60;
            this.btn_HabitosPago.Text = "Habitos de Pago";
            this.btn_HabitosPago.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_HabitosPago.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_HabitosPago.UseVisualStyleBackColor = false;
            this.btn_HabitosPago.Click += new System.EventHandler(this.btn_HabitosPago_Click);
            // 
            // InformacionCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1105, 491);
            this.Controls.Add(this.txt_Comentarios);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.lbl_Cliente);
            this.Controls.Add(this.Panel_Menu);
            this.Controls.Add(this.panelContactos);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "InformacionCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Informacion del Cliente";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InformacionCliente_FormClosing);
            this.Load += new System.EventHandler(this.InformacionCliente_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.InformacionCliente_Scroll);
            this.LocationChanged += new System.EventHandler(this.InformacionCliente_LocationChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InformacionCliente_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelContactos.ResumeLayout(false);
            this.gbx_DatosPorCobrar.ResumeLayout(false);
            this.gbx_DatosPorCobrar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PorCobrar)).EndInit();
            this.gbx_DatosVentasPendientes.ResumeLayout(false);
            this.gbx_DatosVentasPendientes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VentasPendientes)).EndInit();
            this.gbx_DatosHabitosPago.ResumeLayout(false);
            this.gbx_DatosHabitosPago.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_HabitosPago)).EndInit();
            this.Panel_Menu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_ForamaPago;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_CuentaUnicaja;
        private System.Windows.Forms.TextBox txt_Otros;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_Cp;
        private System.Windows.Forms.TextBox txt_TelParticular;
        private System.Windows.Forms.TextBox txt_Estado;
        private System.Windows.Forms.TextBox txt_Colonia;
        private System.Windows.Forms.TextBox txt_EntreCalle;
        private System.Windows.Forms.TextBox txt_rfc;
        private System.Windows.Forms.TextBox txt_Direccion;
        private System.Windows.Forms.TextBox txt_TelMovil;
        private System.Windows.Forms.TextBox txt_Correo;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_ayuda;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.TextBox txt_Municipio;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.FlowLayoutPanel panelContactos;
        private System.Windows.Forms.Button btn_DatosCobrar;
        private System.Windows.Forms.GroupBox gbx_DatosPorCobrar;
        private System.Windows.Forms.Label lbl_Venciminto;
        private System.Windows.Forms.DataGridView dgv_PorCobrar;
        private System.Windows.Forms.GroupBox gbx_DatosVentasPendientes;
        private System.Windows.Forms.DataGridView dgv_VentasPendientes;
        private System.Windows.Forms.Button btn_ImgenesCliente;
        private System.Windows.Forms.Button btn_VentasPendientes;
        private System.Windows.Forms.Button btn_HabitosPago;
        private System.Windows.Forms.GroupBox gbx_DatosHabitosPago;
        private System.Windows.Forms.DataGridView dgv_HabitosPago;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.FlowLayoutPanel Panel_Menu;
        private System.Windows.Forms.Label lbl_Cliente;
        private System.Windows.Forms.Label lbl_DiasRetraso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_TotalCobrar;
        private System.Windows.Forms.Label lbl_Tot;
        private System.Windows.Forms.Label lbl_ImporteTot;
        private System.Windows.Forms.Label lbl_TotalDiasR;
        private System.Windows.Forms.Label lbl_ImporteDiasRetraso;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker cbx_FechaCobrarA;
        private System.Windows.Forms.DateTimePicker cbx_FechaCobrarDe;
        private System.Windows.Forms.DateTimePicker txt_VentaPendienteFechaA;
        private System.Windows.Forms.DateTimePicker txt_VentaPendienteFechaDe;
        private System.Windows.Forms.DateTimePicker txt_HabitosPagoFechaDe;
        private System.Windows.Forms.DateTimePicker txt_HabitosPagoFechaA;
        private System.Windows.Forms.TextBox txt_BuscarHabitos;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_Comentarios;
        private System.Windows.Forms.Button btnActualizarCliente;
        private System.Windows.Forms.Button btnActualizarBeneficiario;
        private System.Windows.Forms.Button btnActualizarAval;
    }
}