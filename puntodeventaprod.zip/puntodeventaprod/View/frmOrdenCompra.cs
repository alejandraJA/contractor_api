﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;

namespace PuntoVenta.View
{
    public partial class frmOrdenCompra : Form
    {
        #region Contructor

        /// <summary>
        ///     Constructor de la clase
        /// </summary>
        /// <param name="mCompra">modelo con la informacion de la compra</param>
        public frmOrdenCompra(clsModeloOrdenCompra mCompra)
        {
            InitializeComponent();
            lblNombre.Text = mCompra.sCliente;
            lblMovimiento.Text = mCompra.sMov;
            lblMovId.Text = mCompra.sMovId;
            iIdVenta = mCompra.iIdVenta;
        }

        #endregion

        private int iIdVenta { get; }

        #region Eventos

        /// <summary>
        ///     Evento del boton de orden de compra
        /// </summary>
        private void btnPdf_Click(object sender, EventArgs e)
        {
            btnPdf.Enabled = false;
            ejecutarExe(iIdVenta);
            btnPdf.Enabled = true;
        }


        /// <summary>
        ///     Evento que se ejecuta al presionar el boton de cerrar
        /// </summary>
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            cerrar();
        }

        /// <summary>
        ///     Evento encargado de validar cuando se le preciona una tecla en el formulario
        /// </summary>
        private void frmOrdenCompra_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) cerrar();
        }

        #endregion

        #region Metodos

        /// <summary>
        ///     Metodo encargado de ejecutar el plugin de orden de compra
        /// </summary>
        /// <param name="iIdVenta">id de de la venta que generara el reporte</param>
        private void ejecutarExe(int iIdVenta)
        {
            try
            {
                Process pOrdenCompra = new Process();
                pOrdenCompra.StartInfo.WorkingDirectory = ClaseEstatica.plugInPath;
                pOrdenCompra.StartInfo.FileName = ClaseEstatica.plugInPath + "OrdenCompra\\OrdendeCompra.exe";

                pOrdenCompra.StartInfo.Verb = "runas";
                pOrdenCompra.StartInfo.Arguments = iIdVenta.ToString();
                pOrdenCompra.StartInfo.UseShellExecute = false;
                pOrdenCompra.Start();
                pOrdenCompra.WaitForExit();
                pOrdenCompra.Dispose();
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError(MethodBase.GetCurrentMethod().Name,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        ///     Metodo encargado de hacer la pregunta y cerrar el formulario
        /// </summary>
        private void cerrar()
        {
            Close();
        }

        #endregion
    }
}