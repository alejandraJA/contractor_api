﻿using System;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace PuntoVenta.Security
{
    public class AESSecurityManager
    {
        private const string AesIV256 = @"gw8#gg&!F*dv1glX";
        private const string AesKey256 = @"a&H2pWLZpUdxWbHQeqNf!s2ie7e9d6@Z";

        public string CifrarAES256(string cadena)
        {
            try
            {
                int IVlength = AesIV256.Length;
                int KEYlength = AesKey256.Length;
                if (string.IsNullOrEmpty(cadena)) throw new ArgumentNullException(nameof(cadena));
                byte[] KEY = Encoding.ASCII.GetBytes(AesKey256);
                byte[] IV = Encoding.ASCII.GetBytes(AesIV256);
                byte[] arrayCadena = Encoding.ASCII.GetBytes(cadena);
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.ECB;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.BlockSize = 128;
                    using (ICryptoTransform encrypt = aes.CreateEncryptor(KEY, IV))
                    {
                        byte[] data = encrypt.TransformFinalBlock(arrayCadena, 0, arrayCadena.Length);
                        encrypt.Dispose();
                        return Convert.ToBase64String(data);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return string.Empty;
            }
        }

        public string DecifrarAES256(string cadena)
        {
            try
            {
                if (string.IsNullOrEmpty(cadena)) throw new ArgumentNullException(nameof(cadena));
                byte[] KEY = Encoding.ASCII.GetBytes(AesKey256);
                byte[] IV = Encoding.ASCII.GetBytes(AesIV256);
                byte[] arrayCadena = Convert.FromBase64String(cadena);
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.ECB;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.BlockSize = 128;
                    using (ICryptoTransform encrypt = aes.CreateDecryptor(KEY, IV))
                    {
                        byte[] data = encrypt.TransformFinalBlock(arrayCadena, 0, arrayCadena.Length);
                        encrypt.Dispose();
                        return Encoding.UTF8.GetString(data);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.Fail(ex.Message);
                return string.Empty;
            }
        }
    }
}