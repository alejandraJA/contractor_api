SET DATEFIRST 7
SET ANSI_NULLS ON
SET ANSI_WARNINGS ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT - 1
SET QUOTED_IDENTIFIER OFF
SET NOCOUNT ON
SET IMPLICIT_TRANSACTIONS OFF
GO

  
---------------------------------------------------------------------------------------------------------------------------------------------    
-- NOMBRE : SpCREDIValeDigital      
-- AUTOR : Armando Morelos Gonzalez      
-- FECHA CREACION : 2019-12-09     
-- DESCRIPCION : Consultas para obtener y validaciones de Vales Digitales    
-- DESARROLLO : Venta DIMA Vale Digital      
-- EJEMPLO : EXEC SpCREDIDatosSolicitudCreditoArt 'GetSaldo','C01504823', null    
---------------------------------------------------------------------------------------------------------------------------------------------      
  
CREATE PROCEDURE [dbo].[SpCREDIValeDigital] @Op varchar(20),  
@Vale varchar(25) = NULL,  
@id int = NULL  
AS  
BEGIN  
  
  DECLARE @idVale int,  
          @cliente varchar(20),  
          @fechaExpiracion datetime,  
          @estatus int,  
          @resp int = 0  
  
  IF @Op = "validar"  
  BEGIN  
  
    IF (SELECT  
        COUNT(IdPedidoValeDigital)  
      FROM VTASDPedidoValeDigital WITH (NOLOCK)  
      WHERE vale = @Vale)  
      > 0  
    BEGIN  
  
      SELECT TOP 1  
        @estatus = fv.ESTATUS,  
        @fechaExpiracion = vd.FechaExpiracion  
      FROM VTASDPedidoValeDigital vd WITH (NOLOCK)  
      LEFT JOIN ERPMAVI.IntelisisTMP.dbo.DM0244_FOLIOS_VALES fv WITH (NOLOCK)  
        ON fv.CODIGOBARRAS = vd.Vale  
      WHERE vd.Vale = @Vale  
      AND fv.tipo = 2  
  
      IF (GETDATE() <= @fechaExpiracion)  
      BEGIN  
        IF (@estatus = 4)  
        BEGIN  
          SELECT  
            @resp = 3 --Vale Cancelado    
        END  
        ELSE  
        IF (@estatus = 2  
          OR @estatus = 3)  
        BEGIN  
          SELECT  
            @resp = 4 --Vale ya usado    
        END  
        ELSE  
        BEGIN  
          SELECT  
            @resp = 0 --Vale correcto    
        END  
      END  
      ELSE  
      BEGIN  
        SELECT  
          @resp = 2 --Vale expirado    
      END  
    END  
    ELSE  
    BEGIN  
      SELECT  
        @resp = 1 --Vale no existe    
    END  
  
    SELECT  
      @resp AS respuesta  
  END  
  
  
  IF @Op = "getDatosVale"  
  BEGIN  
    SELECT TOP 1  
      vd.idPedidoValeDigital,  
      vd.Cliente,  
      vd.Vale,  
      vd.TipoPedido,  
      vd.Total,  
      vd.Correo,  
      vd.Telefono,  
      vd.Canal,  
      vd.Condicion,  
      vd.ClienteBF  
    FROM VTASDPedidoValeDigital vd WITH (NOLOCK)  
    LEFT JOIN ERPMAVI.IntelisisTMP.dbo.DM0244_FOLIOS_VALES fv WITH (NOLOCK)  
      ON fv.CODIGOBARRAS = vd.Vale  
    WHERE vd.Vale = @Vale  
  END  
  
  IF @Op = "getProductosVale"  
  BEGIN  
    SELECT  
      sku,  
      cantidad,  
      nombre,  
      precio  
    FROM VTASDProductosPedidoValeDigital WITH (NOLOCK)  
    WHERE IdProductosPedidoValeDigital = @id  
  END  
  
  IF @Op = "checarTipoVale"  
  BEGIN  
    IF (SELECT TOP 1  
        id_folio  
      FROM ERPMAVI.IntelisisTMP.dbo.DM0244_FOLIOS_VALES  
      WHERE CODIGOBARRAS = @Vale  
      AND tipo = 2)  
      > 1  
    BEGIN  
      SET @resp = 1  
    END  
    ELSE  
    BEGIN  
      SET @resp = 0  
    END  
    SELECT  
      @resp  
  END  
  
  IF @Op = "cancelarVale"  
  BEGIN  
    UPDATE VTASDPedidoValeDigital WITH (ROWLOCK)  
    SET Estatus = 14  
    WHERE Vale = @Vale  
    UPDATE ERPMAVI.IntelisisTMP.dbo.DM0244_FOLIOS_VALES WITH (ROWLOCK)  
    SET Estatus = 4,  
        FECHA_CANCELACION = GETDATE()  
    WHERE CODIGOBARRAS = @Vale  
  
 SELECT @@ROWCOUNT AS Actualizo;  
  END  
END