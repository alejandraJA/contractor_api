SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT - 1
SET QUOTED_IDENTIFIER OFF
SET NOCOUNT ON
SET IMPLICIT_TRANSACTIONS OFF
GO

--============================================================================================================================================================   
--NOMBRE   : SP_DM0312OperacionesInsDelVentaD  
--AUTOR    : Dan Asael Palacios Gonzalez  
--FECHA CREACION : 26/08/2017  
--DESARROLLO  : DM0312 PUNTO DE VENTA  
--ESTANDAR NOCOUNT : DEBE IR ENCENDIDO DESPUES DEL CREATE O ALTER DEL PROCEDURE Y APAGARLOS AL FINALIZAR SU EJECUCION  
--DESCRIPCION  : SP PARA LAS DISTINTAS FUNCIONES EN LA TABLA VENTAD COMO EDITAR, INSERTARY ELIMINAR REGISTROS  
--EJEMPLO   : EXEC DBO.SP_DM0312ManejoAlmacenes   
--============================================================================================================================================================    
-- MODIFICACION: PEREZ OROZCO ERIKA JEANETTE  
-- FECHA:        10/10/2018  
-- DESCRIPCION:  SE AGREGA LA VALIDACION DE QUE SI EL ARTICULO ES DE TIPO COMPONENTE SI PUEDA SER INSERTADO AUNQUE UN PAQUETE YA TENGA ESE MISMO ARTICULO   
--============================================================================================================================================================ 
-- MODIFICACION: Morelos Gonzalez Armando  
-- FECHA:        2019-11-04
-- DESCRIPCION:  Se agrega deletes a las tablas 'DM0313AutorizaIncremento' y 'AutorizacionesUsuarioDescuentoMavi' en la operacion 2
--============================================================================================================================================================   

ALTER PROCEDURE [dbo].[SP_DM0312OperacionesInsDelVentaD] @ID int,
@Renglon float,
@RenglonSub int,
@RenglonID int,
@RenglonTipo char,
@EnviarA int,
@Almacen varchar(10),
@Articulo varchar(20),
@Cantidad float,
@Precio float,
@PrecioSugerido float,
@Impuesto1 float,
@Costo float,
@Paquete int,
@ContUso varchar(10),
@Factor float,
@Unidad varchar(15),
@Agente varchar(10),
@Sucursal int,
@SucursalOrigen int,
@UEN int,
@PropreListaID int,
@OP int,
@DescripcionExtra varchar(100)
AS

  DECLARE @COUNT int,
          @CANTIDADACTUAL int,
          @TIPOPAQUETE varchar(5)

  BEGIN TRAN OPERACIONES
    SET NOCOUNT ON

    IF (@OP = 1)
    BEGIN

      SELECT
        @COUNT = COUNT(*)
      FROM VentaD WITH (NOLOCK)
      WHERE Articulo = @Articulo
      AND ID = @ID

      SELECT TOP 1
        @TIPOPAQUETE = RENGLONTIPO
      FROM VentaD WITH (NOLOCK)
      WHERE Articulo = @Articulo
      AND ID = @ID

      IF (@COUNT = 1
        AND @TIPOPAQUETE <> 'C')
      BEGIN
        SELECT
          @CANTIDADACTUAL = CANTIDAD
        FROM VentaD WITH (NOLOCK)
        WHERE Articulo = @Articulo
        AND ID = @ID

        IF @Cantidad != @CANTIDADACTUAL
        BEGIN
          DELETE FROM VentaD
          WHERE ID = @ID
            AND Articulo = @Articulo

          INSERT INTO VentaD (ID, Renglon, RenglonSub, RenglonID, RenglonTipo, EnviarA, Almacen, Articulo, Cantidad, Precio, PrecioSugerido, Impuesto1, Impuesto2, Impuesto3, Costo, Paquete,
          ContUso, Factor, Unidad, FechaRequerida, Agente, Sucursal, SucursalOrigen, UEN, PropreListaID, DescuentoTipo, DescripcionExtra)
            VALUES (@ID, @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @EnviarA, @Almacen, @Articulo, @Cantidad, @Precio, @PrecioSugerido, @Impuesto1, 0.0, 0.0, @Costo, @Paquete, @ContUso, @Factor, @Unidad, GETDATE(), @Agente, @Sucursal, @SucursalOrigen, @UEN, @PropreListaID, NULL, @DescripcionExtra)

        END
      END
      ELSE
      BEGIN

        INSERT INTO VentaD (ID, Renglon, RenglonSub, RenglonID, RenglonTipo, EnviarA, Almacen, Articulo, Cantidad, Precio, PrecioSugerido, Impuesto1, Impuesto2, Impuesto3, Costo, Paquete,
        ContUso, Factor, Unidad, FechaRequerida, Agente, Sucursal, SucursalOrigen, UEN, PropreListaID, DescuentoTipo, DescripcionExtra)
          VALUES (@ID, @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @EnviarA, @Almacen, @Articulo, @Cantidad, @Precio, @PrecioSugerido, @Impuesto1, 0.0, 0.0, @Costo, @Paquete, @ContUso, @Factor, @Unidad, GETDATE(), @Agente, @Sucursal, @SucursalOrigen, @UEN, @PropreListaID, NULL, @DescripcionExtra)

      END

    END

    IF (@OP = 2)
    BEGIN
      DELETE FROM DM0313AutorizaIncremento
      WHERE ID = @ID
        AND ART = @Articulo

      DELETE FROM AutorizacionesUsuarioDescuentoMavi
      WHERE VtaId = @ID
        AND VtaRenglon = @Renglon

      DELETE FROM VentaD
      WHERE ID = @ID
        AND Articulo = @Articulo
    END

    IF (@OP = 3)
    BEGIN
      DELETE FROM VentaD
      WHERE ID = @ID
    END

    IF (@OP = 4)
    BEGIN
      UPDATE VentaD WITH (ROWLOCK)
      SET Cantidad = @Cantidad
      WHERE ID = @ID
      AND Articulo = @Articulo
    END

    IF (@OP = 5)
    BEGIN

      SET @ContUso = (SELECT
        CentroCostos
      FROM sucursal WITH (NOLOCK)
      WHERE Sucursal = @Sucursal)
      SET @PropreListaID = (SELECT
        dbo.fnProprePrecioID(@ID, @Articulo, 0))
      SELECT
        @COUNT = COUNT(*)
      FROM VentaD WITH (NOLOCK)
      WHERE Articulo = @Articulo
      AND ID = @ID

      IF (@COUNT = 1)
      BEGIN
        DELETE FROM VentaD
        WHERE ID = @ID
          AND Articulo = @Articulo
      END

      INSERT INTO VentaD (ID, Renglon, RenglonSub, RenglonID, RenglonTipo, EnviarA, Almacen, Articulo, Cantidad, Precio, PrecioSugerido, Impuesto1, Impuesto2, Impuesto3, Costo, Paquete,
      ContUso, Factor, Unidad, FechaRequerida, Agente, Sucursal, SucursalOrigen, UEN, PropreListaID, DescuentoTipo, DescripcionExtra)
        VALUES (@ID, @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @EnviarA, @Almacen, @Articulo, @Cantidad, @Precio, @PrecioSugerido, @Impuesto1, 0.0, 0.0, @Costo, @Paquete, @ContUso, @Factor, @Unidad, GETDATE(), @Agente, @Sucursal, @SucursalOrigen, @UEN, @PropreListaID, NULL, @DescripcionExtra)

    END


    IF (@@ERROR > 1)
    BEGIN
      ROLLBACK TRAN OPERACIONES
      SELECT
        ERROR_MESSAGE()
    END
    ELSE
    BEGIN
    COMMIT TRAN OPERACIONES
    SELECT
      'OK'

    SET NOCOUNT OFF
  END