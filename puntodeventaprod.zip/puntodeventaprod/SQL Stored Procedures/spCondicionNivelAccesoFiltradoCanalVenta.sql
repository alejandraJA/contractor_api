SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT - 1
SET QUOTED_IDENTIFIER OFF
SET NOCOUNT ON
SET IMPLICIT_TRANSACTIONS OFF
GO
-- =======================================================================================================================================
-- NOMBRE  		: spCondicionNivelAccesoFiltradoCanalVenta
-- AUTOR			: ORTIZ FLORES JOSE CARLOS
-- FECHA CREACION	: 2015/18/01
-- DESARROLLO		: Filtro Campo Condición
-- MODULO			: Venta
-- DESCRIPCION		: Filtrado de Campo Condicion segun canal de venta 
-- Ejemplo			: EXEC spCondicionNivelAccesoFiltradoCanalVenta  'contm00002',11
-- ========================================================================================================================================
--MODIFICACION: Fernando Romero Robles se agrega la nueva categoria de credito empresario 20/06/2019
-- ========================================================================================================================================


ALTER PROCEDURE [dbo].[spCondicionNivelAccesoFiltradoCanalVenta] @Usuario varchar(10),
@CANALVENTA int
AS
BEGIN
  IF EXISTS (SELECT
      id
    FROM tempdb.sys.sysobjects
    WHERE id = OBJECT_ID('tempdb.dbo.#condicion')
    AND type = 'U')
    DROP TABLE #condicion
  CREATE TABLE
  #condicion (
    condicion varchar(50)
  )
  INSERT #condicion
  EXEC spCondicionNivelAcceso @Usuario

  DECLARE @CATEGORIA varchar(max)
  SELECT
    @CATEGORIA =
    Categoria
  FROM VentasCanalMAVI WITH (NOLOCK)
  WHERE ID = @CANALVENTA

  IF @CATEGORIA IN ('CONTADO', 'CREDITO EXTERNO'/*,'DINERALIA', 'CREDILANA EMPRESARIO'*/)
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Contado'
    AND Grupo = 'menudeo')

  END


  --56 viu
  --11 ma
  IF @CATEGORIA = 'CREDITO MENUDEO'
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion NOT LIKE '%INS%'
    AND Condicion NOT LIKE '%VAL%'
    AND Grupo = 'menudeo'
    AND Condicion NOT LIKE '%AVA%')
  END


  IF @CATEGORIA = 'ASOCIADOS'
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion LIKE '%VAL%')
  END


  IF @CATEGORIA = 'MAYOREO'
    AND @CANALVENTA <> 11
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE Grupo = 'MAYOREO')
  END

  IF @CATEGORIA = 'MAYOREO'
    AND @CANALVENTA = 11
  BEGIN
    SELECT
      condicion
    FROM #condicion

  END

  IF @CATEGORIA = 'INSTITUCIONES'
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion LIKE '%ins%')
  END

  IF @CATEGORIA = 'CREDILANA EMPRESARIO'
  BEGIN
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND Condicion LIKE '%DIEM%')
  END

  IF EXISTS (SELECT
      id
    FROM tempdb.sys.sysobjects
    WHERE id = OBJECT_ID('tempdb.dbo.#condicion')
    AND type = 'U')
    DROP TABLE #condicion

END
 

 