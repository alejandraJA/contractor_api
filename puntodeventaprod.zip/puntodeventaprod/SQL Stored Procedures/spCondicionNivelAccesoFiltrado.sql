SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT - 1
SET QUOTED_IDENTIFIER OFF
SET NOCOUNT ON
SET IMPLICIT_TRANSACTIONS OFF
GO
-- =======================================================================================================================================
-- NOMBRE  		: spCondicionNivelAccesoFiltrado
-- AUTOR			: ORTIZ FLORES JOSE CARLOS
-- FECHA CREACION	: 2015/18/01
-- DESARROLLO		: Filtro Campo Condición
-- MODULO			: Venta
-- DESCRIPCION		: Filtrado de Campo Condicion
-- Ejemplo			: EXEC spCondicionNivelAccesoFiltrado 'contm00002',11
-- ========================================================================================================================================
-- MODIFICACION:   Fernando Romero Robles se agrega la condicion de credito empresario 
-- ========================================================================================================================================
ALTER PROCEDURE [dbo].[spCondicionNivelAccesoFiltrado] @Usuario varchar(10),
@CANALVENTA int

AS
BEGIN
  IF EXISTS (SELECT
      id
    FROM tempdb.sys.sysobjects
    WHERE id = OBJECT_ID('tempdb.dbo.#condicion')
    AND type = 'U')
    DROP TABLE #condicion
  CREATE TABLE
  #condicion (
    condicion varchar(50)
  )
  INSERT #condicion
  EXEC spCondicionNivelAcceso @Usuario


  DECLARE @CATEGORIA varchar(max)
  SELECT
    @CATEGORIA =
    Categoria
  FROM VentasCanalMAVI WITH (NOLOCK)
  WHERE ID = @CANALVENTA

  IF @CATEGORIA IN ('CONTADO', 'CREDITO EXTERNO'/*,'DINERALIA', 'CREDILANA EMPRESARIO'*/)
  BEGIN--1
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Contado'
    AND Grupo = 'menudeo'
    AND condicion NOT IN ('12 M MA PP CN', '12 M VIU PP CN'))

  END--1

  IF @CATEGORIA = 'CREDITO MENUDEO'
  BEGIN--2
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion NOT LIKE '%INS%'
    AND Condicion NOT LIKE '%VAL%'
    AND Grupo = 'menudeo'
    AND Condicion NOT LIKE '%AVA%'
    AND condicion NOT IN ('12 M MA PP CN', '12 M VIU PP CN', '18 M MA PP CN', '18 M VIU PP CN', '12 M MA PP CEL CN', '12 M VIU PP CEL CN'))
  END--2


  IF @CATEGORIA = 'ASOCIADOS'
  BEGIN --3
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion LIKE '%VAL%'
    AND condicion NOT IN ('12 M MA PP CN', '12 M VIU PP CN', '12 M VIU PP CEL CN', '12 M MA PP CEL CN'))
  END --3

  IF @CATEGORIA = 'MAYOREO'
    AND @CANALVENTA <> 11
  BEGIN --4
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE Grupo = 'MAYOREO'
    AND Condicion NOT IN ('12 M MA PP CN', '12 M VIU PP CN', '12 M MA PP CEL CN', '12 M VIU PP CEL CN'))

  END --4


  IF @CATEGORIA = 'MAYOREO'
    AND @CANALVENTA = 11
  BEGIN --5
    SELECT
      condicion
    FROM #condicion

  END --5        

  IF @CATEGORIA = 'INSTITUCIONES'
  BEGIN --6
    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion LIKE '%ins%'
    AND condicion NOT IN ('12 M MA PP CN', '12 M VIU PP CN', '12 M VIU PP CEL CN', '12 M MA PP CEL CN'))
  END --6
  IF @CATEGORIA = 'CREDILANA EMPRESARIO'
  BEGIN

    SELECT
      condicion
    FROM #condicion
    WHERE Condicion IN (SELECT
      condicion
    FROM Condicion WITH (NOLOCK)
    WHERE TipoCondicion = 'Credito'
    AND condicion LIKE '%DIEM%')
  END

  IF EXISTS (SELECT
      id
    FROM tempdb.sys.sysobjects
    WHERE id = OBJECT_ID('tempdb.dbo.#condicion')
    AND type = 'U')
    DROP TABLE #condicion
END



