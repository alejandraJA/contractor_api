﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using PuntoVenta.Controller;
using PuntoVenta.Model;
using PuntoVenta.View;
using Timer = System.Timers.Timer;

namespace PuntoVenta
{
    internal static class Program
    {
        private static bool flag;

        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main(string[] arg)
        {
            DM0312_C_Login Controlador = new DM0312_C_Login();
            DM0312_CPuntoDeVenta CPuntoVenta = new DM0312_CPuntoDeVenta();
            ConfigColumnas CColumna = new ConfigColumnas();
            DM0312_C_ExploradorVenta venta = new DM0312_C_ExploradorVenta();
            clsStd sdt = new clsStd();

            //string[] args = new string[3];
            //args[0] = "VENTP00740";
            //args[1] = "21433";
            //args[2] = "26";


            try
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("es-MX");

                ///*Timer for CloseApp whithout intelisis APP*/
                Timer aTimer = new Timer();
                //aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                aTimer.Interval = 1;
                aTimer.Enabled = true;
                ///************/

                ////bool i = CheckAppActive();
                bool CerrarTodo = false;
                ////MessageBox.Show(arg[0].ToString());
                if (arg.Length > 0 && arg[0] == "CerrarTodo") CerrarTodo = true;
                //if (arg.Length> 1)
                //{
                //    ClaseEstatica.Usuario.sucursal = Convert.ToInt32(arg[2].ToString());
                //}


                conexion Conexion = new conexion();
                Conexion.SqlConexionStatica();
                ClaseEstatica.ConexionEstatica.Open();

                Conexion.SqlConexionStaticaAndroid();
                ClaseEstatica.ConexionEstaticaAndroid.Open();

                //-Venta Cruzada
                //Conexion para agregar registros a ServicioAndroid
                Conexion.SqlConexionStaticaAndroidServicio();
                ClaseEstatica.ConexionEstaticaAndroidS.Open();

                //-ReporteDima
                Conexion.SqlConexionStaticaAndroidSid();
                ClaseEstatica.ConexionEstaticaAndroidSid.Open();

                //-HistoricoAdminDoc
                Conexion.SqlConexionStaticaHistoricoAdminDoc();
                ClaseEstatica.ConexionHistoricoAdminDoc.Open();

                Controlador.SPID();

                CPuntoVenta.GetTipoCosteo();

                //-CerradoIntelisis
                //-CerradoIntelisis
                DateTime fechaActual = venta.FechaActualServidor();

                string cadena = arg[0] + "-" + fechaActual.ToString("yyyy-MM-dd-mm-ss-mm").Trim();

                string md5 = sdt.GetMD5(cadena);

                ClaseEstatica.loginID = md5;
                sdt.actualizarMd5(md5, arg[0]);

                if (arg.Length == 1)
                {
                    string Acceso = string.Empty;
                    Acceso = arg[0];
                    if (Acceso == "1")
                    {
                        DM0312_MenuDeConfiguraciones form = new DM0312_MenuDeConfiguraciones();
                        Application.Run(form);
                    }

                    if (Acceso == "2")
                    {
                        DM0312_Promociones form1 = new DM0312_Promociones();
                        Application.Run(form1);
                    }
                }
                else
                {
                    List<Usuario> Usuarios = new List<Usuario>();

                    string Usuario = arg[0];

                    ClaseEstatica.WorkStation = Convert.ToInt32(arg[1]);
                    ClaseEstatica.iSucural = Convert.ToInt32(arg[2]);
                    string Acceso = string.Empty;


                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);

                    Usuarios = Controlador.IngresaLogin();

                    ClaseEstatica.Usuario = Usuarios.Where(x => x.usuario.Trim() == Usuario.Trim()).FirstOrDefault();
                    ClaseEstatica.Usuario.sucursal = Convert.ToInt32(arg[2]);
                    ClaseEstatica.Usuario.Uen = Controlador.Uen(ClaseEstatica.Usuario.sucursal);
                    ClaseEstatica.Usuario.color = CColumna.TipoColor(ClaseEstatica.Usuario.Acceso);


                    Controlador.AgenteU();


                    if (arg.Length == 5)
                        if (arg[3] == "HISTORIAL")
                        {
                            int IdVenta = int.Parse(arg[4]);
                            if (Controlador.validarVenta(IdVenta))
                            {
                                DM0312_MExploradorVenta ModelSeleccionado = new DM0312_MExploradorVenta();

                                ModelSeleccionado = Controlador.llenarVenta(IdVenta);

                                HistorialSolicitudes historialSol = new HistorialSolicitudes();
                                historialSol.recibeMensajeUsuario = ClaseEstatica.Usuario.Usser;
                                historialSol.recibeMensajeCliente = ModelSeleccionado.Cliente;
                                historialSol.recibeMensajeIdVenta = Convert.ToString(ModelSeleccionado.ID);
                                historialSol.recibeMovId = ModelSeleccionado.MovId;
                                historialSol.recibeCliente = ModelSeleccionado.Cliente;
                                historialSol.recibeMov = ModelSeleccionado.Mov;
                                historialSol.recibeFecha = DateTime.Now.ToString("dd/MM/yyyy");
                                historialSol.recibeSituacion = ModelSeleccionado.Situacion;
                                historialSol.recibeSucursal = Convert.ToString(ModelSeleccionado.Suc);
                                historialSol.recibeFechaD = DateTime.Now.ToString("dd/MM/yyyy");
                                historialSol.ShowDialog();
                                Application.Exit();
                                return;
                            }
                        }


                    if (CheckAppActive(CerrarTodo))
                    {
                        MessageBox.Show("No se puede abrir otra ventana de Punto de Venta", "Error!!!",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (ClaseEstatica.Usuario != null)
                    {
                        List<string> ListaSuc = new List<string>();
                        ListaSuc = Controlador.SucursalesAcceso();
                        int contador = 0;

                        foreach (string lista in ListaSuc)
                            if (ClaseEstatica.Usuario.sucursal == Convert.ToInt32(lista))
                            {
                                //-CambioRutaPlugins
                                ClaseEstatica.plugInPath =
                                    new DirectoryInfo(Application.StartupPath).Parent.FullName + "\\";

                                //ClaseEstatica.plugInPath = pdfPath;
                                DM0312_ExploradorVentas tablero = new DM0312_ExploradorVentas();
                                AccesosDeUsuario UsuarioAcceso = new AccesosDeUsuario();
                                ConfigColumnas CColumnas = new ConfigColumnas();
                                AccesosDeUsuario.AccesosUsuario =
                                    UsuarioAcceso.ObtenerAccesos(ClaseEstatica.Usuario.Usser);

                                //Obtener accesos de usuario que quedan en toda la aplicacion
                                UsuarioAcceso.ObtenerConfiguracionUsuario(ClaseEstatica.Usuario.Usser,
                                    ClaseEstatica.Usuario.grupo);
                                CColumnas.ObtenerColumnasTablero();
                                tablero = (DM0312_ExploradorVentas)UsuarioAcceso.AplicarVistas(tablero);
                                tablero.recibeMensaje = ClaseEstatica.Usuario.Usser;
                                tablero.recibeSucursal = ClaseEstatica.Usuario.sucursal;
                                Application.Run(tablero);
                                contador = 1;
                            }

                        if (ListaSuc.Count == 0 || contador == 0)
                        {
                            MessageBox.Show("No se puede abrir Punto de Venta. Solo perfiles autorizados",
                                "Advertencia!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Application.Exit();
                        }
                    }
                    else
                    {
                        Application.Exit();
                    }
                }
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Main", "Program.cs", ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            CheckIntelisisActive();
        }

        private static bool CheckAppActive(bool CerrarTodo = false)
        {
            //lista de procesos para abrir ventanas
            List<Process> ListP = new List<Process>();
            DM0312_CPuntoDeVenta CPuntoVent = new DM0312_CPuntoDeVenta();
            int TabNum = CPuntoVent.SucursalRDP(ClaseEstatica.Usuario.sucursal);

            //arreglo de procesos
            Process[] processes = Process.GetProcesses();

            Process current = Process.GetCurrentProcess();

            //recorrido de procesos
            int procesosAbiertos = 0;
            foreach (Process p in processes)
                if (p.ProcessName.Contains("PuntoVenta"))
                {
                    if (CerrarTodo)
                    {
                        //MessageBox.Show("entro");
                        p.Kill();
                        Environment.Exit(Environment.ExitCode);
                    }
                    else
                    {
                        if (p.SessionId == current.SessionId) procesosAbiertos++;
                    }
                }

            if (procesosAbiertos > 1)
            {
                if (ClaseEstatica.Usuario.sucursal == 99)
                    return false;
                return true;
            }

            return false;
        }

        private static void CheckIntelisisActive()
        {
            try
            {
                //arreglo de procesos
                List<Process> procesos = new List<Process>();

                procesos = Process.GetProcesses().ToList();

                Process item = procesos.Where(x => x.ProcessName.Contains("Intelisis")).FirstOrDefault();

                if (item != null)
                    flag = false;
                else
                    flag = true;


                if (flag) Environment.Exit(Environment.ExitCode);
            }
            catch (Exception ex)
            {
                DM0312_ErrorLog.RegistraError("Main", "Program.cs", ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}